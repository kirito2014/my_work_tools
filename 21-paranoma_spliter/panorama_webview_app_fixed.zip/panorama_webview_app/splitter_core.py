from __future__ import annotations

import base64
import io
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image, ImageOps


IMAGE_FILTER_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tif', '.tiff'}


class PanoramaSplitterCore:
    """Core image loading, preview calculation and lossless crop/export logic.

    This module intentionally contains no Tkinter / pywebview code so it can be reused
    by a desktop WebView UI, CLI, tests, or another GUI shell.
    """

    ratio_presets: Dict[str, Optional[Tuple[int, int]]] = {
        '9:16': (9, 16),
        '1:2': (1, 2),
        '3:4': (3, 4),
        '2:3': (2, 3),
        '1:1': (1, 1),
        '4:5': (4, 5),
        '16:9': (16, 9),
        '自定义': None,
    }

    def __init__(self) -> None:
        self.image_path: Optional[Path] = None
        self.original_image: Optional[Image.Image] = None

    def has_image(self) -> bool:
        return self.image_path is not None and self.original_image is not None

    def load_image(self, path: str | Path) -> Dict[str, Any]:
        image_path = Path(path)
        if not image_path.exists():
            raise FileNotFoundError(f'图片不存在：{image_path}')
        if image_path.suffix.lower() not in IMAGE_FILTER_EXTENSIONS:
            raise ValueError('不支持的图片格式，请选择 JPG / PNG / WEBP / BMP / TIFF。')

        img = Image.open(image_path)
        img = ImageOps.exif_transpose(img)
        img.load()

        if img.mode not in ('RGB', 'RGBA'):
            img = img.convert('RGB')

        self.image_path = image_path
        self.original_image = img

        return {
            'name': image_path.name,
            'path': str(image_path),
            'width': img.width,
            'height': img.height,
            'mode': img.mode,
        }

    def get_ratio(self, ratio_name: str = '9:16', custom_w: int = 9, custom_h: int = 16) -> Tuple[float, str]:
        if ratio_name == '自定义':
            try:
                w = max(1, int(custom_w))
                h = max(1, int(custom_h))
                return w / h, f'{w}:{h}'
            except Exception:
                return 9 / 16, '9:16'

        preset = self.ratio_presets.get(ratio_name, (9, 16))
        if preset is None:
            return 9 / 16, '9:16'
        return preset[0] / preset[1], ratio_name

    def get_max_count(self, ratio_name: str, custom_w: int, custom_h: int, mode: str) -> int:
        if self.original_image is None:
            return 1

        img_w = self.original_image.width
        img_h = self.original_image.height
        ratio_value, _ = self.get_ratio(ratio_name, custom_w, custom_h)

        if mode == 'fixed_height':
            piece_w = max(1, int(img_h * ratio_value))
            return max(1, img_w // piece_w)

        min_piece_w = max(1, int(img_h * ratio_value))
        max_reasonable = max(1, img_w // min_piece_w)
        return max(1, min(30, max(img_w // 200, max_reasonable)))

    def clamp_split_count(self, count: int, ratio_name: str, custom_w: int, custom_h: int, mode: str) -> int:
        max_count = self.get_max_count(ratio_name, custom_w, custom_h, mode)
        try:
            value = int(count)
        except Exception:
            value = 1
        return min(max(1, value), max_count)

    def auto_recommend_count(self, ratio_name: str, custom_w: int, custom_h: int, mode: str) -> int:
        if self.original_image is None:
            return 1

        img_w = self.original_image.width
        img_h = self.original_image.height
        ratio_value, _ = self.get_ratio(ratio_name, custom_w, custom_h)

        if mode == 'fixed_height':
            piece_w = max(1, int(img_h * ratio_value))
            return min(max(1, img_w // piece_w), self.get_max_count(ratio_name, custom_w, custom_h, mode))

        best_count = 1
        best_score = float('inf')
        max_count = self.get_max_count(ratio_name, custom_w, custom_h, mode)

        for count in range(1, max_count + 1):
            piece_w = img_w / count
            piece_h = piece_w / ratio_value
            if piece_h > img_h:
                continue
            vertical_loss = img_h - piece_h
            piece_width_score = abs(piece_w - 1080)
            score = vertical_loss * 10 + piece_width_score
            if score < best_score:
                best_score = score
                best_count = count

        return best_count

    def get_crop_boxes(
        self,
        ratio_name: str,
        custom_w: int,
        custom_h: int,
        split_count: int,
        mode: str,
    ) -> List[Tuple[int, int, int, int]]:
        if self.original_image is None:
            return []

        img_w = self.original_image.width
        img_h = self.original_image.height
        count = self.clamp_split_count(split_count, ratio_name, custom_w, custom_h, mode)
        ratio_value, _ = self.get_ratio(ratio_name, custom_w, custom_h)
        boxes: List[Tuple[int, int, int, int]] = []

        if mode == 'fixed_height':
            piece_h = img_h
            piece_w = max(1, int(round(piece_h * ratio_value)))
            total_w = piece_w * count

            if total_w > img_w:
                count = max(1, img_w // piece_w)
                total_w = piece_w * count

            start_x = max(0, (img_w - total_w) // 2)
            for i in range(count):
                left = start_x + i * piece_w
                right = min(img_w, left + piece_w)
                boxes.append((left, 0, right, img_h))
            return boxes

        for i in range(count):
            left = int(round(i * img_w / count))
            right = int(round((i + 1) * img_w / count))
            piece_w = max(1, right - left)
            piece_h = int(round(piece_w / ratio_value))

            if piece_h > img_h:
                piece_h = img_h
                adjusted_w = int(round(piece_h * ratio_value))
                cx = (left + right) // 2
                left = max(0, cx - adjusted_w // 2)
                right = min(img_w, left + adjusted_w)

            top = max(0, (img_h - piece_h) // 2)
            bottom = min(img_h, top + piece_h)
            boxes.append((left, top, right, bottom))

        return boxes

    def preview_payload(
        self,
        ratio_name: str,
        custom_w: int,
        custom_h: int,
        split_count: int,
        mode: str,
        include_image: bool = False,
        max_preview_width: int = 1800,
    ) -> Dict[str, Any]:
        if self.original_image is None or self.image_path is None:
            return {'ok': False, 'error': '尚未选择图片。'}

        img = self.original_image
        max_count = self.get_max_count(ratio_name, custom_w, custom_h, mode)
        safe_count = self.clamp_split_count(split_count, ratio_name, custom_w, custom_h, mode)
        boxes = self.get_crop_boxes(ratio_name, custom_w, custom_h, safe_count, mode)
        ratio_value, ratio_label = self.get_ratio(ratio_name, custom_w, custom_h)

        data: Dict[str, Any] = {
            'ok': True,
            'name': self.image_path.name,
            'path': str(self.image_path),
            'width': img.width,
            'height': img.height,
            'ratioLabel': ratio_label,
            'ratioValue': ratio_value,
            'splitCount': safe_count,
            'maxCount': max_count,
            'boxes': [
                {'left': l, 'top': t, 'right': r, 'bottom': b, 'width': r - l, 'height': b - t}
                for l, t, r, b in boxes
            ],
        }

        if boxes:
            first = boxes[0]
            data['info'] = f'单张约 {first[2] - first[0]} × {first[3] - first[1]}px，共 {len(boxes)} 张'
        else:
            data['info'] = '当前参数无法生成有效切分区域。'

        if include_image:
            scale = min(1.0, max_preview_width / max(1, img.width))
            preview = img
            if scale < 1:
                preview = img.resize((int(img.width * scale), int(img.height * scale)), Image.Resampling.LANCZOS)
            if preview.mode == 'RGBA':
                export_img = preview
            else:
                export_img = preview.convert('RGB')
            buffer = io.BytesIO()
            export_img.save(buffer, format='PNG', optimize=True)
            data['previewDataUrl'] = 'data:image/png;base64,' + base64.b64encode(buffer.getvalue()).decode('ascii')
            data['previewWidth'] = preview.width
            data['previewHeight'] = preview.height
            data['previewScale'] = scale

        return data

    def get_output_format(self, selected: str) -> Tuple[str, str]:
        if self.image_path is None:
            return 'PNG', '.png'

        if selected == '原格式':
            suffix = self.image_path.suffix.lower()
            if suffix in ['.jpg', '.jpeg']:
                return 'JPEG', '.jpg'
            if suffix == '.png':
                return 'PNG', '.png'
            if suffix == '.webp':
                return 'WEBP', '.webp'
            if suffix in ['.tif', '.tiff']:
                return 'TIFF', '.tif'
            if suffix == '.bmp':
                return 'BMP', '.bmp'
            return 'PNG', '.png'

        if selected == 'JPEG':
            return 'JPEG', '.jpg'
        if selected == 'WEBP':
            return 'WEBP', '.webp'
        return 'PNG', '.png'

    def get_output_dir(self) -> Optional[Path]:
        if self.image_path is None:
            return None
        return self.image_path.parent / '切分输出'

    def split_and_save(
        self,
        ratio_name: str,
        custom_w: int,
        custom_h: int,
        split_count: int,
        mode: str,
        output_format: str,
        output_quality: int,
    ) -> Dict[str, Any]:
        if self.original_image is None or self.image_path is None:
            return {'ok': False, 'error': '请先选择一张全景图片。'}

        boxes = self.get_crop_boxes(ratio_name, custom_w, custom_h, split_count, mode)
        if not boxes:
            return {'ok': False, 'error': '当前参数无法生成有效切分区域。'}

        output_dir = self.get_output_dir()
        if output_dir is None:
            return {'ok': False, 'error': '无法确定输出目录。'}

        output_dir.mkdir(parents=True, exist_ok=True)
        fmt, ext = self.get_output_format(output_format)
        base_name = self.image_path.stem
        saved_files: List[str] = []

        for index, box in enumerate(boxes, start=1):
            crop = self.original_image.crop(box)

            if fmt == 'JPEG':
                if crop.mode == 'RGBA':
                    background = Image.new('RGB', crop.size, (255, 255, 255))
                    background.paste(crop, mask=crop.split()[-1])
                    crop = background
                else:
                    crop = crop.convert('RGB')

            output_path = output_dir / f'{base_name}_切分_{index:02d}{ext}'
            save_kwargs: Dict[str, Any] = {}

            if fmt in ('JPEG', 'WEBP'):
                save_kwargs['quality'] = int(output_quality)
                save_kwargs['optimize'] = True
            if fmt == 'PNG':
                save_kwargs['compress_level'] = 0

            crop.save(output_path, format=fmt, **save_kwargs)
            saved_files.append(str(output_path))

        return {
            'ok': True,
            'count': len(saved_files),
            'outputDir': str(output_dir),
            'files': saved_files,
        }
