# 全景图片切图工具 - pywebview + Tailwind 版本

这是基于原 Tkinter 版本重构的 WebView 桌面应用雏形：

- `app.py`：pywebview 桌面窗口与 JS API 桥接层。
- `splitter_core.py`：图片加载、比例计算、裁切框计算、导出保存等核心逻辑。
- `frontend/index.html`：TailwindCSS + 原生 JavaScript 界面。
- `original_tkinter_reference.py`：保留的原始 Tkinter 参考文件。

## 安装依赖

```bash
pip install -r requirements.txt
```

## 运行

```bash
python app.py
```

## 说明

当前版本使用 Tailwind CDN，开发时最方便。如果要打包为离线 EXE，建议把 Tailwind 编译为本地 CSS 文件，然后移除 CDN 引用。

核心功能沿用原版思路：

- 支持 JPG / JPEG / PNG / WEBP / BMP / TIFF。
- 支持 9:16、1:2、3:4、2:3、1:1、4:5、16:9、自定义比例。
- 支持固定高度切分、智能铺满宽度。
- 支持 PNG / JPEG / WEBP / 原格式输出。
- 输出目录默认是原图同级目录下的 `切分输出`。
