from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any, Dict

import webview

from splitter_core import PanoramaSplitterCore


BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR / 'frontend'
INDEX_HTML = FRONTEND_DIR / 'index.html'


class PanoramaApi:
    def __init__(self) -> None:
        self.core = PanoramaSplitterCore()
        # 注意：不要使用 self.window 这种公开属性名。
        # pywebview 会把 js_api 对象暴露给前端，并递归扫描公开属性；
        # 如果公开属性里保存了 WebView 窗口对象，会导致递归扫描 window.native，
        # 在 Windows WebView2 下可能触发 maximum recursion depth exceeded / UI thread 错误。
        self._window = None

    def _set_window(self, window) -> None:
        self._window = window

    def _settings(self, settings: Dict[str, Any]) -> Dict[str, Any]:
        return {
            'ratioName': settings.get('ratioName', '9:16'),
            'customW': int(settings.get('customW', 9) or 9),
            'customH': int(settings.get('customH', 16) or 16),
            'splitCount': int(settings.get('splitCount', 3) or 3),
            'mode': settings.get('mode', 'fixed_height'),
            'outputFormat': settings.get('outputFormat', 'PNG'),
            'outputQuality': int(settings.get('outputQuality', 95) or 95),
        }

    def select_image(self, settings: Dict[str, Any]) -> Dict[str, Any]:
        if self._window is None:
            return {'ok': False, 'error': '窗口尚未初始化。'}

        file_types = (
            'Image Files (*.jpg;*.jpeg;*.png;*.webp;*.bmp;*.tif;*.tiff)',
            'All files (*.*)',
        )
        result = self._window.create_file_dialog(
            webview.FileDialog.OPEN,
            allow_multiple=False,
            file_types=file_types,
        )
        if not result:
            return {'ok': False, 'cancelled': True}

        selected_path = result[0]
        try:
            meta = self.core.load_image(selected_path)
            s = self._settings(settings)
            recommended = self.core.auto_recommend_count(s['ratioName'], s['customW'], s['customH'], s['mode'])
            payload = self.core.preview_payload(
                s['ratioName'],
                s['customW'],
                s['customH'],
                recommended,
                s['mode'],
                include_image=True,
            )
            payload['recommendedCount'] = recommended
            payload['loaded'] = meta
            return payload
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def update_preview(self, settings: Dict[str, Any]) -> Dict[str, Any]:
        try:
            s = self._settings(settings)
            return self.core.preview_payload(
                s['ratioName'],
                s['customW'],
                s['customH'],
                s['splitCount'],
                s['mode'],
                include_image=False,
            )
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def auto_recommend_count(self, settings: Dict[str, Any]) -> Dict[str, Any]:
        if not self.core.has_image():
            return {'ok': False, 'error': '请先选择一张全景图片。'}
        try:
            s = self._settings(settings)
            count = self.core.auto_recommend_count(s['ratioName'], s['customW'], s['customH'], s['mode'])
            payload = self.core.preview_payload(s['ratioName'], s['customW'], s['customH'], count, s['mode'])
            payload['recommendedCount'] = count
            return payload
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def split_and_save(self, settings: Dict[str, Any]) -> Dict[str, Any]:
        try:
            s = self._settings(settings)
            return self.core.split_and_save(
                s['ratioName'],
                s['customW'],
                s['customH'],
                s['splitCount'],
                s['mode'],
                s['outputFormat'],
                s['outputQuality'],
            )
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def open_output_folder(self) -> Dict[str, Any]:
        output_dir = self.core.get_output_dir()
        if output_dir is None:
            return {'ok': False, 'error': '请先选择一张图片。'}
        if not output_dir.exists():
            return {'ok': False, 'error': '还没有生成切分输出文件夹。'}

        try:
            if os.name == 'nt':
                os.startfile(str(output_dir))  # type: ignore[attr-defined]
            elif sys.platform == 'darwin' and shutil.which('open'):
                os.system(f'open "{output_dir}"')
            elif shutil.which('xdg-open'):
                os.system(f'xdg-open "{output_dir}"')
            else:
                return {'ok': True, 'path': str(output_dir), 'message': str(output_dir)}
            return {'ok': True, 'path': str(output_dir)}
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def get_app_info(self) -> Dict[str, Any]:
        return {
            'ok': True,
            'app': '全景图片切图工具',
            'version': '2.0.0-webview',
            'ratios': list(self.core.ratio_presets.keys()),
        }


def main() -> None:
    api = PanoramaApi()
    window = webview.create_window(
        '全景图片切图工具',
        str(INDEX_HTML),
        js_api=api,
        width=1440,
        height=860,
        min_size=(980, 640),
        resizable=True,
        text_select=False,
    )
    api._set_window(window)
    webview.start(debug=False)


if __name__ == '__main__':
    main()
