package cn.huawei.hive.udf;

import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        String strDate = "20201029092449000";
        strDate = strDate.substring(0,14)+"."+strDate.substring(14);
        System.out.println(strDate);
    }
}
