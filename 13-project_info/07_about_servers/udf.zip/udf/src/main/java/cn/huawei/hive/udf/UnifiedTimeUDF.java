package cn.huawei.hive.udf;


import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.Date;
import java.util.Locale;

public class UnifiedTimeUDF  extends UDF {

    public static void main(String[] args) throws Exception {
//        System.out.println(new UnifiedTimeUDF().evaluate("0000-00-00 00:00:00"));
//        System.out.println(new UnifiedTimeUDF().evaluate("0000-00-00 00:00:00.000000"));
//        System.out.println(new UnifiedTimeUDF().evaluate("00000000 00:00:00"));
//        System.out.println(new UnifiedTimeUDF().evaluate("00000000 000000"));
//        System.out.println(new UnifiedTimeUDF().evaluate("0000-00-00 00:00:00.000"));
//        System.out.println(new UnifiedTimeUDF().evaluate("00000000000000"));
//        System.out.println(new UnifiedTimeUDF().evaluate("00000000000000.000000"));
        System.out.println(new UnifiedTimeUDF().evaluate("2015-04-27 15:19:39.651"));
        System.out.println(new UnifiedTimeUDF().evaluate("2023-12-26 08:52:28 000000"));
        System.out.println(new UnifiedTimeUDF().evaluate("2017-11-27-19.03.35.543"));
        System.out.println(new UnifiedTimeUDF().evaluate("20210218160714.294000"));
        System.out.println(new UnifiedTimeUDF().evaluate("202010290924491234"));
    }

    public String evaluate(Object objDate) throws Exception {
        if(objDate==null||"null".equals(objDate)||"NULL".equals(objDate)){
            return null;
        }
        String strDate = String.valueOf(objDate);

        if("".equals(strDate)||"0".equals(strDate)){
            return "1899-12-31";
        }
        String unionDate;
        if (this.regexDate(strDate, 1)) {
            unionDate = strDate;
        } else if (this.regexDate(strDate, 2)) {
            unionDate = this.parseDate(strDate, "yyyy-M-d");
        } else if (this.regexDate(strDate, 3)) {
            unionDate = this.parseTimeStamp(strDate, "uuuu-MM-dd HH:mm:ss",false);
        } else if (this.regexDate(strDate, 4)) {
            unionDate = this.parseTimeStamp(strDate, "uuuu-MM-dd-HH.mm.ss.SSSSSS",true);
        } else if (this.regexDate(strDate, 5)) {
            unionDate = this.parseDate(strDate, "yyyy/M/d");
        } else if (this.regexDate(strDate, 6)) {
            unionDate = this.parseTimeStamp(strDate, "uuuuMMdd HH:mm:ss",false);
        } else if (this.regexDate(strDate, 7)) {
            unionDate = this.parseTimeStamp(strDate, "uuuuMMdd HHmmss",false);
        } else if (this.regexDate(strDate, 8)) {
            long timestamp;
            if (10 == strDate.length()) {
                timestamp = Long.parseLong(strDate) * 1000L;
            } else {
                timestamp = Long.parseLong(strDate);
            }

            Date tsDate = new Date(timestamp);
            SimpleDateFormat tsFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            unionDate = parseTimeStamp(tsFormat.format(tsDate),"uuuu-MM-dd HH:mm:ss.SSS",false);
        } else if (this.regexDate(strDate, 9)) {
            unionDate = this.parseTimeStamp(strDate, "uuuuMMddHHmmss",false);
        } else if (this.regexDate(strDate, 10)) {
            unionDate = this.parseTimeStamp(strDate, "uuuuMMddHHmmss.SSSSSS",true);
        } else if (this.regexDate(strDate, 11)) {
            unionDate = this.parseDate(strDate, "yyyyMMdd");
        } else if (this.regexDate(strDate, 12)) {
            unionDate = this.parseTimeStamp(strDate, "uuuu-MM-dd HH:mm:ss.SSSSSS",true);
        } else if (this.regexDate(strDate, 13)) {
            strDate = strDate.substring(0,19)+"."+strDate.substring(20);
            unionDate = this.parseTimeStamp(strDate, "uuuu-MM-dd HH:mm:ss.SSSSSS",true);
        } else if (this.regexDate(strDate, 14)) {
            strDate = strDate.substring(0,14)+"."+strDate.substring(14);
            unionDate = this.parseTimeStamp(strDate, "uuuuMMddHHmmss.SSSSSS",true);
        } else {
            if(isAllZeroTime(strDate)){
                return "0000-00-00 00:00:00.000000";
            }
            unionDate = strDate;
        }
        return unionDate;
    }

    private boolean isAllZeroTime(String strDate){
        int zeroNum = 0;
        try{
            String zeroStr = strDate;
            zeroStr = zeroStr.replace(":","");
            zeroStr = zeroStr.replace(".","");
            zeroStr = zeroStr.replace("-","");
            zeroStr = zeroStr.replaceAll("\\s+","");
            zeroNum = Integer.parseInt(zeroStr);
        }catch (Exception e){
            return false;
        }

        if(zeroNum==0&&strDate.length()>10){
            return true;
        }

        return false;
    }

    private String parseTimeStamp(String strDate, String dateFormat,boolean isms){
        if(isAllZeroTime(strDate)){
            return "0000-00-00 00:00:00.000000";
        }
        if(isms){
            try{
                int lastPoindex = strDate.lastIndexOf(".");
                String str1 = strDate.substring(0,lastPoindex);
                String str2 = strDate.substring(lastPoindex+1);
                String str3 = "";
                if(str2.length()>=1&&str2.length()<=6){
                    str3 = StringUtils.rightPad(str2,6,"0");
                }
                strDate = str1+"."+str3;
            }catch (Exception e){
                return strDate;
            }

        }
        LocalDateTime localDateTime;
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(dateFormat, Locale.ENGLISH).withResolverStyle(ResolverStyle.STRICT);
        try{
            localDateTime = LocalDateTime.parse(strDate,dateTimeFormatter);
        }catch (Exception e){
            e.printStackTrace();
            return strDate;
        }

        DateTimeFormatter dateTimeFormatter1 = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss.SSSSSS",Locale.ENGLISH);
        return localDateTime.format(dateTimeFormatter1);
    }

    public String parseDate(String strDate, String dateFormat) {
        Date parsedDate;
        SimpleDateFormat inputFormat;
        try {
            inputFormat = new SimpleDateFormat(dateFormat, Locale.ENGLISH);
            inputFormat.setLenient(false);
            parsedDate = inputFormat.parse(strDate);
        } catch (ParseException var5) {
            return strDate;
        }

        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
        return outputFormat.format(parsedDate);
    }

    public boolean regexDate(String strDate, Integer dateFormat) {
        Boolean isMatch = false;
        switch(dateFormat) {
            case 1:
                isMatch = strDate.matches("\\d{2}[A-Za-z]{3}\\d{2}");
                break;
            case 2:
                isMatch = strDate.matches("\\d{4}-(0?[1-9]|1[0-2])-(0?[1-9]|[12]\\d|3[01])");
                break;
            case 3:
                isMatch = strDate.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");
                break;
            case 4:
                isMatch = strDate.matches("\\d{4}-\\d{2}-\\d{2}-\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{1,6}");
                break;
            case 5:
                isMatch = strDate.matches("\\d{4}/\\d{1,2}/\\d{1,2}");
                break;
            case 6:
                isMatch = strDate.matches("\\d{8} \\d{2}:\\d{2}:\\d{2}");
                break;
            case 7:
                isMatch = strDate.matches("\\d{8} \\d{6}");
                break;
            case 8:
                isMatch = strDate.matches("\\d{10}|\\d{13}");
                break;
            case 9:
                isMatch = strDate.matches("\\d{14}");
                break;
            case 10:
                isMatch = strDate.matches("\\d{14}\\.\\d{1,6}");
                break;
            case 11:
                isMatch = strDate.matches("\\d{8}");
                break;
            case 12:
                isMatch = strDate.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{1,6}");
                break;
            case 13:
                isMatch = strDate.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2} \\d{1,6}");
                break;
            case 14:
                isMatch = strDate.matches("\\d{15,20}");
                break;
            default:
                break;
        }

        return isMatch;
    }
}
