# -*- coding:utf-8 -*-
#脚本文件位置


#DROP TABLE IF EXISTS hive.agl_comm.agl_get_tabel_info;
# CREATE TABLE hive.agl_comm.agl_get_tabel_info (
#   query_type varchar COMMENT '查询类型',
#   target_table varchar COMMENT '聚合表名',
#   source_table varchar COMMENT '来源表',
#   data_count decimal(20, 0) COMMENT '数据量',
#   data_dt varchar COMMENT '数据日期',
#   belong_person varchar COMMENT '归属人'
#)
#COMMENT '代销信托交易明细表'
#STORE AS ORC;



import os
import sys
import re,sys
import openpyxl

ETL_HOME = os.path.dirname(os.path.abspath(__file__))

def get_belong_theme(file_name):
    file_name_upper = file_name.upper()
    #print(file_name_upper[4:7])
    if file_name_upper[0:7] == "AGL_S01":
        return "AGL_S01"
    elif file_name_upper[0:7] == "AGL_S02":
        return "AGL_S02"
    elif file_name_upper[0:7] == "AGL_S03":
        return "AGL_S03"
    elif file_name_upper[0:7] == "AGL_S04":
        return "AGL_S04"
    elif file_name_upper[0:7] == "AGL_S05":
        return "AGL_S05"
    elif file_name_upper[0:7] in ["AGL_S06","AGL_S07","AGL_S08","AGL_S09","AGL_S10","AGL_S11"]:
        return "AGL_COMM"
    else:
        return "Unknown"
#函数用于提取SQL文件中的文件名
def extract_table_name(sql_content):
    pattern = r'(?:FROM|JOIN)\s+(\w+\.\w+)\s+'
    matches = re.findall(pattern, sql_content.upper())
    return matches

def filter_table_names(file_name, table_names):
    filterd_table_names = []
    for table_name in table_names:
        if file_name.upper().replace('_PC.HQL','').replace('ETL_PROC_','') not in table_name.upper():
            filterd_table_names.append(table_name.upper().replace(' ',''))
    filterd_table_names = list(set(filterd_table_names))
    return filterd_table_names

def process_folder(folder_path,belong_person):
    data = []
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".hql"):
            file_path = os.path.join(folder_path,file_name)
            with open(file_path, 'r',encoding='utf-8') as file:
                sql_content = file.read()
                table_names = extract_table_name(sql_content)
                filterd_table_names = filter_table_names(file_name,table_names)
                belong_theme = get_belong_theme(file_name)
                belong_person = belong_person
                # data[file_name] = [(belong_theme,file_name)] * len(filterd_table_names)
                for table_name in filterd_table_names:
                    data.append((file_name,belong_theme,table_name,belong_person))
    return data

def write_to_excel(data ,output_file ,query_date):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet['A1'] = 'belong_theme'
    sheet['B1'] = 'file_name'
    sheet['C1'] = 'table_name'
    sheet['D1'] = 'belong_person'
    sheet['E1'] = 'query_target'
    sheet['F1'] = 'query_source'

    
    for idx,(file_name,belong_theme,table_name,belong_person) in enumerate(data, start=2):
        sheet.cell(row=idx, column=1, value=belong_theme)
        sheet.cell(row=idx, column=2, value=file_name.upper().replace('_PC.HQL','').replace('ETL_PROC_',''))
        sheet.cell(row=idx, column=3, value=table_name)
        sheet.cell(row=idx, column=4, value=belong_person)
        
        formulaE=f'="insert into AGL_COMM.AGL_GET_TABEL_INFO SELECT \'TT\', \'"&UPPER(TRIM(B{idx}))&"\',\'\',COUNT(1) ,\'{query_date}\',\'"&D{idx}&"\' FROM "&A{idx}&"."&B{idx}&" WHERE PT_DT = \'{query_date}\';"'
        formulaF=f'="insert into AGL_COMM.AGL_GET_TABEL_INFO  SELECT \'ST\',\'"&UPPER(TRIM(B{idx}))&"\',\'"&C{idx}&"\',COUNT(1) ,\'{query_date}\',\'"&D{idx}&"\' FROM "&C{idx}&" WHERE PT_DT = \'{query_date}\';"'
        #print(file_name)
        #print(formulaF)
        sheet.cell(row=idx, column=5,value=formulaE)
        sheet.cell(row=idx, column=6,value=formulaF)


    sheet.column_dimensions['A'].width = 10 
    sheet.column_dimensions['B'].width = 30     
    sheet.column_dimensions['C'].width = 40 
    sheet.column_dimensions['D'].width = 20 
    sheet.column_dimensions['E'].width = 40
    sheet.column_dimensions['F'].width = 40    
    workbook.save(output_file)

def main(folder_path,output_file,query_date):
    data = process_folder(folder_path,belong_person)
    write_to_excel(data ,output_file ,query_date)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python get_rely_table.py <scrpits_folder_path> <belong_person> <query_date>")
        sys.exit(1)
    folder_path = sys.argv[1]
    belong_person = sys.argv[2]
    query_date = sys.argv[3]
    output_file = r"table_rely_output_%s.xlsx"%belong_person
    print (folder_path)
    print (output_file)
    main(folder_path,output_file,query_date)