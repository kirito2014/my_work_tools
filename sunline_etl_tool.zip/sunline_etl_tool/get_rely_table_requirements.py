# -*- coding:utf-8 -*-
#脚本文件位置


#DROP TABLE IF EXISTS hive.agl_comm.agl_get_tabel_info;
# CREATE TABLE hive.agl_comm.agl_get_tabel_info (
#   query_type varchar COMMENT '查询类型',
#   target_table varchar COMMENT '聚合表名',
#   source_table varchar COMMENT '来源表',
#   data_count decimal(20, 0) COMMENT '数据量',
#   data_dt varchar COMMENT '数据日期',
#   belong_person varchar COMMENT '归属人'
#)
#COMMENT '代销信托交易明细表'
#STORE AS ORC;



import os
import sys
import re,sys
import openpyxl
import pandas as pd

ETL_HOME = os.path.dirname(os.path.abspath(__file__))

def get_belong_theme(file_name):
    file_name_upper = file_name.upper()
    #print(file_name_upper[4:7])
    if file_name_upper[0:7] == "AGL_S01":
        return "AGL_S01"
    elif file_name_upper[0:7] == "AGL_S02":
        return "AGL_S02"
    elif file_name_upper[0:7] == "AGL_S03":
        return "AGL_S03"
    elif file_name_upper[0:7] == "AGL_S04":
        return "AGL_S04"
    elif file_name_upper[0:7] == "AGL_S05":
        return "AGL_S05"
    elif file_name_upper[0:7] in ["AGL_S06","AGL_S07","AGL_S08","AGL_S09","AGL_S10","AGL_S11","AGL_S12"]:
        return "AGL_COMM"
    else:
        return "Unknown"
#函数用于提取SQL文件中的文件名
def extract_table_name(sql_content):
    pattern = r'(?:FROM|JOIN)\s+(\w+\.\w+)\s+'
    matches = re.findall(pattern, sql_content.upper())
    return matches

def filter_table_names(file_name, table_names):
    filterd_table_names = []
    for table_name in table_names:
        if file_name.upper().replace('_PC.HQL','').replace('ETL_PROC_','') not in table_name.upper() and not table_name.upper().startswith("AGL_"):
            filterd_table_names.append(table_name.upper().replace(' ',''))
    filterd_table_names = list(set(filterd_table_names))
    return filterd_table_names

def process_folder(folder_path):
    data = []
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".hql"):
            file_path = os.path.join(folder_path,file_name)
            with open(file_path, 'r',encoding='utf-8') as file:
                sql_content = file.read()
                table_names = extract_table_name(sql_content)
                filterd_table_names = filter_table_names(file_name,table_names)
                belong_theme = get_belong_theme(file_name)
                #belong_person = belong_person
                # data[file_name] = [(belong_theme,file_name)] * len(filterd_table_names)
                for table_name in filterd_table_names:
                    source_schema, source_table = table_name.split('.')
                    source_table += '_PC'
                    data.append((file_name,belong_theme,table_name,source_schema,source_table))
    return data

def write_to_excel(data ,output_file ):
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet['A1'] = 'belong_theme'
    sheet['B1'] = 'file_name'
    sheet['C1'] = 'table_name'
    sheet['D1'] = 'source_schema'
    sheet['E1'] = 'source_table'
    sheet['F1'] = 'etl_job_no'
    sheet['G1'] = 'etl_job_name'


    
    for idx,(file_name,belong_theme,table_name,source_schema,source_table) in enumerate(data, start=2):
        sheet.cell(row=idx, column=1, value=belong_theme)
        sheet.cell(row=idx, column=2, value=file_name.upper().replace('_PC.HQL','').replace('ETL_PROC_',''))
        sheet.cell(row=idx, column=3, value=table_name)
        sheet.cell(row=idx, column=4, value=source_schema)
        sheet.cell(row=idx, column=5, value=source_table)
        


    sheet.column_dimensions['A'].width = 10 
    sheet.column_dimensions['B'].width = 30     
    sheet.column_dimensions['C'].width = 40 
    sheet.column_dimensions['D'].width = 20 
    sheet.column_dimensions['E'].width = 40
 
    workbook.save(output_file)



def match_job_numbers1(target_file,output_file):
    df_target = pd.read_excel(target_file, sheet_name = None ,dtype={'etl_job': str,'etl_system': str})
    df_output = pd.read_excel(output_file)

    dev_sheet = df_target['dev']
    perf_sheet = df_target['pref']
    prod_sheet = df_target['prod']
    

    merged_df = pd.concat([dev_sheet,perf_sheet,prod_sheet], keys=['dev','pref','prod']).reset_index(level=0)
    merged_df.rename(columns={'level_0':'source_sheet'},inplace=True)

    merged_output = pd.merge(df_output, merged_df,how='left',left_on='source_table',right_on='etl_job')

    merged_output['etl_job_no'] = merged_output['etl_system']
    merged_output.loc[merged_output['etl_job_no'].isnull(),'etl_job_no'] = '没有对应的作业编号'
    merged_output['etl_job_name'] = 'IMP:' + merged_output['etl_system'] + '_' + merged_output['etl_job']
    merged_output.to_excel(output_file,index=False)

def main(folder_path,output_file,target_file):
    data = process_folder(folder_path)
    write_to_excel(data ,output_file )
    match_job_numbers1(target_file,output_file)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python get_rely_table.py <scrpits_folder_path> <target_file>")
        sys.exit(1)
    folder_path = sys.argv[1]
    output_file = r"table_rely_output.xlsx"
    target_file = sys.argv[2]
    print (folder_path)
    print (output_file)
    main(folder_path,output_file,target_file)