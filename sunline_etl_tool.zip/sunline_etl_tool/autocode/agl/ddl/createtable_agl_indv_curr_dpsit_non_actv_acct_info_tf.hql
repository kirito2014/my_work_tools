-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人活期存款不动户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF
--     表中文名：个人活期存款不动户信息聚合
--     创建日期：2024-07-24 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF (
     ACCT_NO STRING COMMENT '账户编号'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,CARD_NO STRING COMMENT '卡片编号'
    ,CUST_TYPE_CD STRING COMMENT '客户类型代码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,NON_ACTV_ACCT_STATUS_CD STRING COMMENT '不动户状态代码'
    ,ACCT_PROPTY_CD STRING COMMENT '账户性质代码'
    ,MED_TYPE_CD STRING COMMENT '介质类型代码'
    ,DPSTRCP_CONVT_NO STRING COMMENT '存单折号码'
    ,ACCT_TYPE_CD STRING COMMENT '账户类型代码'
    ,DPSIT_BIZ_CATEGORY_CD STRING COMMENT '存款业务类别代码'
    ,DPSIT_PROD_NO STRING COMMENT '存款产品编号'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,REDT_MODE_CD STRING COMMENT '转存方式代码'
    ,DPSIT_ACCTN_SUBJ_NO STRING COMMENT '存款会计科目编号'
    ,DPSIT_ACCTN_SUBJ_NAME STRING COMMENT '存款会计科目名称'
    ,NON_ACTV_ACCT_ACCTN_SUBJ_NO STRING COMMENT '不动户会计科目编号'
    ,NON_ACTV_ACCT_ACCTN_SUBJ_NAME STRING COMMENT '不动户会计科目名称'
    ,TURN_NON_BIZ_ACCTN_SUBJ_NO STRING COMMENT '转营业外会计科目编号'
    ,TURN_NON_BIZ_ACCTN_SUBJ_NAME STRING COMMENT '转营业外会计科目名称'
    ,CURR_BAL DECIMAL(28,2) COMMENT '当前余额'
    ,YESTD_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,OPEN_ACCT_AMT DECIMAL(28,2) COMMENT '开户金额'
    ,TURN_NON_BIZ_INCOME_DT STRING COMMENT '转营业外收入日期'
    ,STL_ACCT_FLAG STRING COMMENT '结算账户标志 '
    ,DPSIT_BIZ_MDL_CATOGR_CD STRING COMMENT '存款业务中类代码'
    ,OD_LIC_FLAG STRING COMMENT '透支许可标志'
    ,VAL_DT STRING COMMENT '起息日期'
    ,INTACR_FLAG STRING COMMENT '计息标志'
    ,TRNIN_BAL_ACCUM DECIMAL(28,2) COMMENT '转入余额积数'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,OPEN_ACCT_DOCTYP_CD STRING COMMENT '开户证件类型代码'
    ,OPEN_ACCT_DOC_NO STRING COMMENT '开户证件号码'
    ,OPEN_ACCT_ORG_NO STRING COMMENT '开户机构编号'
    ,DRAW_DOCTYP_CD STRING COMMENT '支取证件类型代码'
    ,DRAW_DOC_NO STRING COMMENT '支取证件号码'
    ,CANC_ACCT_DT STRING COMMENT '销户日期'
    ,FINAL_ACT_DT STRING COMMENT '最后活动日期'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,BELONG_LP_ORG_NO STRING COMMENT '归属法人机构编号'
    ,REC_STATUS_CD STRING COMMENT '记录状态代码'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '个人活期存款不动户信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




