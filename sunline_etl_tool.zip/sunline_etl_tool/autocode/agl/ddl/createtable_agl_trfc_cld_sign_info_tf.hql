-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云签约信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_SIGN_INFO_TF
--     表中文名：交通云签约信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：CONT_SIGN_AGT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_TRFC_CLD_SIGN_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_TRFC_CLD_SIGN_INFO_TF (
     CONT_SIGN_AGT_NO STRING COMMENT '合约签约协议编号'
    ,TRFC_CLD_SIGN_AGT_NO STRING COMMENT '交通云签约协议编号'
    ,SIGN_CONTR_DT STRING COMMENT '签约日期'
    ,SIGN_TM_STAMP STRING COMMENT '签约时间戳'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,SPC_ARGMT_MERCHT_ABB STRING COMMENT '特约商户简称'
    ,SIGN_CARD_NO STRING COMMENT '签约卡号'
    ,SIGN_ACCT_TYPE_CD STRING COMMENT '签约账户类型代码'
    ,SIGN_ACCT_TYPE_DESC STRING COMMENT '签约账户类型描述'
    ,CONT_STATUS_CD STRING COMMENT '合约状态代码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,DEL_FLAG STRING COMMENT '删除标志'
    ,ETC_SIGN_USER_FLAG STRING COMMENT 'ETC签约用户标志'
    ,ETC_USER_CERT_LVL_CD STRING COMMENT 'ETC用户认证等级代码'
    ,ETC_INTGRT_CERT_FLAG STRING COMMENT 'ETC一体化认证标志'
    ,NTSC_SIGN_CERT_FLAG STRING COMMENT '无感停车签约认证标志'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '交通云签约信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




