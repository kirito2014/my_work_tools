-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-生活缴费代理单位信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_AGEN_CORP_INFO_TF
--     表中文名：生活缴费代理单位信息聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：BIZ_UNIT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：包括中间业务平台（前置、mid73平台、ODS_MID70平台综合代收付单位信息）和外联支付平台中与生活缴费相关的代理单位数据



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF (
     BIZ_UNIT_NO STRING COMMENT '业务单元编号'
    ,BIZ_UNIT_NAME STRING COMMENT '业务单元名称'
    ,UNIT_NAME STRING COMMENT '单位名称'
    ,SPC_ARGMT_MERCHT_NO STRING COMMENT '特约商户编号'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,RGN_NO STRING COMMENT '地区编号'
    ,PAY_PROJ_NO STRING COMMENT '缴费项目编号'
    ,PAY_PROD_NO STRING COMMENT '缴费产品编号'
    ,BASIC_PROD_NO STRING COMMENT '基础产品编号'
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 STRING COMMENT '生活缴费业务类别代码1'
    ,PAY_BIZ_CATE_NO STRING COMMENT '缴费业务种类编号'
    ,PAY_BIZ_CATE_NAME STRING COMMENT '缴费业务种类名称'
    ,AGEN_LVL_CD STRING COMMENT '代理级别代码'
    ,STL_ACCT_NO STRING COMMENT '结算账户编号'
    ,LATE_FEE_STL_ACCT_NO STRING COMMENT '滞纳金结算账户编号'
    ,COMM_FEE_STL_ACCT_NO STRING COMMENT '手续费结算账户编号'
    ,PAYEE_ACCT_NO  STRING COMMENT '收款人账户编号'
    ,STL_PERIOD_CD STRING COMMENT '结算周期代码'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,BAT_SINGLE_IDNT_CD STRING COMMENT '批量单笔标识代码'
    ,CHENK_ACCT_CLS_NO STRING COMMENT '对账分类编号'
    ,EFFECT_STATUS_FLAG STRING COMMENT '有效状态标志'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,TXN_LMT DECIMAL(28,2) COMMENT '交易限额'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,BELONG_LP_ORG_NO STRING COMMENT '归属法人机构编号'
    ,MKTING_ORG_NO STRING COMMENT '营销机构编号'
    ,MKTING_TELR_NO STRING COMMENT '营销柜员编号'
    ,MKTING_TELR_NAME STRING COMMENT '营销柜员名称'
    ,INPUT_DT STRING COMMENT '录入日期'
    ,MODIF_DT STRING COMMENT '修改日期'
    ,B_SRC_SYS_CD STRING COMMENT '业务来源系统代码'
    ,B_SRC_TAB_EN_NAME STRING COMMENT '业务来源表英文名称'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '生活缴费代理单位信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




