-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-ETC充值明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_ETC_RCHG_DTL_TF
--     表中文名：ETC充值明细聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：ETC充值信息，特色代收付平台的交易流水表



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_ETC_RCHG_DTL_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_ETC_RCHG_DTL_TF (
     PLAT_DT STRING COMMENT '平台日期'
    ,PLAT_SER_NO STRING COMMENT '平台流水号'
    ,RCHG_SER_NO STRING COMMENT '充值流水号'
    ,RCHG_CARD_NO STRING COMMENT '充值ETC卡号'
    ,RCHG_CUST_NAME STRING COMMENT '充值客户名称'
    ,INIT_ORG_NO STRING COMMENT '发起机构编号'
    ,INIT_TELR_NO STRING COMMENT '发起柜员编号'
    ,RCHG_DT STRING COMMENT '充值日期'
    ,RCHG_AMT DECIMAL(28,2) COMMENT '充值金额'
    ,LIC_PLATE_NO STRING COMMENT '车牌号码'
    ,ETC_RCHG_TXN_MODE_CD STRING COMMENT 'ETC充值交易方式代码'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_STATUS_CD STRING COMMENT '交易状态代码'
    ,LIC_PLATE_COLOR_CD STRING COMMENT '车牌颜色代码'
    ,DEDUCT_ACCT_NO STRING COMMENT '扣款账户编号'
    ,DEDUCT_ACCT_NAME STRING COMMENT '扣款账户名称'
    ,FORE_END_SER_NO STRING COMMENT '前端流水号'
    ,BELONG_RGN_NO STRING COMMENT '归属地区号'
    ,CHNL_NO STRING COMMENT '渠道编号'
    ,AGEN_CORP_NO STRING COMMENT '代理单位编号'
    ,AGEN_CORP_NAME STRING COMMENT '代理单位名称'
    ,ETC_BIZ_CATEGORY_CD STRING COMMENT 'ETC业务类别代码'
    ,CURR_CD STRING COMMENT '币种代码'
    ,STL_ACCT_NO STRING COMMENT '结算账户编号'
    ,STL_ACCT_NAME STRING COMMENT '结算账户名称'
    ,UNDO_SER_NO STRING COMMENT '撤销流水号'
    ,HOST_TXN_DT STRING COMMENT '主机交易日期'
    ,ACCTN_SEQ_CD STRING COMMENT '记帐顺序代码'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,ERR_INFO_DESC STRING COMMENT '错误信息描述'
    ,HOST_ACCTN_STATUS_CD STRING COMMENT '主机记帐结果代码'
    ,AGEN_CORP_RESLT_CD STRING COMMENT '代理单位记帐结果代码'
    ,HOST_CENT_STATUS_CD STRING COMMENT '主机对账状态代码'
    ,AGEN_CORP_CENT_STATUS_CD STRING COMMENT '代理单位对账状态代码'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT 'ETC充值明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




