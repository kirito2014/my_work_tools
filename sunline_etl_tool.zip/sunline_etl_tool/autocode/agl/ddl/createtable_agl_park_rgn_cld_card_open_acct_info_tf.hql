-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-园区云卡片开户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF
--     表中文名：园区云卡片开户信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：BAT_OPEN_ACCT_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF (
     BAT_OPEN_ACCT_SER_NO STRING COMMENT '批量开户序号'
    ,PARK_RGN_NO STRING COMMENT '园区编号'
    ,PARK_RGN_NAME STRING COMMENT '园区名称'
    ,PARK_RGN_TYPE_CD STRING COMMENT '园区类型代码'
    ,USER_NO STRING COMMENT '用户编号'
    ,PRC_DOCTYP_CD STRING COMMENT '园区云证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,USER_NAME STRING COMMENT '用户名称'
    ,BANK_CARD_NO STRING COMMENT '银行卡号'
    ,OPEN_ACCT_AMT DECIMAL(28,2) COMMENT '开户金额'
    ,PRC_CUST_CATEGORY_CD STRING COMMENT '园区云客户类别代码'
    ,CUST_GENDER_CD STRING COMMENT '客户性别代码'
    ,CUST_BIRTH_DT STRING COMMENT '客户出生日期'
    ,CUST_MOBILE_NO STRING COMMENT '客户手机号码'
    ,CUST_CONT_NO_NO STRING COMMENT '客户联系电话号码'
    ,FAMILY_ADDR STRING COMMENT '家庭地址'
    ,CUST_COMMUNIC_ADDR STRING COMMENT '客户通讯地址'
    ,POST_CD STRING COMMENT '邮政编码'
    ,EMAIL_ADDR STRING COMMENT '电子邮箱地址'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,SYS_DEAL_TM STRING COMMENT '系统处理时间'
    ,DEAL_STATUS_CD STRING COMMENT '处理状态代码'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '园区云卡片开户信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




