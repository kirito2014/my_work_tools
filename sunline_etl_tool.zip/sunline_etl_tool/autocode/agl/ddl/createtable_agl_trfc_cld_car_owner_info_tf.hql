-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云车主信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_CAR_OWNER_INFO_TF
--     表中文名：交通云车主信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：PLAN_CLS_AST_IVS_TXN_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF (
     TRFC_FIN_CLD_USER_ID STRING COMMENT '交通金融云用户id'
    ,GOOD_HVST_INTCNK_USER_ID STRING COMMENT '丰收互联用户id'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,ETC_USE_FLAG STRING COMMENT 'ETC使用标志'
    ,DEL_FLAG STRING COMMENT '删除标志'
    ,INPUT_TM_STAMP STRING COMMENT '录入时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,USER_LVL_CD STRING COMMENT '用户级别代码'
    ,WX_OPENID STRING COMMENT '微信openID'
    ,ETC_INTGRT_CERT_FLAG STRING COMMENT 'ETC一体化认证标志'
    ,CAR_OWNER_CERT_FLAG STRING COMMENT '车主认证标志'
    ,NO_TOUCH_STOP_CAR_SIGN_CERT_FLAG STRING COMMENT '无感停车签约认证标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '交通云车主信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




