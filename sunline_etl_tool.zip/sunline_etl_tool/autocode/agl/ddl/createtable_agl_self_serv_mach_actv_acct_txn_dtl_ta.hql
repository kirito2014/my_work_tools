-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-自助机具动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA
--     表中文名：自助机具动账交易明细聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：BIZ_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA (
     BIZ_SER_NO STRING COMMENT '业务流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TXN_INITR_TYPE_NO STRING COMMENT '交易发起方类型编号'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_COMM_FEE DECIMAL(28,2) COMMENT '交易手续费'
    ,FUNC_ID STRING COMMENT '功能ID'
    ,FUNC_DESC STRING COMMENT '功能描述'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,TXN_INITR_CARD_NO STRING COMMENT '交易发起方卡号'
    ,TXN_INITR_ACCT_NO STRING COMMENT '交易发起方账户编号'
    ,TXN_INITR_CUST_DOC_NO STRING COMMENT '交易发起方客户证件号码'
    ,TXN_INITR_CUST_NAME STRING COMMENT '交易发起方客户名称'
    ,TXN_RECVER_CARD_NO STRING COMMENT '交易接收方卡号'
    ,TXN_RECVER_ACCT_NO STRING COMMENT '交易接收方账户编号'
    ,TXN_RECVER_CUST_DOC_NO STRING COMMENT '交易接收方客户证件号码'
    ,TXN_RECVER_CUST_NAME STRING COMMENT '交易接收方客户名称'
    ,VOCH_NO STRING COMMENT '凭证号码'
    ,P_END_RSPS_CD STRING COMMENT 'P端响应码'
    ,HOST_TRAN_CD STRING COMMENT '主机交易码'
    ,HOST_TRAN_CD_DESC STRING COMMENT '主机交易码描述'
    ,ACTL_RECV_AMT DECIMAL(28,2) COMMENT '实收金额'
    ,UNPY_TRAN_CD STRING COMMENT '银联交易码'
    ,OPBANK_NO STRING COMMENT '开户行行号'
    ,HOST_SER_NO STRING COMMENT '主机流水号'
    ,UNIONPAY_SER_NO STRING COMMENT '银联流水号'
    ,RV_SER_NO STRING COMMENT '冲正流水号'
    ,BIZ_TYPE_NO STRING COMMENT '业务类型编号'
    ,PAY_BIZ_CATE_NO STRING COMMENT '缴费业务种类编号'
    ,SELF_SERV_TERMN_SER_NO STRING COMMENT '自助终端流水号'
    ,EQUIP_NO STRING COMMENT '设备编号'
    ,EQUIP_TYPE_CD STRING COMMENT '设备类型代码'
    ,AFLT_ORG_NO STRING COMMENT '所属机构编号'
    ,SYS_VIRTUAL_TELR_NO STRING COMMENT '系统虚拟柜员编号'
    ,SUCC_FLAG STRING COMMENT '成功标志'
    ,CASH_FLAG STRING COMMENT '现金标志'
    ,RV_FLAG STRING COMMENT '冲正标志'
    ,SERVER_IP STRING COMMENT '服务器IP'
    ,MACH_TXN_TYPE_CD STRING COMMENT '机具交易类型代码'
    ,TXN_ORG_NO STRING COMMENT '交易机构编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,AUDIT_TELR_NO STRING COMMENT '审核柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,DATA_EFFECT_FLAG STRING COMMENT '数据有效标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '自助机具动账交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




