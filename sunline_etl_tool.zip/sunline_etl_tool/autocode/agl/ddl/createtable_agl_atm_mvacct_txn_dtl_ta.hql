-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-ATM动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_ATM_MVACCT_TXN_DTL_TA
--     表中文名：ATM动账交易明细聚合
--     创建日期：2024-03-13 00:00:00
--     主键字段：TXN_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_ATM_MVACCT_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TXN_CARD_NO STRING COMMENT '交易卡片编号'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,ATM_TXN_TYPE_CD STRING COMMENT 'ATM交易类型代码'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TRNOUT_ACCT_NO STRING COMMENT '转出账户编号'
    ,TRNIN_ACCT_NO STRING COMMENT '转入账户编号'
    ,TXN_CARD_TYPE_CD STRING COMMENT '交易卡片类型代码'
    ,TXN_CARD_SEQ_NO STRING COMMENT '交易卡片序列编号'
    ,CARD_HOLDER_NAME STRING COMMENT '持卡人名称'
    ,CARD_HOLDER_CUST_IN_CD STRING COMMENT '持卡人客户内码'
    ,CORE_SER_NO STRING COMMENT '核心流水号'
    ,ORIG_SER_NO STRING COMMENT '原始流水号'
    ,RV_DEAL_STATUS_CD STRING COMMENT '冲正处理状态代码'
    ,RV_SUCC_FLAG STRING COMMENT '冲正成功标志'
    ,RV_DEAL_DESC STRING COMMENT '冲正处理描述'
    ,FRONT_HOUR STRING COMMENT '前置小时'
    ,EQUIP_TXN_TM_STAMP STRING COMMENT '设备交易时间戳'
    ,EQUIP_NO STRING COMMENT '设备编号'
    ,EQUIP_SYS_TRACK_NO STRING COMMENT '设备系统跟踪号'
    ,EQUIP_RGN_CD STRING COMMENT '设备地区代码'
    ,EQUIP_BELONG_BNKOUTLS_NO STRING COMMENT '设备归属网点编号'
    ,EQUIP_BELONG_ORG_NO STRING COMMENT '设备归属机构编号'
    ,EQUIP_VIRTUAL_TELR_NO STRING COMMENT '设备虚拟柜员编号'
    ,ACPTD_TXN_UNPY_ORG_NO STRING COMMENT '受理交易银联机构编号'
    ,RECV_CARD_PTY_BANK_NAME STRING COMMENT '受卡方银行名称'
    ,RETRIV_REF_NO STRING COMMENT '检索参考号'
    ,MERCHT_MCC_CD STRING COMMENT '商户MCC代码'
    ,SERV_POINT_INPUT_MODE_CD STRING COMMENT '服务点输入方式代码'
    ,SERV_POINT_COND_CD STRING COMMENT '服务点条件代码'
    ,ERR_DESC STRING COMMENT '错误描述'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT 'ATM动账交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




