-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人账户非柜面交易控制信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF
--     表中文名：个人账户非柜面交易控制信息聚合
--     创建日期：2024-08-01 00:00:00
--     主键字段：无主键
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF (
     MAIN_ACCT_NO STRING COMMENT '主账户编号'
    ,SUB_ACCT_NO STRING COMMENT '子账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,EACCT_CLS_CD STRING COMMENT '电子账户分类代码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,CTRL_STATUS_CD STRING COMMENT '控制状态代码'
    ,EACCT_TXN_SER_NO STRING COMMENT '电子账户交易流水号'
    ,CTRL_RSN_DESC STRING COMMENT '控制原因描述'
    ,CTRL_TELR_NO STRING COMMENT '控制柜员编号'
    ,CTRL_AUTH_TELR_NO STRING COMMENT '控制授权柜员编号'
    ,CTRL_DT STRING COMMENT '控制日期'
    ,CTRL_TM_STAMP STRING COMMENT '控制时间戳'
    ,CTRL_LIFTED_RSN_DESC STRING COMMENT '控制解除原因描述'
    ,LIFTED_TELR_NO STRING COMMENT '解除柜员编号'
    ,LIFTED_AUTH_TELR_NO STRING COMMENT '解除授权柜员编号'
    ,LIFTED_DT STRING COMMENT '解除日期'
    ,LIFTED_TM_STAMP STRING COMMENT '解除时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '个人账户非柜面交易控制信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




