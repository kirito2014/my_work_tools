-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人数字货币钱包非动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA
--     表中文名：个人数字货币钱包非动账交易明细聚合
--     创建日期：2024-06-11 00:00:00
--     主键字段：CORE_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：个人数字货币钱包非动账交易明细信息



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA (
     CORE_SER_NO STRING COMMENT '核心流水号'
    ,CHNL_SER_NO STRING COMMENT '渠道流水号'
    ,CORE_ORIG_TXN_SER_NO STRING COMMENT '核心原交易流水号'
    ,ORIG_CHNL_SER_NO STRING COMMENT '原渠道流水号'
    ,TXN_TRACK_SER_NO STRING COMMENT '交易跟踪流水号'
    ,PLAT_BATCH_NO STRING COMMENT '平台批次编号'
    ,CORE_FLOW_TM_STAMP STRING COMMENT '核心流水时间戳'
    ,CHNL_REQE_FLOW_TM_STAMP STRING COMMENT '渠道请求流水时间戳'
    ,ORIG_TXN_CORE_FLOW_TM_STAMP STRING COMMENT '原交易核心流水时间戳'
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP STRING COMMENT '原交易渠道请求流水时间戳'
    ,TXN_OVERTM_TM_STAMP STRING COMMENT '交易超时时间戳'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,DIGIT_MNTYTIE_TXN_TYPE_CD STRING COMMENT '数币交易类型代码'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD STRING COMMENT '数币子交易类型代码'
    ,TXN_STATUS_CD STRING COMMENT '交易状态代码'
    ,ERR_CD STRING COMMENT '错误编码'
    ,ERR_DESC STRING COMMENT '错误描述'
    ,DIGIT_MNTY_BIZ_TYPE_CD STRING COMMENT '数字货币业务类型代码'
    ,DIGIT_MNTY_APP_BIZ_CATE_CD STRING COMMENT '数字货币应用业务种类代码'
    ,WALLET_ESTB_AFLT_FIN_ORG_CD STRING COMMENT '钱包开立所属金融机构编码'
    ,WALLET_NO STRING COMMENT '钱包编号'
    ,WALLET_NAME STRING COMMENT '钱包名称'
    ,WALLET_TYPE_CD STRING COMMENT '钱包类型代码'
    ,WALLET_LVL_CD STRING COMMENT '钱包等级代码'
    ,WALLET_ACCT_STATUS_CD STRING COMMENT '钱包账户状态代码'
    ,BANK_CARD_NO STRING COMMENT '银行卡号'
    ,USER_ID STRING COMMENT '用户id'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,OPEN_CARD_ORG_NO STRING COMMENT '开卡机构编号'
    ,TXN_HAPP_ORG_NO STRING COMMENT '交易发生机构编号'
    ,CREATE_TM_STAMP STRING COMMENT '创建时间戳'
    ,MODIF_TM_STAMP STRING COMMENT '修改时间戳'
    ,DIGIT_MNTYTIE_TXN_CHNL_CD STRING COMMENT '数币交易渠道代码'
    ,SYS_CD STRING COMMENT '系统代码'
    ,ANALY_CHNL_CD STRING COMMENT '分析渠道代码'
    ,OPERR_NAME STRING COMMENT '经办人名称'
    ,OPERR_DOCTYP_CD STRING COMMENT '经办人证件类型代码'
    ,OPERR_DOC_NO STRING COMMENT '经办人证件号码'
    ,OPERR_MOBILE_NO STRING COMMENT '经办人手机号码'
    ,VIRTUAL_TELR_NO STRING COMMENT '虚拟柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '个人数字货币钱包非动账交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




