-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-校园云用户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_CAMPUS_CLD_USER_INFO_TF
--     表中文名：校园云用户信息聚合
--     创建日期：None
--     主键字段：CUST_NO, USER_ID
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：None
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF (
     CUST_NO STRING COMMENT '客户号'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,CUST_TYPE_CD STRING COMMENT '客户类型代码'
    ,CUST_LVL_CD STRING COMMENT '客户级别代码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,SCH_NO STRING COMMENT '学校编号'
    ,SCH_NAME STRING COMMENT '学校名称'
    ,CAMPUS_TYPE_CD STRING COMMENT '校园类型代码'
    ,CAMPUS_BELONG_ORG_NO STRING COMMENT '校园归属机构编号'
    ,ORG_BELONG_RGN_CD STRING COMMENT '机构归属地区代码'
    ,GENDER_CD STRING COMMENT '性别代码'
    ,BIRTH_DT STRING COMMENT '出生日期'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,LANDLINE_NO STRING COMMENT '座机号码'
    ,RESIDENTIAL_ADDR STRING COMMENT '住宅地址'
    ,COMMUNIC_ADDR STRING COMMENT '通讯地址'
    ,POST_CD STRING COMMENT '邮政编码'
    ,EMAIL_ADDR STRING COMMENT '电子邮箱地址'
    ,CUST_INFO_CREATE_TM_STAMP STRING COMMENT '客户信息创建时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '校园云用户信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




