-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-ETC签约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_ETC_SIGN_AGT_INFO_TF
--     表中文名：ETC签约协议信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：AGT_NO, SIGN_ACCT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_ETC_SIGN_AGT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_ETC_SIGN_AGT_INFO_TF (
     AGT_NO STRING COMMENT '协议编号'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,CONT_NO_NO STRING COMMENT '联系电话号码'
    ,CARD_HOLDER_DOCTYP_CD STRING COMMENT '持卡人证件类型代码'
    ,CARD_HOLDER_DOC_NO STRING COMMENT '持卡人证件号码'
    ,SIGN_ACCT_TYPE_CD STRING COMMENT 'ETC签约介质类型代码'
    ,SIGN_ACCT_NO STRING COMMENT '签约账户编号'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,CARD_DISCNT_IDNT_CD STRING COMMENT '卡折标识代码'
    ,SIGN_ACCT_NAME STRING COMMENT '签约账户名称'
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO STRING COMMENT '签约账户开户机构编号'
    ,SIGN_CARD_NO STRING COMMENT '签约卡号'
    ,SIGN_CHNL_CD STRING COMMENT '签约渠道代码'
    ,SIGN_VEHIC_COLOR_CD STRING COMMENT '签约车辆颜色代码'
    ,SIGN_VEHIC_LIC_PLATE_NO STRING COMMENT '签约车辆车牌号码'
    ,SIGN_VEHIC_BRAND_NAME STRING COMMENT '签约车辆品牌名称'
    ,SIGN_VEHIC_REG_DT STRING COMMENT '签约车辆注册日期'
    ,SIGN_VEHIC_TEST_MATU_DT STRING COMMENT '签约车辆检验到期日期'
    ,BLKLIST_REC_FLAG STRING COMMENT '黑名单记录标志'
    ,ENTER_BLKLIST_RSN_ILUS STRING COMMENT '进入黑名单原因说明'
    ,ENTER_BLKLIST_DT STRING COMMENT '进入黑名单日期'
    ,UNDO_BLKLIST_DT STRING COMMENT '撤销黑名单日期'
    ,ETC_SIGN_STATUS_CD STRING COMMENT 'ETC签约状态代码'
    ,SIGN_SEQ_CD STRING COMMENT 'ETC签约顺序代码'
    ,SIGN_CONTR_DT STRING COMMENT '签约日期'
    ,SIGN_TM_STAMP STRING COMMENT '签约时间戳'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,SIGN_TELR_NO STRING COMMENT '签约柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_UPDATE_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,PLAT_DT STRING COMMENT '平台日期'
    ,RECNT_MODIF_ORG_NO STRING COMMENT '最后修改机构编号'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,SPREAD_TELR_NO STRING COMMENT '推广柜员编号'
    ,SPREAD_ORG_NO STRING COMMENT '推广机构编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT 'ETC签约协议信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




