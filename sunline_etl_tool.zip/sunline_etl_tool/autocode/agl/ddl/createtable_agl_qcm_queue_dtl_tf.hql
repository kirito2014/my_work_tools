-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-排队叫号机排队明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_QCM_QUEUE_DTL_TF
--     表中文名：排队叫号机排队明细聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：QUEUE_DT, PROC_ORG_NO, QUEUE_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_QCM_QUEUE_DTL_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_QCM_QUEUE_DTL_TF (
     QUEUE_DT STRING COMMENT '排队日期'
    ,PROC_ORG_NO STRING COMMENT '办理机构编号'
    ,QUEUE_SER_NO STRING COMMENT '排队序号'
    ,RANK_NO STRING COMMENT '队列编号'
    ,CALLNO_STATUS_CD STRING COMMENT '叫号状态代码'
    ,IN_QUEUE_TM_STAMP STRING COMMENT '入队时间戳'
    ,OUT_QUEUE_TM_STAMP STRING COMMENT '出队时间戳'
    ,WAIT_TM_STAMP STRING COMMENT '等待时间戳'
    ,START_PROC_BIZ_TM_STAMP STRING COMMENT '开始办理业务时间戳'
    ,END_PROC_BIZ_TM_STAMP STRING COMMENT '业务办理结束时间戳'
    ,BIZ_PROC_TM_STAMP STRING COMMENT '业务办理时间戳'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,CUST_STCT_DEG_ESTIM_CD STRING COMMENT '客户满意度评价代码'
    ,CNTER_NO STRING COMMENT '柜台编号'
    ,CNTER_NAME STRING COMMENT '柜台名称'
    ,TELR_NO STRING COMMENT '柜员编号'
    ,GET_NO_MODE_CD STRING COMMENT '取号模式代码'
    ,GET_NO_CHNL_CD STRING COMMENT '取号渠道代码'
    ,REMOTE_GET_NO_RESV_CD STRING COMMENT '远程取号预约码'
    ,QUEUE_CALLNO_MACH_NO STRING COMMENT '排队叫号机编号'
    ,QUEUE_CALLNO_MAC_ADDR STRING COMMENT '排队机MAC地址'
    ,QUEUE_CALLNO_ENABLED_FLAG STRING COMMENT '排队机启用标志'
    ,QUEUE_CALLNO_ONLINE_TM_STAMP STRING COMMENT '排队机在线时间戳'
    ,QUEUE_CALLNO_ONLINE_FLAG STRING COMMENT '排队机在线标志'
    ,QUEUE_CALLNO_NAME STRING COMMENT '排队机名称'
    ,QUEUE_CALLNO_TYPE_CD STRING COMMENT '排队机类型代码'
    ,BIZ_NO STRING COMMENT '业务编号'
    ,BIZ_NAME STRING COMMENT '业务名称'
    ,BIZ_NAME_ABB STRING COMMENT '业务名称简称'
    ,BIZ_CNTER_TYPE_CD STRING COMMENT '业务柜台类型代码'
    ,CNTER_BIZ_TYPE_CD STRING COMMENT '柜台业务类型代码'
    ,LVL_TWO_BUNDRY_EN_NAME STRING COMMENT '二级界面英文名称'
    ,CNTER_WIN_TYPE_CD STRING COMMENT '柜台窗口类型代码'
    ,CNTER_WIN_NAME STRING COMMENT '柜台窗口名称'
    ,CNTER_WIN_EN_NAME STRING COMMENT '柜台窗口英文名称'
    ,DSPLY_WIN_NO STRING COMMENT '显示窗口号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '排队叫号机排队明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




