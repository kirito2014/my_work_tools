-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-综合代发协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_SYN_PAYOFF_AGT_INFO_TF
--     表中文名：综合代发协议信息聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：SYN_PAYOFF_AGT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF (
     SYN_PAYOFF_AGT_NO STRING COMMENT '综合代发协议编号'
    ,CONT_NO STRING COMMENT '合约编号'
    ,BIZ_UNIT_NO STRING COMMENT '业务单元编号'
    ,SYN_PAYOFF_SIGN_PROD_CD STRING COMMENT '综合代发签约产品代码'
    ,SIGN_PROD_NAME STRING COMMENT '签约产品名称'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,ACCT_NO STRING COMMENT '账户编号'
    ,CUST_BELONG_ORG_NO STRING COMMENT '客户归属机构编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,OPEN_ACCT_ORG_NO STRING COMMENT '开户机构编号'
    ,OPEN_ACCT_TM STRING COMMENT '开户时间'
    ,THIRD_PTY_AGT_NO STRING COMMENT '第三方协议编号'
    ,SIGN_CONTR_DT STRING COMMENT '签约日期'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,OPER_TELR_NO STRING COMMENT '操作柜员编号'
    ,SYN_PAYOFF_SIGN_TYPE_CD STRING COMMENT '综合代发签约类型代码'
    ,IMAGE_PLAT_SER_NO STRING COMMENT '影像平台流水号'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,CONT_EFFECT_DT STRING COMMENT '合约生效日期'
    ,CONT_EXPIR_DT STRING COMMENT '合约失效日期'
    ,SYN_PAYOFF_SIGN_STATUS_CD STRING COMMENT '综合代发签约状态代码'
    ,DBO_ORG_NO STRING COMMENT '运营机构编号'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,CANCEL_CONT_ORG_NO STRING COMMENT '解约机构编号'
    ,CANCEL_CONT_TELR_NO STRING COMMENT '解约交易柜员'
    ,CANCEL_CONT_CHNL_CD STRING COMMENT '解约渠道代码'
    ,CANCEL_CONT_DT STRING COMMENT '解约日期'
    ,CANCEL_CONT_RSN_ILUS STRING COMMENT '解约原因'
    ,CREATE_TM STRING COMMENT '创建时间'
    ,FINAL_UPDATE_TM STRING COMMENT '最后修改时间'
    ,CREATOR_NO STRING COMMENT '创建人编号'
    ,MODIFIER_NO STRING COMMENT '修改人编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,LP_NAME STRING COMMENT '法人名称'
    ,CORP_DOCTYP_CD STRING COMMENT '企业证件类型代码'
    ,CORP_DOC_NO STRING COMMENT '企业证件号码'
    ,CORP_USER_ID STRING COMMENT '企业用户ID'
    ,LP_CONT_NO_NO STRING COMMENT '法人联系电话号码'
    ,LP_DOCTYP_CD STRING COMMENT '法人证件类型代码'
    ,LP_DOC_NO STRING COMMENT '法人证件号码'
    ,AUTON_CNTER_REG_IDNT_CD STRING COMMENT '自主柜面注册标识代码'
    ,CORP_BANK_MGMT_IDNT_CD STRING COMMENT '企业银行管理标识代码'
    ,CORP_CUST_STATUS STRING COMMENT '企业客户状态'
    ,SYN_CD_CUST_TYPE_CD STRING COMMENT '客户等级代码'
    ,GRP_CUST_FLAG STRING COMMENT '集团客户标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '综合代发协议信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




