-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-IC借记卡电子现金交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA
--     表中文名：IC借记卡电子现金交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：TXN_ACCTN_DT, CORE_ORIG_TXN_SER_NO, CORE_SUB_TXN_SER_NO, DEBIT_CARD_NO, ELEC_CASH_ACCT_TYPE_CD
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA (
     TXN_ACCTN_DT STRING COMMENT '交易记账日期'
    ,CORE_ORIG_TXN_SER_NO STRING COMMENT '核心原交易流水号'
    ,CORE_SUB_TXN_SER_NO STRING COMMENT '核心子交易流水号'
    ,DEBIT_CARD_NO STRING COMMENT '借记卡编号'
    ,ELEC_CASH_ACCT_TYPE_CD STRING COMMENT '电子现金账户类型代码'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,CARD_PROD_CD STRING COMMENT '卡产品代码'
    ,ELEC_CASH_ACCT_OPER_TYPE_CD STRING COMMENT '电子现金账户操作类型代码'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,TRNOUT_CARD_CARD_NO STRING COMMENT '转出卡卡号'
    ,CURR_CD STRING COMMENT '币种代码'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,ACCT_BAL DECIMAL(28,2) COMMENT '账户余额'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,POSITIVE_REV_TRAN_CATE_CD STRING COMMENT '正反交易种类代码'
    ,ORIG_TRAN_CD STRING COMMENT '原交易码'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,TXN_ORG_NO STRING COMMENT '交易机构编号'
    ,OPEN_ACCT_ORG_NO STRING COMMENT '开户机构编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,REM STRING COMMENT '备注'
    ,REC_STATUS_CD STRING COMMENT '记录状态代码'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT 'IC借记卡电子现金交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




