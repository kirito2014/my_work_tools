-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-联社公共签约表03
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_T_SIGN_XXX_03_TF
--     表中文名：联社公共签约表03
--     创建日期：2024-04-15 00:00:00
--     主键字段：
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_T_SIGN_XXX_03_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_T_SIGN_XXX_03_TF (
     CUST_NO STRING COMMENT '客户编号'
    ,CONTRACT STRING COMMENT '合同编号'
    ,ENTR_NO STRING COMMENT '单位编号'
    ,USER_ID STRING COMMENT '用户编号'
    ,USER_NAME STRING COMMENT '用户姓名'
    ,CERT_TYPE STRING COMMENT '证件种类'
    ,CERT_ID STRING COMMENT '证件号码'
    ,TELEPHONE STRING COMMENT '电话号码'
    ,ADDRESS STRING COMMENT '地址'
    ,ACCT_TYPE STRING COMMENT '账户性质'
    ,CARD_TYPE STRING COMMENT '卡折标志'
    ,ACCT_NO STRING COMMENT '账号'
    ,STAT STRING COMMENT '状态'
    ,CURR_NO STRING COMMENT '币种'
    ,CURR_IDEN STRING COMMENT '钞汇鉴别'
    ,ACT_NAME STRING COMMENT '账户户名'
    ,CARD_NO STRING COMMENT '卡号'
    ,OPEN_BRCH STRING COMMENT '开户机构'
    ,SIGN_DATE STRING COMMENT '签约日期'
    ,SIGN_TIME STRING COMMENT '签约时间'
    ,SIGN_BRCH_NO STRING COMMENT '签约机构'
    ,SIGN_TELLER_NO STRING COMMENT '签约柜员'
    ,UPT_DATE STRING COMMENT '最后修改日期'
    ,UPT_TIME STRING COMMENT '最后修改时间'
    ,UPT_BRCH_NO STRING COMMENT '最后修改机构'
    ,UPT_TELLER_NO STRING COMMENT '最后修改柜员'
    ,TALLY_ORDER STRING COMMENT '顺序'
    ,RMRK STRING COMMENT '备注'
    ,OLD_ACCT_NO STRING COMMENT '旧帐号'
    ,PLAT_DATE STRING COMMENT '平台日期'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '联社公共签约表03'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




