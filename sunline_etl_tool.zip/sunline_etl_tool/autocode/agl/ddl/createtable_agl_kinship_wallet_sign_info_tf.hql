-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-亲情钱包签约信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_KINSHIP_WALLET_SIGN_INFO_TF
--     表中文名：亲情钱包签约信息聚合
--     创建日期：2024-08-20 00:00:00
--     主键字段：SIGN_NO, LP_ORG_NO, CONT_MODIF_DT
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_KINSHIP_WALLET_SIGN_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_KINSHIP_WALLET_SIGN_INFO_TF (
     SIGN_NO STRING COMMENT '签约编号'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,SIGN_ACCT_NO STRING COMMENT '签约账户编号'
    ,KINSHIP_WALLET_ACCT_NO STRING COMMENT '亲情钱包账户编号'
    ,RELAT_INDV_USER_NO STRING COMMENT '关联人用户编号'
    ,RELAT_INDV_CUST_IN_CD STRING COMMENT '关联人客户内码'
    ,RELAT_INDV_DOC_NO STRING COMMENT '关联人证件号码'
    ,RELAT_INDV_NAME STRING COMMENT '关联人名称'
    ,RELAT_INDV_ACCT_NO STRING COMMENT '关联人账户编号'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,CONT_STATUS_CD STRING COMMENT '合约状态代码'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,SIGN_TM_STAMP STRING COMMENT '签约时间戳'
    ,CANCEL_CONT_TM_STAMP STRING COMMENT '解约时间戳'
    ,CANCEL_CONT_USER_ID STRING COMMENT '解约用户ID'
    ,CANCEL_CONT_CUST_NAME STRING COMMENT '解约客户名称'
    ,SINGLE_LMT DECIMAL(28,2) COMMENT '单笔限额'
    ,DAILY_ACCUM_LMT DECIMAL(28,2) COMMENT '日累计限额'
    ,MONTHLY_ACCUM_LMT DECIMAL(28,2) COMMENT '月累计限额'
    ,SM_DAY_USED_LMT DECIMAL(28,2) COMMENT '当日已用额度'
    ,TH_MONTH_USED_LMT DECIMAL(28,2) COMMENT '当月已用额度'
    ,FINAL_PAY_DT STRING COMMENT '最后支付日期'
    ,KINSHIP_WALLET_STATUS_CD STRING COMMENT '亲情钱包状态代码'
    ,STATUS_VERI_RESLT_CD STRING COMMENT '身份检查结果代码'
    ,CLOSE_RSN_CD STRING COMMENT '关闭原因代码'
    ,CLOSE_PSN_TYPE_CD STRING COMMENT '关闭人类型代码'
    ,DEL_EMPLY_TYPE_CD STRING COMMENT '删除人类型代码'
    ,RELA_DESC STRING COMMENT '关系描述'
    ,CONT_MODIF_DT STRING COMMENT '合约修改日期'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '亲情钱包签约信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




