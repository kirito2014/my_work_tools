-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-城乡两费交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_URTF_TXN_DTL_TA
--     表中文名：城乡两费交易明细聚合
--     创建日期：2024-03-21 00:00:00
--     主键字段：TXN_DT, TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_URTF_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_URTF_TXN_DTL_TA (
     TXN_DT STRING COMMENT '交易日期'
    ,TXN_SER_NO STRING COMMENT '交易流水号'
    ,PAY_FEE_MODE_CD STRING COMMENT '缴费模式代码'
    ,DIROR_TAX_ORG_SRC_CD STRING COMMENT '主管税务机关来源代码'
    ,PLAT_CLEAR_DT STRING COMMENT '平台清算日期'
    ,TXN_ORG_NO STRING COMMENT '交易机构编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,URBA_RURAL_FEE_PAY_MODE_CD STRING COMMENT '城乡两费支付方式代码'
    ,ACCT_PUB_PRIV_TYPE_CD STRING COMMENT '账户公私类型代码'
    ,URBA_RURAL_FEE_ACCT_TYPE_CD STRING COMMENT '城乡两费账户类型代码'
    ,BANK_TXN_SER_NO STRING COMMENT '银行交易流水号'
    ,PAY_REFUND_IDNT_CD STRING COMMENT '缴费退费标识代码'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,BANK_STL_ACCT_NO STRING COMMENT '银行结算账户编号'
    ,TXN_ACCT_OPEN_ACCT_ORG_NO STRING COMMENT '交易账户开户机构编号'
    ,TAX_TXN_SER_NO STRING COMMENT '税务交易流水号'
    ,DIROR_TAX_ORG_CD STRING COMMENT '主管税务机关代码'
    ,DIROR_TAX_ORG_NAME STRING COMMENT '主管税务机关名称'
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO STRING COMMENT '主管税务机关虚拟户编号'
    ,TAX_PRTCPT_INSURE_PSN_NO STRING COMMENT '税务参保人员编号'
    ,TAX_PRTCPT_INSURE_PSN_NAME STRING COMMENT '税务参保人员名称'
    ,CUST_DOC_NO STRING COMMENT '客户证件号码'
    ,CUST_CONT_NO_NO STRING COMMENT '客户联系电话号码'
    ,PAY_PSN_TYPE_CD STRING COMMENT '缴费人员类型代码'
    ,COMMS_DT STRING COMMENT '委托日期'
    ,BANK_PAY_AGT_BOOK_NO STRING COMMENT '银行缴费协议书编号'
    ,URBA_RUBAL_FEE_PAY_STATUS_CD STRING COMMENT '城乡两费缴费状态代码'
    ,URBA_RURAL_FEE_TYPE_CD STRING COMMENT '城乡两费类型代码'
    ,AGEN_CORP_STL_ACCT_NO STRING COMMENT '代理单位结算账户编号'
    ,URFEE_TPTY_ACCTN_STAT_CD STRING COMMENT '城乡两费主机记账状态代码'
    ,URFEE_HOST_ACCTN_STAT_CD STRING COMMENT '城乡两费第三方记账状态代码'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,URBA_RURAL_FEE_SIGN_STATUS_CD STRING COMMENT '城乡两费签约状态代码'
    ,URBA_RURAL_FEE_TXN_STATUS_CD STRING COMMENT '城乡两费交易状态代码'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '城乡两费交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




