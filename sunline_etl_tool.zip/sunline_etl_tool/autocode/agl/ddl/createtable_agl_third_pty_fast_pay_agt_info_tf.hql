-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-第三方快捷支付协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_THIRD_PTY_FAST_PAY_AGT_INFO_TF
--     表中文名：第三方快捷支付协议信息聚合
--     创建日期：2024-01-03 00:00:00
--     主键字段：CONT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_THIRD_PTY_FAST_PAY_AGT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_THIRD_PTY_FAST_PAY_AGT_INFO_TF (
     CONT_NO STRING COMMENT '合约编号'
    ,CONT_STATUS_CD STRING COMMENT '合约状态代码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NAME STRING COMMENT '证件名称'
    ,DOC_NO STRING COMMENT '证件号码'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,BLKLIST_TYPE_CD STRING COMMENT '黑名单类型代码'
    ,SIGN_CARD_NO STRING COMMENT '签约卡号'
    ,SIGN_ACCT_NO STRING COMMENT '签约账户编号'
    ,SIGN_ACCT_NAME STRING COMMENT '签约账户名称'
    ,SIGN_ACCT_TYPB_CD STRING COMMENT '签约账户类型代码'
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO STRING COMMENT '签约账户开户机构编号'
    ,SIGN_ACCT_OPEN_ACCT_ORG_NAME STRING COMMENT '签约账户开户机构名称'
    ,ACCT_BELONG_TYPE_CD STRING COMMENT '账户归属类型代码'
    ,ACCT_CANC_ACCT_XAM_CD STRING COMMENT '账户销户检查代码'
    ,SIEX_CHNL_CD STRING COMMENT '签约渠道代码'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,SIGN_TM_STAMP STRING COMMENT '签约时间戳'
    ,CANCEL_CONT_TM_STAMP STRING COMMENT '解约时间戳'
    ,CUST_CONT_CANCEL_CONT_TYPE_CD STRING COMMENT '客户合约解约类型代码'
    ,CANCEL_CONT_USER_ID STRING COMMENT '解约用户ID'
    ,CANCEL_CONT_CUST_NAME STRING COMMENT '解约客户名称'
    ,ACPTD_BNKOUTLS_ORG_NO STRING COMMENT '受理网点机构编号'
    ,TELR_NO STRING COMMENT '柜员编号'
    ,TXN_CARD_TYPE_CD STRING COMMENT '交易卡片类型代码'
    ,FAST_PAY_SIGN_ADDIT_FLAG STRING COMMENT '快捷支付签约附加标志'
    ,CARD_EXPIR_DT STRING COMMENT '卡片失效日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '第三方快捷支付协议信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




