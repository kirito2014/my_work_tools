-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-网联来账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA
--     表中文名：网联来账交易明细聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：MSG_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：包含第三方发起的支付、退货退款、第三方机构提现、签约解约等来账交易相关信息



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA (
     NUCC_VOSTRO_ACCT_SER_NO STRING COMMENT '网联来账流水号'
    ,NUCC_BIZ_CHNL_DESC STRING COMMENT '网联业务渠道描述'
    ,BIZ_SINGLE_NO STRING COMMENT '业务单编号'
    ,NUCC_MSG_MAP_TYPE_CD STRING COMMENT '网联报文映射类型代码'
    ,NUCC_BIZ_MCLS_CD STRING COMMENT '网联业务大类代码'
    ,NUCC_BIZ_MCLS_DESC STRING COMMENT '网联业务大类描述'
    ,NUCC_BIZ_SCLS_CD STRING COMMENT '网联业务小类代码'
    ,NUCC_BIZ_SCLS_DESC STRING COMMENT '网联业务小类描述'
    ,MSG_NO STRING COMMENT '报文编号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_SUCC_AMT DECIMAL(28,2) COMMENT '交易成功金额'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,ORIG_MSG_TXN_NO STRING COMMENT '原报文交易编号'
    ,CONT_SIGN_AGT_NO STRING COMMENT '合约签约协议编号'
    ,CHECK_ENTRY_STATUS_CD STRING COMMENT '对账状态代码'
    ,END_TO_END_IDE_NO STRING COMMENT '端到端标识号'
    ,RESP_CODE STRING COMMENT '响应码'
    ,RESP_INFO_DESC STRING COMMENT '响应信息描述'
    ,TELEG_BANK_UPP_BANK_NO STRING COMMENT '发报行统一支付平台行号'
    ,RECV_MSG_BANK_UPP_BANK_NO STRING COMMENT '收报行统一支付平台行号'
    ,MSG_SEND_TM_STAMP STRING COMMENT '报文发送时间戳'
    ,MSG_STATUS_CD STRING COMMENT '报文状态代码'
    ,RURAL_BANK_CRDT_MSG_TYPE_NO STRING COMMENT '农信银报文类型编号'
    ,RECV_TM_STAMP STRING COMMENT '报文接收时间戳'
    ,PLAT_CLEAR_TM_STAMP STRING COMMENT '平台清算时间戳'
    ,PAYEE_CN_NAME STRING COMMENT '收款人中文名称'
    ,PAYEE_USER_ID STRING COMMENT '收款人用户ID'
    ,PAYEE_CUST_IN_CD STRING COMMENT '收款人客户内码'
    ,PAYEE_CNAPS_CODE STRING COMMENT '收款方人行支付行号'
    ,PAYEE_ACCT_NO STRING COMMENT '收款方账户编号'
    ,PAYEE_CLEAR_ACCT_NO STRING COMMENT '收款方清算账户编号'
    ,PAYEE_MOBILE_NO STRING COMMENT '收款人手机号码'
    ,PAYER_NAME STRING COMMENT '付款人名称'
    ,PAYER_USER_ID STRING COMMENT '付款人用户ID'
    ,PAYER_CUST_IN_CD STRING COMMENT '付款人客户内码'
    ,PAY_BANK_BANK_NO STRING COMMENT '付款行行号'
    ,PAYER_ACCT_NO STRING COMMENT '付款方账户编号'
    ,PAYER_CLEAR_ACCT_NO STRING COMMENT '付款方清算账户编号'
    ,PAYER_CONT_NO_NO STRING COMMENT '付款人联系电话号码'
    ,CUST_RMT_INFO_DESC STRING COMMENT '客户汇款信息描述'
    ,ACCT_CONT_IDNT_CD STRING COMMENT '账务往来标识代码'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,CHENK_ACCT_CLS_NO STRING COMMENT '对账分类编号'
    ,ERR_CD STRING COMMENT '错误编码'
    ,ERR_DESC STRING COMMENT '错误描述'
    ,REM STRING COMMENT '备注'
    ,NUCC_CORE_TYPE_CD STRING COMMENT '网联核心类型代码'
    ,EXT_RESP_MSG_NO STRING COMMENT '外部响应报文编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '网联来账交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




