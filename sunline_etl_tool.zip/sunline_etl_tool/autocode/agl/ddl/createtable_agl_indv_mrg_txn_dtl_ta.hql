-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人保证金交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_MRG_TXN_DTL_TA
--     表中文名：个人保证金交易明细聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO.TXN_DT, TXN_ACCT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA (
     ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TXN_ACCT_NAME STRING COMMENT '交易账户名称'
    ,ACCT_TYPE_CD STRING COMMENT '账户类型代码'
    ,ACCT_PROPTY_CD STRING COMMENT '账户性质代码'
    ,MRG_REC_TYPE_CD STRING COMMENT '保证金记录类型代码'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,TXN_TYPE_CD STRING COMMENT '交易类型代码'
    ,CASH_TRAN_IDNT_CD STRING COMMENT '现转标识代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,ACCT_BAL DECIMAL(28,2) COMMENT '账户余额'
    ,VAL_DT STRING COMMENT '起息日期'
    ,INT_AMT DECIMAL(28,2) COMMENT '利息金额'
    ,TRAN_CD STRING COMMENT '交易码'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,CNTPTY_TXN_ACCT_NO STRING COMMENT '对方交易账户编号'
    ,CNTPTY_TXN_ACCT_NAME STRING COMMENT '对方交易账户名称'
    ,CNTPTY_BANK_NO STRING COMMENT '对方行号'
    ,CNTPTY_BANK_NAME STRING COMMENT '对方行名'
    ,TXN_HAPP_ORG_NO STRING COMMENT '交易发生机构编号'
    ,TXN_RGN_NO STRING COMMENT '交易地区编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,SUB_TRAN_CD STRING COMMENT '子交易码'
    ,TXN_EQUIP_IP STRING COMMENT '交易设备IP'
    ,TXN_EQUIP_MAC STRING COMMENT '交易设备MAC'
    ,TXN_VOCH_CATE_CD STRING COMMENT '交易凭证种类代码'
    ,TXN_VOCH_NO STRING COMMENT '交易凭证号码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,REM STRING COMMENT '备注'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '个人保证金交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




