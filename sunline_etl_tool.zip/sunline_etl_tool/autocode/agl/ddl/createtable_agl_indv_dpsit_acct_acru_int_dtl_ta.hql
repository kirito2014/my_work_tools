-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人存款账户计提利息明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA
--     表中文名：个人存款账户计提利息明细聚合
--     创建日期：2024-04-23 00:00:00
--     主键字段：ACCT_NO, EXCH_GATHER_ACCT_SER_NO, CURR_CD, ACRU_DT, CASH_RMT_CD
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA (
     ACCT_NO STRING COMMENT '账户编号'
    ,EXCH_GATHER_ACCT_SER_NO STRING COMMENT '汇集账户序号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,ACRU_DT STRING COMMENT '计提日期'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,TM_DEMAND_IDNT_CD STRING COMMENT '定活标识代码'
    ,CURR_DPSTRCP_FLAG STRING COMMENT '活期存单标志'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,DPSIT_PERIOD STRING COMMENT '存期'
    ,ACRU_INT DECIMAL(28,2) COMMENT '计提利息'
    ,RGL_INT DECIMAL(28,2) COMMENT '定期利息'
    ,RGL_INT_RATE DECIMAL(20,7) COMMENT '定期利率'
    ,CURR_INT DECIMAL(28,2) COMMENT '活期利息'
    ,CURR_INT_RATE DECIMAL(20,7) COMMENT '活期利率'
    ,ADJ_INT DECIMAL(28,2) COMMENT '调整利息'
    ,DPSIT_BAL DECIMAL(28,2) COMMENT '存款余额'
    ,DPSIT_BAL_ACCUM DECIMAL(28,2) COMMENT '存款余额积数'
    ,VAL_DT STRING COMMENT '起息日期'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,REC_STATUS_CD STRING COMMENT '记录状态代码'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '个人存款账户计提利息明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




