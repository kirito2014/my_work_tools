-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-移动展业交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_YDZY_TXN_DTL_TA
--     表中文名：移动展业交易明细聚合
--     创建日期：2024-06-11 00:00:00
--     主键字段：TXN_SER_NO, EVENT_ID
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：选取移动展业系统交易流水表的全部信息



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_YDZY_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_YDZY_TXN_DTL_TA (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,EVENT_ID STRING COMMENT '事件ID'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_TM STRING COMMENT '交易时间'
    ,PAD_EQUIP_NO STRING COMMENT 'PAD设备编号'
    ,PAD_EQUIP_MODEL STRING COMMENT 'PAD设备型号'
    ,MAC_ADDR STRING COMMENT 'MAC地址'
    ,BJ_NO STRING COMMENT '背夹编号'
    ,IP_ADDR STRING COMMENT 'IP地址'
    ,GEOG_PSTN_LGTD STRING COMMENT '地理位置经度'
    ,GEOG_PSTN_LATD STRING COMMENT '地理位置纬度'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,BANK_CARD_NO STRING COMMENT '银行卡号'
    ,CUST_DOCTYP_CD STRING COMMENT '客户证件类型代码'
    ,CUST_DOC_NO STRING COMMENT '客户证件号码'
    ,CUST_MOBILE_NO STRING COMMENT '客户手机号码'
    ,ELEC_VOCH_PERMNT_KEEP_FLAG STRING COMMENT '电子凭证永久保留标志'
    ,ORG_NO STRING COMMENT '机构编号'
    ,MENU_NO STRING COMMENT '菜单编号'
    ,MENU_MODULE_NAME STRING COMMENT '菜单模块名称'
    ,TXN_SERV_LINK_DESC STRING COMMENT '交易服务链接描述'
    ,TXN_NAME STRING COMMENT '交易名称'
    ,TXN_DESC_1 STRING COMMENT '交易描述1'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,TXN_TELR_NAME STRING COMMENT '交易柜员名称'
    ,HANDLE_TELR_POST_CD STRING COMMENT '经办柜员岗位代码'
    ,HANDLE_TELR_POST_NAME STRING COMMENT '经办柜员岗位名称'
    ,AUTH_TELR_NO STRING COMMENT '授权柜员编号'
    ,AUTH_FLAG STRING COMMENT '授权标志'
    ,VIRTUAL_TELR_NO STRING COMMENT '虚拟柜员编号'
    ,TXN_ACCT_CATEGORY_IDNT_CD STRING COMMENT '交易账务类别标识代码'
    ,TXN_RESLT_DESC_1 STRING COMMENT '交易结果描述'
    ,TXN_RESLT_DESC_2 STRING COMMENT '交易结果描述'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,IMAGE_PLAT_SER_NO STRING COMMENT '影像平台流水号'
    ,GLOB_SER_NO STRING COMMENT '全局流水号'
    ,CORE_SER_NO STRING COMMENT '核心流水号'
    ,CORE_SUB_TXN_SER_NO STRING COMMENT '核心子交易流水号'
    ,REM STRING COMMENT '备注'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '移动展业交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




