-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-超级网银对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：超级网银对账差错明细聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：SUPER_EBANK_CHECK_ENTRY_SYS_CD, TXN_BIZ_CATE_CD, PLAT_DT, PLAT_SER_NO, THIRD_PTY_CLEAR_DT
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA (
     SUPER_EBANK_CHECK_ENTRY_SYS_CD STRING COMMENT '超级网银对账系统代码'
    ,TXN_BIZ_CATE_CD STRING COMMENT '交易业务种类代码'
    ,PLAT_DT STRING COMMENT '平台日期'
    ,PLAT_SER_NO STRING COMMENT '平台流水号'
    ,HOST_SER_NO STRING COMMENT '主机流水号'
    ,THIRD_PTY_ACCT_DT STRING COMMENT '第三方账务日期'
    ,THIRD_PTY_CLEAR_DT STRING COMMENT '第三方清算日期'
    ,THIRD_PTY_SER_NO STRING COMMENT '第三方流水号'
    ,PBC_BIZ_SER_NO STRING COMMENT '人行业务流水号'
    ,DEBIT_ACCT_NO STRING COMMENT '借方账户编号'
    ,CRDT_ACCT_NO STRING COMMENT '贷方账户编号'
    ,MSG_CONT_DIR_CD STRING COMMENT '报文往来方向代码'
    ,DEBIT_CRDT_IDNT_CD STRING COMMENT '借贷标识代码'
    ,CURR_CD STRING COMMENT '币种代码'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,COMM_FEE_AMT DECIMAL(28,2) COMMENT '手续费金额'
    ,RGN_NO STRING COMMENT '地区编号'
    ,INIT_ORG_NO STRING COMMENT '发起机构编号'
    ,ACCTN_TELR_NO STRING COMMENT '记账柜员编号'
    ,SUPER_EBANK_HOST_LPAY_CD STRING COMMENT '超级网银主机对账结果代码'
    ,HOST_CHECK_ENTRY_ERR_INFO_DESC STRING COMMENT '主机对账差错信息描述'
    ,SUPER_EBANK_TRPRT_LPAY_CD STRING COMMENT '超级网银三方对账结果代码'
    ,TPTY_CENT_ERR_INFO_DESC STRING COMMENT '第三方对账差错信息描述'
    ,SUPER_EBANK_ERR_DEAL_TYPE_CD STRING COMMENT '超级网银差错处理类型代码'
    ,DONE_ERR_DEAL_FLAG STRING COMMENT '已做差错处理标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '超级网银对账差错明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




