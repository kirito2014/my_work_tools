-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云无感停车场信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_NO_TOUCH_STOP_CAR_PLC_INFO_TF
--     表中文名：交通云无感停车场信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：STOP_CAR_PLACE_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_TRFC_CLD_NO_TOUCH_STOP_CAR_PLC_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_TRFC_CLD_NO_TOUCH_STOP_CAR_PLC_INFO_TF (
     STOP_CAR_PLACE_NO STRING COMMENT '停车场编号'
    ,STOP_CAR_PLC_NAME STRING COMMENT '停车场名称'
    ,LOCAL_PROV_NAME STRING COMMENT '所在省份名称'
    ,CITY_NAME STRING COMMENT '所在城市名称'
    ,LOCAL_DIST_NAME STRING COMMENT '所在区县名称'
    ,TWNSHP_STREET_NAME STRING COMMENT '乡镇街道名称'
    ,DTL_ADDR STRING COMMENT '详细地址'
    ,STOP_CAR_PLC_COOR_LATD STRING COMMENT '停车场坐标纬度'
    ,STOP_CAR_PLC_COOR_LGTD STRING COMMENT '停车场坐标经度'
    ,INPUT_TM_STAMP STRING COMMENT '录入时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,MERCHT_IDTFY_NO STRING COMMENT '商户识别编号'
    ,SPC_ARGMT_MERCHT_NO STRING COMMENT '特约商户编号'
    ,TRFC_FIN_CLD_MERCHT_NO STRING COMMENT '交通金融云商户编号'
    ,MERCHT_CLD_MERCHT_NO STRING COMMENT '商户云商户编号'
    ,SPC_ARGMT_MERCHT_NAME STRING COMMENT '特约商户名称'
    ,SPC_ARGMT_MERCHT_TYPE_CD STRING COMMENT '特约商户类型代码'
    ,SPC_ARGMT_MERCHT_ATTR_CD STRING COMMENT '特约商户属性代码'
    ,SPC_ARGMT_MERCHT_STATUS_CD STRING COMMENT '特约商户状态代码'
    ,SPC_ARGMT_MERCHT_ABB STRING COMMENT '特约商户简称'
    ,SPC_ARGMT_MERCHT_STL_ACCT_NO STRING COMMENT '特约商户结算账户编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LOCAL_COMM_NAME STRING COMMENT '所在社区名称'
    ,DEL_FLAG STRING COMMENT '删除标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '交通云无感停车场信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




