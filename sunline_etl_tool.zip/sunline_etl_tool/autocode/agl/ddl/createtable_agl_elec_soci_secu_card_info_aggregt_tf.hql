-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-电子社保卡信息聚合表
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF
--     表中文名：电子社保卡信息聚合表
--     创建日期：2024-08-08 00:00:00
--     主键字段：TXN_SEQ_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF (
     TXN_SEQ_NO BIGINT COMMENT '序号'
    ,USER_NAME STRING COMMENT '姓名'
    ,IDENTITY_CARD_NO STRING COMMENT '身份证号码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,SOCI_SECU_CARD_CARD_NO STRING COMMENT '社保卡编号'
    ,BANK_CARD_NO STRING COMMENT '银行卡号'
    ,PRTCPT_INSURE_RGN_NAME STRING COMMENT '参保地区名称'
    ,ELEC_SOCI_SECU_CARD_OPEN_FLAG STRING COMMENT '电子社保卡开通标志'
    ,VIRTUAL_CARD_STATUS_CD STRING COMMENT '卡状态'
    ,CONT_SIGN_AGT_NO STRING COMMENT '合约中心签约号'
    ,EXC_CREATE_TM_STAMP STRING COMMENT '创建时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '更改时间戳'
    ,REG_LOCAL_ADDR STRING COMMENT '所在地（对应行社）'
    ,DRAW_CARD_BIZ_SER_NO STRING COMMENT '领卡业务流水号'
    ,ISSUE_LVL_CD STRING COMMENT '签发等级'
    ,ISSUE_NO STRING COMMENT '签发号'
    ,VALID_END_DT STRING COMMENT '有效期'
    ,DIST_CD STRING COMMENT '发卡地区行政区划代码'
    ,CARD_ISSUE_DT STRING COMMENT '发卡日期'
    ,ELEC_SOCI_SECU_CARD_TRIG_FUNC_STATUS_CD STRING COMMENT '电子社保卡触发功能状态代码'
    ,GOOD_HVST_INTCNK_USER_ID STRING COMMENT '丰收互联用户id'
    ,CHNL_CD STRING COMMENT '渠道编号'
    ,NOTICE_SOCI_SECU_STAUS_CD STRING COMMENT '通知社保状态'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '电子社保卡信息聚合表'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




