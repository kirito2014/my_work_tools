-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-电子社保卡签约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF
--     表中文名：电子社保卡签约协议信息聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：CONT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：包含社保云系统端发起的电子社保卡的签约、解约交易数据信息



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF (
     CONT_NO STRING COMMENT '合约编号（合同编号）'
    ,USER_NO STRING COMMENT '用户编号'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,USER_NAME STRING COMMENT '用户名称'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,ACCT_CANC_ACCT_XAM_CD STRING COMMENT '账户销户检查代码'
    ,SIGN_ACCT_NO STRING COMMENT '签约账户编号'
    ,SIGN_ACCT_NAME STRING COMMENT '签约账户名称'
    ,OPBANK_NO STRING COMMENT '开户行行号'
    ,OPBANK_NAME STRING COMMENT '开户行名称'
    ,SIGN_CHNL_CD STRING COMMENT '签约渠道代码'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,CONT_STATUS_CD STRING COMMENT '合约状态代码'
    ,SIGN_TM_STAMP STRING COMMENT '签约时间戳'
    ,CANCEL_CONT_TM_STAMP STRING COMMENT '解约时间戳'
    ,CANCEL_CONT_USER_ID STRING COMMENT '解约用户ID'
    ,MODIF_TM_STAMP STRING COMMENT '修改时间戳'
    ,ACPTD_BNKOUTLS_ORG_NO STRING COMMENT '受理网点机构编号'
    ,TELR_NO STRING COMMENT '柜员编号'
    ,ISSUE_NO STRING COMMENT '签发号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '电子社保卡签约协议信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




