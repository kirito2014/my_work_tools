-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-无纸化交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_PAPLES_TXN_DTL_TF
--     表中文名：无纸化交易明细聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：保留交易流水表中所有记录



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_PAPLES_TXN_DTL_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_PAPLES_TXN_DTL_TF (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,ACCTNG_DT STRING COMMENT '会计日期'
    ,ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,TXN_AMT STRING COMMENT '交易金额'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_NAME STRING COMMENT '交易名称'
    ,CORE_SER_NO STRING COMMENT '核心流水号'
    ,IMAGE_SER_NO STRING COMMENT '影像流水号'
    ,SCENE_CD STRING COMMENT '场景码'
    ,TXN_DEAL_RTN_CD STRING COMMENT '交易处理返回码'
    ,TXN_RETURN_INFO_DESC STRING COMMENT '交易返回信息描述'
    ,TXN_INQR_CD STRING COMMENT '交易查询码'
    ,PAPLES_CHNL_CD STRING COMMENT '无纸化渠道代码'
    ,CHNL_SER_NO STRING COMMENT '渠道流水号'
    ,CHNL_DT STRING COMMENT '渠道日期'
    ,CHNL_TM_STAMP STRING COMMENT '渠道时间戳'
    ,SERVER_IP STRING COMMENT '服务器IP'
    ,SERVER_DT STRING COMMENT '服务器日期'
    ,SERVER_TM_STAMP STRING COMMENT '服务器时间戳'
    ,TXN_ORG_NO STRING COMMENT '交易机构编号'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,CFM_TELR_NO STRING COMMENT '确认柜员编号'
    ,FGPRT_SIGN_STATUS_CD STRING COMMENT '指纹签名状态代码'
    ,PAPLES_SIGN_STATUS_CD STRING COMMENT '无纸化签名状态代码'
    ,PAPLES_CHECK_STATUS_CD STRING COMMENT '无纸化校验状态代码'
    ,IMAGE_PLAT_AL_ISSUED_FLAG STRING COMMENT '影像平台已下发标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '无纸化交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




