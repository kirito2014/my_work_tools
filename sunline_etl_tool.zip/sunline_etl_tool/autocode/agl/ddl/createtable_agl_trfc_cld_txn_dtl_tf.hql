-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_TXN_DTL_TF
--     表中文名：交通云交易明细聚合
--     创建日期：None
--     主键字段：TXN_SER_NO, TXN_TYPE_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_TRFC_CLD_TXN_DTL_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,TXN_TYPE_CD STRING COMMENT '交易类型代码'
    ,USER_ID STRING COMMENT '用户ID'
    ,LIC_PLATE_NO STRING COMMENT '车牌号码'
    ,BIZ_SER_NO STRING COMMENT '业务流水号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TXN_STATUS_CD STRING COMMENT '交易状态代码'
    ,STOP_CAR_PLACE_NO STRING COMMENT '停车场编号'
    ,DRIVING_IN_TM_STAMP STRING COMMENT '驶入时间戳'
    ,PAYER_PAY_CARD_NO STRING COMMENT '付款方支付卡号'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,CUST_DOCTYP_CD STRING COMMENT '客户证件类型代码'
    ,CUST_DOC_NO STRING COMMENT '客户证件号码'
    ,CUST_MOBILE_NO STRING COMMENT '客户手机号码'
    ,MERCHT_IDTFY_NO STRING COMMENT '商户识别编号'
    ,MERCHT_ORDER_NO STRING COMMENT '商户订单编号'
    ,MERCHT_REFUND_BIL_NO STRING COMMENT '商户退款单号'
    ,AGT_NO STRING COMMENT '协议编号'
    ,REFUND_STATUS_DESC STRING COMMENT '退款状态描述                                                                           '
    ,DEL_FLAG STRING COMMENT '删除标志'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,TRFC_CLD_MERCHT_NO STRING COMMENT '交通云商户编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '交通云交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




