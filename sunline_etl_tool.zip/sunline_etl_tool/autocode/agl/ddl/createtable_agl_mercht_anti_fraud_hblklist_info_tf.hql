-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-商户反欺诈灰黑名单信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF
--     表中文名：商户反欺诈灰黑名单信息聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF (
     MERCHT_REC_SER_NO STRING COMMENT '商户记录流水号'
    ,MERCHT_NO STRING COMMENT '商户编号'
    ,MERCHT_NAME STRING COMMENT '商户名称'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,MERCHT_RISK_SRC_CHNL_CD STRING COMMENT '商户风险来源渠道代码'
    ,MERCHT_BLKLIST_STAT_CD STRING COMMENT '商户黑名单状态代码'
    ,RECV_BIL_MERCHT_TXN_CHNL_CD STRING COMMENT '收单商户交易渠道代码'
    ,ACCT_STATUS_CD STRING COMMENT '账户状态代码'
    ,MERCHT_BLKLIST_SRC_CD STRING COMMENT '商户黑名单来源代码'
    ,MERCHANT_FLAG STRING COMMENT 'merchant标志'
    ,MERCHT_DOCTYP_CD STRING COMMENT '商户证件类型代码'
    ,MERCHT_DOC_NO STRING COMMENT '商户证件号码'
    ,LP_REPRSNT_NAME STRING COMMENT '法人代表名称'
    ,LP_REPRSNT_DOCTYP_CD STRING COMMENT '法人代表证件类型代码'
    ,LP_REPRSNT_DOC_NO STRING COMMENT '法人代表证件号码'
    ,LP_RISK_TYPE_CD STRING COMMENT '法人风险类型代码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,CREATE_TM_STAMP STRING COMMENT '创建时间戳'
    ,EXP_TM_STAMP STRING COMMENT '过期时间戳'
    ,FINAL_UPDATE_TM_STAMP STRING COMMENT '最后更新时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '商户反欺诈灰黑名单信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




