-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-人行代理缴费签约信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF
--     表中文名：人行代理缴费签约信息聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：AGT_NO, BIZ_UNIT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：mid平台中所有有效的一户通签约协议数据，不包括已解约又重新签约的解约数据



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF (
     AGT_NO STRING COMMENT '协议编号'
    ,THIRD_PTY_AGT_NO STRING COMMENT '第三方协议编号'
    ,PLAT_DT STRING COMMENT '平台日期'
    ,AGT_EFFECT_DT STRING COMMENT '协议生效日期'
    ,AGT_EXPIR_DT STRING COMMENT '协议失效日期'
    ,PBC_AGEN_PAY_AGT_TYPE_CD STRING COMMENT '人行代理缴费协议类型代码'
    ,BIZ_UNIT_NO STRING COMMENT '业务单元编号'
    ,BIZ_UNIT_NAME STRING COMMENT '业务单元名称'
    ,PBC_BIZ_UNIT_NO STRING COMMENT '人行业务单元编号'
    ,USCD STRING COMMENT '统一社会信用代码'
    ,MDL_BIZ_CATE_NO STRING COMMENT '中间业务种类编号'
    ,THIRD_PTY_USER_NO STRING COMMENT '第三方用户编号'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,USER_NAME STRING COMMENT '用户名称'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,ACCT_PUB_PRIV_TYPE_CD STRING COMMENT '账户公私类型代码'
    ,PBC_AGEN_PAY_ACCT_PROPTY_CD STRING COMMENT '人行代理缴费账户性质代码'
    ,CARD_DISCNT_IDNT_CD STRING COMMENT '卡折标识代码'
    ,ACCT_NO STRING COMMENT '账户编号'
    ,CARD_NO STRING COMMENT '卡片编号'
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO STRING COMMENT '签约账户开户机构编号'
    ,SIGN_ACCT_OPBANK_CNAPS_CODE STRING COMMENT '签约账户开户行人行支付行号'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,CONT_NO_NO STRING COMMENT '联系电话号码'
    ,CONT_ADDR STRING COMMENT '联系地址'
    ,POST_CD STRING COMMENT '邮政编码'
    ,PAYER_TXN_UNION_BANK STRING COMMENT '付款方交易联行号'
    ,PAYEE_TXN_UNION_BANK STRING COMMENT '收款方交易联行号'
    ,INIT_LIQD_BANK_CNAPS_CODE STRING COMMENT '发起清算行人行支付行号'
    ,ACTL_USER_NAME STRING COMMENT '实际使用人名称'
    ,USER_CONT_NO_NO STRING COMMENT '使用人联系电话号码'
    ,USER_ADDR STRING COMMENT '使用人地址'
    ,SIGN_AGENT_NAME STRING COMMENT '签约代理人名称'
    ,SIGN_AGENT_DOCTYP_CD STRING COMMENT '签约代理人证件类型代码'
    ,SIGN_AGENT_DOC_NO STRING COMMENT '签约代理人证件号码'
    ,DEDUCT_PERIOD_CD STRING COMMENT '扣款周期代码'
    ,SINGLE_LMT DECIMAL(28,2) COMMENT '单笔限额'
    ,ALLOW_PERIOD_IN_TXN_CNT BIGINT COMMENT '允许周期内交易笔数'
    ,ALLOW_PERIOD_IN_LMT DECIMAL(28,2) COMMENT '允许周期内限额'
    ,ORIG_TXN_CHNL_DT STRING COMMENT '原交易渠道日期'
    ,ORIG_TXN_CHNL_SER_NO STRING COMMENT '原交易渠道流水号'
    ,SIGN_CHNL_CD STRING COMMENT '签约渠道代码'
    ,SIGN_CONTR_DT STRING COMMENT '签约日期'
    ,SIGN_TM_STAMP STRING COMMENT '签约时间戳'
    ,SIGN_ORG_NO STRING COMMENT '签约机构编号'
    ,SIGN_TELR_NO STRING COMMENT '签约柜员编号'
    ,AUTH_TELR_NO STRING COMMENT '授权柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_UPDATE_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,RECNT_MODIF_ORG_NO STRING COMMENT '最后修改机构编号'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,LIFE_PAY_AGT_STATUS_CD STRING COMMENT '生活缴费协议状态代码'
    ,TXN_EXCEP_DESC STRING COMMENT '交易异常描述'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '人行代理缴费签约信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




