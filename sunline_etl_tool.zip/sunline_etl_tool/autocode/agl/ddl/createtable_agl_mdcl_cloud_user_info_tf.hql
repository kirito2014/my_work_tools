-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-医疗云用户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_MDCL_CLOUD_USER_INFO_TF
--     表中文名：医疗云用户信息聚合
--     创建日期：2024-08-14 00:00:00
--     主键字段：MDCL_CLD_USER_ID
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_MDCL_CLOUD_USER_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF (
     MDCL_CLD_USER_ID STRING COMMENT '医疗云用户ID'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,GENDER_CD STRING COMMENT '性别代码'
    ,CONT_NO_NO STRING COMMENT '联系电话号码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,DOC_EFFECT_DT STRING COMMENT '证件有效日期'
    ,DOC_MATU_DT STRING COMMENT '证件到期日期'
    ,CREATE_TM_STAMP STRING COMMENT '创建时间戳'
    ,MODIF_TM_STAMP STRING COMMENT '修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '医疗云用户信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




