-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人大额存取款交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA
--     表中文名：个人大额存取款交易明细聚合
--     创建日期：2024-05-18 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA (
     ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,DEBIT_CARD_NO STRING COMMENT '借记卡编号'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,DATA_SRC_MODULE_CD STRING COMMENT '数据来源模块代码'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,CASH_TRAN_IDNT_CD STRING COMMENT '现转标识代码'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,TELR_INPUT_ORIG_TRAN_CD STRING COMMENT '柜员输入原交易码'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,AUTH_TELR_NO STRING COMMENT '授权柜员编号'
    ,TXN_ORG_NO STRING COMMENT '交易机构编号'
    ,CNTPTY_ACCT_NO STRING COMMENT '对方账户编号'
    ,CNTPTY_ACCT_NAME STRING COMMENT '对方账户名称'
    ,CNTPTY_BANK_NAME STRING COMMENT '对方行名'
    ,CNTPTY_BANK_NO STRING COMMENT '对方行号'
    ,OPERR_NAME STRING COMMENT '经办人名称'
    ,OPERR_DOCTYP_CD STRING COMMENT '经办人证件类型代码'
    ,OPERR_DOC_NO STRING COMMENT '经办人证件号码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,REM STRING COMMENT '备注'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '个人大额存取款交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




