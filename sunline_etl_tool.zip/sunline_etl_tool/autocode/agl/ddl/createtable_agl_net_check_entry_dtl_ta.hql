-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-网联对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_NET_CHECK_ENTRY_DTL_TA
--     表中文名：网联对账明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：UPP_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：保留三方对账相关的交易信息和流水信息



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_NET_CHECK_ENTRY_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA (
     UPP_SER_NO STRING COMMENT '统一支付平台流水号'
    ,MSG_NO STRING COMMENT '报文编号'
    ,REQE_SER_NO STRING COMMENT '请求流水号'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,NXY_BIZ_MCLS_CD STRING COMMENT '农信银业务大类代码'
    ,RURAL_BANK_CRDT_MSG_TYPE_NO STRING COMMENT '农信银报文类型编号'
    ,ACCT_CONT_IDNT_CD STRING COMMENT '账务往来标识代码'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,TXN_STATUS_CD STRING COMMENT '交易状态代码'
    ,TXN_CMPLT_TM STRING COMMENT '交易完成时间'
    ,THIRD_PTY_SER_NO STRING COMMENT '第三方流水号'
    ,PASS_BATCH_NO STRING COMMENT '通道批次编号'
    ,PLAT_BATCH_NO STRING COMMENT '平台批次编号 '
    ,NUCC_PASS_CHECK_ENTRY_STATUS_CD STRING COMMENT '网联通道对账状态代码'
    ,NUCC_CORE_CHECK_ENTRY_STATUS_CD STRING COMMENT '网联核心对账状态代码'
    ,CHENK_ACCT_CLS_NO STRING COMMENT '对账分类编号'
    ,ACCTN_DT STRING COMMENT '记账日期'
    ,NUCC_CHECK_ENTRY_STATUS_CD STRING COMMENT '网联对账状态代码'
    ,CHECK_ENTRY_STATUS_INFO_DESC STRING COMMENT '对账状态描述信息'
    ,NXY_CHECK_ENTRY_PASS_CD STRING COMMENT '农信银对账通道代码'
    ,NXY_CORE_TYPE_CD STRING COMMENT '农信银核心类型代码'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,业务术语待申请  COMMENT '统一报文epmId'
    ,PLAT_CLEAR_DT STRING COMMENT '平台清算日期'
    ,PASS_CLEAR_DT STRING COMMENT '通道清算日期'
    ,CORE_CLEAR_DT STRING COMMENT '核心清算日期'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '网联对账明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




