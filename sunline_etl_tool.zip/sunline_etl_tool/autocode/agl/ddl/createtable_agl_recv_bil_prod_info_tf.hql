-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单产品信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_RECV_BIL_PROD_INFO_TF
--     表中文名：收单产品信息聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：RECV_BIL_PROD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_RECV_BIL_PROD_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF (
     RECV_BIL_PROD_NO STRING COMMENT '收单产品编号'
    ,RECV_BIL_PROD_NAME STRING COMMENT '收单产品名称'
    ,NEED_DVLP_FLAG STRING COMMENT '需开发标志'
    ,RECV_BIL_PROD_TYPE_CD STRING COMMENT '收单产品类型代码'
    ,RECV_BIL_PROD_SRC_CD STRING COMMENT '收单产品来源代码'
    ,RECV_BIL_PROD_MCLS_CD STRING COMMENT '收单产品大类代码'
    ,RECV_BIL_PROD_MDL_CATOGR_CD STRING COMMENT '收单产品中类代码'
    ,RECV_BIL_PROD_SCLS_CD STRING COMMENT '收单产品小类代码'
    ,RECV_BIL_PROD_DESC STRING COMMENT '收单产品描述'
    ,CAN_CHOOSE_FEE_MODE_SEQ STRING COMMENT '可选计费模式序列'
    ,CAN_CHOOSE_PAY_MODE_SEQ STRING COMMENT '可选支付方式序列'
    ,BIG_WALLET_FIT_ORG_NO_SEQ STRING COMMENT '大钱包适用机构编号序列'
    ,SMALL_WALLET_FIT_ORG_NO_SEQ STRING COMMENT '小钱包适用机构编号序列'
    ,PROD_FIT_ORG_NO_SEQ STRING COMMENT '产品适用机构编号序列'
    ,FIT_MERCHT_ATTR_CD STRING COMMENT '适用商户属性代码'
    ,FIT_MERCHT_TYPE_CD STRING COMMENT '适用商户类型代码'
    ,FIT_MERCHT_MCC_CD_SEQ STRING COMMENT '适用商户MCC代码序列'
    ,FIT_APP_OBJ_TYPE_CD STRING COMMENT '适用申请对象类型代码'
    ,SAM_APPID_MATN_FLAG STRING COMMENT '特约商户appid维护标志'
    ,SERV_PROVDER_APPID_MATN_FLAG STRING COMMENT '服务商appid维护标志'
    ,FIT_TERMN_TYPE_SEQ STRING COMMENT '适用终端类型序列'
    ,AUTO_TUNE_PAY_CTRL_FLAG STRING COMMENT '自动调起支付控件标志'
    ,PUT_ON_FLAG STRING COMMENT '上架标志'
    ,PUT_ON_TM_STAMP STRING COMMENT '上架时间戳'
    ,CREATE_TM_STAMP STRING COMMENT '创建时间戳'
    ,INPUT_TELR_NO STRING COMMENT '录入柜员编号'
    ,INPUT_ORG_NO STRING COMMENT '录入机构编号'
    ,FINAL_UPDATE_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,RECNT_MODIF_ORG_NO STRING COMMENT '最后修改机构编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '收单产品信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




