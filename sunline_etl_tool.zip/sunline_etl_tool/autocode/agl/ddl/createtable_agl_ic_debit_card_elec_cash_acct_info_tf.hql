-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-IC借记卡电子现金账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_IC_DEBIT_CARD_ELEC_CASH_ACCT_INFO_TF
--     表中文名：IC借记卡电子现金账户信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：DEBIT_CARD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_IC_DEBIT_CARD_ELEC_CASH_ACCT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_IC_DEBIT_CARD_ELEC_CASH_ACCT_INFO_TF (
     DEBIT_CARD_NO STRING COMMENT '借记卡编号'
    ,ELEC_CASH_ACCT_NO STRING COMMENT '电子现金账户编号'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NO STRING COMMENT '客户号'
    ,OPEN_ACCT_ORG_NO STRING COMMENT '开户机构编号'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,ACCT_STATUS_CD STRING COMMENT '电子现金账户状态代码'
    ,BMODIF_ECASH_CARD_STAT_CD STRING COMMENT '修改前电子现金卡片状态代码'
    ,CURR_CD STRING COMMENT '币种代码'
    ,DEBIT_CARD_PROD_CD STRING COMMENT '借记卡产品代码'
    ,ELEC_CASH_ACCT_BAL DECIMAL(28,2) COMMENT '电子现金账户余额'
    ,COMPLT_ACCT_BAL DECIMAL(28,2) COMMENT '补登账户余额'
    ,CANC_ACCT_BAL DECIMAL(28,2) COMMENT '销户余额'
    ,FINAL_TXN_DT STRING COMMENT '最后交易日期'
    ,CANC_ACCT_PAY_DT STRING COMMENT '销户付款日期'
    ,LOAD_BIZ_OPEN_FLAG STRING COMMENT '圈存业务开通标志'
    ,ELEC_CASH_LOAD_TYPE_CD STRING COMMENT '电子现金圈存类型代码'
    ,CARD_TRNOUT_MED_TYPE_CD STRING COMMENT '卡转出介质类型代码'
    ,ELEC_CASH_LOAD_SIGN_CHNL_CD STRING COMMENT '电子现金圈存签约渠道代码'
    ,ELEC_CASH_LOAD_MODE_CD STRING COMMENT '电子现金圈存方式代码'
    ,ELEC_CASH_LOAD_SIGN_STATUS_CD STRING COMMENT '电子现金圈存签约状态代码'
    ,LOAD_PERIOD_VAL BIGINT COMMENT '圈存周期值'
    ,LOAD_AMT DECIMAL(28,2) COMMENT '圈存金额'
    ,REC_STATUS_CD STRING COMMENT '记录状态代码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT 'IC借记卡电子现金账户信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




