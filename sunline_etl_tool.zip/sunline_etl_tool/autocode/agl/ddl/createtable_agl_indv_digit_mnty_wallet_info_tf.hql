-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人数字货币钱包信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF
--     表中文名：个人数字货币钱包信息聚合
--     创建日期：2024-03-28 00:00:00
--     主键字段：WALLET_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF (
     WALLET_NO STRING COMMENT '钱包编号'
    ,MAIN_WALLET_FLAG STRING COMMENT '主钱包标志'
    ,WALLET_NAME STRING COMMENT '钱包名称'
    ,WALLET_TYPE_CD STRING COMMENT '钱包类型代码'
    ,WALLET_LVL_CD STRING COMMENT '钱包等级代码'
    ,WALLET_ACCT_STATUS_CD STRING COMMENT '钱包账户状态代码'
    ,WALLET_ESTB_AFLT_FIN_ORG_CD STRING COMMENT '钱包开立所属金融机构编码'
    ,BELONG_RGN_NO STRING COMMENT '归属地区号'
    ,BELONG_BNKOUTLS_ORG_NO STRING COMMENT '归属网点机构编号'
    ,WALLET_ACCESS_MODE_CD STRING COMMENT '钱包接入方式代码'
    ,WALLET_MFSCT_STAT_CD STRING COMMENT '钱包小额免密状态代码'
    ,WALLET_AUTH_STATUS_CD STRING COMMENT '钱包授权状态代码'
    ,IBANK_AUTH_NO STRING COMMENT '同业授权编号'
    ,WALLET_AUTH_TM_STAMP STRING COMMENT '钱包授权时间戳'
    ,WALLET_AUTH_BEGIN_DT STRING COMMENT '钱包授权起始日期'
    ,WALLET_AUTH_END_DT STRING COMMENT '钱包授权结束日期'
    ,WALLET_ESTB_MODE_CD STRING COMMENT '钱包开立方式代码'
    ,ANALY_CHNL_CD STRING COMMENT '分析渠道代码'
    ,PHYS_CHNL_CD STRING COMMENT '物理渠道代码'
    ,SYS_CD STRING COMMENT '系统代码'
    ,FINAL_UPDATE_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,DOC_NO STRING COMMENT '证件号码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,REG_DT STRING COMMENT '注册日期'
    ,WALLET_BIND_MOBILE_NO STRING COMMENT '钱包绑定手机号码'
    ,WALLET_BIND_MAILBOX_ADDR STRING COMMENT '钱包绑定邮箱地址'
    ,VIRTUAL_TELR_NO STRING COMMENT '虚拟柜员编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '个人数字货币钱包信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




