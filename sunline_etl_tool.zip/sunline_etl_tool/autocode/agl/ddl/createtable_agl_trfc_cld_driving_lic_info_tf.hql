-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云行驶证信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_DRIVING_LIC_INFO_TF
--     表中文名：交通云行驶证信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：DRIVING_LIC_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：三张表找不到



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF (
     DRIVING_LIC_NO STRING COMMENT '行驶证编号'
    ,TRFC_FIN_CLD_USER_ID STRING COMMENT '交通金融云用户ID'
    ,LIC_PLATE_NO STRING COMMENT '车牌号码'
    ,VEHIC_TYPE STRING COMMENT '车辆类型'
    ,VEHIC_BELONGER_NAME STRING COMMENT '车辆归属人名称'
    ,CONT_ADDR STRING COMMENT '联系地址'
    ,ETC_USE_FLAG STRING COMMENT 'ETC使用标志'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,VEHIC_USAGE_DESC STRING COMMENT '车辆用途描述'
    ,VEHIC_BRAND STRING COMMENT '车辆品牌'
    ,VEHIC_IDTFY_CD STRING COMMENT '车辆识别代码'
    ,ENGINE_NO STRING COMMENT '发动机编号'
    ,DRIVING_LIC_REG_DT STRING COMMENT '行驶证注册日期'
    ,DRIVING_LIC_ISSUE_DT STRING COMMENT '行驶证签发日期'
    ,ARCHIVE_NO STRING COMMENT '档案编号'
    ,APPRV_LOAD_PSN_CNT BIGINT COMMENT '核定载人数'
    ,TOTAL_WEIGHT STRING COMMENT '总质量'
    ,CURB_WEIGHT STRING COMMENT '整备质量'
    ,APPRV_WEIGHT STRING COMMENT '核定载质量'
    ,OUT_XPSN_DESC STRING COMMENT '外廓尺寸描述'
    ,AXLE_CNT BIGINT COMMENT '车轴数量'
    ,COMNLY_VEHIC_FLAG STRING COMMENT '常用车辆标志'
    ,DEL_FLAG STRING COMMENT '删除标志'
    ,LIC_PLATE_COLOR_CD STRING COMMENT '车牌颜色代码'
    ,CERT_TM_STAMP STRING COMMENT '认证时间戳'
    ,INPUT_TM_STAMP STRING COMMENT '录入时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,MKTING_TELR_NO STRING COMMENT '营销柜员编号'
    ,MKTING_ORG_NO STRING COMMENT '营销机构编号'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '交通云行驶证信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




