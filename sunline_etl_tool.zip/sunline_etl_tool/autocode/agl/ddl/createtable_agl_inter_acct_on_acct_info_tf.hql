-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-内部账户挂账信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_INTER_ACCT_ON_ACCT_INFO_TF
--     表中文名：内部账户挂账信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：ON_ACCT_SER_NO, ON_ACCT_DT, REC_STATUS_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF (
     ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,ON_ACCT_SER_NO STRING COMMENT '挂账序号'
    ,ON_ACCT_DT STRING COMMENT '挂账日期'
    ,INTER_ACCT_ON_ACCT_STATUS_CD STRING COMMENT '内部账户挂账状态代码'
    ,ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,TXN_ORG_NO STRING COMMENT '交易机构编号'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,VOCH_CATE_CD STRING COMMENT '凭证种类代码'
    ,TXN_VOCH_NO STRING COMMENT '交易凭证号码'
    ,VICE_VOCH_CATE_CD STRING COMMENT '副凭证种类代码'
    ,TXN_VICE_VOCH_NO STRING COMMENT '交易副凭证号码'
    ,VOUCH_NO STRING COMMENT '传票套号'
    ,DWELL_SPC_SER_NO STRING COMMENT '套内序号'
    ,CNTPTY_ACCT_NO STRING COMMENT '对方账户编号'
    ,CNTPTY_ACCT_NAME STRING COMMENT '对方账户名称'
    ,ON_ACCT_AMT DECIMAL(28,2) COMMENT '挂账金额'
    ,AL_WRTOFF_AMT DECIMAL(28,2) COMMENT '已销账金额'
    ,UN_WRTOFF_AMT DECIMAL(28,2) COMMENT '未销账金额'
    ,AL_WRTOFF_CNT BIGINT COMMENT '已销账笔数'
    ,FINAL_WRTOFF_DT STRING COMMENT '最后销账日期'
    ,AL_WRTOFF_MAX_SER_NO STRING COMMENT '已销账最大序号'
    ,ON_ACCT_ORG_NO STRING COMMENT '挂账机构编号'
    ,ON_ACCT_CRDT_STAT_SEQ_NO STRING COMMENT '挂账信用站顺序号'
    ,ON_ACCT_TELR_NO STRING COMMENT '挂账柜员编号'
    ,ON_ACCT_AUTH_TELR_NO STRING COMMENT '挂账授权柜员编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,REC_STATUS_CD STRING COMMENT '记录状态代码'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '内部账户挂账信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




