-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-批量代扣表
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_T_AGT_DATA_XXXX_TA_TM
--     表中文名：批量代扣表
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None


--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM (
entr_no           STRING         COMMENT '代理单位编号'                                                                             
,data_date        STRING         COMMENT '数据装入日期'                                                          
,user_no          STRING         COMMENT '用户号'                                                              
,sub_seq          bigint         COMMENT '子序号'                                                              
,end_date         STRING         COMMENT '缴费截止日期 '                                                         
,plat_date        STRING         COMMENT '批量提交日期 '                                                         
,bat_seq          bigint         COMMENT '批号'                                                               
,seri_no          bigint         COMMENT '批内顺序号'                                                               
,entr_bat_seq     bigint         COMMENT '第三方批号(批次号)'                                                      
,file_seq         STRING         COMMENT '文件序号'                                                          
,det_stat         STRING         COMMENT '交易状态'                                                          
,cust_acct_no1    STRING         COMMENT '客户帐号一'                                                      
,set_acct_no1    STRING          COMMENT '结算帐号一'                                                      
,cust_acct_no2    STRING         COMMENT '客户帐号二'                                                      
,set_acct_no2     STRING         COMMENT '结算帐号二'                                                      
,rp_flag          STRING         COMMENT '入帐规则判定标志字段'                                                              
,tran_amt         decimal(16,2)  COMMENT '本金'                                                           
,late_amt         decimal(16,2)  COMMENT '滞纳金'                                                           
,tot_amt          decimal(16,2)  COMMENT '总金额'                                                               
,real_amt         decimal(16,2)  COMMENT '实际发生额'                                                           
,user_name        STRING         COMMENT '用户名'                                                          
,vou_type         STRING         COMMENT '凭证种类'                                                          
,vou_no           STRING         COMMENT '凭证号码'                                                              
,acct_name        STRING         COMMENT '帐户名称'                                                          
,open_brch        STRING         COMMENT '开户机构'                                                          
,acct_bal         decimal(16,2)  COMMENT '帐户余额'                                                           
,entr_date        STRING         COMMENT '计费日期'                                                          
,brch_no          STRING         COMMENT '交易机构编码'                                                              
,oper_no          STRING         COMMENT '交易柜员'                                                              
,tran_date        STRING         COMMENT '交易日期'                                                          
,tran_time        STRING         COMMENT '交易时间'                                                          
,seq_no           bigint         COMMENT '前置流水号'                                                               
,host_seq_no      STRING         COMMENT '主机流水号'                                                          
,host_code        STRING         COMMENT '主机返回代码'                                                          
,host_msg         STRING         COMMENT '主机返回信息'                                                          
,prt_stat         STRING         COMMENT '打印标志'                                                          
,prt_oper         STRING         COMMENT '打印柜员'                                                          
,prt_date         STRING         COMMENT '打印日期'                                                          
,prt_time         STRING         COMMENT '打印时间'                                                          
,prt_seq_no       bigint         COMMENT '打印时的前置流水号'                                                           
,prt_data         STRING         COMMENT '打印字段'                                                          
,last_etl_acg_dt  STRING         COMMENT 'last_etl_acg_dt'                                                       
,del_f            STRING         COMMENT 'del_f'                                                              
,etl_timestamp    STRING         COMMENT 'etl_timestamp' 
)
USING ORC
COMMENT '批量代扣表'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




