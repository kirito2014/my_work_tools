-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-综合代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_SYN_AGEN_PAY_TXN_DTL_TA
--     表中文名：综合代发交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：PLAT_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA (
     PLAT_DT STRING COMMENT '平台日期'
    ,PLAT_BATCH_NO STRING COMMENT '平台批次编号'
    ,BAT_AGEN_PAY_SEQ_NO STRING COMMENT '批量代发顺序号'
    ,BIZ_UNIT_NO STRING COMMENT '业务单元编号'
    ,FRONT_BAT_STATUS_CD STRING COMMENT '前置批量状态代码'
    ,BIZ_UNIT_NAME STRING COMMENT '业务单元名称'
    ,AGEN_CORP_CUST_IN_CD STRING COMMENT '代理单位客户内码'
    ,PAYOFF_CORP_BELONG_ORG_NO STRING COMMENT '代发单位归属机构编号'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,SYN_PAYOFF_OPEN_ACCT_TYPE_CD STRING COMMENT '综合代发开户类型代码'
    ,SYN_PAYOFF_BIZ_CATE_CD STRING COMMENT '综合代发业务种类代码'
    ,SYN_PAYOFF_TYPE_CD STRING COMMENT '综合代发类型代码'
    ,PAYOFF_CORP_ACCT_NO STRING COMMENT '代发单位账户编号'
    ,CUST_ACCT_NO STRING COMMENT '客户账户编号'
    ,SYN_PAYOFF_TXN_STATUS_CD STRING COMMENT '综合代发交易状态代码'
    ,ISSUG_AMT DECIMAL(28,2) COMMENT '代发金额'
    ,PAYOFF_TOTAL_CNT BIGINT COMMENT '代发总笔数'
    ,PAYOFF_SUCC_CNT BIGINT COMMENT '代发成功笔数'
    ,PAYOFF_FAIL_CNT BIGINT COMMENT '代发失败笔数'
    ,HOST_RTN_CD STRING COMMENT '主机返回码'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '综合代发交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




