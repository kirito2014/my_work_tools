-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-小额支付对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：小额支付对账差错明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO, CHECK_ENTRY_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA (
     PLAT_DT STRING COMMENT '平台日期'
    ,PLAT_SER_NO STRING COMMENT '平台流水号'
    ,CHECK_ENTRY_DT STRING COMMENT '对账日期'
    ,MSG_CATEGORY_CD STRING COMMENT '报文类别代码'
    ,MSG_NO STRING COMMENT '报文编号'
    ,COL_PAY_MNY_IDNT_CD STRING COMMENT '收付款标识代码'
    ,MSG_CONT_DIR_CD STRING COMMENT '报文往来方向代码'
    ,MSG_DEAL_STATUS_CD STRING COMMENT '报文处理状态代码'
    ,PBC_AGEN_PAY_BIZ_STATUS_CD STRING COMMENT '人行代理支付业务状态代码'
    ,INIT_LIQD_BANK_CNAPS_CODE STRING COMMENT '发起清算行人行支付行号'
    ,MSG_IDE_NO STRING COMMENT '报文标识号'
    ,RECV_DIR_PRTCPT_ORG_NO STRING COMMENT '接收直接参与机构编号'
    ,TOTAL_CNT BIGINT COMMENT '总笔数'
    ,TXN_TOTAL_AMT DECIMAL(28,2) COMMENT '交易总金额'
    ,NTTG_DT STRING COMMENT '轧差日期'
    ,NTTG_SITE_CNT BIGINT COMMENT '轧差场次'
    ,MICRO_HOST_CHECK_ENTRY_STATUS_CD STRING COMMENT '小额主机对账状态代码'
    ,DONE_ERR_DEAL_FLAG STRING COMMENT '已做差错处理标志'
    ,ERR_DEAL_INFO_DESC STRING COMMENT '差错处理信息描述'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '小额支付对账差错明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




