-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-农信银对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_NXY_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：农信银对账差错明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：PLAT_SER_NO，INCRS_SEQ_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：农信银支付平台与农信银和核心进行三方对账错账处理



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA (
     PLAT_SER_NO STRING COMMENT '平台流水号'
    ,INCRS_SEQ_NO STRING COMMENT '自增顺序号'
    ,NXY_CHECK_ENTRY_PASS_CD STRING COMMENT '农信银对账通道代码'
    ,NXY_CORE_TYPE_CD STRING COMMENT '农信银核心类型代码'
    ,NXY_CHECK_ENTRY_TYPE_CD STRING COMMENT '农信银对账类型代码'
    ,MSG_NO STRING COMMENT '报文编号'
    ,TXN_REQE_SER_NO STRING COMMENT '交易请求流水号'
    ,REQE_SER_NO STRING COMMENT '请求流水号'
    ,END_TO_END_IDE_NO STRING COMMENT '端到端标识号'
    ,CHENK_ACCT_CLS_NO STRING COMMENT '对账分类编号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,CURR_CD STRING COMMENT '币种代码'
    ,COMM_FEE_AMT DECIMAL(28,2) COMMENT '手续费金额'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,NXY_BIZ_SUB_CLS_CD STRING COMMENT '农信银业务子类代码'
    ,ACCT_CONT_IDNT_CD STRING COMMENT '账务往来标识代码'
    ,INTER_MSG_NO_DESC STRING COMMENT '内部报文编号描述'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,TXN_CMPLT_TM_STAMP STRING COMMENT '交易完成时间'
    ,PLAT_CHECK_ENTRY_DT STRING COMMENT '平台对账日期'
    ,CLEAR_DT STRING COMMENT '清算日期'
    ,CORE_CLEAR_DT STRING COMMENT '核心清算日期'
    ,CORE_ACCTN_DT STRING COMMENT '核心会计日期（待治理）'
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD STRING COMMENT '通道核心对账状态代码'
    ,NXY_ERR_ACCT_DEAL_STATUS_CD STRING COMMENT '农信银错账处理状态代码'
    ,NXY_ERR_ACCT_DEAL_MODE_CD STRING COMMENT '农信银错账处理方式代码'
    ,ERR_ACCT_DEAL_MSG_DESC STRING COMMENT '错账处理消息描述'
    ,INPUT_TELR_NO STRING COMMENT '录入柜员编号'
    ,CHECKER_NO STRING COMMENT '复核柜员编号'
    ,CFM_TELR_NO STRING COMMENT '确认柜员编号'
    ,AUTH_TELR_NO STRING COMMENT '授权柜员编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,TXN_CREATE_TM_STAMP STRING COMMENT '交易创建时间戳'
    ,TXN_UPDATE_TM_STAMP STRING COMMENT '交易更新时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '农信银对账差错明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




