-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-移动展业平板设备信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_YDZY_PAD_EQUIP_INFO_TF
--     表中文名：移动展业平板设备信息聚合
--     创建日期：2024-05-20 00:00:00
--     主键字段：EQUIP_PIN_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：可用于统计移动展业设备数量



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_YDZY_PAD_EQUIP_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_YDZY_PAD_EQUIP_INFO_TF (
     EQUIP_PIN_CD STRING COMMENT '设备PIN码'
    ,MDM_NO STRING COMMENT 'MDM编号'
    ,EQUIP_INVTRY_STATUS_CD STRING COMMENT '设备库存状态代码'
    ,APPRV_STATUS_CD STRING COMMENT '审批状态代码'
    ,APPRV_OPIN_DESC STRING COMMENT '审批意见描述'
    ,EQUIP_MGMT_ORG_NO STRING COMMENT '设备管理机构编号'
    ,EQUIP_MGMT_ORG_NAME STRING COMMENT '设备管理机构名称'
    ,USE_TELR_BELONG_ORG_NO STRING COMMENT '使用柜员归属机构编号'
    ,USE_TELR_NO STRING COMMENT '使用柜员编号'
    ,USE_TELR_NAME STRING COMMENT '使用柜员名称'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '移动展业平板设备信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




