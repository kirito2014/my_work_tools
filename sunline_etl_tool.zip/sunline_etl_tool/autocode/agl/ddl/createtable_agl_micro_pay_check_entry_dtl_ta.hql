-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-小额支付对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_MICRO_PAY_CHECK_ENTRY_DTL_TA
--     表中文名：小额支付对账明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：TXN_DT, TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_MICRO_PAY_CHECK_ENTRY_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_DTL_TA (
     TXN_DT STRING COMMENT '交易日期'
    ,TXN_SER_NO STRING COMMENT '交易流水号'
    ,CHECK_ENTRY_DT STRING COMMENT '对账日期'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,ACCT_CONT_IDNT_CD STRING COMMENT '账务往来标识代码'
    ,START_BANK_CNAPS_CODE STRING COMMENT '发起行人行支付行号'
    ,START_BANK_NAME STRING COMMENT '发起行名称'
    ,RECV_BANK_CNAPS_CODE STRING COMMENT '接收行人行支付行号'
    ,RECV_BANK_NAME STRING COMMENT '收款行名称/接收行名称'
    ,DEBIT_CRDT_DIR_CD STRING COMMENT '借贷方向代码'
    ,PAYER_ACCT_NO  STRING COMMENT '付款人账户编号'
    ,PAYEE_ACCT_NO  STRING COMMENT '收款人账户编号'
    ,TXN_SEQ_NO STRING COMMENT '交易序号'
    ,MSG_NO STRING COMMENT '报文编号'
    ,ORIG_TXN_DT STRING COMMENT '原交易日期'
    ,ORIG_TXN_SER_NUM STRING COMMENT '原交易序号'
    ,ORIG_START_BANK_CNAPS_CODE STRING COMMENT '原发起行人行支付行号'
    ,ORIG_START_BANK_NAME STRING COMMENT '原发起行名称'
    ,ORIG_MSG_NO STRING COMMENT '原报文编号'
    ,PKG_COMMS_DT STRING COMMENT '包委托日期'
    ,PKG_SER_NO STRING COMMENT '包序号'
    ,INIT_LIQD_BANK_CNAPS_CODE STRING COMMENT '发起清算行人行支付行号'
    ,INIT_LIQD_BANK_NAME STRING COMMENT '发起清算行名称'
    ,RECV_LIQD_BANK_CNAPS_CODE STRING COMMENT '接收清算行人行支付行号'
    ,RECV_LIQD_BANK_NAME STRING COMMENT '接收清算行名称'
    ,NTTG_DT STRING COMMENT '轧差日期'
    ,NTTG_SITE_CNT BIGINT COMMENT '轧差场次'
    ,MICRO_PAY_CHECK_ENTRY_RESLT_CD STRING COMMENT '小额支付对账结果代码'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '小额支付对账明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




