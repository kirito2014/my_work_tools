-- 模板名称: 聚合层-主档表-全量快照-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-电话银行坐席通话总结信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF
--     表中文名：电话银行坐席通话总结信息聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：BRIEF_SUM_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF (
     BRIEF_SUM_SER_NO STRING COMMENT '小结流水号'
    ,SOUND_REC_SER_NO STRING COMMENT '录音流水号'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,BANK_CARD_NO STRING COMMENT '银行卡号'
    ,CUST_LABEL_CD STRING COMMENT '客户标签代码'
    ,TEL_SEAT_SIGN_TYPE_CD STRING COMMENT '电话坐席签约类型代码'
    ,CUST_DOCTYP_CD STRING COMMENT '客户证件类型代码'
    ,CUST_DOC_NO STRING COMMENT '客户证件号码'
    ,CALL_TEL_NO STRING COMMENT '来电电话号码'
    ,SEAT_TELR_NO STRING COMMENT '坐席柜员编号'
    ,SEAT_LOGIN_ACCT_NO STRING COMMENT '坐席登录账号'
    ,SEAT_EXT_NO STRING COMMENT '坐席分机号码'
    ,SERV_START_TM_STAMP STRING COMMENT '服务开始时间戳'
    ,SERV_END_TM_STAMP STRING COMMENT '服务结束时间戳'
    ,SERV_CALL_DURAN STRING COMMENT '服务通话时长'
    ,SERV_RESLT_DESC STRING COMMENT '服务结果描述'
    ,SERV_CONT_DESC STRING COMMENT '服务内容描述'
    ,SERV_CONT_SUPP_DESC STRING COMMENT '服务内容补充描述'
    ,BRIEF_SUM_SUBMIT_FLAG STRING COMMENT '小结提交标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_CREATE_DT STRING COMMENT 'ETL创建日期'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
    ,DEL_F STRING COMMENT '删除标志'
)
USING ORC
COMMENT '电话银行坐席通话总结信息聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




