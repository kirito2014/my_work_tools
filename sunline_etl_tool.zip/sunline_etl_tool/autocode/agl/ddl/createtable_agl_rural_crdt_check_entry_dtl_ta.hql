-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-农信银对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA
--     表中文名：农信银对账明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：PLAT_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：农信银平台与农信银中心和核心进行三方对账



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA (
     PLAT_SER_NO STRING COMMENT '平台流水号'
    ,NXY_CHECK_ENTRY_PASS_CD STRING COMMENT '农信银对账通道代码'
    ,NXY_CORE_TYPE_CD STRING COMMENT '农信银核心类型代码'
    ,NXY_CHECK_ENTRY_TYPE_CD STRING COMMENT '农信银对账类型代码'
    ,MSG_IDE_NO STRING COMMENT '报文标识号'
    ,REQE_SER_NO STRING COMMENT '请求流水号'
    ,TXN_ORDER_NO STRING COMMENT '交易订单编号'
    ,END_TO_END_IDE_NO STRING COMMENT '端到端标识号'
    ,CHENK_ACCT_CLS_NO STRING COMMENT '对账分类编号'
    ,TXN_BATCH_NO STRING COMMENT '交易批次编号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,COMM_FEE_AMT DECIMAL(28,2) COMMENT '手续费金额'
    ,NXY_BIZ_SCLS_CD STRING COMMENT '农信银业务小类代码'
    ,RURAL_BANK_CRDT_MSG_TYPE_NO STRING COMMENT '农信银报文类型编号'
    ,ACCT_CONT_IDNT_CD STRING COMMENT '账务往来标识代码'
    ,DEBIT_CRDT_IDNT_CD STRING COMMENT '借贷标识代码'
    ,TXN_STATUS_CD STRING COMMENT '交易状态代码'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD STRING COMMENT '通道核心对账状态代码'
    ,NXY_TXN_CHECK_ENTRY_STATUS_CD STRING COMMENT '农信银交易对账状态代码'
    ,PLAT_CLEAR_DT STRING COMMENT '平台清算日期'
    ,CORE_CLEAR_DT STRING COMMENT '核心清算日期'
    ,CORE_DAILY_CUT_DT STRING COMMENT '核心日切日期'
    ,PASS_CLEAR_DT STRING COMMENT '通道清算日期'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,NXY_ERR_DEAL_MODE_CD STRING COMMENT '农信银差错处理方式代码'
    ,TXN_CREATE_TM_STAMP STRING COMMENT '交易创建时间戳'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '农信银对账明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




