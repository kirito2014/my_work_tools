-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-医保社保代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA
--     表中文名：医保社保代发交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：TXN_SER_NO, TXN_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,PLAT_BATCH_NO STRING COMMENT '平台批次编号'
    ,BAT_AGEN_PAY_SEQ_NO STRING COMMENT '批量代发顺序号'
    ,MSS_PAYOFF_IDNT_CD STRING COMMENT '医保社保代发标识代码'
    ,IN_BANK_FUND_COL_ACCT_FLAG STRING COMMENT '行内收款账户标志'
    ,BIZ_UNIT_NO STRING COMMENT '业务单元编号'
    ,BIZ_UNIT_NAME STRING COMMENT '业务单元名称'
    ,SOCI_SECU_PAYOFF_MODE_CD STRING COMMENT '社保代发模式代码'
    ,MSS_PAYOFF_BIZ_TYPE_CD STRING COMMENT '医保社保代发业务类型代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CLEAR_CHNL_CD STRING COMMENT '社保清算渠道代码'
    ,MSS_TXN_DTL_STAT_CD STRING COMMENT '医保社保交易明细状态代码'
    ,AGEN_RCPT_PAY_CUST_ACCT_NO STRING COMMENT '代收付客户账户编号'
    ,AGEN_CORP_STL_ACCT_NO STRING COMMENT '代理单位结算账户编号'
    ,PAY_FUND_ACCT_NO STRING COMMENT '付款账户编号'
    ,PAY_ACCT_NAME STRING COMMENT '付款账户名称'
    ,PAYER_CNAPS_CODE STRING COMMENT '付款方人行支付行号'
    ,PAY_ACCT_OPEN_ACCT_ORG_NO STRING COMMENT '付款账户开户机构编号'
    ,FUND_COL_ACCT_NO STRING COMMENT '收款账户编号'
    ,FUND_COL_ACCT_NAME STRING COMMENT '收款账户名称'
    ,PAYEE_CNAPS_CODE STRING COMMENT '收款方人行支付行号'
    ,BELONG_ORG_NO STRING COMMENT '收款账号归属机构编号'
    ,SOCI_SECU_CARD_CARD_NO STRING COMMENT '社保卡卡号'
    ,PRTCPT_INSURE_OBJ_NO STRING COMMENT '参保对象编号'
    ,PRTCPT_INSURE_OBJ_TYPE_CD STRING COMMENT '参保对象类型代码'
    ,PRTCPT_INSURE_OBJ_NAME STRING COMMENT '参保对象名称'
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD STRING COMMENT '参保对象证件类型代码'
    ,PRTCPT_INSURE_OBJ_DOC_NO STRING COMMENT '参保对象证件号码'
    ,PRTCPT_INSURE_OBJ_NATION_CD STRING COMMENT '参保对象国籍代码'
    ,INS_COMMUNIC_ADDR STRING COMMENT '参保对象通讯地址'
    ,MEDCARE_PAYOFF_DTL_SER_NO STRING COMMENT '医保代发明细流水号'
    ,TXN_CMPLT_TM_STAMP STRING COMMENT '交易完成时间戳'
    ,STL_PLAT_TXN_DT STRING COMMENT '结算平台交易日期'
    ,STL_PLAT_SER_NO STRING COMMENT '结算平台流水号'
    ,MOBILE_NO STRING COMMENT '手机号码'
    ,CONT_NO_NO STRING COMMENT '联系电话号码'
    ,SUMMARY_ILUS STRING COMMENT '摘要说明'
    ,POSTSC_DESC STRING COMMENT '附言描述'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '医保社保代发交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




