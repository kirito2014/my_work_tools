-- 模板名称: 聚合层-流水表-增量流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-校园云交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_CAMPUS_CLD_TXN_DTL_TA
--     表中文名：校园云交易明细聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     时间粒度：日
--     描述信息：None



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA;


/* 1.2 create table  */
CREATE TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,SCH_NO STRING COMMENT '学校编号'
    ,SCH_NAME STRING COMMENT '学校名称'
    ,TXN_CARD_NO STRING COMMENT '交易卡片编号'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,BANK_CARD_NO STRING COMMENT '银行卡号'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,RTN_GOODS_AMT DECIMAL(28,2) COMMENT '退货金额'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,CAMPUS_CLD_TXN_TYPE_CD STRING COMMENT '校园云交易类型代码'
    ,CAMPUS_CLD_TXN_CHNL_CD STRING COMMENT '校园云交易渠道代码'
    ,CAMPUS_CLD_OPER_TYPE_CD STRING COMMENT '校园云操作类型代码'
    ,TXN_BATCH_NO STRING COMMENT '交易批次编号'
    ,TXN_SEQ_NO STRING COMMENT '交易序号'
    ,ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,ORIG_TXN_BATCH_NO STRING COMMENT '原交易批次编号'
    ,RELA_TXN_SER_NO STRING COMMENT '关联交易流水号'
    ,TXN_DEAL_STATUS_CD STRING COMMENT '交易处理状态代码'
    ,CUST_NO STRING COMMENT '客户号'
    ,CAMPUS_CLD_DOCTYP_CD STRING COMMENT '校园云证件类型代码'
    ,USER_DOC_NO STRING COMMENT '用户证件号码'
    ,USER_NAME STRING COMMENT '用户名称'
    ,CAMPUS_CARD_ACCT_BAL DECIMAL(28,2) COMMENT '校园卡账户余额'
    ,AVAILBL_BAL DECIMAL(28,2) COMMENT '可用余额'
    ,TERMN_NO STRING COMMENT '终端编号'
    ,CAMPUS_CLD_MERCHT_NO STRING COMMENT '校园云商户编号'
    ,MERCHT_CLD_MERCHT_NO STRING COMMENT '商户云商户编号'
    ,SPC_ARGMT_MERCHT_NO STRING COMMENT '特约商户编号'
    ,SPC_ARGMT_MERCHT_NAME STRING COMMENT '特约商户名称'
    ,SPC_ARGMT_MERCHT_ABB STRING COMMENT '特约商户简称'
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO STRING COMMENT '特约商户归属机构编号'
    ,OPER_TELR_NO STRING COMMENT '操作柜员编号'
    ,ANSWER_CD STRING COMMENT '应答码'
    ,CHECK_ENTRY_FLAG STRING COMMENT '对账标志'
    ,UNDO_FLAG STRING COMMENT '撤销标志'
    ,RV_FLAG STRING COMMENT '冲正标志'
    ,CREATE_TM_STAMP STRING COMMENT '创建时间戳'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,TXN_EFFECT_FLAG STRING COMMENT '交易有效标志'
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
)
USING ORC
COMMENT '校园云交易明细聚合'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




