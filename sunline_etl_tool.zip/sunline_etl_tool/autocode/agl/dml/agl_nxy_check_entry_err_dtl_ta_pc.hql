-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-农信银对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_NXY_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：农信银对账差错明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：PLAT_SER_NO，INCRS_SEQ_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：原海娜
--     时间粒度：日
--     保留周期：None
--     描述信息：农信银支付平台与农信银和核心进行三方对账错账处理
--     更新记录：
--         2024-07-01 00:00:00 原海娜 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA_TM
USING ORC
COMMENT '农信银对账差错明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_SER_NO -- 平台流水号
    ,INCRS_SEQ_NO -- 自增顺序号
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,MSG_NO -- 报文编号
    ,TXN_REQE_SER_NO -- 交易请求流水号
    ,REQE_SER_NO -- 请求流水号
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,TXN_CURR_CD -- 交易币种代码
    ,NXY_BIZ_SUB_CLS_CD -- 农信银业务子类代码
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,INTER_MSG_NO_DESC -- 内部报文编号描述
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间
    ,PLAT_CHECK_ENTRY_DT -- 平台对账日期
    ,CLEAR_DT -- 清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,CORE_ACCTN_DT -- 核心会计日期（待治理）
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,NXY_ERR_ACCT_DEAL_STATUS_CD -- 农信银错账处理状态代码
    ,NXY_ERR_ACCT_DEAL_MODE_CD -- 农信银错账处理方式代码
    ,ERR_ACCT_DEAL_MSG_DESC -- 错账处理消息描述
    ,INPUT_TELR_NO -- 录入柜员编号
    ,CHECKER_NO -- 复核柜员编号
    ,CFM_TELR_NO -- 确认柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 农信银对账差错明细聚合

INSERT INTO TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA_TM(
     PLAT_SER_NO -- 平台流水号
    ,INCRS_SEQ_NO -- 自增顺序号
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,MSG_NO -- 报文编号
    ,TXN_REQE_SER_NO -- 交易请求流水号
    ,REQE_SER_NO -- 请求流水号
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,TXN_CURR_CD -- 交易币种代码
    ,NXY_BIZ_SUB_CLS_CD -- 农信银业务子类代码
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,INTER_MSG_NO_DESC -- 内部报文编号描述
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间
    ,PLAT_CHECK_ENTRY_DT -- 平台对账日期
    ,CLEAR_DT -- 清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,CORE_ACCTN_DT -- 核心会计日期（待治理）
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,NXY_ERR_ACCT_DEAL_STATUS_CD -- 农信银错账处理状态代码
    ,NXY_ERR_ACCT_DEAL_MODE_CD -- 农信银错账处理方式代码
    ,ERR_ACCT_DEAL_MSG_DESC -- 错账处理消息描述
    ,INPUT_TELR_NO -- 录入柜员编号
    ,CHECKER_NO -- 复核柜员编号
    ,CFM_TELR_NO -- 确认柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.MSG_ID AS PLAT_SER_NO -- 平台流水号
    ,T1.PID AS INCRS_SEQ_NO -- 自增顺序号
    ,T1.TUNNEL_ID AS NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,T1.CORE_ID AS NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,T1.RECON_TP AS NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,'' AS MSG_NO -- 报文编号
    ,T1.REQ_ID AS TXN_REQE_SER_NO -- 交易请求流水号
    ,T1.ORDER_ID AS REQE_SER_NO -- 请求流水号
    ,'' AS END_TO_END_IDE_NO -- 端到端标识号
    ,T1.RECON_CLASSIFY_ID AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,T1.AMOUNT AS TXN_AMT -- 交易金额
    ,T1.CCY AS CURR_CD -- 币种代码
    ,T1.FEE_AMT AS COMM_FEE_AMT -- 手续费金额
    ,T1.TXN_TYPE AS TXN_CURR_CD -- 交易币种代码
    ,T1.BIZ_TYPE AS NXY_BIZ_SUB_CLS_CD -- 农信银业务子类代码
    ,T1.MSG_DIRC AS ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,T1.MSG_TYPE AS INTER_MSG_NO_DESC -- 内部报文编号描述
    ,T1.LOAN_TYPE AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,unifiedTime(T1.TXN_TIME) AS TXN_CMPLT_TM_STAMP -- 交易完成时间
    ,unifiedTime(T1.BATCH_DATE) AS PLAT_CHECK_ENTRY_DT -- 平台对账日期
    ,unifiedTime(T1.TUNNEL_STTL_DATE) AS CLEAR_DT -- 清算日期
    ,unifiedTime(T1.CORE_STTL_DATE) AS CORE_CLEAR_DT -- 核心清算日期
    ,unifiedTime(T1.CORE_CUT_DATE) AS CORE_ACCTN_DT -- 核心会计日期（待治理）
    ,T1.CHANNL_RECON_STATUS AS PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,T1.ERROR_STATUS AS NXY_ERR_ACCT_DEAL_STATUS_CD -- 农信银错账处理状态代码
    ,T1.DEAL_METHOD AS NXY_ERR_ACCT_DEAL_MODE_CD -- 农信银错账处理方式代码
    ,T1.DEAL_MSG AS ERR_ACCT_DEAL_MSG_DESC -- 错账处理消息描述
    ,T1.DEAL_OPT_ID AS INPUT_TELR_NO -- 录入柜员编号
    ,T1.CHK_OPT_ID AS CHECKER_NO -- 复核柜员编号
    ,T1.VERIFY_OPT_ID AS CFM_TELR_NO -- 确认柜员编号
    ,T1.AUTH_OPT_ID AS AUTH_TELR_NO -- 授权柜员编号
    ,T1.TNT_INST_ID AS LP_ORG_NO -- 法人机构编号
    ,'' AS TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,'' AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,'ODS_UCPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_UPCS_SP_BATCH_ERROR_RECON_DETAIL_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_UCPS.ODS_UCPS_SP_BATCH_ERROR_RECON_DETAIL_TA AS T1 -- 错账记录表

WHERE T1.PT_DT = '${process_date}'  AND  T1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_SER_NO -- 平台流水号
    ,INCRS_SEQ_NO -- 自增顺序号
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,MSG_NO -- 报文编号
    ,TXN_REQE_SER_NO -- 交易请求流水号
    ,REQE_SER_NO -- 请求流水号
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,TXN_CURR_CD -- 交易币种代码
    ,NXY_BIZ_SUB_CLS_CD -- 农信银业务子类代码
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,INTER_MSG_NO_DESC -- 内部报文编号描述
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间
    ,PLAT_CHECK_ENTRY_DT -- 平台对账日期
    ,CLEAR_DT -- 清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,CORE_ACCTN_DT -- 核心会计日期（待治理）
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,NXY_ERR_ACCT_DEAL_STATUS_CD -- 农信银错账处理状态代码
    ,NXY_ERR_ACCT_DEAL_MODE_CD -- 农信银错账处理方式代码
    ,ERR_ACCT_DEAL_MSG_DESC -- 错账处理消息描述
    ,INPUT_TELR_NO -- 录入柜员编号
    ,CHECKER_NO -- 复核柜员编号
    ,CFM_TELR_NO -- 确认柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_NXY_CHECK_ENTRY_ERR_DTL_TA_TM;
