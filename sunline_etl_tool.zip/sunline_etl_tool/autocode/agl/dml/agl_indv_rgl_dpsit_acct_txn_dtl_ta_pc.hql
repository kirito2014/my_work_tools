-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人定期存款账户交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA
--     表中文名：个人定期存款账户交易明细聚合
--     创建日期：2023-12-29 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_DT, TXN_ACCT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-29 00:00:00 游崔龙 新增
--         2024-01-09 00:00:00 游崔龙 对标
--         2024-09-09 00:00:00 魏丹丹 修改取数逻辑
--         2024-10-21 00:00:00 魏丹丹 修改设计0923/0927的变更



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '个人定期存款账户交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人定期存款账户交易明细聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_01;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_01 (
     ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,OLD_SYS_TXN_ACCT_NO STRING COMMENT '老系统交易账户编号'
    ,MRG_REC_TYPE_CD STRING COMMENT '保证金记录类型代码'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_DIR_CD STRING COMMENT '交易方向代码'
    ,TXN_TYPE_CD STRING COMMENT '交易类型代码'
    ,CASH_TRAN_IDNT_CD STRING COMMENT '现转标识代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_AMT_CONVT_RMB DECIMAL(28,2) COMMENT '交易金额折人民币'
    ,TXN_AMT_CONVT_USD DECIMAL(28,2) COMMENT '交易金额折美元'
    ,ACCT_BAL DECIMAL(28,2) COMMENT '账户余额'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,TXN_HAPP_ORG_NO STRING COMMENT '交易发生机构编号'
    ,TXN_RGN_NO STRING COMMENT '交易地区编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,INITR_SYS_CD STRING COMMENT '发起方系统代码'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,SUB_TRAN_CD STRING COMMENT '子交易码'
    ,DPSIT_IN_DRAW_TMS STRING COMMENT '存入支取期数'
    ,TXN_VOCH_CATE_CD STRING COMMENT '交易凭证种类代码'
    ,TXN_VOCH_NO STRING COMMENT '交易凭证号码'
    ,AGENT_BANK_BNKOUTLS_NO STRING COMMENT '代理行网点编号'
    ,DLGT_BANK_BNKOUTLS_NO STRING COMMENT '委托行网点编号'
    ,REM STRING COMMENT '备注'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
)
USING ORC
COMMENT '个人定期存款账户交易明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_01(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
)
SELECT
     CAST(P1.AC04TXSN AS STRING) AS ORIG_TXN_SER_NO -- 原交易流水号
    ,CAST(P1.AC05TSSN AS STRING) AS SUB_TXN_SER_NO -- 子交易流水号
    ,unifiedTime(CAST(P1.AC03DATE AS STRING)) AS TXN_DT -- 交易日期
    ,P1.AC01AC15 AS TXN_ACCT_NO -- 交易账户编号
    ,unifiedTime1(P2.CRE_TS) AS TXN_TM_STAMP -- 交易时间戳
    ,CAST(P1.AC24SN04 AS STRING) AS TELR_SER_NO -- 柜员流水号
    ,P1.AC25NO12 AS FRONT_SER_NO -- 前置流水号
    ,P2.OACC_NO AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,'' AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,P1.AC07CCYC AS TXN_CURR_CD -- 交易币种代码
    ,P2.CSDR_FLG AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P2.SYS_TXID AS TRAN_CD -- 交易码
    ,P1.AC09CDFG AS TXN_DIR_CD -- 交易方向代码
    ,P1.AC18JYLX AS TXN_TYPE_CD -- 交易类型代码
    ,P2.CSTR_IND AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.AC10AMT AS TXN_AMT -- 交易金额
    ,CASE WHEN  P1.AC07CCYC = 'CNY' THEN  P1.AC10AMT ELSE P1.AC10AMT*COALESCE(P3.YRCAEXRT,0)/COALESCE(P3.YRCACUNO,1)  END AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,(CASE WHEN  P1.AC07CCYC <> 'CNY' THEN P1.AC10AMT*P3.YRCAEXRT/P3.YRCACUNO ELSE P1.AC10AMT END )/P5.YRCAEXRT*P5.YRCACUNO AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.AC11BAL AS ACCT_BAL -- 账户余额
    ,P1.AC06NTCD AS SUMMARY_CD -- 摘要代码
    ,P2.ABS_DSC AS SUMMARY_DESC -- 摘要描述
    ,P4.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P4.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P2.TX_OUNO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P2.TX_DIS AS TXN_RGN_NO -- 交易地区编号
    ,P1.AC15STAF AS TXN_TELR_NO -- 交易柜员编号
    ,P2.SRS_ID AS INITR_SYS_CD -- 发起方系统代码
    ,P1.AC14CNCD AS TXN_CHNL_CD -- 交易渠道代码
    ,P2.ATX_ID AS SUB_TRAN_CD -- 子交易码
    ,CAST(P1.AC08SN03 AS STRING) AS DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,CASE WHEN P2.VOU_TYP1 IS NULL OR TRIM(P2.VOU_TYP1)=''
     THEN ''
     ELSE COALESCE(TRIM(P6.TARGET_CD_VAL), CONCAT('@',TRIM(P2.VOU_TYP1)),'')
END AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P2.VOU_NO1 AS TXN_VOCH_NO -- 交易凭证号码
    ,P1.AC16BRNO AS AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,P1.AC17BRNO AS DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,P2.JRN_MARK AS REM -- 备注
    ,unifiedTime(CAST(P2.CRT_DTE AS STRING)) AS SETUP_DT -- 建立日期
    ,unifiedTime(P2.CRE_TS) AS SETUP_TM_STAMP -- 建立时间戳
    ,P2.CRE_UID AS SETUP_TELR_NO -- 建立柜员编号
    ,CAST(P2.UPD_DTE AS STRING) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P2.UPD_TS) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P2.UPD_UID AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
FROM
ODS_CORE${version_num}.ODS_CORE_BFFTDQAC_TA AS P1 -- 定期存入、支取明细表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BYFTJRN_TA AS P2 -- 会计流水文件
       ON P1.AC03DATE = CAST(REPLACE(cast(P2.TX_DATE as STRING),'-','') AS DECIMAL(8,0))
AND P1.AC05TSSN = P2.BTX_JNO
AND P1.AC04TXSN = P2.ATX_JNO
AND P1.AC01AC15 = P2.ACC_NO 
AND P2.PT_DT = '${process_date}'
AND P2.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P3 -- 年度报表汇率文件
       ON P1.AC07CCYC = P3.YRCACCYC 
AND CAST(P3.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日 
AND P3.YRCARS1B <> '9'
AND P3.DEL_F='0'
AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS P4 -- 新会计科目核算码对照表
       ON P2.GLAC_NO = P4.KHDBACID AND P4.PT_DT = '${process_date}'  AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P5 -- 年度报表汇率文件
       ON P3.PT_DT = P5.PT_DT
AND CAST(P5.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日
AND P5.YRCARS1B <> '9'
AND P5.YRCACCYC = 'USD' 
AND P5.DEL_F='0'
AND P5.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P6 -- 代码转换
       ON P2.VOU_TYP1=P6.SRC_CD_VAL  
AND P6.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND P6.SRC_TAB_EN_NAME='BYFTJRN' --来源表英文名  
AND P6.SRC_FIELD_EN_NAME='VOU_TYP1' --来源字段英文名 
AND P6.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA'  --目标表名   
AND P6.TARGET_FIELD_EN_NAME='TXN_VOCH_CATE_CD' --目标字段 
WHERE SUBSTR(P1.AC01AC15,1,1) = '1'   AND P1.RCSTRS1B <> '9' AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第1-2组）==============
-- 个人定期存款账户交易明细聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_02;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_02 (
     ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,OLD_SYS_TXN_ACCT_NO STRING COMMENT '老系统交易账户编号'
    ,TXN_ACCT_NAME STRING COMMENT '交易账户名称'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,NATION_CD STRING COMMENT '国籍代码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,ACCT_TYPE_CD STRING COMMENT '账户类型代码'
    ,MRG_REC_TYPE_CD STRING COMMENT '保证金记录类型代码'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_DIR_CD STRING COMMENT '交易方向代码'
    ,TXN_TYPE_CD STRING COMMENT '交易类型代码'
    ,CASH_TRAN_IDNT_CD STRING COMMENT '现转标识代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_AMT_CONVT_RMB DECIMAL(28,2) COMMENT '交易金额折人民币'
    ,TXN_AMT_CONVT_USD DECIMAL(28,2) COMMENT '交易金额折美元'
    ,ACCT_BAL DECIMAL(28,2) COMMENT '账户余额'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,TXN_HAPP_ORG_NO STRING COMMENT '交易发生机构编号'
    ,TXN_RGN_NO STRING COMMENT '交易地区编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,INITR_SYS_CD STRING COMMENT '发起方系统代码'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,SUB_TRAN_CD STRING COMMENT '子交易码'
    ,DPSIT_IN_DRAW_TMS STRING COMMENT '存入支取期数'
    ,TXN_VOCH_CATE_CD STRING COMMENT '交易凭证种类代码'
    ,TXN_VOCH_NO STRING COMMENT '交易凭证号码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,AGENT_BANK_BNKOUTLS_NO STRING COMMENT '代理行网点编号'
    ,DLGT_BANK_BNKOUTLS_NO STRING COMMENT '委托行网点编号'
    ,REM STRING COMMENT '备注'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,AB01AC15 STRING COMMENT '关联字段'
    ,AB03CCYC STRING COMMENT '关联字段'
    ,AB05CHSX STRING COMMENT '关联字段'
    ,AB32DATE STRING COMMENT '关联字段'
)
USING ORC
COMMENT '个人定期存款账户交易明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_02(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,AB01AC15 -- 关联字段
    ,AB03CCYC -- 关联字段
    ,AB05CHSX -- 关联字段
    ,AB32DATE -- 关联字段
)
SELECT
     P1.ORIG_TXN_SER_NO AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.SUB_TXN_SER_NO AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.TXN_DT AS TXN_DT -- 交易日期
    ,P1.TXN_ACCT_NO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.TXN_TM_STAMP AS TXN_TM_STAMP -- 交易时间戳
    ,P1.TELR_SER_NO AS TELR_SER_NO -- 柜员流水号
    ,P1.FRONT_SER_NO AS FRONT_SER_NO -- 前置流水号
    ,P1.OLD_SYS_TXN_ACCT_NO AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,P2.AA04FLNM AS TXN_ACCT_NAME -- 交易账户名称
    ,COALESCE(P3.USER_ID,T4.CUSTID) AS USER_ID -- 用户ID
    ,P2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P4.CUST_NM AS CUST_NAME -- 客户名称
    ,P4.NTNLT AS NATION_CD -- 国籍代码
    ,P5.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,P5.CRTF_NO AS DOC_NO -- 证件号码
    ,P6.AB06ACFG AS ACCT_TYPE_CD -- 账户类型代码
    ,'' AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,P1.TXN_CURR_CD AS TXN_CURR_CD -- 交易币种代码
    ,P1.TXN_CASH_RMT_CD AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.TRAN_CD AS TRAN_CD -- 交易码
    ,P1.TXN_DIR_CD AS TXN_DIR_CD -- 交易方向代码
    ,P1.TXN_TYPE_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.CASH_TRAN_IDNT_CD AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,P1.TXN_AMT_CONVT_RMB AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,P1.TXN_AMT_CONVT_USD AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.ACCT_BAL AS ACCT_BAL -- 账户余额
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SUMMARY_DESC AS SUMMARY_DESC -- 摘要描述
    ,P1.ACCTN_SUBJ_NO AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.ACCTN_SUBJ_NAME AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,CONCAT(P6.AB10PDTP,P6.AB11PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,P7.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.TXN_HAPP_ORG_NO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P1.TXN_RGN_NO AS TXN_RGN_NO -- 交易地区编号
    ,P1.TXN_TELR_NO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.INITR_SYS_CD AS INITR_SYS_CD -- 发起方系统代码
    ,P1.TXN_CHNL_CD AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.SUB_TRAN_CD AS SUB_TRAN_CD -- 子交易码
    ,P1.DPSIT_IN_DRAW_TMS AS DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,P1.TXN_VOCH_CATE_CD AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.TXN_VOCH_NO AS TXN_VOCH_NO -- 交易凭证号码
    ,P2.AA40BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.AA42BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.AA43BRNO AS LP_ORG_NO -- 法人机构编号
    ,P1.AGENT_BANK_BNKOUTLS_NO AS AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,P1.DLGT_BANK_BNKOUTLS_NO AS DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,P1.REM AS REM -- 备注
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.SETUP_TELR_NO AS SETUP_TELR_NO -- 建立柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_MODIF_TM_STAMP AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P6.AB01AC15 AS AB01AC15 -- 关联字段
    ,P6.AB03CCYC AS AB03CCYC -- 关联字段
    ,P6.AB05CHSX AS AB05CHSX -- 关联字段
    ,P6.AB32DATE AS AB32DATE -- 关联字段
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_01 AS P1 -- 临时表1

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAA_TF AS P2 -- 定期存款账户控制文件
       ON P1.TXN_ACCT_NO = P2.AA01AC15 AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
LEFT JOIN (
SELECT
   CST_IN_CD
  ,USER_ID
FROM(
   SELECT 
      CST_IN_CD
     ,USER_ID
     ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY USER_ID DESC) AS RN
   FROM ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF
   WHERE  DELETED='0' AND PT_DT = '${process_date}'  AND DEL_F='0'
   )
WHERE RN=1
) AS P3 -- 用户信息表
       ON P2.AA03CSNO = P3.CST_IN_CD 
LEFT JOIN (SELECT * FROM(
    SELECT
      U4.CUSTID
     ,U4.CUSTCD 
     ,ROW_NUMBER() OVER(PARTITION BY U4.CUSTCD ORDER BY U4.STATUS   ) RN
    FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF  U4
    WHERE U4.PT_DT = '${process_date}'  AND DEL_F = '0'
)D4 WHERE D4.RN = 1) AS T4 -- 客户信息关联表
       ON P2.AA03CSNO =T4.CUSTCD 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF AS P4 -- 客户基础信息表
       ON P2.AA03CSNO = P4.CST_IN_CD AND P4.PT_DT = '${process_date}'  AND P4.DEL_F='0' 
LEFT JOIN (
SELECT
   CST_IN_CD
  ,CRTF_NO
  ,CRTF_TYP
FROM(
   SELECT 
      CST_IN_CD
     ,CRTF_NO
     ,CRTF_TYP
     ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) AS RN
   FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF
   WHERE MAJOR_FLG = '1' AND DELETED='0' AND PT_DT = '${process_date}'  AND DEL_F='0'
   )
WHERE RN=1
) AS P5 -- 客户证件信息表
       ON P2.AA03CSNO = P5.CST_IN_CD 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAB_TF AS P6 -- 定期模块账户分户余额信息
       ON P1.TXN_ACCT_NO = P6.AB01AC15 AND P6.AB03CCYC=P1.TXN_CURR_CD  AND P6.PT_DT = '${process_date}'  AND P6.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQCW_TF AS P7 -- 产品代码名称表
       ON P6.AB11PRON = P7.CW05FLNM AND P6.AB10PDTP = P7.CW02PDTP AND P7.PT_DT = '${process_date}'  AND P7.DEL_F='0' 
;
-- ==============聚合层字段映射（第1-3组）==============
-- 个人定期存款账户交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ORIG_TXN_SER_NO AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.SUB_TXN_SER_NO AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.TXN_DT AS TXN_DT -- 交易日期
    ,P1.TXN_ACCT_NO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.TXN_TM_STAMP AS TXN_TM_STAMP -- 交易时间戳
    ,P1.TELR_SER_NO AS TELR_SER_NO -- 柜员流水号
    ,P1.FRONT_SER_NO AS FRONT_SER_NO -- 前置流水号
    ,P1.OLD_SYS_TXN_ACCT_NO AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,P1.TXN_ACCT_NAME AS TXN_ACCT_NAME -- 交易账户名称
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.NATION_CD AS NATION_CD -- 国籍代码
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.ACCT_TYPE_CD AS ACCT_TYPE_CD -- 账户类型代码
    ,P2.BC08ZHTP AS ACCT_PROPTY_CD -- 账户性质代码
    ,'' AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,P1.TXN_CURR_CD AS TXN_CURR_CD -- 交易币种代码
    ,P1.TXN_CASH_RMT_CD AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.TRAN_CD AS TRAN_CD -- 交易码
    ,P1.TXN_DIR_CD AS TXN_DIR_CD -- 交易方向代码
    ,P1.TXN_TYPE_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.CASH_TRAN_IDNT_CD AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,P1.TXN_AMT_CONVT_RMB AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,P1.TXN_AMT_CONVT_USD AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.ACCT_BAL AS ACCT_BAL -- 账户余额
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SUMMARY_DESC AS SUMMARY_DESC -- 摘要描述
    ,P1.ACCTN_SUBJ_NO AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.ACCTN_SUBJ_NAME AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P1.DPSIT_PROD_NAME AS DPSIT_PROD_NAME -- 存款产品名称
    ,P3.ET05AC32 AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P3.ET06FLNM AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,P3.ET07BK20 AS CNTPTY_BANK_NO -- 对方行号
    ,P4.ORCAFLNM AS CNTPTY_BANK_NAME -- 对方行名
    ,P1.TXN_HAPP_ORG_NO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P1.TXN_RGN_NO AS TXN_RGN_NO -- 交易地区编号
    ,P1.TXN_TELR_NO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.INITR_SYS_CD AS INITR_SYS_CD -- 发起方系统代码
    ,P1.TXN_CHNL_CD AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.SUB_TRAN_CD AS SUB_TRAN_CD -- 子交易码
    ,P5.KF06IPAD AS TXN_EQUIP_IP -- 交易设备IP
    ,P5.KF07MAC AS TXN_EQUIP_MAC -- 交易设备MAC
    ,P1.DPSIT_IN_DRAW_TMS AS DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,P1.TXN_VOCH_CATE_CD AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.TXN_VOCH_NO AS TXN_VOCH_NO -- 交易凭证号码
    ,P6.HA07CFTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P6.HA08CFNO AS AGENT_DOC_NO -- 代理人证件号码
    ,P6.HA09FLNM AS AGENT_NAME -- 代理人名称
    ,P6.HA10TELN AS AGENT_CONT_MODE -- 代理人联系方式
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.STAT_ORG_NO AS STAT_ORG_NO -- 统计机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,P1.AGENT_BANK_BNKOUTLS_NO AS AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,P1.DLGT_BANK_BNKOUTLS_NO AS DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,P1.REM AS REM -- 备注
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.SETUP_TELR_NO AS SETUP_TELR_NO -- 建立柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_MODIF_TM_STAMP AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BFFTDQAC_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_02 AS P1 -- 临时表2

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBC_TF AS P2 -- 开户登记薄
       ON TRIM(P2.BC01AC22)=TRIM(P1.AB01AC15)  
AND TRIM(P2.BC03CCYC)=TRIM(P1.AB03CCYC) 
AND TRIM(P2.BC04CHSX)=TRIM(P1.AB05CHSX) 
AND TRIM(P2.BC31DATE)=TRIM(P1.AB32DATE) 
AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQET_TF AS P3 -- 活期存款当日账户交易明细补充信息表
       ON P1.TXN_ACCT_NO = P3.ET01AC15
AND cast(P1.TXN_DT as DECIMAL(28,2)) = P3.ET02DATE
AND cast(P1.ORIG_TXN_SER_NO as DECIMAL(28,2))  = P3.ET03TXSN
AND cast(P1.SUB_TXN_SER_NO as DECIMAL(28,2)) = P3.ET04TSSN 
AND P3.DEL_F='0'
AND P3.PT_DT = '${process_date}'  
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BBFMORGA_TF AS P4 -- 机构信息表
       ON P3.ET07BK20 = P4.ORCABRNO AND P4.PT_DT = '${process_date}'  AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQKF_TA AS P5 -- 活期存款互联网交易登记簿（当日）
       ON P1.TXN_ACCT_NO = P5.KF01AC15
and cast(P1.TXN_DT as DECIMAL(28,2))  = P5.KF02DATE
AND cast(P1.ORIG_TXN_SER_NO as DECIMAL(28,2))  = P5.KF03TXSN
AND cast(P1.SUB_TXN_SER_NO as DECIMAL(28,2)) = P5.KF04TSSN 
AND P5.DEL_F='0'
 AND P5.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQHA_TA AS P6 -- 会计流水补充文件
       ON cast(P1.TXN_DT as DECIMAL(28,2))  = CAST(REPLACE(CAST(P6.HA17DTE AS STRING),'-','') AS DECIMAL(10,0))
AND cast(P1.ORIG_TXN_SER_NO as DECIMAL(28,2))  = P6.HA01TXSN
AND cast(P1.SUB_TXN_SER_NO as DECIMAL(28,2)) = P6.HA04TSSN 
AND P6.DEL_F='0'  AND P6.PT_DT = '${process_date}' 
;
-- ==============聚合层字段映射（第2-1组）==============
-- 个人定期存款账户交易明细聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_03;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_03 (
     ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,TXN_ACCT_NAME STRING COMMENT '交易账户名称'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_DIR_CD STRING COMMENT '交易方向代码'
    ,TXN_TYPE_CD STRING COMMENT '交易类型代码'
    ,CASH_TRAN_IDNT_CD STRING COMMENT '现转标识代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_AMT_CONVT_RMB DECIMAL(28,2) COMMENT '交易金额折人民币'
    ,TXN_AMT_CONVT_USD DECIMAL(28,2) COMMENT '交易金额折美元'
    ,ACCT_BAL DECIMAL(28,2) COMMENT '账户余额'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,CNTPTY_TXN_ACCT_NO STRING COMMENT '对方交易账户编号'
    ,CNTPTY_TXN_ACCT_NAME STRING COMMENT '对方交易账户名称'
    ,CNTPTY_BANK_NO STRING COMMENT '对方行号'
    ,CNTPTY_BANK_NAME STRING COMMENT '对方行名'
    ,TXN_HAPP_ORG_NO STRING COMMENT '交易发生机构编号'
    ,TXN_RGN_NO STRING COMMENT '交易地区编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,TXN_EQUIP_IP STRING COMMENT '交易设备IP'
    ,TXN_EQUIP_MAC STRING COMMENT '交易设备MAC'
    ,TXN_VOCH_CATE_CD STRING COMMENT '交易凭证种类代码'
    ,TXN_VOCH_NO STRING COMMENT '交易凭证号码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,REM STRING COMMENT '备注'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,TOACCT STRING COMMENT '关联字段'
    ,AMNTCD STRING COMMENT '关联字段'
    ,ACCTNO STRING COMMENT '关联字段'
    ,DTITCD STRING COMMENT '关联字段'
    ,TRANMS STRING COMMENT '关联字段'
    ,AGENT_DOCTYP_CD STRING COMMENT '代理人证件类型代码'
    ,AGENT_DOC_NO STRING COMMENT '代理人证件号码'
    ,AGENT_NAME STRING COMMENT '代理人名称'
    ,AGENT_CONT_MODE STRING COMMENT '代理人联系方式'
)
USING ORC
COMMENT '个人定期存款账户交易明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_03(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,TOACCT -- 关联字段
    ,AMNTCD -- 关联字段
    ,ACCTNO -- 关联字段
    ,DTITCD -- 关联字段
    ,TRANMS -- 关联字段
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
)
SELECT
     P1.TRANSQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,CAST(P1.DETLSQ AS STRING) AS SUB_TXN_SER_NO -- 子交易流水号
    ,unifiedTime(P1.TRANDT) AS TXN_DT -- 交易日期
    ,P1.ACCTNO AS TXN_ACCT_NO -- 交易账户编号
    ,unifiedTime(P1.TRANTM) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.USSQNO AS TELR_SER_NO -- 柜员流水号
    ,P1.PROCSQ AS FRONT_SER_NO -- 前置流水号
    ,P1.ACCTNA AS TXN_ACCT_NAME -- 交易账户名称
    ,P1.TRANCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.CSEXTG AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.INTRCD AS TRAN_CD -- 交易码
    ,CASE WHEN P1.AMNTCD IS NULL OR TRIM(P1.AMNTCD)=''
     THEN ''
     ELSE COALESCE(TRIM(P8.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AMNTCD)),'')
END AS TXN_DIR_CD -- 交易方向代码
    ,CASE WHEN P1.CORRTG = '1' THEN '2'
     WHEN P1.STACPS = '1' THEN '3'
     WHEN P1.STACPS = '2' THEN '4'
     ELSE '1' END AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN P1.cdtrfg= '0' THEN '1' else '2' end AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.TRANAM AS TXN_AMT -- 交易金额
    ,CASE WHEN  P1.TRANCY = 'CNY' THEN CAST(P1.TRANAM AS DECIMAL(28,2)) ELSE CAST(P1.TRANAM AS DECIMAL(28,2))*(COALESCE(P3.YRCAEXRT,0)/COALESCE(P3.YRCACUNO,1))  END AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,(CASE WHEN  P1.TRANCY <> 'CNY' THEN CAST(P1.TRANAM AS DECIMAL(28,2))*P3.YRCAEXRT/P3.YRCACUNO ELSE CAST(P1.TRANAM AS DECIMAL(28,2)) END)/P7.YRCAEXRT*P7.YRCACUNO AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.ACCTBL AS ACCT_BAL -- 账户余额
    ,P1.SMRYCD AS SUMMARY_CD -- 摘要代码
    ,P1.SMRYDS AS SUMMARY_DESC -- 摘要描述
    ,P1.OPCUAC AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P1.OPACNA AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CASE WHEN (TRIM(P1.BANKCD) = '' OR P1.BANKCD IS NULL) AND (P1.OPBRCH = '999000' OR TRIM(P1.OPBRCH)='' OR P1.OPBRCH IS NULL)
     THEN CASE WHEN SUBSTR(P1.OPCUAC,1,6) <> '933000'
               THEN CASE WHEN SUBSTR(P1.OPCUAC,1,10)=P4.CARD_BIN_NO 
                         THEN P4.BANK_NO 
                         ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,9)=P4.CARD_BIN_NO 
                                   THEN P4.BANK_NO
                                   ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,8)=P4.CARD_BIN_NO 
                                             THEN P4.BANK_NO 
                                             ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,7)=P4.CARD_BIN_NO 
                                                       THEN P4.BANK_NO
                                                       ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,6)=P4.CARD_BIN_NO 
                                                                 THEN P4.BANK_NO 
                                                                 ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,5)=P4.CARD_BIN_NO 
                                                                           THEN P4.BANK_NO
                                                                           ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,4)=P4.CARD_BIN_NO 
                                                                                     THEN P4.BANK_NO 
                                                                                 END 
                                                                       END 
                                                              END 
                                                    END 
                                          END 
                                 END 
                        END 
               WHEN SUBSTR(P1.OPCUAC,1,6)='933000' 
               THEN '403100000004'
               ELSE CASE WHEN LENGTH(TRIM(P1.BANKCD))>0 
                         THEN P1.BANKCD 
                         ELSE P1.OPBRCH 
                     END 
           END 
 END AS CNTPTY_BANK_NO -- 对方行号
    ,CASE WHEN (TRIM(P1.BANKCD) = '' OR P1.BANKCD IS NULL) AND (P1.OPBRCH = '999000' OR TRIM(P1.OPBRCH)='' OR P1.OPBRCH IS NULL)
      THEN CASE WHEN SUBSTR(P1.OPCUAC,1,6)<>'933000'
                THEN CASE WHEN SUBSTR(P1.OPCUAC,1,10)=P4.CARD_BIN_NO 
                          THEN P4.BANK_NAME 
                          ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,9)=P4.CARD_BIN_NO 
                                    THEN P4.BANK_NAME
                                    ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,8)=P4.CARD_BIN_NO 
                                              THEN P4.BANK_NAME 
                                              ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,7)=P4.CARD_BIN_NO 
                                                        THEN P4.BANK_NAME
                                                        ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,6)=P4.CARD_BIN_NO 
                                                                  THEN P4.BANK_NAME 
                                                                  ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,5)=P4.CARD_BIN_NO 
                                                                            THEN P4.BANK_NAME
                                                                            ELSE CASE WHEN SUBSTR(P1.OPCUAC,1,4)=P4.CARD_BIN_NO 
                                                                                      THEN P4.BANK_NAME 
                                                                                  END 
                                                                       END 
                                                              END 
                                                   END 
                                          END 
                               END 
                      END 
                WHEN SUBSTR(P1.OPCUAC,1,6)='933000' 
                THEN '403100000004'
                ELSE CASE WHEN LENGTH(TRIM(P1.BANKCD))>0 
                          THEN P1.BANKCD 
                          ELSE P1.OPBRCH 
                      END 
           END 
  END AS CNTPTY_BANK_NAME -- 对方行名
    ,P1.TRANBR AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P5.ORCAATDR AS TXN_RGN_NO -- 交易地区编号
    ,P1.USERID AS TXN_TELR_NO -- 交易柜员编号
    ,P1.SERVTP AS TXN_CHNL_CD -- 交易渠道代码
    ,CASE WHEN COALESCE(TRIM(P1.OPPOMK),'') = ''  THEN '' WHEN LENGTH(P1.OPPOMK) <=2 THEN P1.OPPOMK
ELSE SPLIT(P1.OPPOMK,'\|,')[1]    END AS TXN_EQUIP_IP -- 交易设备IP
    ,CASE WHEN COALESCE(TRIM(P1.OPPOMK),'') = ''  THEN '' WHEN LENGTH(P1.OPPOMK) <=2 THEN P1.OPPOMK
ELSE SPLIT(P1.OPPOMK,'\|,')[8]   END AS TXN_EQUIP_MAC -- 交易设备MAC
    ,COALESCE(P1.CARDNO,P1.DCBTNO) AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.DCBTNO AS TXN_VOCH_NO -- 交易凭证号码
    ,CONCAT(P1.corpno,'000') AS BELONG_ORG_NO -- 归属机构编号
    ,CONCAT(P1.corpno,'000') AS STAT_ORG_NO -- 统计机构编号
    ,CONCAT(P1.corpno,'000') AS LP_ORG_NO -- 法人机构编号
    ,P1.REMARK AS REM -- 备注
    ,unifiedTime(SUBSTR(P1.timetm,1,8)) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.TIMETM) AS SETUP_TM_STAMP -- 建立时间戳
    ,T7.TOACCT AS TOACCT -- 关联字段
    ,T7.AMNTCD AS AMNTCD -- 关联字段
    ,T7.ACCTNO AS ACCTNO -- 关联字段
    ,T7.DTITCD AS DTITCD -- 关联字段
    ,T7.TRANMS AS TRANMS -- 关联字段
    ,P6.AGIDTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P6.AGIDNO AS AGENT_DOC_NO -- 代理人证件号码
    ,P6.AGNAME AS AGENT_NAME -- 代理人名称
    ,P6.AGTLNO AS AGENT_CONT_MODE -- 代理人联系方式
FROM
ODS_NAS${version_num}.ODS_NAS_KNL_BILL_TA AS P1 -- 账户余额发生明细

INNER JOIN ODS_NAS${version_num}.ODS_NAS_KNA_ACCS_TF AS P2 -- 负债账号客户账号对照表
       ON P1.ACCTNO = P2.ACCTNO AND P1.CORPNO=P2.CORPNO AND P2.FCFLAG = '0205'  AND P2.DEL_F='0' AND P2.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P3 -- 年度报表汇率文件
       ON P1.trancy=P3.YRCACCYC 
AND P3.YRCADATE = CAST(REPLACE('${process_date}','-','') AS DECIMAL(10,0))  --跑批日 
AND P3.YRCARS1B <> '9'
AND P3.DEL_F='0'
AND P3.PT_DT = '${process_date}' 
LEFT JOIN (
select  T1.card_bin_no  --卡bin号
       ,T1.bank_name --银行名称
       ,T1.card_length --卡长度
       ,T1.BANK_NO
from    ODS_UPPRUN${version_num}.ODS_UPPRUN_CARD_BIN_AND_BANKNO_RELATIONSHIP_TF T1 --超级（农信银）卡bin号表
where   T1.TUNNEL_ID='IBPS' AND T1.del_f='0'  AND   T1.PT_DT = '${process_date}'
group by T1.card_bin_no,T1.bank_name,T1.card_length,T1.BANK_NO
) AS P4 -- 超级（农信银）卡bin号表
       ON CAST(length(P1.opcuac) AS STRING) = P4.card_length
and    (substr(P1.opcuac,1,10) = P4.card_bin_no
     or substr(P1.opcuac,1,9) = P4.card_bin_no
     or substr(P1.opcuac,1,8) = P4.card_bin_no
     or substr(P1.opcuac,1,7) = P4.card_bin_no
     or substr(P1.opcuac,1,6) = P4.card_bin_no
     or substr(P1.opcuac,1,5) = P4.card_bin_no
     or substr(P1.opcuac,1,4) = P4.card_bin_no) 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BBFMORGA_TF AS P5 -- 机构信息表
       ON P1.TRANBR = P5.ORCABRNO AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
LEFT JOIN (SELECT * FROM(SELECT 
   AGIDTP
  ,AGIDNO
  ,AGNAME
  ,AGTLNO
  ,ACCTNO
  ,ACORNO
  ,ROW_NUMBER() OVER(PARTITION BY ACCTNO,ACORNO ORDER BY TIMETM DESC) AS RN
 FROM ODS_NAS${version_num}.ODS_NAS_KNB_DCMT_TF
WHERE  PT_DT = '${process_date}' AND DEL_F='0'
)WHERE RN=1) AS P6 -- 凭证登记簿
       ON P1.ACCTNO = P6.ACCTNO AND P1.ACSENO = P6.ACORNO 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P7 -- 年度报表汇率文件
       ON P3.PT_DT = P7.PT_DT
AND CAST(P7.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日
AND P7.YRCARS1B <> '9'
AND P7.YRCACCYC = 'USD' 
AND P7.DEL_F='0'
AND P7.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT
 TOACCT
,AMNTCD
,ACCTNO
,DTITCD
,TRANMS
,TRANSQ 
FROM ODS_NAS${version_num}.ODS_NAS_KNS_ACSQ_TF
WHERE ATOWTP='0'  AND DEL_F='0' AND PT_DT = '${process_date}'
GROUP BY  TRANSQ,AMNTCD,ACCTNO,TOACCT,DTITCD,TRANMS
) AS T7 -- 会计核算规则定义
       ON T7.TRANSQ=P1.TRANSQ AND T7.TOACCT=P1.OPCUAC AND T7.AMNTCD=P1.AMNTCD AND T7.ACCTNO=P1.ACCTNO 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P8 -- 代码转换
       ON P1.AMNTCD=P8.SRC_CD_VAL  
AND P8.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P8.SRC_TAB_EN_NAME='KNL_BILL' --来源表英文名  
AND P8.SRC_FIELD_EN_NAME='AMNTCD' --来源字段英文名 
AND P8.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA'  --目标表名   
AND P8.TARGET_FIELD_EN_NAME='TXN_DIR_CD' --目标字段 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2-2组）==============
-- 个人定期存款账户交易明细聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_04;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_04 (
     ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,ORIG_TXN_SER_NO STRING COMMENT '原交易流水号'
    ,SUB_TXN_SER_NO STRING COMMENT '子交易流水号'
    ,TXN_DT STRING COMMENT '交易日期'
    ,TXN_ACCT_NO STRING COMMENT '交易账户编号'
    ,TXN_TM_STAMP STRING COMMENT '交易时间戳'
    ,TELR_SER_NO STRING COMMENT '柜员流水号'
    ,FRONT_SER_NO STRING COMMENT '前置流水号'
    ,TXN_ACCT_NAME STRING COMMENT '交易账户名称'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,TXN_CASH_RMT_CD STRING COMMENT '交易钞汇代码'
    ,TRAN_CD STRING COMMENT '交易码'
    ,TXN_DIR_CD STRING COMMENT '交易方向代码'
    ,TXN_TYPE_CD STRING COMMENT '交易类型代码'
    ,CASH_TRAN_IDNT_CD STRING COMMENT '现转标识代码'
    ,TXN_AMT DECIMAL(28,2) COMMENT '交易金额'
    ,TXN_AMT_CONVT_RMB DECIMAL(28,2) COMMENT '交易金额折人民币'
    ,TXN_AMT_CONVT_USD DECIMAL(28,2) COMMENT '交易金额折美元'
    ,ACCT_BAL DECIMAL(28,2) COMMENT '账户余额'
    ,SUMMARY_CD STRING COMMENT '摘要代码'
    ,SUMMARY_DESC STRING COMMENT '摘要描述'
    ,CNTPTY_TXN_ACCT_NO STRING COMMENT '对方交易账户编号'
    ,CNTPTY_TXN_ACCT_NAME STRING COMMENT '对方交易账户名称'
    ,CNTPTY_BANK_NO STRING COMMENT '对方行号'
    ,CNTPTY_BANK_NAME STRING COMMENT '对方行名'
    ,TXN_HAPP_ORG_NO STRING COMMENT '交易发生机构编号'
    ,TXN_RGN_NO STRING COMMENT '交易地区编号'
    ,TXN_TELR_NO STRING COMMENT '交易柜员编号'
    ,TXN_CHNL_CD STRING COMMENT '交易渠道代码'
    ,TXN_EQUIP_IP STRING COMMENT '交易设备IP'
    ,TXN_EQUIP_MAC STRING COMMENT '交易设备MAC'
    ,TXN_VOCH_CATE_CD STRING COMMENT '交易凭证种类代码'
    ,TXN_VOCH_NO STRING COMMENT '交易凭证号码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,REM STRING COMMENT '备注'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,AGENT_DOCTYP_CD STRING COMMENT '代理人证件类型代码'
    ,AGENT_DOC_NO STRING COMMENT '代理人证件号码'
    ,AGENT_NAME STRING COMMENT '代理人名称'
    ,AGENT_CONT_MODE STRING COMMENT '代理人联系方式'
)
USING ORC
COMMENT '个人定期存款账户交易明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_04(
     ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
)
SELECT
     COALESCE(P3.SUBJECT_DR,P3.SUBJECT_CR) AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P4.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.ORIG_TXN_SER_NO AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.SUB_TXN_SER_NO AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.TXN_DT AS TXN_DT -- 交易日期
    ,P1.TXN_ACCT_NO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.TXN_TM_STAMP AS TXN_TM_STAMP -- 交易时间戳
    ,P1.TELR_SER_NO AS TELR_SER_NO -- 柜员流水号
    ,P1.FRONT_SER_NO AS FRONT_SER_NO -- 前置流水号
    ,P1.TXN_ACCT_NAME AS TXN_ACCT_NAME -- 交易账户名称
    ,P1.TXN_CURR_CD AS TXN_CURR_CD -- 交易币种代码
    ,P1.TXN_CASH_RMT_CD AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.TRAN_CD AS TRAN_CD -- 交易码
    ,P1.TXN_DIR_CD AS TXN_DIR_CD -- 交易方向代码
    ,P1.TXN_TYPE_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.CASH_TRAN_IDNT_CD AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,P1.TXN_AMT_CONVT_RMB AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,P1.TXN_AMT_CONVT_USD AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.ACCT_BAL AS ACCT_BAL -- 账户余额
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SUMMARY_DESC AS SUMMARY_DESC -- 摘要描述
    ,P1.CNTPTY_TXN_ACCT_NO AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P1.CNTPTY_TXN_ACCT_NAME AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,P1.CNTPTY_BANK_NO AS CNTPTY_BANK_NO -- 对方行号
    ,P1.CNTPTY_BANK_NAME AS CNTPTY_BANK_NAME -- 对方行名
    ,P1.TXN_HAPP_ORG_NO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P1.TXN_RGN_NO AS TXN_RGN_NO -- 交易地区编号
    ,P1.TXN_TELR_NO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TXN_CHNL_CD AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.TXN_EQUIP_IP AS TXN_EQUIP_IP -- 交易设备IP
    ,P1.TXN_EQUIP_MAC AS TXN_EQUIP_MAC -- 交易设备MAC
    ,P1.TXN_VOCH_CATE_CD AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.TXN_VOCH_NO AS TXN_VOCH_NO -- 交易凭证号码
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.STAT_ORG_NO AS STAT_ORG_NO -- 统计机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,P1.REM AS REM -- 备注
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.AGENT_DOCTYP_CD AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P1.AGENT_DOC_NO AS AGENT_DOC_NO -- 代理人证件号码
    ,P1.AGENT_NAME AS AGENT_NAME -- 代理人名称
    ,P1.AGENT_CONT_MODE AS AGENT_CONT_MODE -- 代理人联系方式
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_03 AS P1 -- 临时表3

LEFT JOIN (
SELECT 
   B.DTITCD
  ,B.TRANSQ
  ,B.AMNTCD
  ,B.ACCTNO
  ,B.TOACCT
  ,B.TRANMS
  ,B.ATOWTP
  ,ROW_NUMBER() over(partition by B.DTITCD,B.TRANMS  order by B.DTITCD,B.TRANMS) as RN
FROM ODS_NAS${version_num}.ODS_NAS_KNS_ACSQ_TF  B
LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_EA_RULES_TF C
ON B.DTITCD = C.PRODUCT AND C.EVENT_TYPE = B.TRANMS AND C.DEL_F='0' AND C.PT_DT = '${process_date}'
WHERE B.DEL_F='0' AND B.PT_DT = '${process_date}'
) AS P2 -- 会计流水表
       ON P1.ORIG_TXN_SER_NO = P2.TRANSQ
AND P1.TXN_DIR_CD = P2.AMNTCD
AND P1.TXN_ACCT_NO = P2.ACCTNO
AND P1.CNTPTY_TXN_ACCT_NO = P2.TOACCT
AND P2.ATOWTP = '0' AND RN=1
 
LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_EA_RULES_TF AS P3 -- 会计核算规则定义
       ON P1.DTITCD=P3.PRODUCT AND P3.EVENT_TYPE=P1.TRANMS AND P3.DEL_F='0' AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_FLEX_VALUES_V_TF AS P4 -- COA段值视图
       ON COALESCE(P3.SUBJECT_DR,P3.SUBJECT_CR) = P4.flex_value AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
;
-- ==============聚合层字段映射（第2-3组）==============
-- 个人定期存款账户交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM(
     OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,INITR_SYS_CD -- 发起方系统代码
    ,SUB_TRAN_CD -- 子交易码
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,T2.CUSTID AS USER_ID -- 用户ID
    ,CASE WHEN TRIM(P3.CUST_INNER_ID)<>'' THEN TRIM(P3.CUST_INNER_ID) ELSE T2.CUSTCD END AS CUST_IN_CD -- 客户内码
    ,P2.ACCTNA AS CUST_NAME -- 客户名称
    ,P5.INCTRY AS NATION_CD -- 国籍代码
    ,P6.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,P6.CRTF_NO AS DOC_NO -- 证件号码
    ,CASE WHEN P2.ACSETP IS NULL OR TRIM(P2.ACSETP)=''
     THEN ''
     ELSE COALESCE(TRIM(P7.TARGET_CD_VAL), CONCAT('@',TRIM(P2.ACSETP)),'')
END AS ACCT_TYPE_CD -- 账户类型代码
    ,'0012' AS ACCT_PROPTY_CD -- 账户性质代码
    ,'' AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,P2.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,P4.prodtx AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.ACCTN_SUBJ_NO AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.ACCTN_SUBJ_NAME AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.ORIG_TXN_SER_NO AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.SUB_TXN_SER_NO AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.TXN_DT AS TXN_DT -- 交易日期
    ,P1.TXN_ACCT_NO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.TXN_TM_STAMP AS TXN_TM_STAMP -- 交易时间戳
    ,P1.TELR_SER_NO AS TELR_SER_NO -- 柜员流水号
    ,P1.FRONT_SER_NO AS FRONT_SER_NO -- 前置流水号
    ,P1.TXN_ACCT_NAME AS TXN_ACCT_NAME -- 交易账户名称
    ,P1.TXN_CURR_CD AS TXN_CURR_CD -- 交易币种代码
    ,P1.TXN_CASH_RMT_CD AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.TRAN_CD AS TRAN_CD -- 交易码
    ,P1.TXN_DIR_CD AS TXN_DIR_CD -- 交易方向代码
    ,P1.TXN_TYPE_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.CASH_TRAN_IDNT_CD AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,P1.TXN_AMT_CONVT_RMB AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,P1.TXN_AMT_CONVT_USD AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.ACCT_BAL AS ACCT_BAL -- 账户余额
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SUMMARY_DESC AS SUMMARY_DESC -- 摘要描述
    ,P1.CNTPTY_TXN_ACCT_NO AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P1.CNTPTY_TXN_ACCT_NAME AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,P1.CNTPTY_BANK_NO AS CNTPTY_BANK_NO -- 对方行号
    ,P1.CNTPTY_BANK_NAME AS CNTPTY_BANK_NAME -- 对方行名
    ,P1.TXN_HAPP_ORG_NO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P1.TXN_RGN_NO AS TXN_RGN_NO -- 交易地区编号
    ,P1.TXN_TELR_NO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TXN_CHNL_CD AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.TXN_EQUIP_IP AS TXN_EQUIP_IP -- 交易设备IP
    ,P1.TXN_EQUIP_MAC AS TXN_EQUIP_MAC -- 交易设备MAC
    ,P1.TXN_VOCH_CATE_CD AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.TXN_VOCH_NO AS TXN_VOCH_NO -- 交易凭证号码
    ,P1.AGENT_DOCTYP_CD AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P1.AGENT_DOC_NO AS AGENT_DOC_NO -- 代理人证件号码
    ,P1.AGENT_NAME AS AGENT_NAME -- 代理人名称
    ,P1.AGENT_CONT_MODE AS AGENT_CONT_MODE -- 代理人联系方式
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.STAT_ORG_NO AS STAT_ORG_NO -- 统计机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,P1.REM AS REM -- 备注
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS INITR_SYS_CD -- 发起方系统代码
    ,'' AS SUB_TRAN_CD -- 子交易码
    ,'' AS DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,'' AS AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,'' AS DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'' AS FINAL_MODIF_DT -- 最后修改日期
    ,'' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNL_BILL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_04 AS P1 -- 临时表4

LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_FXAC_TF AS P2 -- 负债活期帐户信息表
       ON P1.TXN_ACCT_NO= P2.ACCTNO AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
LEFT JOIN (SELECT * FROM(
 SELECT  
    CUSTNO
   ,CUSTID
   ,CUSTCD
   ,ROW_NUMBER() OVER (PARTITION BY CUSTNO ORDER BY STATUS  )AS RN
 FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF
 WHERE DEL_F='0' AND PT_DT='${process_date}'
 ) A WHERE RN=1) AS T2 -- 客户信息关联表
       ON P2.CUSTNO=T2.CUSTNO 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF AS P3 -- None
       ON P3.USER_ID=T2.CUSTID AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KUP_DPPB_TF AS P4 -- NAS产品表
       ON P2.prodcd = P4.prodcd AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_ICF${version_num}.ODS_ICF_SCMS_CUST_TF AS P5 -- 客户基础信息表
       ON P5.CUSTID= T2.CUSTID AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
LEFT JOIN (
SELECT
   CST_IN_CD
  ,CRTF_NO
  ,CRTF_TYP
FROM(
   SELECT 
      CST_IN_CD
     ,CRTF_NO
     ,CRTF_TYP
     ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) AS RN
   FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF
   WHERE MAJOR_FLG = '1' AND DELETED='0' AND PT_DT = '${process_date}'  AND DEL_F='0'
   )
WHERE RN=1
) AS P6 -- 客户证件信息表
       ON T2.CUSTCD = P6.CST_IN_CD 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P7 -- 代码转换
       ON P2.ACSETP=P7.SRC_CD_VAL  
AND P7.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P7.SRC_TAB_EN_NAME='KNA_FXAC' --来源表英文名  
AND P7.SRC_FIELD_EN_NAME='ACSETP' --来源字段英文名 
AND P7.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA'  --目标表名   
AND P7.TARGET_FIELD_EN_NAME='ACCT_TYPE_CD' --目标字段 
;
-- ==============聚合层字段映射（第3组）==============
-- 个人定期存款账户交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CAST(P1.AO03TXSN AS STRING) AS ORIG_TXN_SER_NO -- 原交易流水号
    ,CAST(P1.AO04TSSN AS STRING) AS SUB_TXN_SER_NO -- 子交易流水号
    ,unifiedTime(CAST(P1.AO02DATE AS STRING)) AS TXN_DT -- 交易日期
    ,P1.AO01AC15 AS TXN_ACCT_NO -- 交易账户编号
    ,unifiedTime(P1.AO17STAM) AS TXN_TM_STAMP -- 交易时间戳
    ,CAST(P2.TEL_JNO AS STRING) AS TELR_SER_NO -- 柜员流水号
    ,CAST(P2.SRV_JNO AS STRING) AS FRONT_SER_NO -- 前置流水号
    ,P2.OACC_NO AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,P3.AA04FLNM AS TXN_ACCT_NAME -- 交易账户名称
    ,COALESCE(P4.USER_ID,T4.CUSTID) AS USER_ID -- 用户ID
    ,P3.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P5.CUST_NM AS CUST_NAME -- 客户名称
    ,P5.NTNLT AS NATION_CD -- 国籍代码
    ,P6.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,P6.CRTF_NO AS DOC_NO -- 证件号码
    ,P7.AB06ACFG AS ACCT_TYPE_CD -- 账户类型代码
    ,'2104' AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.AO10JZFS AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,P1.AO07CCYC AS TXN_CURR_CD -- 交易币种代码
    ,P1.AO08CHSX AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P2.SYS_TXID AS TRAN_CD -- 交易码
    ,P1.AO13CDFG AS TXN_DIR_CD -- 交易方向代码
    ,P1.AO26JYLX AS TXN_TYPE_CD -- 交易类型代码
    ,P2.CSTR_IND AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.AO11AMT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.AO07CCYC = 'CNY' THEN P1.AO11AMT ELSE  P1.AO11AMT*COALESCE(P8.YRCAEXRT,0)/COALESCE(P8.YRCACUNO,1) END AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,(CASE WHEN P1.AO07CCYC <> 'CNY' THEN P1.AO11AMT*P8.YRCAEXRT/P8.YRCACUNO ELSE P1.AO11AMT END)/P15.YRCAEXRT*P15.YRCACUNO AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.AO12BAL AS ACCT_BAL -- 账户余额
    ,P1.AO22NTCD AS SUMMARY_CD -- 摘要代码
    ,P2.ABS_DSC AS SUMMARY_DESC -- 摘要描述
    ,P9.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P9.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,CONCAT(P7.AB10PDTP,P7.AB11PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,P10.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,P11.ET05AC32 AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P11.ET06FLNM AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,P11.ET07BK20 AS CNTPTY_BANK_NO -- 对方行号
    ,P12.ORCAFLNM AS CNTPTY_BANK_NAME -- 对方行名
    ,P1.AO20BRNO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P2.TX_DIS AS TXN_RGN_NO -- 交易地区编号
    ,P1.AO19STAF AS TXN_TELR_NO -- 交易柜员编号
    ,P2.SRS_ID AS INITR_SYS_CD -- 发起方系统代码
    ,P1.AO18CNCD AS TXN_CHNL_CD -- 交易渠道代码
    ,P2.ATX_ID AS SUB_TRAN_CD -- 子交易码
    ,P13.KF06IPAD AS TXN_EQUIP_IP -- 交易设备IP
    ,P13.KF07MAC AS TXN_EQUIP_MAC -- 交易设备MAC
    ,'' AS DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,CASE WHEN P1.AO14OPTP IS NULL OR TRIM(P1.AO14OPTP)=''
     THEN ''
     ELSE COALESCE(TRIM(P16.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AO14OPTP)),'')
END AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,CAST(P1.AO15BLNO AS STRING) AS TXN_VOCH_NO -- 交易凭证号码
    ,P14.HA07CFTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P14.HA08CFNO AS AGENT_DOC_NO -- 代理人证件号码
    ,P14.HA09FLNM AS AGENT_NAME -- 代理人名称
    ,P14.HA10TELN AS AGENT_CONT_MODE -- 代理人联系方式
    ,P3.AA40BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P3.AA42BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P3.AA43BRNO AS LP_ORG_NO -- 法人机构编号
    ,'' AS AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,'' AS DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,P2.JRN_MARK AS REM -- 备注
    ,unifiedTime(CAST(P2.CRT_DTE AS STRING)) AS SETUP_DT -- 建立日期
    ,unifiedTime(P2.CRE_TS) AS SETUP_TM_STAMP -- 建立时间戳
    ,P2.CRE_UID AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(CAST(P2.UPD_DTE AS STRING)) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P2.UPD_TS) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P2.UPD_UID AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAO_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE${version_num}.ODS_CORE_BDFMHQAO_TA AS P1 -- 保证金交易明细表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BYFTJRN_TA AS P2 -- 会计流水文件
       ON CAST(P1.AO17STAM AS STRING) = CAST(P2.TX_DATE AS STRING)  
AND P1.AO03TXSN =P2.BTX_JNO
AND P1.AO04TSSN =P2.ATX_JNO
AND P1.AO01AC15 =P2.ACC_NO
AND P2.DEL_F='0'
AND P2.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAA_TF AS P3 -- 定期存款账户控制文件
       ON P1.AO01AC15 = P3.AA01AC15 AND P3.PT_DT = '${process_date}'  AND P3.DEL_F='0' 
LEFT JOIN (
SELECT 
   USER_ID
  ,CST_IN_CD
FROM(
  SELECT 
     USER_ID
    ,CST_IN_CD
    ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY USER_ID DESC) RN 
  FROM ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF 
  WHERE  PT_DT = '${process_date}'  AND DEL_F='0' AND DELETED='0'
GROUP BY CST_IN_CD,USER_ID
  )
WHERE RN=1
) AS P4 -- 用户信息表
       ON P3.AA03CSNO = P4.CST_IN_CD 
LEFT JOIN (SELECT * FROM(
    SELECT
      U4.CUSTID
     ,U4.CUSTCD 
     ,ROW_NUMBER() OVER(PARTITION BY U4.CUSTCD ORDER BY U4.STATUS ) RN
    FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF  U4
    WHERE U4.PT_DT = '${process_date}'  AND DEL_F = '0'
)D4 WHERE D4.RN = 1) AS T4 -- 客户信息关联表
       ON P3.AA03CSNO =T4.CUSTCD 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF AS P5 -- 客户基础信息表
       ON P3.AA03CSNO = P5.CST_IN_CD AND P5.PT_DT = '${process_date}'  AND P5.DEL_F='0' 
LEFT JOIN (
SELECT
   CST_IN_CD
  ,CRTF_NO
  ,CRTF_TYP
FROM(
   SELECT 
      CST_IN_CD
     ,CRTF_NO
     ,CRTF_TYP
     ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) AS RN
   FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF
   WHERE MAJOR_FLG = '1' AND DELETED='0' AND PT_DT = '${process_date}'  AND DEL_F='0'
   )
WHERE RN=1
) AS P6 -- 客户证件信息表
       ON P3.AA03CSNO = P6.CST_IN_CD 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAB_TF AS P7 -- 定期模块账户分户余额信息
       ON P1.AO01AC15 = P7.AB01AC15 AND P7.AB03CCYC=P1.AO07CCYC AND  P7.AB05CHSX=P1.AO08CHSX AND P7.PT_DT = '${process_date}' AND P7.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P8 -- 年度报表汇率文件
       ON P1.AO07CCYC=P8.YRCACCYC 
AND CAST(P8.YRCADATE AS STRING) = REPLACE('${process_date}','_','')  --跑批日
AND P8.YRCARS1B <> '9'
AND P8.DEL_F='0'
AND P8.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS P9 -- 新会计科目核算码对照表
       ON P2.GLAC_NO = P9.KHDBACID AND P9.PT_DT = '${process_date}'  AND P9.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQCW_TF AS P10 -- 产品代码名称表
       ON P7.AB11PRON = P10.CW05FLNM AND P7.AB10PDTP = P10.CW02PDTP AND P10.PT_DT = '${process_date}'  AND P10.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQET_TA AS P11 -- 活期存款当日账户交易明细补充信息表
       ON P1.AO01AC15 = P11.ET01AC15
AND P1.AO02DATE = P11.ET02DATE
AND P1.AO03TXSN = P11.ET03TXSN
AND P1.AO04TSSN = P11.ET04TSSN 
AND P11.DEL_F='0'
AND P11.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BBFMORGA_TF AS P12 -- 机构信息表
       ON P11.ET07BK20=P12.ORCABRNO AND P12.PT_DT = '${process_date}' AND P12.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQKF_TA AS P13 -- 活期存款互联网交易登记簿（当日）
       ON P1.AO01AC15 = P13.KF01AC15
AND P1.AO02DATE = P13.KF02DATE
AND P1.AO03TXSN = P13.KF03TXSN
AND P1.AO04TSSN = P13.KF04TSSN 
AND P13.DEL_F='0'
AND P13.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQHA_TA AS P14 -- 会计流水补充文件
       ON P1.AO02DATE = CAST(REPLACE(CAST(P14.HA17DTE AS STRING),'-','') AS DECIMAL(10,0))
AND P1.AO03TXSN = P14.HA01TXSN
AND P1.AO04TSSN = P14.HA04TSSN
AND P14.DEL_F='0'
AND P14.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P15 -- 年度报表汇率文件
       ON P8.PT_DT = P15.PT_DT
AND CAST(P15.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日
AND P15.YRCARS1B <> '9'
AND P15.YRCACCYC = 'USD' 
AND P15.DEL_F='0'
AND P15.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P16 -- 代码转换
       ON P1.AO14OPTP=P16.SRC_CD_VAL  
AND P16.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND P16.SRC_TAB_EN_NAME='BDFMHQAO' --来源表英文名  
AND P16.SRC_FIELD_EN_NAME='AO14OPTP' --来源字段英文名 
AND P16.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA'  --目标表名   
AND P16.TARGET_FIELD_EN_NAME='TXN_VOCH_CATE_CD' --目标字段 
WHERE SUBSTR(P1.AO01AC15,1,1) = '1'   AND P1.RCSTRS1B <> '9'  AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,DPSIT_IN_DRAW_TMS -- 存入支取期数
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,AGENT_BANK_BNKOUTLS_NO -- 代理行网点编号
    ,DLGT_BANK_BNKOUTLS_NO -- 委托行网点编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_TM;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_01;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_02;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_03;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_TXN_DTL_TA_04;
