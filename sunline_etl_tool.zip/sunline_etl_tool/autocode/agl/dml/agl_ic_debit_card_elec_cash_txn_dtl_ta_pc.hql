-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-IC借记卡电子现金交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA
--     表中文名：IC借记卡电子现金交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：TXN_ACCTN_DT, CORE_ORIG_TXN_SER_NO, CORE_SUB_TXN_SER_NO, DEBIT_CARD_NO, ELEC_CASH_ACCT_TYPE_CD
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-29 00:00:00 魏丹丹 新增
--         2024-09-09 00:00:00 魏丹丹 改表名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA_TM
USING ORC
COMMENT 'IC借记卡电子现金交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_ACCTN_DT -- 交易记账日期
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,DEBIT_CARD_NO -- 借记卡编号
    ,ELEC_CASH_ACCT_TYPE_CD -- 电子现金账户类型代码
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CARD_PROD_CD -- 卡产品代码
    ,ELEC_CASH_ACCT_OPER_TYPE_CD -- 电子现金账户操作类型代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,CURR_CD -- 币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ORIG_TRAN_CD -- 原交易码
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_ORG_NO -- 交易机构编号
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,SUMMARY_CD -- 摘要代码
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- IC借记卡电子现金交易明细聚合

INSERT INTO TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA_TM(
     TXN_ACCTN_DT -- 交易记账日期
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,DEBIT_CARD_NO -- 借记卡编号
    ,ELEC_CASH_ACCT_TYPE_CD -- 电子现金账户类型代码
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CARD_PROD_CD -- 卡产品代码
    ,ELEC_CASH_ACCT_OPER_TYPE_CD -- 电子现金账户操作类型代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,CURR_CD -- 币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ORIG_TRAN_CD -- 原交易码
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_ORG_NO -- 交易机构编号
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,SUMMARY_CD -- 摘要代码
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.DL02DATE) AS TXN_ACCTN_DT -- 交易记账日期
    ,P1.DL03TXSN AS CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,P1.DL04TSSN AS CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,P1.DL01AC19 AS DEBIT_CARD_NO -- 借记卡编号
    ,CASE WHEN P1.DL07ACFG IS NULL OR TRIM(P1.DL07ACFG)=''
     THEN ''
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DL07ACFG)),'')
END AS ELEC_CASH_ACCT_TYPE_CD -- 电子现金账户类型代码
    ,P1.DL05SN11 AS TELR_SER_NO -- 柜员流水号
    ,P1.DL06NO12 AS FRONT_SER_NO -- 前置流水号
    ,P1.DL13PDTP||P1.DL14PRON AS CARD_PROD_CD -- 卡产品代码
    ,P1.DL08TYPE AS ELEC_CASH_ACCT_OPER_TYPE_CD -- 电子现金账户操作类型代码
    ,P1.DL09INVT AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.DL12AC19 AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,P1.DL20CCYC AS CURR_CD -- 币种代码
    ,CASE WHEN P1.DL21CDFG IS NULL OR TRIM(P1.DL21CDFG)=''
     THEN ''
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DL21CDFG)),'')
END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.DL22AMT AS TXN_AMT -- 交易金额
    ,P1.DL23AMT AS ACCT_BAL -- 账户余额
    ,unifiedTime(CASE WHEN LENGTH(P1.DL10DATE)=6 THEN SUBSTR(P1.DL11STAM,1,2)|| P1.DL10DATE ELSE P1.DL10DATE END) AS TXN_DT -- 交易日期
    ,P1.DL11STAM AS TXN_TM_STAMP -- 交易时间戳
    ,CASE WHEN P1.DL24RDST IS NULL OR TRIM(P1.DL24RDST)=''
     THEN ''
     ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DL24RDST)),'')
END AS POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,P1.DL25TXCD AS ORIG_TRAN_CD -- 原交易码
    ,P1.DL26STAF AS TXN_TELR_NO -- 交易柜员编号
    ,P1.DL15BRNO AS TXN_ORG_NO -- 交易机构编号
    ,P1.DL16BRNO AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,P1.DL17BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.DL18BRNO AS LP_ORG_NO -- 法人机构编号
    ,P1.DL19BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.DL27NTCD AS SUMMARY_CD -- 摘要代码
    ,P1.DL28NO80 AS REM -- 备注
    ,CASE WHEN P1.DL29RS1B IS NULL OR TRIM(P1.DL29RS1B)=''
     THEN '0'
     ELSE COALESCE(TRIM(S4.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DL29RS1B)),'')
END AS REC_STATUS_CD -- 记录状态代码
    ,unifiedTime(P1.DL30DATE) AS SETUP_DT -- 建立日期
    ,P1.DL31STAM AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.DL32STAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.DL33DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.DL34STAM AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.DL35STAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BWFMECDL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE.ODS_CORE_BWFMECDL_TA AS P1 -- 电子现金账户明细表

LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON P1.DL07ACFG=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND S1.SRC_TAB_EN_NAME='BWFMECDL' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='DL07ACFG' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='ELEC_CASH_ACCT_TYPE_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 代码转换
       ON P1.DL21CDFG=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND S2.SRC_TAB_EN_NAME='BWFMECDL' --来源表英文名  
AND S2.SRC_FIELD_EN_NAME='DL21CDFG' --来源字段英文名 
AND S2.TARGET_TAB_EN_NAME='AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA'  --目标表名   
AND S2.TARGET_FIELD_EN_NAME='DEBIT_CRDT_DIR_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S3 -- 代码转换
       ON P1.DL24RDST=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND S3.SRC_TAB_EN_NAME='BWFMECDL' --来源表英文名  
AND S3.SRC_FIELD_EN_NAME='DL24RDST' --来源字段英文名 
AND S3.TARGET_TAB_EN_NAME='AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA'  --目标表名   
AND S3.TARGET_FIELD_EN_NAME='POSITIVE_REV_TRAN_CATE_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S4 -- 代码转换
       ON P1.DL29RS1B=S4.SRC_CD_VAL  
AND S4.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND S4.SRC_TAB_EN_NAME='BWFMECDL' --来源表英文名  
AND S4.SRC_FIELD_EN_NAME='DL29RS1B' --来源字段英文名 
AND S4.TARGET_TAB_EN_NAME='AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA'  --目标表名   
AND S4.TARGET_FIELD_EN_NAME='REC_STATUS_CD' --目标字段 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_ACCTN_DT -- 交易记账日期
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,DEBIT_CARD_NO -- 借记卡编号
    ,ELEC_CASH_ACCT_TYPE_CD -- 电子现金账户类型代码
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CARD_PROD_CD -- 卡产品代码
    ,ELEC_CASH_ACCT_OPER_TYPE_CD -- 电子现金账户操作类型代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,CURR_CD -- 币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ORIG_TRAN_CD -- 原交易码
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_ORG_NO -- 交易机构编号
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,SUMMARY_CD -- 摘要代码
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_IC_DEBIT_CARD_ELEC_CASH_TXN_DTL_TA_TM;
