-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-医疗云用户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MDCL_CLOUD_USER_INFO_TF
--     表中文名：医疗云用户信息聚合
--     创建日期：2024-08-14 00:00:00
--     主键字段：MDCL_CLD_USER_ID
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：叶禹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-14 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_MDCL_CLOUD_USER_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF_TM
USING ORC
COMMENT '医疗云用户信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     MDCL_CLD_USER_ID -- 医疗云用户ID
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,GENDER_CD -- 性别代码
    ,CONT_NO_NO -- 联系电话号码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_EFFECT_DT -- 证件有效日期
    ,DOC_MATU_DT -- 证件到期日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_MDCL_CLOUD_USER_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 医疗云用户信息聚合

INSERT INTO TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF_TM(
     MDCL_CLD_USER_ID -- 医疗云用户ID
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,GENDER_CD -- 性别代码
    ,CONT_NO_NO -- 联系电话号码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_EFFECT_DT -- 证件有效日期
    ,DOC_MATU_DT -- 证件到期日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.us_id AS MDCL_CLD_USER_ID -- 医疗云用户ID
    ,P1.user_id AS USER_ID -- 用户ID
    ,P2.CUSTCD AS CUST_IN_CD -- 客户内码
    ,P3.pat_name AS CUST_NAME -- 客户名称
    ,P3.sex AS GENDER_CD -- 性别代码
    ,P3.phone_no AS CONT_NO_NO -- 联系电话号码
    ,P3.id_card_type AS DOCTYP_CD -- 证件类型代码
    ,P3.id_card_no AS DOC_NO -- 证件号码
    ,unifiedTime(P3.id_card_start_date) AS DOC_EFFECT_DT -- 证件有效日期
    ,unifiedTime(P3.id_card_end_date) AS DOC_MATU_DT -- 证件到期日期
    ,unifiedTime(P3.create_time) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(P3.update_time) AS MODIF_TM_STAMP -- 修改时间戳
    ,'MHP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MHP_USER_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MHP.ODS_MHP_USER_TF AS P1 -- 用户表

LEFT JOIN ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF AS P2 -- 客户信息关联表
       ON P1.USER_ID = P2.CUSTID
      AND P2.DEL_F = '0'
      AND P2.PT_DT = '${PROCESS_DATE}' 
LEFT JOIN ODS_MHP.ODS_MHP_PATIENT_USER_TF AS P3 -- 患者信息表
       ON P1.US_ID =P3.US_ID
      AND P3.RELATION='0'
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${PROCESS_DATE}' 
WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_MDCL_CLOUD_USER_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDCL_CLD_USER_ID IS NULL THEN NULL ELSE COALESCE(TM.MDCL_CLD_USER_ID, BF.MDCL_CLD_USER_ID) END AS MDCL_CLD_USER_ID -- 医疗云用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GENDER_CD IS NULL THEN NULL ELSE COALESCE(TM.GENDER_CD, BF.GENDER_CD) END AS GENDER_CD -- 性别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_NO_NO, BF.CONT_NO_NO) END AS CONT_NO_NO -- 联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DOCTYP_CD, BF.DOCTYP_CD) END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.DOC_NO, BF.DOC_NO) END AS DOC_NO -- 证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_EFFECT_DT IS NULL THEN NULL ELSE COALESCE(TM.DOC_EFFECT_DT, BF.DOC_EFFECT_DT) END AS DOC_EFFECT_DT -- 证件有效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_MATU_DT IS NULL THEN NULL ELSE COALESCE(TM.DOC_MATU_DT, BF.DOC_MATU_DT) END AS DOC_MATU_DT -- 证件到期日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CREATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.CREATE_TM_STAMP, BF.CREATE_TM_STAMP) END AS CREATE_TM_STAMP -- 创建时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.MODIF_TM_STAMP, BF.MODIF_TM_STAMP) END AS MODIF_TM_STAMP -- 修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.GENDER_CD,'') = COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段相等
         AND COALESCE(TM.CONT_NO_NO,'') = COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.DOC_EFFECT_DT,'') = COALESCE(BF.DOC_EFFECT_DT,'') -- 证件有效日期 非主键字段相等
         AND COALESCE(TM.DOC_MATU_DT,'') = COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段相等
         AND COALESCE(TM.CREATE_TM_STAMP,'') = COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段相等
         AND COALESCE(TM.MODIF_TM_STAMP,'') = COALESCE(BF.MODIF_TM_STAMP,'') -- 修改时间戳 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.GENDER_CD,'') <> COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段不相等
         OR COALESCE(TM.CONT_NO_NO,'') <> COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.DOC_EFFECT_DT,'') <> COALESCE(BF.DOC_EFFECT_DT,'') -- 证件有效日期 非主键字段不相等
         OR COALESCE(TM.DOC_MATU_DT,'') <> COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段不相等
         OR COALESCE(TM.CREATE_TM_STAMP,'') <> COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段不相等
         OR COALESCE(TM.MODIF_TM_STAMP,'') <> COALESCE(BF.MODIF_TM_STAMP,'') -- 修改时间戳 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.GENDER_CD,'') = COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段相等
         AND COALESCE(TM.CONT_NO_NO,'') = COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.DOC_EFFECT_DT,'') = COALESCE(BF.DOC_EFFECT_DT,'') -- 证件有效日期 非主键字段相等
         AND COALESCE(TM.DOC_MATU_DT,'') = COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段相等
         AND COALESCE(TM.CREATE_TM_STAMP,'') = COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段相等
         AND COALESCE(TM.MODIF_TM_STAMP,'') = COALESCE(BF.MODIF_TM_STAMP,'') -- 修改时间戳 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.GENDER_CD,'') <> COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段不相等
         OR COALESCE(TM.CONT_NO_NO,'') <> COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.DOC_EFFECT_DT,'') <> COALESCE(BF.DOC_EFFECT_DT,'') -- 证件有效日期 非主键字段不相等
         OR COALESCE(TM.DOC_MATU_DT,'') <> COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段不相等
         OR COALESCE(TM.CREATE_TM_STAMP,'') <> COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段不相等
         OR COALESCE(TM.MODIF_TM_STAMP,'') <> COALESCE(BF.MODIF_TM_STAMP,'') -- 修改时间戳 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_MDCL_CLOUD_USER_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_MDCL_CLOUD_USER_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.MDCL_CLD_USER_ID,'') = COALESCE(BF.MDCL_CLD_USER_ID,'') -- 医疗云用户ID 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_MDCL_CLOUD_USER_INFO_TF_TM;
