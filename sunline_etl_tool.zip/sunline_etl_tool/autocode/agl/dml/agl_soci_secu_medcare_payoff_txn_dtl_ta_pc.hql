-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-医保社保代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA
--     表中文名：医保社保代发交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：TXN_SER_NO, TXN_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-11-15 00:00:00 魏丹丹 重写



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM
USING ORC
COMMENT '医保社保代发交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.SUB_BKCODE AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.USER_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.USER_ID_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.USER_ID_NO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_ZJSB_BAT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_ZJSB_BAT_DETAIL_TA AS P1 -- 浙江社保批量明细表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS FUND_COL_ACCT_NO -- 收款账户编号
    ,'' AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,'' AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_HZSB_BATDET_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_HZSB_BATDET_TA AS P1 -- 浙江社保批量明细表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,'' AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS FUND_COL_ACCT_NO -- 收款账户编号
    ,'' AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,'' AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_WXSB_BATDET_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_WXSB_BATDET_TA AS P1 -- 吴兴社保批量明细表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第4组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.SUB_BKCODE AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.USER_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.USER_ID_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.USER_ID_NO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_JHSB_BAT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_JHSB_BAT_DETAIL_TA AS P1 -- 金华社保批量代发明细

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第5组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.SUB_BKCODE AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.USER_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.USER_ID_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.USER_ID_NO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_XCSB_BAT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_XCSB_BAT_DETAIL_TA AS P1 -- 新昌养老金代发批量明细表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第6组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.SUB_BKCODE AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.USER_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.USER_ID_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.USER_ID_NO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_BAT_DET_TZLHSB_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_BAT_DET_TZLHSB_TA AS P1 -- 台州联合社保的批量代发表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第7组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'MID71' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MID71_T_XSSB_BATDET_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,7 AS GRP_SER_NO -- 组序号
FROM
ODS_MID71${version_num}.ODS_MID71_T_XSSB_BATDET_TA AS P1 -- 萧山社保批量代发明细表

WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第8组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,'' AS PLAT_BATCH_NO -- 平台批次编号
    ,'' AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'2' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'2' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.DC_FLAG AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CHN_TYPE AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,'' AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,'' AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,'' AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.ACT_NO2 AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.ACT_NAME2 AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.ACT_BANK2 AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.ACT_NO1 AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.ACT_NAME1 AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.ACT_BANK1 AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,P1.CUST_NO AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.CUST_TYPE AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.SICARDNO AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.CUST_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.CERT_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.CERT_ID AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,P1.CUST_NATION AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,P1.CUST_ADDR AS STL_PLAT_SER_NO -- 结算平台流水号
    ,P1.CUST_MOBILE AS MOBILE_NO -- 手机号码
    ,P1.CUST_TELE AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.ADDWORD AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_JRNL_JS_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,8 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_JRNL_JS_JRNL_TA AS P1 -- 社保代发系统

WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第9组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,'' AS PLAT_BATCH_NO -- 平台批次编号
    ,'' AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'1' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'1' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'2' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.DC_FLAG AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,'' AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,'' AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,'' AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.ACT_NO2 AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.ACT_NAME2 AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.ACT_BANK2 AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.ACT_NO1 AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.ACT_NAME1 AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.ACT_BANK1 AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,P1.CUST_NO AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.CUST_TYPE AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.SICARDNO AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.CUST_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.CERT_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.CERT_ID AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,P1.CUST_NATION AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,P1.CUST_ADDR AS STL_PLAT_SER_NO -- 结算平台流水号
    ,P1.CUST_MOBILE AS MOBILE_NO -- 手机号码
    ,P1.CUST_TELE AS CONT_NO_NO -- 联系电话号码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,'' AS POSTSC_DESC -- 附言描述
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_JRNL_ZJSB_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,9 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_JRNL_ZJSB_TA AS P1 -- 浙江单笔缴费流水表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第10组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.BANK_SEQ AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'2' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,P1.BANKTYPE AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ORGNAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.BAT_TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,P1.DET_STAT AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,P1.CUST_ACCT_NO1 AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,P1.SET_ACCT_NO1 AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.PAY_BANKCODE AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,P1.PAY_OPEN_BRCH AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.BANK_NO AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.PAYEE_BANKCODE AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.OBJ_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.CERT_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.CERTNO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,P1.DONE_TIME AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,'' AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,'' AS STL_PLAT_SER_NO -- 结算平台流水号
    ,'' AS MOBILE_NO -- 手机号码
    ,P1.TEL AS CONT_NO_NO -- 联系电话号码
    ,P1.SUMMARY_1 AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_ZJYB_BATDET_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,10 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_ZJYB_BATDET_TA AS P1 -- 浙江社保批量明细表

WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第11组）==============
-- 医保社保代发交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'2' AS MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,'1' AS IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'1' AS SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,P1.TYPE AS MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS CLEAR_CHNL_CD -- 社保清算渠道代码
    ,'' AS MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,'' AS AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,'' AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,P1.ACCTNO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.ACCTNAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.INACCTNO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.INACCTNAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.INBANKNO AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS BELONG_ORG_NO -- 收款账号归属机构编号
    ,'' AS SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,'' AS INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,'' AS MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,'' AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,P1.DONE_TIME AS STL_PLAT_TXN_DT -- 结算平台交易日期
    ,P1.JS_DATE AS STL_PLAT_SER_NO -- 结算平台流水号
    ,P1.JS_SEQ AS MOBILE_NO -- 手机号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,P1.REMARK AS SUMMARY_ILUS -- 摘要说明
    ,'' AS POSTSC_DESC -- 附言描述
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_JS_JRNL_ZJYB_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,11 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_JS_JRNL_ZJYB_TA AS P1 -- 浙江社保批量明细表

WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,MSS_PAYOFF_IDNT_CD -- 医保社保代发标识代码
    ,IN_BANK_FUND_COL_ACCT_FLAG -- 行内收款账户标志
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,SOCI_SECU_PAYOFF_MODE_CD -- 社保代发模式代码
    ,MSS_PAYOFF_BIZ_TYPE_CD -- 医保社保代发业务类型代码
    ,TXN_AMT -- 交易金额
    ,CURR_CD -- 币种代码
    ,CLEAR_CHNL_CD -- 社保清算渠道代码
    ,MSS_TXN_DTL_STAT_CD -- 医保社保交易明细状态代码
    ,AGEN_RCPT_PAY_CUST_ACCT_NO -- 代收付客户账户编号
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,BELONG_ORG_NO -- 收款账号归属机构编号
    ,SOCI_SECU_CARD_CARD_NO -- 社保卡卡号
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,PRTCPT_INSURE_OBJ_NATION_CD -- 参保对象国籍代码
    ,INS_COMMUNIC_ADDR -- 参保对象通讯地址
    ,MEDCARE_PAYOFF_DTL_SER_NO -- 医保代发明细流水号
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,STL_PLAT_TXN_DT -- 结算平台交易日期
    ,STL_PLAT_SER_NO -- 结算平台流水号
    ,MOBILE_NO -- 手机号码
    ,CONT_NO_NO -- 联系电话号码
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA_TM;
