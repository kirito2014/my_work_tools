-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-信用卡结算交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_STL_TXN_DTL_TA
--     表中文名：信用卡结算交易明细聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：ACCT_NO, TXN_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-02-27 00:00:00 魏丹丹 新增
--         2024-09-07 00:00:00 魏丹丹 新增  卡片组织类型代码,征信管理机构编号,信用卡产品代码  3字段
--         2024-11-05 00:00:00 王穆军 修改逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA_TM
USING ORC
COMMENT '信用卡结算交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ACCT_NO -- 账户编号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,BELONG_ORG_NO -- 账户归属机构编号
    ,CRDT_CARD_ACCT_TYPE_CD -- 信用卡账户类型代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,CARD_NO -- 卡号
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,MAIN_DOCTYP_CD -- 证件类型代码
    ,MAIN_DOC_NO -- 证件号码
    ,MOBILE_NO -- 手机号码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_SYMBOL_CD -- 交易金额符号代码
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CNT_RV_CONSM_FLAG -- 笔数冲正消费标志
    ,AMT_RV_CONSM_FLAG -- 金额冲正消费标志
    ,CRDT_CARD_TXN_SRC_CD -- 信用卡交易来源代码
    ,CRDT_CARD_TXN_CHNL_CD -- 信用卡交易渠道代码
    ,CRDT_CARD_TXN_CATEGORY_CD -- 信用卡交易类别代码
    ,CRDT_CARD_TXN_TYPE_CD -- 信用卡交易类型代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,RCD_DT -- 入账日期
    ,TXN_COMM_FEE_SYMBOL_CD -- 交易手续费符号代码
    ,COMM_FEE_AMT -- 手续费金额
    ,TXN_UNDO_FLAG -- 交易撤销标志
    ,REFUND_AMT -- 退款金额
    ,TXN_ARGUE_FLAG -- 交易争议标志
    ,TXN_BNKOUTLS_NO -- 交易网点编号
    ,TXN_DESC_1 -- 交易描述1
    ,TXN_DESC_2 -- 交易描述2
    ,ORIG_CURR_CD -- 原始币种代码
    ,ORIG_CURR_AMT_SYMBOL_CD -- 原始币种金额符号代码
    ,ORIG_CURR_AMT -- 原始币种金额
    ,FOREIGN_IND -- 境内外标志
    ,PURCH_EXCH_EXCH_RATE -- 购汇汇率
    ,EXCH_FEE -- 交换费用
    ,AL_AUTH_FLAG -- 已授权标志
    ,OPER_TELR_NO -- 操作柜员编号
    ,TERMN_NO -- 终端编号
    ,TERMN_BIT_ADDR -- 终端位址
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_LOCAL_PROV_CITY_DESC -- 商户所在省市描述
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,POS_INPUT_MODE_CD -- POS输入方式代码
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,CNTPTY_BANK_NAME -- 对方行名
    ,CNTPTY_BANK_NO -- 对方行号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,IP_ADDR -- IP地址
    ,MAC_ADDR -- MAC地址
    ,OVER_PAYMENT_AMT -- 溢缴款金额
    ,OVER_PAYMENT_AMT_SYMBOL_CD -- 溢缴款金额符号代码
    ,USED_CRDT_OD_LMT -- 已使用信用透支额度
    ,OD_AMT_SYMBOL_CD -- 透支金额符号代码
    ,TXN_USE_OD_AMT -- 交易使用透支金额
    ,RV_AMT -- 冲正金额
    ,RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,INSTALMT_FLAG -- 分期付款标志
    ,INSTALLMENT_TMS -- 分期期数
    ,REPAY_STATUS_CD -- 偿付状态代码
    ,PAYOFF_MODE_CD -- 结清方式代码
    ,CARD_ORG_TYPE_CD -- 卡片组织类型代码
    ,CRDT_COLECT_MGMT_ORG_NO -- 征信管理机构编号
    ,CRDT_CARD_PROD_CD -- 信用卡产品代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 信用卡结算交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA_TM(
     ACCT_NO -- 账户编号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,BELONG_ORG_NO -- 账户归属机构编号
    ,CRDT_CARD_ACCT_TYPE_CD -- 信用卡账户类型代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,CARD_NO -- 卡号
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,MAIN_DOCTYP_CD -- 证件类型代码
    ,MAIN_DOC_NO -- 证件号码
    ,MOBILE_NO -- 手机号码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_SYMBOL_CD -- 交易金额符号代码
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CNT_RV_CONSM_FLAG -- 笔数冲正消费标志
    ,AMT_RV_CONSM_FLAG -- 金额冲正消费标志
    ,CRDT_CARD_TXN_SRC_CD -- 信用卡交易来源代码
    ,CRDT_CARD_TXN_CHNL_CD -- 信用卡交易渠道代码
    ,CRDT_CARD_TXN_CATEGORY_CD -- 信用卡交易类别代码
    ,CRDT_CARD_TXN_TYPE_CD -- 信用卡交易类型代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,RCD_DT -- 入账日期
    ,TXN_COMM_FEE_SYMBOL_CD -- 交易手续费符号代码
    ,COMM_FEE_AMT -- 手续费金额
    ,TXN_UNDO_FLAG -- 交易撤销标志
    ,REFUND_AMT -- 退款金额
    ,TXN_ARGUE_FLAG -- 交易争议标志
    ,TXN_BNKOUTLS_NO -- 交易网点编号
    ,TXN_DESC_1 -- 交易描述1
    ,TXN_DESC_2 -- 交易描述2
    ,ORIG_CURR_CD -- 原始币种代码
    ,ORIG_CURR_AMT_SYMBOL_CD -- 原始币种金额符号代码
    ,ORIG_CURR_AMT -- 原始币种金额
    ,FOREIGN_IND -- 境内外标志
    ,PURCH_EXCH_EXCH_RATE -- 购汇汇率
    ,EXCH_FEE -- 交换费用
    ,AL_AUTH_FLAG -- 已授权标志
    ,OPER_TELR_NO -- 操作柜员编号
    ,TERMN_NO -- 终端编号
    ,TERMN_BIT_ADDR -- 终端位址
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_LOCAL_PROV_CITY_DESC -- 商户所在省市描述
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,POS_INPUT_MODE_CD -- POS输入方式代码
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,CNTPTY_BANK_NAME -- 对方行名
    ,CNTPTY_BANK_NO -- 对方行号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,IP_ADDR -- IP地址
    ,MAC_ADDR -- MAC地址
    ,OVER_PAYMENT_AMT -- 溢缴款金额
    ,OVER_PAYMENT_AMT_SYMBOL_CD -- 溢缴款金额符号代码
    ,USED_CRDT_OD_LMT -- 已使用信用透支额度
    ,OD_AMT_SYMBOL_CD -- 透支金额符号代码
    ,TXN_USE_OD_AMT -- 交易使用透支金额
    ,RV_AMT -- 冲正金额
    ,RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,INSTALMT_FLAG -- 分期付款标志
    ,INSTALLMENT_TMS -- 分期期数
    ,REPAY_STATUS_CD -- 偿付状态代码
    ,PAYOFF_MODE_CD -- 结清方式代码
    ,CARD_ORG_TYPE_CD -- 卡片组织类型代码
    ,CRDT_COLECT_MGMT_ORG_NO -- 征信管理机构编号
    ,CRDT_CARD_PROD_CD -- 信用卡产品代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ACCTNBR AS ACCT_NO -- 账户编号
    ,P1.XTRANNO AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.INP_DATE) AS TXN_DT -- 交易日期
    ,CASE WHEN LENGTH(P1.INP_TIME) = 8
THEN unifiedTime(P1.INP_DATE)||' '||substr(P1.INP_TIME,1,2)||':'||substr(P1.INP_TIME,3,2)||':'||substr(P1.INP_TIME,5,2)||':'||substr(P1.INP_TIME,7,2)||'0000'
     WHEN LENGTH(P1.INP_TIME) = 7
THEN unifiedTime(P1.INP_DATE)||' 0'||substr(P1.INP_TIME,1,1)||':'||substr(P1.INP_TIME,2,2)||':'||substr(P1.INP_TIME,4,2)||':'||substr(P1.INP_TIME,6,2)||'0000'
ELSE unifiedTime1(P1.INP_DATE)
END  AS TXN_TM_STAMP -- 交易时间戳
    ,P1.BRANCH AS BELONG_ORG_NO -- 账户归属机构编号
    ,P2.CATEGORY AS CRDT_CARD_ACCT_TYPE_CD -- 信用卡账户类型代码
    ,CASE WHEN P2.CLOSE_CODE IS NULL 
     THEN ''
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P2.CLOSE_CODE)),'')
END AS ACCT_STATUS_CD -- 账户状态代码
    ,P1.CARD_NBR AS CARD_NO -- 卡号
    ,P3.SURNAME AS CUST_NAME -- 客户名称
    ,P3.CUSTR_REF AS CUST_IN_CD -- 客户内码
    ,CASE WHEN P3.RACE_CODE IS NULL OR TRIM(P3.RACE_CODE)=''
     THEN ''
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P3.RACE_CODE)),'')
END AS MAIN_DOCTYP_CD -- 证件类型代码
    ,P3.CUSTR_NBR AS MAIN_DOC_NO -- 证件号码
    ,P3.MO_PHONE AS MOBILE_NO -- 手机号码
    ,CASE WHEN P1.CURRNCY_CD='156' THEN 'CNY' WHEN P1.CURRNCY_CD='840' THEN 'USD' END AS CURR_CD -- 币种代码
    ,P1.BILL_AMT AS TXN_AMT -- 交易金额
    ,P1.BILL_AMTFLAG AS TXN_AMT_SYMBOL_CD -- 交易金额符号代码
    ,case when P1.BILL_AMTFLAG='+' then '14280001' --借
     else '14280002'                       --贷
  end AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'' --P7.O_R_F AS CNT_RV_CONSM_FLAG -- 笔数冲正消费标志
    ,'' --P6.O_R_F AS AMT_RV_CONSM_FLAG -- 金额冲正消费标志
    ,P1.TRANS_SRC AS CRDT_CARD_TXN_SRC_CD -- 信用卡交易来源代码
    ,P1.PIPE AS CRDT_CARD_TXN_CHNL_CD -- 信用卡交易渠道代码
    ,P1.TRAN_CODE AS CRDT_CARD_TXN_CATEGORY_CD -- 信用卡交易类别代码
    ,P1.TRANS_TYPE AS CRDT_CARD_TXN_TYPE_CD -- 信用卡交易类型代码
    ,P4.STATUSCD AS TXN_STATUS_CD -- 交易状态代码
    ,unifiedTime(P1.VAL_DATE) AS RCD_DT -- 入账日期
    ,P4.TRANFEE_FLAG AS TXN_COMM_FEE_SYMBOL_CD -- 交易手续费符号代码
    ,P4.TRANFEE AS COMM_FEE_AMT -- 手续费金额
    ,P1.REV_IND AS TXN_UNDO_FLAG -- 交易撤销标志
    ,P1.CASHBACK AS REFUND_AMT -- 退款金额
    ,P1.STIP_IND AS TXN_ARGUE_FLAG -- 交易争议标志
    ,P1.BRNO AS TXN_BNKOUTLS_NO -- 交易网点编号
    ,P1.DES_LINE1 AS TXN_DESC_1 -- 交易描述1
    ,P1.DES_LINE2 AS TXN_DESC_2 -- 交易描述2
    ,P1.ORGN_CURR AS ORIG_CURR_CD -- 原始币种代码
    ,P1.ORGN_AMTFLAG AS ORIG_CURR_AMT_SYMBOL_CD -- 原始币种金额符号代码
    ,P1.ORGN_AMT AS ORIG_CURR_AMT -- 原始币种金额
    ,P1.OSFLAG AS FOREIGN_IND -- 境内外标志
    ,P4.CONVRATE AS PURCH_EXCH_EXCH_RATE -- 购汇汇率
    ,P1.TRAN_FEE AS EXCH_FEE -- 交换费用
    ,P4.AUTFLAG AS AL_AUTH_FLAG -- 已授权标志
    ,P1.EMPNO AS OPER_TELR_NO -- 操作柜员编号
    ,P1.TERMINALI AS TERMN_NO -- 终端编号
    ,P1.CAP_ADDR AS TERMN_BIT_ADDR -- 终端位址
    ,case when P1.TRANS_TYPE between 1000 and 1999 and P1.TRANS_TYPE<>1050 then P1.MERCHANT else '' end AS MERCHT_NO -- 商户编号
    ,replace(P1.DES_LINE1,'"','') AS MERCHT_NAME -- 商户名称
    ,P1.MERCH_STAT AS MERCHT_LOCAL_PROV_CITY_DESC -- 商户所在省市描述
    ,P1.MCC_ALLOW AS MERCHT_MCC_CD -- 商户MCC代码
    ,P1.POS_ENTRY AS POS_INPUT_MODE_CD -- POS输入方式代码
    ,CASE WHEN instr(P5.XUSE,'DJ')=1 THEN SUBSTR(P5.INFO, 121, 20)  
WHEN instr(P5.XUSE,'DJ')=4 THEN SUBSTR(P5.INFO2, 121, 20)  
WHEN instr(P5.XUSE,'DJ')=7 THEN SUBSTR(P5.INFO3, 121, 20) 
WHEN instr(P5.XUSE,'DJ')=10 THEN SUBSTR(P5.INFO4, 121, 20)  
WHEN instr(P5.XUSE,'DJ')=13 THEN SUBSTR(P5.INFO5, 121, 20)  
WHEN instr(P5.XUSE,'AD')=1 THEN SUBSTR(P5.INFO, 1, 20)  
WHEN instr(P5.XUSE,'AD')=4 THEN SUBSTR(P5.INFO2, 1, 20) 
WHEN instr(P5.XUSE,'AD')=7 THEN SUBSTR(P5.INFO3, 1, 20)  
WHEN instr(P5.XUSE,'AD')=10 THEN SUBSTR(P5.INFO4, 1, 20)  
WHEN instr(P5.XUSE,'AD')=13 THEN SUBSTR(P5.INFO5, 1, 20)  
else '' end AS CNTPTY_ACCT_NO -- 对方账户编号
    ,CASE WHEN instr(P5.XUSE,'DJ')=1 THEN SUBSTR(P5.INFO, 1, 120)  
WHEN instr(P5.XUSE,'DJ')=4 THEN SUBSTR(P5.INFO2, 1, 120)  
WHEN instr(P5.XUSE,'DJ')=7 THEN SUBSTR(P5.INFO3, 1, 120)  
WHEN instr(P5.XUSE,'DJ')=10 THEN SUBSTR(P5.INFO4, 1, 120)
WHEN instr(P5.XUSE,'DJ')=13 THEN SUBSTR(P5.INFO5, 1, 120)  
WHEN instr(P5.XUSE,'AD')=1 THEN SUBSTR(P5.INFO, 93, 60)  
WHEN instr(P5.XUSE,'AD')=4 THEN SUBSTR(P5.INFO2, 93, 60)  
WHEN instr(P5.XUSE,'AD')=7 THEN SUBSTR(P5.INFO3, 93, 60)
WHEN instr(P5.XUSE,'AD')=10 THEN SUBSTR(P5.INFO4, 93, 60)  
WHEN instr(P5.XUSE,'AD')=13 THEN SUBSTR(P5.INFO5, 93, 60)  
else '' end AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,CASE WHEN P5.XUSE LIKE '%AD%' THEN SUBSTR(P5.INFO,33,60) ELSE '' END AS CNTPTY_BANK_NAME -- 对方行名
    ,CASE WHEN P5.XUSE LIKE '%AD%' THEN SUBSTR(P5.INFO,21,20) ELSE '' END AS CNTPTY_BANK_NO -- 对方行号
    ,P4.PAN_TR_IN AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,P4.PAN_TR_OU AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,CASE WHEN P5.XUSE LIKE '%CD%' THEN SUBSTR(P5.INFO,1,39) ELSE '' END AS IP_ADDR -- IP地址
    ,CASE WHEN P5.XUSE LIKE '%CD%' THEN SUBSTR(P5.INFO,40,17) ELSE '' END AS MAC_ADDR -- MAC地址
    ,P1.EXPAY_AMT AS OVER_PAYMENT_AMT -- 溢缴款金额
    ,P1.EXPAY_AMT_FLG AS OVER_PAYMENT_AMT_SYMBOL_CD -- 溢缴款金额符号代码
    ,P4.OD_AMT AS USED_CRDT_OD_LMT -- 已使用信用透支额度
    ,P4.OD_AMT_FLG AS OD_AMT_SYMBOL_CD -- 透支金额符号代码
    ,P4.AMOUNT_OD AS TXN_USE_OD_AMT -- 交易使用透支金额
    ,P1.Bill_AMT AS RV_AMT -- 冲正金额
    ,P4.DELFLG AS RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,P1.M_P_IND AS INSTALMT_FLAG -- 分期付款标志
    ,P1.NBR_MTHS AS INSTALLMENT_TMS -- 分期期数
    ,P1.REIMBURSE AS REPAY_STATUS_CD -- 偿付状态代码
    ,P4.OVER_DRAFT AS PAYOFF_MODE_CD -- 结清方式代码
    ,P1.CARD_PLAN AS CARD_ORG_TYPE_CD -- 卡片组织类型代码
    ,P2.PBC_BRNCH AS CRDT_COLECT_MGMT_ORG_NO -- 征信管理机构编号
    ,P1.PRODUCT AS CRDT_CARD_PROD_CD -- 信用卡产品代码
    ,'CCRD' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCRD_EVENT_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CCRD${version_num}.ODS_CCRD_EVENT_TA AS P1 -- 账务交易流水表

LEFT JOIN ODS_CCRD${version_num}.ODS_CCRD_ACCT_TF AS P2 -- 信用卡账户信息
       ON P1.ACCTNBR=P2.XACCOUNT 
AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_CCRD${version_num}.ODS_CCRD_CUSTR_TF AS P3 -- 信用卡客户信息
       ON P2.CUSTR_NBR=P3.CUSTR_NBR AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_CCRD${version_num}.ODS_CCRD_CUPLG_TF AS P4 -- 境内金融交易日志表
       ON P4.PAN = P1.CARD_NBR
AND P4.GXSEQNO = P1.SCHMFEEAMT
AND P4.SEQNO = P1.XTRANNO
AND P4.TRANTYPE_A = P1.TRANS_TYPE
AND P4.RSPCODE = '00' --2024/11/5 ADD BY WMJ
AND P4.PT_DT = '${process_date}' 
AND P4.DEL_F='0' 
LEFT JOIN (
SELECT
   INFO2
  ,INFO
  ,XUSE
  ,INFO3
  ,INFO4
  ,INFO5
  ,ACCTNBR
  ,TRAN_NO
  ,ROW_NUMBER() OVER(PARTITION BY ACCTNBR,TRAN_NO ORDER BY XUSE DESC) RN
FROM ODS_CCRD.ODS_CCRD_AGINF_TF
WHERE PT_DT = '${process_date}' AND DEL_F='0'
) AS P5 -- 交易附加信息登记簿
       ON P1.ACCTNBR=P5.ACCTNBR AND P1.XTRANNO=P5.TRAN_NO AND P5.RN=1 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 代码转换
       ON TRIM(P2.CLOSE_CODE)=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='CCRD'  --源系统
AND S1.SRC_TAB_EN_NAME='ACCT' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='CLOSE_CODE' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_CRDT_CARD_STL_TXN_DTL_TA'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='ACCT_STATUS_CD' --目标字段 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 代码转换
       ON TRIM(P3.RACE_CODE)=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='CCRD'  --源系统
AND S2.SRC_TAB_EN_NAME='CUSTR' --来源表英文名  
AND S2.SRC_FIELD_EN_NAME='RACE_CODE' --来源字段英文名 
AND S2.TARGET_TAB_EN_NAME='AGL_CRDT_CARD_STL_TXN_DTL_TA'  --目标表名   
AND S2.TARGET_FIELD_EN_NAME='MAIN_DOCTYP_CD' --目标字段 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
AND P1.TRANS_SRC IN ('MBKIO','CUPIO')  --2024/11/5 ADD BY WMJ
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     ACCT_NO -- 账户编号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,BELONG_ORG_NO -- 账户归属机构编号
    ,CRDT_CARD_ACCT_TYPE_CD -- 信用卡账户类型代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,CARD_NO -- 卡号
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,MAIN_DOCTYP_CD -- 证件类型代码
    ,MAIN_DOC_NO -- 证件号码
    ,MOBILE_NO -- 手机号码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_SYMBOL_CD -- 交易金额符号代码
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CNT_RV_CONSM_FLAG -- 笔数冲正消费标志
    ,AMT_RV_CONSM_FLAG -- 金额冲正消费标志
    ,CRDT_CARD_TXN_SRC_CD -- 信用卡交易来源代码
    ,CRDT_CARD_TXN_CHNL_CD -- 信用卡交易渠道代码
    ,CRDT_CARD_TXN_CATEGORY_CD -- 信用卡交易类别代码
    ,CRDT_CARD_TXN_TYPE_CD -- 信用卡交易类型代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,RCD_DT -- 入账日期
    ,TXN_COMM_FEE_SYMBOL_CD -- 交易手续费符号代码
    ,COMM_FEE_AMT -- 手续费金额
    ,TXN_UNDO_FLAG -- 交易撤销标志
    ,REFUND_AMT -- 退款金额
    ,TXN_ARGUE_FLAG -- 交易争议标志
    ,TXN_BNKOUTLS_NO -- 交易网点编号
    ,TXN_DESC_1 -- 交易描述1
    ,TXN_DESC_2 -- 交易描述2
    ,ORIG_CURR_CD -- 原始币种代码
    ,ORIG_CURR_AMT_SYMBOL_CD -- 原始币种金额符号代码
    ,ORIG_CURR_AMT -- 原始币种金额
    ,FOREIGN_IND -- 境内外标志
    ,PURCH_EXCH_EXCH_RATE -- 购汇汇率
    ,EXCH_FEE -- 交换费用
    ,AL_AUTH_FLAG -- 已授权标志
    ,OPER_TELR_NO -- 操作柜员编号
    ,TERMN_NO -- 终端编号
    ,TERMN_BIT_ADDR -- 终端位址
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_LOCAL_PROV_CITY_DESC -- 商户所在省市描述
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,POS_INPUT_MODE_CD -- POS输入方式代码
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,CNTPTY_BANK_NAME -- 对方行名
    ,CNTPTY_BANK_NO -- 对方行号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,IP_ADDR -- IP地址
    ,MAC_ADDR -- MAC地址
    ,OVER_PAYMENT_AMT -- 溢缴款金额
    ,OVER_PAYMENT_AMT_SYMBOL_CD -- 溢缴款金额符号代码
    ,USED_CRDT_OD_LMT -- 已使用信用透支额度
    ,OD_AMT_SYMBOL_CD -- 透支金额符号代码
    ,TXN_USE_OD_AMT -- 交易使用透支金额
    ,RV_AMT -- 冲正金额
    ,RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,INSTALMT_FLAG -- 分期付款标志
    ,INSTALLMENT_TMS -- 分期期数
    ,REPAY_STATUS_CD -- 偿付状态代码
    ,PAYOFF_MODE_CD -- 结清方式代码
    ,CARD_ORG_TYPE_CD -- 卡片组织类型代码
    ,CRDT_COLECT_MGMT_ORG_NO -- 征信管理机构编号
    ,CRDT_CARD_PROD_CD -- 信用卡产品代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_CRDT_CARD_STL_TXN_DTL_TA_TM;
