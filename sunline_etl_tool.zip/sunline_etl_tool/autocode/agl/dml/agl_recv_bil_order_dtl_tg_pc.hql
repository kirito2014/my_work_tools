-- 模板名称: 聚合层-流水表-区间流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVP-收单订单明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 15:10:00
-- 脚本类型: DML
-- 注意: 1.辅助字段【ETL_PERIOD_DT STRING COMMENT 'ETL区间日期'】需要显式的填写到SDM文档映射每组目标为主临时表_TM的字段映射里面。
--       2.参数 ${interval_flow_dt} 区间起始日期 由配置任务时候选择区间天数，DataOps作业跑批时候会自动计算。
-- 修改日志:
--     表英文名：AGL_RECV_BIL_ORDER_DTL_TG
--     表中文名：收单订单明细聚合
--     创建日期：2024-01-03 00:00:00
--     主键字段：TXN_SER_NO, ORIG_TXN_SER_NO, TXN_RECV_TM_STAMP, TXN_SETUP_TM_STAMP, TXN_UPDATE_TM_STAMP, TXN_CMPLT_TM_STAMP, ORIG_TXN_RECV_TM_STAMP
--     归属层次：AGL-EVP
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-01-03 00:00:00 魏丹丹 新增
--         2024-08-24 00:00:00 魏丹丹 新增字段、主键
--         2024-08-29 00:00:00 魏丹丹 添加时间戳初始化日期
--         2024-09-11 00:00:00 魏丹丹 第二组参数表已入湖，修复 ,2024/9/26修改区间取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.0 drop old backup table */
DROP TABLE IF EXISTS AGL.AGL_RECV_BIL_ORDER_DTL_TG_BK;

/* 1.1 backup before batch_date data */
CREATE TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_BK
USING ORC
COMMENT '收单订单明细聚合-历史区间数据备份表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,ETL_LAST_ACG_DT -- ETL更新日期
    ,PT_DT -- ETL区间日期
FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG
WHERE PT_DT < '${process_date}' AND PT_DT > '${interval_flow_dt}';


/* 2.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM;

/* 2.2 create main temp table  */
CREATE TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM
USING ORC
COMMENT '收单订单明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源英文名称
    ,SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS ETL_PERIOD_DT -- ETL区间日期
FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG WHERE 0=1 ;


/* 2.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM;

/* 3.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 收单订单明细聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_RECV_BIL_ORDER_DTL_TG_01;

CREATE TABLE AGL.TMP_AGL_RECV_BIL_ORDER_DTL_TG_01 (
     TXN_SER_NO STRING COMMENT '交易流水号'
    ,ORIG_TXN_RECV_TM_STAMP STRING COMMENT '原交易接收时间戳'
    ,IN_BANK_SCENE_PLAT_CD STRING COMMENT '行内场景平台代码'
    ,CORE_ACCTN_DT STRING COMMENT '核心记账日期'
    ,CAN_DISCNT_AMT DECIMAL(28,2) COMMENT '可打折金额'
    ,NO_DISCNT_AMT DECIMAL(28,2) COMMENT '不可打折金额'
    ,CFM_RECV_GOOD_FLAG STRING COMMENT '确认收货标志'
    ,COURT_MNY_FLAG STRING COMMENT '法院案款标志'
    ,PRE_AUTH_SCENE_CD STRING COMMENT '预授权场景代码'
    ,AUTH_CD STRING COMMENT '授权码'
    ,PRE_AUTH_CD STRING COMMENT '预授权码'
    ,PRE_AUTH_CFM_MODE_CD STRING COMMENT '预授权确认模式代码'
    ,PAY_MODE_TYPE_CD STRING COMMENT '支付模式类型代码'
    ,ERR_RSN_ILUS STRING COMMENT '错误原因说明'
    ,ERR_CD STRING COMMENT '错误编码'
    ,CD_BRAND_TYPE_CD STRING COMMENT '码牌类型代码'
    ,ASSIS_EQUIP_NO STRING COMMENT '辅助设备号'
    ,TERMN_REAL_TM_LTLN_INFO_DESC STRING COMMENT '终端实时经纬度信息描述'
    ,TERMN_NET_IN_CERT_NO STRING COMMENT '终端入网认证编号'
    ,MERCHT_POINT_EQUIP_TYPE_CD STRING COMMENT '商户端设备类型代码'
    ,APP_PROGRAM_VER_NO STRING COMMENT '应用程序版本编号'
    ,MERCHT_POINT_EQUIP_IP_ADDR STRING COMMENT '商户端设备IP地址'
    ,CAN_OPEN_ELEC_INVOICE_FLAG STRING COMMENT '可开电子发票标志'
    ,USER_IP_ADDR STRING COMMENT '用户IP地址'
    ,USER_MAC_ADDR STRING COMMENT '用户MAC地址'
    ,MERCHT_STORE_NO STRING COMMENT '商户门店编号'
    ,BIZ_SMALL_RECEIPT_TYPE_CD STRING COMMENT '商家小票类型代码'
    ,SELLER_ZFB_USER_ID STRING COMMENT '卖家支付宝用户ID'
    ,ZFB_SHOP_NO STRING COMMENT '支付宝店铺编号'
    ,MERCHT_OPERR_NO STRING COMMENT '商户操作员编号'
    ,MERCHT_RGN_INFO_CD STRING COMMENT '商户区域信息编码'
    ,MERCHT_WALLET_MODE_CD STRING COMMENT '商户钱包模式代码'
    ,MERCHT_BIZ_SER_NO STRING COMMENT '商户业务流水号'
    ,MERCHT_TEL_NO STRING COMMENT '商户电话号码'
    ,RECV_BIL_ORG_IDTFY_IDNT STRING COMMENT '收单机构识别标识'
    ,APPLY_NO STRING COMMENT '应用编号'
    ,SERV_PROVDER_NAME STRING COMMENT '服务商名称'
    ,CHNL_MERCHT_MERCHT_NO STRING COMMENT '渠道商商户编号'
    ,CHNL_MERCHT_MERCHT_NAME STRING COMMENT '渠道商商户名称'
    ,RECV_BIL_STL_ACCT_NO STRING COMMENT '收单结算账户编号'
    ,RECV_BIL_STL_ACCT_NAME STRING COMMENT '收单结算账户名称'
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO STRING COMMENT '收单结算账号开户行行号'
    ,RBSA_OPBK_NAME STRING COMMENT '收单结算账号开户行名称'
    ,RECV_BIL_STL_ACCT_CATEGORY_CD STRING COMMENT '收单结算账户类别代码'
    ,PAY_FUND_ACCT_NO STRING COMMENT '付款账户编号'
    ,PAY_ACCT_NAME STRING COMMENT '付款账户名称'
    ,PAY_ACCT_OPEN_ACCT_ORG_NO STRING COMMENT '付款账户开户机构编号'
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME STRING COMMENT '付款账户开户机构名称'
    ,EXCESS_REFUND_DEBIT_ACCT_NO STRING COMMENT '超额退款借方账户编号'
    ,EXCESS_REFUND_DEBIT_ACCT_NAME STRING COMMENT '超额退款借方账户名称'
    ,EXCESS_REFUND_DEBIT_ORG_NO STRING COMMENT '超额退款借方机构编号'
    ,EXCESS_REFUND_CRDT_ACCT_NO STRING COMMENT '超额退款贷方账户编号'
    ,EXCESS_REFUND_CRDT_ACCT_NAME STRING COMMENT '超额退款贷方账户名称'
    ,EXCESS_REFUND_CRDT_ORG_NO STRING COMMENT '超额退款贷方机构编号'
    ,COURT_MNY_ACCT_NO STRING COMMENT '法院案款虚账户编号'
    ,BUYER_NAME STRING COMMENT '买方名称'
    ,BUYER_MOBILE_NO STRING COMMENT '买方手机号码'
    ,BUYER_DOCTYP_CD STRING COMMENT '买方证件类型代码'
    ,BUYER_DOC_NO STRING COMMENT '买方证件号码'
    ,BUYER_MIN_AGE BIGINT COMMENT '买方最小年龄'
    ,BUYER_CUST_NO STRING COMMENT '买方客户编号'
    ,MNY_USER_ID STRING COMMENT '案款用户ID'
    ,BUYER_LOGIN_ACCT_NO STRING COMMENT '买方登录账号'
    ,INSTALLMENT_TOTAL_AMT DECIMAL(28,2) COMMENT '分期总金额'
    ,INST_TOTAL_CFEE_RATE DECIMAL(20,7) COMMENT '分期付款总手续费费率'
    ,MERCHT_SCF_SERV_CHARGE_RATE DECIMAL(20,7) COMMENT '商户补贴手续费费率'
    ,MCH_SBDY_INSFSC_RATE DECIMAL(20,7) COMMENT '行社补贴分期费费率'
    ,MCH_SBDY_INSCF_AMT DECIMAL(28,2) COMMENT '行社补贴分期手续费金额'
    ,CHDER_INSFSC_RATE DECIMAL(20,7) COMMENT '持卡人分期费费率'
    ,CHDER_INSCF_AMT DECIMAL(28,2) COMMENT '持卡人分期手续费金额'
    ,MERCHT_SBDY_INSCF_AMT DECIMAL(28,2) COMMENT '商户补贴分期手续费金额'
    ,INSTALLMENT_PAY_TYPE_CD STRING COMMENT '分期支付类型代码'
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD STRING COMMENT '收单付款账户限制类型代码'
    ,INSTALLMENT_TMS BIGINT COMMENT '分期期数'
    ,ETL_PERIOD_DT STRING COMMENT 'ETL区间日期'
)
USING ORC
COMMENT '收单订单明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_RECV_BIL_ORDER_DTL_TG_01(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,ETL_PERIOD_DT -- ETL区间日期
)
SELECT
     P1.MSG_ID AS TXN_SER_NO -- 交易流水号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ORGNL_LO_TIME') AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CHNL_TP') AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INFOFCORE_STTLMDT1') AS CORE_ACCTN_DT -- 核心记账日期
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DISC_AMT') AS CAN_DISCNT_AMT -- 可打折金额
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DISC_AMT') AS NO_DISCNT_AMT -- 不可打折金额
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_SET_CONREC_RECEIPT') AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.M_CDTR_CASEFUND') AS COURT_MNY_FLAG -- 法院案款标志
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_PREAUTH_PROD_CD') AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTR_AUTH_BNKACCTID') AS AUTH_CD -- 授权码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_PREAUTH_NO') AS PRE_AUTH_CD -- 预授权码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_PREAUTH_CONF') AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ADV_PAY_TP') AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_RJCT_RSN') AS ERR_RSN_ILUS -- 错误原因说明
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_RJCT_CD') AS ERR_CD -- 错误编码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_PLAT_TP') AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DEV_ID') AS ASSIS_EQUIP_NO -- 辅助设备号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.M_POS_TMLOC_CD') AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_TERMNL_CERT_ID') AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_TER_TY_TYPE') AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_TERMNL_SFT_VER') AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DEV_IP') AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INV_REQ') AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.M_CLT_IP_ADDR') AS USER_IP_ADDR -- 用户IP地址
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.M_MAC_ADDR') AS USER_MAC_ADDR -- 用户MAC地址
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_STOR_ID') AS MERCHT_STORE_NO -- 商户门店编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_WC_RECE_TYPE') AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_SELL_ID') AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_TNNL_STOR_ID') AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INPUT_OPT_ID') AS MERCHT_OPERR_NO -- 商户操作员编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CARD_ACCPTER_DTCT') AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_SIGN_MRCH_MWD') AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_MRCH_BUS_NO') AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CON_PHO_TELNB') AS MERCHT_TEL_NO -- 商户电话号码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ACQUIRER_ACQID') AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ACQUIRER_APPID') AS APPLY_NO -- 应用编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ISV_NM') AS SERV_PROVDER_NAME -- 服务商名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ACQUIRER_PARTNERID') AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_ACQUIRER_PARTNERNM') AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_MRCH_STLL_ACC') AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CDTR_ACCT_NM') AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_BANK_BRAN_ID') AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_BANK_ACCOUNTBANK') AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_MRCH_STLL_ACC_TP') AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTR_ACCT_ID') AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTRACCT_NM') AS PAY_ACCT_NAME -- 付款账户名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTRACCT_ISSR') AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTR_AGT_NM') AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_EXCE_DBTR_ACCT_ID') AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_EXCE_DBTR_ACCT_NM') AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_EXCE_DBTR_ACCT_ISSR_CD') AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_EXCE_CDTR_ACCT_ID') AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_EXCE_CDTR_ACCT_NM') AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_EXCE_CDTR_ACCT_ISSUER') AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.M_CDTR_VTLPSTSCPT') AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CUST_NM') AS BUYER_NAME -- 买方名称
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CUST_ID_TP') AS BUYER_MOBILE_NO -- 买方手机号码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CUST_ID_NO') AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CUST_PHON_NO') AS BUYER_DOC_NO -- 买方证件号码
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_CUST_MINI_AGE') AS BUYER_MIN_AGE -- 买方最小年龄
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTR_CLNTID') AS BUYER_CUST_NO -- 买方客户编号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_DBTR_CLNTID') AS MNY_USER_ID -- 案款用户ID
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_BUR_LOG_ID') AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_TOT_AMO_AMOUNT') AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INSTL_CHRGSRT') AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INSTL_CHRGFEE') AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INSTN_INSTL_RT') AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INSTN_INSTL_FEE') AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_USR_INSTL_RT') AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_USR_INSTL_FEE') AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_MRCH_INSTL_FEE') AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INS_PA_TYPE') AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,CASE WHEN GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_MRCH_STLL_ACC_TP')='1' THEN '10'
     WHEN GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_MRCH_STLL_ACC_TP')='2' THEN '20'
     ELSE NULL
END AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,CASE WHEN CAST(GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INS_PA_TYPE') AS STRING) = '1'
     THEN GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INSTL_TTLNBOFPMTS') 
     WHEN CAST(GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INS_PA_TYPE') AS STRING) = '2'
     THEN GET_JSON_OBJECT(EXT_FIELD_INFO,'$.WP_INSTL_NMCSMFNC')
     ELSE NULL
END AS INSTALLMENT_TMS -- 分期期数
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
FROM
ODS_UPPRUN.ODS_UPPRUN_UPP_PAY_SIMPLE_EXTEND_TA AS P1 -- 交易流水表辅表

WHERE P1.MSG_ID <> ''  AND P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第1-1组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TX_MSG_ID AS TXN_SER_NO -- 交易流水号
    ,P1.TX_ORI_MSG_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,unifiedTime(CASE WHEN P1.TX_REC_TIME IS NULL OR P1.TX_REC_TIME='' THEN NULL ELSE P1.TX_REC_TIME END) AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,unifiedTime(CASE WHEN P1.GMT_CREATE IS NULL OR P1.GMT_CREATE='' THEN NULL ELSE P1.GMT_CREATE END) AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime(CASE WHEN P1.GMT_MODIFIED IS NULL OR P1.GMT_MODIFIED='' THEN NULL ELSE P1.GMT_MODIFIED END) AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TX_TXN_TIME IS NULL OR P1.TX_TXN_TIME='' THEN NULL ELSE P1.TX_TXN_TIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,unifiedTime(CASE WHEN P2.ORIG_TXN_RECV_TM_STAMP IS NULL OR P2.ORIG_TXN_RECV_TM_STAMP='' THEN NULL ELSE P2.ORIG_TXN_RECV_TM_STAMP END) AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.SETT_TRANS_DATE) AS TXN_DT -- 交易日期
    ,P1.CHANNEL_REQ_SERIAL_NUMBER AS CHNL_SER_NO -- 渠道流水号
    ,P1.CHANNEL_ORI_REQ_SERIAL_NUMBER AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,P1.CHANNEL_ID AS TXN_CHNL_CD -- 交易渠道代码
    ,CASE WHEN P2.IN_BANK_SCENE_PLAT_CD IS NULL OR TRIM(P2.IN_BANK_SCENE_PLAT_CD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P2.IN_BANK_SCENE_PLAT_CD),'') 
END AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,unifiedTime(CASE WHEN P1.CHANNEL_TIME IS NULL OR P1.CHANNEL_TIME='' THEN NULL ELSE P1.CHANNEL_TIME END) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,P1.TX_PAY_ID AS CNAPS_SER_NO -- 支付系统流水号
    ,P1.TX_ORI_PAY_ID AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,unifiedTime(P1.SETT_EXT_TRANS_DATE) AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.TUNNEL_TYPE IS NULL OR TRIM(P1.TUNNEL_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), '@'||TRIM(P1.TUNNEL_TYPE),'') 
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,P1.TUNNEL_ID AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,unifiedTime(CASE WHEN P1.TUNNEL_TIME IS NULL OR P1.TUNNEL_TIME='' THEN NULL ELSE P1.TUNNEL_TIME END) AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,unifiedTime(P2.CORE_ACCTN_DT) AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.TX_CCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,CASE WHEN P3.ACCT_TYPE = '0101'
     THEN P3.TX_AMT
     ELSE NULL
END AS PSBOOK_PAY_AMT -- 存折支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0102'
     THEN P3.TX_AMT
     ELSE NULL
END AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0103'
     THEN P3.TX_AMT
     ELSE NULL
END AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0104'
     THEN P3.TX_AMT
     ELSE NULL
END AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0201'
     THEN P3.TX_AMT
     ELSE NULL
END AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0201_inst'
     THEN P3.TX_AMT
     ELSE NULL
END AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0301'
     THEN P3.TX_AMT
     ELSE NULL
END AS EACCT_PAY_AMT -- 电子账户支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0302'
     THEN P3.TX_AMT
     ELSE NULL
END AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,CASE WHEN P3.ACCT_TYPE = '0501'
     THEN P3.TX_AMT
     ELSE NULL
END AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,CASE WHEN P3.ACCT_TYPE = 'S001'
     THEN P3.TX_AMT
     ELSE NULL
END AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,CASE WHEN P3.ACCT_TYPE = 'PR01'
     THEN P3.TX_AMT
     ELSE NULL
END AS RNDM_SUB_AMT -- 随机立减金额
    ,CASE WHEN P3.ACCT_TYPE = 'PR02'
     THEN P3.TX_AMT
     ELSE NULL
END AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,P1.TX_TXN_TYPE AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,P1.TX_BIZ_CGY AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,P1.TX_PURP_PRTRY AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,P1.TX_TXN_STS AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,P1.TX_TXN_SUB_STS AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,P1.TX_REFUND_MODE AS REFUND_MODE_CD -- 退款模式代码
    ,P1.TX_SETTLE_AMT AS SHOULD_STL_AMT -- 应结金额
    ,P2.CAN_DISCNT_AMT AS CAN_DISCNT_AMT -- 可打折金额
    ,P2.NO_DISCNT_AMT AS NO_DISCNT_AMT -- 不可打折金额
    ,P2.CFM_RECV_GOOD_FLAG AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,P2.COURT_MNY_FLAG AS COURT_MNY_FLAG -- 法院案款标志
    ,P2.PRE_AUTH_SCENE_CD AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,P2.AUTH_CD AS AUTH_CD -- 授权码
    ,P2.PRE_AUTH_CD AS PRE_AUTH_CD -- 预授权码
    ,P2.PRE_AUTH_CFM_MODE_CD AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,P2.PAY_MODE_TYPE_CD AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,CASE WHEN T1.TX_MSG_ID IS NOT NULL OR T1.TX_PRT_MSG_ID IS NOT NULL
     THEN '1'
     ELSE '0'
END AS MERGE_PAY_FLAG -- 合并支付标志
    ,CASE WHEN T1.TX_PRT_MSG_ID IS NOT NULL   THEN '1'
     WHEN T1.TX_MSG_ID IS NOT NULL   THEN '0'
     ELSE ''
END AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,T1.TX_PRT_MSG_ID AS FATHER_TXN_SER_NO -- 父交易流水号
    ,P2.ERR_RSN_ILUS AS ERR_RSN_ILUS -- 错误原因说明
    ,P2.ERR_CD AS ERR_CD -- 错误编码
    ,P1.TERMINAL_ID AS TXN_TERMN_CD -- 交易终端号
    ,P1.TERMINAL_INFO_INDEX AS TERMN_SN -- 终端序列号
    ,P2.CD_BRAND_TYPE_CD AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,P2.ASSIS_EQUIP_NO AS ASSIS_EQUIP_NO -- 辅助设备号
    ,P2.TERMN_REAL_TM_LTLN_INFO_DESC AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,P2.TERMN_NET_IN_CERT_NO AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,P2.MERCHT_POINT_EQUIP_TYPE_CD AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,P2.APP_PROGRAM_VER_NO AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,P2.MERCHT_POINT_EQUIP_IP_ADDR AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,P2.CAN_OPEN_ELEC_INVOICE_FLAG AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,P2.USER_IP_ADDR AS USER_IP_ADDR -- 用户IP地址
    ,P2.USER_MAC_ADDR AS USER_MAC_ADDR -- 用户MAC地址
    ,P1.PROD_PAY_PROD AS RECV_BIL_PROD_NO -- 收单产品编号
    ,P1.PROD_PAY_SCEN AS PAY_SCENE_CD -- 支付场景代码
    ,P1.PROD_BA_PD_CD AS BASIC_PROD_NO -- 基础产品编号
    ,P1.ORDER_MER_ORDER_NO AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.ORDER_ORGL_MER_ORDER_NO AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,P1.ORDER_BODY AS MERCHD_DESC -- 商品描述
    ,P1.ORDER_REMARK AS ORDER_REM -- 订单备注
    ,P1.ORDER_SUBJECT AS ORDER_TITLE_NAME -- 订单标题名称
    ,unifiedTime(CASE WHEN P1.ORDER_EXPR_TIME IS NULL OR P1.ORDER_EXPR_TIME='' THEN NULL ELSE P1.ORDER_EXPR_TIME END) AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,P1.MERCH_TYP AS MERCHT_TYPE_CD -- 商户类型代码
    ,P1.MERCH_S_IDEN_CD AS MERCHT_IDTFY_NO -- 商户识别编号
    ,P1.MERCH_ID AS MERCHT_NO -- 商户编号
    ,P1.MERCH_CATEG_CD AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MERCH_S_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCH_S_MER_NM AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.MERCH_S_NM_NAME AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,P1.MERCH_S_APPID AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P1.MERCH_ORG_NO AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,P2.MERCHT_STORE_NO AS MERCHT_STORE_NO -- 商户门店编号
    ,P2.BIZ_SMALL_RECEIPT_TYPE_CD AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,P1.TUNNEL_SUB_MERCH_ID AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,P1.TUNNEL_SUB_APPID AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,P2.SELLER_ZFB_USER_ID AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,P2.ZFB_SHOP_NO AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,P2.MERCHT_OPERR_NO AS MERCHT_OPERR_NO -- 商户操作员编号
    ,P2.MERCHT_RGN_INFO_CD AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,P2.MERCHT_WALLET_MODE_CD AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,P2.MERCHT_BIZ_SER_NO AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,P2.MERCHT_TEL_NO AS MERCHT_TEL_NO -- 商户电话号码
    ,P2.RECV_BIL_ORG_IDTFY_IDNT AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,P2.APPLY_NO AS APPLY_NO -- 应用编号
    ,P1.SP_IDENTIFY_NO AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,P1.SP_CHANNEL_NO AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,P1.SP_APPID AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,P2.SERV_PROVDER_NAME AS SERV_PROVDER_NAME -- 服务商名称
    ,P2.CHNL_MERCHT_MERCHT_NO AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,P2.CHNL_MERCHT_MERCHT_NAME AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,P1.SETT_BRAN_ACCT_NO AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,P1.SETT_BRAN_ACCT_NM AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P2.RECV_BIL_STL_ACCT_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P2.RECV_BIL_STL_ACCT_NAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,P2.RECV_BIL_STL_ACCT_NO_OPBANK_NO AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,P2.RBSA_OPBK_NAME AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,P2.RECV_BIL_STL_ACCT_CATEGORY_CD AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P2.PAY_FUND_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P2.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,P2.PAY_ACCT_OPEN_ACCT_ORG_NO AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P2.PAY_ACCT_OPEN_ACCT_ORG_NAME AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,CASE WHEN P2.RECV_BIL_PAY_ACCT_LMT_TYPE_CD IS NULL OR TRIM(P2.RECV_BIL_PAY_ACCT_LMT_TYPE_CD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), '@'||TRIM(P2.RECV_BIL_PAY_ACCT_LMT_TYPE_CD),'') 
END AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,P2.EXCESS_REFUND_DEBIT_ACCT_NO AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,P2.EXCESS_REFUND_DEBIT_ACCT_NAME AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,P2.EXCESS_REFUND_DEBIT_ORG_NO AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,P2.EXCESS_REFUND_CRDT_ACCT_NO AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,P2.EXCESS_REFUND_CRDT_ACCT_NAME AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,P2.EXCESS_REFUND_CRDT_ORG_NO AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,P2.COURT_MNY_ACCT_NO AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,P2.BUYER_NAME AS BUYER_NAME -- 买方名称
    ,P2.BUYER_MOBILE_NO AS BUYER_MOBILE_NO -- 买方手机号码
    ,P2.BUYER_DOCTYP_CD AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,P2.BUYER_DOC_NO AS BUYER_DOC_NO -- 买方证件号码
    ,P2.BUYER_MIN_AGE AS BUYER_MIN_AGE -- 买方最小年龄
    ,P2.BUYER_CUST_NO AS BUYER_CUST_NO -- 买方客户编号
    ,P2.MNY_USER_ID AS MNY_USER_ID -- 案款用户ID
    ,P2.BUYER_LOGIN_ACCT_NO AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,P1.TUNNEL_PAYER_ID AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,P2.INSTALLMENT_TOTAL_AMT AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,P2.INST_TOTAL_CFEE_RATE AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,P2.MERCHT_SCF_SERV_CHARGE_RATE AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,P2.MCH_SBDY_INSFSC_RATE AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,P2.MCH_SBDY_INSCF_AMT AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,P2.CHDER_INSFSC_RATE AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,P2.CHDER_INSCF_AMT AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,P2.MERCHT_SBDY_INSCF_AMT AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,P2.INSTALLMENT_PAY_TYPE_CD AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,P2.INSTALLMENT_TMS AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'IG' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_IG_UAS_PAY_SIMPLE_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'IG' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_IG_UAS_PAY_SIMPLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_IG.ODS_IG_UAS_PAY_SIMPLE_TA AS P1 -- 交易流水表

LEFT JOIN ODS_IG.ODS_IG_UAS_MERGE_PAYMENT_MAP_TA AS T1 -- 合并支付主子单映射表
       ON P1.TX_MSG_ID = T1.TX_MSG_ID AND T1.DEL_F = '0' AND T1.PT_DT='${process_date}' 
LEFT JOIN AGL.TMP_AGL_RECV_BIL_ORDER_DTL_TG_01 AS P2 -- 临时表
       ON P1.TX_MSG_ID = P2.TXN_SER_NO 
LEFT JOIN (SELECT * FROM(
SELECT
   ACCT_TYPE
  ,TX_AMT
  ,TXN_ID
  ,ROW_NUMBER() OVER(PARTITION BY TXN_ID ORDER BY GMT_MODIFIED DESC) RN
FROM ODS_SPS.ODS_SPS_SPS_PAY_SIMPLE_TA
WHERE TXN_STS = '01' AND PT_DT='${process_date}' AND DEL_F = '0'
)WHERE RN=1
) AS P3 -- 简水表
       ON P1.TX_MSG_ID = P3.TXN_ID 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 码值映射表
       ON P2.IN_BANK_SCENE_PLAT_CD=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='UPPRUN'  --源系统
AND S1.SRC_TAB_EN_NAME='UPP_PAY_SIMPLE_EXTEND'  --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='WP_CHNL_TP'   --来源字段英文名
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'   --目标表名  
AND S1.TARGET_FIELD_EN_NAME='IN_BANK_SCENE_PLAT_CD'  --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 码值映射表
       ON P1.TUNNEL_TYPE=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='IG' 
AND S2.SRC_TAB_EN_NAME='UAS_PAY_SIMPLE'
AND S2.SRC_FIELD_EN_NAME='TUNNEL_TYPE'
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND S2.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S3 -- 码值映射表
       ON P2.RECV_BIL_PAY_ACCT_LMT_TYPE_CD=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='UPPRUN'  --源系统
AND S3.SRC_TAB_EN_NAME='UPP_PAY_SIMPLE_EXTEND'  --来源表英文名  
AND S3.SRC_FIELD_EN_NAME='WP_MRCH_STLL_ACC_TP'   --来源字段英文名
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'   --目标表名  
AND S3.TARGET_FIELD_EN_NAME='RECV_BIL_PAY_ACCT_LMT_TYPE_CD'  --目标字段 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.SUBTRANSSEQNBR AS TXN_SER_NO -- 交易流水号
    ,P1.ORIGSUBTRANSSEQNBR AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime(CASE WHEN P1.DATELASTMAINT IS NULL OR P1.DATELASTMAINT='' THEN NULL ELSE P1.DATELASTMAINT END) AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TRANSTIME IS NULL OR P1.TRANSTIME='' THEN NULL ELSE P1.TRANSTIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TRANSDATE) AS TXN_DT -- 交易日期
    ,P1.MERSEQNBR AS CHNL_SER_NO -- 渠道流水号
    ,P1.ORIGSUBMERSEQNBR AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,unifiedTime(CASE WHEN P1.MERTRANSDATETIME IS NULL OR P1.MERTRANSDATETIME='' THEN NULL ELSE P1.MERTRANSDATETIME END) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.PAYTYPCD IS NULL OR TRIM(P1.PAYTYPCD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), '@'||TRIM(P1.PAYTYPCD),'') 
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.CURRENCYCD AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRANSAMT AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,P1.DEDUCTAMT AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TRANSTYPCD IS NULL OR TRIM(P1.TRANSTYPCD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S4.TARGET_CD_VAL), '@'||TRIM(P1.TRANSTYPCD),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TRANSSTATUS IS NULL OR TRIM(P1.TRANSSTATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TRANSSTATUS),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRANSSTATUS IS NULL OR TRIM(P1.TRANSSTATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANSSTATUS),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,CASE WHEN P1.REFUNDMODE IS NULL OR TRIM(P1.REFUNDMODE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.REFUNDMODE),'') 
END AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,P1.DISCOUNTABLEAMT AS CAN_DISCNT_AMT -- 可打折金额
    ,P1.UNDISCOUNTABLEAMT AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'1' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'1' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,P1.TRANSSEQNBR AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MERNBR,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MERNBR AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P1.MEROPENDEPTNBR AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,P1.MERSEQNBR AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.PAYEEACCTNBR AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.PAYEEACCTNAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,P1.PAYEEACCTDEPTNBR AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,CASE WHEN P1.PAYEEACCTKIND IS NULL OR TRIM(P1.PAYEEACCTKIND)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), '@'||TRIM(P1.PAYEEACCTKIND),'') 
END AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.PAYERACCTNBR AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAYERACCTNAME AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.PAYERACCTDEPTNBR AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,P1.CLIENTNO AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,P1.UNREFUNDAMT AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'EPAY' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_EPAY_ONLINESUBTRANS_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'EPAY' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_EPAY_ONLINESUBTRANS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_EPAY.ODS_EPAY_ONLINESUBTRANS_TA AS P1 -- 子交易明细历史表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TRANSSTATUS=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='EPAY'  --源系统
AND P2.SRC_TAB_EN_NAME='ONLINESUBTRANS'  --来源表英文名  
AND P2.SRC_FIELD_EN_NAME='TRANSSTATUS'   --来源字段英文名
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'   --目标表名  
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD'  --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANSSTATUS=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='EPAY' 
AND P3.SRC_TAB_EN_NAME='ONLINESUBTRANS'
AND P3.SRC_FIELD_EN_NAME='TRANSSTATUS'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 码值映射表
       ON P1.REFUNDMODE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='EPAY'  --源系统
AND S1.SRC_TAB_EN_NAME='ONLINESUBTRANS'  --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='REFUNDMODE'   --来源字段英文名
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'   --目标表名  
AND S1.TARGET_FIELD_EN_NAME='REFUND_MODE_CD'  --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 码值映射表
       ON P1.PAYEEACCTKIND=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='EPAY' 
AND S2.SRC_TAB_EN_NAME='ONLINESUBTRANS'
AND S2.SRC_FIELD_EN_NAME='PAYEEACCTKIND'
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND S2.TARGET_FIELD_EN_NAME='RECV_BIL_STL_ACCT_CATEGORY_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S3 -- 码值映射表
       ON P1.PAYTYPCD=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='EPAY' 
AND S3.SRC_TAB_EN_NAME='ONLINESUBTRANS'
AND S3.SRC_FIELD_EN_NAME='PAYTYPCD'
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND S3.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S4 -- 码值映射表
       ON P1.TRANSTYPCD=S4.SRC_CD_VAL  
AND S4.SRC_TAB_LIB_NAME ='EPAY' 
AND S4.SRC_TAB_EN_NAME='ONLINESUBTRANS'
AND S4.SRC_FIELD_EN_NAME='TRANSTYPCD'
AND S4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND S4.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSSEQNBR AS TXN_SER_NO -- 交易流水号
    ,'' AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime(CASE WHEN P1.DATELASTMAINT IS NULL OR P1.DATELASTMAINT='' THEN NULL ELSE P1.DATELASTMAINT END) AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TRANSTIME IS NULL OR P1.TRANSTIME='' THEN NULL ELSE P1.TRANSTIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TRANSDATE) AS TXN_DT -- 交易日期
    ,P1.MERSEQNBR AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,unifiedTime(CASE WHEN P1.MERTRANSDATETIME IS NULL OR P1.MERTRANSDATETIME='' THEN NULL ELSE P1.MERTRANSDATETIME END) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.PAYTYPCD IS NULL OR TRIM(P1.PAYTYPCD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.PAYTYPCD),'') 
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,P1.DEDUCTAMT AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TRANSCODE IS NULL OR TRIM(P1.TRANSCODE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.TRANSCODE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TRANSSTATUS IS NULL OR TRIM(P1.TRANSSTATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TRANSSTATUS),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRANSSTATUS IS NULL OR TRIM(P1.TRANSSTATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANSSTATUS),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,P1.DISCOUNTABLEAMT AS CAN_DISCNT_AMT -- 可打折金额
    ,P1.UNDISCOUNTABLEAMT AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'1' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,'' AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,P1.MERSEQNBR AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.PAYEEACCTNBR AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.PAYEEACCTNAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,P1.PAYEEACCTDEPTNBR AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.PAYERACCTNBR AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAYERACCTNAME AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.PAYERACCTDEPTNBR AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,P1.CLIENTNO AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'EPAY' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_EPAY_ONLINETRANSHIST_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'EPAY' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_EPAY_ONLINETRANSHIST_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_EPAY.ODS_EPAY_ONLINETRANSHIST_TA AS P1 -- 总交易明细历史表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TRANSSTATUS=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='EPAY' 
AND P2.SRC_TAB_EN_NAME='ONLINETRANSHIST'
AND P2.SRC_FIELD_EN_NAME='TRANSSTATUS'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANSSTATUS=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='EPAY' 
AND P3.SRC_TAB_EN_NAME='ONLINETRANSHIST'
AND P3.SRC_FIELD_EN_NAME='TRANSSTATUS'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.PAYTYPCD=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='EPAY' 
AND P4.SRC_TAB_EN_NAME='ONLINETRANSHIST'
AND P4.SRC_FIELD_EN_NAME='PAYTYPCD'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 码值映射表
       ON P1.TRANSCODE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='EPAY' 
AND S1.SRC_TAB_EN_NAME='ONLINETRANSHIST'
AND S1.SRC_FIELD_EN_NAME='TRANSCODE'
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND S1.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第4组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ORDER_ID AS TXN_SER_NO -- 交易流水号
    ,P1.ORGNL_ORDER_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,unifiedTime(CASE WHEN P1.BIZ_TIME IS NULL OR P1.BIZ_TIME='' THEN NULL ELSE P1.BIZ_TIME END) AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,unifiedTime(CASE WHEN P1.CREATE_TIME IS NULL OR P1.CREATE_TIME='' THEN NULL ELSE P1.CREATE_TIME END) AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime(CASE WHEN P1.UPDATE_TIME IS NULL OR P1.UPDATE_TIME='' THEN NULL ELSE P1.UPDATE_TIME END) AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,NULL AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,P1.ANAY_CHNL_ID AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,P1.TUNNEL AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.BIZ_AMOUNT_CCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.BIZ_AMOUNT AS TXN_AMT -- 交易金额
    ,'' AS PSBOOK_PAY_AMT -- 存折支付金额
    ,'' AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,'' AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,'' AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,'' AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,'' AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,'' AS EACCT_PAY_AMT -- 电子账户支付金额
    ,'' AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,'' AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,'' AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,'' AS RNDM_SUB_AMT -- 随机立减金额
    ,'' AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TRANS_TYPE IS NULL OR TRIM(P1.TRANS_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_TYPE),'')
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,P1.PURP_PRTRY AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.PAY_STATUS IS NULL OR TRIM(P1.PAY_STATUS)=''
     THEN ''
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.PAY_STATUS),'')
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.SUB_STATUS IS NULL OR TRIM(P1.SUB_STATUS)=''
     THEN ''
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.SUB_STATUS),'')
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS CAN_DISCNT_AMT -- 可打折金额
    ,'' AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,P1.ERROR_MSG AS ERR_RSN_ILUS -- 错误原因说明
    ,P1.ERROR_CODE AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,P1.USER_IP AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,CASE WHEN P1.TRANS_SCENE IS NULL OR TRIM(P1.TRANS_SCENE)=''
     THEN ''
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_SCENE),'')
END AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,P1.PRODUCT_DESC AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,P1.INVAL_DATE AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MERCH_ID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MERCH_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,'' AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,P1.CERT_TYPE AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,P1.CERT_NO AS BUYER_DOC_NO -- 买方证件号码
    ,'' AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,P1.LOGIN_ID AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,'' AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,'' AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,'' AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,'' AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,'' AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,'' AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,'' AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,'' AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,'' AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,P4.CHANNL_ID AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'SPS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_SPS_SP_PAY_ORDER_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_SPS_SP_PAY_ORDER_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_SPS.ODS_SPS_SP_PAY_ORDER_TA AS P1 -- 订单表

LEFT JOIN ODS_SPS.ODS_SPS_SP_BATCH_RECON_PARAM_TA AS P4 -- 参数表
       ON TRIM(P1.MERCH_ID)=TRIM(P4.CHANNL_MERCH_ID) AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON TRIM(P1.PAY_STATUS)=P2.SRC_CD_VAL
AND P2.SRC_TAB_LIB_NAME ='SPS'
AND P2.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND P2.SRC_FIELD_EN_NAME='PAY_STATUS'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON TRIM(P1.SUB_STATUS)=P3.SRC_CD_VAL 
AND P3.SRC_TAB_LIB_NAME ='SPS'
AND P3.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND P3.SRC_FIELD_EN_NAME='SUB_STATUS'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 码值映射表
       ON TRIM(P1.TRANS_TYPE)=S1.SRC_CD_VAL
AND S1.SRC_TAB_LIB_NAME ='SPS'
AND S1.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND S1.SRC_FIELD_EN_NAME='TRANS_TYPE'
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'
AND S1.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 码值映射表
       ON TRIM(P1.TRANS_SCENE)=S2.SRC_CD_VAL 
AND S2.SRC_TAB_LIB_NAME ='SPS'
AND S2.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND S2.SRC_FIELD_EN_NAME='TRANS_SCENE'
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'
AND S2.TARGET_FIELD_EN_NAME='PAY_SCENE_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第5组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.PSEQ AS TXN_SER_NO -- 交易流水号
    ,'' AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.PLAT_TIME IS NULL OR P1.PLAT_TIME='' THEN NULL ELSE P1.PLAT_TIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.TERM_TRANS_TRC AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,unifiedTime(SUBSTR(P1.TXNTIME,1,8)) AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.SYSPROCOD IN ('W00000001','W00000006','W00000008','W00000004','W00000009','W00000010','IFQ002001','IFQ002003')
     THEN 'WEIXIN'
     WHEN P1.SYSPROCOD IN ('A00000001','A00000006','A00000008','A00000004','A00000009','A00000010','IFQ001001','IFQ001003','AP00000003','AP00000005')
     THEN 'ALIPAY'
     WHEN P1.SYSPROCOD IN ('U00000001','U00000006','FPR000002','FPR000004','FPR000006','U00000004','FC0000006','FC0000001')
     THEN 'UNIONPAY'
     WHEN P1.SYSPROCOD IN ('Z00000001','Z00000006','Z00000008','Z00000004','UZ0000001','IFQ003001','IFQ003003')
     THEN 'ZJRCU'
     WHEN P1.SYSPROCOD IN ('T00000001','100323031','10383031','10383131','100333037','100383132','T00000007','T00000009','IF0000101','IF0000102','T000000012','T00000002','T00000003','T00000031','T00000025','T00000027','T00000028','T00000029','T00000022','T00000004','100373031','T00000005','T00000006','T00000008','T00000011','100383033','100333033','IF0000100','T00000015','C00000002','C00000004','C00000006','C00000008','F00000001') AND P1.YL_FLG = '0'
     THEN 'ZJRCU'
     WHEN P1.SYSPROCOD IN ('T00000001','100323031','10383031','10383131','100333037','100383132','T00000007','T00000009','IF0000101','IF0000102','T000000012','T00000002','T00000003','T00000031','T00000025','T00000027','T00000028','T00000029','T00000022','T00000004','100373031','T00000005','T00000006','T00000008','T00000011','100383033','100333033','IF0000100','T00000015','C00000002','C00000004','C00000006','C00000008','F00000001') AND P1.YL_FLG = '1'
     THEN 'UNIONPAY'
     ELSE ''
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.STDTRNSCUR AS TXN_CURR_CD -- 交易币种代码
    ,P1.STDTRNSAMT AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,P1.SYSPROCOD AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'')
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'')
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,CASE WHEN P1.SYSPROCOD IN ('T00000022','T00000025','W00000010','W00000009','A00000010','A00000009')
     THEN '1'
     ELSE '0'
END AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,P1.AUTH_NO AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,S1.TERMINAL_NO AS TXN_TERMN_CD -- 交易终端号
    ,P1.TERM_SEQ_ID AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,P1.ORDERNUMBER AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.OLD_ORDER_NUMBER AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.STDACCID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,P1.STDMCHTYP AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.STDACCID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.STDACCNAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P1.CUP_BRANCH_ID AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,P1.YL_MCHNT_ID AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.STDACC2 AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.STDPRIACC AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.OUT_ORG_CODE AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,P1.PAYER_ID AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,P1.TRNSSRC AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
FROM
(
SELECT
   PSEQ
  ,PLAT_TIME
  ,PLAT_DATE
  ,TERM_TRANS_TRC
  ,TXNTIME
  ,STDTRNSCUR
  ,STDTRNSAMT
  ,SYSPROCOD
  ,TRNSFLAG
  ,AUTH_NO
  ,STDTERMID
  ,TERM_SEQ_ID
  ,ORDERNUMBER
  ,OLD_ORDER_NUMBER
  ,STDACCID
  ,STDMCHTYP
  ,STDACCID
  ,STDACCNAME
  ,CUP_BRANCH_ID
  ,YL_MCHNT_ID
  ,STDACC2
  ,STDPRIACC
  ,OUT_ORG_CODE
  ,PAYER_ID
  ,PT_DT
  ,TRNSSRC
  ,YL_FLG
  ,ROW_NUMBER() OVER(PARTITION BY PSEQ ORDER BY ID DESC) RN
FROM ODS_POSP.ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA
WHERE PT_DT<='${process_date}'
AND PT_DT> '${interval_flow_dt}' AND DEL_F='0'
) AS P1 -- 流水表历史表

LEFT JOIN (
SELECT
   TERMINAL_NO
  ,TERM_SEQ
FROM ODS_POSP.ODS_POSP_ACPS_MGM_TERMINAL_INFO_TA
WHERE PT_DT='${process_date}' AND DEL_F='0'
) AS S1 -- 终端信息表
       ON P1.TERM_SEQ_ID=S1.TERM_SEQ 
LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON CAST(P1.TRNSFLAG AS STRING)=P2.SRC_CD_VAL 
AND P2.SRC_TAB_LIB_NAME ='POSP'
AND P2.SRC_TAB_EN_NAME='TBL_EPS_TRNS_OLDJOUR'
AND P2.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON CAST(P1.TRNSFLAG AS STRING)=P3.SRC_CD_VAL 
AND P3.SRC_TAB_LIB_NAME ='POSP'
AND P3.SRC_TAB_EN_NAME='TBL_EPS_TRNS_OLDJOUR'
AND P3.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG'
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.RN=1
;
-- ==============聚合层字段映射（第6组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.HOSTLS AS TXN_SER_NO -- 交易流水号
    ,'' AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TRANSTIME IS NULL OR P1.TRANSTIME='' THEN NULL ELSE P1.TRANSTIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TRANSDATE) AS TXN_DT -- 交易日期
    ,P1.TRACE AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,'ZJRCU' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,P1.INTEGRAL AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,P1.INTEGRAL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,'' AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TRANFLAG IS NULL OR TRIM(P1.TRANFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TRANFLAG),'')
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRANFLAG IS NULL OR TRIM(P1.TRANFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANFLAG),'')
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,P1.RESPDESC AS ERR_RSN_ILUS -- 错误原因说明
    ,P1.RESPCODE AS ERR_CD -- 错误编码
    ,P1.TERMID AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,P1.ORDERNUMBER AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MERID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MERID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P1.ORGID AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.CARDNO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_EPS_INTEGRAL_TRANS_LINE_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_EPS_INTEGRAL_TRANS_LINE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_EPS_INTEGRAL_TRANS_LINE_TA AS P1 -- 积分消费当日流水信息表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TRANFLAG=P2.SRC_CD_VAL 
AND P2.SRC_TAB_LIB_NAME ='POSP'
AND P2.SRC_TAB_EN_NAME='TBL_EPS_INTEGRAL_TRANS_LINE'
AND P2.SRC_FIELD_EN_NAME='TRANFLAG'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANFLAG=P3.SRC_CD_VAL 
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_EPS_INTEGRAL_TRANS_LINE'
AND P3.SRC_FIELD_EN_NAME='TRANFLAG'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第7组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.PSEQ AS TXN_SER_NO -- 交易流水号
    ,'' AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TRNS_TIME IS NULL OR P1.TRNS_TIME='' THEN NULL ELSE P1.TRNS_TIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.SERIAL AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,1 AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,'' AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'')
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'')
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,P1.TERM_NO AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MCHNT_NO,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MCHNT_NO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MCHNT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P1.INST_CODE AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.CARD_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_ACPS_MGM_RIGHTS_JOUR_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_ACPS_MGM_RIGHTS_JOUR_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,7 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_ACPS_MGM_RIGHTS_JOUR_TA AS P1 -- 权益活动流水表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON CAST(P1.TRNSFLAG AS STRING)=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='ACPS_MGM_RIGHTS_JOUR'
AND P2.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON CAST(P1.TRNSFLAG AS STRING)=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='ACPS_MGM_RIGHTS_JOUR'
AND P3.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第8组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSSEQNBR AS TXN_SER_NO -- 交易流水号
    ,'' AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TRANSTIME IS NULL OR P1.TRANSTIME='' THEN NULL ELSE P1.TRANSTIME END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(SUBSTR(P1.TRANSTIME,1,8)) AS TXN_DT -- 交易日期
    ,P1.TERM_SERIAL AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,'' AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'')
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'')
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,P1.TERM_NO AS TXN_TERMN_CD -- 交易终端号
    ,P1.TERM_SEQ AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MCHNT_NO,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MCHNT_NO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MCHNT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P1.INST_CODE AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.CARD_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_EPS_JUANMA_JOUR_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_EPS_JUANMA_JOUR_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,8 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_EPS_JUANMA_JOUR_TA AS P1 -- 券码核销流水表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TRNSFLAG=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_EPS_JUANMA_JOUR'
AND P2.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRNSFLAG=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_EPS_JUANMA_JOUR'
AND P3.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0' 
;
-- ==============聚合层字段映射（第9组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.OGL_ORD_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TXN_TM IS NULL OR P1.TXN_TM='' THEN NULL ELSE P1.TXN_TM END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.MER_ORDER_ID AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,CASE WHEN P1.TXN_CHANNEL IS NULL OR TRIM(P1.TXN_CHANNEL)=''
     THEN ''
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.TXN_CHANNEL),'')
END AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.PAY_ACCESS_TYPE IS NULL OR TRIM(P1.PAY_ACCESS_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(P6.TARGET_CD_VAL), '@'||TRIM(P1.PAY_ACCESS_TYPE),'')
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,unifiedTime(P1.CORE_DATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.CURRENCY_CODE AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRADE_MONEY AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'')
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)=''
     THEN ''
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'')
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)=''
     THEN ''
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'')
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,P1.DISCOUNTABLE_AMOUNT AS CAN_DISCNT_AMT -- 可打折金额
    ,P1.UNDISCOUNTABLE_AMOUNT AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MER_ID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CONCAT(SUBSTR(P1.MER_ID,1,3),'000') AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.RESERVE4 AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,P1.PAYERID AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,S1.EWM_SEQ AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_ORDER_TXN_HIS_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_ORDER_TXN_HIS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,9 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_ORDER_TXN_HIS_TA AS P1 -- 订单支付信息登记表

LEFT JOIN (
SELECT
   EWM_SEQ
  ,EWM_DATA
FROM ODS_POSP.ODS_POSP_TBL_STATIC_EWM_THREE_CODE_INFO_TA
WHERE PT_DT='${process_date}' AND DEL_F='0'
) AS S1 -- 三码合一静态二维码表
       ON P1.EWM_DATA=S1.EWM_DATA 
LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TXN_TYPE=P2.SRC_CD_VAL 
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P2.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_STA=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P3.SRC_FIELD_EN_NAME='TXN_STA'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TXN_STA=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P4.SRC_FIELD_EN_NAME='TXN_STA'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.TXN_CHANNEL=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP' 
AND P5.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P5.SRC_FIELD_EN_NAME='TXN_CHANNEL'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P5.TARGET_FIELD_EN_NAME='TXN_CHNL_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P6 -- 码值映射表
       ON P1.PAY_ACCESS_TYPE=P6.SRC_CD_VAL  
AND P6.SRC_TAB_LIB_NAME ='POSP' 
AND P6.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P6.SRC_FIELD_EN_NAME='PAY_ACCESS_TYPE'
AND P6.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P6.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0' 
;
-- ==============聚合层字段映射（第10组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.OGL_ORD_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TXN_TM IS NULL OR P1.TXN_TM='' THEN NULL ELSE P1.TXN_TM END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.MER_ORDER_ID AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,CASE WHEN P1.TXN_CHANNEL IS NULL OR TRIM(P1.TXN_CHANNEL)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.TXN_CHANNEL),'') 
END AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.PAY_ACCESS_TYPE='02' THEN '04'
     WHEN P1.PAY_ACCESS_TYPE='03' THEN '01'
     WHEN P1.PAY_ACCESS_TYPE IN ('04','01') THEN '05'
     WHEN P1.PAY_ACCESS_TYPE IN ('05','06') THEN '03'
     ELSE ''
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,unifiedTime(P1.CORE_DATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.CURRENCY_CODE AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRADE_MONEY AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)=''
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,P1.TERM_ID AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,P1.SOURCE_IP  AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MER_ID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,P1.MER_CAT_CODE AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MER_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CONCAT(SUBSTR(P1.MER_ID,1,3),'000') AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.ACCOUNT_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P1.ACC_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,P1.MOBILE AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,S1.EWM_SEQ AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_C2B_ORDER_TXN_HIS_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_C2B_ORDER_TXN_HIS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,10 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_C2B_ORDER_TXN_HIS_TA AS P1 -- 银联二维码订单支付信息登记表

LEFT JOIN (
SELECT
   EWM_SEQ
  ,EWM_DATA
FROM ODS_POSP.ODS_POSP_TBL_STATIC_EWM_THREE_CODE_INFO_TA
WHERE PT_DT='${process_date}' AND DEL_F='0'
) AS S1 -- 三码合一静态二维码表
       ON P1.QR_NO=S1.EWM_DATA 
LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TXN_TYPE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P2.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_STA=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P3.SRC_FIELD_EN_NAME='TXN_STA'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TXN_STA=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P4.SRC_FIELD_EN_NAME='TXN_STA'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.TXN_CHANNEL=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP' 
AND P5.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P5.SRC_FIELD_EN_NAME='TXN_CHANNEL'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P5.TARGET_FIELD_EN_NAME='TXN_CHNL_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0' 
;
-- ==============聚合层字段映射（第11组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.OGL_ORD_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TXN_TM IS NULL OR P1.TXN_TM='' THEN NULL ELSE P1.TXN_TM END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.MER_ORDER_ID AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,'WEIXIN' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,unifiedTime(CASE WHEN P1.SETTLE_DATE IS NULL OR P1.SETTLE_DATE='' THEN NULL ELSE P1.SETTLE_DATE END) AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.CURRENCY_CODE AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRADE_MONEY AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'') 
END  AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MER_ID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CONCAT(SUBSTR(P1.MER_ID,1,3),'000') AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,P1.PAYERID AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_ZN_WX_ORDER_TXN_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_ZN_WX_ORDER_TXN_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,11 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_ZN_WX_ORDER_TXN_TA AS P1 -- 智能支付系统微信订单流水表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TXN_TYPE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_ZN_WX_ORDER_TXN'
AND P2.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_STA=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_ZN_WX_ORDER_TXN'
AND P3.SRC_FIELD_EN_NAME='TXN_STA'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TXN_STA=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_ZN_WX_ORDER_TXN'
AND P4.SRC_FIELD_EN_NAME='TXN_STA'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第12组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.OGL_ORD_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TXN_TM IS NULL OR P1.TXN_TM='' THEN NULL ELSE P1.TXN_TM END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.ORDER_BODY AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.PAY_ACCESS_TYPE='02' THEN '04'
     WHEN P1.PAY_ACCESS_TYPE='03' THEN '01'
     WHEN P1.PAY_ACCESS_TYPE='04' THEN '05'
     WHEN P1.PAY_ACCESS_TYPE='05' THEN '03'
     ELSE ''
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,P1.CURRENCY_CODE AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRADE_MONEY AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,P1.DISCOUNTABLE_AMOUNT AS CAN_DISCNT_AMT -- 可打折金额
    ,P1.UNDISCOUNTABLE_AMOUNT AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,'' AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,P1.SPBILL_CREATE_IP AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,P1.MER_ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MER_ID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MER_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CONCAT(SUBSTR(P1.MER_ID,1,3),'000') AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.ACCT_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,'' AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,'' AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_POLYMER_ORDER_TXN_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_POLYMER_ORDER_TXN_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,12 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_POLYMER_ORDER_TXN_TA AS P1 -- 聚合支付流水表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TXN_TYPE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_POLYMER_ORDER_TXN'
AND P2.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_STA=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_POLYMER_ORDER_TXN'
AND P3.SRC_FIELD_EN_NAME='TXN_STA'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TXN_STA=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_POLYMER_ORDER_TXN'
AND P4.SRC_FIELD_EN_NAME='TXN_STA'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0' 
;
-- ==============聚合层字段映射（第13组）==============
-- 收单订单明细聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TXN_DT -- 交易日期
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CNAPS_SER_NO -- 支付系统流水号
    ,ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,CNAPS_TXN_DT -- 支付系统交易日期
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,CORE_ACCTN_DT -- 核心记账日期
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,PSBOOK_PAY_AMT -- 存折支付金额
    ,DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,EACCT_PAY_AMT -- 电子账户支付金额
    ,KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,POINT_DEDUCT_AMT -- 积分抵扣金额
    ,RNDM_SUB_AMT -- 随机立减金额
    ,CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,SHOULD_STL_AMT -- 应结金额
    ,CAN_DISCNT_AMT -- 可打折金额
    ,NO_DISCNT_AMT -- 不可打折金额
    ,CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,COURT_MNY_FLAG -- 法院案款标志
    ,PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,AUTH_CD -- 授权码
    ,PRE_AUTH_CD -- 预授权码
    ,PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,MERGE_PAY_FLAG -- 合并支付标志
    ,FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,FATHER_TXN_SER_NO -- 父交易流水号
    ,ERR_RSN_ILUS -- 错误原因说明
    ,ERR_CD -- 错误编码
    ,TXN_TERMN_CD -- 交易终端号
    ,TERMN_SN -- 终端序列号
    ,CD_BRAND_TYPE_CD -- 码牌类型代码
    ,ASSIS_EQUIP_NO -- 辅助设备号
    ,TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,USER_IP_ADDR -- 用户IP地址
    ,USER_MAC_ADDR -- 用户MAC地址
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,PAY_SCENE_CD -- 支付场景代码
    ,BASIC_PROD_NO -- 基础产品编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,MERCHD_DESC -- 商品描述
    ,ORDER_REM -- 订单备注
    ,ORDER_TITLE_NAME -- 订单标题名称
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,MERCHT_STORE_NO -- 商户门店编号
    ,BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,ZFB_SHOP_NO -- 支付宝店铺编号
    ,MERCHT_OPERR_NO -- 商户操作员编号
    ,MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,MERCHT_TEL_NO -- 商户电话号码
    ,RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,APPLY_NO -- 应用编号
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,SERV_PROVDER_NAME -- 服务商名称
    ,CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,BUYER_NAME -- 买方名称
    ,BUYER_MOBILE_NO -- 买方手机号码
    ,BUYER_DOCTYP_CD -- 买方证件类型代码
    ,BUYER_DOC_NO -- 买方证件号码
    ,BUYER_MIN_AGE -- 买方最小年龄
    ,BUYER_CUST_NO -- 买方客户编号
    ,MNY_USER_ID -- 案款用户ID
    ,BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,BUYER_IDTFY_IDNT -- 买方识别标识
    ,INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,INSTALLMENT_TMS -- 分期期数
    ,RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,UN_RTN_GOODS_AMT -- 未退货金额
    ,STAT_QR_CD_SN -- 静态二维码序列号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.OGL_ORD_ID AS ORIG_TXN_SER_NO -- 原交易流水号
    ,NULL AS TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,NULL AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,NULL AS TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,unifiedTime(CASE WHEN P1.TXN_TM IS NULL OR P1.TXN_TM='' THEN NULL ELSE P1.TXN_TM END) AS TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,NULL AS ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.MER_ORDER_ID AS CHNL_SER_NO -- 渠道流水号
    ,'' AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,NULL AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,NULL AS CNAPS_TXN_DT -- 支付系统交易日期
    ,CASE WHEN P1.PAY_ACCESS_TYPE='02' THEN '04'
     WHEN P1.PAY_ACCESS_TYPE='03' THEN '01'
     ELSE ''
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,NULL AS PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,unifiedTime(P1.CORE_DATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRADE_MONEY AS TXN_AMT -- 交易金额
    ,NULL AS PSBOOK_PAY_AMT -- 存折支付金额
    ,NULL AS DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,NULL AS SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,NULL AS THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,NULL AS CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,NULL AS OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,NULL AS EACCT_PAY_AMT -- 电子账户支付金额
    ,NULL AS KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,NULL AS FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,NULL AS POINT_DEDUCT_AMT -- 积分抵扣金额
    ,NULL AS RNDM_SUB_AMT -- 随机立减金额
    ,NULL AS CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,NULL AS SHOULD_STL_AMT -- 应结金额
    ,NULL AS CAN_DISCNT_AMT -- 可打折金额
    ,NULL AS NO_DISCNT_AMT -- 不可打折金额
    ,'' AS CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,CASE WHEN P1.TXN_CHANNEL = '6008'
     THEN '1'
     ELSE '0'
END AS COURT_MNY_FLAG -- 法院案款标志
    ,'' AS PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,'' AS AUTH_CD -- 授权码
    ,'' AS PRE_AUTH_CD -- 预授权码
    ,'' AS PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,'' AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,'0' AS MERGE_PAY_FLAG -- 合并支付标志
    ,'0' AS FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,'' AS FATHER_TXN_SER_NO -- 父交易流水号
    ,'' AS ERR_RSN_ILUS -- 错误原因说明
    ,'' AS ERR_CD -- 错误编码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,'' AS TERMN_SN -- 终端序列号
    ,'' AS CD_BRAND_TYPE_CD -- 码牌类型代码
    ,'' AS ASSIS_EQUIP_NO -- 辅助设备号
    ,'' AS TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,'' AS TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,'' AS MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,'' AS APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,'' AS MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,'' AS CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,'' AS USER_IP_ADDR -- 用户IP地址
    ,'' AS USER_MAC_ADDR -- 用户MAC地址
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS PAY_SCENE_CD -- 支付场景代码
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,P1.ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,'' AS MERCHD_DESC -- 商品描述
    ,'' AS ORDER_REM -- 订单备注
    ,'' AS ORDER_TITLE_NAME -- 订单标题名称
    ,NULL AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,CONCAT(P1.MER_ID,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CONCAT(SUBSTR(P1.MER_ID,1,3),'000') AS SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,'' AS MERCHT_STORE_NO -- 商户门店编号
    ,'' AS BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,'' AS THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,'' AS SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,'' AS SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,'' AS ZFB_SHOP_NO -- 支付宝店铺编号
    ,'' AS MERCHT_OPERR_NO -- 商户操作员编号
    ,'' AS MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,'' AS MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,'' AS MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,'' AS MERCHT_TEL_NO -- 商户电话号码
    ,'' AS RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,'' AS APPLY_NO -- 应用编号
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,'' AS CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,'' AS MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,'' AS MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,P1.ACC_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,'' AS RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,'' AS EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,'' AS EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,'' AS EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,'' AS EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,'' AS COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,P1.COURT_NAME AS BUYER_NAME -- 买方名称
    ,'' AS BUYER_MOBILE_NO -- 买方手机号码
    ,'' AS BUYER_DOCTYP_CD -- 买方证件类型代码
    ,'' AS BUYER_DOC_NO -- 买方证件号码
    ,NULL AS BUYER_MIN_AGE -- 买方最小年龄
    ,'' AS BUYER_CUST_NO -- 买方客户编号
    ,'' AS MNY_USER_ID -- 案款用户ID
    ,'' AS BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,P1.PAYERID AS BUYER_IDTFY_IDNT -- 买方识别标识
    ,NULL AS INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,NULL AS INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,NULL AS MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,NULL AS MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,NULL AS MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,NULL AS CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,NULL AS CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,NULL AS MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,'' AS INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,NULL AS INSTALLMENT_TMS -- 分期期数
    ,'' AS RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,'' AS RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,NULL AS UN_RTN_GOODS_AMT -- 未退货金额
    ,'' AS STAT_QR_CD_SN -- 静态二维码序列号
    ,'POSP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_POSP_TBL_COMMON_ORDER_TXN_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,P1.PT_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'ODS_POSP_TBL_COMMON_ORDER_TXN_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,13 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_COMMON_ORDER_TXN_TA AS P1 -- 公共订单流水表

LEFT JOIN AGL.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TXN_TYPE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_COMMON_ORDER_TXN'
AND P2.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_TYPE_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_STA=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_COMMON_ORDER_TXN'
AND P3.SRC_FIELD_EN_NAME='TXN_STA'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TXN_STA=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_COMMON_ORDER_TXN'
AND P4.SRC_FIELD_EN_NAME='TXN_STA'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ORDER_DTL_TG' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT <='${process_date}' AND P1.PT_DT> '${interval_flow_dt}'   AND P1.DEL_F='0'
;

/* 4.1 drop target table's period partition */
ALTER TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG DROP IF EXISTS PARTITION(PT_DT > '${interval_flow_dt}');

/* 4.2 put data into target table */
INSERT INTO AGL.AGL_RECV_BIL_ORDER_DTL_TG
SELECT
     TM.TXN_SER_NO -- 交易流水号
    ,TM.ORIG_TXN_SER_NO -- 原交易流水号
    ,TM.TXN_RECV_TM_STAMP -- 交易接收时间戳
    ,TM.TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TM.TXN_UPDATE_TM_STAMP -- 交易更新时间戳
    ,TM.TXN_CMPLT_TM_STAMP -- 交易完成时间戳
    ,TM.ORIG_TXN_RECV_TM_STAMP -- 原交易接收时间戳
    ,TM.TXN_DT -- 交易日期
    ,TM.CHNL_SER_NO -- 渠道流水号
    ,TM.ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TM.TXN_CHNL_CD -- 交易渠道代码
    ,TM.RECV_BIL_TXN_DATA_SRC_CHNL_CD -- 收单交易数据来源渠道代码
    ,TM.IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,TM.CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,TM.CNAPS_SER_NO -- 支付系统流水号
    ,TM.ORIG_CNAPS_SER_NO -- 原支付系统流水号
    ,TM.CNAPS_TXN_DT -- 支付系统交易日期
    ,TM.RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,TM.PASS_RETURN_SER_NO -- 通道返回流水号
    ,TM.PASS_TXN_TM_STAMP -- 通道交易时间戳
    ,TM.CORE_ACCTN_DT -- 核心记账日期
    ,TM.TXN_CURR_CD -- 交易币种代码
    ,TM.TXN_AMT -- 交易金额
    ,TM.PSBOOK_PAY_AMT -- 存折支付金额
    ,TM.DEBIT_CARD_PAY_AMT -- 借记卡支付金额
    ,TM.SCD_SSC_PAY_AMT -- 二代社保卡支付金额
    ,TM.THIRD_SSC_PAY_AMT -- 第三代社保卡支付金额
    ,TM.CRDT_CARD_PAY_AMT -- 贷记卡支付金额
    ,TM.OBANK_CRDT_CARD_INSPAY_AMT -- 本行信用卡分期支付金额
    ,TM.EACCT_PAY_AMT -- 电子账户支付金额
    ,TM.KINSHIP_WALLET_PAY_AMT -- 亲情钱包支付金额
    ,TM.FLOW_HEART_COST_PAY_AMT -- 随心花支付金额
    ,TM.POINT_DEDUCT_AMT -- 积分抵扣金额
    ,TM.RNDM_SUB_AMT -- 随机立减金额
    ,TM.CUPNS_CARD_DEDUCT_AMT -- 卡券抵扣金额
    ,TM.RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TM.RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,TM.RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,TM.RECV_BIL_SYS_TASK_TYPE_CD -- 收单系统任务类型代码
    ,TM.RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,TM.RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,TM.REFUND_MODE_CD -- 退款模式代码
    ,TM.SHOULD_STL_AMT -- 应结金额
    ,TM.CAN_DISCNT_AMT -- 可打折金额
    ,TM.UN_RTN_GOODS_AMT -- 未退货金额
    ,TM.NO_DISCNT_AMT -- 不可打折金额
    ,TM.CFM_RECV_GOOD_FLAG -- 确认收货标志
    ,TM.COURT_MNY_FLAG -- 法院案款标志
    ,TM.PRE_AUTH_SCENE_CD -- 预授权场景代码
    ,TM.AUTH_CD -- 授权码
    ,TM.PRE_AUTH_CD -- 预授权码
    ,TM.PRE_AUTH_CFM_MODE_CD -- 预授权确认模式代码
    ,TM.PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,TM.MERGE_PAY_FLAG -- 合并支付标志
    ,TM.FATHER_TXN_FLOW_FLAG -- 父交易流水标志
    ,TM.FATHER_TXN_SER_NO -- 父交易流水号
    ,TM.ERR_RSN_ILUS -- 错误原因说明
    ,TM.ERR_CD -- 错误编码
    ,TM.TXN_TERMN_CD -- 交易终端号
    ,TM.TERMN_SN -- 终端序列号
    ,TM.CD_BRAND_TYPE_CD -- 码牌类型代码
    ,TM.ASSIS_EQUIP_NO -- 辅助设备号
    ,TM.TERMN_REAL_TM_LTLN_INFO_DESC -- 终端实时经纬度信息描述
    ,TM.TERMN_NET_IN_CERT_NO -- 终端入网认证编号
    ,TM.MERCHT_POINT_EQUIP_TYPE_CD -- 商户端设备类型代码
    ,TM.APP_PROGRAM_VER_NO -- 应用程序版本编号
    ,TM.MERCHT_POINT_EQUIP_IP_ADDR -- 商户端设备IP地址
    ,TM.CAN_OPEN_ELEC_INVOICE_FLAG -- 可开电子发票标志
    ,TM.USER_IP_ADDR -- 用户IP地址
    ,TM.USER_MAC_ADDR -- 用户MAC地址
    ,TM.RECV_BIL_PROD_NO -- 收单产品编号
    ,TM.PAY_SCENE_CD -- 支付场景代码
    ,TM.BASIC_PROD_NO -- 基础产品编号
    ,TM.MERCHT_ORDER_NO -- 商户订单编号
    ,TM.ORIG_MERCHT_ORDER_NO -- 原商户订单编号
    ,TM.MERCHD_DESC -- 商品描述
    ,TM.ORDER_REM -- 订单备注
    ,TM.ORDER_TITLE_NAME -- 订单标题名称
    ,TM.ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,TM.MERCHT_TYPE_CD -- 商户类型代码
    ,TM.MERCHT_IDTFY_NO -- 商户识别编号
    ,TM.MERCHT_NO -- 商户编号
    ,TM.SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,TM.SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,TM.SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,TM.SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,TM.SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,TM.SPC_ARGMT_MERCHT_AFLT_ORG_NO -- 特约商户所属机构编号
    ,TM.MERCHT_STORE_NO -- 商户门店编号
    ,TM.BIZ_SMALL_RECEIPT_TYPE_CD -- 商家小票类型代码
    ,TM.THIRD_PTY_MERCHT_NO -- 第三方商户编号
    ,TM.SUB_MERCHT_PUB_ACCT_NO -- 子商户公众账户编号
    ,TM.SELLER_ZFB_USER_ID -- 卖家支付宝用户ID
    ,TM.ZFB_SHOP_NO -- 支付宝店铺编号
    ,TM.MERCHT_OPERR_NO -- 商户操作员编号
    ,TM.MERCHT_RGN_INFO_CD -- 商户区域信息编码
    ,TM.MERCHT_WALLET_MODE_CD -- 商户钱包模式代码
    ,TM.MERCHT_BIZ_SER_NO -- 商户业务流水号
    ,TM.MERCHT_TEL_NO -- 商户电话号码
    ,TM.RECV_BIL_ORG_IDTFY_IDNT -- 收单机构识别标识
    ,TM.APPLY_NO -- 应用编号
    ,TM.SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,TM.SERV_PROVDER_CHNL_NO -- 服务商渠道编号
    ,TM.SERV_PROVDER_APP_ID -- 服务商APPID
    ,TM.SERV_PROVDER_NAME -- 服务商名称
    ,TM.CHNL_MERCHT_MERCHT_NO -- 渠道商商户编号
    ,TM.CHNL_MERCHT_MERCHT_NAME -- 渠道商商户名称
    ,TM.MCH_RECV_BIL_WAIT_STL_ACCT_NO -- 行社收单待结算账户编号
    ,TM.MCH_RBCSA_NAME -- 行社收单待结算账户名称
    ,TM.RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,TM.RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,TM.RECV_BIL_STL_ACCT_NO_OPBANK_NO -- 收单结算账号开户行行号
    ,TM.RBSA_OPBK_NAME -- 收单结算账号开户行名称
    ,TM.RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,TM.PAY_FUND_ACCT_NO -- 付款账户编号
    ,TM.PAY_ACCT_NAME -- 付款账户名称
    ,TM.PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,TM.PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,TM.RECV_BIL_PAY_ACCT_LMT_TYPE_CD -- 收单付款账户限制类型代码
    ,TM.EXCESS_REFUND_DEBIT_ACCT_NO -- 超额退款借方账户编号
    ,TM.EXCESS_REFUND_DEBIT_ACCT_NAME -- 超额退款借方账户名称
    ,TM.EXCESS_REFUND_DEBIT_ORG_NO -- 超额退款借方机构编号
    ,TM.EXCESS_REFUND_CRDT_ACCT_NO -- 超额退款贷方账户编号
    ,TM.EXCESS_REFUND_CRDT_ACCT_NAME -- 超额退款贷方账户名称
    ,TM.EXCESS_REFUND_CRDT_ORG_NO -- 超额退款贷方机构编号
    ,TM.COURT_MNY_ACCT_NO -- 法院案款虚账户编号
    ,TM.BUYER_NAME -- 买方名称
    ,TM.BUYER_MOBILE_NO -- 买方手机号码
    ,TM.BUYER_DOCTYP_CD -- 买方证件类型代码
    ,TM.BUYER_DOC_NO -- 买方证件号码
    ,TM.BUYER_MIN_AGE -- 买方最小年龄
    ,TM.BUYER_CUST_NO -- 买方客户编号
    ,TM.MNY_USER_ID -- 案款用户ID
    ,TM.BUYER_LOGIN_ACCT_NO -- 买方登录账号
    ,TM.BUYER_IDTFY_IDNT -- 买方识别标识
    ,TM.INSTALLMENT_TOTAL_AMT -- 分期总金额
    ,TM.INST_TOTAL_CFEE_RATE -- 分期付款总手续费费率
    ,TM.MERCHT_SCF_SERV_CHARGE_RATE -- 商户补贴手续费费率
    ,TM.MCH_SBDY_INSFSC_RATE -- 行社补贴分期费费率
    ,TM.MCH_SBDY_INSCF_AMT -- 行社补贴分期手续费金额
    ,TM.CHDER_INSFSC_RATE -- 持卡人分期费费率
    ,TM.CHDER_INSCF_AMT -- 持卡人分期手续费金额
    ,TM.MERCHT_SBDY_INSCF_AMT -- 商户补贴分期手续费金额
    ,TM.INSTALLMENT_PAY_TYPE_CD -- 分期支付类型代码
    ,TM.INSTALLMENT_TMS -- 分期期数
    ,TM.STAT_QR_CD_SN -- 静态二维码序列号
    ,TM.B_SRC_SYS_CD -- 业务来源系统代码
    ,TM.B_SRC_TAB_EN_NAME -- 业务来源英文名称
    ,TM.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,TM.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,TM.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上,更新ETL_LAST_ACG_DT
     WHEN BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.TXN_DT,'') = COALESCE(BF.TXN_DT,'') -- 交易日期 非主键字段相等
         AND COALESCE(TM.CHNL_SER_NO,'') = COALESCE(BF.CHNL_SER_NO,'') -- 渠道流水号 非主键字段相等
         AND COALESCE(TM.ORIG_CHNL_SER_NO,'') = COALESCE(BF.ORIG_CHNL_SER_NO,'') -- 原渠道流水号 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_TXN_DATA_SRC_CHNL_CD,'') = COALESCE(BF.RECV_BIL_TXN_DATA_SRC_CHNL_CD,'') -- 收单交易数据来源渠道代码 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段相等
         AND COALESCE(TM.CHNL_TXN_TM_STAMP,'') = COALESCE(BF.CHNL_TXN_TM_STAMP,'') -- 渠道交易时间戳 非主键字段相等
         AND COALESCE(TM.CNAPS_SER_NO,'') = COALESCE(BF.CNAPS_SER_NO,'') -- 支付系统流水号 非主键字段相等
         AND COALESCE(TM.ORIG_CNAPS_SER_NO,'') = COALESCE(BF.ORIG_CNAPS_SER_NO,'') -- 原支付系统流水号 非主键字段相等
         AND COALESCE(TM.CNAPS_TXN_DT,'') = COALESCE(BF.CNAPS_TXN_DT,'') -- 支付系统交易日期 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_PASS_TYPE_CD,'') = COALESCE(BF.RECV_BIL_STL_PASS_TYPE_CD,'') -- 收单结算通道类型代码 非主键字段相等
         AND COALESCE(TM.PASS_RETURN_SER_NO,'') = COALESCE(BF.PASS_RETURN_SER_NO,'') -- 通道返回流水号 非主键字段相等
         AND COALESCE(TM.PASS_TXN_TM_STAMP,'') = COALESCE(BF.PASS_TXN_TM_STAMP,'') -- 通道交易时间戳 非主键字段相等
         AND COALESCE(TM.CORE_ACCTN_DT,'') = COALESCE(BF.CORE_ACCTN_DT,'') -- 核心记账日期 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段相等
         AND COALESCE(TM.PSBOOK_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.PSBOOK_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 存折支付金额 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DEBIT_CARD_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 借记卡支付金额 非主键字段相等
         AND COALESCE(TM.SCD_SSC_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.SCD_SSC_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 二代社保卡支付金额 非主键字段相等
         AND COALESCE(TM.THIRD_SSC_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.THIRD_SSC_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 第三代社保卡支付金额 非主键字段相等
         AND COALESCE(TM.CRDT_CARD_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CRDT_CARD_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 贷记卡支付金额 非主键字段相等
         AND COALESCE(TM.OBANK_CRDT_CARD_INSPAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.OBANK_CRDT_CARD_INSPAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 本行信用卡分期支付金额 非主键字段相等
         AND COALESCE(TM.EACCT_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.EACCT_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 电子账户支付金额 非主键字段相等
         AND COALESCE(TM.KINSHIP_WALLET_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.KINSHIP_WALLET_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 亲情钱包支付金额 非主键字段相等
         AND COALESCE(TM.FLOW_HEART_COST_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FLOW_HEART_COST_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 随心花支付金额 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.POINT_DEDUCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 积分抵扣金额 非主键字段相等
         AND COALESCE(TM.RNDM_SUB_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RNDM_SUB_AMT,CAST(0 AS DECIMAL(28,2))) -- 随机立减金额 非主键字段相等
         AND COALESCE(TM.CUPNS_CARD_DEDUCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CUPNS_CARD_DEDUCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 卡券抵扣金额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_TXN_TYPE_CD,'') = COALESCE(BF.RECV_BIL_TXN_TYPE_CD,'') -- 收单交易类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_BIZ_TYPE_CD,'') = COALESCE(BF.RECV_BIL_BIZ_TYPE_CD,'') -- 收单业务类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_BIZ_CATE_CD,'') = COALESCE(BF.RECV_BIL_BIZ_CATE_CD,'') -- 收单业务种类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_SYS_TASK_TYPE_CD,'') = COALESCE(BF.RECV_BIL_SYS_TASK_TYPE_CD,'') -- 收单系统任务类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_TXN_MAIN_STATUS_CD,'') = COALESCE(BF.RECV_BIL_TXN_MAIN_STATUS_CD,'') -- 收单交易主状态代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_TXN_SUB_STATUS_CD,'') = COALESCE(BF.RECV_BIL_TXN_SUB_STATUS_CD,'') -- 收单交易子状态代码 非主键字段相等
         AND COALESCE(TM.REFUND_MODE_CD,'') = COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段相等
         AND COALESCE(TM.SHOULD_STL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.SHOULD_STL_AMT,CAST(0 AS DECIMAL(28,2))) -- 应结金额 非主键字段相等
         AND COALESCE(TM.CAN_DISCNT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CAN_DISCNT_AMT,CAST(0 AS DECIMAL(28,2))) -- 可打折金额 非主键字段相等
         AND COALESCE(TM.UN_RTN_GOODS_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.UN_RTN_GOODS_AMT,CAST(0 AS DECIMAL(28,2))) -- 未退货金额 非主键字段相等
         AND COALESCE(TM.NO_DISCNT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.NO_DISCNT_AMT,CAST(0 AS DECIMAL(28,2))) -- 不可打折金额 非主键字段相等
         AND COALESCE(TM.CFM_RECV_GOOD_FLAG,'') = COALESCE(BF.CFM_RECV_GOOD_FLAG,'') -- 确认收货标志 非主键字段相等
         AND COALESCE(TM.COURT_MNY_FLAG,'') = COALESCE(BF.COURT_MNY_FLAG,'') -- 法院案款标志 非主键字段相等
         AND COALESCE(TM.PRE_AUTH_SCENE_CD,'') = COALESCE(BF.PRE_AUTH_SCENE_CD,'') -- 预授权场景代码 非主键字段相等
         AND COALESCE(TM.AUTH_CD,'') = COALESCE(BF.AUTH_CD,'') -- 授权码 非主键字段相等
         AND COALESCE(TM.PRE_AUTH_CD,'') = COALESCE(BF.PRE_AUTH_CD,'') -- 预授权码 非主键字段相等
         AND COALESCE(TM.PRE_AUTH_CFM_MODE_CD,'') = COALESCE(BF.PRE_AUTH_CFM_MODE_CD,'') -- 预授权确认模式代码 非主键字段相等
         AND COALESCE(TM.PAY_MODE_TYPE_CD,'') = COALESCE(BF.PAY_MODE_TYPE_CD,'') -- 支付模式类型代码 非主键字段相等
         AND COALESCE(TM.MERGE_PAY_FLAG,'') = COALESCE(BF.MERGE_PAY_FLAG,'') -- 合并支付标志 非主键字段相等
         AND COALESCE(TM.FATHER_TXN_FLOW_FLAG,'') = COALESCE(BF.FATHER_TXN_FLOW_FLAG,'') -- 父交易流水标志 非主键字段相等
         AND COALESCE(TM.FATHER_TXN_SER_NO,'') = COALESCE(BF.FATHER_TXN_SER_NO,'') -- 父交易流水号 非主键字段相等
         AND COALESCE(TM.ERR_RSN_ILUS,'') = COALESCE(BF.ERR_RSN_ILUS,'') -- 错误原因说明 非主键字段相等
         AND COALESCE(TM.ERR_CD,'') = COALESCE(BF.ERR_CD,'') -- 错误编码 非主键字段相等
         AND COALESCE(TM.TXN_TERMN_CD,'') = COALESCE(BF.TXN_TERMN_CD,'') -- 交易终端号 非主键字段相等
         AND COALESCE(TM.TERMN_SN,'') = COALESCE(BF.TERMN_SN,'') -- 终端序列号 非主键字段相等
         AND COALESCE(TM.CD_BRAND_TYPE_CD,'') = COALESCE(BF.CD_BRAND_TYPE_CD,'') -- 码牌类型代码 非主键字段相等
         AND COALESCE(TM.ASSIS_EQUIP_NO,'') = COALESCE(BF.ASSIS_EQUIP_NO,'') -- 辅助设备号 非主键字段相等
         AND COALESCE(TM.TERMN_REAL_TM_LTLN_INFO_DESC,'') = COALESCE(BF.TERMN_REAL_TM_LTLN_INFO_DESC,'') -- 终端实时经纬度信息描述 非主键字段相等
         AND COALESCE(TM.TERMN_NET_IN_CERT_NO,'') = COALESCE(BF.TERMN_NET_IN_CERT_NO,'') -- 终端入网认证编号 非主键字段相等
         AND COALESCE(TM.MERCHT_POINT_EQUIP_TYPE_CD,'') = COALESCE(BF.MERCHT_POINT_EQUIP_TYPE_CD,'') -- 商户端设备类型代码 非主键字段相等
         AND COALESCE(TM.APP_PROGRAM_VER_NO,'') = COALESCE(BF.APP_PROGRAM_VER_NO,'') -- 应用程序版本编号 非主键字段相等
         AND COALESCE(TM.MERCHT_POINT_EQUIP_IP_ADDR,'') = COALESCE(BF.MERCHT_POINT_EQUIP_IP_ADDR,'') -- 商户端设备IP地址 非主键字段相等
         AND COALESCE(TM.CAN_OPEN_ELEC_INVOICE_FLAG,'') = COALESCE(BF.CAN_OPEN_ELEC_INVOICE_FLAG,'') -- 可开电子发票标志 非主键字段相等
         AND COALESCE(TM.USER_IP_ADDR,'') = COALESCE(BF.USER_IP_ADDR,'') -- 用户IP地址 非主键字段相等
         AND COALESCE(TM.USER_MAC_ADDR,'') = COALESCE(BF.USER_MAC_ADDR,'') -- 用户MAC地址 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_NO,'') = COALESCE(BF.RECV_BIL_PROD_NO,'') -- 收单产品编号 非主键字段相等
         AND COALESCE(TM.PAY_SCENE_CD,'') = COALESCE(BF.PAY_SCENE_CD,'') -- 支付场景代码 非主键字段相等
         AND COALESCE(TM.BASIC_PROD_NO,'') = COALESCE(BF.BASIC_PROD_NO,'') -- 基础产品编号 非主键字段相等
         AND COALESCE(TM.MERCHT_ORDER_NO,'') = COALESCE(BF.MERCHT_ORDER_NO,'') -- 商户订单编号 非主键字段相等
         AND COALESCE(TM.ORIG_MERCHT_ORDER_NO,'') = COALESCE(BF.ORIG_MERCHT_ORDER_NO,'') -- 原商户订单编号 非主键字段相等
         AND COALESCE(TM.MERCHD_DESC,'') = COALESCE(BF.MERCHD_DESC,'') -- 商品描述 非主键字段相等
         AND COALESCE(TM.ORDER_REM,'') = COALESCE(BF.ORDER_REM,'') -- 订单备注 非主键字段相等
         AND COALESCE(TM.ORDER_TITLE_NAME,'') = COALESCE(BF.ORDER_TITLE_NAME,'') -- 订单标题名称 非主键字段相等
         AND COALESCE(TM.ORDER_INVALID_TM_STAMP,'') = COALESCE(BF.ORDER_INVALID_TM_STAMP,'') -- 订单失效时间戳 非主键字段相等
         AND COALESCE(TM.MERCHT_TYPE_CD,'') = COALESCE(BF.MERCHT_TYPE_CD,'') -- 商户类型代码 非主键字段相等
         AND COALESCE(TM.MERCHT_IDTFY_NO,'') = COALESCE(BF.MERCHT_IDTFY_NO,'') -- 商户识别编号 非主键字段相等
         AND COALESCE(TM.MERCHT_NO,'') = COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_CATEGORY_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_CATEGORY_CD,'') -- 特约商户类别代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_ABB,'') = COALESCE(BF.SPC_ARGMT_MERCHT_ABB,'') -- 特约商户简称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_APP_ID,'') = COALESCE(BF.SPC_ARGMT_MERCHT_APP_ID,'') -- 特约商户APPID 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_AFLT_ORG_NO,'') = COALESCE(BF.SPC_ARGMT_MERCHT_AFLT_ORG_NO,'') -- 特约商户所属机构编号 非主键字段相等
         AND COALESCE(TM.MERCHT_STORE_NO,'') = COALESCE(BF.MERCHT_STORE_NO,'') -- 商户门店编号 非主键字段相等
         AND COALESCE(TM.BIZ_SMALL_RECEIPT_TYPE_CD,'') = COALESCE(BF.BIZ_SMALL_RECEIPT_TYPE_CD,'') -- 商家小票类型代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_MERCHT_NO,'') = COALESCE(BF.THIRD_PTY_MERCHT_NO,'') -- 第三方商户编号 非主键字段相等
         AND COALESCE(TM.SUB_MERCHT_PUB_ACCT_NO,'') = COALESCE(BF.SUB_MERCHT_PUB_ACCT_NO,'') -- 子商户公众账户编号 非主键字段相等
         AND COALESCE(TM.SELLER_ZFB_USER_ID,'') = COALESCE(BF.SELLER_ZFB_USER_ID,'') -- 卖家支付宝用户ID 非主键字段相等
         AND COALESCE(TM.ZFB_SHOP_NO,'') = COALESCE(BF.ZFB_SHOP_NO,'') -- 支付宝店铺编号 非主键字段相等
         AND COALESCE(TM.MERCHT_OPERR_NO,'') = COALESCE(BF.MERCHT_OPERR_NO,'') -- 商户操作员编号 非主键字段相等
         AND COALESCE(TM.MERCHT_RGN_INFO_CD,'') = COALESCE(BF.MERCHT_RGN_INFO_CD,'') -- 商户区域信息编码 非主键字段相等
         AND COALESCE(TM.MERCHT_WALLET_MODE_CD,'') = COALESCE(BF.MERCHT_WALLET_MODE_CD,'') -- 商户钱包模式代码 非主键字段相等
         AND COALESCE(TM.MERCHT_BIZ_SER_NO,'') = COALESCE(BF.MERCHT_BIZ_SER_NO,'') -- 商户业务流水号 非主键字段相等
         AND COALESCE(TM.MERCHT_TEL_NO,'') = COALESCE(BF.MERCHT_TEL_NO,'') -- 商户电话号码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_ORG_IDTFY_IDNT,'') = COALESCE(BF.RECV_BIL_ORG_IDTFY_IDNT,'') -- 收单机构识别标识 非主键字段相等
         AND COALESCE(TM.APPLY_NO,'') = COALESCE(BF.APPLY_NO,'') -- 应用编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_IDTFY_NO,'') = COALESCE(BF.SERV_PROVDER_IDTFY_NO,'') -- 服务商识别编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_CHNL_NO,'') = COALESCE(BF.SERV_PROVDER_CHNL_NO,'') -- 服务商渠道编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_APP_ID,'') = COALESCE(BF.SERV_PROVDER_APP_ID,'') -- 服务商APPID 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NAME,'') = COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段相等
         AND COALESCE(TM.CHNL_MERCHT_MERCHT_NO,'') = COALESCE(BF.CHNL_MERCHT_MERCHT_NO,'') -- 渠道商商户编号 非主键字段相等
         AND COALESCE(TM.CHNL_MERCHT_MERCHT_NAME,'') = COALESCE(BF.CHNL_MERCHT_MERCHT_NAME,'') -- 渠道商商户名称 非主键字段相等
         AND COALESCE(TM.MCH_RECV_BIL_WAIT_STL_ACCT_NO,'') = COALESCE(BF.MCH_RECV_BIL_WAIT_STL_ACCT_NO,'') -- 行社收单待结算账户编号 非主键字段相等
         AND COALESCE(TM.MCH_RBCSA_NAME,'') = COALESCE(BF.MCH_RBCSA_NAME,'') -- 行社收单待结算账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NO,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NO,'') -- 收单结算账户编号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NAME,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NAME,'') -- 收单结算账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NO_OPBANK_NO,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NO_OPBANK_NO,'') -- 收单结算账号开户行行号 非主键字段相等
         AND COALESCE(TM.RBSA_OPBK_NAME,'') = COALESCE(BF.RBSA_OPBK_NAME,'') -- 收单结算账号开户行名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_CATEGORY_CD,'') = COALESCE(BF.RECV_BIL_STL_ACCT_CATEGORY_CD,'') -- 收单结算账户类别代码 非主键字段相等
         AND COALESCE(TM.PAY_FUND_ACCT_NO,'') = COALESCE(BF.PAY_FUND_ACCT_NO,'') -- 付款账户编号 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_NAME,'') = COALESCE(BF.PAY_ACCT_NAME,'') -- 付款账户名称 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NO,'') -- 付款账户开户机构编号 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') -- 付款账户开户机构名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PAY_ACCT_LMT_TYPE_CD,'') = COALESCE(BF.RECV_BIL_PAY_ACCT_LMT_TYPE_CD,'') -- 收单付款账户限制类型代码 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_DEBIT_ACCT_NO,'') = COALESCE(BF.EXCESS_REFUND_DEBIT_ACCT_NO,'') -- 超额退款借方账户编号 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_DEBIT_ACCT_NAME,'') = COALESCE(BF.EXCESS_REFUND_DEBIT_ACCT_NAME,'') -- 超额退款借方账户名称 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_DEBIT_ORG_NO,'') = COALESCE(BF.EXCESS_REFUND_DEBIT_ORG_NO,'') -- 超额退款借方机构编号 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_CRDT_ACCT_NO,'') = COALESCE(BF.EXCESS_REFUND_CRDT_ACCT_NO,'') -- 超额退款贷方账户编号 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_CRDT_ACCT_NAME,'') = COALESCE(BF.EXCESS_REFUND_CRDT_ACCT_NAME,'') -- 超额退款贷方账户名称 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_CRDT_ORG_NO,'') = COALESCE(BF.EXCESS_REFUND_CRDT_ORG_NO,'') -- 超额退款贷方机构编号 非主键字段相等
         AND COALESCE(TM.COURT_MNY_ACCT_NO,'') = COALESCE(BF.COURT_MNY_ACCT_NO,'') -- 法院案款虚账户编号 非主键字段相等
         AND COALESCE(TM.BUYER_NAME,'') = COALESCE(BF.BUYER_NAME,'') -- 买方名称 非主键字段相等
         AND COALESCE(TM.BUYER_MOBILE_NO,'') = COALESCE(BF.BUYER_MOBILE_NO,'') -- 买方手机号码 非主键字段相等
         AND COALESCE(TM.BUYER_DOCTYP_CD,'') = COALESCE(BF.BUYER_DOCTYP_CD,'') -- 买方证件类型代码 非主键字段相等
         AND COALESCE(TM.BUYER_DOC_NO,'') = COALESCE(BF.BUYER_DOC_NO,'') -- 买方证件号码 非主键字段相等
         AND COALESCE(TM.BUYER_MIN_AGE,CAST(0 AS BIGINT)) = COALESCE(BF.BUYER_MIN_AGE,CAST(0 AS BIGINT)) -- 买方最小年龄 非主键字段相等
         AND COALESCE(TM.BUYER_CUST_NO,'') = COALESCE(BF.BUYER_CUST_NO,'') -- 买方客户编号 非主键字段相等
         AND COALESCE(TM.MNY_USER_ID,'') = COALESCE(BF.MNY_USER_ID,'') -- 案款用户ID 非主键字段相等
         AND COALESCE(TM.BUYER_LOGIN_ACCT_NO,'') = COALESCE(BF.BUYER_LOGIN_ACCT_NO,'') -- 买方登录账号 非主键字段相等
         AND COALESCE(TM.BUYER_IDTFY_IDNT,'') = COALESCE(BF.BUYER_IDTFY_IDNT,'') -- 买方识别标识 非主键字段相等
         AND COALESCE(TM.INSTALLMENT_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.INSTALLMENT_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) -- 分期总金额 非主键字段相等
         AND COALESCE(TM.INST_TOTAL_CFEE_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.INST_TOTAL_CFEE_RATE,CAST(0 AS DECIMAL(20,7))) -- 分期付款总手续费费率 非主键字段相等
         AND COALESCE(TM.MERCHT_SCF_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.MERCHT_SCF_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) -- 商户补贴手续费费率 非主键字段相等
         AND COALESCE(TM.MCH_SBDY_INSFSC_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.MCH_SBDY_INSFSC_RATE,CAST(0 AS DECIMAL(20,7))) -- 行社补贴分期费费率 非主键字段相等
         AND COALESCE(TM.MCH_SBDY_INSCF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MCH_SBDY_INSCF_AMT,CAST(0 AS DECIMAL(28,2))) -- 行社补贴分期手续费金额 非主键字段相等
         AND COALESCE(TM.CHDER_INSFSC_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.CHDER_INSFSC_RATE,CAST(0 AS DECIMAL(20,7))) -- 持卡人分期费费率 非主键字段相等
         AND COALESCE(TM.CHDER_INSCF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CHDER_INSCF_AMT,CAST(0 AS DECIMAL(28,2))) -- 持卡人分期手续费金额 非主键字段相等
         AND COALESCE(TM.MERCHT_SBDY_INSCF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MERCHT_SBDY_INSCF_AMT,CAST(0 AS DECIMAL(28,2))) -- 商户补贴分期手续费金额 非主键字段相等
         AND COALESCE(TM.INSTALLMENT_PAY_TYPE_CD,'') = COALESCE(BF.INSTALLMENT_PAY_TYPE_CD,'') -- 分期支付类型代码 非主键字段相等
         AND COALESCE(TM.INSTALLMENT_TMS,CAST(0 AS BIGINT)) = COALESCE(BF.INSTALLMENT_TMS,CAST(0 AS BIGINT)) -- 分期期数 非主键字段相等
         AND COALESCE(TM.STAT_QR_CD_SN,'') = COALESCE(BF.STAT_QR_CD_SN,'') -- 静态二维码序列号 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.B_SRC_TAB_EN_NAME,'') = COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源英文名称 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化,继承ETL_LAST_ACG_DT
     ELSE '${process_date}' END -- 新旧数据可以关联上且数据变化,更新ETL_LAST_ACG_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,ETL_PERIOD_DT AS PT_DT -- 表分区日期
FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM TM
LEFT JOIN AGL.AGL_RECV_BIL_ORDER_DTL_TG_BK BF
ON (
     COALESCE(TM.TXN_SER_NO,'') = COALESCE(BF.TXN_SER_NO,'') -- 交易流水号 主键字段关联
    AND COALESCE(TM.ORIG_TXN_SER_NO,'') = COALESCE(BF.ORIG_TXN_SER_NO,'') -- 原交易流水号 主键字段关联
    AND COALESCE(TM.TXN_RECV_TM_STAMP,'') = COALESCE(BF.TXN_RECV_TM_STAMP,'') -- 交易接收时间戳 主键字段关联
    AND COALESCE(TM.TXN_SETUP_TM_STAMP,'') = COALESCE(BF.TXN_SETUP_TM_STAMP,'') -- 交易建立时间戳 主键字段关联
    AND COALESCE(TM.TXN_UPDATE_TM_STAMP,'') = COALESCE(BF.TXN_UPDATE_TM_STAMP,'') -- 交易更新时间戳 主键字段关联
    AND COALESCE(TM.TXN_CMPLT_TM_STAMP,'') = COALESCE(BF.TXN_CMPLT_TM_STAMP,'') -- 交易完成时间戳 主键字段关联
    AND COALESCE(TM.ORIG_TXN_RECV_TM_STAMP,'') = COALESCE(BF.ORIG_TXN_RECV_TM_STAMP,'') -- 原交易接收时间戳 主键字段关联
    AND COALESCE(TM.ETL_PERIOD_DT,'') = COALESCE(BF.PT_DT,'') -- 数据日期 主键字段关联
    )
;


/* 5.1 drop temp table */
DROP TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_BK;
DROP TABLE AGL.AGL_RECV_BIL_ORDER_DTL_TG_TM;
DROP TABLE AGL.TMP_AGL_RECV_BIL_ORDER_DTL_TG_01;
