-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-综合代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SYN_AGEN_PAY_TXN_DTL_TA
--     表中文名：综合代发交易明细聚合   
--     创建日期：2024-04-15 00:00:00
--     主键字段：PLAT_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-18 00:00:00 魏丹丹 新增
--         2024-09-09 00:00:00 魏丹丹 修改中间业务表名 ,第二组主表少关联条件字段,0920设计通知不需要第二组



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM
USING ORC
COMMENT '综合代发交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,CUST_ACCT_NO -- 客户账户编号
    ,SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,ISSUG_AMT -- 代发金额
    ,PAYOFF_TOTAL_CNT -- 代发总笔数
    ,PAYOFF_SUCC_CNT -- 代发成功笔数
    ,PAYOFF_FAIL_CNT -- 代发失败笔数
    ,HOST_RTN_CD -- 主机返回码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUMMARY_CD -- 摘要代码
    ,SETUP_DT -- 建立日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 综合代发交易明细聚合

INSERT INTO TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,CUST_ACCT_NO -- 客户账户编号
    ,SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,ISSUG_AMT -- 代发金额
    ,PAYOFF_TOTAL_CNT -- 代发总笔数
    ,PAYOFF_SUCC_CNT -- 代发成功笔数
    ,PAYOFF_FAIL_CNT -- 代发失败笔数
    ,HOST_RTN_CD -- 主机返回码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUMMARY_CD -- 摘要代码
    ,SETUP_DT -- 建立日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     SUBSTR(unifiedTime(P1.PLAT_DATE),1,10) AS PLAT_DT -- 平台日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.BAT_STAT AS FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,P3.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.ENTR_NO AS AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,P3.BRCH_NO AS PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,COALESCE(P4.AA03CSNO,P5.CINOCSNO) AS CUST_IN_CD -- 客户内码
    ,COALESCE(P4.AA05STNM,P5.CHNMNM40) AS CUST_NAME -- 客户名称
    ,P2.OPEN_TYPE AS SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,P2.BAT_TYPE AS SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,'01' AS SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,P1.SET_ACCT_NO1 AS PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,P1.CUST_ACCT_NO1 AS CUST_ACCT_NO -- 客户账户编号
    ,'' AS SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,P1.TOT_AMT AS ISSUG_AMT -- 代发金额
    ,NULL AS PAYOFF_TOTAL_CNT -- 代发总笔数
    ,P2.ACC_NUM_TOT1 AS PAYOFF_SUCC_CNT -- 代发成功笔数
    ,P2.ACC_NUM_TOT2 AS PAYOFF_FAIL_CNT -- 代发失败笔数
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,unifiedTime(P1.DATA_DATE) AS SETUP_DT -- 建立日期
    ,'IBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_BAT_ACC_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_BAT_ACC_TA AS P1 -- 批量代发明细表

LEFT JOIN ODS_OSCIP.ODS_OSCIP_T_BAT_TASK_TF AS P2 -- 批量任务表
       ON P1.PLAT_DATE=P2.PLAT_DATE
AND P1.BAT_SEQ=  P2.BAT_SEQ
AND P1.ENTR_NO=  P2.ENTR_NO AND P2.BAT_TYPE='02'  AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN (
SELECT
   ENTR_NAME
  ,BRCH_NO
  ,ENTR_NO
  ,ROW_NUMBER() OVER(PARTITION BY ENTR_NO ORDER BY  BRCH_NO DESC) RN
FROM ODS_OSCIP.ODS_OSCIP_T_ENTR_TF
WHERE PT_DT = '${process_date}' AND DEL_F='0'
) AS P3 -- 代发单位管理表
       ON P1.ENTR_NO=P3.ENTR_NO  AND P3.RN=1 
LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款帐户主档
       ON TRIM(P1.CUST_ACCT_NO1)=TRIM(P4.AA01AC15)   AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P5 -- 借记卡信息主档文件
       ON TRIM(P1.CUST_ACCT_NO1)=TRIM(P5.CDNOAC19)   AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 综合代发交易明细聚合

INSERT INTO TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,CUST_ACCT_NO -- 客户账户编号
    ,SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,ISSUG_AMT -- 代发金额
    ,PAYOFF_TOTAL_CNT -- 代发总笔数
    ,PAYOFF_SUCC_CNT -- 代发成功笔数
    ,PAYOFF_FAIL_CNT -- 代发失败笔数
    ,HOST_RTN_CD -- 主机返回码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUMMARY_CD -- 摘要代码
    ,SETUP_DT -- 建立日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     SUBSTR(unifiedTime(P1.PLAT_DATE),1,10) AS PLAT_DT -- 平台日期
    ,P1.BAT_SEQ    AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,P3.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P2.AA03CSNO AS AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,P2.AA47BRNO AS PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,COALESCE(P4.AA03CSNO,P5.CINOCSNO) AS CUST_IN_CD -- 客户内码
    ,COALESCE(P4.AA05STNM,P5.CHNMNM40) AS CUST_NAME -- 客户名称
    ,'' AS SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,P1.BAT_TYPE AS SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,'02' AS SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,P1.SET_ACCT_NO1 AS PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,P1.CUST_ACCT_NO1 AS CUST_ACCT_NO -- 客户账户编号
    ,P1.DET_STAT AS SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,P1.REAL_AMT AS ISSUG_AMT -- 代发金额
    ,NULL AS PAYOFF_TOTAL_CNT -- 代发总笔数
    ,NULL AS PAYOFF_SUCC_CNT -- 代发成功笔数
    ,NULL AS PAYOFF_FAIL_CNT -- 代发失败笔数
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P3.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'' AS SETUP_DT -- 建立日期
    ,'OFSBP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFSBP_T_NMGZDF_BATDET_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OFSBP.ODS_OFSBP_T_NMGZDF_BATDET_TA AS P1 -- 批量明细表

LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款帐户主档
       ON SUBSTRING(P1.ACCTNO,1,15)=P2.AA47BRNO AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN (
SELECT
   ENTR_NAME
  ,DSCRP_CODE
  ,ENTR_NO
  ,ROW_NUMBER() OVER(PARTITION BY ENTR_NO ORDER BY  BRCH_NO DESC) RN
FROM ODS_MID71.ODS_MID71_T_ENTR_TF
WHERE PT_DT = '${process_date}' AND DEL_F='0'
) AS P3 -- 代发单位管理表
       ON P1.ENTR_NO=P3.ENTR_NO  AND P3.RN=1 
LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款帐户主档
       ON TRIM(P1.CUST_ACCT_NO1)=TRIM(P4.AA01AC15)   AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P5 -- 借记卡信息主档文件
       ON TRIM(P1.CUST_ACCT_NO1)=TRIM(P5.CDNOAC19)   AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
WHERE P1.BAT_TYPE='2' AND P1.PT_DT = '${process_date}' AND P1.DEL_F='0' 
;
-- ==============聚合层字段映射（第4组）==============
-- 综合代发交易明细聚合

INSERT INTO TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,CUST_ACCT_NO -- 客户账户编号
    ,SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,ISSUG_AMT -- 代发金额
    ,PAYOFF_TOTAL_CNT -- 代发总笔数
    ,PAYOFF_SUCC_CNT -- 代发成功笔数
    ,PAYOFF_FAIL_CNT -- 代发失败笔数
    ,HOST_RTN_CD -- 主机返回码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUMMARY_CD -- 摘要代码
    ,SETUP_DT -- 建立日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     SUBSTR(unifiedTime(P1.TX_TM),1,10) AS PLAT_DT -- 平台日期
    ,P1.BAT_NUM AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.DTL_ORDR_NUM AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,P2.CORP_ID AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,P2.CORP_NM AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.CORP_CORE_ID AS AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,P3.ORG_NO AS PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,COALESCE(P4.AA03CSNO,P5.CINOCSNO) AS CUST_IN_CD -- 客户内码
    ,COALESCE(P4.AA05STNM,P5.CHNMNM40) AS CUST_NAME -- 客户名称
    ,'' AS SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,P2.TX_CL AS SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,'03' AS SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,P3.PAYR_ACCT_NUM AS PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,P1.RECVR_ACCT_NUM AS CUST_ACCT_NO -- 客户账户编号
    ,P1.TX_ST AS SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,P1.TX_AMT AS ISSUG_AMT -- 代发金额
    ,P3.TOTL_NUM AS PAYOFF_TOTAL_CNT -- 代发总笔数
    ,P3.SUCC_TOTL_NUM AS PAYOFF_SUCC_CNT -- 代发成功笔数
    ,P3.FAIL_TOTL_NUM AS PAYOFF_FAIL_CNT -- 代发失败笔数
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,P2.CHNL_CD AS TXN_CHNL_CD -- 交易渠道代码
    ,P3.MEMO_CD AS SUMMARY_CD -- 摘要代码
    ,'' AS SETUP_DT -- 建立日期
    ,'COPCT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_COPCT_T_CCT_DF_DTLS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_COPCT.ODS_COPCT_T_CCT_DF_DTLS_TA AS P1 -- 批量代发明细表

LEFT JOIN ODS_COPCT.ODS_COPCT_T_CCT_DF_INF_TF AS P3 -- 代发批次表
       ON P1.CORP_CORE_ID=P3.CORP_CORE_ID AND P1.BAT_NUM=P3.BAT_NUM  AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_COPCT.ODS_COPCT_T_CCT_ORDR_INF_TF AS P2 -- 订单信息表
       ON P3.CORP_CORE_ID=P2.CORP_CORE_ID AND P3.ORDR_ID=P2.ORDR_ID AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款帐户主档
       ON TRIM(P1.RECVR_ACCT_NUM)=TRIM(P4.AA01AC15)   AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P5 -- 借记卡信息主档文件
       ON TRIM(P1.RECVR_ACCT_NUM)=TRIM(P5.CDNOAC19)   AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0' 
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,FRONT_BAT_STATUS_CD -- 前置批量状态代码
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,AGEN_CORP_CUST_IN_CD -- 代理单位客户内码
    ,PAYOFF_CORP_BELONG_ORG_NO -- 代发单位归属机构编号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,SYN_PAYOFF_OPEN_ACCT_TYPE_CD -- 综合代发开户类型代码
    ,SYN_PAYOFF_BIZ_CATE_CD -- 综合代发业务种类代码
    ,SYN_PAYOFF_TYPE_CD -- 综合代发类型代码
    ,PAYOFF_CORP_ACCT_NO -- 代发单位账户编号
    ,CUST_ACCT_NO -- 客户账户编号
    ,SYN_PAYOFF_TXN_STATUS_CD -- 综合代发交易状态代码
    ,ISSUG_AMT -- 代发金额
    ,PAYOFF_TOTAL_CNT -- 代发总笔数
    ,PAYOFF_SUCC_CNT -- 代发成功笔数
    ,PAYOFF_FAIL_CNT -- 代发失败笔数
    ,HOST_RTN_CD -- 主机返回码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUMMARY_CD -- 摘要代码
    ,SETUP_DT -- 建立日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA_TM;
