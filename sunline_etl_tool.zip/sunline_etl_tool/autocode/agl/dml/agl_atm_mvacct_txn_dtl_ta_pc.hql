-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-ATM动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ATM_MVACCT_TXN_DTL_TA
--     表中文名：ATM动账交易明细聚合
--     创建日期：2024-03-13 00:00:00
--     主键字段：TXN_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-13 00:00:00 龙耀超 创建
--         2024-10-21 00:00:00 魏丹丹 设计0828的新增字段



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_ATM_MVACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA_TM
USING ORC
COMMENT 'ATM动账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_AMT -- 交易金额
    ,ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TRNOUT_ACCT_NO -- 转出账户编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CARD_HOLDER_NAME -- 持卡人名称
    ,CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CORE_SER_NO -- 核心流水号
    ,ORIG_SER_NO -- 原始流水号
    ,RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,RV_SUCC_FLAG -- 冲正成功标志
    ,RV_DEAL_DESC -- 冲正处理描述
    ,FRONT_HOUR -- 前置小时
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,EQUIP_NO -- 设备编号
    ,EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,EQUIP_RGN_CD -- 设备地区代码
    ,EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,RECV_CARD_PTY_BANK_NAME -- 受卡方银行名称
    ,RETRIV_REF_NO -- 检索参考号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,ERR_DESC -- 错误描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_ATM_MVACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- ATM动账交易明细聚合

INSERT INTO TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_AMT -- 交易金额
    ,ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TRNOUT_ACCT_NO -- 转出账户编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CARD_HOLDER_NAME -- 持卡人名称
    ,CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CORE_SER_NO -- 核心流水号
    ,ORIG_SER_NO -- 原始流水号
    ,RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,RV_SUCC_FLAG -- 冲正成功标志
    ,RV_DEAL_DESC -- 冲正处理描述
    ,FRONT_HOUR -- 前置小时
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,EQUIP_NO -- 设备编号
    ,EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,EQUIP_RGN_CD -- 设备地区代码
    ,EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,RECV_CARD_PTY_BANK_NAME -- 受卡方银行名称
    ,RETRIV_REF_NO -- 检索参考号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,ERR_DESC -- 错误描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     cast(P1.YLF_11 as string) AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.QZJYRQ) AS TXN_DT -- 交易日期
    ,unifiedTime1(CONCAT(SUBSTR(P1.QZJYRQ,1,4),P1.YLF_7)) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.F_2 AS TXN_CARD_NO -- 交易卡片编号
    ,CASE WHEN P1.F2_BINTYPE = '1' THEN P2.DFANAC19
WHEN P1.F2_BINTYPE = '2' THEN CAST(P3.XACCOUNT AS STRING)
WHEN P1.F2_BINTYPE = '3' THEN NULL
WHEN P1.F2_BINTYPE = '4' THEN P4.CUSTAC
WHEN P1.F2_BINTYPE = '5' THEN (CASE WHEN P1.F_2 = '0000000000000000' THEN P1.F_102 ELSE P1.F_2 END )
ELSE NULL END AS TXN_ACCT_NO -- 交易账户编号
    ,cast(nullif(P1.F_4,'') as DECIMAL(28,2))/100 AS TXN_AMT -- 交易金额
    ,SUBSTR(P1.TYPE,1,6) AS ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,CASE WHEN P1.F_49 IS NULL OR TRIM(P1.F_49)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.F_49)),'') END AS TXN_CURR_CD -- 交易币种代码
    ,P1.F_102 AS TRNOUT_ACCT_NO -- 转出账户编号
    ,P1.F_103 AS TRNIN_ACCT_NO -- 转入账户编号
    ,P1.F2_BINTYPE AS TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,P1.F_23 AS TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CASE WHEN P1.F2_BINTYPE = '1' THEN P2.CHNMNM40
WHEN P1.F2_BINTYPE = '2' THEN P3.SURNAME
WHEN P1.F2_BINTYPE = '4' THEN P4.USER_NM
ELSE NULL END AS CARD_HOLDER_NAME -- 持卡人名称
    ,CASE WHEN P1.F2_BINTYPE = '1' THEN P2.CINOCSNO
WHEN P1.F2_BINTYPE = '2' THEN P3.CUSTR_REF
WHEN P1.F2_BINTYPE = '4' THEN P4.CST_IN_CD
ELSE NULL END AS CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,P1.QDLSH_62 AS CORE_SER_NO -- 核心流水号
    ,P1.LSH AS ORIG_SER_NO -- 原始流水号
    ,P1.CLZT AS RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,P1.CLBZ AS RV_SUCC_FLAG -- 冲正成功标志
    ,P1.CLJG AS RV_DEAL_DESC -- 冲正处理描述
    ,SUBSTR(P1.YLF_7,5,2) AS FRONT_HOUR -- 前置小时
    ,unifiedTime1(P1.F_7) AS EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,P1.F_41 AS EQUIP_NO -- 设备编号
    ,P1.F_11 AS EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,P1.YLDQDM AS EQUIP_RGN_CD -- 设备地区代码
    ,CONCAT(SUBSTR(P1.JGM,3,3),'000') AS EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,SUBSTR(P1.JGM,3,6) AS EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,P1.CZY AS EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,P1.F_42 AS ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,P1.F_43 AS RECV_CARD_PTY_BANK_NAME -- 受卡方银行名称
    ,P1.F_37 AS RETRIV_REF_NO -- 检索参考号
    ,P1.F_18 AS MERCHT_MCC_CD -- 商户MCC代码
    ,SUBSTR(P1.F_22,1,2) AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,P1.F_25 AS SERV_POINT_COND_CD -- 服务点条件代码
    ,P1.ERRMSG AS ERR_DESC -- 错误描述
    ,'CARD' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CARD_ATMJYLS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CARD.ODS_CARD_ATMJYLS_TA AS P1 -- ATM交易流水表

LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P2 -- 借记卡信息主档文件
       ON P1.F_2 = P2.CDNOAC19 AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN (
SELECT 
A1.CARD_NBR,
A1.XACCOUNT,
A2.CUSTR_REF,
A2.SURNAME
FROM 
ODS_CCRD.ODS_CCRD_CARD_TF A1
INNER JOIN 
ODS_CCRD.ODS_CCRD_CUSTR_TF A2
ON A1.CUSTR_NBR = A2.CUSTR_NBR AND A1.PT_DT='${process_date}' AND A1.DEL_F='0' AND A2.PT_DT='${process_date}' AND A2.DEL_F='0'          
) AS P3 -- T3
       ON P1.F_2 = P3.CARD_NBR  
LEFT JOIN (
SELECT 
B1.CARDNO,
B1.CUSTAC,
B4.CST_IN_CD,
B4.USER_NM
FROM
ODS_NAS.ODS_NAS_KNA_ACDC_TF B1
INNER JOIN 
ODS_NAS.ODS_NAS_KNA_CUST_TF B2 
ON B1.CUSTAC = B2.CUSTAC AND B1.PT_DT='${process_date}' AND B1.DEL_F='0'  AND B2.PT_DT='${process_date}' AND B2.DEL_F='0'
INNER JOIN       
ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF  B3
ON B2.CUSTNO = B3.CUSTNO  AND B3.PT_DT='${process_date}' AND B3.DEL_F='0'
INNER JOIN 
ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF B4
ON B3.CUSTID = B4.USER_ID AND B4.PT_DT='${process_date}' AND B4.DEL_F='0'
) AS P4 -- T4
       ON P1.F_2 = P4.CARDNO 
LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'CARD'
        AND P1.SRC_FIELD_EN_NAME ='F_49'
        AND P1.SRC_TAB_EN_NAME = 'ATMJYLS'
        AND P1.TARGET_TAB_EN_NAME='AGL_ATM_MVACCT_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'TXN_CURR_CD'
) AS S1 -- TXN_CURR_CD
       ON TRIM(P1.F_49)=S1.SRC_CD_VAL 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0' AND P1.F_4 <>'0' AND P1.F_4 IS NOT NULL AND P1.F_4<>'' AND P1.F_4<>'000000000000'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_ATM_MVACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,TXN_AMT -- 交易金额
    ,ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TRNOUT_ACCT_NO -- 转出账户编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CARD_HOLDER_NAME -- 持卡人名称
    ,CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CORE_SER_NO -- 核心流水号
    ,ORIG_SER_NO -- 原始流水号
    ,RV_DEAL_STATUS_CD -- 冲正处理状态代码
    ,RV_SUCC_FLAG -- 冲正成功标志
    ,RV_DEAL_DESC -- 冲正处理描述
    ,FRONT_HOUR -- 前置小时
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,EQUIP_NO -- 设备编号
    ,EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,EQUIP_RGN_CD -- 设备地区代码
    ,EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,RECV_CARD_PTY_BANK_NAME -- 受卡方银行名称
    ,RETRIV_REF_NO -- 检索参考号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,ERR_DESC -- 错误描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_ATM_MVACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_ATM_MVACCT_TXN_DTL_TA_TM;
