-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-乘车码交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MULTY_CAR_CD_TXN_DTL_TA
--     表中文名：乘车码交易明细聚合
--     创建日期：2024-08-01 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-01 00:00:00 陈艺丹 创建
--         2024-09-14 00:00:00 陈艺丹 1.UNION1和UNION2主源表与卡合约表增加关联条件
--         2024-09-20 00:00:00 陈艺丹 新增字段:用户编号,用户归属机构编号,优惠金额
--         2024-09-20 00:00:00 陈艺丹 UNION1和UNION2字段原始票价金额、执行票价金额修改取数逻辑；UNION3字段实际支付金额、应收金额修改取数逻辑\
--         2024-09-20 00:00:00 陈艺丹 UNION1和UNION2字段“交通类型代码”填写固定值
--         2024-09-29 00:00:00 陈艺丹 修改正常交易流水表，公交订单记录表，地铁订单记录表和营销活动核销记录表为增量表；
--         2024-09-29 00:00:00 陈艺丹 修改实际支付金额,应收金额PAYABLE_PRICE/100为PAYABLE_PRICE，RECEIVABLE_PRICE/100为RECEIVABLE_PRICE；



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM
USING ORC
COMMENT '乘车码交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,TXN_SEQ_NO -- 交易序号
    ,TXN_TYPE_CD -- 交易类型代码
    ,OPENID -- openID
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,USER_ID -- 用户ID
    ,USER_BELONG_ORG_NO -- 用户归属机构编号
    ,SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,APPLY_NO -- 应用编号
    ,CONT_NO -- 合约编号
    ,VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,TRFC_TYPE_CD -- 交通类型代码
    ,VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,TXN_DT -- 交易日期
    ,MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,TXN_BANK_CARD_NO -- 交易银行卡号
    ,MOBILE_NO -- 手机号码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,PAY_STATUS_CD -- 支付状态代码
    ,MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,ORDER_EFFECT_FLAG -- 订单有效标志
    ,ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,PAY_RESLT_DESC -- 支付结果描述
    ,PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,INTLG_PAY_SER_NO -- 智能支付流水号
    ,INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,BUCKLE_SER_NO -- 补扣流水号
    ,INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,MERCHT_APP_ID -- 商户APPID
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,ORIG_BIL_PRC_AMT -- 原始票价金额
    ,EXC_BIL_PRC_AMT -- 执行票价金额
    ,ACTL_PAY_AMT -- 实际支付金额
    ,RECVBL_AMT -- 应收金额
    ,PREFR_AMT -- 优惠金额
    ,MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,MERCHT_PREFR_AMT -- 商户优惠金额
    ,BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,PREFR_ACT_NO -- 优惠活动编号
    ,PREFR_ACT_NAME -- 优惠活动名称
    ,PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,JOURNEY_BIL_NO -- 行程单号
    ,MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,LINE_NAME -- 线路名称
    ,POS_TXN_SER_NO -- POS交易流水号
    ,POS_LINE_NO -- POS线路编号
    ,POS_SITE_NO -- POS站点编号
    ,VEHIC_NO -- 车辆编号
    ,6_BIT_DIST_CD -- 六位行政区划代码
    ,CITY_NAME -- 所在城市名称
    ,DRIVER_NO -- 司机编号
    ,ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 乘车码交易明细聚合

INSERT INTO TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,TXN_SEQ_NO -- 交易序号
    ,TXN_TYPE_CD -- 交易类型代码
    ,OPENID -- openID
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,USER_ID -- 用户ID
    ,USER_BELONG_ORG_NO -- 用户归属机构编号
    ,SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,APPLY_NO -- 应用编号
    ,CONT_NO -- 合约编号
    ,VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,TRFC_TYPE_CD -- 交通类型代码
    ,VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,TXN_DT -- 交易日期
    ,MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,TXN_BANK_CARD_NO -- 交易银行卡号
    ,MOBILE_NO -- 手机号码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,PAY_STATUS_CD -- 支付状态代码
    ,MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,ORDER_EFFECT_FLAG -- 订单有效标志
    ,ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,PAY_RESLT_DESC -- 支付结果描述
    ,PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,INTLG_PAY_SER_NO -- 智能支付流水号
    ,INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,BUCKLE_SER_NO -- 补扣流水号
    ,INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,MERCHT_APP_ID -- 商户APPID
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,ORIG_BIL_PRC_AMT -- 原始票价金额
    ,EXC_BIL_PRC_AMT -- 执行票价金额
    ,ACTL_PAY_AMT -- 实际支付金额
    ,RECVBL_AMT -- 应收金额
    ,PREFR_AMT -- 优惠金额
    ,MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,MERCHT_PREFR_AMT -- 商户优惠金额
    ,BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,PREFR_ACT_NO -- 优惠活动编号
    ,PREFR_ACT_NAME -- 优惠活动名称
    ,PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,JOURNEY_BIL_NO -- 行程单号
    ,MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,LINE_NAME -- 线路名称
    ,POS_TXN_SER_NO -- POS交易流水号
    ,POS_LINE_NO -- POS线路编号
    ,POS_SITE_NO -- POS站点编号
    ,VEHIC_NO -- 车辆编号
    ,6_BIT_DIST_CD -- 六位行政区划代码
    ,CITY_NAME -- 所在城市名称
    ,DRIVER_NO -- 司机编号
    ,ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRADE_FLOW_ID AS TXN_SER_NO -- 交易流水号
    ,P1.ORDER_ID AS TXN_ORDER_NO -- 交易订单编号
    ,P1.TRADE_TYPE AS MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,P1.SEQUENCE AS TXN_SEQ_NO -- 交易序号
    ,'' AS TXN_TYPE_CD -- 交易类型代码
    ,P1.OPEN_ID AS OPENID -- openID
    ,P1.PRODUCT_ID AS PROD_NO -- 产品编号
    ,P2.PRODUCT_NAME AS PROD_NAME -- 产品名称
    ,P1.MERCHANT_ID AS MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,P3.NAME AS MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,P4.MERCHANT_ORDER_ID AS MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,P5.USER_ID AS USER_ID -- 用户ID
    ,P6.INSTITUTE_NO AS USER_BELONG_ORG_NO -- 用户归属机构编号
    ,P1.UID AS SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,P1.APP_ID AS APPLY_NO -- 应用编号
    ,P1.CONTACT_ID AS CONT_NO -- 合约编号
    ,P1.CARD_ID AS VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,'02' AS TRFC_TYPE_CD -- 交通类型代码
    ,P1.CHANNEL AS VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,unifiedTime(P1.LIQUIDATE_DATE) AS TXN_DT -- 交易日期
    ,CASE WHEN P7.CHANNEL='FSHL' AND P7.CONTRACT_ACCOUNT_TYPE='1' THEN '2' --借记卡
     WHEN P7.CHANNEL='FSHL' AND P7.CONTRACT_ACCOUNT_TYPE='2' THEN '3' --贷记卡
     WHEN P7.CHANNEL='FSHL' AND P7.CONTRACT_ACCOUNT_TYPE='3' THEN '1' --电子帐户
     WHEN P7.CHANNEL='FSHL' AND P7.CONTRACT_ACCOUNT_TYPE='4' THEN '6' --随心花
     WHEN P7.CONTRACT_ACCOUNT_TYPE='5' THEN '2' --借记卡
     WHEN P7.CONTRACT_ACCOUNT_TYPE='6' THEN '3' --贷记卡
     WHEN P7.CHANNEL='NBYZBANK' AND P7.CONTRACT_ACCOUNT_TYPE='1' THEN '12'--存折
     WHEN P7.CHANNEL='NBYZBANK' AND P7.CONTRACT_ACCOUNT_TYPE='2' THEN '13'--一卡通（借记卡）
     WHEN P7.CHANNEL='NBYZBANK' AND P7.CONTRACT_ACCOUNT_TYPE='3' THEN '14'--电子钱包
END AS MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,P5.ACCT_NO AS TXN_BANK_CARD_NO -- 交易银行卡号
    ,'' AS MOBILE_NO -- 手机号码
    ,CASE WHEN P4.PAY_TYPE='0' THEN '01'
     WHEN P4.PAY_TYPE='1' THEN '02' 
END AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,CASE WHEN P4.STATE='1' THEN '2' --支付中
     WHEN P4.STATE='2' THEN '1' --成功
     ELSE P4.STATE
END AS PAY_STATUS_CD -- 支付状态代码
    ,'' AS MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,P1.BORROW_FLAG AS ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,P1.IS_VALID_STATE AS ORDER_EFFECT_FLAG -- 订单有效标志
    ,unifiedTime1(P4.CREATE_TIME) AS ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,unifiedTime1(P1.CREATE_TIME) AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime1(P1.MODIFY_TIME) AS TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,P1.DEL_F AS TXN_EFFECT_FLAG -- 交易有效标志
    ,CASE WHEN P1.STATE='1' THEN '2' --支付中
     WHEN P1.STATE='2' THEN '1' --成功
     ELSE P1.STATE
END AS MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,P1.ERROR_MSG AS PAY_RESLT_DESC -- 支付结果描述
    ,P4.EXT_INFO AS PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,P1.OUT_TRADE_FLOW_ID AS INTLG_PAY_SER_NO -- 智能支付流水号
    ,P1.PAY_MERCHANT_ID AS INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,'' AS BUCKLE_SER_NO -- 补扣流水号
    ,P1.IS_ACCEPT AS INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,'' AS MERCHT_APP_ID -- 商户APPID
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,'' AS THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,NULL AS TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,P4.ORIGINAL_PRICE/100 AS ORIG_BIL_PRC_AMT -- 原始票价金额
    ,P4.TICKET_PRICE/100 AS EXC_BIL_PRC_AMT -- 执行票价金额
    ,P4.PAYABLE_PRICE/100 AS ACTL_PAY_AMT -- 实际支付金额
    ,P4.RECEIVABLE_PRICE/100 AS RECVBL_AMT -- 应收金额
    ,P1.DISCOUNT_AMOUNT/100 AS PREFR_AMT -- 优惠金额
    ,P4.PREFERENTIAL_TYPE AS MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,P8.PAY_STATUS AS ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,P8.ACQUIRE_TYPE AS CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,P8.TICKET_ACCOUNT_ID AS RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,P8.ACTIVITY_FLOW_ID AS ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,unifiedTime1(P8.PAY_TIME) AS ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,P4.BUS_PROMOTION/100 AS MERCHT_PREFR_AMT -- 商户优惠金额
    ,P4.THIRD_PARTY_PROMOTION/100 AS BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,P8.ACTIVITY_ID AS PREFR_ACT_NO -- 优惠活动编号
    ,P8.ACTIVITY_NAME AS PREFR_ACT_NAME -- 优惠活动名称
    ,P8.INSTITUTE_NO AS PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,P8.INSTITUTE_TYPE AS PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,P4.RIDE_ID AS JOURNEY_BIL_NO -- 行程单号
    ,P4.RIDE_TYPE AS MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,unifiedTime(P4.POS_TIME) AS GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,NULL AS GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,'' AS GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,'' AS GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,P4.POS_TERMINAL_NO AS GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,'' AS GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,P4.ROUTE_ID AS GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,'' AS GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,P4.ROUTE_NAME AS LINE_NAME -- 线路名称
    ,P4.POS_SERIAL_NO AS POS_TXN_SER_NO -- POS交易流水号
    ,P4.POS_ROUTE_ID AS POS_LINE_NO -- POS线路编号
    ,P4.POS_STOP_ID AS POS_SITE_NO -- POS站点编号
    ,P4.POS_BUS_ID AS VEHIC_NO -- 车辆编号
    ,P4.CITY_ID AS 6_BIT_DIST_CD -- 六位行政区划代码
    ,P4.CITY_NAME AS CITY_NAME -- 所在城市名称
    ,P4.DRIVER_ID AS DRIVER_NO -- 司机编号
    ,P1.USER_PAY_INSTITUTE_NO AS ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,P9.INSTITUTE_NAME AS ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,P3.ORGANIZATION_NO AS PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,P10.INSTITUTE_NAME AS PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,'1' AS MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,'SCPP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SCPP_T_TRADE_FLOW_RECORD_TA'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_SCPP.ODS_SCPP_T_TRADE_FLOW_RECORD_TA AS P1 -- 正常交易流水表

LEFT JOIN ODS_SCPP.ODS_SCPP_T_PRODUCT_TF AS P2 -- 产品表
       ON P1.PRODUCT_ID = P2.PRODUCT_ID AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_MERCHANT_TF AS P3 -- 商户表
       ON P1.MERCHANT_ID = P3.MERCHANT_ID AND P3.PT_DT='${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_ORDER_RECORD_TF AS P4 -- 公交订单记录表
       ON P1.ORDER_ID = P4.ORDER_ID AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CCL.ODS_CCL_T_CCL_BOOK_TF AS P5 -- 合约主表
       ON P1.CONTACT_ID = P5.CON_ID AND P5.PT_DT='${process_date}' AND P5.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_USER_INFO_TF AS P6 -- 用户信息表
       ON P1.UID = P6.UID AND P1.OPEN_ID = P6.OPEN_ID AND P6.PT_DT='${process_date}' AND P6.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_CARD_CONTRACT_TF AS P7 -- 卡合约表
       ON P1.CONTACT_ID = P7.CONTRACT_ID AND P1.CARD_ID=P7.CARD_ID AND P7.PT_DT='${process_date}' AND P7.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_ACTIVITY_CONSUME_ORDER_TF AS P8 -- 营销活动核销记录表
       ON P1.TRADE_FLOW_ID = P8.TRADE_FLOW_ID AND P8.PT_DT='${process_date}' AND P8.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_INSTITUTE_INFO_TF AS P9 -- 机构与二级商户号维护信息表
       ON P1.USER_PAY_INSTITUTE_NO = P9.INSTITUTE_NO AND P9.PT_DT='${process_date}' AND P9.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_INSTITUTE_INFO_TF AS P10 -- 机构与二级商户号维护信息表
       ON P3.ORGANIZATION_NO = P10.INSTITUTE_NO AND P10.PT_DT='${process_date}' AND P10.DEL_F='0' 
WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.INDUSTRY_ID='02'
;
-- ==============聚合层字段映射（第2组）==============
-- 乘车码交易明细聚合

INSERT INTO TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,TXN_SEQ_NO -- 交易序号
    ,TXN_TYPE_CD -- 交易类型代码
    ,OPENID -- openID
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,USER_ID -- 用户ID
    ,USER_BELONG_ORG_NO -- 用户归属机构编号
    ,SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,APPLY_NO -- 应用编号
    ,CONT_NO -- 合约编号
    ,VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,TRFC_TYPE_CD -- 交通类型代码
    ,VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,TXN_DT -- 交易日期
    ,MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,TXN_BANK_CARD_NO -- 交易银行卡号
    ,MOBILE_NO -- 手机号码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,PAY_STATUS_CD -- 支付状态代码
    ,MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,ORDER_EFFECT_FLAG -- 订单有效标志
    ,ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,PAY_RESLT_DESC -- 支付结果描述
    ,PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,INTLG_PAY_SER_NO -- 智能支付流水号
    ,INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,BUCKLE_SER_NO -- 补扣流水号
    ,INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,MERCHT_APP_ID -- 商户APPID
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,ORIG_BIL_PRC_AMT -- 原始票价金额
    ,EXC_BIL_PRC_AMT -- 执行票价金额
    ,ACTL_PAY_AMT -- 实际支付金额
    ,RECVBL_AMT -- 应收金额
    ,PREFR_AMT -- 优惠金额
    ,MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,MERCHT_PREFR_AMT -- 商户优惠金额
    ,BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,PREFR_ACT_NO -- 优惠活动编号
    ,PREFR_ACT_NAME -- 优惠活动名称
    ,PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,JOURNEY_BIL_NO -- 行程单号
    ,MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,LINE_NAME -- 线路名称
    ,POS_TXN_SER_NO -- POS交易流水号
    ,POS_LINE_NO -- POS线路编号
    ,POS_SITE_NO -- POS站点编号
    ,VEHIC_NO -- 车辆编号
    ,6_BIT_DIST_CD -- 六位行政区划代码
    ,CITY_NAME -- 所在城市名称
    ,DRIVER_NO -- 司机编号
    ,ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRADE_FLOW_ID AS TXN_SER_NO -- 交易流水号
    ,P1.ORDER_ID AS TXN_ORDER_NO -- 交易订单编号
    ,P1.TRADE_TYPE AS MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,P1.SEQUENCE AS TXN_SEQ_NO -- 交易序号
    ,'' AS TXN_TYPE_CD -- 交易类型代码
    ,P1.OPEN_ID AS OPENID -- openID
    ,P1.PRODUCT_ID AS PROD_NO -- 产品编号
    ,P2.PRODUCT_NAME AS PROD_NAME -- 产品名称
    ,P1.MERCHANT_ID AS MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,P3.NAME AS MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,'' AS MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,P4.USER_ID AS USER_ID -- 用户ID
    ,P5.INSTITUTE_NO AS USER_BELONG_ORG_NO -- 用户归属机构编号
    ,P1.UID AS SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,P1.APP_ID AS APPLY_NO -- 应用编号
    ,P1.CONTACT_ID AS CONT_NO -- 合约编号
    ,P1.CARD_ID AS VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,'01' AS TRFC_TYPE_CD -- 交通类型代码
    ,P1.CHANNEL AS VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,unifiedTime(P1.LIQUIDATE_DATE) AS TXN_DT -- 交易日期
    ,CASE WHEN P6.CHANNEL='FSHL' AND P6.CONTRACT_ACCOUNT_TYPE='1' THEN '2' --借记卡
     WHEN P6.CHANNEL='FSHL' AND P6.CONTRACT_ACCOUNT_TYPE='2' THEN '3' --贷记卡
     WHEN P6.CHANNEL='FSHL' AND P6.CONTRACT_ACCOUNT_TYPE='3' THEN '1' --电子帐户
     WHEN P6.CHANNEL='FSHL' AND P6.CONTRACT_ACCOUNT_TYPE='4' THEN '6' --随心花
     WHEN P6.CONTRACT_ACCOUNT_TYPE='5' THEN '2' --借记卡
     WHEN P6.CONTRACT_ACCOUNT_TYPE='6' THEN '3' --贷记卡
     WHEN P6.CHANNEL='NBYZBANK' AND P6.CONTRACT_ACCOUNT_TYPE='1' THEN '12'--存折
     WHEN P6.CHANNEL='NBYZBANK' AND P6.CONTRACT_ACCOUNT_TYPE='2' THEN '13'--一卡通（借记卡）
     WHEN P6.CHANNEL='NBYZBANK' AND P6.CONTRACT_ACCOUNT_TYPE='3' THEN '14'--电子钱包
END AS MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,P4.ACCT_NO AS TXN_BANK_CARD_NO -- 交易银行卡号
    ,'' AS MOBILE_NO -- 手机号码
    ,CASE WHEN P7.PAY_TYPE='0' THEN '01'
     WHEN P7.PAY_TYPE='1' THEN '02' 
END AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,CASE WHEN P7.PAY_TYPE='0' THEN '01'
     WHEN P7.PAY_TYPE='1' THEN '02' 
END AS PAY_STATUS_CD -- 支付状态代码
    ,'' AS MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,P1.BORROW_FLAG AS ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,P1.IS_VALID_STATE AS ORDER_EFFECT_FLAG -- 订单有效标志
    ,unifiedTime1(P7.CREATE_TIME) AS ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,unifiedTime1(P1.CREATE_TIME) AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime1(P1.MODIFY_TIME) AS TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,P1.DEL_F AS TXN_EFFECT_FLAG -- 交易有效标志
    ,CASE WHEN P1.STATE='1' THEN '2' --支付中
     WHEN P1.STATE='2' THEN '1' --成功
     ELSE P1.STATE
END AS MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,P1.ERROR_MSG AS PAY_RESLT_DESC -- 支付结果描述
    ,P7.EXT_INFO AS PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,P1.OUT_TRADE_FLOW_ID AS INTLG_PAY_SER_NO -- 智能支付流水号
    ,P1.PAY_MERCHANT_ID AS INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,'' AS BUCKLE_SER_NO -- 补扣流水号
    ,P1.IS_ACCEPT AS INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,'' AS MERCHT_APP_ID -- 商户APPID
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,P7.TRADE_CODE AS THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,unifiedTime1(P7.TIME_CREATE) AS TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,P7.ORIGINAL_PRICE/100 AS ORIG_BIL_PRC_AMT -- 原始票价金额
    ,P7.TICKET_PRICE/100 AS EXC_BIL_PRC_AMT -- 执行票价金额
    ,P7.PAYABLE_PRICE/100 AS ACTL_PAY_AMT -- 实际支付金额
    ,P7.RECEIVABLE_PRICE/100 AS RECVBL_AMT -- 应收金额
    ,P1.DISCOUNT_AMOUNT/100 AS PREFR_AMT -- 优惠金额
    ,P7.PREFERENTIAL_TYPE AS MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,P8.PAY_STATUS AS ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,P8.ACQUIRE_TYPE AS CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,P8.TICKET_ACCOUNT_ID AS RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,P8.ACTIVITY_FLOW_ID AS ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,unifiedTime1(P8.PAY_TIME) AS ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,P7.BUS_PROMOTION/100 AS MERCHT_PREFR_AMT -- 商户优惠金额
    ,P7.THIRD_PARTY_PROMOTION/100 AS BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,P8.ACTIVITY_ID AS PREFR_ACT_NO -- 优惠活动编号
    ,P8.ACTIVITY_NAME AS PREFR_ACT_NAME -- 优惠活动名称
    ,P8.INSTITUTE_NO AS PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,P8.INSTITUTE_TYPE AS PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,P7.RIDE_ID AS JOURNEY_BIL_NO -- 行程单号
    ,'' AS MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,unifiedTime1(REPLACE(get_json_object(P7.ORDER_DESC,'$.inTimeAcross') ,'T',' ')) AS GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,unifiedTime1(REPLACE(get_json_object(P7.ORDER_DESC,'$.outTimeAcross'),'T',' ')) AS GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,get_json_object(P7.ORDER_DESC,'$.inStationName') AS GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,get_json_object(P7.ORDER_DESC,'$.outStationName') AS GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,get_json_object(P7.ORDER_DESC,'$.inStationCode') AS GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,get_json_object(P7.ORDER_DESC,'$.outStationCode') AS GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,get_json_object(P7.ORDER_DESC,'$.inLineName') AS GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,get_json_object(P7.ORDER_DESC,'$.outLineName') AS GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,'' AS LINE_NAME -- 线路名称
    ,'' AS POS_TXN_SER_NO -- POS交易流水号
    ,'' AS POS_LINE_NO -- POS线路编号
    ,'' AS POS_SITE_NO -- POS站点编号
    ,'' AS VEHIC_NO -- 车辆编号
    ,'' AS 6_BIT_DIST_CD -- 六位行政区划代码
    ,'' AS CITY_NAME -- 所在城市名称
    ,'' AS DRIVER_NO -- 司机编号
    ,P1.USER_PAY_INSTITUTE_NO AS ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,P9.INSTITUTE_NAME AS ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,P3.ORGANIZATION_NO AS PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,P10.INSTITUTE_NAME AS PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,'1' AS MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,'SCPP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SCPP_T_TRADE_FLOW_RECORD_TA'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_SCPP.ODS_SCPP_T_TRADE_FLOW_RECORD_TA AS P1 -- 正常交易流水表

LEFT JOIN ODS_SCPP.ODS_SCPP_T_PRODUCT_TF AS P2 -- 产品表
       ON P1.PRODUCT_ID = P2.PRODUCT_ID AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_MERCHANT_TF AS P3 -- 商户表
       ON P1.MERCHANT_ID = P3.MERCHANT_ID AND P3.PT_DT='${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_CCL.ODS_CCL_T_CCL_BOOK_TF AS P4 -- 合约主表
       ON P1.CONTACT_ID = P4.CON_ID AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_USER_INFO_TF AS P5 -- 用户信息表
       ON P1.UID = P5.UID AND P1.OPEN_ID = P5.OPEN_ID AND P5.PT_DT='${process_date}' AND P5.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_CARD_CONTRACT_TF AS P6 -- 卡合约表
       ON P1.CARD_ID=P6.CARD_ID AND P1.CONTACT_ID = P6.CONTRACT_ID AND P6.PT_DT='${process_date}' AND P6.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_METRO_ORDER_RECORD_TF AS P7 -- 地铁订单记录表
       ON P1.ORDER_ID = P7.ORDER_ID AND P7.PT_DT='${process_date}' AND P7.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_ACTIVITY_CONSUME_ORDER_TF AS P8 -- 营销活动核销记录表
       ON P1.TRADE_FLOW_ID = P8.TRADE_FLOW_ID AND P8.PT_DT='${process_date}' AND P8.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_INSTITUTE_INFO_TF AS P9 -- 机构与二级商户号维护信息表
       ON P1.USER_PAY_INSTITUTE_NO = P9.INSTITUTE_NO AND P9.PT_DT='${process_date}' AND P9.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_T_INSTITUTE_INFO_TF AS P10 -- 机构与二级商户号维护信息表
       ON P3.ORGANIZATION_NO = P10.INSTITUTE_NO AND P10.PT_DT='${process_date}' AND P10.DEL_F='0' 
WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.INDUSTRY_ID='01'
;
-- ==============聚合层字段映射（第3组）==============
-- 乘车码交易明细聚合

INSERT INTO TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,TXN_SEQ_NO -- 交易序号
    ,TXN_TYPE_CD -- 交易类型代码
    ,OPENID -- openID
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,USER_ID -- 用户ID
    ,USER_BELONG_ORG_NO -- 用户归属机构编号
    ,SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,APPLY_NO -- 应用编号
    ,CONT_NO -- 合约编号
    ,VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,TRFC_TYPE_CD -- 交通类型代码
    ,VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,TXN_DT -- 交易日期
    ,MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,TXN_BANK_CARD_NO -- 交易银行卡号
    ,MOBILE_NO -- 手机号码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,PAY_STATUS_CD -- 支付状态代码
    ,MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,ORDER_EFFECT_FLAG -- 订单有效标志
    ,ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,PAY_RESLT_DESC -- 支付结果描述
    ,PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,INTLG_PAY_SER_NO -- 智能支付流水号
    ,INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,BUCKLE_SER_NO -- 补扣流水号
    ,INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,MERCHT_APP_ID -- 商户APPID
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,ORIG_BIL_PRC_AMT -- 原始票价金额
    ,EXC_BIL_PRC_AMT -- 执行票价金额
    ,ACTL_PAY_AMT -- 实际支付金额
    ,RECVBL_AMT -- 应收金额
    ,PREFR_AMT -- 优惠金额
    ,MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,MERCHT_PREFR_AMT -- 商户优惠金额
    ,BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,PREFR_ACT_NO -- 优惠活动编号
    ,PREFR_ACT_NAME -- 优惠活动名称
    ,PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,JOURNEY_BIL_NO -- 行程单号
    ,MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,LINE_NAME -- 线路名称
    ,POS_TXN_SER_NO -- POS交易流水号
    ,POS_LINE_NO -- POS线路编号
    ,POS_SITE_NO -- POS站点编号
    ,VEHIC_NO -- 车辆编号
    ,6_BIT_DIST_CD -- 六位行政区划代码
    ,CITY_NAME -- 所在城市名称
    ,DRIVER_NO -- 司机编号
    ,ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRADE_FLOW_ID AS TXN_SER_NO -- 交易流水号
    ,P1.ORDER_ID AS TXN_ORDER_NO -- 交易订单编号
    ,P1.TRADE_TYPE AS MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,P1.SEQUENCE_FLAG AS TXN_SEQ_NO -- 交易序号
    ,CASE WHEN P1.TRANS_MER_TYPE='01' THEN '1'
     WHEN P1.TRANS_MER_TYPE='02' THEN '5'
END AS TXN_TYPE_CD -- 交易类型代码
    ,P1.OPEN_ID AS OPENID -- openID
    ,P1.PRODUCT_ID AS PROD_NO -- 产品编号
    ,P2.PRODUCT_NAME AS PROD_NAME -- 产品名称
    ,P1.MERCHANT_ID AS MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,P3.NAME AS MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,'' AS MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,P4.USER_ID AS USER_ID -- 用户ID
    ,P5.INSTITUTE_NO AS USER_BELONG_ORG_NO -- 用户归属机构编号
    ,P1.UID AS SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,P1.APP_ID AS APPLY_NO -- 应用编号
    ,P1.CONTACT_ID AS CONT_NO -- 合约编号
    ,P1.CARD_ID AS VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,P1.INDUSTRY_ID AS TRFC_TYPE_CD -- 交通类型代码
    ,P1.CHANNEL AS VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,unifiedTime(P1.LIQUIDATE_DATE) AS TXN_DT -- 交易日期
    ,CASE WHEN P1.CHANNEL='FSHL' AND P1.CARD_ATTR='1' THEN '2' --借记卡
     WHEN P1.CHANNEL='FSHL' AND P1.CARD_ATTR='2' THEN '3' --贷记卡
     WHEN P1.CHANNEL='FSHL' AND P1.CARD_ATTR='3' THEN '1' --电子帐户
     WHEN P1.CHANNEL='FSHL' AND P1.CARD_ATTR='4' THEN '6' --随心花
     WHEN P1.CARD_ATTR='5' THEN '2' --借记卡
     WHEN P1.CARD_ATTR='6' THEN '3' --贷记卡
     WHEN P1.CHANNEL='NBYZBANK' AND P1.CARD_ATTR='1' THEN '12'--存折
     WHEN P1.CHANNEL='NBYZBANK' AND P1.CARD_ATTR='2' THEN '13'--一卡通（借记卡）
     WHEN P1.CHANNEL='NBYZBANK' AND P1.CARD_ATTR='3' THEN '14'--电子钱包
END AS MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,P1.ACC_NO AS TXN_BANK_CARD_NO -- 交易银行卡号
    ,P1.MOBLIE AS MOBILE_NO -- 手机号码
    ,CASE WHEN P6.PAY_TYPE='0' THEN '01'
     WHEN P6.PAY_TYPE='1' THEN '02' 
END AS PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,CASE WHEN P6.STATE='1' THEN '2' --支付中
     WHEN P6.STATE='2' THEN '1' --成功
     ELSE P6.STATE
END AS PAY_STATUS_CD -- 支付状态代码
    ,P6.PAYMENTAFTER_STATE AS MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,P1.BORROW_FLAG AS ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,P1.IS_VALID_STATE AS ORDER_EFFECT_FLAG -- 订单有效标志
    ,unifiedTime1(P6.GMT_CREATE) AS ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,unifiedTime1(P1.GMT_CREATE) AS TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,unifiedTime1(P1.GMT_MODIFIED) AS TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,unifiedTime1(P1.LAST_ETL_ACG_DT) AS TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,P1.DEL_F AS TXN_EFFECT_FLAG -- 交易有效标志
    ,CASE WHEN P1.STATE='1' THEN '2' --支付中
     WHEN P1.STATE='2' THEN '1' --成功
     ELSE P1.STATE
END AS MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,P1.ERROR_MSG AS PAY_RESLT_DESC -- 支付结果描述
    ,P6.EXT_INFO AS PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,P1.OUT_TRADE_FLOW_ID AS INTLG_PAY_SER_NO -- 智能支付流水号
    ,P1.PAY_MERCHANT_ID AS INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,P1.REPAYMENT_FLOW_ID AS BUCKLE_SER_NO -- 补扣流水号
    ,P1.IS_ACCEPT AS INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,P1.APP_MER_ID AS MERCHT_APP_ID -- 商户APPID
    ,P1.OP_ID AS UNPY_MERCHT_NO -- 银联商户编号
    ,P6.TRADE_CODE AS THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,unifiedTime1(P6.TIME_CREATE) AS TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,P6.ORIGINAL_PRICE AS ORIG_BIL_PRC_AMT -- 原始票价金额
    ,P6.TICKET_PRICE AS EXC_BIL_PRC_AMT -- 执行票价金额
    ,P6.PAYABLE_PRICE AS ACTL_PAY_AMT -- 实际支付金额
    ,P6.RECEIVABLE_PRICE AS RECVBL_AMT -- 应收金额
    ,P6.TICKET_PRICE-P6.PAYABLE_PRICE AS PREFR_AMT -- 优惠金额
    ,P6.PREFERENTIAL_TYPE AS MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,'' AS ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,'' AS CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,'' AS RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,'' AS ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,NULL AS ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,NULL AS MERCHT_PREFR_AMT -- 商户优惠金额
    ,NULL AS BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,'' AS PREFR_ACT_NO -- 优惠活动编号
    ,'' AS PREFR_ACT_NAME -- 优惠活动名称
    ,'' AS PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,'' AS PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,P6.RIDE_ID AS JOURNEY_BIL_NO -- 行程单号
    ,'' AS MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,unifiedTime1(REPLACE(get_json_object(P6.ORDER_DESC,'$.inTimeAcross') ,'T',' ')) AS GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,unifiedTime1(REPLACE(get_json_object(P6.ORDER_DESC,'$.outTimeAcross'),'T',' ')) AS GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,get_json_object(P6.ORDER_DESC,'$.inStationName') AS GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,get_json_object(P6.ORDER_DESC,'$.outStationName') AS GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,get_json_object(P6.ORDER_DESC,'$.inStationCode') AS GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,get_json_object(P6.ORDER_DESC,'$.outStationCode') AS GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,get_json_object(P6.ORDER_DESC,'$.inLineName') AS GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,get_json_object(P6.ORDER_DESC,'$.outLineName') AS GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,'' AS LINE_NAME -- 线路名称
    ,'' AS POS_TXN_SER_NO -- POS交易流水号
    ,'' AS POS_LINE_NO -- POS线路编号
    ,'' AS POS_SITE_NO -- POS站点编号
    ,'' AS VEHIC_NO -- 车辆编号
    ,'' AS 6_BIT_DIST_CD -- 六位行政区划代码
    ,'' AS CITY_NAME -- 所在城市名称
    ,'' AS DRIVER_NO -- 司机编号
    ,P1.USER_PAY_INSTITUTE_NO AS ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,P7.INSTITUTE_NAME AS ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,P3.ORGANIZATION_NO AS PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,P8.INSTITUTE_NAME AS PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,'2' AS MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,'SCPP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SCPP_TBL_TRADE_FLOW_RECORD_TA'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_SCPP.ODS_SCPP_TBL_TRADE_FLOW_RECORD_TA AS P1 -- 正常交易流水表（银联）

LEFT JOIN ODS_SCPP.ODS_SCPP_TBL_PRODUCT_TF AS P2 -- 产品表（银联）
       ON P1.PRODUCT_ID = P2.PRODUCT_ID AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_TBL_MERCHANT_TF AS P3 -- 商户表（银联）
       ON P1.MERCHANT_ID = P3.MERCHANT_ID AND P3.PT_DT='${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_CCL.ODS_CCL_T_CCL_BOOK_TF AS P4 -- 合约主表
       ON P1.CONTACT_ID = P4.CON_ID AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_TBL_USER_INFO_TF AS P5 -- 用户信息表（银联）
       ON P1.UID = P5.UID AND P1.OPEN_ID = P5.OPEN_ID AND P5.PT_DT='${process_date}' AND P5.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_TBL_METRO_ORDER_RECORD_TF AS P6 -- 地铁订单记录表（银联）
       ON P1.ORDER_ID = P6.ORDER_ID AND P6.PT_DT='${process_date}' AND P6.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_TBL_INSTITUTE_INFO_TF AS P7 -- 机构与二级商户号维护信息表（银联）
       ON P1.USER_PAY_INSTITUTE_NO = P7.INSTITUTE_NO AND P7.PT_DT='${process_date}' AND P7.DEL_F='0' 
LEFT JOIN ODS_SCPP.ODS_SCPP_TBL_INSTITUTE_INFO_TF AS P8 -- 机构与二级商户号维护信息表（银联）
       ON P3.ORGANIZATION_NO = P8.INSTITUTE_NO AND P8.PT_DT='${process_date}' AND P8.DEL_F='0' 
WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,MULTY_CAR_CD_TXN_MODE_CD -- 乘车码交易方式代码
    ,TXN_SEQ_NO -- 交易序号
    ,TXN_TYPE_CD -- 交易类型代码
    ,OPENID -- openID
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MULTY_CAR_CD_MERCHT_NO -- 乘车码商户编号
    ,MULTY_CAR_CD_MERCHT_NAME -- 乘车码商户名称
    ,MCC_MERCHT_ORDER_SER_NO -- 乘车码商户订单流水号
    ,USER_ID -- 用户ID
    ,USER_BELONG_ORG_NO -- 用户归属机构编号
    ,SCENE_QR_CD_PLAT_USER_NO -- 场景二维码平台用户编号
    ,APPLY_NO -- 应用编号
    ,CONT_NO -- 合约编号
    ,VIRTUAL_CARD_CARD_NO -- 虚拟卡卡号
    ,TRFC_TYPE_CD -- 交通类型代码
    ,VIRTUAL_CARD_ACCESS_CHNL_CD -- 虚拟卡接入渠道代码
    ,TXN_DT -- 交易日期
    ,MULTY_CAR_CD_TXN_MED_TYPE_CD -- 乘车码交易介质类型代码
    ,TXN_BANK_CARD_NO -- 交易银行卡号
    ,MOBILE_NO -- 手机号码
    ,PAY_MODE_TYPE_CD -- 支付模式类型代码
    ,PAY_STATUS_CD -- 支付状态代码
    ,MKUP_PAY_STATUS_CD -- 补缴状态代码
    ,ADV_MNY_PAY_FLAG -- 垫资支付标志
    ,ORDER_EFFECT_FLAG -- 订单有效标志
    ,ORDER_CREATE_TM_STAMP -- 订单生成时间戳
    ,TXN_SETUP_TM_STAMP -- 交易建立时间戳
    ,TXN_MODIF_TM_STAMP -- 交易修改时间戳
    ,TXN_FINAL_MODIF_DT -- 交易最后修改日期
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,MULTY_CAR_CD_TXN_STATUS_CD -- 乘车码交易状态代码
    ,PAY_RESLT_DESC -- 支付结果描述
    ,PAY_RESLT_EXPAND_INFO_DESC -- 支付结果扩展信息描述
    ,INTLG_PAY_SER_NO -- 智能支付流水号
    ,INTLG_PAY_MERCHT_NO -- 智能支付商户编号
    ,BUCKLE_SER_NO -- 补扣流水号
    ,INTLG_PAY_ACPTD_RESLT_CD -- 智能支付受理结果代码
    ,MERCHT_APP_ID -- 商户APPID
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,THIRD_PTY_SYS_TXN_ORDER_SER_NO -- 第三方系统交易订单流水号
    ,TSYST_TXN_NTC_TM_STAMP -- 第三方系统交易通知时间戳
    ,ORIG_BIL_PRC_AMT -- 原始票价金额
    ,EXC_BIL_PRC_AMT -- 执行票价金额
    ,ACTL_PAY_AMT -- 实际支付金额
    ,RECVBL_AMT -- 应收金额
    ,PREFR_AMT -- 优惠金额
    ,MULTY_CAR_CD_PREFR_TYPE_CD -- 乘车码优惠类型代码
    ,ACT_WRTOFF_STATUS_CD -- 活动核销状态代码
    ,CUST_BIL_GET_MODE_CD -- 客票获取方式代码
    ,RELA_CUST_BIL_ACCT_NO -- 关联客票账户编号
    ,ACT_WRTOFF_SER_NO -- 活动核销流水号
    ,ACT_WRTOFF_TM_STAMP -- 活动核销时间戳
    ,MERCHT_PREFR_AMT -- 商户优惠金额
    ,BANK_PTY_PREFR_AMT -- 行方优惠金额
    ,PREFR_ACT_NO -- 优惠活动编号
    ,PREFR_ACT_NAME -- 优惠活动名称
    ,PREFR_MKTING_CTRB_ORG_NO -- 优惠营销出资机构编号
    ,PMKT_CTRB_ORG_CATEGORY_CD -- 优惠营销出资机构类别代码
    ,JOURNEY_BIL_NO -- 行程单号
    ,MULTY_CAR_CD_FEE_MODE_CD -- 乘车码计费模式代码
    ,GET_ON_IN_STATION_TM_STAMP -- 上车/进站时间戳
    ,GET_OFF_OUT_STATION_TM_STAMP -- 下车/出站时间戳
    ,GET_ON_IN_STATION_SITE_DESC -- 上车/进站站点描述
    ,GET_OFF_OUT_STATION_SITE_DESC -- 下车/出站站点描述
    ,GET_ON_IN_STATION_TERMN_NO -- 上车/进站终端编号
    ,GET_OFF_OUT_STATION_TERMN_NO -- 下车/出站终端编号
    ,GET_ON_IN_STATION_LINE_DESC -- 上车/进站线路描述
    ,GET_OFF_OUT_STATION_LINE_DESC -- 下车/出站线路描述
    ,LINE_NAME -- 线路名称
    ,POS_TXN_SER_NO -- POS交易流水号
    ,POS_LINE_NO -- POS线路编号
    ,POS_SITE_NO -- POS站点编号
    ,VEHIC_NO -- 车辆编号
    ,6_BIT_DIST_CD -- 六位行政区划代码
    ,CITY_NAME -- 所在城市名称
    ,DRIVER_NO -- 司机编号
    ,ACCT_BELONG_ORG_NO -- 账户归属机构编号
    ,ACCT_BELONG_ORG_NAME -- 账户归属机构名称
    ,PROD_BELONG_ORG_NO -- 产品归属机构编号
    ,PROD_BELONG_ORG_NAME -- 产品归属机构名称
    ,MULTY_CAR_CD_SCENE_CD -- 乘车码场景代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA_TM;
