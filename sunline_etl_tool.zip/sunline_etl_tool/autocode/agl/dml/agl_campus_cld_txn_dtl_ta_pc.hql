-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-校园云交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CAMPUS_CLD_TXN_DTL_TA
--     表中文名：校园云交易明细聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-16 00:00:00 叶禹 创建
--         2024-11-07 00:00:00 魏丹丹 修改从表为TF，交易时间戳取数逻辑变更



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM
USING ORC
COMMENT '校园云交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,SCH_NO -- 学校编号
    ,SCH_NAME -- 学校名称
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BANK_CARD_NO -- 银行卡号
    ,TXN_AMT -- 交易金额
    ,RTN_GOODS_AMT -- 退货金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,CAMPUS_CLD_TXN_TYPE_CD -- 校园云交易类型代码
    ,CAMPUS_CLD_TXN_CHNL_CD -- 校园云交易渠道代码
    ,CAMPUS_CLD_OPER_TYPE_CD -- 校园云操作类型代码
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_SEQ_NO -- 交易序号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_TXN_BATCH_NO -- 原交易批次编号
    ,RELA_TXN_SER_NO -- 关联交易流水号
    ,TXN_DEAL_STATUS_CD -- 交易处理状态代码
    ,CUST_NO -- 客户号
    ,CAMPUS_CLD_DOCTYP_CD -- 校园云证件类型代码
    ,USER_DOC_NO -- 用户证件号码
    ,USER_NAME -- 用户名称
    ,CAMPUS_CARD_ACCT_BAL -- 校园卡账户余额
    ,AVAILBL_BAL -- 可用余额
    ,TERMN_NO -- 终端编号
    ,CAMPUS_CLD_MERCHT_NO -- 校园云商户编号
    ,MERCHT_CLD_MERCHT_NO -- 商户云商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,ANSWER_CD -- 应答码
    ,CHECK_ENTRY_FLAG -- 对账标志
    ,UNDO_FLAG -- 撤销标志
    ,RV_FLAG -- 冲正标志
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 校园云交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,SCH_NO -- 学校编号
    ,SCH_NAME -- 学校名称
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BANK_CARD_NO -- 银行卡号
    ,TXN_AMT -- 交易金额
    ,RTN_GOODS_AMT -- 退货金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,CAMPUS_CLD_TXN_TYPE_CD -- 校园云交易类型代码
    ,CAMPUS_CLD_TXN_CHNL_CD -- 校园云交易渠道代码
    ,CAMPUS_CLD_OPER_TYPE_CD -- 校园云操作类型代码
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_SEQ_NO -- 交易序号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_TXN_BATCH_NO -- 原交易批次编号
    ,RELA_TXN_SER_NO -- 关联交易流水号
    ,TXN_DEAL_STATUS_CD -- 交易处理状态代码
    ,CUST_NO -- 客户号
    ,CAMPUS_CLD_DOCTYP_CD -- 校园云证件类型代码
    ,USER_DOC_NO -- 用户证件号码
    ,USER_NAME -- 用户名称
    ,CAMPUS_CARD_ACCT_BAL -- 校园卡账户余额
    ,AVAILBL_BAL -- 可用余额
    ,TERMN_NO -- 终端编号
    ,CAMPUS_CLD_MERCHT_NO -- 校园云商户编号
    ,MERCHT_CLD_MERCHT_NO -- 商户云商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,ANSWER_CD -- 应答码
    ,CHECK_ENTRY_FLAG -- 对账标志
    ,UNDO_FLAG -- 撤销标志
    ,RV_FLAG -- 冲正标志
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SSN AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.SYS_DATE) AS TXN_DT -- 交易日期
    ,P1.SITE_ID AS SCH_NO -- 学校编号
    ,P2.SITE_NAME AS SCH_NAME -- 学校名称
    ,P1.CARD_NO AS TXN_CARD_NO -- 交易卡片编号
    ,P1.ACCT_NO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.CARD_BANK_NO AS BANK_CARD_NO -- 银行卡号
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,P1.RETURN_AMT AS RTN_GOODS_AMT -- 退货金额
    ,unifiedTime1(P1.SYS_DATE||' '||P1.SYS_TIME) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.TXN_CODE AS CAMPUS_CLD_TXN_TYPE_CD -- 校园云交易类型代码
    ,P1.CHNL_ID AS CAMPUS_CLD_TXN_CHNL_CD -- 校园云交易渠道代码
    ,P1.OPR_TYPE AS CAMPUS_CLD_OPER_TYPE_CD -- 校园云操作类型代码
    ,P1.TXN_BATCH_NO AS TXN_BATCH_NO -- 交易批次编号
    ,P1.TXN_SEQ AS TXN_SEQ_NO -- 交易序号
    ,P1.ORI_TXN_SEQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.ORI_TXN_BATCH_NO AS ORIG_TXN_BATCH_NO -- 原交易批次编号
    ,P1.REL_TXN_SSN AS RELA_TXN_SER_NO -- 关联交易流水号
    ,P1.TXN_STAT AS TXN_DEAL_STATUS_CD -- 交易处理状态代码
    ,P3.CUST_NO AS CUST_NO -- 客户号
    ,P1.CDS_TYPE AS CAMPUS_CLD_DOCTYP_CD -- 校园云证件类型代码
    ,P1.CDS_NO AS USER_DOC_NO -- 用户证件号码
    ,P1.CUST_NAME AS USER_NAME -- 用户名称
    ,P1.ACC_BAL AS CAMPUS_CARD_ACCT_BAL -- 校园卡账户余额
    ,P1.AVAIL_BAL AS AVAILBL_BAL -- 可用余额
    ,P1.TERM_ID AS TERMN_NO -- 终端编号
    ,P1.MCHT_ID AS CAMPUS_CLD_MERCHT_NO -- 校园云商户编号
    ,P4.MERCH_ID AS MERCHT_CLD_MERCHT_NO -- 商户云商户编号
    ,P4.MERCH_S_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P4.MERCH_S_MER_NM AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P4.MERCH_S_NM_NAME AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,P4.MERCH_ORG_NO AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,P1.TLR_NO AS OPER_TELR_NO -- 操作柜员编号
    ,P1.REPLY_CODE AS ANSWER_CD -- 应答码
    ,P1.RECON_FLG AS CHECK_ENTRY_FLAG -- 对账标志
    ,P1.UNDO_FLG AS UNDO_FLAG -- 撤销标志
    ,P1.REV_FLG AS RV_FLAG -- 冲正标志
    ,unifiedTime1(P1.CREATE_TIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime1(P1.LST_UPD_TIME) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.DEL_F AS TXN_EFFECT_FLAG -- 交易有效标志
    ,'YYKT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_YYKT_TBL_TXN_FINANCEC_LOG_T_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_YYKT${version_num}.ODS_YYKT_TBL_TXN_FINANCEC_LOG_T_TA AS P1 -- 金融流水表（充值）

LEFT JOIN ODS_YYKT${version_num}.ODS_YYKT_TBL_SITE_INFO_TF AS P2 -- 站点信息表
       ON P1.SITE_ID = P2.SITE_ID
     AND P2.PT_DT = '${process_date}' 
     AND P2.DEL_F = '0' 
LEFT JOIN (SELECT * FROM 
(
SELECT 
CUST_NO
,SITE_ID
,CDS_TYPE
,CDS_NO
,ROW_NUMBER()OVER(PARTITION BY SITE_ID,CDS_TYPE,CDS_NO            
ORDER BY CREATE_TIME DESC) RN
FROM ODS_YYKT${version_num}.ODS_YYKT_TBL_CUST_BASE_INFO_TF
WHERE PT_DT = '${process_date}' 
  AND DEL_F = '0' 
)
WHERE RN=1
) AS P3 -- 客户信息表
       ON P1.SITE_ID = P3.SITE_ID
     AND P1.CDS_TYPE = P3.CDS_TYPE
     AND P1.CDS_NO = P3.CDS_NO 
LEFT JOIN (SELECT * FROM 
(
SELECT 
ORDER_MER_ORDER_NO
,MERCH_ID
,MERCH_S_ID
,MERCH_S_MER_NM
,MERCH_S_NM_NAME
,MERCH_ORG_NO
,ROW_NUMBER()OVER(PARTITION BY ORDER_MER_ORDER_NO            
ORDER BY GMT_MODIFIED DESC,GMT_CREATE DESC) RN
FROM ODS_IG${version_num}.ODS_IG_UAS_PAY_SIMPLE_TF
WHERE PT_DT = '${process_date}' 
  AND DEL_F = '0' 
)
WHERE RN=1
) AS P4 -- 交易流水表
       ON P1.REL_TXN_SSN = P4.ORDER_MER_ORDER_NO 
WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- 校园云交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,SCH_NO -- 学校编号
    ,SCH_NAME -- 学校名称
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BANK_CARD_NO -- 银行卡号
    ,TXN_AMT -- 交易金额
    ,RTN_GOODS_AMT -- 退货金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,CAMPUS_CLD_TXN_TYPE_CD -- 校园云交易类型代码
    ,CAMPUS_CLD_TXN_CHNL_CD -- 校园云交易渠道代码
    ,CAMPUS_CLD_OPER_TYPE_CD -- 校园云操作类型代码
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_SEQ_NO -- 交易序号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_TXN_BATCH_NO -- 原交易批次编号
    ,RELA_TXN_SER_NO -- 关联交易流水号
    ,TXN_DEAL_STATUS_CD -- 交易处理状态代码
    ,CUST_NO -- 客户号
    ,CAMPUS_CLD_DOCTYP_CD -- 校园云证件类型代码
    ,USER_DOC_NO -- 用户证件号码
    ,USER_NAME -- 用户名称
    ,CAMPUS_CARD_ACCT_BAL -- 校园卡账户余额
    ,AVAILBL_BAL -- 可用余额
    ,TERMN_NO -- 终端编号
    ,CAMPUS_CLD_MERCHT_NO -- 校园云商户编号
    ,MERCHT_CLD_MERCHT_NO -- 商户云商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,ANSWER_CD -- 应答码
    ,CHECK_ENTRY_FLAG -- 对账标志
    ,UNDO_FLAG -- 撤销标志
    ,RV_FLAG -- 冲正标志
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_SSN AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.SYS_DATE) AS TXN_DT -- 交易日期
    ,P1.SITE_ID AS SCH_NO -- 学校编号
    ,P2.SITE_NAME AS SCH_NAME -- 学校名称
    ,P1.CARD_NO AS TXN_CARD_NO -- 交易卡片编号
    ,P1.ACCT_NO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.CARD_BANK_NO AS BANK_CARD_NO -- 银行卡号
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,P1.RETURN_AMT AS RTN_GOODS_AMT -- 退货金额
    ,unifiedTime1(P1.SYS_DATE||' '||P1.SYS_TIME) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.TXN_CODE AS CAMPUS_CLD_TXN_TYPE_CD -- 校园云交易类型代码
    ,P1.CHNL_ID AS CAMPUS_CLD_TXN_CHNL_CD -- 校园云交易渠道代码
    ,P1.OPR_TYPE AS CAMPUS_CLD_OPER_TYPE_CD -- 校园云操作类型代码
    ,P1.TXN_BATCH_NO AS TXN_BATCH_NO -- 交易批次编号
    ,P1.TXN_SEQ AS TXN_SEQ_NO -- 交易序号
    ,P1.ORI_TXN_SEQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.ORI_TXN_BATCH_NO AS ORIG_TXN_BATCH_NO -- 原交易批次编号
    ,P1.REL_TXN_SSN AS RELA_TXN_SER_NO -- 关联交易流水号
    ,P1.TXN_STAT AS TXN_DEAL_STATUS_CD -- 交易处理状态代码
    ,P3.CUST_NO AS CUST_NO -- 客户号
    ,P1.CDS_TYPE AS CAMPUS_CLD_DOCTYP_CD -- 校园云证件类型代码
    ,P1.CDS_NO AS USER_DOC_NO -- 用户证件号码
    ,P1.CUST_NAME AS USER_NAME -- 用户名称
    ,P1.ACC_BAL AS CAMPUS_CARD_ACCT_BAL -- 校园卡账户余额
    ,P1.AVAIL_BAL AS AVAILBL_BAL -- 可用余额
    ,P1.TERM_ID AS TERMN_NO -- 终端编号
    ,P1.MCHT_ID AS CAMPUS_CLD_MERCHT_NO -- 校园云商户编号
    ,'' AS MERCHT_CLD_MERCHT_NO -- 商户云商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,P1.TLR_NO AS OPER_TELR_NO -- 操作柜员编号
    ,P1.REPLY_CODE AS ANSWER_CD -- 应答码
    ,P1.RECON_FLG AS CHECK_ENTRY_FLAG -- 对账标志
    ,P1.UNDO_FLG AS UNDO_FLAG -- 撤销标志
    ,P1.REV_FLG AS RV_FLAG -- 冲正标志
    ,unifiedTime1(P1.CREATE_TIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime1(P1.LST_UPD_TIME) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.DEL_F AS TXN_EFFECT_FLAG -- 交易有效标志
    ,'YYKT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_YYKT_TBL_TXN_FINANCED_LOG_T_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_YYKT${version_num}.ODS_YYKT_TBL_TXN_FINANCED_LOG_T_TA AS P1 -- 金融流水表（消费）

LEFT JOIN ODS_YYKT${version_num}.ODS_YYKT_TBL_SITE_INFO_TF AS P2 -- 站点信息表
       ON P1.SITE_ID = P2.SITE_ID
     AND P2.PT_DT = '${process_date}' 
     AND P2.DEL_F = '0' 
LEFT JOIN (SELECT * FROM 
(
SELECT 
CUST_NO
,SITE_ID
,CDS_TYPE
,CDS_NO
,ROW_NUMBER()OVER(PARTITION BY SITE_ID,CDS_TYPE,CDS_NO            
ORDER BY CREATE_TIME DESC) RN
FROM ODS_YYKT${version_num}.ODS_YYKT_TBL_CUST_BASE_INFO_TF
WHERE PT_DT = '${process_date}' 
  AND DEL_F = '0' 
)
WHERE RN=1
) AS P3 -- 客户信息表
       ON P1.SITE_ID = P3.SITE_ID
     AND P1.CDS_TYPE = P3.CDS_TYPE
     AND P1.CDS_NO = P3.CDS_NO 
WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,SCH_NO -- 学校编号
    ,SCH_NAME -- 学校名称
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BANK_CARD_NO -- 银行卡号
    ,TXN_AMT -- 交易金额
    ,RTN_GOODS_AMT -- 退货金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,CAMPUS_CLD_TXN_TYPE_CD -- 校园云交易类型代码
    ,CAMPUS_CLD_TXN_CHNL_CD -- 校园云交易渠道代码
    ,CAMPUS_CLD_OPER_TYPE_CD -- 校园云操作类型代码
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_SEQ_NO -- 交易序号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_TXN_BATCH_NO -- 原交易批次编号
    ,RELA_TXN_SER_NO -- 关联交易流水号
    ,TXN_DEAL_STATUS_CD -- 交易处理状态代码
    ,CUST_NO -- 客户号
    ,CAMPUS_CLD_DOCTYP_CD -- 校园云证件类型代码
    ,USER_DOC_NO -- 用户证件号码
    ,USER_NAME -- 用户名称
    ,CAMPUS_CARD_ACCT_BAL -- 校园卡账户余额
    ,AVAILBL_BAL -- 可用余额
    ,TERMN_NO -- 终端编号
    ,CAMPUS_CLD_MERCHT_NO -- 校园云商户编号
    ,MERCHT_CLD_MERCHT_NO -- 商户云商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,ANSWER_CD -- 应答码
    ,CHECK_ENTRY_FLAG -- 对账标志
    ,UNDO_FLAG -- 撤销标志
    ,RV_FLAG -- 冲正标志
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_EFFECT_FLAG -- 交易有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_CAMPUS_CLD_TXN_DTL_TA_TM;
