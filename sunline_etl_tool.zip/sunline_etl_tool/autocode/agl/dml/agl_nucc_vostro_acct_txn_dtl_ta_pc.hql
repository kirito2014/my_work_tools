-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-网联来账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA
--     表中文名：网联来账交易明细聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：MSG_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：包含第三方发起的支付、退货退款、第三方机构提现、签约解约等来账交易相关信息
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 修改脚本
--         2024-09-20 00:00:00 王穆军 修改P4关联条件,修改关联条件
--         2024-11-11 00:00:00 魏丹丹 增加来源表，修改客户内码取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '网联来账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     NUCC_VOSTRO_ACCT_SER_NO -- 网联来账流水号
    ,NUCC_BIZ_CHNL_DESC -- 网联业务渠道描述
    ,BIZ_SINGLE_NO -- 业务单编号
    ,NUCC_MSG_MAP_TYPE_CD -- 网联报文映射类型代码
    ,NUCC_BIZ_MCLS_CD -- 网联业务大类代码
    ,NUCC_BIZ_MCLS_DESC -- 网联业务大类描述
    ,NUCC_BIZ_SCLS_CD -- 网联业务小类代码
    ,NUCC_BIZ_SCLS_DESC -- 网联业务小类描述
    ,MSG_NO -- 报文编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_SUCC_AMT -- 交易成功金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,ORIG_MSG_TXN_NO -- 原报文交易编号
    ,CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,CHECK_ENTRY_STATUS_CD -- 对账状态代码
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,RESP_CODE -- 响应码
    ,RESP_INFO_DESC -- 响应信息描述
    ,TELEG_BANK_UPP_BANK_NO -- 发报行统一支付平台行号
    ,RECV_MSG_BANK_UPP_BANK_NO -- 收报行统一支付平台行号
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,MSG_STATUS_CD -- 报文状态代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,RECV_TM_STAMP -- 报文接收时间戳
    ,PLAT_CLEAR_TM_STAMP -- 平台清算时间戳
    ,PAYEE_CN_NAME -- 收款人中文名称
    ,PAYEE_USER_ID -- 收款人用户ID
    ,PAYEE_CUST_IN_CD -- 收款人客户内码
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,PAYEE_ACCT_NO -- 收款方账户编号
    ,PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,PAYEE_MOBILE_NO -- 收款人手机号码
    ,PAYER_NAME -- 付款人名称
    ,PAYER_USER_ID -- 付款人用户ID
    ,PAYER_CUST_IN_CD -- 付款人客户内码
    ,PAY_BANK_BANK_NO -- 付款行行号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,PAYER_CONT_NO_NO -- 付款人联系电话号码
    ,CUST_RMT_INFO_DESC -- 客户汇款信息描述
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,MOBILE_NO -- 手机号码
    ,SIGN_ORG_NO -- 签约机构编号
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,REM -- 备注
    ,NUCC_CORE_TYPE_CD -- 网联核心类型代码
    ,EXT_RESP_MSG_NO -- 外部响应报文编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA_TM(
     NUCC_VOSTRO_ACCT_SER_NO -- 网联来账流水号
    ,NUCC_BIZ_CHNL_DESC -- 网联业务渠道描述
    ,BIZ_SINGLE_NO -- 业务单编号
    ,NUCC_MSG_MAP_TYPE_CD -- 网联报文映射类型代码
    ,NUCC_BIZ_MCLS_CD -- 网联业务大类代码        NUCC_BIZ_MCLS_CD        VARCHAR  
    ,NUCC_BIZ_MCLS_DESC -- 网联业务大类描述
    ,NUCC_BIZ_SCLS_CD -- 网联业务小类代码
    ,NUCC_BIZ_SCLS_DESC -- 网联业务小类描述
    ,MSG_NO -- 报文编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_SUCC_AMT -- 交易成功金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,ORIG_MSG_TXN_NO -- 原报文交易编号
    ,CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,CHECK_ENTRY_STATUS_CD -- 对账状态代码
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,RESP_CODE -- 响应码
    ,RESP_INFO_DESC -- 响应信息描述
    ,TELEG_BANK_UPP_BANK_NO -- 发报行统一支付平台行号
    ,RECV_MSG_BANK_UPP_BANK_NO -- 收报行统一支付平台行号
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,MSG_STATUS_CD -- 报文状态代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,RECV_TM_STAMP -- 报文接收时间戳
    ,PLAT_CLEAR_TM_STAMP -- 平台清算时间戳
    ,PAYEE_CN_NAME -- 收款人中文名称
    ,PAYEE_USER_ID -- 收款人用户ID
    ,PAYEE_CUST_IN_CD -- 收款人客户内码
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,PAYEE_ACCT_NO -- 收款方账户编号
    ,PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,PAYEE_MOBILE_NO -- 收款人手机号码
    ,PAYER_NAME -- 付款人名称
    ,PAYER_USER_ID -- 付款人用户ID
    ,PAYER_CUST_IN_CD -- 付款人客户内码
    ,PAY_BANK_BANK_NO -- 付款行行号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,PAYER_CONT_NO_NO -- 付款人联系电话号码
    ,CUST_RMT_INFO_DESC -- 客户汇款信息描述
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,MOBILE_NO -- 手机号码
    ,SIGN_ORG_NO -- 签约机构编号
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,REM -- 备注
    ,NUCC_CORE_TYPE_CD -- 网联核心类型代码
    ,EXT_RESP_MSG_NO -- 外部响应报文编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.ID AS NUCC_VOSTRO_ACCT_SER_NO -- 网联来账流水号
    ,T1.CHAN_ID AS NUCC_BIZ_CHNL_DESC -- 网联业务渠道描述
    ,T1.ORDER_ID AS BIZ_SINGLE_NO -- 业务单编号
    ,'PURPPRTRY' AS NUCC_MSG_MAP_TYPE_CD -- 网联报文映射类型代码
    ,T1.BIZ_CATEGORY AS NUCC_BIZ_MCLS_CD -- 网联业务大类代码  
    ,T4.INTERNAL_DESC AS NUCC_BIZ_MCLS_DESC -- 网联业务大类描述
    ,T1.BIZ_PURP AS NUCC_BIZ_SCLS_CD -- 网联业务小类代码
    ,T4.INTERNAL_DESC AS NUCC_BIZ_SCLS_DESC -- 网联业务小类描述
    ,T1.MSG_ID AS MSG_NO -- 报文编号
    ,T1.STTL_AMT AS TXN_AMT -- 交易金额
    ,T1.STTL_AMT_CCY AS TXN_CURR_CD -- 交易币种代码
    ,T1.ACTUAL_STTL_AMT AS TXN_SUCC_AMT -- 交易成功金额
    ,unifiedTime(T1.TRANS_TIME) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.TXN_ID AS ORIG_MSG_TXN_NO -- 原报文交易编号
    ,T1.MND AS CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,T1.CHK_STS AS CHECK_ENTRY_STATUS_CD -- 对账状态代码
    ,T1.ENDTOENDID AS END_TO_END_IDE_NO -- 端到端标识号
    ,T1.RESP_CODE AS RESP_CODE -- 响应码
    ,T1.RES_MSG AS RESP_INFO_DESC -- 响应信息描述
    ,T1.SNDR_BRNCH_ID AS TELEG_BANK_UPP_BANK_NO -- 发报行统一支付平台行号
    ,T1.RCVR_BRNCH_ID AS RECV_MSG_BANK_UPP_BANK_NO -- 收报行统一支付平台行号
    ,unifiedTime1(T1.SEND_TIME) AS MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,T1.MSG_STS AS MSG_STATUS_CD -- 报文状态代码
    ,T1.MSG_TYPE AS RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,unifiedTime1(T1.CAPTURE_TIME) AS RECV_TM_STAMP -- 报文接收时间戳
    ,unifiedTime(T1.SP_STTL_DT) AS PLAT_CLEAR_TM_STAMP -- 平台清算时间戳
    ,T1.CDTR_NM AS PAYEE_CN_NAME -- 收款人中文名称
    ,T1.CDTR_CLIENT_CODE AS PAYEE_USER_ID -- 收款人用户ID
    ,COALESCE(T2.CST_IN_CD,T3.CUSTID) AS PAYEE_CUST_IN_CD -- 收款人客户内码
    ,T1.CDTR_ID AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,T1.CDTR_ACCT_ID AS PAYEE_ACCT_NO -- 收款方账户编号
    ,T1.FSTCD_ACCT_ID AS PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,T1.CDTR_CONTACTNO AS PAYEE_MOBILE_NO -- 收款人手机号码
    ,T1.DBTR_NM AS PAYER_NAME -- 付款人名称
    ,T1.DBTR_CLIENT_CODE AS PAYER_USER_ID -- 付款人用户ID
    ,COALESCE(T2.CST_IN_CD,T3.CUSTID) AS PAYER_CUST_IN_CD -- 付款人客户内码
    ,T1.DBTR_INST_ID AS PAY_BANK_BANK_NO -- 付款行行号
    ,T1.DBTR_ACCT_ID AS PAYER_ACCT_NO -- 付款方账户编号
    ,T1.FSTDB_ACCT_ID AS PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,T1.DBTR_CONTACTNO AS PAYER_CONT_NO_NO -- 付款人联系电话号码
    ,T1.CUST_REMIT_INFO AS CUST_RMT_INFO_DESC -- 客户汇款信息描述
    ,T1.IO_FLG AS ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,T1.MOBILENUMBER AS MOBILE_NO -- 手机号码
    ,T1.POSTING_OFFICE_ID AS SIGN_ORG_NO -- 签约机构编号
    ,unifiedTime(T1.UPDATE_TIME) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,T1.RECON_ID AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,T1.ERROR_CODE AS ERR_CD -- 错误编码
    ,T1.ERROR_DESP AS ERR_DESC -- 错误描述
    ,T1.REMARK_INFO AS REM -- 备注
    ,T1.BIZ_INST_ID AS NUCC_CORE_TYPE_CD -- 网联核心类型代码
    ,T1.EXT_MSG_TP AS EXT_RESP_MSG_NO -- 外部响应报文编号
    ,'UPP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_UPP_SP_PAY_SIMPLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ods_upp${version_num}.ODS_UPP_SP_PAY_SIMPLE_TA AS T1 -- 网联支付流水表

LEFT JOIN ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF AS T2 -- 用户信息表
       ON T1.DBTR_CLIENT_CODE=T2.USER_ID  AND   T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF AS T3 -- 用户信息表
       ON T1.DBTR_CLIENT_CODE=T3.CUSTID  AND  T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN (select * from(
select
   *
   ,row_number ()over(partition by internal_code order by gmt_modified desc ) rn 
from
 ods_upp${version_num}.ods_upp_sp_opengw_field_mapping_tf
where
 pt_dt = '${process_date}'
 and del_f = '0'
 and mapping_type = 'PURPPRTRY'
 )t where rn=1) AS T4 -- 业务类型参数表
       ON T1.BIZ_CATEGORY = T4.INTERNAL_CODE 
WHERE   t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     NUCC_VOSTRO_ACCT_SER_NO -- 网联来账流水号
    ,NUCC_BIZ_CHNL_DESC -- 网联业务渠道描述
    ,BIZ_SINGLE_NO -- 业务单编号
    ,NUCC_MSG_MAP_TYPE_CD -- 网联报文映射类型代码
    ,NUCC_BIZ_MCLS_CD -- 网联业务大类代码
    ,NUCC_BIZ_MCLS_DESC -- 网联业务大类描述
    ,NUCC_BIZ_SCLS_CD -- 网联业务小类代码
    ,NUCC_BIZ_SCLS_DESC -- 网联业务小类描述
    ,MSG_NO -- 报文编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_SUCC_AMT -- 交易成功金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,ORIG_MSG_TXN_NO -- 原报文交易编号
    ,CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,CHECK_ENTRY_STATUS_CD -- 对账状态代码
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,RESP_CODE -- 响应码
    ,RESP_INFO_DESC -- 响应信息描述
    ,TELEG_BANK_UPP_BANK_NO -- 发报行统一支付平台行号
    ,RECV_MSG_BANK_UPP_BANK_NO -- 收报行统一支付平台行号
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,MSG_STATUS_CD -- 报文状态代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,RECV_TM_STAMP -- 报文接收时间戳
    ,PLAT_CLEAR_TM_STAMP -- 平台清算时间戳
    ,PAYEE_CN_NAME -- 收款人中文名称
    ,PAYEE_USER_ID -- 收款人用户ID
    ,PAYEE_CUST_IN_CD -- 收款人客户内码
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,PAYEE_ACCT_NO -- 收款方账户编号
    ,PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,PAYEE_MOBILE_NO -- 收款人手机号码
    ,PAYER_NAME -- 付款人名称
    ,PAYER_USER_ID -- 付款人用户ID
    ,PAYER_CUST_IN_CD -- 付款人客户内码
    ,PAY_BANK_BANK_NO -- 付款行行号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,PAYER_CONT_NO_NO -- 付款人联系电话号码
    ,CUST_RMT_INFO_DESC -- 客户汇款信息描述
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,MOBILE_NO -- 手机号码
    ,SIGN_ORG_NO -- 签约机构编号
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,REM -- 备注
    ,NUCC_CORE_TYPE_CD -- 网联核心类型代码
    ,EXT_RESP_MSG_NO -- 外部响应报文编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA_TM;
