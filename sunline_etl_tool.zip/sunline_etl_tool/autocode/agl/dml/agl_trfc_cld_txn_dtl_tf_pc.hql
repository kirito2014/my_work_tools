-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_TXN_DTL_TF
--     表中文名：交通云交易明细聚合
--     创建日期：None
--     主键字段：TXN_SER_NO, TXN_TYPE_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-15 00:00:00 万香 新增
--         2024-10-21 00:00:00 魏丹丹 修改字段英文名：业务流水号



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM
USING ORC
COMMENT '交通云交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,USER_ID -- 用户ID
    ,LIC_PLATE_NO -- 车牌号码
    ,BIZ_SER_NO -- 业务流水号
    ,TXN_AMT -- 交易金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,STOP_CAR_PLACE_NO -- 停车场编号
    ,DRIVING_IN_TM_STAMP -- 驶入时间戳
    ,PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,MERCHT_REFUND_BIL_NO -- 商户退款单号
    ,AGT_NO -- 协议编号
    ,REFUND_STATUS_DESC -- 退款状态描述                                                                           
    ,DEL_FLAG -- 删除标志
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TRFC_CLD_MERCHT_NO -- 交通云商户编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 交通云交易明细聚合

INSERT INTO TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,USER_ID -- 用户ID
    ,LIC_PLATE_NO -- 车牌号码
    ,BIZ_SER_NO -- 业务流水号
    ,TXN_AMT -- 交易金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,STOP_CAR_PLACE_NO -- 停车场编号
    ,DRIVING_IN_TM_STAMP -- 驶入时间戳
    ,PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,MERCHT_REFUND_BIL_NO -- 商户退款单号
    ,AGT_NO -- 协议编号
    ,REFUND_STATUS_DESC -- 退款状态描述
    ,DEL_FLAG -- 删除标志
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TRFC_CLD_MERCHT_NO -- 交通云商户编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     cast(P1.id as string) AS TXN_SER_NO -- 交易流水号
    ,'1' AS TXN_TYPE_CD -- 交易类型代码
    ,P1.user_id AS USER_ID -- 用户ID
    ,P1.plate_no AS LIC_PLATE_NO -- 车牌号码
    ,P1.msg_id AS BIZ_SER_NO -- 业务流水号
    ,P1.amt AS TXN_AMT -- 交易金额
    ,unifiedTime(P1.tx_dt_tm) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.status AS TXN_STATUS_CD -- 交易状态代码
    ,P1.park_id AS STOP_CAR_PLACE_NO -- 停车场编号
    ,unifiedTime(P1.entry_time) AS DRIVING_IN_TM_STAMP -- 驶入时间戳
    ,P2.acct_no AS PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,P2.acct_nm AS CUST_NAME -- 客户名称
    ,'' AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,'' AS CUST_DOC_NO -- 客户证件号码
    ,'' AS CUST_MOBILE_NO -- 客户手机号码
    ,P1.mch_seq AS MERCHT_IDTFY_NO -- 商户识别编号
    ,P1.tx_id AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS MERCHT_REFUND_BIL_NO -- 商户退款单号
    ,P1.con_id AS AGT_NO -- 协议编号
    ,'' AS REFUND_STATUS_DESC -- 退款状态描述
    ,P1.is_delete AS DEL_FLAG -- 删除标志
    ,unifiedTime(P1.gmt_modified) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.tfc_merchant_id AS TRFC_CLD_MERCHT_NO -- 交通云商户编号
    ,'TFCS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_TFCS_PAY_FLOW_LOG_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_TFCS.ODS_TFCS_PAY_FLOW_LOG_TF AS P1 -- 支付流程记录表

LEFT JOIN (SELECT T.* FROM (
    SELECT
      ACCT_NO
     ,ACCT_NM
     ,APP_USER_ID
     ,ROW_NUMBER() OVER(PARTITION BY APP_USER_ID ORDER BY ID DESC ) RN 
    FROM ODS_TFCS.ODS_TFCS_AGREEMENT_APPLY_TF 
    WHERE PT_DT='${process_date}' AND DEL_F = '0' 
)T WHERE T.RN=1) AS P2 -- 签约申请表
       ON P1.USER_ID = P2.APP_USER_ID 
WHERE P1.PT_DT='${process_date}'    AND    P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- 交通云交易明细聚合

INSERT INTO TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,USER_ID -- 用户ID
    ,LIC_PLATE_NO -- 车牌号码
    ,BIZ_SER_NO -- 业务流水号
    ,TXN_AMT -- 交易金额
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,STOP_CAR_PLACE_NO -- 停车场编号
    ,DRIVING_IN_TM_STAMP -- 驶入时间戳
    ,PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,MERCHT_REFUND_BIL_NO -- 商户退款单号
    ,AGT_NO -- 协议编号
    ,REFUND_STATUS_DESC -- 退款状态描述
    ,DEL_FLAG -- 删除标志
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TRFC_CLD_MERCHT_NO -- 交通云商户编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     cast(P1.id as string)  AS TXN_SER_NO -- 交易流水号
    ,'0' AS TXN_TYPE_CD -- 交易类型代码
    ,P2.USER_ID AS USER_ID -- 用户ID
    ,P1.PLATE_NO AS LIC_PLATE_NO -- 车牌号码
    ,P1.MSG_ID AS BIZ_SER_NO -- 业务流水号
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,unifiedTime(P1.TX_DT_TM) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.STATUS AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS STOP_CAR_PLACE_NO -- 停车场编号
    ,'' AS DRIVING_IN_TM_STAMP -- 驶入时间戳
    ,P3.ACCT_NO AS PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,P3.ACCT_NM AS CUST_NAME -- 客户名称
    ,'' AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,'' AS CUST_DOC_NO -- 客户证件号码
    ,'' AS CUST_MOBILE_NO -- 客户手机号码
    ,P1.MCH_SEQ AS MERCHT_IDTFY_NO -- 商户识别编号
    ,P1.ORGL_TX_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.TX_ID AS MERCHT_REFUND_BIL_NO -- 商户退款单号
    ,'' AS AGT_NO -- 协议编号
    ,P1.REFUND_RESULT AS REFUND_STATUS_DESC -- 退款状态描述
    ,P1.IS_DELETE AS DEL_FLAG -- 删除标志
    ,unifiedTime(P1.GMT_MODIFIED) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.TFC_MERCHANT_ID AS TRFC_CLD_MERCHT_NO -- 交通云商户编号
    ,'TFCS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_TFCS_REFUND_FLOW_LOG_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_TFCS.ODS_TFCS_REFUND_FLOW_LOG_TF AS P1 -- 退款流程记录表

LEFT JOIN ODS_TFCS.ODS_TFCS_PAY_FLOW_LOG_TF AS P2 -- 支付流程记录表
       ON P1.ORGL_TX_ID = P2.TX_ID AND P2.PT_DT='${process_date}'    AND    P2.DEL_F = '0' 
LEFT JOIN (SELECT T.* FROM (
    SELECT
      ACCT_NO
     ,ACCT_NM
     ,APP_USER_ID
     ,ROW_NUMBER() OVER(PARTITION BY APP_USER_ID ORDER BY ID DESC ) RN 
    FROM ODS_TFCS.ODS_TFCS_AGREEMENT_APPLY_TF 
    WHERE PT_DT='${process_date}' AND DEL_F = '0' 
)T WHERE T.RN=1) AS P3 -- 签约申请表
       ON P2.USER_ID = P3.APP_USER_ID 
WHERE P1.PT_DT='${process_date}'    AND    P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_TRFC_CLD_TXN_DTL_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.TXN_SER_NO, BF.TXN_SER_NO) END AS TXN_SER_NO -- 交易流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_TYPE_CD, BF.TXN_TYPE_CD) END AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIC_PLATE_NO IS NULL THEN NULL ELSE COALESCE(TM.LIC_PLATE_NO, BF.LIC_PLATE_NO) END AS LIC_PLATE_NO -- 车牌号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.BIZ_SER_NO, BF.BIZ_SER_NO) END AS BIZ_SER_NO -- 业务流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_AMT IS NULL THEN NULL ELSE COALESCE(TM.TXN_AMT, BF.TXN_AMT) END AS TXN_AMT -- 交易金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.TXN_TM_STAMP, BF.TXN_TM_STAMP) END AS TXN_TM_STAMP -- 交易时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_STATUS_CD, BF.TXN_STATUS_CD) END AS TXN_STATUS_CD -- 交易状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_CAR_PLACE_NO IS NULL THEN NULL ELSE COALESCE(TM.STOP_CAR_PLACE_NO, BF.STOP_CAR_PLACE_NO) END AS STOP_CAR_PLACE_NO -- 停车场编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRIVING_IN_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.DRIVING_IN_TM_STAMP, BF.DRIVING_IN_TM_STAMP) END AS DRIVING_IN_TM_STAMP -- 驶入时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYER_PAY_CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.PAYER_PAY_CARD_NO, BF.PAYER_PAY_CARD_NO) END AS PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_DOCTYP_CD, BF.CUST_DOCTYP_CD) END AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_DOC_NO, BF.CUST_DOC_NO) END AS CUST_DOC_NO -- 客户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_MOBILE_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_MOBILE_NO, BF.CUST_MOBILE_NO) END AS CUST_MOBILE_NO -- 客户手机号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_IDTFY_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_IDTFY_NO, BF.MERCHT_IDTFY_NO) END AS MERCHT_IDTFY_NO -- 商户识别编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_ORDER_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_ORDER_NO, BF.MERCHT_ORDER_NO) END AS MERCHT_ORDER_NO -- 商户订单编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_REFUND_BIL_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_REFUND_BIL_NO, BF.MERCHT_REFUND_BIL_NO) END AS MERCHT_REFUND_BIL_NO -- 商户退款单号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.AGT_NO, BF.AGT_NO) END AS AGT_NO -- 协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_STATUS_DESC IS NULL THEN NULL ELSE COALESCE(TM.REFUND_STATUS_DESC, BF.REFUND_STATUS_DESC) END AS REFUND_STATUS_DESC -- 退款状态描述                                                                           
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEL_FLAG IS NULL THEN NULL ELSE COALESCE(TM.DEL_FLAG, BF.DEL_FLAG) END AS DEL_FLAG -- 删除标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TRFC_CLD_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.TRFC_CLD_MERCHT_NO, BF.TRFC_CLD_MERCHT_NO) END AS TRFC_CLD_MERCHT_NO -- 交通云商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.LIC_PLATE_NO,'') = COALESCE(BF.LIC_PLATE_NO,'') -- 车牌号码 非主键字段相等
         AND COALESCE(TM.BIZ_SER_NO,'') = COALESCE(BF.BIZ_SER_NO,'') -- 业务流水号 非主键字段相等
         AND COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段相等
         AND COALESCE(TM.TXN_TM_STAMP,'') = COALESCE(BF.TXN_TM_STAMP,'') -- 交易时间戳 非主键字段相等
         AND COALESCE(TM.TXN_STATUS_CD,'') = COALESCE(BF.TXN_STATUS_CD,'') -- 交易状态代码 非主键字段相等
         AND COALESCE(TM.STOP_CAR_PLACE_NO,'') = COALESCE(BF.STOP_CAR_PLACE_NO,'') -- 停车场编号 非主键字段相等
         AND COALESCE(TM.DRIVING_IN_TM_STAMP,'') = COALESCE(BF.DRIVING_IN_TM_STAMP,'') -- 驶入时间戳 非主键字段相等
         AND COALESCE(TM.PAYER_PAY_CARD_NO,'') = COALESCE(BF.PAYER_PAY_CARD_NO,'') -- 付款方支付卡号 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.CUST_MOBILE_NO,'') = COALESCE(BF.CUST_MOBILE_NO,'') -- 客户手机号码 非主键字段相等
         AND COALESCE(TM.MERCHT_IDTFY_NO,'') = COALESCE(BF.MERCHT_IDTFY_NO,'') -- 商户识别编号 非主键字段相等
         AND COALESCE(TM.MERCHT_ORDER_NO,'') = COALESCE(BF.MERCHT_ORDER_NO,'') -- 商户订单编号 非主键字段相等
         AND COALESCE(TM.MERCHT_REFUND_BIL_NO,'') = COALESCE(BF.MERCHT_REFUND_BIL_NO,'') -- 商户退款单号 非主键字段相等
         AND COALESCE(TM.AGT_NO,'') = COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段相等
         AND COALESCE(TM.REFUND_STATUS_DESC,'') = COALESCE(BF.REFUND_STATUS_DESC,'') -- 退款状态描述                                                                            非主键字段相等
         AND COALESCE(TM.DEL_FLAG,'') = COALESCE(BF.DEL_FLAG,'') -- 删除标志 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.TRFC_CLD_MERCHT_NO,'') = COALESCE(BF.TRFC_CLD_MERCHT_NO,'') -- 交通云商户编号 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.LIC_PLATE_NO,'') <> COALESCE(BF.LIC_PLATE_NO,'') -- 车牌号码 非主键字段不相等
         OR COALESCE(TM.BIZ_SER_NO,'') <> COALESCE(BF.BIZ_SER_NO,'') -- 业务流水号 非主键字段不相等
         OR COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段不相等
         OR COALESCE(TM.TXN_TM_STAMP,'') <> COALESCE(BF.TXN_TM_STAMP,'') -- 交易时间戳 非主键字段不相等
         OR COALESCE(TM.TXN_STATUS_CD,'') <> COALESCE(BF.TXN_STATUS_CD,'') -- 交易状态代码 非主键字段不相等
         OR COALESCE(TM.STOP_CAR_PLACE_NO,'') <> COALESCE(BF.STOP_CAR_PLACE_NO,'') -- 停车场编号 非主键字段不相等
         OR COALESCE(TM.DRIVING_IN_TM_STAMP,'') <> COALESCE(BF.DRIVING_IN_TM_STAMP,'') -- 驶入时间戳 非主键字段不相等
         OR COALESCE(TM.PAYER_PAY_CARD_NO,'') <> COALESCE(BF.PAYER_PAY_CARD_NO,'') -- 付款方支付卡号 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_DOCTYP_CD,'') <> COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_DOC_NO,'') <> COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_MOBILE_NO,'') <> COALESCE(BF.CUST_MOBILE_NO,'') -- 客户手机号码 非主键字段不相等
         OR COALESCE(TM.MERCHT_IDTFY_NO,'') <> COALESCE(BF.MERCHT_IDTFY_NO,'') -- 商户识别编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_ORDER_NO,'') <> COALESCE(BF.MERCHT_ORDER_NO,'') -- 商户订单编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_REFUND_BIL_NO,'') <> COALESCE(BF.MERCHT_REFUND_BIL_NO,'') -- 商户退款单号 非主键字段不相等
         OR COALESCE(TM.AGT_NO,'') <> COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段不相等
         OR COALESCE(TM.REFUND_STATUS_DESC,'') <> COALESCE(BF.REFUND_STATUS_DESC,'') -- 退款状态描述                                                                            非主键字段不相等
         OR COALESCE(TM.DEL_FLAG,'') <> COALESCE(BF.DEL_FLAG,'') -- 删除标志 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.TRFC_CLD_MERCHT_NO,'') <> COALESCE(BF.TRFC_CLD_MERCHT_NO,'') -- 交通云商户编号 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.LIC_PLATE_NO,'') = COALESCE(BF.LIC_PLATE_NO,'') -- 车牌号码 非主键字段相等
         AND COALESCE(TM.BIZ_SER_NO,'') = COALESCE(BF.BIZ_SER_NO,'') -- 业务流水号 非主键字段相等
         AND COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段相等
         AND COALESCE(TM.TXN_TM_STAMP,'') = COALESCE(BF.TXN_TM_STAMP,'') -- 交易时间戳 非主键字段相等
         AND COALESCE(TM.TXN_STATUS_CD,'') = COALESCE(BF.TXN_STATUS_CD,'') -- 交易状态代码 非主键字段相等
         AND COALESCE(TM.STOP_CAR_PLACE_NO,'') = COALESCE(BF.STOP_CAR_PLACE_NO,'') -- 停车场编号 非主键字段相等
         AND COALESCE(TM.DRIVING_IN_TM_STAMP,'') = COALESCE(BF.DRIVING_IN_TM_STAMP,'') -- 驶入时间戳 非主键字段相等
         AND COALESCE(TM.PAYER_PAY_CARD_NO,'') = COALESCE(BF.PAYER_PAY_CARD_NO,'') -- 付款方支付卡号 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.CUST_MOBILE_NO,'') = COALESCE(BF.CUST_MOBILE_NO,'') -- 客户手机号码 非主键字段相等
         AND COALESCE(TM.MERCHT_IDTFY_NO,'') = COALESCE(BF.MERCHT_IDTFY_NO,'') -- 商户识别编号 非主键字段相等
         AND COALESCE(TM.MERCHT_ORDER_NO,'') = COALESCE(BF.MERCHT_ORDER_NO,'') -- 商户订单编号 非主键字段相等
         AND COALESCE(TM.MERCHT_REFUND_BIL_NO,'') = COALESCE(BF.MERCHT_REFUND_BIL_NO,'') -- 商户退款单号 非主键字段相等
         AND COALESCE(TM.AGT_NO,'') = COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段相等
         AND COALESCE(TM.REFUND_STATUS_DESC,'') = COALESCE(BF.REFUND_STATUS_DESC,'') -- 退款状态描述                                                                            非主键字段相等
         AND COALESCE(TM.DEL_FLAG,'') = COALESCE(BF.DEL_FLAG,'') -- 删除标志 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.TRFC_CLD_MERCHT_NO,'') = COALESCE(BF.TRFC_CLD_MERCHT_NO,'') -- 交通云商户编号 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.LIC_PLATE_NO,'') <> COALESCE(BF.LIC_PLATE_NO,'') -- 车牌号码 非主键字段不相等
         OR COALESCE(TM.BIZ_SER_NO,'') <> COALESCE(BF.BIZ_SER_NO,'') -- 业务流水号 非主键字段不相等
         OR COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段不相等
         OR COALESCE(TM.TXN_TM_STAMP,'') <> COALESCE(BF.TXN_TM_STAMP,'') -- 交易时间戳 非主键字段不相等
         OR COALESCE(TM.TXN_STATUS_CD,'') <> COALESCE(BF.TXN_STATUS_CD,'') -- 交易状态代码 非主键字段不相等
         OR COALESCE(TM.STOP_CAR_PLACE_NO,'') <> COALESCE(BF.STOP_CAR_PLACE_NO,'') -- 停车场编号 非主键字段不相等
         OR COALESCE(TM.DRIVING_IN_TM_STAMP,'') <> COALESCE(BF.DRIVING_IN_TM_STAMP,'') -- 驶入时间戳 非主键字段不相等
         OR COALESCE(TM.PAYER_PAY_CARD_NO,'') <> COALESCE(BF.PAYER_PAY_CARD_NO,'') -- 付款方支付卡号 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_DOCTYP_CD,'') <> COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_DOC_NO,'') <> COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_MOBILE_NO,'') <> COALESCE(BF.CUST_MOBILE_NO,'') -- 客户手机号码 非主键字段不相等
         OR COALESCE(TM.MERCHT_IDTFY_NO,'') <> COALESCE(BF.MERCHT_IDTFY_NO,'') -- 商户识别编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_ORDER_NO,'') <> COALESCE(BF.MERCHT_ORDER_NO,'') -- 商户订单编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_REFUND_BIL_NO,'') <> COALESCE(BF.MERCHT_REFUND_BIL_NO,'') -- 商户退款单号 非主键字段不相等
         OR COALESCE(TM.AGT_NO,'') <> COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段不相等
         OR COALESCE(TM.REFUND_STATUS_DESC,'') <> COALESCE(BF.REFUND_STATUS_DESC,'') -- 退款状态描述                                                                            非主键字段不相等
         OR COALESCE(TM.DEL_FLAG,'') <> COALESCE(BF.DEL_FLAG,'') -- 删除标志 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.TRFC_CLD_MERCHT_NO,'') <> COALESCE(BF.TRFC_CLD_MERCHT_NO,'') -- 交通云商户编号 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.TXN_SER_NO,'') = COALESCE(BF.TXN_SER_NO,'') -- 交易流水号 主键字段关联
    AND COALESCE(TM.TXN_TYPE_CD,'') = COALESCE(BF.TXN_TYPE_CD,'') -- 交易类型代码 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_TRFC_CLD_TXN_DTL_TF_TM;
