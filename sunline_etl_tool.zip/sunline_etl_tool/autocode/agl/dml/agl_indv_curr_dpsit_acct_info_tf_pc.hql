-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人活期存款账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CURR_DPSIT_ACCT_INFO_TF
--     表中文名：个人活期存款账户信息聚合
--     创建日期：2023-02-15 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：存储个人活期存款账户聚合
--     更新记录：
--         2024-04-09 00:00:00 沈健 加上DEL_F=0,流水补充文件表注释
--         2024-09-24 00:00:00 王穆军 新增多个字段，调整逻辑，修改映射
--         2024-10-21 00:00:00 王穆军 变更设计文档0927截止：新增字段：客户国籍代码，客户职业代码，两组用户ID调整逻辑
--         2024-11-04 00:00:00 魏丹丹 删除字段：客户国籍代码，客户职业代码，昨日余额调整
--         2024-11-19 00:00:00 魏丹丹 修改第一组记录状态代码取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM
USING ORC
COMMENT '个人活期存款账户信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CUST_TYPE_CD -- 客户类型代码
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,MRG_BIZ_CATE -- 保证金业务种类
    ,MED_TYPE_CD -- 介质类型代码
    ,HANG_CARD_FLAG -- 挂卡标志
    ,MASTER_CARD_NO -- 主卡卡号
    ,DPSTRCP_CONVT_NO -- 存单折号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,ALLOW_WITHDR_CASH_FLAG -- 允许提现标志
    ,ALLOW_DRAW_FLAG -- 允许支取标志
    ,ALLOW_DPSIT_IN_FLAG -- 允许存入标志
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD_ENABLED_FLAG -- 交易密码启用标志
    ,PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,AUTH_AMT -- 授权金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CHARGE_MODE_CD -- 收费方式代码
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,BNCHMK_INT_RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,INTACR_MODE_CD -- 计息方式代码
    ,SETMENT_FREQ -- 结息频率
    ,VAL_DT -- 起息日期
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,OPEN_ACCT_TM -- 开户时间
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,OPEN_ACCT_AMT -- 开户金额
    ,OPEN_ACCT_TELR -- 开户柜员
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,DRAW_DOCTYP_CD -- 支取证件类型代码
    ,DRAW_DOC_NO -- 支取证件号码
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,WX_BIND_FLAG -- 微信绑定标志
    ,RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_011;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_011 (
     AB01AC15 STRING COMMENT '账户编号'
    ,AA01AC15 STRING COMMENT '账户编号'
    ,AA04FLNM STRING COMMENT '账户名称'
    ,AB02CCYC STRING COMMENT '币种代码'
    ,AB03CHSX STRING COMMENT '钞汇代码'
    ,AA10CSTP STRING COMMENT '客户类型代码'
    ,AA03CSNO STRING COMMENT '客户内码'
    ,AA24SSLV STRING COMMENT '通兑级别代码'
    ,AA25SWLV STRING COMMENT '通存级别代码'
    ,AA13ZHTP STRING COMMENT '账户性质代码'
    ,AA12ACT2 STRING COMMENT '介质类型代码'
    ,AA09SN03 STRING COMMENT '挂卡标志'
    ,AA14BLNO DECIMAL(20,7) COMMENT '存单折号码'
    ,AA11ACFG STRING COMMENT '账户类型代码'
    ,AB08ACST STRING COMMENT '账户状态代码'
    ,AA06BUST STRING COMMENT '存款业务类别代码'
    ,AA07PDTP STRING COMMENT '产品e代码'
    ,AA08PRON STRING COMMENT '产品代码'
    ,AB06ACID STRING COMMENT '存款科目号'
    ,AA48BRNO STRING COMMENT '核算主体行'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_COMB_PROD_CD STRING COMMENT '存款组合产品代码'
    ,DPSIT_COMB_PROD_NAME STRING COMMENT '存款组合产品名称'
    ,STOP_PAY_STATUS_CD STRING COMMENT '止付状态代码'
    ,AA16PZZT STRING COMMENT '挂失状态代码'
    ,FRZ_STATUS_CD STRING COMMENT '冻结状态代码'
    ,AA18DRWT STRING COMMENT '支取方式代码'
    ,AA66PEFG STRING COMMENT '交易密码启用标志'
    ,PWD_ENCRYPT_MODE_CD STRING COMMENT '密码加密方式代码'
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD STRING COMMENT '电话银行密码加密方式代码'
    ,AB16BAL DECIMAL(28,2) COMMENT '当前余额'
    ,AB14BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,AB20AMT DECIMAL(28,2) COMMENT '保留金额'
    ,AB18AMT DECIMAL(28,2) COMMENT '冻结金额'
    ,AB19AMT DECIMAL(28,2) COMMENT '止付金额'
    ,AB21AMT DECIMAL(28,2) COMMENT '授权金额'
    ,AA35SFTP STRING COMMENT '收费方式代码'
    ,AB23FLTP STRING COMMENT '浮动利率周期代码'
    ,AB12ICTP STRING COMMENT '计息方式代码'
    ,AB13DATE STRING COMMENT '起息日期'
    ,AB26AC15 STRING COMMENT '收息账户编号'
    ,AB27DATE STRING COMMENT '开户日期'
    ,AA61CFTP STRING COMMENT '开户证件类型代码'
    ,AA62CFNO STRING COMMENT '开户证件号码'
    ,AA22CFTP STRING COMMENT '支取证件类型代码'
    ,AA23CFNO STRING COMMENT '支取证件号码'
    ,AB28DATE STRING COMMENT '结清日期'
    ,AA44DATE STRING COMMENT '销户日期'
    ,WX_BIND_FLAG STRING COMMENT '微信绑定标志'
    ,RECV_INTERCONT_OPEN_FLAG STRING COMMENT '丰收互联开通标志'
    ,STATUS_VERI_STATUS_CD STRING COMMENT '身份核查状态代码'
    ,AB31BRNO STRING COMMENT '核算机构编号'
    ,AB29BRNO STRING COMMENT '统计机构编号'
    ,AB30BRNO STRING COMMENT '归属机构编号'
    ,BUOPDATE STRING COMMENT '建立日期'
    ,BUTSSTAF STRING COMMENT '建立柜员编号'
    ,UPOPDATE STRING COMMENT '最后修改日期'
    ,UPTSSTAF STRING COMMENT '最后修改柜员编号'
    ,AB33DATE STRING COMMENT '最后交易日期'
    ,AB32DATE STRING COMMENT '客户最后交易日期'
    ,RCSTRS1B STRING COMMENT '记录状态代码'
    ,AA64SDTP STRING COMMENT '保证金业务种类'
    ,AB10NO10 STRING COMMENT '交易标志'
    ,BUDISTAM STRING COMMENT '建立时间戳'
    ,UPDTSTAM STRING COMMENT '建立时间戳'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_011(
     AB01AC15 -- 账户编号
    ,AA01AC15 -- 账户编号
    ,AA04FLNM -- 账户名称
    ,AB02CCYC -- 币种代码
    ,AB03CHSX -- 钞汇代码
    ,AA10CSTP -- 客户类型代码
    ,AA03CSNO -- 客户内码
    ,AA24SSLV -- 通兑级别代码
    ,AA25SWLV -- 通存级别代码
    ,AA13ZHTP -- 账户性质代码
    ,AA12ACT2 -- 介质类型代码
    ,AA09SN03 -- 挂卡标志
    ,AA14BLNO -- 存单折号码
    ,AA11ACFG -- 账户类型代码
    ,AB08ACST -- 账户状态代码
    ,AA06BUST -- 存款业务类别代码
    ,AA07PDTP -- 产品e代码
    ,AA08PRON -- 产品代码
    ,AB06ACID -- 存款科目号
    ,AA48BRNO -- 核算主体行
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AA16PZZT -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,AA18DRWT -- 支取方式代码
    ,AA66PEFG -- 交易密码启用标志
    ,PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,AB16BAL -- 当前余额
    ,AB14BAL -- 昨日余额
    ,AB20AMT -- 保留金额
    ,AB18AMT -- 冻结金额
    ,AB19AMT -- 止付金额
    ,AB21AMT -- 授权金额
    ,AA35SFTP -- 收费方式代码
    ,AB23FLTP -- 浮动利率周期代码
    ,AB12ICTP -- 计息方式代码
    ,AB13DATE -- 起息日期
    ,AB26AC15 -- 收息账户编号
    ,AB27DATE -- 开户日期
    ,AA61CFTP -- 开户证件类型代码
    ,AA62CFNO -- 开户证件号码
    ,AA22CFTP -- 支取证件类型代码
    ,AA23CFNO -- 支取证件号码
    ,AB28DATE -- 结清日期
    ,AA44DATE -- 销户日期
    ,WX_BIND_FLAG -- 微信绑定标志
    ,RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,AB31BRNO -- 核算机构编号
    ,AB29BRNO -- 统计机构编号
    ,AB30BRNO -- 归属机构编号
    ,BUOPDATE -- 建立日期
    ,BUTSSTAF -- 建立柜员编号
    ,UPOPDATE -- 最后修改日期
    ,UPTSSTAF -- 最后修改柜员编号
    ,AB33DATE -- 最后交易日期
    ,AB32DATE -- 客户最后交易日期
    ,RCSTRS1B -- 记录状态代码
    ,AA64SDTP -- 保证金业务种类
    ,AB10NO10 -- 交易标志
    ,BUDISTAM -- 建立时间戳
    ,UPDTSTAM -- 建立时间戳
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS AB01AC15 -- 账户编号
    ,P2.AA01AC15 AS AA01AC15 -- 账户编号
    ,P2.AA04FLNM AS AA04FLNM -- 账户名称
    ,P1.AB02CCYC AS AB02CCYC -- 币种代码
    ,P1.AB03CHSX AS AB03CHSX -- 钞汇代码
    ,P2.AA10CSTP AS AA10CSTP -- 客户类型代码
    ,P2.AA03CSNO AS AA03CSNO -- 客户内码
    ,P2.AA24SSLV AS AA24SSLV -- 通兑级别代码
    ,P2.AA25SWLV AS AA25SWLV -- 通存级别代码
    ,P2.AA13ZHTP AS AA13ZHTP -- 账户性质代码
    ,P2.AA12ACT2 AS AA12ACT2 -- 介质类型代码
    ,P2.AA09SN03 AS AA09SN03 -- 挂卡标志
    ,P2.AA14BLNO AS AA14BLNO -- 存单折号码
    ,P2.AA11ACFG AS AA11ACFG -- 账户类型代码
    ,CASE WHEN  P1.AB08ACST='2' 
      AND  SUBSTR(P1.AB09NO16,7,1)='1' 
      AND   P3.CB15BDHS<>'3' --销户  
     THEN '5'                --不动户 
     ELSE P1.AB08ACST 
END AS AB08ACST -- 账户状态代码
    ,P2.AA06BUST AS AA06BUST -- 存款业务类别代码
    ,P2.AA07PDTP AS AA07PDTP -- 产品e代码
    ,P2.AA08PRON AS AA08PRON -- 产品代码
    ,P1.AB06ACID AS AB06ACID -- 存款科目号
    ,P2.AA48BRNO AS AA48BRNO -- 核算主体行
    ,CONCAT(P2.AA07PDTP,P2.AA08PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,SUBSTR(P2.AA78NO20,2,5) AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,CASE WHEN SUBSTR(P2.AA78NO20,2,5)='91107' THEN '1' --1-定活互转
WHEN SUBSTR(P2.AA78NO20,2,5)='91109' THEN '2'      --2-定活通
WHEN SUBSTR(P2.AA78NO20,2,5)='91111' THEN '3'      --3-定盈宝
ELSE '' END AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,CASE WHEN SUBSTR(P1.AB09NO16,3,1)='1' THEN '1' --1-全部止付
         WHEN  SUBSTR(P1.AB11NO02,2,1)='1' THEN '2' --2-部分止付
 ELSE '0' --0未止付
END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P2.AA16PZZT AS AA16PZZT -- 挂失状态代码
    ,CASE WHEN SUBSTR(P1.AB09NO16,2,1)='1' THEN '1'  -- 1-全部冻结
          WHEN SUBSTR(P1.AB09NO16,1,1)='1' THEN '3' --3-借方冻结
         WHEN  SUBSTR(P1.AB11NO02,1,1)='1' THEN '2'  --2-部分冻结
ELSE '0'  --0-未冻结
END AS FRZ_STATUS_CD -- 冻结状态代码
    ,P2.AA18DRWT AS AA18DRWT -- 支取方式代码
    ,P2.AA66PEFG AS AA66PEFG -- 交易密码启用标志
    ,SUBSTR(P2.AA19JMFS,1,1) AS PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,SUBSTR(P2.AA19JMFS,2,1) AS TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,P1.AB16BAL AS AB16BAL -- 当前余额
    ,P1.AB14BAL AS AB14BAL -- 昨日余额
    ,P1.AB20AMT AS AB20AMT -- 保留金额
    ,P1.AB18AMT AS AB18AMT -- 冻结金额
    ,P1.AB19AMT AS AB19AMT -- 止付金额
    ,P1.AB21AMT AS AB21AMT -- 授权金额
    ,P2.AA35SFTP AS AA35SFTP -- 收费方式代码
    ,P1.AB23FLTP AS AB23FLTP -- 浮动利率周期代码
    ,P1.AB12ICTP AS AB12ICTP -- 计息方式代码
    ,P1.AB13DATE AS AB13DATE -- 起息日期
    ,P1.AB26AC15 AS AB26AC15 -- 收息账户编号
    ,P1.AB27DATE AS AB27DATE -- 开户日期
    ,P2.AA61CFTP AS AA61CFTP -- 开户证件类型代码
    ,P2.AA62CFNO AS AA62CFNO -- 开户证件号码
    ,P2.AA22CFTP AS AA22CFTP -- 支取证件类型代码
    ,P2.AA23CFNO AS AA23CFNO -- 支取证件号码
    ,P1.AB28DATE AS AB28DATE -- 结清日期
    ,P2.AA44DATE AS AA44DATE -- 销户日期
    ,SUBSTR(P2.AA34NO16,13,1) AS WX_BIND_FLAG -- 微信绑定标志
    ,SUBSTR(P2.AA78NO20,10,1) AS RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,SUBSTR(P2.AA34NO16,10,1) AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,P1.AB31BRNO AS AB31BRNO -- 核算机构编号
    ,P1.AB29BRNO AS AB29BRNO -- 统计机构编号
    ,P1.AB30BRNO AS AB30BRNO -- 归属机构编号
    ,P1.BUOPDATE AS BUOPDATE -- 建立日期
    ,P1.BUTSSTAF AS BUTSSTAF -- 建立柜员编号
    ,P1.UPOPDATE AS UPOPDATE -- 最后修改日期
    ,P1.UPTSSTAF AS UPTSSTAF -- 最后修改柜员编号
    ,P1.AB33DATE AS AB33DATE -- 最后交易日期
    ,P1.AB32DATE AS AB32DATE -- 客户最后交易日期
    ,CASE WHEN TRIM(P1.RCSTRS1B)='' THEN '0' 
     WHEN TRIM(P1.RCSTRS1B) IS NULL THEN '0' 
     ELSE TRIM(P1.RCSTRS1B)
END AS RCSTRS1B -- 记录状态代码
    ,P2.AA64SDTP AS AA64SDTP -- 保证金业务种类
    ,p1.AB10NO10 AS AB10NO10 -- 交易标志
    ,P1.BUDISTAM AS BUDISTAM -- 建立时间戳
    ,P1.UPDTSTAM AS UPDTSTAM -- 建立时间戳
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE${version_num}.ODS_CORE_BDFMHQAB_TF AS P1 -- 活期存款余额主档

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款帐户主档
       ON P1.AB01AC15 = P2.AA01AC15 
AND P2.DEL_F='0' 
    AND P2.PT_DT='${process_date}' 
LEFT JOIN (SELECT CB15BDHS ,CB01AC22 FROM ODS_CORE${version_num}.ODS_CORE_BDFMHQCB_TF WHERE  DEL_F='0' AND PT_DT='${process_date}') AS P3 -- 不动户活期存款帐户主档
       ON P2.AA01AC15 =P3.CB01AC22 
WHERE SUBSTR(P1.AB01AC15,1,1) = '1' 
    AND P1.DEL_F='0' 
    AND P1.PT_DT='${process_date}'
;
-- ==============聚合层字段映射（第1-2组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_012;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_012 (
     AB01AC15 STRING COMMENT '账户编号'
    ,AA01AC15 STRING COMMENT '账户编号'
    ,AA04FLNM STRING COMMENT '账户名称'
    ,AB02CCYC STRING  COMMENT '币种代码'
    ,AB03CHSX STRING  COMMENT '钞汇代码'
    ,AA10CSTP STRING  COMMENT '客户类型代码'
    ,AA03CSNO STRING COMMENT '客户内码'
    ,USER_ID STRING COMMENT '用户ID'
    ,AA24SSLV STRING  COMMENT '通兑级别代码'
    ,AA25SWLV STRING  COMMENT '通存级别代码'
    ,AA13ZHTP STRING  COMMENT '账户性质代码'
    ,AA12ACT2 STRING  COMMENT '介质类型代码'
    ,AA09SN03 STRING  COMMENT '挂卡标志'
    ,AA14BLNO DECIMAL(20)  COMMENT '存单折号码'
    ,AA11ACFG STRING  COMMENT '账户类型代码'
    ,AB08ACST  STRING  COMMENT '账户状态代码'
    ,AA06BUST STRING  COMMENT '存款业务类别代码'
    ,AA07PDTP STRING  COMMENT '产品e代码'
    ,AA08PRON STRING  COMMENT '产品代码'
    ,AB06ACID STRING COMMENT '存款科目号'
    ,AA48BRNO STRING COMMENT '核算主体行'
    ,DPSIT_PROD_CD STRING  COMMENT '存款产品代码'
    ,DPSIT_COMB_PROD_CD STRING  COMMENT '存款组合产品代码'
    ,DPSIT_COMB_PROD_NAME STRING COMMENT '存款组合产品名称'
    ,STOP_PAY_STATUS_CD STRING  COMMENT '止付状态代码'
    ,AA16PZZT STRING  COMMENT '挂失状态代码'
    ,FRZ_STATUS_CD STRING  COMMENT '冻结状态代码'
    ,AA18DRWT STRING  COMMENT '支取方式代码'
    ,AA66PEFG STRING  COMMENT '交易密码启用标志'
    ,PWD_ENCRYPT_MODE_CD STRING  COMMENT '密码加密方式代码'
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD STRING  COMMENT '电话银行密码加密方式代码'
    ,AB16BAL DECIMAL(28,2) COMMENT '当前余额'
    ,AB14BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,AB20AMT DECIMAL(28,2) COMMENT '保留金额'
    ,AB18AMT DECIMAL(28,2) COMMENT '冻结金额'
    ,AB19AMT DECIMAL(28,2) COMMENT '止付金额'
    ,AB21AMT DECIMAL(28,2) COMMENT '授权金额'
    ,AA35SFTP STRING  COMMENT '收费方式代码'
    ,AB23FLTP STRING  COMMENT '浮动利率周期代码'
    ,AB12ICTP STRING  COMMENT '计息方式代码'
    ,AB13DATE STRING  COMMENT '起息日期'
    ,AB26AC15 STRING COMMENT '收息账户编号'
    ,AB27DATE STRING  COMMENT '开户日期'
    ,AA61CFTP STRING  COMMENT '开户证件类型代码'
    ,AA62CFNO STRING COMMENT '开户证件号码'
    ,AA22CFTP STRING  COMMENT '支取证件类型代码'
    ,AA23CFNO STRING COMMENT '支取证件号码'
    ,AB28DATE STRING  COMMENT '结清日期'
    ,AA44DATE STRING  COMMENT '销户日期'
    ,WX_BIND_FLAG STRING  COMMENT '微信绑定标志'
    ,RECV_INTERCONT_OPEN_FLAG STRING  COMMENT '丰收互联开通标志'
    ,STATUS_VERI_STATUS_CD STRING  COMMENT '身份核查状态代码'
    ,AB31BRNO STRING   COMMENT '核算机构编号'
    ,AB29BRNO STRING COMMENT '统计机构编号'
    ,AB30BRNO STRING COMMENT '归属机构编号'
    ,BUOPDATE STRING  COMMENT '建立日期'
    ,BUTSSTAF STRING COMMENT '建立柜员编号'
    ,UPOPDATE STRING  COMMENT '最后修改日期'
    ,UPTSSTAF STRING COMMENT '最后修改柜员编号'
    ,AB33DATE STRING  COMMENT '最后交易日期'
    ,AB32DATE STRING  COMMENT '客户最后交易日期'
    ,RCSTRS1B STRING  COMMENT '记录状态代码'
    ,AA64SDTP STRING  COMMENT '保证金业务种类'
    ,AB10NO10 STRING  COMMENT '交易标志'
    ,BUDISTAM STRING  COMMENT '建立时间戳'
    ,UPDTSTAM STRING  COMMENT '最后修改时间戳'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_012(
     AB01AC15 -- 账户编号
    ,AA01AC15 -- 账户编号
    ,AA04FLNM -- 账户名称
    ,AB02CCYC -- 币种代码
    ,AB03CHSX -- 钞汇代码
    ,AA10CSTP -- 客户类型代码
    ,AA03CSNO -- 客户内码
    ,USER_ID -- 用户ID
    ,AA24SSLV -- 通兑级别代码
    ,AA25SWLV -- 通存级别代码
    ,AA13ZHTP -- 账户性质代码
    ,AA12ACT2 -- 介质类型代码
    ,AA09SN03 -- 挂卡标志
    ,AA14BLNO -- 存单折号码
    ,AA11ACFG -- 账户类型代码
    ,AB08ACST  -- 账户状态代码
    ,AA06BUST -- 存款业务类别代码
    ,AA07PDTP -- 产品e代码
    ,AA08PRON -- 产品代码
    ,AB06ACID -- 存款科目号
    ,AA48BRNO -- 核算主体行
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AA16PZZT -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,AA18DRWT -- 支取方式代码
    ,AA66PEFG -- 交易密码启用标志
    ,PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,AB16BAL -- 当前余额
    ,AB14BAL -- 昨日余额
    ,AB20AMT -- 保留金额
    ,AB18AMT -- 冻结金额
    ,AB19AMT -- 止付金额
    ,AB21AMT -- 授权金额
    ,AA35SFTP -- 收费方式代码
    ,AB23FLTP -- 浮动利率周期代码
    ,AB12ICTP -- 计息方式代码
    ,AB13DATE -- 起息日期
    ,AB26AC15 -- 收息账户编号
    ,AB27DATE -- 开户日期
    ,AA61CFTP -- 开户证件类型代码
    ,AA62CFNO -- 开户证件号码
    ,AA22CFTP -- 支取证件类型代码
    ,AA23CFNO -- 支取证件号码
    ,AB28DATE -- 结清日期
    ,AA44DATE -- 销户日期
    ,WX_BIND_FLAG -- 微信绑定标志
    ,RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,AB31BRNO -- 核算机构编号
    ,AB29BRNO -- 统计机构编号
    ,AB30BRNO -- 归属机构编号
    ,BUOPDATE -- 建立日期
    ,BUTSSTAF -- 建立柜员编号
    ,UPOPDATE -- 最后修改日期
    ,UPTSSTAF -- 最后修改柜员编号
    ,AB33DATE -- 最后交易日期
    ,AB32DATE -- 客户最后交易日期
    ,RCSTRS1B -- 记录状态代码
    ,AA64SDTP -- 保证金业务种类
    ,AB10NO10 -- 交易标志
    ,BUDISTAM -- 建立时间戳
    ,UPDTSTAM -- 最后修改时间戳
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS AB01AC15 -- 账户编号
    ,P1.AA01AC15 AS AA01AC15 -- 账户编号
    ,P1.AA04FLNM AS AA04FLNM -- 账户名称
    ,P1.AB02CCYC AS AB02CCYC -- 币种代码
    ,P1.AB03CHSX AS AB03CHSX -- 钞汇代码
    ,P1.AA10CSTP AS AA10CSTP -- 客户类型代码
    ,P1.AA03CSNO AS AA03CSNO -- 客户内码
    ,COALESCE(P2.USER_ID,P3.CUSTID) AS USER_ID -- 用户ID
    ,P1.AA24SSLV AS AA24SSLV -- 通兑级别代码
    ,P1.AA25SWLV AS AA25SWLV -- 通存级别代码
    ,P1.AA13ZHTP AS AA13ZHTP -- 账户性质代码
    ,P1.AA12ACT2 AS AA12ACT2 -- 介质类型代码
    ,P1.AA09SN03 AS AA09SN03 -- 挂卡标志
    ,P1.AA14BLNO AS AA14BLNO -- 存单折号码
    ,P1.AA11ACFG AS AA11ACFG -- 账户类型代码
    ,P1.AB08ACST  AS AB08ACST  -- 账户状态代码
    ,P1.AA06BUST AS AA06BUST -- 存款业务类别代码
    ,P1.AA07PDTP AS AA07PDTP -- 产品e代码
    ,P1.AA08PRON AS AA08PRON -- 产品代码
    ,P1.AB06ACID AS AB06ACID -- 存款科目号
    ,P1.AA48BRNO AS AA48BRNO -- 核算主体行
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P1.DPSIT_COMB_PROD_CD AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,P1.DPSIT_COMB_PROD_NAME AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P1.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P1.AA16PZZT AS AA16PZZT -- 挂失状态代码
    ,P1.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,P1.AA18DRWT AS AA18DRWT -- 支取方式代码
    ,P1.AA66PEFG AS AA66PEFG -- 交易密码启用标志
    ,P1.PWD_ENCRYPT_MODE_CD AS PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,P1.TEL_BANK_PWD_ENCRYPT_MODE_CD AS TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,P1.AB16BAL AS AB16BAL -- 当前余额
    ,P1.AB14BAL AS AB14BAL -- 昨日余额
    ,P1.AB20AMT AS AB20AMT -- 保留金额
    ,P1.AB18AMT AS AB18AMT -- 冻结金额
    ,P1.AB19AMT AS AB19AMT -- 止付金额
    ,P1.AB21AMT AS AB21AMT -- 授权金额
    ,P1.AA35SFTP AS AA35SFTP -- 收费方式代码
    ,P1.AB23FLTP AS AB23FLTP -- 浮动利率周期代码
    ,P1.AB12ICTP AS AB12ICTP -- 计息方式代码
    ,P1.AB13DATE AS AB13DATE -- 起息日期
    ,P1.AB26AC15 AS AB26AC15 -- 收息账户编号
    ,P1.AB27DATE AS AB27DATE -- 开户日期
    ,P1.AA61CFTP AS AA61CFTP -- 开户证件类型代码
    ,P1.AA62CFNO AS AA62CFNO -- 开户证件号码
    ,P1.AA22CFTP AS AA22CFTP -- 支取证件类型代码
    ,P1.AA23CFNO AS AA23CFNO -- 支取证件号码
    ,P1.AB28DATE AS AB28DATE -- 结清日期
    ,P1.AA44DATE AS AA44DATE -- 销户日期
    ,P1.WX_BIND_FLAG AS WX_BIND_FLAG -- 微信绑定标志
    ,P1.RECV_INTERCONT_OPEN_FLAG AS RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,P1.STATUS_VERI_STATUS_CD AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,P1.AB31BRNO AS AB31BRNO -- 核算机构编号
    ,P1.AB29BRNO AS AB29BRNO -- 统计机构编号
    ,P1.AB30BRNO AS AB30BRNO -- 归属机构编号
    ,P1.BUOPDATE AS BUOPDATE -- 建立日期
    ,P1.BUTSSTAF AS BUTSSTAF -- 建立柜员编号
    ,P1.UPOPDATE AS UPOPDATE -- 最后修改日期
    ,P1.UPTSSTAF AS UPTSSTAF -- 最后修改柜员编号
    ,P1.AB33DATE AS AB33DATE -- 最后交易日期
    ,P1.AB32DATE AS AB32DATE -- 客户最后交易日期
    ,P1.RCSTRS1B AS RCSTRS1B -- 记录状态代码
    ,P1.AA64SDTP AS AA64SDTP -- 保证金业务种类
    ,p1.AB10NO10 AS AB10NO10 -- 交易标志
    ,P1.BUDISTAM AS BUDISTAM -- 建立时间戳
    ,P1.UPDTSTAM AS UPDTSTAM -- 最后修改时间戳
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_011 AS P1 -- 活期存款余额主档

LEFT JOIN (SELECT * FROM (
   SELECT
      USER_ID
     ,CST_IN_CD
     ,ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY USER_ID DESC ) AS RN 
   FROM ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF  
   WHERE DEL_F='0' AND  PT_DT='${process_date}'
)T WHERE RN=1) AS P2 -- 用户信息表
       ON P1.AA03CSNO = P2.CST_IN_CD 
LEFT JOIN (SELECT * FROM (
   SELECT
      CUSTID
     ,CUSTCD
     ,ROW_NUMBER() OVER (PARTITION BY CUSTCD ORDER BY STATUS DESC ) AS RN 
   FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF  
   WHERE DEL_F='0' AND  PT_DT='${process_date}'
)T WHERE RN=1) AS P3 -- 客户信息关联表
       ON P1.AA03CSNO = P3.CUSTCD 
;
-- ==============聚合层字段映射（第1-3组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01 (
     AB01AC15 STRING COMMENT '账户编号'
    ,AA01AC15 STRING COMMENT '账户编号'
    ,AA04FLNM STRING COMMENT '账户名称'
    ,AB02CCYC STRING COMMENT '币种代码'
    ,AB03CHSX STRING COMMENT '钞汇代码'
    ,AA10CSTP STRING COMMENT '客户类型代码'
    ,AA03CSNO STRING COMMENT '客户内码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CRTF_TYP STRING COMMENT '主证件类型代码'
    ,CRTF_NO STRING COMMENT '主证件号码'
    ,AA24SSLV STRING COMMENT '通兑级别代码'
    ,AA25SWLV STRING COMMENT '通存级别代码'
    ,AA13ZHTP STRING COMMENT '账户性质代码'
    ,AA12ACT2 STRING COMMENT '介质类型代码'
    ,AA09SN03 STRING COMMENT '挂卡标志'
    ,AA14BLNO DECIMAL(20) COMMENT '存单折号码'
    ,AA11ACFG STRING COMMENT '账户类型代码'
    ,AB08ACST  STRING COMMENT '账户状态代码'
    ,AA06BUST STRING COMMENT '存款业务类别代码'
    ,AA07PDTP STRING COMMENT '产品e代码'
    ,AA08PRON STRING COMMENT '产品代码'
    ,AB06ACID STRING COMMENT '存款科目号'
    ,AA48BRNO STRING COMMENT '核算主体行'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_COMB_PROD_CD STRING COMMENT '存款组合产品代码'
    ,DPSIT_COMB_PROD_NAME STRING COMMENT '存款组合产品名称'
    ,STOP_PAY_STATUS_CD STRING COMMENT '止付状态代码'
    ,AA16PZZT STRING COMMENT '挂失状态代码'
    ,FRZ_STATUS_CD STRING COMMENT '冻结状态代码'
    ,AA18DRWT STRING COMMENT '支取方式代码'
    ,AA66PEFG STRING COMMENT '交易密码启用标志'
    ,PWD_ENCRYPT_MODE_CD STRING COMMENT '密码加密方式代码'
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD STRING COMMENT '电话银行密码加密方式代码'
    ,AB16BAL DECIMAL(28,2) COMMENT '当前余额'
    ,AB14BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,AB20AMT DECIMAL(28,2) COMMENT '保留金额'
    ,AB18AMT DECIMAL(28,2) COMMENT '冻结金额'
    ,AB19AMT DECIMAL(28,2) COMMENT '止付金额'
    ,AB21AMT DECIMAL(28,2) COMMENT '授权金额'
    ,AA35SFTP STRING COMMENT '收费方式代码'
    ,AB23FLTP STRING COMMENT '浮动利率周期代码'
    ,AB12ICTP STRING COMMENT '计息方式代码'
    ,AB13DATE STRING COMMENT '起息日期'
    ,AB26AC15 STRING COMMENT '收息账户编号'
    ,AB27DATE STRING COMMENT '开户日期'
    ,AA61CFTP STRING COMMENT '开户证件类型代码'
    ,AA62CFNO STRING COMMENT '开户证件号码'
    ,AA22CFTP STRING COMMENT '支取证件类型代码'
    ,AA23CFNO STRING COMMENT '支取证件号码'
    ,AB28DATE STRING COMMENT '结清日期'
    ,AA44DATE STRING COMMENT '销户日期'
    ,WX_BIND_FLAG STRING COMMENT '微信绑定标志'
    ,RECV_INTERCONT_OPEN_FLAG STRING COMMENT '丰收互联开通标志'
    ,STATUS_VERI_STATUS_CD STRING COMMENT '身份核查状态代码'
    ,AB31BRNO STRING COMMENT '核算机构编号'
    ,AB29BRNO STRING COMMENT '统计机构编号'
    ,AB30BRNO STRING COMMENT '归属机构编号'
    ,BUOPDATE STRING COMMENT '建立日期'
    ,BUTSSTAF STRING COMMENT '建立柜员编号'
    ,UPOPDATE STRING COMMENT '最后修改日期'
    ,UPTSSTAF STRING COMMENT '最后修改柜员编号'
    ,AB33DATE STRING COMMENT '最后交易日期'
    ,AB32DATE STRING COMMENT '客户最后交易日期'
    ,RCSTRS1B STRING COMMENT '记录状态代码'
    ,AA64SDTP STRING COMMENT '保证金业务种类'
    ,AB10NO10 STRING COMMENT '交易标志'
    ,BUDISTAM STRING COMMENT '建立时间戳'
    ,UPDTSTAM STRING COMMENT '最后修改时间戳'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01(
     AB01AC15 -- 账户编号
    ,AA01AC15 -- 账户编号
    ,AA04FLNM -- 账户名称
    ,AB02CCYC -- 币种代码
    ,AB03CHSX -- 钞汇代码
    ,AA10CSTP -- 客户类型代码
    ,AA03CSNO -- 客户内码
    ,USER_ID -- 用户ID
    ,CRTF_TYP -- 主证件类型代码
    ,CRTF_NO -- 主证件号码
    ,AA24SSLV -- 通兑级别代码
    ,AA25SWLV -- 通存级别代码
    ,AA13ZHTP -- 账户性质代码
    ,AA12ACT2 -- 介质类型代码
    ,AA09SN03 -- 挂卡标志
    ,AA14BLNO -- 存单折号码
    ,AA11ACFG -- 账户类型代码
    ,AB08ACST  -- 账户状态代码
    ,AA06BUST -- 存款业务类别代码
    ,AA07PDTP -- 产品e代码
    ,AA08PRON -- 产品代码
    ,AB06ACID -- 存款科目号
    ,AA48BRNO -- 核算主体行
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AA16PZZT -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,AA18DRWT -- 支取方式代码
    ,AA66PEFG -- 交易密码启用标志
    ,PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,AB16BAL -- 当前余额
    ,AB14BAL -- 昨日余额
    ,AB20AMT -- 保留金额
    ,AB18AMT -- 冻结金额
    ,AB19AMT -- 止付金额
    ,AB21AMT -- 授权金额
    ,AA35SFTP -- 收费方式代码
    ,AB23FLTP -- 浮动利率周期代码
    ,AB12ICTP -- 计息方式代码
    ,AB13DATE -- 起息日期
    ,AB26AC15 -- 收息账户编号
    ,AB27DATE -- 开户日期
    ,AA61CFTP -- 开户证件类型代码
    ,AA62CFNO -- 开户证件号码
    ,AA22CFTP -- 支取证件类型代码
    ,AA23CFNO -- 支取证件号码
    ,AB28DATE -- 结清日期
    ,AA44DATE -- 销户日期
    ,WX_BIND_FLAG -- 微信绑定标志
    ,RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,AB31BRNO -- 核算机构编号
    ,AB29BRNO -- 统计机构编号
    ,AB30BRNO -- 归属机构编号
    ,BUOPDATE -- 建立日期
    ,BUTSSTAF -- 建立柜员编号
    ,UPOPDATE -- 最后修改日期
    ,UPTSSTAF -- 最后修改柜员编号
    ,AB33DATE -- 最后交易日期
    ,AB32DATE -- 客户最后交易日期
    ,RCSTRS1B -- 记录状态代码
    ,AA64SDTP -- 保证金业务种类
    ,AB10NO10 -- 交易标志
    ,BUDISTAM -- 建立时间戳
    ,UPDTSTAM -- 最后修改时间戳
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS AB01AC15 -- 账户编号
    ,P1.AA01AC15 AS AA01AC15 -- 账户编号
    ,P1.AA04FLNM AS AA04FLNM -- 账户名称
    ,P1.AB02CCYC AS AB02CCYC -- 币种代码
    ,P1.AB03CHSX AS AB03CHSX -- 钞汇代码
    ,P1.AA10CSTP AS AA10CSTP -- 客户类型代码
    ,P1.AA03CSNO AS AA03CSNO -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P2.CRTF_TYP AS CRTF_TYP -- 主证件类型代码
    ,P2.CRTF_NO AS CRTF_NO -- 主证件号码
    ,P1.AA24SSLV AS AA24SSLV -- 通兑级别代码
    ,P1.AA25SWLV AS AA25SWLV -- 通存级别代码
    ,P1.AA13ZHTP AS AA13ZHTP -- 账户性质代码
    ,P1.AA12ACT2 AS AA12ACT2 -- 介质类型代码
    ,P1.AA09SN03 AS AA09SN03 -- 挂卡标志
    ,P1.AA14BLNO AS AA14BLNO -- 存单折号码
    ,P1.AA11ACFG AS AA11ACFG -- 账户类型代码
    ,P1.AB08ACST  AS AB08ACST  -- 账户状态代码
    ,P1.AA06BUST AS AA06BUST -- 存款业务类别代码
    ,P1.AA07PDTP AS AA07PDTP -- 产品e代码
    ,P1.AA08PRON AS AA08PRON -- 产品代码
    ,P1.AB06ACID AS AB06ACID -- 存款科目号
    ,P1.AA48BRNO AS AA48BRNO -- 核算主体行
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P1.DPSIT_COMB_PROD_CD AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,P1.DPSIT_COMB_PROD_NAME AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P1.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P1.AA16PZZT AS AA16PZZT -- 挂失状态代码
    ,P1.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,P1.AA18DRWT AS AA18DRWT -- 支取方式代码
    ,P1.AA66PEFG AS AA66PEFG -- 交易密码启用标志
    ,P1.PWD_ENCRYPT_MODE_CD AS PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,P1.TEL_BANK_PWD_ENCRYPT_MODE_CD AS TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,P1.AB16BAL AS AB16BAL -- 当前余额
    ,P1.AB14BAL AS AB14BAL -- 昨日余额
    ,P1.AB20AMT AS AB20AMT -- 保留金额
    ,P1.AB18AMT AS AB18AMT -- 冻结金额
    ,P1.AB19AMT AS AB19AMT -- 止付金额
    ,P1.AB21AMT AS AB21AMT -- 授权金额
    ,P1.AA35SFTP AS AA35SFTP -- 收费方式代码
    ,P1.AB23FLTP AS AB23FLTP -- 浮动利率周期代码
    ,P1.AB12ICTP AS AB12ICTP -- 计息方式代码
    ,P1.AB13DATE AS AB13DATE -- 起息日期
    ,P1.AB26AC15 AS AB26AC15 -- 收息账户编号
    ,P1.AB27DATE AS AB27DATE -- 开户日期
    ,P1.AA61CFTP AS AA61CFTP -- 开户证件类型代码
    ,P1.AA62CFNO AS AA62CFNO -- 开户证件号码
    ,P1.AA22CFTP AS AA22CFTP -- 支取证件类型代码
    ,P1.AA23CFNO AS AA23CFNO -- 支取证件号码
    ,P1.AB28DATE AS AB28DATE -- 结清日期
    ,P1.AA44DATE AS AA44DATE -- 销户日期
    ,P1.WX_BIND_FLAG AS WX_BIND_FLAG -- 微信绑定标志
    ,P1.RECV_INTERCONT_OPEN_FLAG AS RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,P1.STATUS_VERI_STATUS_CD AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,P1.AB31BRNO AS AB31BRNO -- 核算机构编号
    ,P1.AB29BRNO AS AB29BRNO -- 统计机构编号
    ,P1.AB30BRNO AS AB30BRNO -- 归属机构编号
    ,P1.BUOPDATE AS BUOPDATE -- 建立日期
    ,P1.BUTSSTAF AS BUTSSTAF -- 建立柜员编号
    ,P1.UPOPDATE AS UPOPDATE -- 最后修改日期
    ,P1.UPTSSTAF AS UPTSSTAF -- 最后修改柜员编号
    ,P1.AB33DATE AS AB33DATE -- 最后交易日期
    ,P1.AB32DATE AS AB32DATE -- 客户最后交易日期
    ,P1.RCSTRS1B AS RCSTRS1B -- 记录状态代码
    ,P1.AA64SDTP AS AA64SDTP -- 保证金业务种类
    ,p1.AB10NO10 AS AB10NO10 -- 交易标志
    ,P1.BUDISTAM AS BUDISTAM -- 建立时间戳
    ,P1.UPDTSTAM AS UPDTSTAM -- 最后修改时间戳
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_012 AS P1 -- 活期存款余额主档

LEFT JOIN (SELECT 
CST_IN_CD,
CRTF_NO,
CRTF_TYP
FROM 
(SELECT 
CST_IN_CD,
CRTF_NO,
CRTF_TYP,
ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) AS RN 
FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF 
WHERE MAJOR_FLG='1'
AND DELETED = '0' AND DEL_F='0'
AND PT_DT='${process_date}'
) where RN=1) AS P2 -- 客户证件信息表
       ON P1.AA03CSNO = P2.CST_IN_CD 
;
-- ==============聚合层字段映射（第1-4组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_02;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_02 (
     AB01AC15 STRING COMMENT '账户编号'
    ,AB02CCYC STRING  COMMENT '币种代码'
    ,AB03CHSX STRING  COMMENT '钞汇代码'
    ,CDNOAC19 STRING COMMENT '主卡卡号'
    ,CW05FLNM STRING COMMENT '存款产品名称'
    ,KHDAACID STRING COMMENT '会计科目编号'
    ,KHDAFLNM STRING COMMENT '会计科目名称'
    ,YESTD_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_02(
     AB01AC15 -- 账户编号
    ,AB02CCYC -- 币种代码
    ,AB03CHSX -- 钞汇代码
    ,CDNOAC19 -- 主卡卡号
    ,CW05FLNM -- 存款产品名称
    ,KHDAACID -- 会计科目编号
    ,KHDAFLNM -- 会计科目名称
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS AB01AC15 -- 账户编号
    ,P1.AB02CCYC AS AB02CCYC -- 币种代码
    ,P1.AB03CHSX AS AB03CHSX -- 钞汇代码
    ,P5.CDNOAC19 AS CDNOAC19 -- 主卡卡号
    ,P6.CW05FLNM AS CW05FLNM -- 存款产品名称
    ,P7.KHDAACID AS KHDAACID -- 会计科目编号
    ,P7.KHDAFLNM AS KHDAFLNM -- 会计科目名称
    ,CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB14BAL
     ELSE P1.AB14BAL*(NVL(P8.YRCAEXRT,0)/NVL(P8.YRCACUNO,1))  
END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01 AS P1 -- None

LEFT JOIN (SELECT DFANAC19,CDNOAC19 FROM(
 SELECT
   DFANAC19
  ,CDNOAC19
  ,ROW_NUMBER() OVER(PARTITION BY DFANAC19 ORDER BY UPDTDATE DESC ) RN
 FROM ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF
 WHERE DEL_F = '0' AND PT_DT = '${process_date}' AND CRDSCRDS <> '5'
   AND CDNOAC19 IN ( SELECT PRNOAC19 FROM ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF
                     WHERE CRDSCRDS <> '5' AND DEL_F = '0' AND PT_DT = '${process_date}' AND TRIM(PRNOAC19) <> '' )
 )T WHERE T.RN = 1) AS P5 -- 借记卡信息主档文件
       ON P1.AA01AC15=P5.DFANAC19 
LEFT JOIN (
 select
  d6.CW02PDTP,
  d6.CW03PRON,
  d6.CW05FLNM
 from
  ODS_CORE${version_num}.ODS_CORE_BDFMHQCW_TF d6
 where
  d6.DEL_F = '0'
  and d6.PT_DT = '${process_date}'
) AS P6 -- 产品代码定义文件
       ON P1.AA07PDTP=P6.CW02PDTP  
AND P1.AA08PRON =P6.CW03PRON 
LEFT JOIN (
 select
  d7.KHDAACID,
  d7.KHDAFLNM,
  d7.KHDBACID  
 from
  ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF d7
 where
  d7.DEL_F = '0'
  and d7.PT_DT = '${process_date}'
) AS P7 -- 新会计科目核算码对照表
       ON P1.AB06ACID=P7.KHDBACID 
LEFT JOIN (
 select
  d8.YRCAEXRT,
  d8.YRCACUNO,
  d8.YRCACCYC 
 from
  ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF d8
 where
   CAST(d8.YRCADATE as STRING)=REPLACE('${process_date}','-','') 
  AND d8.YRCARS1B <> '9' 
  AND d8.DEL_F='0'  
  AND d8.PT_DT='${process_date}'
) AS P8 -- 年度报表汇率文件
       ON P1.AB02CCYC=P8.YRCACCYC 
;
-- ==============聚合层字段映射（第1-5组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_03;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_03 (
     AB01AC15 STRING COMMENT '账户编号'
    ,AB02CCYC STRING COMMENT '币种代码'
    ,AB03CHSX STRING COMMENT '钞汇代码'
    ,AA48BRNO STRING COMMENT '核算主体行'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,OPEN_ACCT_INT_RATE DECIMAL(20,7) COMMENT '开户利率'
    ,D1__RATE DECIMAL(20,7) COMMENT '基准利率'
    ,FLOT_INT_RATE DECIMAL(20,7) COMMENT '浮动利率'
    ,FLOT_INT_RATE_TYPE_CD STRING COMMENT '浮动利率类型代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_03(
     AB01AC15 -- 账户编号
    ,AB02CCYC -- 币种代码
    ,AB03CHSX -- 钞汇代码
    ,AA48BRNO -- 核算主体行
    ,DPSIT_PROD_CD -- 存款产品代码
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,D1__RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS AB01AC15 -- 账户编号
    ,P1.AB02CCYC AS AB02CCYC -- 币种代码
    ,P1.AB03CHSX AS AB03CHSX -- 钞汇代码
    ,P1.AA48BRNO AS AA48BRNO -- 核算主体行
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,CASE WHEN P9.D2__RATE<>0 THEN P10.D1__RATE+P9.D2__RATE WHEN P9.D2__RTIO<>0 THEN P10.D1__RATE*(P9.D2__RTIO/100+1) ELSE 0 END  AS OPEN_ACCT_INT_RATE -- 开户利率
    ,P10.D1__RATE AS D1__RATE -- 基准利率
    ,CASE WHEN P9.D2__RATE<>0 THEN P10.D1__RATE+P9.D2__RATE WHEN P9.D2__RTIO<>0 THEN P10.D1__RATE*(P9.D2__RTIO/100+1) ELSE 0 END  AS FLOT_INT_RATE -- 浮动利率
    ,CASE WHEN P9.D2__RATE<>0 THEN 2 WHEN P9.D2__RTIO<>0 THEN 1 ELSE 0 END  AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01 AS P1 -- None

LEFT JOIN (
select
    D9.D2__RATE,
    D9.D2__RTIO,
    D9.D2__PDTP,
    D9.D2__PRON,
    D9.D2__PDTP||D9.D2__PRON AS DPSIT_PROD_CD,
    D9.D2LSDATE,
    D9.D2__BKNO,
    D9.D2__CCYC,
    D9.D2__BIRC
from
 (
 select
  D2__RATE,
  D2__RTIO,
  D2__PDTP,
  D2__PRON,
  D2LSDATE,
  D2__BKNO,
  D2__CCYC,
  D2__BIRC
 from
  ODS_CORE${version_num}.ODS_CORE_BIFDPDIR_TF B
 where
  D2LSDATE = 18991231
  and D2__BIRC <> ''
  and PT_DT = '${process_date}'
  and DEL_F = '0'
  and D2__PDTP <> '11'
  and D2__PRON <> '101'
  and D2__BKNO <> '695'
  and D2__RTIO <> 20
 group by
  D2__RATE,
  D2__RTIO,
  D2__PRON,
  D2LSDATE,
  D2__BKNO,
  D2__CCYC,
  D2__BIRC,
  D2__PDTP )
 D9
 ) AS P9 -- 分行产品利率表
       ON P1.DPSIT_PROD_CD = P9.DPSIT_PROD_CD
 AND substr(P1.AA48BRNO,1,3) = P9.D2__BKNO
 AND P1.AB02CCYC=P9.D2__CCYC 
LEFT JOIN (
 select
  d10.D1__BIRC,
  d10.D1__CCYC,
  d10.D1__RATE 
 from
  ODS_CORE${version_num}.ODS_CORE_BIFDBRIR_TF d10
 where
    d10.D1LSDATE = 18991231
  AND d10.DEL_F='0'
  AND d10.PT_DT='${process_date}'
) AS P10 -- 银行/分行基本利率表
       ON P9.D2__BIRC = P10.D1__BIRC 
AND P1.AB02CCYC=P10.D1__CCYC 
;
-- ==============聚合层字段映射（第1-6组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_04;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_04 (
     AB01AC15 STRING COMMENT '账户编号'
    ,AB02CCYC STRING  COMMENT '币种代码'
    ,AB03CHSX STRING  COMMENT '钞汇代码'
    ,BC35CNCD STRING  COMMENT '开户渠道代码'
    ,BQ07BRNO STRING COMMENT '销户机构编号'
    ,BQ08STAF STRING COMMENT '销户柜员编号'
    ,BQ09CNCD STRING  COMMENT '销户渠道代码'
    ,BC19AMT DECIMAL(28,2) COMMENT '开户金额'
    ,BC34STAF STRING  COMMENT '开户柜员'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_04(
     AB01AC15 -- 账户编号
    ,AB02CCYC -- 币种代码
    ,AB03CHSX -- 钞汇代码
    ,BC35CNCD -- 开户渠道代码
    ,BQ07BRNO -- 销户机构编号
    ,BQ08STAF -- 销户柜员编号
    ,BQ09CNCD -- 销户渠道代码
    ,BC19AMT -- 开户金额
    ,BC34STAF -- 开户柜员
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS AB01AC15 -- 账户编号
    ,P1.AB02CCYC AS AB02CCYC -- 币种代码
    ,P1.AB03CHSX AS AB03CHSX -- 钞汇代码
    ,CASE WHEN P13.BC35CNCD='CC' THEN 'IC' 
ELSE P13.BC35CNCD
END  AS BC35CNCD -- 开户渠道代码
    ,P14.BQ07BRNO AS BQ07BRNO -- 销户机构编号
    ,P14.BQ08STAF AS BQ08STAF -- 销户柜员编号
    ,CASE WHEN P14.BQ09CNCD='CC' THEN 'IC' 
ELSE P14.BQ09CNCD
END AS BQ09CNCD -- 销户渠道代码
    ,p13.BC19AMT AS BC19AMT -- 开户金额
    ,p13.BC34STAF AS BC34STAF -- 开户柜员
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01 AS P1 -- None

LEFT JOIN (
select  
 T13.BC01AC22  
 ,T13.BC03CCYC
 ,T13.BC04CHSX
 ,T13.BC31DATE  
 ,T13.BC35CNCD
 ,T13.BC09ACT2
 ,T13.BC19AMT
 ,T13.BC34STAF
 ,T13.PT_DT
 from 
(
select 
  D12.BC01AC22  
 ,D12.BC03CCYC
 ,D12.BC04CHSX
 ,D12.BC31DATE  
 ,D12.BC35CNCD
 ,d12.BC09ACT2
 ,d12.BC19AMT
 ,d12.BC34STAF
 ,D12.PT_DT
,ROW_NUMBER()OVER(partition by  D12.BC01AC22 ,D12.BC03CCYC,D12.BC04CHSX,D12.BC31DATE order by D12.BC31DATE desc ) RN 
from ODS_CORE${version_num}.ODS_CORE_BDFMHQBC_TF D12
where D12.DEL_F='0' 
AND  D12.PT_DT='${process_date}'
)T13
where T13.RN =1 
) AS P13 -- 开户登记簿
       ON P1.AB01AC15=P13.BC01AC22 
and P1.AB02CCYC=P13.BC03CCYC 
and P1.AB03CHSX=P13.BC04CHSX 
and P1.AB27DATE =CAST(P13.BC31DATE AS STRING)  
LEFT JOIN (
select  
 T14.BQ01AC22  
 ,T14.BQ03CCYC
 ,T14.BQ04CHSX
 ,T14.BQ06DATE  
 ,T14.BQ07BRNO
 ,T14.BQ08STAF
 ,T14.BQ09CNCD
 ,T14.BQ10CLSN
 ,T14.BQ11AMT
 ,T14.BQ12AMT
 ,T14.BQ13AMT
 ,T14.PT_DT
 from 
(
select 
  d12.BQ01AC22  
 ,d12.BQ03CCYC
 ,d12.BQ04CHSX
 ,d12.BQ06DATE  
 ,d12.BQ07BRNO
 ,d12.BQ08STAF
 ,d12.BQ09CNCD
 ,d12.BQ10CLSN
 ,d12.BQ11AMT
 ,d12.BQ12AMT
 ,D12.BQ13AMT
 ,D12.PT_DT
,ROW_NUMBER()OVER(partition by  D12.BQ01AC22 ,D12.BQ03CCYC,D12.BQ04CHSX,D12.BQ06DATE order by D12.BQ06DATE desc ) RN 
from ODS_CORE${version_num}.ODS_CORE_BDFMHQBQ_TF D12
where D12.DEL_F='0' 
AND  D12.PT_DT='${process_date}'
)T14
where T14.RN =1 
) AS P14 -- 销户登记簿
       ON P1.AA01AC15=P14.BQ01AC22 
AND  P1.AB02CCYC=P14.BQ03CCYC 
AND P1.AB03CHSX=P14.bq04chsx 
AND P1.AA44DATE = CAST(P14.BQ06DATE  AS STRING) 
;
-- ==============聚合层字段映射（第1-0组）==============
-- 个人活期存款账户聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CUST_TYPE_CD -- 客户类型代码
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,MRG_BIZ_CATE -- 保证金业务种类
    ,MED_TYPE_CD -- 介质类型代码
    ,HANG_CARD_FLAG -- 挂卡标志
    ,MASTER_CARD_NO -- 主卡卡号
    ,DPSTRCP_CONVT_NO -- 存单折号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,ALLOW_WITHDR_CASH_FLAG -- 允许提现标志
    ,ALLOW_DRAW_FLAG -- 允许支取标志
    ,ALLOW_DPSIT_IN_FLAG -- 允许存入标志
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD_ENABLED_FLAG -- 交易密码启用标志
    ,PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,AUTH_AMT -- 授权金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CHARGE_MODE_CD -- 收费方式代码
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,BNCHMK_INT_RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,INTACR_MODE_CD -- 计息方式代码
    ,SETMENT_FREQ -- 结息频率
    ,VAL_DT -- 起息日期
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,OPEN_ACCT_TM -- 开户时间
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,OPEN_ACCT_AMT -- 开户金额
    ,OPEN_ACCT_TELR -- 开户柜员
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,DRAW_DOCTYP_CD -- 支取证件类型代码
    ,DRAW_DOC_NO -- 支取证件号码
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,WX_BIND_FLAG -- 微信绑定标志
    ,RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AB01AC15 AS ACCT_NO -- 账户编号
    ,P1.AA04FLNM AS ACCT_NAME -- 账户名称
    ,P1.AB02CCYC AS CURR_CD -- 币种代码
    ,P1.AB03CHSX AS CASH_RMT_CD -- 钞汇代码
    ,P1.AA10CSTP AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN SUBSTR(P1.AA03CSNO,1,2)='81' THEN '1' WHEN SUBSTR(P1.AA03CSNO,1,2)='82' THEN '2' ELSE 3 END AS CUST_TYPE_CD -- 客户类型代码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P1.AA04FLNM AS CUST_NAME -- 客户名称
    ,P1.CRTF_TYP AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P1.CRTF_NO AS MAIN_DOC_NO -- 主证件号码
    ,P1.AA24SSLV AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,P1.AA25SWLV AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,CASE WHEN TRIM(P1.AA13ZHTP)=''  OR P1.AA13ZHTP IS NULL THEN '9999' ELSE P1.AA13ZHTP END  AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN TRIM(P1.AA64SDTP)='' THEN '0' ELSE '1' END AS MRGACCT_FLAG -- 保证金账户标志
    ,P1.AA64SDTP AS MRG_BIZ_CATE -- 保证金业务种类
    ,P1.AA12ACT2 AS MED_TYPE_CD -- 介质类型代码
    ,P1.AA09SN03 AS HANG_CARD_FLAG -- 挂卡标志
    ,P2.CDNOAC19 AS MASTER_CARD_NO -- 主卡卡号
    ,P1.AA14BLNO AS DPSTRCP_CONVT_NO -- 存单折号码
    ,P1.AA11ACFG AS ACCT_TYPE_CD -- 账户类型代码
    ,P1.AB08ACST AS ACCT_STATUS_CD -- 账户状态代码
    ,'' AS EACCT_NO -- 电子账户编号
    ,'' AS EACCT_STATUS_CD -- 电子账户状态代码
    ,'' AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,'' AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,'' AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,P1.AA06BUST AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P2.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.DPSIT_COMB_PROD_CD AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,P1.DPSIT_COMB_PROD_NAME AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P1.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P1.AA16PZZT AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P1.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,CASE WHEN SUBSTR(TRIM(p1.AB10NO10),1,1)='1' THEN '1' ELSE '0' END AS ALLOW_WITHDR_CASH_FLAG -- 允许提现标志
    ,CASE WHEN SUBSTR(TRIM(p1.AB10NO10),2,1)='1' THEN '1' ELSE '0' END AS ALLOW_DRAW_FLAG -- 允许支取标志
    ,CASE WHEN SUBSTR(TRIM(p1.AB10NO10),3,1)='1' THEN '1' ELSE '0' END AS ALLOW_DPSIT_IN_FLAG -- 允许存入标志
    ,P1.AA18DRWT AS DRAW_MODE_CD -- 支取方式代码
    ,P1.AA66PEFG AS TXN_PWD_ENABLED_FLAG -- 交易密码启用标志
    ,P1.PWD_ENCRYPT_MODE_CD AS PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,P1.TEL_BANK_PWD_ENCRYPT_MODE_CD AS TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,P2.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P2.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.AB16BAL AS CURR_BAL -- 当前余额
    ,P1.AB14BAL AS YESTD_BAL -- 昨日余额
    ,P1.AB20AMT AS KEEP_AMT -- 保留金额
    ,P1.AB18AMT AS FRZ_AMT -- 冻结金额
    ,P1.AB19AMT AS STOP_PAY_AMT -- 止付金额
    ,P1.AB21AMT AS AUTH_AMT -- 授权金额
    ,CASE WHEN  trunc('${process_date}','MM') = '${process_date}'
                   THEN COALESCE(P1.AB14BAL,0)
             ELSE COALESCE(P17.YESTD_BAL_MONTH_ACCUM,0)+COALESCE(P1.AB14BAL,0)
    END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN  trunc('${process_date}','quarter') = '${process_date}'
                   THEN COALESCE(P1.AB14BAL,0)
             ELSE COALESCE(P17.YESTD_BAL_QUAR_ACCUM,0)+COALESCE(P1.AB14BAL,0)
        end AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN  trunc('${process_date}','YY') = '${process_date}'
                   THEN COALESCE(P1.AB14BAL,0)
             ELSE COALESCE(P17.YESTD_BAL_YEAR_ACCUM,0)+COALESCE(P1.AB14BAL,0)
        end AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,P2.YESTD_BAL_CONVT_RMB AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN  trunc('${process_date}','MM') = '${process_date}'
                   THEN COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
             ELSE COALESCE(P17.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0)+COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
    END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN  trunc('${process_date}','quarter') = '${process_date}'
                   THEN COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
             ELSE COALESCE(P17.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0)+COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
        end AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN  trunc('${process_date}','YY') = '${process_date}'
                   THEN COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
             ELSE COALESCE(P17.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0)+COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
        end AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,P1.AA35SFTP AS CHARGE_MODE_CD -- 收费方式代码
    ,P3.OPEN_ACCT_INT_RATE AS OPEN_ACCT_INT_RATE -- 开户利率
    ,P3.D1__RATE AS BNCHMK_INT_RATE -- 基准利率
    ,P3.FLOT_INT_RATE AS FLOT_INT_RATE -- 浮动利率
    ,P1.AB23FLTP AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,P3.FLOT_INT_RATE_TYPE_CD AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,CASE WHEN P1.AB12ICTP IS NULL OR TRIM(P1.AB12ICTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(P18.TARGET_CD_VAL), '@'||TRIM(P1.AB12ICTP),'') 
END  AS INTACR_MODE_CD -- 计息方式代码
    ,'' AS SETMENT_FREQ -- 结息频率
    ,unifiedTime(P1.AB13DATE) AS VAL_DT -- 起息日期
    ,P1.AB26AC15 AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,case when P12.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P12.ACTL_INT_AMT_YEAR_CUM,0)  --当为年初时，取当日余额
ELSE COALESCE(P12.ACTL_INT_AMT_YEAR_CUM,0)+ COALESCE(p17.ACTL_INT_AMT_YEAR_CUM,0)  END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,unifiedTime(P1.AB27DATE) AS OPEN_ACCT_DT -- 开户日期
    ,'' AS OPEN_ACCT_TM -- 开户时间
    ,P1.AA61CFTP AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.AA62CFNO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P4.BC19AMT AS OPEN_ACCT_AMT -- 开户金额
    ,P4.BC34STAF AS OPEN_ACCT_TELR -- 开户柜员
    ,P4.BC35CNCD AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,'' AS AGENT_NAME -- 代理人名称
    ,'' AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,'' AS AGENT_DOC_NO -- 代理人证件号码
    ,'' AS AGENT_CONT_MODE -- 代理人联系方式
    ,P1.AA22CFTP AS DRAW_DOCTYP_CD -- 支取证件类型代码
    ,P1.AA23CFNO AS DRAW_DOC_NO -- 支取证件号码
    ,unifiedTime(P1.AB28DATE) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(P1.AA44DATE) AS CANC_ACCT_DT -- 销户日期
    ,P4.BQ07BRNO AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,P4.BQ08STAF AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,P4.BQ09CNCD AS CANC_ACCT_CHNL -- 销户渠道代码
    ,P1.WX_BIND_FLAG AS WX_BIND_FLAG -- 微信绑定标志
    ,P1.RECV_INTERCONT_OPEN_FLAG AS RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,P1.STATUS_VERI_STATUS_CD AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,P1.AB31BRNO AS LP_ORG_NO -- 法人机构编号
    ,P1.AB29BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.AB30BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,'CORE' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,substr(unifiedTime(P1.BUOPDATE),1,10) AS SETUP_DT -- 建立日期
    ,unifiedTime(p1.BUDISTAM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.BUTSSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,substr(unifiedTime(P1.UPOPDATE),1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(p1.UPDTSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.UPTSSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,substr(unifiedTime(P1.AB33DATE),1,10) AS FINAL_TXN_DT -- 最后交易日期
    ,substr(unifiedTime(P1.AB32DATE),1,10) AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,P1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAB_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01 AS P1 -- None

LEFT JOIN AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_02 AS P2 -- None
       ON P1.AB01AC15 = P2.AB01AC15
AND P1.AB02CCYC = P2.AB02CCYC
AND P1.AB03CHSX = P2.AB03CHSX 
LEFT JOIN AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_03 AS P3 -- None
       ON P1.AB01AC15 = P3.AB01AC15
AND P1.AB02CCYC = P3.AB02CCYC
AND P1.AB03CHSX = P3.AB03CHSX 
LEFT JOIN AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_04 AS P4 -- None
       ON P1.AB01AC15 = P4.AB01AC15
AND P1.AB02CCYC = P4.AB02CCYC
AND P1.AB03CHSX = P4.AB03CHSX 
LEFT JOIN (
SELECT
   MAX(NTNLT)  NTNLT
  ,MAX(OCPTN)  OCPTN
  ,CST_IN_CD
FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF  
WHERE DELETED='0'  AND DEL_F='0' AND  PT_DT='${process_date}'
GROUP BY CST_IN_CD
) AS P5 -- None
       ON P1.AA03CSNO=P5.CST_IN_CD 
LEFT JOIN (SELECT
   T1.MG__AC22
  ,SUM(T1.MGMSAMT + T1.MGYSAMT) AS ACTL_INT_AMT_YEAR_CUM
  ,T1.PT_DT
FROM   ODS_CORE${version_num}.ODS_CORE_BIFMLXDJ_TF T1 --帐户利息登记簿
WHERE  TO_DATE(CAST(T1.MG__DATE AS STRING) ,'yyyymmdd') = TO_DATE(REPLACE('${process_date}','-',''),'yyyymmdd') --跑批日期参数
  AND T1.RCSTRS1B NOT IN ('1','9') AND T1.PT_DT = '${process_date}' AND    T1.DEL_F = '0' 
GROUP BY T1.MG__AC22,T1.PT_DT
) AS P12 -- 帐户利息登记簿
       ON P1.AB01AC15=P12.MG__AC22 
LEFT JOIN (
SELECT  T1.ACCT_NO,
        T1.CURR_CD,
        T1.CASH_RMT_CD
       ,T1.YESTD_BAL_MONTH_ACCUM
       ,T1.YESTD_BAL_QUAR_ACCUM
       ,T1.YESTD_BAL_YEAR_ACCUM
       ,T1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
       ,T1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
       ,T1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
       ,T1.ACTL_INT_AMT_YEAR_CUM
FROM  AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF  T1
WHERE  T1.SRC_SYS_CD='CORE'  
AND T1.PT_DT=  CAST(DATE_SUB('${process_date}',1) as STRING ) 
) AS P17 -- None
       ON P1.AB01AC15=P17.ACCT_NO
AND P1.AB02CCYC=P17.CURR_CD
AND P1.AB03CHSX=P17.CASH_RMT_CD 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P18 -- 码值表
       ON P1.AB12ICTP=P18.SRC_CD_VAL  
AND P18.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
AND P18.SRC_TAB_EN_NAME='BDFMHQAB' --来源表英文名 大写
AND P18.SRC_FIELD_EN_NAME='AB12ICTP' --来源字段英文名 大写
AND P18.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_INFO_TF' --目标表名 大写
AND P18.TARGET_FIELD_EN_NAME='INTACR_MODE_CD' --目标字段 大写 
;
-- ==============聚合层字段映射（第2-1组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05 (
     ACCTNO STRING COMMENT '账户编号'
    ,CUSTAC STRING COMMENT '客户账号'
    ,ACCTCD STRING COMMENT '核算代码'
    ,ACSETP STRING COMMENT '子账户类型'
    ,ACCTNA STRING COMMENT '账户名称'
    ,CRCYCD STRING  COMMENT '币种代码'
    ,CSEXTG STRING  COMMENT '钞汇代码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CST_IN_CD STRING COMMENT '客户内码'
    ,ACCT_PROPTY_CD STRING  COMMENT '账户性质代码'
    ,ACCTST STRING  COMMENT '账户状态代码'
    ,DEBTTP STRING  COMMENT '存款业务类别代码'
    ,PRODCD STRING  COMMENT '存款产品代码'
    ,ONLNBL DECIMAL(28,2) COMMENT '当前余额'
    ,LASTBL DECIMAL(28,2) COMMENT '昨日余额'
    ,HDMIMY DECIMAL(28,2) COMMENT '保留金额'
    ,BGINDT STRING  COMMENT '起息日期'
    ,OPENDT STRING  COMMENT '开户日期'
    ,CRTF_TYP STRING  COMMENT '开户证件类型代码'
    ,CRTF_NO STRING COMMENT '开户证件号码'
    ,PAYOFF_DT STRING  COMMENT '结清日期'
    ,CANC_ACCT_DT STRING  COMMENT '销户日期'
    ,CANC_ACCT_CHNL STRING  COMMENT '销户渠道代码'
    ,BRCHNO STRING   COMMENT '核算机构编号'
    ,SETUP_DT STRING  COMMENT '建立日期'
    ,TIMETM STRING  COMMENT '最后修改日期'
    ,TRPROD STRING  COMMENT 'None'
    ,EACCT_NO STRING  COMMENT '电子账户编号'
    ,EACCT_STATUS_CD STRING  COMMENT '电子账户状态代码'
    ,ELEC_LIACCT_PROPTY_CD STRING  COMMENT '电子负债账户账户性质代码'
    ,ELEC_LIACCT_CLS_CD STRING  COMMENT '电子负债账户账户分类代码'
    ,ELEC_LIACCT_TYPE_CD STRING  COMMENT '电子负债账户账户类型代码'
    ,OPENUS STRING  COMMENT '开户柜员'
    ,TIMETM1 STRING  COMMENT '时间戳'
    ,OPMONY DECIMAL(28,2) COMMENT '开户金额'
    ,OPEN_ACCT_CHNL_CD STRING COMMENT '开户渠道代码'
    ,CORPNO STRING COMMENT '法人机构'
    ,LSTRDT STRING COMMENT '上次交易日期'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05(
     ACCTNO -- 账户编号
    ,CUSTAC -- 客户账号
    ,ACCTCD -- 核算代码
    ,ACSETP -- 子账户类型
    ,ACCTNA -- 账户名称
    ,CRCYCD -- 币种代码
    ,CSEXTG -- 钞汇代码
    ,USER_ID -- 用户ID
    ,CST_IN_CD -- 客户内码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,ACCTST -- 账户状态代码
    ,DEBTTP -- 存款业务类别代码
    ,PRODCD -- 存款产品代码
    ,ONLNBL -- 当前余额
    ,LASTBL -- 昨日余额
    ,HDMIMY -- 保留金额
    ,BGINDT -- 起息日期
    ,OPENDT -- 开户日期
    ,CRTF_TYP -- 开户证件类型代码
    ,CRTF_NO -- 开户证件号码
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,BRCHNO -- 核算机构编号
    ,SETUP_DT -- 建立日期
    ,TIMETM -- 最后修改日期
    ,TRPROD -- None
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户账户类型代码
    ,OPENUS -- 开户柜员
    ,TIMETM1 -- 时间戳
    ,OPMONY -- 开户金额
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CORPNO -- 法人机构
    ,LSTRDT -- 上次交易日期
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCTNO AS ACCTNO -- 账户编号
    ,P1.CUSTAC AS CUSTAC -- 客户账号
    ,P1.ACCTCD AS ACCTCD -- 核算代码
    ,P1.ACSETP AS ACSETP -- 子账户类型
    ,P1.ACCTNA AS ACCTNA -- 账户名称
    ,P1.CRCYCD AS CRCYCD -- 币种代码
    ,P1.CSEXTG AS CSEXTG -- 钞汇代码
    ,P2.CUSTID AS USER_ID -- 用户ID
    ,CASE WHEN TRIM(T2.CUST_INNER_ID)<>'' THEN TRIM(T2.CUST_INNER_ID) ELSE P2.CUSTCD END AS CST_IN_CD -- 客户内码
    ,CASE WHEN P3.ACCATP = '1'             AND P1.ACSETP= '01'     THEN '0011' --个人结算户-I类个人结算户
     WHEN  P3.ACCATP = '2'            AND P1.ACSETP= '01'     THEN '0013' --个人结算户-II类个人结算户
     WHEN P3.ACCATP = '3'             AND P1.ACSETP= '03'     THEN 'W003' --亲情钱包
     WHEN  P3.ACCATP = '3'            AND P1.ACSETP= '02'     THEN '0014' --个人结算户-III类个人结算户
     WHEN P1.ACSETP IN ('04','08')                            THEN '0012' --个人储蓄户
     WHEN P1.ACSETP = '01'            AND P3.ACCATP IS NULL   THEN '0011' --个人结算户-I类个人结算户
     WHEN P1.ACSETP = '02'            AND P3.ACCATP IS NULL   THEN '0014' --个人结算户-III类个人结算户
ELSE '9999' END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.ACCTST AS ACCTST -- 账户状态代码
    ,P1.debttp AS DEBTTP -- 存款业务类别代码
    ,P1.PRODCD AS PRODCD -- 存款产品代码
    ,P1.ONLNBL AS ONLNBL -- 当前余额
    ,CASE WHEN P1.UPBLDT<=REPLACE('${process_date}','-') OR P1.UPBLDT IS NULL THEN P1.ONLNBL ELSE P1.LASTBL END AS LASTBL -- 昨日余额
    ,P1.HDMIMY AS HDMIMY -- 保留金额
    ,P1.BGINDT AS BGINDT -- 起息日期
    ,P1.OPENDT AS OPENDT -- 开户日期
    ,P6.CRTF_TYP AS CRTF_TYP -- 开户证件类型代码
    ,P6.CRTF_NO AS CRTF_NO -- 开户证件号码
    ,P1.CLOSDT AS PAYOFF_DT -- 结清日期
    ,P1.CLOSDT AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN P1.ACCTST = '2' THEN 'NM' ELSE '' END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,P1.BRCHNO AS BRCHNO -- 核算机构编号
    ,P1.OPENDT AS SETUP_DT -- 建立日期
    ,P1.TIMETM AS TIMETM -- 最后修改日期
    ,p4.trprod AS TRPROD -- None
    ,p1.CUSTAC AS EACCT_NO -- 电子账户编号
    ,p5.acctst AS EACCT_STATUS_CD -- 电子账户状态代码
    ,p1.SPECTP AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户账户性质代码
    ,p3.ACCATP AS ELEC_LIACCT_CLS_CD -- 电子负债账户账户分类代码
    ,p1.ACSETP AS ELEC_LIACCT_TYPE_CD -- 电子负债账户账户类型代码
    ,p8.OPENUS AS OPENUS -- 开户柜员
    ,p8.TIMETM AS TIMETM1 -- 时间戳
    ,P1.OPMONY AS OPMONY -- 开户金额
    ,CASE WHEN P1.ACSETP IN ('01' ,'02','03','04') THEN 'NM' ELSE 'TE' END  AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,P1.CORPNO AS CORPNO -- 法人机构
    ,P7.TRANDT AS LSTRDT -- 上次交易日期
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS${version_num}.ODS_NAS_KNA_ACCT_TF AS P1 -- 负债活期帐户信息表

LEFT JOIN (SELECT * FROM (
   SELECT
      CUSTCD
     ,CUSTNO
     ,CUSTID
     ,ROW_NUMBER() OVER (PARTITION BY CUSTNO ORDER BY STATUS) AS RN 
   FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF 
   WHERE DEL_F='0' AND  PT_DT='${process_date}'
)T WHERE RN=1) AS P2 -- 用户信息表
       ON P1.CUSTNO  = P2.CUSTNO 
LEFT JOIN ODS_CIF${version_num}.ODS_CIF_T_CIF_CUST_BASE_INFO_TF AS T2 -- None
       ON T2.USER_ID=P2.CUSTID AND T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN (
    SELECT 
        ACCATP
        ,ACCTNO 
    FROM ODS_NAS${version_num}.ODS_NAS_KNA_ACCT_ADDT_TF D3
    WHERE   D3.DEL_F='0' 
    AND D3.PT_DT='${process_date}'
) AS P3 -- 负债账户附加信息表
       ON P1.ACCTNO=P3.ACCTNO 
LEFT JOIN (
select
 trprod
 ,acctno
from
 ods_nas${version_num}.ods_nas_kna_sign_detl_tf
where
 DEL_F = '0'
 and PT_DT = '${process_date}'
 and SIGNTP='1'
 ) AS P4 -- 转存签约明细表
       ON P1.ACCTNO=P4.ACCTNO 
LEFT JOIN (SELECT 
   D10.FROZST
  ,D10.CUSTAC
  ,D10.acctst
FROM ODS_NAS${version_num}.ODS_NAS_KNA_CUST_TF D10
WHERE   D10.DEL_F='0'  AND D10.PT_DT='${process_date}'
) AS P5 -- 电子账户表
       ON P1.CUSTAC=P5.CUSTAC 
LEFT JOIN (SELECT * FROM(
SELECT
    P2.USER_ID
   ,P2.CST_IN_CD
   ,p2.CRTF_TYP
   ,p2.CRTF_NO
   ,ROW_NUMBER()OVER(PARTITION BY CST_IN_CD ORDER BY USER_ID DESC) RN
FROM ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF P2
WHERE P2.PT_DT = '${process_date}' AND P2.DELETED='0' AND P2.DEL_F='0'
)T WHERE RN=1) AS P6 -- 用户信息表
       ON p2.CUSTCD = P6.CST_IN_CD 
LEFT JOIN (SELECT ACCTNO,MAX(TRANDT) AS TRANDT  FROM ODS_NAS${version_num}.ODS_NAS_KNL_BILL_TA WHERE PT_DT= '${process_date}' AND DEL_F='0' GROUP BY ACCTNO) AS P7 -- None
       ON P1.ACCTNO=P7.ACCTNO 
LEFT JOIN (select
 CUSTAC,
 CORPNO,
 TIMETM,
 OPENUS,
 row_number() over (partition by CUSTAC,CORPNO order by
 OPENSQ) as RN
from
 ODS_NAS${version_num}.ODS_NAS_KNB_OPAC_TF 
 where pt_dt  = '${process_date}'
 and del_f  = '0' ) AS P8 -- None
       ON P1.CUSTAC = P8.CUSTAC
and P1.CORPNO = P8.CORPNO
and p8.rn = 1 
WHERE P1.PT_DT='${process_date}'
AND P1.SPECTP IN ('0011','0012')
AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2-2组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_06;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_06 (
     ACCTNO STRING COMMENT '账户编号'
    ,CRCYCD STRING  COMMENT '币种代码'
    ,CSEXTG STRING  COMMENT '钞汇代码'
    ,CARDNO STRING COMMENT '主卡卡号'
    ,PRODTX STRING COMMENT '存款产品名称'
    ,STOP_PAY_STATUS_CD STRING  COMMENT '止付状态代码'
    ,FRZ_STATUS_CD STRING  COMMENT '冻结状态代码'
    ,SUBJECT STRING COMMENT '会计科目编号'
    ,DESCRIPTION STRING COMMENT '会计科目名称'
    ,FROZTP STRING COMMENT '冻结业务类型'
    ,FRZ_AMT DECIMAL(28,2) COMMENT '冻结金额'
    ,STOP_PAY_AMT DECIMAL(28,2) COMMENT '止付金额'
    ,YESTD_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,OPINTR DECIMAL(20,7) COMMENT '开户利率'
    ,IRFLBY STRING  COMMENT '浮动利率类型代码'
    ,REPLOS_STATUS_CD STRING  COMMENT '挂失状态代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_06(
     ACCTNO -- 账户编号
    ,CRCYCD -- 币种代码
    ,CSEXTG -- 钞汇代码
    ,CARDNO -- 主卡卡号
    ,PRODTX -- 存款产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,SUBJECT -- 会计科目编号
    ,DESCRIPTION -- 会计科目名称
    ,FROZTP -- 冻结业务类型
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,OPINTR -- 开户利率
    ,IRFLBY -- 浮动利率类型代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCTNO AS ACCTNO -- 账户编号
    ,P1.CRCYCD AS CRCYCD -- 币种代码
    ,P1.CSEXTG AS CSEXTG -- 钞汇代码
    ,P4.CARDNO AS CARDNO -- 主卡卡号
    ,P5.PRODTX AS PRODTX -- 存款产品名称
    ,coalesce(p7.STOP_PAY_STATUS_CD,CASE WHEN SUBSTR(P10.FROZST,6,1) = '1' THEN '1' --全部止付
when SUBSTR(P10.FROZST,5,1) = '1' THEN '1'--全部止付
when SUBSTR(P10.FROZST,4,1) = '1' THEN '2'--部分止付
when SUBSTR(P10.FROZST,7,1) = '1' THEN '4'--其他止付
ELSE '0' END  --未止付
) AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,p7.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,P9.SUBJECT AS SUBJECT -- 会计科目编号
    ,P9.DESCRIPTION AS DESCRIPTION -- 会计科目名称
    ,P7.FROZTP AS FROZTP -- 冻结业务类型
    ,p7.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,p7.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1)) END   AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,P12.OPINTR AS OPINTR -- 开户利率
    ,P12.IRFLBY AS IRFLBY -- 浮动利率类型代码
    ,CASE WHEN  p3.rplstp='1' THEN '6' --口挂 
WHEN P3.rplstp='2' THEN '8' --正式挂失 
else '1' --正常 
end AS REPLOS_STATUS_CD -- 挂失状态代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05 AS P1 -- None

LEFT JOIN (
select
 ACCTNO,
 RPLSTP,
 row_number() over (partition by ACCTNO
order by
 RPTLNO desc) as RN
from
 ODS_NAS${version_num}.ODS_NAS_KNB_RPVO_TF
where
 PT_DT ='${process_date}'
 and DEL_F = '0') AS P3 -- None
       ON P1.ACCTNO=P3.ACCTNO 
AND P3.RN =1 
LEFT JOIN (
    SELECT 
        D4.CARDNO
        ,D4.CUSTAC 


    FROM ODS_NAS${version_num}.ODS_NAS_KNA_ACDC_TF D4
    WHERE   D4.DEL_F='0' 
    AND D4.PT_DT='${process_date}'
) AS P4 -- 卡客户账号对照表
       ON P1.CUSTAC=P4.CUSTAC  
LEFT JOIN (
    SELECT 
        D5.PRODTX
        ,PRODCD
 FROM ODS_NAS${version_num}.ODS_NAS_KUP_DPPB_TF D5
    WHERE   D5.DEL_F='0' 
    AND D5.PT_DT='${process_date}'
) AS P5 -- 产品基础属性表
       ON P1.PRODCD=P5.PRODCD 
LEFT JOIN (SELECT
T1.CUSTAC
,T1.FROZTP
,CASE WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='1' THEN '2'
           WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='2' THEN '3'
WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='3' THEN '1'
WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='4' THEN '4' 
ELSE '0' END AS  FRZ_STATUS_CD --冻结状态代码
,CASE WHEN T1.FROZTP IN ('3' ,'4','5','6') AND T1.FRLMTP='1' THEN '2'
           WHEN T1.FROZTP IN ('3' ,'4','5','6') AND T1.FRLMTP='3' THEN '1'
WHEN T1.FROZTP IN  ('3' ,'4','5','6') AND T1.FRLMTP IN ( '2','4') THEN '3'
ELSE '0' END AS  STOP_PAY_STATUS_CD --止付状态代码
,SUM(CASE WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP IN ('3','4','1','2') THEN T2.FROZAM ELSE 0 END ) AS STOP_PAY_AMT--止付金额
,SUM(CASE WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP IN ('1','2','3','4') THEN T2.FROZAM ELSE 0 END) AS FRZ_AMT -- 冻结金额
FROM ODS_NAS${version_num}.ODS_NAS_KNB_FROZ_TF T1
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNB_FROZ_DETL_TF T2
ON T1.FROZNO = T2.FROZNO 
AND T1.FROZSQ =T2.FROZSQ  
AND T2.FROZST='0' 
AND T2.DEL_F = '0' 
and T2.pt_dt  = '${process_date}'
WHERE T1.FREDDT='20990101' 
AND T1.FROZST = '0' 
AND T1.DEL_F='0'
and T1.pt_dt  = '${process_date}'
GROUP BY T1.CUSTAC,T1.FROZTP,T1.FRLMTP) AS P7 -- 冻结登记簿
       ON P1.CUSTAC=P7.CUSTAC 
LEFT JOIN (SELECT A.PRODUCT,A.SUBJECT,C.DESCRIPTION
      FROM (SELECT EVENT_TYPE,PRODUCT,(CASE WHEN SUBJECT_DR<>'' AND SUBJECT_DR <> '30410310' THEN SUBJECT_DR ELSE SUBJECT_CR END ) SUBJECT
             FROM ODS_GAS${version_num}.ODS_GAS_CUX_EA_RULES_TF WHERE SUBSTR(EVENT_TYPE,1,1) = '1' AND PT_DT='${process_date}' ) A 
        LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_FLEX_VALUES_V_TF C
        ON C.FLEX_VALUE = A.SUBJECT
        WHERE C.PT_DT='${process_date}' AND C.DEL_F='0'
        GROUP BY A.PRODUCT,SUBJECT,C.DESCRIPTION) AS P9 -- None
       ON P1.ACCTCD= P9.PRODUCT 
LEFT JOIN (
    SELECT 
        D10.FROZST
        ,D10.CUSTAC
 FROM ODS_NAS${version_num}.ODS_NAS_KNA_CUST_TF D10
    WHERE   D10.DEL_F='0' 
    AND D10.PT_DT='${process_date}'
) AS P10 -- 电子账户表
       ON P1.CUSTAC=P10.CUSTAC 
LEFT JOIN (
 select
  d8.YRCAEXRT,
  d8.YRCACUNO,
  d8.YRCACCYC 
 from
  ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF d8
 where
   CAST(d8.YRCADATE as STRING)=REPLACE('${process_date}','-','') 
  AND d8.YRCARS1B <> '9' 
  AND d8.DEL_F='0'  
  AND d8.PT_DT='${process_date}'
)
 AS P11 -- 年度报表汇率文件
       ON P1.CRCYCD=P11.YRCACCYC 
LEFT JOIN (SELECT OPINTR,IRFLBY,ACCTNO  FROM ODS_NAS${version_num}.ODS_NAS_KUB_INRT_TF WHERE PT_DT='${process_date}' AND  DEL_F='0') AS P12 -- 账户利率表
       ON P1.ACCTNO=P12.ACCTNO 
;
-- ==============聚合层字段映射（第2-3组）==============
-- 个人活期存款账户聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_07;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_07 (
     ACCTNO STRING COMMENT '账户编号'
    ,CRCYCD STRING  COMMENT '币种代码'
    ,CSEXTG STRING  COMMENT '钞汇代码'
    ,CRTF_TYP STRING  COMMENT '主证件类型代码'
    ,CRTF_NO STRING COMMENT '主证件号码'
    ,INBEFG STRING  COMMENT '计息方式代码'
    ,CLOSBR STRING COMMENT '销户机构编号'
    ,CLOSUS STRING COMMENT '销户柜员编号'
    ,WX_BIND_FLAG STRING  COMMENT '微信绑定标志'
    ,TXBEFR STRING  COMMENT '结息频率'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人活期存款账户聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_07(
     ACCTNO -- 账户编号
    ,CRCYCD -- 币种代码
    ,CSEXTG -- 钞汇代码
    ,CRTF_TYP -- 主证件类型代码
    ,CRTF_NO -- 主证件号码
    ,INBEFG -- 计息方式代码
    ,CLOSBR -- 销户机构编号
    ,CLOSUS -- 销户柜员编号
    ,WX_BIND_FLAG -- 微信绑定标志
    ,TXBEFR -- 结息频率
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCTNO AS ACCTNO -- 账户编号
    ,P1.CRCYCD AS CRCYCD -- 币种代码
    ,P1.CSEXTG AS CSEXTG -- 钞汇代码
    ,P17.CRTF_TYP AS CRTF_TYP -- 主证件类型代码
    ,P17.CRTF_NO AS CRTF_NO -- 主证件号码
    ,CASE WHEN  P13.INBEFG='1' THEN '7'  else '0' end  AS INBEFG -- 计息方式代码
    ,P15.CLOSBR AS CLOSBR -- 销户机构编号
    ,P15.CLOSUS AS CLOSUS -- 销户柜员编号
    ,CASE WHEN LENGTH(P16.ACCT_NO)>0  THEN '1' ELSE  '0' END AS WX_BIND_FLAG -- 微信绑定标志
    ,P13.TXBEFR AS TXBEFR -- 结息频率
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05 AS P1 -- None

LEFT JOIN (
    SELECT 
        INBEFG
        ,acctno
        ,TXBEFR
 FROM ODS_NAS${version_num}.ODS_NAS_KNB_ACIN_TF D13
    WHERE   D13.DEL_F='0' 
    AND D13.PT_DT='${process_date}'
) AS P13 -- 负债账户计息信息
       ON P1.ACCTNO=P13.ACCTNO 
LEFT JOIN (select 
ACCTNO,
CLOSBR,
CLOSUS, 
CLOSSQ 
FROM 
(SELECT 
ACCTNO ,
CLOSBR ,
CLOSUS, 
CLOSSQ,
 ROW_NUMBER() OVER (PARTITION BY ACCTNO ORDER BY CLOSSQ DESC ) AS RN 
FROM ODS_NAS${version_num}.ODS_NAS_KNB_CLAC_TF
WHERE ACCTNO <>'' AND DEL_F='0'
and PT_DT='${process_date}'
) A where RN=1) AS P15 -- 电子账户销户登记簿
       ON P1.ACCTNO=P15.ACCTNO 
LEFT JOIN (
select ACCT_NO
from  ODS_CCL${version_num}.ODS_CCL_T_CCL_BOOK_TF t1
where t1.PT_DT = '${process_date}' and t1.DEL_F = '0'
group by ACCT_NO  
) AS P16 -- 合约主表
       ON P1.ACCTNO=P16.ACCT_NO 
LEFT JOIN (SELECT 
CST_IN_CD,
CRTF_TYP,
CRTF_NO 
FROM 
(SELECT  
CST_IN_CD,
CRTF_NO,
CRTF_TYP,
ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) AS RN 
FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF  
WHERE MAJOR_FLG='1'
AND DELETED ='0'
and PT_DT='${process_date}'
) where RN=1) AS P17 -- 客户证件信息表
       ON P1.CST_IN_CD=P17.CST_IN_CD 
;
-- ==============聚合层字段映射（第2-0组）==============
-- 个人活期存款账户聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CUST_TYPE_CD -- 客户类型代码
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,MRG_BIZ_CATE -- 保证金业务种类
    ,MED_TYPE_CD -- 介质类型代码
    ,HANG_CARD_FLAG -- 挂卡标志
    ,MASTER_CARD_NO -- 主卡卡号
    ,DPSTRCP_CONVT_NO -- 存单折号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,ALLOW_WITHDR_CASH_FLAG -- 允许提现标志
    ,ALLOW_DRAW_FLAG -- 允许支取标志
    ,ALLOW_DPSIT_IN_FLAG -- 允许存入标志
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD_ENABLED_FLAG -- 交易密码启用标志
    ,PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,AUTH_AMT -- 授权金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CHARGE_MODE_CD -- 收费方式代码
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,BNCHMK_INT_RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,INTACR_MODE_CD -- 计息方式代码
    ,SETMENT_FREQ -- 结息频率
    ,VAL_DT -- 起息日期
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,OPEN_ACCT_TM -- 开户时间
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,OPEN_ACCT_AMT -- 开户金额
    ,OPEN_ACCT_TELR -- 开户柜员
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,DRAW_DOCTYP_CD -- 支取证件类型代码
    ,DRAW_DOC_NO -- 支取证件号码
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,WX_BIND_FLAG -- 微信绑定标志
    ,RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCTNO AS ACCT_NO -- 账户编号
    ,P1.ACCTNA AS ACCT_NAME -- 账户名称
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,'1' AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,'1' AS CUST_TYPE_CD -- 客户类型代码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.ACCTNA AS CUST_NAME -- 客户名称
    ,P3.CRTF_TYP AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P3.CRTF_NO AS MAIN_DOC_NO -- 主证件号码
    ,'1' AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,'1' AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,P1.ACCT_PROPTY_CD AS ACCT_PROPTY_CD -- 账户性质代码
    ,'' AS MRGACCT_FLAG -- 保证金账户标志
    ,'' AS MRG_BIZ_CATE -- 保证金业务种类
    ,'8' AS MED_TYPE_CD -- 介质类型代码
    ,'1' AS HANG_CARD_FLAG -- 挂卡标志
    ,P2.CARDNO AS MASTER_CARD_NO -- 主卡卡号
    ,'' AS DPSTRCP_CONVT_NO -- 存单折号码
    ,'1' AS ACCT_TYPE_CD -- 账户类型代码
    ,CASE WHEN P1.ACCTST IS NULL OR TRIM(P1.ACCTST)='' 
     THEN '' 
ELSE COALESCE(TRIM(P24.TARGET_CD_VAL), '@'||TRIM(P1.ACCTST),'') 
END  AS ACCT_STATUS_CD -- 账户状态代码
    ,P1.EACCT_NO AS EACCT_NO -- 电子账户编号
    ,P1.EACCT_STATUS_CD AS EACCT_STATUS_CD -- 电子账户状态代码
    ,P1.ELEC_LIACCT_PROPTY_CD AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,P1.ELEC_LIACCT_CLS_CD AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,P1.ELEC_LIACCT_TYPE_CD AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,CASE WHEN P1.debttp IS NULL OR TRIM(P1.debttp)='' 
     THEN '' 
ELSE COALESCE(TRIM(P25.TARGET_CD_VAL), '@'||TRIM(P1.debttp),'') 
END  AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,P2.PRODTX AS DPSIT_PROD_NAME -- 存款产品名称
    ,'1' AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,'定活互转' AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P2.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P2.REPLOS_STATUS_CD AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P2.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,'1' AS ALLOW_WITHDR_CASH_FLAG -- 允许提现标志
    ,'1' AS ALLOW_DRAW_FLAG -- 允许支取标志
    ,'1' AS ALLOW_DPSIT_IN_FLAG -- 允许存入标志
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,'' AS TXN_PWD_ENABLED_FLAG -- 交易密码启用标志
    ,'' AS PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,'' AS TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,P2.SUBJECT AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P2.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.ONLNBL AS CURR_BAL -- 当前余额
    ,P1.LASTBL AS YESTD_BAL -- 昨日余额
    ,P1.HDMIMY AS KEEP_AMT -- 保留金额
    ,P2.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,P2.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,NULL AS AUTH_AMT -- 授权金额
    ,CASE WHEN  TRUNC('${process_date}','MM')  = '${process_date}'
                   THEN COALESCE(P1.LASTBL,0)
             ELSE COALESCE(P19.YESTD_BAL_MONTH_ACCUM,0)+COALESCE(P1.LASTBL,0)
    END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN  TRUNC('${process_date}','quarter')  = '${process_date}'
                   THEN COALESCE(P1.LASTBL,0)
             ELSE COALESCE(P19.YESTD_BAL_QUAR_ACCUM,0)+COALESCE(P1.LASTBL,0)
        end AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN  TRUNC('${process_date}','YY')  = '${process_date}'
                   THEN COALESCE(P1.LASTBL,0)
             ELSE COALESCE(P19.YESTD_BAL_YEAR_ACCUM,0)+COALESCE(P1.LASTBL,0)
        end AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,P2.YESTD_BAL_CONVT_RMB AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN  TRUNC('${process_date}','MM')  = '${process_date}'
                   THEN COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
             ELSE COALESCE(P19.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0)+COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
    END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN  TRUNC('${process_date}','quarter')  = '${process_date}'
                   THEN COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
             ELSE COALESCE(P19.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0)+COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
        end AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN  TRUNC('${process_date}','YY')  = '${process_date}'
                   THEN COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
             ELSE COALESCE(P19.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0)+COALESCE(P2.YESTD_BAL_CONVT_RMB,0)
        end AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,'' AS CHARGE_MODE_CD -- 收费方式代码
    ,P2.OPINTR AS OPEN_ACCT_INT_RATE -- 开户利率
    ,COALESCE(P20.BASEIR,0) AS BNCHMK_INT_RATE -- 基准利率
    ,CASE WHEN P22.FLIRWY = '1' THEN COALESCE(P20.baseir,0)*((P22.FLIRRT/100)+1) 
     WHEN P22.FLIRWY = '2' THEN COALESCE(P20.baseir,0)+COALESCE(P22.FLIRVL,0) ELSE 0 
END AS FLOT_INT_RATE -- 浮动利率
    ,CASE WHEN P22.RFIRTM IS NULL OR TRIM(P22.RFIRTM)='' 
     THEN '' 
ELSE COALESCE(TRIM(P23.TARGET_CD_VAL), '@'||TRIM(P22.RFIRTM),'') 
END AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,CASE WHEN P22.FLIRWY='1' THEN '2' WHEN P22.FLIRWY='2' THEN '1' ELSE '0' END AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,P3.INBEFG AS INTACR_MODE_CD -- 计息方式代码
    ,P3.TXBEFR AS SETMENT_FREQ -- 结息频率
    ,unifiedTime(P1.BGINDT) AS VAL_DT -- 起息日期
    ,P1.ACCTNO AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,case when P21.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(p21.ACTL_INT_AMT_YEAR_CUM,0)  --当为年初时，取当日余额
ELSE COALESCE(P21.ACTL_INT_AMT_YEAR_CUM,0)+ coalesce(p19.ACTL_INT_AMT_YEAR_CUM,0)  END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,unifiedTime(P1.OPENDT) AS OPEN_ACCT_DT -- 开户日期
    ,P1.TIMETM1 AS OPEN_ACCT_TM -- 开户时间
    ,P1.CRTF_TYP AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.CRTF_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.OPMONY AS OPEN_ACCT_AMT -- 开户金额
    ,P1.OPENUS AS OPEN_ACCT_TELR -- 开户柜员
    ,P1.OPEN_ACCT_CHNL_CD AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,'' AS AGENT_NAME -- 代理人名称
    ,'' AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,'' AS AGENT_DOC_NO -- 代理人证件号码
    ,'' AS AGENT_CONT_MODE -- 代理人联系方式
    ,'' AS DRAW_DOCTYP_CD -- 支取证件类型代码
    ,'' AS DRAW_DOC_NO -- 支取证件号码
    ,unifiedTime(P1.PAYOFF_DT) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(P1.PAYOFF_DT) AS CANC_ACCT_DT -- 销户日期
    ,'' AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,'' AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,P1.CANC_ACCT_CHNL AS CANC_ACCT_CHNL -- 销户渠道代码
    ,P3.WX_BIND_FLAG AS WX_BIND_FLAG -- 微信绑定标志
    ,'1' AS RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,'' AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,P1.CORPNO || '000' AS LP_ORG_NO -- 法人机构编号
    ,P1.BRCHNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,'NAS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,substr(unifiedTime(P1.SETUP_DT),1,10) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.TIMETM) AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,substr(unifiedTime(P1.TIMETM),1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,substr(unifiedTime(COALESCE(P1.LSTRDT,P19.FINAL_TXN_DT)),1,10) AS FINAL_TXN_DT -- 最后交易日期
    ,substr(unifiedTime(COALESCE(P1.LSTRDT,P19.CUST_FINAL_TXN_DT)),1,10) AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,'0' AS REC_STATUS_CD -- 记录状态代码
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNA_ACCT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05 AS P1 -- None

LEFT JOIN AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_06 AS P2 -- None
       ON p1.ACCTNO =p2.ACCTNO
and p1.CRCYCD =p2.CRCYCD
and p1.CSEXTG =p2.CSEXTG 
LEFT JOIN AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_07 AS P3 -- None
       ON p1.ACCTNO =p3.ACCTNO
and p1.CRCYCD =p3.CRCYCD
and p1.CSEXTG =p3.CSEXTG 
LEFT JOIN (SELECT * FROM (
   SELECT
      NTNLT
     ,OCPTN
     ,CST_IN_CD
     ,ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY ID DESC ) AS RN 
   FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF  
   WHERE DELETED='0'  AND DEL_F='0' AND  PT_DT='${process_date}'
)T WHERE RN=1) AS P4 -- None
       ON P1.CST_IN_CD= P4.CST_IN_CD 
LEFT JOIN (
SELECT 
    T2.PRODCD
    ,T2.INTRCD
    ,T2.CRCYCD
    ,T2.INTRTP
    ,T2.CORPNO
    ,T3.BASEIR
FROM 
(
    SELECT 
        P2.PRODCD 
        ,P2.INTRCD
        ,P2.CRCYCD
        ,P2.INTRTP
        ,P2.CORPNO
    FROM ODS_NAS${version_num}.ODS_NAS_KUP_DPPB_INTR_TF P2
    WHERE  P2.DEL_F='0' 
    AND P2.PT_DT='${process_date}'
    AND P2.INCDTP='1' 
    and COALESCE(TRIM(P2.CORPNO),'') <>''
)T2
LEFT JOIN 
(
    SELECT 
        P3.RFIRSQ
        ,P3.BASEIR
        ,P3.CORPNO
    FROM 
    ODS_NAS${version_num}.ODS_NAS_KUP_RFIR_TF P3
    WHERE  P3.DEL_F='0' 
    AND P3.PT_DT='${process_date}'
    and COALESCE(TRIM(P3.CORPNO),'') <>''
)T3
ON T2.INTRCD = T3.RFIRSQ
and T2.CORPNO = T3.CORPNO
) AS P20 -- None
       ON P1.PRODCD=P20.PRODCD 
LEFT JOIN (
SELECT 
    T2.PRODCD
    ,T2.INTRCD
    ,T2.CRCYCD
    ,T2.INTRTP
    ,T2.CORPNO
    ,T3.FLIRWY 
    ,T3.FLIRRT
    ,T3.FLIRVL
    ,T3.RFIRTM
FROM 
(
    SELECT 
        P2.PRODCD 
        ,P2.INTRCD
        ,P2.CRCYCD
        ,P2.INTRTP
        ,P2.CORPNO
    FROM ODS_NAS${version_num}.ODS_NAS_KUP_DPPB_INTR_TF P2
    WHERE  P2.DEL_F='0' 
    AND P2.PT_DT='${process_date}'
    AND P2.INCDTP='2' 
    and COALESCE(TRIM(P2.CORPNO),'') <>''
)T2
LEFT JOIN 
(
    SELECT 
        P3.BKIRSQ  
        ,p3.CORPNO
        ,P3.FLIRWY 
        ,P3.FLIRRT
        ,P3.FLIRVL
        ,P3.RFIRTM
    FROM 
    ODS_NAS${version_num}.ODS_NAS_KUP_BKIR_TF P3
    WHERE  P3.DEL_F='0' 
    AND P3.PT_DT='${process_date}'
    and COALESCE(TRIM(P3.CORPNO),'') <>''
)T3
ON T2.INTRCD = T3.BKIRSQ
and T2.CORPNO = T3.CORPNO
) AS P22 -- None
       ON P1.PRODCD=P22.PRODCD 
AND P1.crcycd = P22.CRCYCD
AND P1.CORPNO = P22.CORPNO 
LEFT JOIN (SELECT ACCTNO,SUM(RLINTR) AS  ACTL_INT_AMT_YEAR_CUM,PT_DT
 FROM    ODS_NAS${version_num}.ODS_NAS_KNB_PIDL_TF
 WHERE TO_DATE(PYINDT,'YYYYMMDD')=to_date(REPLACE('${process_date}','-',''),'yyyymmdd') 
 AND DEL_F='0'
 AND   PT_DT='${process_date}' 
 GROUP BY ACCTNO,PT_DT
) AS P21 -- None
       ON P1.ACCTNO =P21.ACCTNO 
LEFT JOIN (
SELECT  T1.ACCT_NO
       ,T1.CURR_CD
       ,T1.CASH_RMT_CD
       ,FINAL_TXN_DT
       ,CUST_FINAL_TXN_DT
       ,T1.YESTD_BAL_MONTH_ACCUM
       ,T1.YESTD_BAL_QUAR_ACCUM
       ,T1.YESTD_BAL_YEAR_ACCUM
       ,T1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
       ,T1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
       ,T1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
       ,T1.ACTL_INT_AMT_YEAR_CUM
FROM  AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF  T1
WHERE  T1.SRC_SYS_CD='NAS'  
AND T1.PT_DT=  CAST(DATE_SUB('${process_date}',1) as STRING ) 
) AS P19 -- None
       ON P1.ACCTNO=P19.ACCT_NO 
AND  P1.CRCYCD=P19.CURR_CD 
AND  P1.CSEXTG=P19.CASH_RMT_CD 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P23 -- 码值表
       ON P22.RFIRTM=P23.SRC_CD_VAL  
AND P23.SRC_TAB_LIB_NAME ='NAS'  --源系统 简称或中文名 待定
AND P23.SRC_TAB_EN_NAME='KUP_BKIR' --来源表英文名 大写
AND P23.SRC_FIELD_EN_NAME='RFIRTM' --来源字段英文名 大写
AND P23.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_INFO_TF' ---目标表名 大写
AND P23.TARGET_FIELD_EN_NAME='FLOT_INT_RATE_PERIOD_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P24 -- 码值表
       ON P1.ACCTST=P24.SRC_CD_VAL  
AND P24.SRC_TAB_LIB_NAME ='NAS'  --源系统 简称或中文名 待定
AND P24.SRC_TAB_EN_NAME='KNA_ACCT' --来源表英文名 大写
AND P24.SRC_FIELD_EN_NAME='ACCTST' --来源字段英文名 大写
AND P24.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_INFO_TF' ---目标表名 大写
AND P24.TARGET_FIELD_EN_NAME='ACCT_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P25 -- 码值表
       ON P1.DEBTTP=P25.SRC_CD_VAL  
AND P25.SRC_TAB_LIB_NAME ='NAS'  --源系统 简称或中文名 待定
AND P25.SRC_TAB_EN_NAME='KNA_ACCT' --来源表英文名 大写
AND P25.SRC_FIELD_EN_NAME='DEBTTP' --来源字段英文名 大写
AND P25.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_INFO_TF' ---目标表名 大写
AND P25.TARGET_FIELD_EN_NAME='DPSIT_BIZ_CATEGORY_CD' --目标字段 大写 
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.CASH_RMT_CD, BF.CASH_RMT_CD) END AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INDV_CORP_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.INDV_CORP_IDNT_CD, BF.INDV_CORP_IDNT_CD) END AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_TYPE_CD, BF.CUST_TYPE_CD) END AS CUST_TYPE_CD -- 客户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAIN_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.MAIN_DOCTYP_CD, BF.MAIN_DOCTYP_CD) END AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAIN_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.MAIN_DOC_NO, BF.MAIN_DOC_NO) END AS MAIN_DOC_NO -- 主证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIVERSAL_WITHDR_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD, BF.UNIVERSAL_WITHDR_LVL_CD) END AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIVERSAL_SAVING_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.UNIVERSAL_SAVING_LVL_CD, BF.UNIVERSAL_SAVING_LVL_CD) END AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_PROPTY_CD, BF.ACCT_PROPTY_CD) END AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MRGACCT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.MRGACCT_FLAG, BF.MRGACCT_FLAG) END AS MRGACCT_FLAG -- 保证金账户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MRG_BIZ_CATE IS NULL THEN NULL ELSE COALESCE(TM.MRG_BIZ_CATE, BF.MRG_BIZ_CATE) END AS MRG_BIZ_CATE -- 保证金业务种类
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.MED_TYPE_CD, BF.MED_TYPE_CD) END AS MED_TYPE_CD -- 介质类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.HANG_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.HANG_CARD_FLAG, BF.HANG_CARD_FLAG) END AS HANG_CARD_FLAG -- 挂卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MASTER_CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.MASTER_CARD_NO, BF.MASTER_CARD_NO) END AS MASTER_CARD_NO -- 主卡卡号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSTRCP_CONVT_NO IS NULL THEN NULL ELSE COALESCE(TM.DPSTRCP_CONVT_NO, BF.DPSTRCP_CONVT_NO) END AS DPSTRCP_CONVT_NO -- 存单折号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_TYPE_CD, BF.ACCT_TYPE_CD) END AS ACCT_TYPE_CD -- 账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_STATUS_CD, BF.ACCT_STATUS_CD) END AS ACCT_STATUS_CD -- 账户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.EACCT_NO, BF.EACCT_NO) END AS EACCT_NO -- 电子账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EACCT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.EACCT_STATUS_CD, BF.EACCT_STATUS_CD) END AS EACCT_STATUS_CD -- 电子账户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_PROPTY_CD, BF.ELEC_LIACCT_PROPTY_CD) END AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_CLS_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_CLS_CD, BF.ELEC_LIACCT_CLS_CD) END AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_TYPE_CD, BF.ELEC_LIACCT_TYPE_CD) END AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_BIZ_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_BIZ_CATEGORY_CD, BF.DPSIT_BIZ_CATEGORY_CD) END AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PROD_CD, BF.DPSIT_PROD_CD) END AS DPSIT_PROD_CD -- 存款产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PROD_NAME, BF.DPSIT_PROD_NAME) END AS DPSIT_PROD_NAME -- 存款产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_COMB_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_COMB_PROD_CD, BF.DPSIT_COMB_PROD_CD) END AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_COMB_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_COMB_PROD_NAME, BF.DPSIT_COMB_PROD_NAME) END AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_PAY_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.STOP_PAY_STATUS_CD, BF.STOP_PAY_STATUS_CD) END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REPLOS_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REPLOS_STATUS_CD, BF.REPLOS_STATUS_CD) END AS REPLOS_STATUS_CD -- 挂失状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.FRZ_STATUS_CD, BF.FRZ_STATUS_CD) END AS FRZ_STATUS_CD -- 冻结状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ALLOW_WITHDR_CASH_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ALLOW_WITHDR_CASH_FLAG, BF.ALLOW_WITHDR_CASH_FLAG) END AS ALLOW_WITHDR_CASH_FLAG -- 允许提现标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ALLOW_DRAW_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ALLOW_DRAW_FLAG, BF.ALLOW_DRAW_FLAG) END AS ALLOW_DRAW_FLAG -- 允许支取标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ALLOW_DPSIT_IN_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ALLOW_DPSIT_IN_FLAG, BF.ALLOW_DPSIT_IN_FLAG) END AS ALLOW_DPSIT_IN_FLAG -- 允许存入标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.DRAW_MODE_CD, BF.DRAW_MODE_CD) END AS DRAW_MODE_CD -- 支取方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_PWD_ENABLED_FLAG IS NULL THEN NULL ELSE COALESCE(TM.TXN_PWD_ENABLED_FLAG, BF.TXN_PWD_ENABLED_FLAG) END AS TXN_PWD_ENABLED_FLAG -- 交易密码启用标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PWD_ENCRYPT_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.PWD_ENCRYPT_MODE_CD, BF.PWD_ENCRYPT_MODE_CD) END AS PWD_ENCRYPT_MODE_CD -- 密码加密方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TEL_BANK_PWD_ENCRYPT_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.TEL_BANK_PWD_ENCRYPT_MODE_CD, BF.TEL_BANK_PWD_ENCRYPT_MODE_CD) END AS TEL_BANK_PWD_ENCRYPT_MODE_CD -- 电话银行密码加密方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NO, BF.ACCTN_SUBJ_NO) END AS ACCTN_SUBJ_NO -- 会计科目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NAME, BF.ACCTN_SUBJ_NAME) END AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_BAL IS NULL THEN NULL ELSE COALESCE(TM.CURR_BAL, BF.CURR_BAL) END AS CURR_BAL -- 当前余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL, BF.YESTD_BAL) END AS YESTD_BAL -- 昨日余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.KEEP_AMT IS NULL THEN NULL ELSE COALESCE(TM.KEEP_AMT, BF.KEEP_AMT) END AS KEEP_AMT -- 保留金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_AMT IS NULL THEN NULL ELSE COALESCE(TM.FRZ_AMT, BF.FRZ_AMT) END AS FRZ_AMT -- 冻结金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_PAY_AMT IS NULL THEN NULL ELSE COALESCE(TM.STOP_PAY_AMT, BF.STOP_PAY_AMT) END AS STOP_PAY_AMT -- 止付金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUTH_AMT IS NULL THEN NULL ELSE COALESCE(TM.AUTH_AMT, BF.AUTH_AMT) END AS AUTH_AMT -- 授权金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM, BF.YESTD_BAL_MONTH_ACCUM) END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM, BF.YESTD_BAL_QUAR_ACCUM) END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM, BF.YESTD_BAL_YEAR_ACCUM) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_CONVT_RMB, BF.YESTD_BAL_CONVT_RMB) END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB, BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CHARGE_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.CHARGE_MODE_CD, BF.CHARGE_MODE_CD) END AS CHARGE_MODE_CD -- 收费方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_INT_RATE IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_INT_RATE, BF.OPEN_ACCT_INT_RATE) END AS OPEN_ACCT_INT_RATE -- 开户利率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BNCHMK_INT_RATE IS NULL THEN NULL ELSE COALESCE(TM.BNCHMK_INT_RATE, BF.BNCHMK_INT_RATE) END AS BNCHMK_INT_RATE -- 基准利率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FLOT_INT_RATE IS NULL THEN NULL ELSE COALESCE(TM.FLOT_INT_RATE, BF.FLOT_INT_RATE) END AS FLOT_INT_RATE -- 浮动利率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FLOT_INT_RATE_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.FLOT_INT_RATE_PERIOD_CD, BF.FLOT_INT_RATE_PERIOD_CD) END AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FLOT_INT_RATE_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.FLOT_INT_RATE_TYPE_CD, BF.FLOT_INT_RATE_TYPE_CD) END AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INTACR_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.INTACR_MODE_CD, BF.INTACR_MODE_CD) END AS INTACR_MODE_CD -- 计息方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETMENT_FREQ IS NULL THEN NULL ELSE COALESCE(TM.SETMENT_FREQ, BF.SETMENT_FREQ) END AS SETMENT_FREQ -- 结息频率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VAL_DT IS NULL THEN NULL ELSE COALESCE(TM.VAL_DT, BF.VAL_DT) END AS VAL_DT -- 起息日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_INT_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.DRAW_INT_ACCT_NO, BF.DRAW_INT_ACCT_NO) END AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_INT_AMT_YEAR_CUM IS NULL THEN NULL ELSE COALESCE(TM.ACTL_INT_AMT_YEAR_CUM, BF.ACTL_INT_AMT_YEAR_CUM) END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DT, BF.OPEN_ACCT_DT) END AS OPEN_ACCT_DT -- 开户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_TM IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_TM, BF.OPEN_ACCT_TM) END AS OPEN_ACCT_TM -- 开户时间
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DOCTYP_CD, BF.OPEN_ACCT_DOCTYP_CD) END AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DOC_NO, BF.OPEN_ACCT_DOC_NO) END AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_AMT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_AMT, BF.OPEN_ACCT_AMT) END AS OPEN_ACCT_AMT -- 开户金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_TELR IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_TELR, BF.OPEN_ACCT_TELR) END AS OPEN_ACCT_TELR -- 开户柜员
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_CHNL_CD, BF.OPEN_ACCT_CHNL_CD) END AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_NAME IS NULL THEN NULL ELSE COALESCE(TM.AGENT_NAME, BF.AGENT_NAME) END AS AGENT_NAME -- 代理人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.AGENT_DOCTYP_CD, BF.AGENT_DOCTYP_CD) END AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.AGENT_DOC_NO, BF.AGENT_DOC_NO) END AS AGENT_DOC_NO -- 代理人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_CONT_MODE IS NULL THEN NULL ELSE COALESCE(TM.AGENT_CONT_MODE, BF.AGENT_CONT_MODE) END AS AGENT_CONT_MODE -- 代理人联系方式
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DRAW_DOCTYP_CD, BF.DRAW_DOCTYP_CD) END AS DRAW_DOCTYP_CD -- 支取证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.DRAW_DOC_NO, BF.DRAW_DOC_NO) END AS DRAW_DOC_NO -- 支取证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYOFF_DT IS NULL THEN NULL ELSE COALESCE(TM.PAYOFF_DT, BF.PAYOFF_DT) END AS PAYOFF_DT -- 结清日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_DT, BF.CANC_ACCT_DT) END AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_ORG_NO, BF.CANC_ACCT_ORG_NO) END AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_TELR_NO, BF.CANC_ACCT_TELR_NO) END AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_CHNL IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_CHNL, BF.CANC_ACCT_CHNL) END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WX_BIND_FLAG IS NULL THEN NULL ELSE COALESCE(TM.WX_BIND_FLAG, BF.WX_BIND_FLAG) END AS WX_BIND_FLAG -- 微信绑定标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_INTERCONT_OPEN_FLAG IS NULL THEN NULL ELSE COALESCE(TM.RECV_INTERCONT_OPEN_FLAG, BF.RECV_INTERCONT_OPEN_FLAG) END AS RECV_INTERCONT_OPEN_FLAG -- 丰收互联开通标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STATUS_VERI_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.STATUS_VERI_STATUS_CD, BF.STATUS_VERI_STATUS_CD) END AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STAT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.STAT_ORG_NO, BF.STAT_ORG_NO) END AS STAT_ORG_NO -- 统计机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.B_SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.B_SRC_SYS_CD, BF.B_SRC_SYS_CD) END AS B_SRC_SYS_CD -- 业务来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_DT IS NULL THEN NULL ELSE COALESCE(TM.SETUP_DT, BF.SETUP_DT) END AS SETUP_DT -- 建立日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TM_STAMP, BF.SETUP_TM_STAMP) END AS SETUP_TM_STAMP -- 建立时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TELR_NO, BF.SETUP_TELR_NO) END AS SETUP_TELR_NO -- 建立柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_TXN_DT, BF.FINAL_TXN_DT) END AS FINAL_TXN_DT -- 最后交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_FINAL_TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.CUST_FINAL_TXN_DT, BF.CUST_FINAL_TXN_DT) END AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REC_STATUS_CD, BF.REC_STATUS_CD) END AS REC_STATUS_CD -- 记录状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.INDV_CORP_IDNT_CD,'') = COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.MAIN_DOCTYP_CD,'') = COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段相等
         AND COALESCE(TM.MAIN_DOC_NO,'') = COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') = COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') = COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.MRGACCT_FLAG,'') = COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段相等
         AND COALESCE(TM.MRG_BIZ_CATE,'') = COALESCE(BF.MRG_BIZ_CATE,'') -- 保证金业务种类 非主键字段相等
         AND COALESCE(TM.MED_TYPE_CD,'') = COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段相等
         AND COALESCE(TM.HANG_CARD_FLAG,'') = COALESCE(BF.HANG_CARD_FLAG,'') -- 挂卡标志 非主键字段相等
         AND COALESCE(TM.MASTER_CARD_NO,'') = COALESCE(BF.MASTER_CARD_NO,'') -- 主卡卡号 非主键字段相等
         AND COALESCE(TM.DPSTRCP_CONVT_NO,'') = COALESCE(BF.DPSTRCP_CONVT_NO,'') -- 存单折号码 非主键字段相等
         AND COALESCE(TM.ACCT_TYPE_CD,'') = COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段相等
         AND COALESCE(TM.ACCT_STATUS_CD,'') = COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段相等
         AND COALESCE(TM.EACCT_NO,'') = COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段相等
         AND COALESCE(TM.EACCT_STATUS_CD,'') = COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') = COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_CLS_CD,'') = COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') = COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段相等
         AND COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') = COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_CD,'') = COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_NAME,'') = COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_CD,'') = COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_NAME,'') = COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段相等
         AND COALESCE(TM.STOP_PAY_STATUS_CD,'') = COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段相等
         AND COALESCE(TM.REPLOS_STATUS_CD,'') = COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段相等
         AND COALESCE(TM.FRZ_STATUS_CD,'') = COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段相等
         AND COALESCE(TM.ALLOW_WITHDR_CASH_FLAG,'') = COALESCE(BF.ALLOW_WITHDR_CASH_FLAG,'') -- 允许提现标志 非主键字段相等
         AND COALESCE(TM.ALLOW_DRAW_FLAG,'') = COALESCE(BF.ALLOW_DRAW_FLAG,'') -- 允许支取标志 非主键字段相等
         AND COALESCE(TM.ALLOW_DPSIT_IN_FLAG,'') = COALESCE(BF.ALLOW_DPSIT_IN_FLAG,'') -- 允许存入标志 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.TXN_PWD_ENABLED_FLAG,'') = COALESCE(BF.TXN_PWD_ENABLED_FLAG,'') -- 交易密码启用标志 非主键字段相等
         AND COALESCE(TM.PWD_ENCRYPT_MODE_CD,'') = COALESCE(BF.PWD_ENCRYPT_MODE_CD,'') -- 密码加密方式代码 非主键字段相等
         AND COALESCE(TM.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') = COALESCE(BF.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') -- 电话银行密码加密方式代码 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段相等
         AND COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段相等
         AND COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段相等
         AND COALESCE(TM.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 授权金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.CHARGE_MODE_CD,'') = COALESCE(BF.CHARGE_MODE_CD,'') -- 收费方式代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段相等
         AND COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') = COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') = COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段相等
         AND COALESCE(TM.INTACR_MODE_CD,'') = COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段相等
         AND COALESCE(TM.SETMENT_FREQ,'') = COALESCE(BF.SETMENT_FREQ,'') -- 结息频率 非主键字段相等
         AND COALESCE(TM.VAL_DT,'') = COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段相等
         AND COALESCE(TM.DRAW_INT_ACCT_NO,'') = COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段相等
         AND COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM,'') = COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') = COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOC_NO,'') = COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TELR,'') = COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_CHNL_CD,'') = COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段相等
         AND COALESCE(TM.AGENT_NAME,'') = COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段相等
         AND COALESCE(TM.AGENT_DOCTYP_CD,'') = COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.AGENT_DOC_NO,'') = COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段相等
         AND COALESCE(TM.AGENT_CONT_MODE,'') = COALESCE(BF.AGENT_CONT_MODE,'') -- 代理人联系方式 非主键字段相等
         AND COALESCE(TM.DRAW_DOCTYP_CD,'') = COALESCE(BF.DRAW_DOCTYP_CD,'') -- 支取证件类型代码 非主键字段相等
         AND COALESCE(TM.DRAW_DOC_NO,'') = COALESCE(BF.DRAW_DOC_NO,'') -- 支取证件号码 非主键字段相等
         AND COALESCE(TM.PAYOFF_DT,'') = COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_ORG_NO,'') = COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TELR_NO,'') = COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_CHNL,'') = COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段相等
         AND COALESCE(TM.WX_BIND_FLAG,'') = COALESCE(BF.WX_BIND_FLAG,'') -- 微信绑定标志 非主键字段相等
         AND COALESCE(TM.RECV_INTERCONT_OPEN_FLAG,'') = COALESCE(BF.RECV_INTERCONT_OPEN_FLAG,'') -- 丰收互联开通标志 非主键字段相等
         AND COALESCE(TM.STATUS_VERI_STATUS_CD,'') = COALESCE(BF.STATUS_VERI_STATUS_CD,'') -- 身份核查状态代码 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_TXN_DT,'') = COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段相等
         AND COALESCE(TM.CUST_FINAL_TXN_DT,'') = COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.INDV_CORP_IDNT_CD,'') <> COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.MAIN_DOCTYP_CD,'') <> COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段不相等
         OR COALESCE(TM.MAIN_DOC_NO,'') <> COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.MRGACCT_FLAG,'') <> COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段不相等
         OR COALESCE(TM.MRG_BIZ_CATE,'') <> COALESCE(BF.MRG_BIZ_CATE,'') -- 保证金业务种类 非主键字段不相等
         OR COALESCE(TM.MED_TYPE_CD,'') <> COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段不相等
         OR COALESCE(TM.HANG_CARD_FLAG,'') <> COALESCE(BF.HANG_CARD_FLAG,'') -- 挂卡标志 非主键字段不相等
         OR COALESCE(TM.MASTER_CARD_NO,'') <> COALESCE(BF.MASTER_CARD_NO,'') -- 主卡卡号 非主键字段不相等
         OR COALESCE(TM.DPSTRCP_CONVT_NO,'') <> COALESCE(BF.DPSTRCP_CONVT_NO,'') -- 存单折号码 非主键字段不相等
         OR COALESCE(TM.ACCT_TYPE_CD,'') <> COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段不相等
         OR COALESCE(TM.ACCT_STATUS_CD,'') <> COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段不相等
         OR COALESCE(TM.EACCT_NO,'') <> COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段不相等
         OR COALESCE(TM.EACCT_STATUS_CD,'') <> COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') <> COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_CLS_CD,'') <> COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') <> COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') <> COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_CD,'') <> COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_NAME,'') <> COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_CD,'') <> COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_NAME,'') <> COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_STATUS_CD,'') <> COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段不相等
         OR COALESCE(TM.REPLOS_STATUS_CD,'') <> COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段不相等
         OR COALESCE(TM.FRZ_STATUS_CD,'') <> COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段不相等
         OR COALESCE(TM.ALLOW_WITHDR_CASH_FLAG,'') <> COALESCE(BF.ALLOW_WITHDR_CASH_FLAG,'') -- 允许提现标志 非主键字段不相等
         OR COALESCE(TM.ALLOW_DRAW_FLAG,'') <> COALESCE(BF.ALLOW_DRAW_FLAG,'') -- 允许支取标志 非主键字段不相等
         OR COALESCE(TM.ALLOW_DPSIT_IN_FLAG,'') <> COALESCE(BF.ALLOW_DPSIT_IN_FLAG,'') -- 允许存入标志 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.TXN_PWD_ENABLED_FLAG,'') <> COALESCE(BF.TXN_PWD_ENABLED_FLAG,'') -- 交易密码启用标志 非主键字段不相等
         OR COALESCE(TM.PWD_ENCRYPT_MODE_CD,'') <> COALESCE(BF.PWD_ENCRYPT_MODE_CD,'') -- 密码加密方式代码 非主键字段不相等
         OR COALESCE(TM.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') <> COALESCE(BF.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') -- 电话银行密码加密方式代码 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段不相等
         OR COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段不相等
         OR COALESCE(TM.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 授权金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.CHARGE_MODE_CD,'') <> COALESCE(BF.CHARGE_MODE_CD,'') -- 收费方式代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段不相等
         OR COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') <> COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') <> COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段不相等
         OR COALESCE(TM.INTACR_MODE_CD,'') <> COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段不相等
         OR COALESCE(TM.SETMENT_FREQ,'') <> COALESCE(BF.SETMENT_FREQ,'') -- 结息频率 非主键字段不相等
         OR COALESCE(TM.VAL_DT,'') <> COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段不相等
         OR COALESCE(TM.DRAW_INT_ACCT_NO,'') <> COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段不相等
         OR COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM,'') <> COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') <> COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOC_NO,'') <> COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TELR,'') <> COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_CHNL_CD,'') <> COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段不相等
         OR COALESCE(TM.AGENT_NAME,'') <> COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段不相等
         OR COALESCE(TM.AGENT_DOCTYP_CD,'') <> COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.AGENT_DOC_NO,'') <> COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段不相等
         OR COALESCE(TM.AGENT_CONT_MODE,'') <> COALESCE(BF.AGENT_CONT_MODE,'') -- 代理人联系方式 非主键字段不相等
         OR COALESCE(TM.DRAW_DOCTYP_CD,'') <> COALESCE(BF.DRAW_DOCTYP_CD,'') -- 支取证件类型代码 非主键字段不相等
         OR COALESCE(TM.DRAW_DOC_NO,'') <> COALESCE(BF.DRAW_DOC_NO,'') -- 支取证件号码 非主键字段不相等
         OR COALESCE(TM.PAYOFF_DT,'') <> COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_ORG_NO,'') <> COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TELR_NO,'') <> COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_CHNL,'') <> COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段不相等
         OR COALESCE(TM.WX_BIND_FLAG,'') <> COALESCE(BF.WX_BIND_FLAG,'') -- 微信绑定标志 非主键字段不相等
         OR COALESCE(TM.RECV_INTERCONT_OPEN_FLAG,'') <> COALESCE(BF.RECV_INTERCONT_OPEN_FLAG,'') -- 丰收互联开通标志 非主键字段不相等
         OR COALESCE(TM.STATUS_VERI_STATUS_CD,'') <> COALESCE(BF.STATUS_VERI_STATUS_CD,'') -- 身份核查状态代码 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_TXN_DT,'') <> COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段不相等
         OR COALESCE(TM.CUST_FINAL_TXN_DT,'') <> COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.INDV_CORP_IDNT_CD,'') = COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.MAIN_DOCTYP_CD,'') = COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段相等
         AND COALESCE(TM.MAIN_DOC_NO,'') = COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') = COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') = COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.MRGACCT_FLAG,'') = COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段相等
         AND COALESCE(TM.MRG_BIZ_CATE,'') = COALESCE(BF.MRG_BIZ_CATE,'') -- 保证金业务种类 非主键字段相等
         AND COALESCE(TM.MED_TYPE_CD,'') = COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段相等
         AND COALESCE(TM.HANG_CARD_FLAG,'') = COALESCE(BF.HANG_CARD_FLAG,'') -- 挂卡标志 非主键字段相等
         AND COALESCE(TM.MASTER_CARD_NO,'') = COALESCE(BF.MASTER_CARD_NO,'') -- 主卡卡号 非主键字段相等
         AND COALESCE(TM.DPSTRCP_CONVT_NO,'') = COALESCE(BF.DPSTRCP_CONVT_NO,'') -- 存单折号码 非主键字段相等
         AND COALESCE(TM.ACCT_TYPE_CD,'') = COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段相等
         AND COALESCE(TM.ACCT_STATUS_CD,'') = COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段相等
         AND COALESCE(TM.EACCT_NO,'') = COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段相等
         AND COALESCE(TM.EACCT_STATUS_CD,'') = COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') = COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_CLS_CD,'') = COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') = COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段相等
         AND COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') = COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_CD,'') = COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_NAME,'') = COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_CD,'') = COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_NAME,'') = COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段相等
         AND COALESCE(TM.STOP_PAY_STATUS_CD,'') = COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段相等
         AND COALESCE(TM.REPLOS_STATUS_CD,'') = COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段相等
         AND COALESCE(TM.FRZ_STATUS_CD,'') = COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段相等
         AND COALESCE(TM.ALLOW_WITHDR_CASH_FLAG,'') = COALESCE(BF.ALLOW_WITHDR_CASH_FLAG,'') -- 允许提现标志 非主键字段相等
         AND COALESCE(TM.ALLOW_DRAW_FLAG,'') = COALESCE(BF.ALLOW_DRAW_FLAG,'') -- 允许支取标志 非主键字段相等
         AND COALESCE(TM.ALLOW_DPSIT_IN_FLAG,'') = COALESCE(BF.ALLOW_DPSIT_IN_FLAG,'') -- 允许存入标志 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.TXN_PWD_ENABLED_FLAG,'') = COALESCE(BF.TXN_PWD_ENABLED_FLAG,'') -- 交易密码启用标志 非主键字段相等
         AND COALESCE(TM.PWD_ENCRYPT_MODE_CD,'') = COALESCE(BF.PWD_ENCRYPT_MODE_CD,'') -- 密码加密方式代码 非主键字段相等
         AND COALESCE(TM.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') = COALESCE(BF.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') -- 电话银行密码加密方式代码 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段相等
         AND COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段相等
         AND COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段相等
         AND COALESCE(TM.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 授权金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.CHARGE_MODE_CD,'') = COALESCE(BF.CHARGE_MODE_CD,'') -- 收费方式代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段相等
         AND COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') = COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') = COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段相等
         AND COALESCE(TM.INTACR_MODE_CD,'') = COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段相等
         AND COALESCE(TM.SETMENT_FREQ,'') = COALESCE(BF.SETMENT_FREQ,'') -- 结息频率 非主键字段相等
         AND COALESCE(TM.VAL_DT,'') = COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段相等
         AND COALESCE(TM.DRAW_INT_ACCT_NO,'') = COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段相等
         AND COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM,'') = COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') = COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOC_NO,'') = COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TELR,'') = COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_CHNL_CD,'') = COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段相等
         AND COALESCE(TM.AGENT_NAME,'') = COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段相等
         AND COALESCE(TM.AGENT_DOCTYP_CD,'') = COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.AGENT_DOC_NO,'') = COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段相等
         AND COALESCE(TM.AGENT_CONT_MODE,'') = COALESCE(BF.AGENT_CONT_MODE,'') -- 代理人联系方式 非主键字段相等
         AND COALESCE(TM.DRAW_DOCTYP_CD,'') = COALESCE(BF.DRAW_DOCTYP_CD,'') -- 支取证件类型代码 非主键字段相等
         AND COALESCE(TM.DRAW_DOC_NO,'') = COALESCE(BF.DRAW_DOC_NO,'') -- 支取证件号码 非主键字段相等
         AND COALESCE(TM.PAYOFF_DT,'') = COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_ORG_NO,'') = COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TELR_NO,'') = COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_CHNL,'') = COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段相等
         AND COALESCE(TM.WX_BIND_FLAG,'') = COALESCE(BF.WX_BIND_FLAG,'') -- 微信绑定标志 非主键字段相等
         AND COALESCE(TM.RECV_INTERCONT_OPEN_FLAG,'') = COALESCE(BF.RECV_INTERCONT_OPEN_FLAG,'') -- 丰收互联开通标志 非主键字段相等
         AND COALESCE(TM.STATUS_VERI_STATUS_CD,'') = COALESCE(BF.STATUS_VERI_STATUS_CD,'') -- 身份核查状态代码 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_TXN_DT,'') = COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段相等
         AND COALESCE(TM.CUST_FINAL_TXN_DT,'') = COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.INDV_CORP_IDNT_CD,'') <> COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.MAIN_DOCTYP_CD,'') <> COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段不相等
         OR COALESCE(TM.MAIN_DOC_NO,'') <> COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.MRGACCT_FLAG,'') <> COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段不相等
         OR COALESCE(TM.MRG_BIZ_CATE,'') <> COALESCE(BF.MRG_BIZ_CATE,'') -- 保证金业务种类 非主键字段不相等
         OR COALESCE(TM.MED_TYPE_CD,'') <> COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段不相等
         OR COALESCE(TM.HANG_CARD_FLAG,'') <> COALESCE(BF.HANG_CARD_FLAG,'') -- 挂卡标志 非主键字段不相等
         OR COALESCE(TM.MASTER_CARD_NO,'') <> COALESCE(BF.MASTER_CARD_NO,'') -- 主卡卡号 非主键字段不相等
         OR COALESCE(TM.DPSTRCP_CONVT_NO,'') <> COALESCE(BF.DPSTRCP_CONVT_NO,'') -- 存单折号码 非主键字段不相等
         OR COALESCE(TM.ACCT_TYPE_CD,'') <> COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段不相等
         OR COALESCE(TM.ACCT_STATUS_CD,'') <> COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段不相等
         OR COALESCE(TM.EACCT_NO,'') <> COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段不相等
         OR COALESCE(TM.EACCT_STATUS_CD,'') <> COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') <> COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_CLS_CD,'') <> COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') <> COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') <> COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_CD,'') <> COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_NAME,'') <> COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_CD,'') <> COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_NAME,'') <> COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_STATUS_CD,'') <> COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段不相等
         OR COALESCE(TM.REPLOS_STATUS_CD,'') <> COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段不相等
         OR COALESCE(TM.FRZ_STATUS_CD,'') <> COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段不相等
         OR COALESCE(TM.ALLOW_WITHDR_CASH_FLAG,'') <> COALESCE(BF.ALLOW_WITHDR_CASH_FLAG,'') -- 允许提现标志 非主键字段不相等
         OR COALESCE(TM.ALLOW_DRAW_FLAG,'') <> COALESCE(BF.ALLOW_DRAW_FLAG,'') -- 允许支取标志 非主键字段不相等
         OR COALESCE(TM.ALLOW_DPSIT_IN_FLAG,'') <> COALESCE(BF.ALLOW_DPSIT_IN_FLAG,'') -- 允许存入标志 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.TXN_PWD_ENABLED_FLAG,'') <> COALESCE(BF.TXN_PWD_ENABLED_FLAG,'') -- 交易密码启用标志 非主键字段不相等
         OR COALESCE(TM.PWD_ENCRYPT_MODE_CD,'') <> COALESCE(BF.PWD_ENCRYPT_MODE_CD,'') -- 密码加密方式代码 非主键字段不相等
         OR COALESCE(TM.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') <> COALESCE(BF.TEL_BANK_PWD_ENCRYPT_MODE_CD,'') -- 电话银行密码加密方式代码 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段不相等
         OR COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段不相等
         OR COALESCE(TM.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 授权金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.CHARGE_MODE_CD,'') <> COALESCE(BF.CHARGE_MODE_CD,'') -- 收费方式代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段不相等
         OR COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') <> COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') <> COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段不相等
         OR COALESCE(TM.INTACR_MODE_CD,'') <> COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段不相等
         OR COALESCE(TM.SETMENT_FREQ,'') <> COALESCE(BF.SETMENT_FREQ,'') -- 结息频率 非主键字段不相等
         OR COALESCE(TM.VAL_DT,'') <> COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段不相等
         OR COALESCE(TM.DRAW_INT_ACCT_NO,'') <> COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段不相等
         OR COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM,'') <> COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') <> COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOC_NO,'') <> COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TELR,'') <> COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_CHNL_CD,'') <> COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段不相等
         OR COALESCE(TM.AGENT_NAME,'') <> COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段不相等
         OR COALESCE(TM.AGENT_DOCTYP_CD,'') <> COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.AGENT_DOC_NO,'') <> COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段不相等
         OR COALESCE(TM.AGENT_CONT_MODE,'') <> COALESCE(BF.AGENT_CONT_MODE,'') -- 代理人联系方式 非主键字段不相等
         OR COALESCE(TM.DRAW_DOCTYP_CD,'') <> COALESCE(BF.DRAW_DOCTYP_CD,'') -- 支取证件类型代码 非主键字段不相等
         OR COALESCE(TM.DRAW_DOC_NO,'') <> COALESCE(BF.DRAW_DOC_NO,'') -- 支取证件号码 非主键字段不相等
         OR COALESCE(TM.PAYOFF_DT,'') <> COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_ORG_NO,'') <> COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TELR_NO,'') <> COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_CHNL,'') <> COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段不相等
         OR COALESCE(TM.WX_BIND_FLAG,'') <> COALESCE(BF.WX_BIND_FLAG,'') -- 微信绑定标志 非主键字段不相等
         OR COALESCE(TM.RECV_INTERCONT_OPEN_FLAG,'') <> COALESCE(BF.RECV_INTERCONT_OPEN_FLAG,'') -- 丰收互联开通标志 非主键字段不相等
         OR COALESCE(TM.STATUS_VERI_STATUS_CD,'') <> COALESCE(BF.STATUS_VERI_STATUS_CD,'') -- 身份核查状态代码 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_TXN_DT,'') <> COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段不相等
         OR COALESCE(TM.CUST_FINAL_TXN_DT,'') <> COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 主键字段关联
    AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 主键字段关联
    AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_011;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_012;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_01;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_02;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_03;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_04;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_05;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_06;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_CURR_DPSIT_ACCT_INFO_TF_TM_07;
