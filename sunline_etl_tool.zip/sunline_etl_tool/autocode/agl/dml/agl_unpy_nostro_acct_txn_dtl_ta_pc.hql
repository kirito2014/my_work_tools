-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-银联往账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA
--     表中文名：银联往账交易明细聚合
--     创建日期：2024-06-14 00:00:00
--     主键字段：TOTAL_TXN_SER_NO, SUB_TXN_SER_NO, TXN_TYPE_CD, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：None
--     保留周期：None
--     描述信息：行内对接银联系统的往账交易明细
--     更新记录：
--         2024-06-14 00:00:00 wangmujun new
--         2024-09-05 00:00:00 王穆军 新增字段，同步设计20240902
--         2024-09-13 00:00:00 王穆军  修改主键重复去重
--         2024-09-18 00:00:00 王穆军 修改子查询，新建临时表



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '银联往账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TOTAL_TXN_SER_NO -- 总交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,SUB_TXN_AMT -- 子交易金额
    ,SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,REFUND_AMT -- 退款金额
    ,TXN_REM -- 交易备注
    ,UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,CORE_SER_NO -- 核心流水号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,PAYEE_ACCT_NO  -- 收款方账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,MERCHT_NO -- 商户编号
    ,MERCHT_OPEN_DT -- 商户开通日期
    ,MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_ABB -- 商户简称
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,RETURN_INFO_DESC -- 返回信息描述
    ,EQUIP_NO -- 设备编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None
DROP TABLE IF EXISTS AGL.TMP_AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_01;

CREATE TABLE AGL.TMP_AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_01 (
     ACCT_NO STRING COMMENT '交易账号'
)
USING ORC
COMMENT 'None'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_01(
     ACCT_NO -- 交易账号
)
SELECT
     DFANAC19 AS ACCT_NO -- 交易账号
FROM
( 
SELECT DISTINCT DFANAC19 FROM ODS_CORE.ODS_CORE_BWFMDCIM_TF WHERE PT_DT = '${process_date}' AND DEL_F = '0'
UNION 
SELECT DISTINCT CARD_NBR FROM ODS_CCRD.ODS_CCRD_CARD_TF WHERE PT_DT = '${process_date}' AND DEL_F = '0'
UNION
SELECT DISTINCT CARDNO FROM ODS_NAS.ODS_NAS_KNA_ACDC_TF WHERE PT_DT = '${process_date}' AND DEL_F = '0' 
) AS T1 -- 账号合集

;
-- ==============聚合层字段映射（第2组）==============
-- None

INSERT INTO TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM(
     TOTAL_TXN_SER_NO -- 总交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,SUB_TXN_AMT -- 子交易金额
    ,SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,REFUND_AMT -- 退款金额
    ,TXN_REM -- 交易备注
    ,UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,CORE_SER_NO -- 核心流水号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,PAYEE_ACCT_NO  -- 收款方账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,MERCHT_NO -- 商户编号
    ,MERCHT_OPEN_DT -- 商户开通日期
    ,MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_ABB -- 商户简称
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,RETURN_INFO_DESC -- 返回信息描述
    ,EQUIP_NO -- 设备编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     concat(t1.qzjyrq,t1.ylf_7,t1.ylf_11) AS TOTAL_TXN_SER_NO -- 总交易流水号
    ,concat(t1.qzjyrq,t1.ylf_7,t1.ylf_11) AS SUB_TXN_SER_NO -- 子交易流水号
    ,substr(t1.type,1,6) AS TXN_TYPE_CD -- 交易类型代码
    ,unifiedTime(t1.QZJYRQ) AS TXN_DT -- 交易日期
    ,unifiedTime(t1.YLF_7) AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,t1.F_4/100 AS TXN_AMT -- 交易金额
    ,CASE
         WHEN T1.F_49 IS NULL OR  TRIM(T1.F_49) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.F_49),
                   '')
       END AS TXN_CURR_CD -- 交易币种代码
    ,F_4/100 AS SUB_TXN_AMT -- 子交易金额
    ,null AS SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,null AS REFUND_AMT -- 退款金额
    ,'' AS TXN_REM -- 交易备注
    ,'' AS UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,'' AS UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,t1.QDLSH_62 AS CORE_SER_NO -- 核心流水号
    ,t1.F_2 AS PAYER_ACCT_NO -- 付款方账户编号
    ,case when substr(T1.f_2,1,6) <> '623540' then t3.chnmnm40
  when  substr(T1.f_2,1,6) = '623540' then t5.custna end  AS PAYER_ACCT_NAME -- 付款方账户名称
    ,'' AS PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,'' AS BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,'' AS BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,'' AS INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,t1.F_103 AS PAYEE_ACCT_NO  -- 收款方账户编号
    ,case when substr(T1.f_103,1,6) <> '623540' then t3.chnmnm40
  when substr(T1.f_103,1,6)  = '623540' then t5.custna end  AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,'' AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,t1.f_42 AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T2.TRANS_ORG_NAME AS START_BANK_NAME -- 发起行名称
    ,'' AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,'' AS RECV_BANK_NAME -- 接收行名称
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_OPEN_DT -- 商户开通日期
    ,'' AS MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'' AS MERCHT_ABB -- 商户简称
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,t1.f_18 AS MERCHT_MCC_CD -- 商户MCC代码
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,t1.ERRMSG AS RETURN_INFO_DESC -- 返回信息描述
    ,t1.F_41 AS EQUIP_NO -- 设备编号
    ,concat(SUBSTR(t1.JGM,3,3),'000') AS EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,unifiedTime(T1.F_7) AS EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,T1.last_etl_acg_dt||' 00:00:00.00000' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'CARD' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CARD_ATMJYLS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ods_card.ODS_CARD_ATMJYLS_TA AS T1 -- ATM交易流水

LEFT JOIN ODS_CCPT.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T2 -- 银联交易机构代码表
       ON T1.f_42 =T2. TRANS_ORG_NO  
AND T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS T3 -- 借记卡信息主档
       ON t1.f_2 = t3.CDNOAC19
AND T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_ACDC_TF AS T4 -- 卡账户表
       ON t1.f_2 = t4.cardno 
AND T4.PT_DT = '${process_date}' AND T4.DEL_F = '0' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_CUST_TF AS T5 -- 电子账户表
       ON t5.custac = t4.custac
AND T5.PT_DT = '${process_date}' AND T5.DEL_F = '0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON T1.F_49 = S1.SRC_CD_VAL
AND S1.SRC_TAB_LIB_NAME = 'CARD'
AND S1.SRC_FIELD_EN_NAME ='F_49'
AND S1.SRC_TAB_EN_NAME = 'ATMJYLS'
AND S1.TARGET_TAB_EN_NAME='AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'TXN_CURR_CD' 
WHERE T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
and (T1.f2_bintype = '3' or (T1.f2_bintype <> '3' and  case when trim(T1.f_103) <> '' then  not exists (
SELECT 1 FROM AGL.TMP_AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_01 T WHERE T.ACCT_NO = T1.f_103
) end ))
;
-- ==============聚合层字段映射（第3组）==============
-- None

INSERT INTO TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM(
     TOTAL_TXN_SER_NO -- 总交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,SUB_TXN_AMT -- 子交易金额
    ,SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,REFUND_AMT -- 退款金额
    ,TXN_REM -- 交易备注
    ,UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,CORE_SER_NO -- 核心流水号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,PAYEE_ACCT_NO  -- 收款方账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,MERCHT_NO -- 商户编号
    ,MERCHT_OPEN_DT -- 商户开通日期
    ,MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_ABB -- 商户简称
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,RETURN_INFO_DESC -- 返回信息描述
    ,EQUIP_NO -- 设备编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.OVERALLTRANSNBR AS TOTAL_TXN_SER_NO -- 总交易流水号
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T2.SUBTRANSSEQNBR
when T1.OVERALLTRANSTYPCD ='OTEC' then  T2.OVERALLTRANSNBR end AS SUB_TXN_SER_NO -- 子交易流水号
    ,T1.OVERALLTRANSTYPCD AS TXN_TYPE_CD -- 交易类型代码
    ,unifiedTime(T1.TRANSDATE) AS TXN_DT -- 交易日期
    ,unifiedTime(concat(substr(T1.TRANSTIME,1,4),substr(T1.TRANSTIME,6,2),substr(T1.TRANSTIME,9,2),substr(T1.TRANSTIME,12,2),substr(T1.TRANSTIME,15,2),substr(T1.TRANSTIME,18,2))) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.OVERALLTRANSSTATUS AS TXN_STATUS_CD -- 交易状态代码
    ,T1.TRANSAMT AS TXN_AMT -- 交易金额
    ,CASE
         WHEN T1.CURRENCYCD IS NULL  OR TRIM(T1.CURRENCYCD) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.CURRENCYCD),
                   '')
       END AS TXN_CURR_CD -- 交易币种代码
    ,T2.TRANSAMT AS SUB_TXN_AMT -- 子交易金额
    ,T2.FEEAMT AS SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T2.REFUNDEDAMT
 when T1.OVERALLTRANSTYPCD ='OTEC' then T1.REFUNDEDAMT + T1.REFUNDINGAMT end  AS REFUND_AMT -- 退款金额
    ,T1.MEMO AS TXN_REM -- 交易备注
    ,'' AS UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,'' AS UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,T1.UPPERTRANSNBR AS CORE_SER_NO -- 核心流水号
    ,T1.PAYERACCTNBR AS PAYER_ACCT_NO -- 付款方账户编号
    ,T1.PAYERACCTNAME AS PAYER_ACCT_NAME -- 付款方账户名称
    ,T1.PAYERACCTDEPTNBR AS PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T1.PAYEEACCTNBR
 when T1.OVERALLTRANSTYPCD ='OTEC' then null end AS BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T1.PAYEEACCTNAME
when T1.OVERALLTRANSTYPCD ='OTEC' then null end AS BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T1.PAYEEACCTDEPTNBR
when T1.OVERALLTRANSTYPCD ='OTEC' then null end  AS INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T3.SETTLEACCTNBR
 when T1.OVERALLTRANSTYPCD ='OTEC' then T1.PAYEEACCTNBR end AS PAYEE_ACCT_NO  -- 收款方账户编号
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T3.SETTLEACCTNAME
when T1.OVERALLTRANSTYPCD ='OTEC' then T1.PAYEEACCTNAME end AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,case when T1.OVERALLTRANSTYPCD ='UPAY' then T4.OWONBRNO
 when T1.OVERALLTRANSTYPCD ='OTEC' then T1.PAYEEACCTDEPTNBR end AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,T1.PAYERBANKNBR AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T1.PAYERBANKNAME AS START_BANK_NAME -- 发起行名称
    ,T1.PAYEEBANKNBR AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T1.PAYEEBANKNAME AS RECV_BANK_NAME -- 接收行名称
    ,T2.MERNBR AS MERCHT_NO -- 商户编号
    ,unifiedTime(T3.MEROPENDATE) AS MERCHT_OPEN_DT -- 商户开通日期
    ,T2.MEROPENDEPTNBR AS MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,T3.MERNAME AS MERCHT_NAME -- 商户名称
    ,'' AS MERCHT_ABB -- 商户简称
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,T3.MERCATCODE AS MERCHT_MCC_CD -- 商户MCC代码
    ,T3.SUPERMERNBR AS SUPER_MERCHT_NO -- 上级商户编号
    ,T1.RETURNMSG AS RETURN_INFO_DESC -- 返回信息描述
    ,'' AS EQUIP_NO -- 设备编号
    ,'' AS EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,'' AS EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,unifiedTime(concat(substr(T1.DATELASTMAINT,1,4),substr(T1.DATELASTMAINT,6,2),substr(T1.DATELASTMAINT,9,2),substr(T1.DATELASTMAINT,12,2),substr(T1.DATELASTMAINT,15,2),substr(T1.DATELASTMAINT,18,2))) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'EPAY' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_EPAY_OVERALLTRANSHIST_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_EPAY.ODS_EPAY_OVERALLTRANSHIST_TA AS T1 -- 总交易流水表

INNER JOIN  ODS_EPAY.ODS_EPAY_ONLINESUBTRANSHIST_TA AS T2 -- 子交易明细表
       ON T1.UPPERTRANSNBR = T2.transseqnbr
AND T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN ODS_EPAY.ODS_EPAY_MERACCTINFO_TF AS T3 -- 商户账务信息
       ON t2.MERNBR=t3.MERNBR
AND T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN (
select 
CDNOAC19 
,OWONBRNO
from ODS_CORE.ODS_CORE_BWFMDCIM_TF p1 
where p1.PT_DT = '2023-12-26' AND p1.DEL_F = '0'
union 
(
select 
 DFANAC19
 ,OWONBRNO 
from 
(
select
 DFANAC19,
 OWONBRNO,
 row_number()over(partition by DFANAC19 order by updtdate desc ) rn 

from
 ODS_CORE.ODS_CORE_BWFMDCIM_TF
where
 DEL_F = '0'
 and PT_DT = '2023-12-26'
 --and CRDSCRDS <> '5'
 )t 
 where t.rn = 1
)) AS T4 -- 借记卡信息主档
       ON T3.SETTLEACCTNBR = T4.CDNOAC19 
AND T4.PT_DT = '${process_date}' AND T4.DEL_F = '0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON T1.CURRENCYCD = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'EPAY'
AND S1.SRC_FIELD_EN_NAME ='CURRENCYCD'
AND S1.SRC_TAB_EN_NAME = 'OVERALLTRANSHIST'
AND S1.TARGET_TAB_EN_NAME='AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'TXN_CURR_CD' 
WHERE T1.OVERALLTRANSTYPCD = 'OOTEC' 
OR (T1.OVERALLTRANSTYPCD = 'UPAY' 
       and T1.checkdataflag = 'UNIONPAY')
AND T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- None

INSERT INTO TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM(
     TOTAL_TXN_SER_NO -- 总交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,SUB_TXN_AMT -- 子交易金额
    ,SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,REFUND_AMT -- 退款金额
    ,TXN_REM -- 交易备注
    ,UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,CORE_SER_NO -- 核心流水号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,PAYEE_ACCT_NO  -- 收款方账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,MERCHT_NO -- 商户编号
    ,MERCHT_OPEN_DT -- 商户开通日期
    ,MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_ABB -- 商户简称
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,RETURN_INFO_DESC -- 返回信息描述
    ,EQUIP_NO -- 设备编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.parent_msg_id AS TOTAL_TXN_SER_NO -- 总交易流水号
    ,T1.msg_id AS SUB_TXN_SER_NO -- 子交易流水号
    ,T1.txn_type AS TXN_TYPE_CD -- 交易类型代码
    ,unifiedTime(t1.gmt_create) AS TXN_DT -- 交易日期
    ,unifiedTime(t1.gmt_create) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.txn_sts AS TXN_STATUS_CD -- 交易状态代码
    ,T1.tx_amt AS TXN_AMT -- 交易金额
    ,CASE
         WHEN T1.TX_AMT_CCY IS NULL  OR TRIM(T1.TX_AMT_CCY) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.TX_AMT_CCY),
                   '')
       END AS TXN_CURR_CD -- 交易币种代码
    ,T1.tx_amt AS SUB_TXN_AMT -- 子交易金额
    ,T1.fee_amt AS SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,t2.tx_settle_amt AS REFUND_AMT -- 退款金额
    ,T1.remark AS TXN_REM -- 交易备注
    ,T1.biz_category AS UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,T1.biz_purp AS UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,T1.orgl_msgid AS CORE_SER_NO -- 核心流水号
    ,t2.tunnel_payer_id AS PAYER_ACCT_NO -- 付款方账户编号
    ,'' AS PAYER_ACCT_NAME -- 付款方账户名称
    ,'' AS PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,t3.debit_account AS BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,T3.debit_account_name AS BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,T3.debit_bankno AS INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,T3.credit_account AS PAYEE_ACCT_NO  -- 收款方账户编号
    ,T3.credit_account_name AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,T3.credit_bank_cd AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,'' AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,'' AS START_BANK_NAME -- 发起行名称
    ,T3.credit_bankno AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T4.hhmc AS RECV_BANK_NAME -- 接收行名称
    ,T1.merch_id AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_OPEN_DT -- 商户开通日期
    ,T1.merch_inst_id AS MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,T3.s_mer_nm AS MERCHT_NAME -- 商户名称
    ,T1.merch_nm AS MERCHT_ABB -- 商户简称
    ,t2.merch_typ AS MERCHT_TYPE_CD -- 商户类型代码
    ,t2.merch_categ_cd AS MERCHT_MCC_CD -- 商户MCC代码
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS RETURN_INFO_DESC -- 返回信息描述
    ,'' AS EQUIP_NO -- 设备编号
    ,'' AS EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,'' AS EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,unifiedTime(t1.gmt_create) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SPS_SPS_PAY_SIMPLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_SPS.ODS_SPS_SPS_PAY_SIMPLE_TA AS T1 -- 交易流水表

LEFT JOIN ODS_IG.ods_ig_uas_pay_simple_ta AS t2 -- 交易流水表
       ON t1.TXN_ID = t2.TX_MSG_ID
AND T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN ODS_IG.ODS_IG_SP_BATCH_SETTLE_DETAIL_TA AS T3 -- 结算明细表
       ON T1.TXN_ID = T3.MSG_ID
AND T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN ODS_UPPRUN.ODS_UPPRUN_ZPS_BANK_TF AS T4 -- 农信银支付系统号表
       ON T3.credit_bankno =T4.HH
AND T4.PT_DT = '${process_date}' AND T4.DEL_F = '0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON T1.TX_AMT_CCY = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'SPS'
AND S1.SRC_FIELD_EN_NAME ='TX_AMT_CCY'
AND S1.SRC_TAB_EN_NAME = 'SPS_PAY_SIMPLE'
AND S1.TARGET_TAB_EN_NAME='AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'TXN_CURR_CD' 
WHERE  T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第5组）==============
-- None

INSERT INTO TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM(
     TOTAL_TXN_SER_NO -- 总交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,SUB_TXN_AMT -- 子交易金额
    ,SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,REFUND_AMT -- 退款金额
    ,TXN_REM -- 交易备注
    ,UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,CORE_SER_NO -- 核心流水号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,PAYEE_ACCT_NO  -- 收款方账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,MERCHT_NO -- 商户编号
    ,MERCHT_OPEN_DT -- 商户开通日期
    ,MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_ABB -- 商户简称
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,RETURN_INFO_DESC -- 返回信息描述
    ,EQUIP_NO -- 设备编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     concat(t1.id,t1.pseq) AS TOTAL_TXN_SER_NO -- 总交易流水号
    ,concat(t1.id,t1.pseq) AS SUB_TXN_SER_NO -- 子交易流水号
    ,T1.sysprocod AS TXN_TYPE_CD -- 交易类型代码
    ,unifiedTime(T1.plat_date) AS TXN_DT -- 交易日期
    ,unifiedTime(t1.plat_date||' '||t1.stdloctime) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.trnsflag AS TXN_STATUS_CD -- 交易状态代码
    ,T1.stdtrnsamt AS TXN_AMT -- 交易金额
    ,CASE
         WHEN T1.STDTRNSCUR IS NULL  OR TRIM(T1.STDTRNSCUR) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.STDTRNSCUR),
                   '')
       END AS TXN_CURR_CD -- 交易币种代码
    ,T1.stdtrnsamt AS SUB_TXN_AMT -- 子交易金额
    ,T1.stdtrnsfee AS SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,T1.refund_amount AS REFUND_AMT -- 退款金额
    ,T1.stdrspcod AS TXN_REM -- 交易备注
    ,'' AS UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,'' AS UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,T1.hostseq AS CORE_SER_NO -- 核心流水号
    ,T1.stdpriacc AS PAYER_ACCT_NO -- 付款方账户编号
    ,'' AS PAYER_ACCT_NAME -- 付款方账户名称
    ,'' AS PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,'' AS BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,'' AS BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,'' AS INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,T1.stdacc2 AS PAYEE_ACCT_NO  -- 收款方账户编号
    ,case when substr(T1.stdacc2,1,6) <> '623540' then t3.chnmnm40
  when substr(T1.stdacc2,1,6) = '623540' then t5.custna end 
 AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,T3.OWONBRNO AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,'' AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,'' AS START_BANK_NAME -- 发起行名称
    ,T1.rec_bank_cd AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T2.TRANS_ORG_NAME AS RECV_BANK_NAME -- 接收行名称
    ,T1.stdaccid AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_OPEN_DT -- 商户开通日期
    ,T1.cup_branch_id AS MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,T1.stdaccname AS MERCHT_NAME -- 商户名称
    ,T1.stdaccname AS MERCHT_ABB -- 商户简称
    ,'' AS MERCHT_TYPE_CD -- 商户类型代码
    ,T1.stdmchtyp AS MERCHT_MCC_CD -- 商户MCC代码
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS RETURN_INFO_DESC -- 返回信息描述
    ,T1.stdtermid AS EQUIP_NO -- 设备编号
    ,'' AS EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,unifiedTime(T1.loc_trade_time) AS EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,T1.last_etl_acg_dt || ' 00:00:00.000000' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP.ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA AS T1 -- 流水历史表

LEFT JOIN ODS_CCPT.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T2 -- 银联交易机构代码表
       ON T1.rec_bank_cd =T2. TRANS_ORG_NO   
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS T3 -- 借记卡信息主档
       ON t1.stdacc2 = t3.CDNOAC19
AND T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_ACDC_TF AS T4 -- 卡账户表
       ON t1.stdacc2 = t4.cardno 
AND T4.PT_DT = '${process_date}' AND T4.DEL_F = '0' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_CUST_TF AS T5 -- 电子账户表
       ON t5.custac = t4.custac
AND T5.PT_DT = '${process_date}' AND T5.DEL_F = '0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON T1.STDTRNSCUR = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'POSP'
AND S1.SRC_FIELD_EN_NAME ='STDTRNSCUR'
AND S1.SRC_TAB_EN_NAME = 'TBL_EPS_TRNS_OLDJOUR'
AND S1.TARGET_TAB_EN_NAME='AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'TXN_CURR_CD'
 
WHERE  T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
AND T1.sysprocod in ('U00000001','U00000004','U00000006') OR (T1.SYSPROCOD IN ('T00000001','T00000002','T00000003','T00000004','T00000009','T00000011','T00000022') AND YL_FLG = '1')
AND T1.TRNSFLAG = '1'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TOTAL_TXN_SER_NO -- 总交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,SUB_TXN_AMT -- 子交易金额
    ,SUB_TXN_IN_BANK_COMM_FEE -- 子交易行内手续费
    ,REFUND_AMT -- 退款金额
    ,TXN_REM -- 交易备注
    ,UNPY_BIZ_MCLS_CD -- 银联业务大类代码              
    ,UNPY_BIZ_SCLS_CD -- 银联业务小类代码  
    ,CORE_SER_NO -- 核心流水号
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,BANK_INTER_ACCT_NO -- 银行内部账户编号
    ,BANK_INTER_ACCT_NAME -- 银行内部账户名称
    ,INTER_ACCT_BELONG_ORG_NO -- 内部账户归属机构编号
    ,PAYEE_ACCT_NO  -- 收款方账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,MERCHT_NO -- 商户编号
    ,MERCHT_OPEN_DT -- 商户开通日期
    ,MERCHT_BELONG_ORG_NO -- 商户归属机构编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_ABB -- 商户简称
    ,MERCHT_TYPE_CD -- 商户类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,RETURN_INFO_DESC -- 返回信息描述
    ,EQUIP_NO -- 设备编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_TXN_TM_STAMP -- 设备交易时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_TM;
DROP TABLE AGL.TMP_AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA_01;
