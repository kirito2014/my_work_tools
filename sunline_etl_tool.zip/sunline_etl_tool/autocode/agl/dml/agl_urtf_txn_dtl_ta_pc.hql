-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-城乡两费交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_URTF_TXN_DTL_TA
--     表中文名：城乡两费交易明细聚合
--     创建日期：2024-03-21 00:00:00
--     主键字段：TXN_DT, TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-21 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_URTF_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_URTF_TXN_DTL_TA_TM
USING ORC
COMMENT '城乡两费交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,PAY_FEE_MODE_CD -- 缴费模式代码
    ,DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_AMT -- 交易金额
    ,URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,BANK_TXN_SER_NO -- 银行交易流水号
    ,PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CUST_NAME -- 客户名称
    ,BANK_STL_ACCT_NO -- 银行结算账户编号
    ,TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,TAX_TXN_SER_NO -- 税务交易流水号
    ,DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,COMMS_DT -- 委托日期
    ,BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,SIGN_ORG_NO -- 签约机构编号
    ,URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_URTF_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_URTF_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 城乡两费交易明细聚合

INSERT INTO TABLE AGL.AGL_URTF_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,PAY_FEE_MODE_CD -- 缴费模式代码
    ,DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_AMT -- 交易金额
    ,URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,BANK_TXN_SER_NO -- 银行交易流水号
    ,PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CUST_NAME -- 客户名称
    ,BANK_STL_ACCT_NO -- 银行结算账户编号
    ,TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,TAX_TXN_SER_NO -- 税务交易流水号
    ,DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,COMMS_DT -- 委托日期
    ,BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,SIGN_ORG_NO -- 签约机构编号
    ,URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,'1' AS PAY_FEE_MODE_CD -- 缴费模式代码
    ,'1' AS DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,unifiedTime(P1.CLEAR_DATE) AS PLAT_CLEAR_DT -- 平台清算日期
    ,P1.BRCH_NO AS TXN_ORG_NO -- 交易机构编号
    ,P1.TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TRAN_AMT AS TXN_AMT -- 交易金额
    ,P1.TX_MODE AS URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,'' AS URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,P1.YHJYLSH AS BANK_TXN_SER_NO -- 银行交易流水号
    ,P1.DC_FLAG AS PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,P1.CHN_TYPE AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.ACT_NAME AS CUST_NAME -- 客户名称
    ,P1.ACT_NO AS BANK_STL_ACCT_NO -- 银行结算账户编号
    ,P1.OPEN_BRCH_NO AS TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,P1.SWJYLSH AS TAX_TXN_SER_NO -- 税务交易流水号
    ,P1.ZGSWJGDM AS DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,P1.ZGSWJGMC AS DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,P1.XNHBM AS DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,P1.RYBM AS TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,P1.XM AS TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,P1.ZJHM AS CUST_DOC_NO -- 客户证件号码
    ,P1.LXDH AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P1.JFRLX AS PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,unifiedTime(P1.WTRQ) AS COMMS_DT -- 委托日期
    ,P1.XYSH AS BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,P1.TX_FLAG AS URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,'' AS URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,P1.SET_ACCT_NO AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,CASE WHEN P1.HOST_ACC_STAT IS NULL OR TRIM(P1.HOST_ACC_STAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.HOST_ACC_STAT),'')) END AS URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,CASE WHEN P1.ENTR_ACC_STAT IS NULL OR TRIM(P1.ENTR_ACC_STAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ENTR_ACC_STAT),'')) END AS URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,'' AS SIGN_ORG_NO -- 签约机构编号
    ,'' AS URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,'' AS URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,'OZJSW' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OZJSW_T_NZJSW_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_OZJSW.ODS_OZJSW_T_NZJSW_JRNL_TA AS P1 -- 新版省税务流水表

LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'ZJSW'
        AND P1.SRC_FIELD_EN_NAME ='HOST_ACC_STAT'
        AND P1.SRC_TAB_EN_NAME = 'T_NZJSW_JRNL'
        AND P1.TARGET_TAB_EN_NAME='AGL_URTF_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'URFEE_TPTY_ACCTN_STAT_CD'
) AS S1 -- URFEE_TPTY_ACCTN_STAT_CD
       ON P1.HOST_ACC_STAT=S1.SRC_CD_VAL 
LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'ZJSW'
        AND P1.SRC_FIELD_EN_NAME ='ENTR_ACC_STAT'
        AND P1.SRC_TAB_EN_NAME = 'T_NZJSW_JRNL'
        AND P1.TARGET_TAB_EN_NAME='AGL_URTF_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'URFEE_HOST_ACCTN_STAT_CD'
) AS S2 -- URFEE_HOST_ACCTN_STAT_CD
       ON P1.ENTR_ACC_STAT=S2.SRC_CD_VAL 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 城乡两费交易明细聚合

INSERT INTO TABLE AGL.AGL_URTF_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,PAY_FEE_MODE_CD -- 缴费模式代码
    ,DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_AMT -- 交易金额
    ,URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,BANK_TXN_SER_NO -- 银行交易流水号
    ,PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CUST_NAME -- 客户名称
    ,BANK_STL_ACCT_NO -- 银行结算账户编号
    ,TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,TAX_TXN_SER_NO -- 税务交易流水号
    ,DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,COMMS_DT -- 委托日期
    ,BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,SIGN_ORG_NO -- 签约机构编号
    ,URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,cast(P1.BAT_SEQ as string)||cast(P1.SERI_NO as string)  AS TXN_SER_NO -- 交易流水号
    ,'2' AS PAY_FEE_MODE_CD -- 缴费模式代码
    ,'1' AS DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,unifiedTime(P1.CLEAR_DATE) AS PLAT_CLEAR_DT -- 平台清算日期
    ,'' AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,'' AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,'' AS BANK_TXN_SER_NO -- 银行交易流水号
    ,'' AS PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.ACCT_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_ACCT_NO AS BANK_STL_ACCT_NO -- 银行结算账户编号
    ,P1.OPEN_BRCH AS TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,P1.SWJYLSH AS TAX_TXN_SER_NO -- 税务交易流水号
    ,P1.ZSJGDM AS DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,P1.ZSJGQC AS DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,'' AS DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,'' AS TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,P1.NSRMC AS TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,P1.NSRSBH AS CUST_DOC_NO -- 客户证件号码
    ,P1.IPHONE AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P2.PEOPLE_TYPE AS PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,'' AS COMMS_DT -- 委托日期
    ,P2.CONTRACT AS BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,'' AS URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,P2.SIGN_TYPE AS URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,P1.SET_ACCT_NO AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,'' AS URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,'' AS URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,P2.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,CASE WHEN P2.STAT IS NULL OR TRIM(P2.STAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P2.STAT),'')) END AS URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,P1.DET_STAT AS URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,'OZJSW' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OZJSW_T_NZJSW_BAT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_OZJSW.ODS_OZJSW_T_NZJSW_BAT_DETAIL_TA AS P1 -- 新版省税务批量明细表

LEFT JOIN ODS_OZJSW.ODS_OZJSW_T_ZJSW_SIGN_TF AS P2 -- 省税务签约表
       ON P2.CONTRACT =P1.XYSH AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'ZJSW'
        AND P1.SRC_FIELD_EN_NAME ='STAT'
        AND P1.SRC_TAB_EN_NAME = 'T_ZJSW_SIGN'
        AND P1.TARGET_TAB_EN_NAME='AGL_URTF_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'URBA_RURAL_FEE_SIGN_STATUS_CD'
) AS S1 -- URBA_RURAL_FEE_SIGN_STATUS_CD
       ON P2.STAT=S1.SRC_CD_VAL 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 城乡两费交易明细聚合

INSERT INTO TABLE AGL.AGL_URTF_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,PAY_FEE_MODE_CD -- 缴费模式代码
    ,DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_AMT -- 交易金额
    ,URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,BANK_TXN_SER_NO -- 银行交易流水号
    ,PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CUST_NAME -- 客户名称
    ,BANK_STL_ACCT_NO -- 银行结算账户编号
    ,TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,TAX_TXN_SER_NO -- 税务交易流水号
    ,DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,COMMS_DT -- 委托日期
    ,BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,SIGN_ORG_NO -- 签约机构编号
    ,URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,'1' AS PAY_FEE_MODE_CD -- 缴费模式代码
    ,'2' AS DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,unifiedTime(P1.CLEAR_DATE) AS PLAT_CLEAR_DT -- 平台清算日期
    ,P1.BRCH_NO AS TXN_ORG_NO -- 交易机构编号
    ,P1.TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TRAN_AMT AS TXN_AMT -- 交易金额
    ,P1.TX_MODE AS URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,'' AS URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,'' AS BANK_TXN_SER_NO -- 银行交易流水号
    ,P1.DC_FLAG AS PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,P1.CHN_TYPE AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.ACT_NAME AS CUST_NAME -- 客户名称
    ,P1.ACT_NO AS BANK_STL_ACCT_NO -- 银行结算账户编号
    ,P1.OPEN_BRCH_NO AS TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,P1.SWJYLSH AS TAX_TXN_SER_NO -- 税务交易流水号
    ,P1.ZGSWJGDM AS DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,P1.ZGSWJGMC AS DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,'' AS DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,P1.RYBM AS TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,P1.XM AS TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,P1.ZJHM AS CUST_DOC_NO -- 客户证件号码
    ,'' AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P1.JFRLX AS PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,unifiedTime(P1.WTRQ) AS COMMS_DT -- 委托日期
    ,P1.XYSH AS BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,P1.TX_FLAG AS URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,'' AS URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,P1.SET_ACCT_NO AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,CASE WHEN P1.HOST_ACC_STAT IS NULL OR TRIM(P1.HOST_ACC_STAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.HOST_ACC_STAT),'')) END AS URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,CASE WHEN P1.ENTR_ACC_STAT IS NULL OR TRIM(P1.ENTR_ACC_STAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ENTR_ACC_STAT),'')) END AS URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,'' AS SIGN_ORG_NO -- 签约机构编号
    ,'' AS URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,'' AS URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,'OZJSW' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OZJSW_T_NBSW_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OZJSW.ODS_OZJSW_T_NBSW_JRNL_TA AS P1 -- 宁波税务流水表

LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'ZJSW'
        AND P1.SRC_FIELD_EN_NAME ='HOST_ACC_STAT'
        AND P1.SRC_TAB_EN_NAME = 'T_NBSW_JRNL'
        AND P1.TARGET_TAB_EN_NAME='AGL_URTF_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'URFEE_TPTY_ACCTN_STAT_CD'
) AS S1 -- URFEE_TPTY_ACCTN_STAT_CD
       ON P1.HOST_ACC_STAT=S1.SRC_CD_VAL 
LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'ZJSW'
        AND P1.SRC_FIELD_EN_NAME ='ENTR_ACC_STAT'
        AND P1.SRC_TAB_EN_NAME = 'T_NBSW_JRNL'
        AND P1.TARGET_TAB_EN_NAME='AGL_URTF_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'URFEE_HOST_ACCTN_STAT_CD'
) AS S2 -- URFEE_HOST_ACCTN_STAT_CD
       ON P1.ENTR_ACC_STAT=S2.SRC_CD_VAL 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第4组）==============
-- 城乡两费交易明细聚合

INSERT INTO TABLE AGL.AGL_URTF_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,PAY_FEE_MODE_CD -- 缴费模式代码
    ,DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_AMT -- 交易金额
    ,URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,BANK_TXN_SER_NO -- 银行交易流水号
    ,PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CUST_NAME -- 客户名称
    ,BANK_STL_ACCT_NO -- 银行结算账户编号
    ,TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,TAX_TXN_SER_NO -- 税务交易流水号
    ,DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,COMMS_DT -- 委托日期
    ,BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,SIGN_ORG_NO -- 签约机构编号
    ,URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,cast(P1.BAT_SEQ as string)||cast(P1.SERI_NO as string)  AS TXN_SER_NO -- 交易流水号
    ,'2' AS PAY_FEE_MODE_CD -- 缴费模式代码
    ,'2' AS DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,unifiedTime(P1.CLEAR_DATE) AS PLAT_CLEAR_DT -- 平台清算日期
    ,'' AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,'' AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,'' AS BANK_TXN_SER_NO -- 银行交易流水号
    ,'' AS PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.ACCT_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_ACCT_NO AS BANK_STL_ACCT_NO -- 银行结算账户编号
    ,P1.OPEN_BRCH AS TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,P1.SWJYLSH AS TAX_TXN_SER_NO -- 税务交易流水号
    ,P1.ZSJGDM AS DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,P1.ZSJGQC AS DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,'' AS DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,'' AS TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,P1.NSRMC AS TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,P1.NSRSBH AS CUST_DOC_NO -- 客户证件号码
    ,'' AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,'' AS PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,'' AS COMMS_DT -- 委托日期
    ,P2.CONTRACT AS BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,'' AS URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,'' AS URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,P1.SET_ACCT_NO AS AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,'' AS URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,'' AS URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,P2.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,CASE WHEN P2.STAT IS NULL OR TRIM(P2.STAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P2.STAT),'')) END AS URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,P1.DET_STAT AS URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,'OZJSW' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OZJSW_T_NBSW_BAT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_OZJSW.ODS_OZJSW_T_NBSW_BAT_DETAIL_TA AS P1 -- 宁波税务批量明细表

LEFT JOIN ODS_OZJSW.ODS_OZJSW_T_NBSW_SIGN_TF AS P2 -- 宁波税务签约表
       ON P2.CONTRACT =P1.XYSH AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN (
 SELECT      
 P1.TARGET_CD_VAL
,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     WHERE  
       P1.SRC_TAB_LIB_NAME = 'ZJSW'
        AND P1.SRC_FIELD_EN_NAME ='STAT'
        AND P1.SRC_TAB_EN_NAME = 'T_NBSW_SIGN'
        AND P1.TARGET_TAB_EN_NAME='AGL_URTF_TXN_DTL_TA'
        AND P1.TARGET_FIELD_EN_NAME = 'URBA_RURAL_FEE_SIGN_STATUS_CD'
) AS S1 -- URBA_RURAL_FEE_SIGN_STATUS_CD
       ON P2.STAT=S1.SRC_CD_VAL 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_URTF_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_URTF_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_URTF_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,PAY_FEE_MODE_CD -- 缴费模式代码
    ,DIROR_TAX_ORG_SRC_CD -- 主管税务机关来源代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_AMT -- 交易金额
    ,URBA_RURAL_FEE_PAY_MODE_CD -- 城乡两费支付方式代码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,URBA_RURAL_FEE_ACCT_TYPE_CD -- 城乡两费账户类型代码
    ,BANK_TXN_SER_NO -- 银行交易流水号
    ,PAY_REFUND_IDNT_CD -- 缴费退费标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CUST_NAME -- 客户名称
    ,BANK_STL_ACCT_NO -- 银行结算账户编号
    ,TXN_ACCT_OPEN_ACCT_ORG_NO -- 交易账户开户机构编号
    ,TAX_TXN_SER_NO -- 税务交易流水号
    ,DIROR_TAX_ORG_CD -- 主管税务机关代码
    ,DIROR_TAX_ORG_NAME -- 主管税务机关名称
    ,DIROR_TAX_ORG_VIRTUAL_ACCT_NO -- 主管税务机关虚拟户编号
    ,TAX_PRTCPT_INSURE_PSN_NO -- 税务参保人员编号
    ,TAX_PRTCPT_INSURE_PSN_NAME -- 税务参保人员名称
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,PAY_PSN_TYPE_CD -- 缴费人员类型代码
    ,COMMS_DT -- 委托日期
    ,BANK_PAY_AGT_BOOK_NO -- 银行缴费协议书编号
    ,URBA_RUBAL_FEE_PAY_STATUS_CD -- 城乡两费缴费状态代码
    ,URBA_RURAL_FEE_TYPE_CD -- 城乡两费类型代码
    ,AGEN_CORP_STL_ACCT_NO -- 代理单位结算账户编号
    ,URFEE_TPTY_ACCTN_STAT_CD -- 城乡两费主机记账状态代码
    ,URFEE_HOST_ACCTN_STAT_CD -- 城乡两费第三方记账状态代码
    ,SIGN_ORG_NO -- 签约机构编号
    ,URBA_RURAL_FEE_SIGN_STATUS_CD -- 城乡两费签约状态代码
    ,URBA_RURAL_FEE_TXN_STATUS_CD -- 城乡两费交易状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_URTF_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_URTF_TXN_DTL_TA_TM;
