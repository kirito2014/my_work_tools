-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单特约商户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF
--     表中文名：收单特约商户信息聚合
--     创建日期：2023-12-05 00:00:00
--     主键字段：SPC_ARGMT_MERCHT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：存储特约商户聚合
--     更新记录：
--         2023-12-04 00:00:00 沈健 新增
--         2024-07-25 00:00:00 王穆军 修改保持与设计文档一致
--         2024-08-14 00:00:00 王穆军 修改版本，不是最新版，第三组数据重复，证件号关联
--         2024-08-29 00:00:00 王穆军 新增字段，修改逻辑
--         2024-09-05 00:00:00 王穆军 变更字段，码值变更
--         2024-10-21 00:00:00 魏丹丹 修改9月的变更以及1012截止的变更
--         2024-11-11 00:00:00 魏丹丹 生产问题修复



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM
USING ORC
COMMENT '收单特约商户信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 收单特约商户信息聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01;

CREATE TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01 (
     IDNOCFNO STRING COMMENT '证件号码'
    ,IDTYCFTP STRING COMMENT '证件种类'
    ,CINOCSNO STRING COMMENT '客户内码'
    ,ISDTDATE STRING COMMENT '签发日期'
    ,EXDTDATE STRING COMMENT '失效日期'
    ,MIFLBOOL STRING COMMENT '主证标识'
    ,BUTSSTAM STRING COMMENT '建立时间戳'
    ,UPTSSTAM STRING COMMENT '修改时间戳'
    ,RCSTRS1B STRING COMMENT '关联条件'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '收单特约商户信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01(
     IDNOCFNO -- 证件号码
    ,IDTYCFTP -- 证件种类
    ,CINOCSNO -- 客户内码
    ,ISDTDATE -- 签发日期
    ,EXDTDATE -- 失效日期
    ,MIFLBOOL -- 主证标识
    ,BUTSSTAM -- 建立时间戳
    ,UPTSSTAM -- 修改时间戳
    ,RCSTRS1B -- 关联条件
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.IDNOCFNO AS IDNOCFNO -- 证件号码
    ,P1.IDTYCFTP AS IDTYCFTP -- 证件种类
    ,P1.CINOCSNO AS CINOCSNO -- 客户内码
    ,P1.ISDTDATE AS ISDTDATE -- 签发日期
    ,P1.EXDTDATE AS EXDTDATE -- 失效日期
    ,P1.MIFLBOOL AS MIFLBOOL -- 主证标识
    ,P1.BUTSSTAM AS BUTSSTAM -- 建立时间戳
    ,P1.UPTSSTAM AS UPTSSTAM -- 修改时间戳
    ,P1.RCSTRS1B AS RCSTRS1B -- 关联条件
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT * FROM (
select IDNOCFNO,IDTYCFTP,CINOCSNO,ISDTDATE,EXDTDATE,MIFLBOOL,BUTSSTAM,UPTSSTAM,RCSTRS1B,row_number()OVER(PARTITION BY IDNOCFNO,IDTYCFTP ORDER BY butsstam DESC) RN  
from ODS_CORE${version_num}.ODS_CORE_BCFMCIDI_TF 
where del_f = '0' 
-- and MIFLBOOL='1'
and RCSTRS1B<> ''
and pt_dt ='${process_date}'
)
where RN = 1) AS P1 -- 客户证件信息表（柜面核心）

;
-- ==============聚合层字段映射（第1-2组）==============
-- 收单特约商户信息聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01;

CREATE TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01 (
     CINOCSNO STRING COMMENT '客户内码'
    ,PNNOTELN STRING COMMENT '联系信息'
    ,PNTYTLTP STRING COMMENT '电话种类'
    ,BUTSSTAM STRING COMMENT '建立时间戳'
    ,UPTSSTAM STRING COMMENT '修改时间戳'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '收单特约商户信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01(
     CINOCSNO -- 客户内码
    ,PNNOTELN -- 联系信息
    ,PNTYTLTP -- 电话种类
    ,BUTSSTAM -- 建立时间戳
    ,UPTSSTAM -- 修改时间戳
    ,DT_FLG -- 数据存在标志
)
SELECT
     p1.CINOCSNO AS CINOCSNO -- 客户内码
    ,P1.PNNOTELN AS PNNOTELN -- 联系信息
    ,P1.PNTYTLTP AS PNTYTLTP -- 电话种类
    ,P1.BUTSSTAM AS BUTSSTAM -- 建立时间戳
    ,P1.UPTSSTAM AS UPTSSTAM -- 修改时间戳
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT * FROM (
select CINOCSNO,PNNOTELN,PNTYTLTP,BUTSSTAM,UPTSSTAM,row_number()OVER(PARTITION BY CINOCSNO ORDER BY butsstam DESC) RN  
from ODS_CORE${version_num}.ODS_CORE_BCFMCPNI_TF
where PNTYTLTP='6'   
and del_f='0' 
and rcstrs1b<>'9'
and pt_dt ='${process_date}'
)
where RN = 1) AS P1 -- 客户电话信息表

;
-- ==============聚合层字段映射（第1-3组）==============
-- 收单特约商户信息聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01;

CREATE TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 (
     CINOCSNO STRING COMMENT '客户内码'
    ,ADARRGNM STRING COMMENT '地址区划'
    ,ADI1ADDR STRING COMMENT '电话种类'
    ,ADTYADTP STRING COMMENT '地址种类'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '收单特约商户信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01(
     CINOCSNO -- 客户内码
    ,ADARRGNM -- 地址区划
    ,ADI1ADDR -- 电话种类
    ,ADTYADTP -- 地址种类
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CINOCSNO AS CINOCSNO -- 客户内码
    ,P1.ADARRGNM AS ADARRGNM -- 地址区划
    ,P1.ADI1ADDR AS ADI1ADDR -- 电话种类
    ,P1.ADTYADTP AS ADTYADTP -- 地址种类
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT CINOCSNO,ADARRGNM,ADI1ADDR,ADTYADTP FROM (
select CINOCSNO,ADARRGNM,ADI1ADDR,ADTYADTP,row_number()OVER(PARTITION BY CINOCSNO ORDER BY butsstam DESC) RN  
from ODS_CORE${version_num}.ODS_CORE_BCFMCADI_TF 
where ADTYADTP = '4' 
and  del_f='0'  
and rcstrs1b<>'9'
and pt_dt ='${process_date}'
)
where RN = 1) AS P1 -- 客户地址信息表

;
-- ==============聚合层字段映射（第1-4组）==============
-- 收单特约商户信息聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01;

CREATE TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01 (
     IDNOCFNO STRING COMMENT '证件号码'
    ,IDTYCFTP STRING COMMENT '证件种类'
    ,CINOCSNO STRING COMMENT '客户内码'
    ,ISDTDATE STRING COMMENT '签发日期'
    ,EXDTDATE STRING COMMENT '失效日期'
    ,MIFLBOOL STRING COMMENT '主证标识'
    ,BUTSSTAM STRING COMMENT '建立时间戳'
    ,UPTSSTAM STRING COMMENT '修改时间戳'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '收单特约商户信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01(
     IDNOCFNO -- 证件号码
    ,IDTYCFTP -- 证件种类
    ,CINOCSNO -- 客户内码
    ,ISDTDATE -- 签发日期
    ,EXDTDATE -- 失效日期
    ,MIFLBOOL -- 主证标识
    ,BUTSSTAM -- 建立时间戳
    ,UPTSSTAM -- 修改时间戳
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.IDNOCFNO AS IDNOCFNO -- 证件号码
    ,P1.IDTYCFTP AS IDTYCFTP -- 证件种类
    ,P1.CINOCSNO AS CINOCSNO -- 客户内码
    ,P1.ISDTDATE AS ISDTDATE -- 签发日期
    ,P1.EXDTDATE AS EXDTDATE -- 失效日期
    ,P1.MIFLBOOL AS MIFLBOOL -- 主证标识
    ,P1.BUTSSTAM AS BUTSSTAM -- 建立时间戳
    ,P1.UPTSSTAM AS UPTSSTAM -- 修改时间戳
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT * FROM (
 SELECT
  IDNOCFNO
 ,IDTYCFTP
 ,CINOCSNO
 ,ISDTDATE
 ,EXDTDATE
 ,MIFLBOOL
 ,BUTSSTAM
 ,UPTSSTAM
 ,ROW_NUMBER()OVER(PARTITION BY IDNOCFNO ORDER BY BUTSSTAM DESC) RN  
FROM ODS_CORE${version_num}.ODS_CORE_BCFMCIDI_TF 
WHERE RCSTRS1B<> '' AND DEL_F = '0' AND PT_DT ='${process_date}'
)WHERE RN = 1) AS P1 -- 客户证件信息表（柜面核心）

;
-- ==============聚合层字段映射（第1-5组）==============
-- 收单特约商户信息聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_01;

CREATE TABLE AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_01 (
     SPC_ARGMT_MERCHT_NO STRING COMMENT '特约商户编号'
    ,SPC_ARGMT_MERCHT_NAME STRING COMMENT '特约商户名称'
    ,SPC_ARGMT_MERCHT_TYPE_CD STRING COMMENT '特约商户类型代码'
    ,SPC_ARGMT_MERCHT_ATTR_CD STRING COMMENT '特约商户属性代码'
    ,MERCHT_NO STRING COMMENT '商户编号'
    ,WX_MERCHT_NO STRING COMMENT '微信商户编号'
    ,ZFB_MERCHT_NO STRING COMMENT '支付宝商户编号'
    ,UNPY_MERCHT_NO STRING COMMENT '银联商户编号'
    ,MERCHT_NAME STRING COMMENT '商户名称'
    ,STL_ACCT_CUST_IN_CD STRING COMMENT '结算账户客户内码'
    ,LP_CUST_IN_CD STRING COMMENT '法人客户内码'
    ,CORP_CUST_IN_CD STRING COMMENT '企业客户内码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,DOC_ISSUE_DT STRING COMMENT '证件签发日期'
    ,DOC_MATU_DT STRING COMMENT '证件到期日期'
    ,REG_CAP STRING COMMENT '注册资金'
    ,REG_ADDR_DIST_CD STRING COMMENT '注册地址行政区划代码'
    ,REG_ADDR STRING COMMENT '注册地址'
    ,LP_PRINC_DOCTYP_CD STRING COMMENT '法人负责人证件类型代码'
    ,LP_PRINC_DOC_NO STRING COMMENT '法人负责人证件号码'
    ,LP_PRINC_DOC_ISSUE_DT STRING COMMENT '法人负责人证件签发日期'
    ,LP_PRINC_DOC_MATU_DT STRING COMMENT '法人负责人证件到期日期'
    ,LP_PRINC_NAME STRING COMMENT '法人负责人名称'
    ,LP_PRINC_TEL_NO STRING COMMENT '法人负责人电话号码'
    ,ASSIS_DOCTYP_CD STRING COMMENT '辅助证件类型代码'
    ,ASSIS_DOC_NO STRING COMMENT '辅助证件号码'
    ,ASSIS_DOC_NAME STRING COMMENT '辅助证件名称'
    ,CONT_NAME STRING COMMENT '联系人名称'
    ,CONT_TEL_NO STRING COMMENT '联系人电话号码'
    ,CONT_EMAIL_ADDR STRING COMMENT '联系人电子邮箱地址'
    ,SPC_ARGMT_MERCHT_NAME_ABB STRING COMMENT '特约商户名称简称'
    ,SPC_ARGMT_MERCHT_EN_NAME STRING COMMENT '特约商户英文名称'
    ,SPC_ARGMT_MERCHT_CATEGORY_CD STRING COMMENT '特约商户类别代码'
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD STRING COMMENT '特约商户场景大类代码'
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD STRING COMMENT '特约商户场景小类代码'
    ,ZFB_OPER_CAT_CD STRING COMMENT '支付宝经营类目代码'
    ,WX_CORP_STL_CD STRING COMMENT '微信对公结算代码'
    ,HELP_FMR_POINT_STAR_LVL_CD STRING COMMENT '助农点星级代码'
    ,WEB_MERCHT_REG_URL STRING COMMENT '网络商户登记网址'
    ,WEB_MERCHT_REG_IP_ADDR STRING COMMENT '网络商户登记IP地址'
    ,WEB_MERCHT_IC_REC_LIC_NO STRING COMMENT '网络商户ICP备案/许可证号'
    ,CUST_SERV_TEL_NO STRING COMMENT '客服电话号码'
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD STRING COMMENT '实际经营地址所在省份代码'
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD STRING COMMENT '实际经营地址所在市代码'
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD STRING COMMENT '实际经营地址所在区县代码'
    ,AOA_LOCAL_TOWN_STREET_CD STRING COMMENT '实际经营地址所在镇街道代码'
    ,AOA_LOCAL_VILG_COMM_CD STRING COMMENT '实际经营地址所在村社区代码'
    ,ACTL_OPER_ADDR_DESC STRING COMMENT '实际经营地址'
    ,ACTL_OPER_ADDR_LATD STRING COMMENT '实际经营地址纬度'
    ,ACTL_OPER_ADDR_LGTD STRING COMMENT '实际经营地址经度'
    ,TXN_CURR_CD STRING COMMENT '交易币种代码'
    ,PREFR_DERATE_TYPE_CD STRING COMMENT '优惠减免类型代码'
    ,SMALL_MICRO_MERCHT_TYPE_CD STRING COMMENT '小微商户类型代码'
    ,RISK_ESTIM_LVL_CD STRING COMMENT '风险评估等级代码'
    ,EXPAND_MODE_CD STRING COMMENT '拓展方式代码'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,MKTING_TELR_NO STRING COMMENT '营销柜员编号'
    ,MKTING_TELR_NAME STRING COMMENT '营销柜员名称'
    ,MATN_TELR_NO STRING COMMENT '维护柜员编号'
    ,MATN_TELR_NAME STRING COMMENT '维护柜员名称'
    ,SERV_PROVDER_CD STRING COMMENT '服务商编码'
    ,SERV_PROVDER_NAME STRING COMMENT '服务商名称'
    ,SERV_PROVDER_DOC_NO STRING COMMENT '服务商证件号码'
    ,CO_MODE_CD STRING COMMENT '合作模式代码'
    ,BIZ_PROD_PRVLG_CD STRING COMMENT '业务产品权限代码'
    ,ESCR_MERCHT_FLAG STRING COMMENT '特殊费率商户标志'
    ,PRFT_CUT_FLAG STRING COMMENT '分润标志'
    ,INSTALLMENT_MERCHT_FLAG STRING COMMENT '分期商户标志'
    ,POS_MERCHT_FLAG STRING COMMENT 'POS商户标志'
    ,POS_MIGRATE_MERCHT_FLAG STRING COMMENT 'POS迁移商户标志'
    ,IN_BANK_SCENE_PLAT_CD STRING COMMENT '行内场景平台代码'
    ,SAM_OPER_APP_TYPE_CD STRING COMMENT '特约商户操作申请类型代码'
    ,SPC_ARGMT_MERCHT_STATUS_CD STRING COMMENT '特约商户状态代码'
    ,SAM_AUDIT_STAT_CD STRING COMMENT '特约商户审核状态代码'
    ,SUBMIT_APP_MODE_CD STRING COMMENT '进件方式代码'
    ,SUBMIT_APP_TYPE_CD STRING COMMENT '进件类型代码'
    ,PRE_COL_INFO_SER_NO STRING COMMENT '预采集信息流水号'
    ,OPEN_ACCT_TM_STAMP STRING COMMENT '开户时间戳'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,CANC_ACCT_TM_STAMP STRING COMMENT '销户时间戳'
    ,CANC_ACCT_DT STRING COMMENT '销户日期'
    ,AUDIT_NO STRING COMMENT '审核编号'
    ,AUDIT_TM_STAMP STRING COMMENT '审核时间戳'
    ,RECV_BIL_PROD_FRZ_RSN_CD STRING COMMENT '收单产品冻结原因代码'
    ,CANC_ACCT_RSN_CD STRING COMMENT '销户原因代码'
    ,AUDIT_FAIL_RSN STRING COMMENT '审核失败原因'
    ,INPUT_TELR_NO STRING COMMENT '录入柜员编号'
    ,INPUT_ORG_NO STRING COMMENT '录入机构编号'
    ,RECNT_MODIF_ORG_NO STRING COMMENT '最后修改机构编号'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,FINAL_UPDATE_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,MIGRATE_MERCHT_IDNT_CD STRING COMMENT '迁移商户标识代码'
    ,MIGRATE_TM_STAMP STRING COMMENT '迁移时间戳'
    ,FRZ_RSN_REM STRING COMMENT '冻结原因备注'
    ,RECNT_FRZ_TM_STAMP STRING COMMENT '最近冻结时间戳'
    ,RECNT_UNFRZ_TM_STAMP STRING COMMENT '最近解冻时间戳'
    ,RECV_BIL_STL_ACCT_NO STRING COMMENT '收单结算账户编号'
    ,recdtp STRING COMMENT 'None'
    ,recdno STRING COMMENT 'None'
    ,LP_DOC_INFO_SETUP_TM_STAMP STRING COMMENT '法人证件信息建立时间戳'
    ,LP_DOC_INFO_MODIF_TM_STAMP STRING COMMENT '法人证件信息修改时间戳'
    ,SAM_CATEGORY_DESC STRING COMMENT '特约商户类别描述'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '收单特约商户信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_01(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,recdtp -- None
    ,recdno -- None
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,DT_FLG -- 数据存在标志
)
SELECT
     trim(P1.SMCHNO) AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.SMCHNA AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.MCHTYP AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,P1.MCHATT AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,P1.PAPBID AS MERCHT_NO -- 商户编号
    ,CASE WHEN P7.PAYWAY='02' THEN P7.OTCHNO END AS WX_MERCHT_NO -- 微信商户编号
    ,CASE WHEN P7.PAYWAY='03' THEN P7.OTCHNO END AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,CASE WHEN P7.PAYWAY='06' THEN P7.OTCHNO END AS UNPY_MERCHT_NO -- 银联商户编号
    ,P2.PBNAME AS MERCHT_NAME -- 商户名称
    ,TRIM(COALESCE(p5.AA03CSNO,p6.CINOCSNO)) AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,P4.CINOCSNO AS LP_CUST_IN_CD -- 法人客户内码
    ,P3.CINOCSNO AS CORP_CUST_IN_CD -- 企业客户内码
    ,COALESCE(P3.CINOCSNO,P4.CINOCSNO) AS CUST_IN_CD -- 客户内码
    ,P2.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P2.DOC_NO AS DOC_NO -- 证件号码
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.ISDTDATE) END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.EXDTDATE) END AS DOC_MATU_DT -- 证件到期日期
    ,P2.REGCAP AS REG_CAP -- 注册资金
    ,P9.ADARRGNM AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,P9.ADI1ADDR AS REG_ADDR -- 注册地址
    ,P2.LP_PRINC_DOCTYP_CD AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P2.LP_PRINC_DOC_NO AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,SUBSTR(unifiedTime(P2.LP_PRINC_DOC_ISSUE_DT),1,10) AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,SUBSTR(unifiedTime(P2.LP_PRINC_DOC_MATU_DT),1,10) AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P2.LP_PRINC_NAME AS LP_PRINC_NAME -- 法人负责人名称
    ,P2.LP_PRINC_TEL_NO AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,P2.AUX_DOC_TYPE AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,P2.AUX_DOC_NUMBER AS ASSIS_DOC_NO -- 辅助证件号码
    ,P2.AUX_DOC_NAME AS ASSIS_DOC_NAME -- 辅助证件名称
    ,P2.CONTAT AS CONT_NAME -- 联系人名称
    ,P2.COTMOB AS CONT_TEL_NO -- 联系人电话号码
    ,P2.COTEML AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,P1.SMCHAB AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,P2.MCHENM AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SUBSTR(TRIM(p2.mchmcc),1,4) AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,p2.scene_superclass AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,p2.scene_subclass AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,P2.ALINDU AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,P2.WXSTID AS WX_CORP_STL_CD -- 微信对公结算代码
    ,P2.AUX_FARM_POINT_LEVEL AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,P2.WMLGST AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,P2.WMLGIP AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,P2.WMICPB AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,P2.CUTMOB AS CUST_SERV_TEL_NO -- 客服电话号码
    ,P2.MCHPRO AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,P2.MCHCTY AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,P2.MCHARA AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,P2.MCHSTR AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,P2.MCHVIL AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,P2.ADDRES AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,P2.MCHLAT AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,P2.MCHLON AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,P2.TRACUR AS TXN_CURR_CD -- 交易币种代码
    ,P2.DISCOUNT_TYPE AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,P2.SMCHTP AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,P1.RISKLV AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,P2.DEVMOD AS EXPAND_MODE_CD -- 拓展方式代码
    ,P1.BEBRCH AS BELONG_ORG_NO -- 归属机构编号
    ,P2.MAMANO AS MKTING_TELR_NO -- 营销柜员编号
    ,P2.MAMANM AS MKTING_TELR_NAME -- 营销柜员名称
    ,P2.MTMTNO AS MATN_TELR_NO -- 维护柜员编号
    ,P2.MTMTNM AS MATN_TELR_NAME -- 维护柜员名称
    ,P2.SEPRNM AS SERV_PROVDER_CD -- 服务商编码
    ,P2.OUTNAM AS SERV_PROVDER_NAME -- 服务商名称
    ,P2.OUTCER AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,P2.COOMOD AS CO_MODE_CD -- 合作模式代码
    ,P2.BUSPER AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,P2.ISSPRT AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,P1.ISHARE AS PRFT_CUT_FLAG -- 分润标志
    ,P2.SFINST AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,P1.POSMIG AS POS_MERCHT_FLAG -- POS商户标志
    ,P1.ISPOSM AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,CASE WHEN P1.MRCHID IS NULL OR TRIM(P1.MRCHID)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.MRCHID)),'') END AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CASE WHEN P1.MCHOPT IS NULL OR TRIM(P1.MCHOPT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.MCHOPT)),'') END AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,P1.MCSTAT AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,CASE WHEN P1.VFSTAT IS NULL OR TRIM(P1.VFSTAT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.VFSTAT)),'') END AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,P1.ADDWAY AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,P1.PREPTY AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,P1.PREPNU AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,unifiedTime(P1.OPACDT) AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,substr(P1.OPACDT,1,10) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P1.CLACDT) AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,substr(P1.CLACDT,1,10) AS CANC_ACCT_DT -- 销户日期
    ,P1.VEFYSQ AS AUDIT_NO -- 审核编号
    ,unifiedTime(P1.VERDAT) AS AUDIT_TM_STAMP -- 审核时间戳
    ,CASE WHEN P1.FRORES IS NULL OR TRIM(P1.FRORES)='' 
     THEN '' 
ELSE COALESCE(TRIM(S4.TARGET_CD_VAL), CONCAT('@',TRIM(P1.FRORES)),'') END AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,P1.CLARES AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,P1.REMARK AS AUDIT_FAIL_RSN -- 审核失败原因
    ,P1.tranus AS INPUT_TELR_NO -- 录入柜员编号
    ,P1.brchno AS INPUT_ORG_NO -- 录入机构编号
    ,P1.upbrchno AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,unifiedTime(P1.gmt_create) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.updusr AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(P1.gmt_modified) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.ismigr AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,unifiedTime(P1.MIGRDT) AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,P1.FRORES_REMARK AS FRZ_RSN_REM -- 冻结原因备注
    ,unifiedTime(P2.LAST_FREEZE_TIME) AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,unifiedTime(P2.LAST_THAW_TIME) AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,p1.bankno AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.recdtp AS recdtp -- None
    ,P1.recdno AS recdno -- None
    ,unifiedTime1(P3.BUTSSTAM) AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,unifiedTime1(P3.UPTSSTAM) AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,REPLACE(P2.MCHMCC,SUBSTR(P2.MCHMCC,1,5),'') AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP${version_num}.ODS_MCSP_SMERCHANT_INFO_TF AS P1 -- 特约商户表

LEFT JOIN (select 
     p2.SMCHNO
    ,p2.MCHMCC
    ,P2.PBNAME
    ,coalesce(trim(P2.RECDTP),trim(p21.RECDTP)) as DOCTYP_CD
    ,coalesce(trim(P2.RECDNO),trim(p21.RECDNO)) as DOC_NO
    ,coalesce(TRIM(p2.LEGCET),TRIM(p21.LEGCET)) as LP_PRINC_DOCTYP_CD
    ,coalesce(TRIM(p2.LEGNUM),trim(p21.LEGNUM)) as LP_PRINC_DOC_NO
    ,coalesce(TRIM(p2.LESTIM),trim(p21.LESTIM)) AS LP_PRINC_DOC_ISSUE_DT
    ,coalesce(TRIM(p2.LEGTIM),trim(p21.LEGTIM)) AS LP_PRINC_DOC_MATU_DT
    ,coalesce(TRIM(p2.LEGNAM),trim(p21.LEGNAM)) AS LP_PRINC_NAME
    ,coalesce(TRIM(p2.LEGMOB),trim(p21.LEGMOB)) AS LP_PRINC_TEL_NO
    ,P2.REGCAP
    ,P2.AUX_DOC_TYPE
    ,P2.AUX_DOC_NUMBER
    ,P2.AUX_DOC_NAME
    ,P2.CONTAT
    ,P2.COTMOB
    ,P2.COTEML
    ,P2.MCHENM
    ,P2.ALINDU
    ,P2.WXSTID
    ,P2.AUX_FARM_POINT_LEVEL
    ,P2.WMLGST
    ,P2.WMLGIP
    ,P2.WMICPB
    ,P2.CUTMOB
    ,P2.MCHPRO
    ,P2.MCHCTY
    ,P2.MCHARA
    ,P2.MCHSTR
    ,P2.MCHVIL
    ,P2.ADDRES
    ,P2.MCHLAT
    ,P2.MCHLON
    ,P2.TRACUR
    ,P2.DISCOUNT_TYPE
    ,P2.SMCHTP
    ,P2.DEVMOD
    ,P2.MAMANO
    ,P2.MAMANM
    ,P2.MTMTNO
    ,P2.MTMTNM
    ,P2.SEPRNM
    ,P2.OUTNAM
    ,P2.OUTCER
    ,P2.COOMOD
    ,P2.BUSPER
    ,P2.ISSPRT
    ,P2.SFINST
    ,P2.LAST_FREEZE_TIME
    ,P2.LAST_THAW_TIME
    ,p2.scene_superclass
    ,p2.scene_subclass
FROM ods_mcsp${version_num}.ods_mcsp_SMERCHANT_INFO_DETAIL_tf p2 --特约商户基本信息表
LEFT JOIN ods_mcsp${version_num}.ods_mcsp_SMERCHANT_INFO_DETAIL_VERIFY_tf p21 --特约商户基本信息审核表
       ON trim(p2.SMCHNO)=trim(p21.SMCHNO) AND p21.pt_dt = '${process_date}' and p21.del_f = '0'
WHERE p2.DEL_F='0' and p2.pt_dt = '${process_date}'
) AS P2 -- 特约商户基本信息审核表
       ON P1.SMCHNO = P2.SMCHNO 
LEFT JOIN (SELECT 
 IDNOCFNO
,IDTYCFTP
,CINOCSNO
,ISDTDATE
,EXDTDATE
,BUTSSTAM
,UPTSSTAM
,MIFLBOOL
FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01) AS P3 -- 客户证件信息表（柜面核心）
       ON p2.DOCTYP_CD = P3.IDTYCFTP  AND p2.DOC_NO=P3.IDNOCFNO AND P3.IDNOCFNO<>'000000000000000000' 
LEFT JOIN (SELECT 
 IDNOCFNO
,IDTYCFTP
,CINOCSNO
,ISDTDATE
,EXDTDATE
,BUTSSTAM
,UPTSSTAM
,MIFLBOOL
FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01) AS P4 -- 客户证件信息表（柜面核心）
       ON p2.LP_PRINC_DOC_NO= TRIM(P4.IDNOCFNO) AND p2.LP_PRINC_DOCTYP_CD = TRIM(P4.IDTYCFTP) AND P4.IDNOCFNO<>'000000000000000000' 
LEFT JOIN (
select
 D2.aa01ac15 
,
 D2.AA03CSNO
from
 ods_core${version_num}.ODS_CORE_BDFMHQAA_TF D2
where
 D2.pt_dt = '${process_date}'
 and D2.DEL_F = '0'
 ) AS P5 -- 活期存款账户主档
       ON substr(trim(P1.bankno),1,15)=substr(P5.aa01ac15,1,15) 
LEFT JOIN (
select
 D3.cdnoac19 
, D3.cinocsno
from
 ods_core${version_num}.ODS_CORE_BWFMDCIM_TF D3
where
 D3.pt_dt = '${process_date}'
 and D3.DEL_F = '0'
 ) AS P6 -- 借记卡信息主档文件
       ON trim(P1.bankno)=P6.cdnoac19 
LEFT JOIN (
SELECT
 TRIM(SMCHNO) SMCHNO
,MAX(TRIM(PAYWAY)) PAYWAY
,MAX(TRIM(OTCHNO)) OTCHNO
FROM ODS_MCSP${version_num}.ODS_MCSP_SMERCHANT_INFO_SUBREC_TF
WHERE TRIM(PAYWAY) IN('02','03','06') AND DEL_F = '0' AND PT_DT='${process_date}'
GROUP BY TRIM(SMCHNO)
) AS P7 -- 商户报送记录表
       ON P1.SMCHNO=P7.SMCHNO 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 AS P9 -- 客户地址信息表
       ON P3.CINOCSNO= P9.CINOCSNO 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 码值表
       ON P1.MCHOPT=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='SMERCHANT_INFO' --来源表英文名 大写
AND S1.SRC_FIELD_EN_NAME='MCHOPT' --来源字段英文名 大写
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S1.TARGET_FIELD_EN_NAME='SAM_OPER_APP_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 码值表
       ON P1.VFSTAT=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='SMERCHANT_INFO' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='VFSTAT' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='SAM_AUDIT_STAT_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S3 -- 码值表
       ON P1.MRCHID=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S3.SRC_TAB_EN_NAME='SMERCHANT_INFO' --来源表英文名 大写
AND S3.SRC_FIELD_EN_NAME='MRCHID' --来源字段英文名 大写
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S3.TARGET_FIELD_EN_NAME='IN_BANK_SCENE_PLAT_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S4 -- 码值表
       ON P1.FRORES=S4.SRC_CD_VAL  
AND S4.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S4.SRC_TAB_EN_NAME='SMERCHANT_INFO' --来源表英文名 大写
AND S4.SRC_FIELD_EN_NAME='FRORES' --来源字段英文名 大写
AND S4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S4.TARGET_FIELD_EN_NAME='RECV_BIL_PROD_FRZ_RSN_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.IS_DELETE = '0' AND p1.DEL_F = '0'
;
-- ==============聚合层字段映射（第1-7组）==============
-- 收单特约商户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.SPC_ARGMT_MERCHT_NO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.SPC_ARGMT_MERCHT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.SPC_ARGMT_MERCHT_TYPE_CD AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,P1.SPC_ARGMT_MERCHT_ATTR_CD AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,P1.MERCHT_NO AS MERCHT_NO -- 商户编号
    ,P1.WX_MERCHT_NO AS WX_MERCHT_NO -- 微信商户编号
    ,P1.ZFB_MERCHT_NO AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,P1.UNPY_MERCHT_NO AS UNPY_MERCHT_NO -- 银联商户编号
    ,P1.MERCHT_NAME AS MERCHT_NAME -- 商户名称
    ,P1.STL_ACCT_CUST_IN_CD AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,P1.LP_CUST_IN_CD AS LP_CUST_IN_CD -- 法人客户内码
    ,P1.CORP_CUST_IN_CD AS CORP_CUST_IN_CD -- 企业客户内码
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.DOC_ISSUE_DT AS DOC_ISSUE_DT -- 证件签发日期
    ,P1.DOC_MATU_DT AS DOC_MATU_DT -- 证件到期日期
    ,P1.REG_CAP AS REG_CAP -- 注册资金
    ,P1.REG_ADDR_DIST_CD AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,P1.REG_ADDR AS REG_ADDR -- 注册地址
    ,P1.LP_PRINC_DOCTYP_CD AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P1.LP_PRINC_DOC_NO AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,P1.LP_PRINC_DOC_ISSUE_DT AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,P1.LP_PRINC_DOC_MATU_DT AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P1.LP_PRINC_NAME AS LP_PRINC_NAME -- 法人负责人名称
    ,P1.LP_PRINC_TEL_NO AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,P1.LP_DOC_INFO_SETUP_TM_STAMP AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,P1.LP_DOC_INFO_MODIF_TM_STAMP AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,P1.ASSIS_DOCTYP_CD AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,P1.ASSIS_DOC_NO AS ASSIS_DOC_NO -- 辅助证件号码
    ,P1.ASSIS_DOC_NAME AS ASSIS_DOC_NAME -- 辅助证件名称
    ,P1.CONT_NAME AS CONT_NAME -- 联系人名称
    ,P1.CONT_TEL_NO AS CONT_TEL_NO -- 联系人电话号码
    ,P1.CONT_EMAIL_ADDR AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,P1.SPC_ARGMT_MERCHT_NAME_ABB AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,P1.SPC_ARGMT_MERCHT_EN_NAME AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,P1.SPC_ARGMT_MERCHT_CATEGORY_CD AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,P1.SAM_CATEGORY_DESC AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,P1.SPC_ARGMT_MERCHT_SCENE_MCLS_CD AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,P1.SPC_ARGMT_MERCHT_SCENE_SCLS_CD AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'' AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,'' AS INDUS_NAME -- 行业名称
    ,P1.ZFB_OPER_CAT_CD AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,P1.WX_CORP_STL_CD AS WX_CORP_STL_CD -- 微信对公结算代码
    ,P1.HELP_FMR_POINT_STAR_LVL_CD AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,P1.WEB_MERCHT_REG_URL AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,P1.WEB_MERCHT_REG_IP_ADDR AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,P1.WEB_MERCHT_IC_REC_LIC_NO AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,COALESCE(P10.WXCSRA,0) AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,P1.CUST_SERV_TEL_NO AS CUST_SERV_TEL_NO -- 客服电话号码
    ,P1.ACTL_OPER_ADDR_LOCAL_PROV_CD AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,P1.ACTL_OPER_ADDR_LOCAL_CITY_CD AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,P1.ACTL_OPER_ADDR_LOCAL_DIST_CD AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,P1.AOA_LOCAL_TOWN_STREET_CD AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,P1.AOA_LOCAL_VILG_COMM_CD AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,P1.ACTL_OPER_ADDR_DESC AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,P1.ACTL_OPER_ADDR_LATD AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,P1.ACTL_OPER_ADDR_LGTD AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,P1.TXN_CURR_CD AS TXN_CURR_CD -- 交易币种代码
    ,P1.PREFR_DERATE_TYPE_CD AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,P1.SMALL_MICRO_MERCHT_TYPE_CD AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,P1.RISK_ESTIM_LVL_CD AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,P1.EXPAND_MODE_CD AS EXPAND_MODE_CD -- 拓展方式代码
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.MKTING_TELR_NO AS MKTING_TELR_NO -- 营销柜员编号
    ,P1.MKTING_TELR_NAME AS MKTING_TELR_NAME -- 营销柜员名称
    ,P1.MATN_TELR_NO AS MATN_TELR_NO -- 维护柜员编号
    ,P1.MATN_TELR_NAME AS MATN_TELR_NAME -- 维护柜员名称
    ,P1.SERV_PROVDER_CD AS SERV_PROVDER_CD -- 服务商编码
    ,P1.SERV_PROVDER_NAME AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.SERV_PROVDER_DOC_NO AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,P11.SPTYPE AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,'' AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,'' AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,P13.SETWAY AS STL_MODE_CD -- 结算方式代码
    ,P13.SETACH  AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,P13.SETANA AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,CASE WHEN P13.BILACT IS NULL OR TRIM(P13.BILACT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P13.BILACT)),'') END AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,P1.RECV_BIL_STL_ACCT_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P13.BIANAM  AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,CASE WHEN P13.ACCTYP IS NULL OR TRIM(P13.ACCTYP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P13.ACCTYP)),'') END AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,P13.ACBANO AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,P13.ACCOUNT_BANK AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,p13.tbilacn AS ARBSA_NO -- 实际收单结算账户编号
    ,p13.tbianam AS ARBSA_NAME -- 实际收单结算账户名称
    ,p13.tsetach AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,p13.tsetana AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,p13.tbilact AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,p13.tacbano AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,P13.ACFECH AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,CASE WHEN P13.MCFECT IS NULL OR TRIM(P13.MCFECT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P13.MCFECT)),'') END AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,P13.MCFENO AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,P13.MCFENM AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,P13.MONCYC AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,P13.MONWAY AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,P13.FEECYC AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,P13.IS_CONRECEIPT AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,P13.REFWAY AS REFUND_MODE_CD -- 退款模式代码
    ,P13.REFACN AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,P13.REFACT AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,P13.REFANO AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,P13.REFANM AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,P13.ISOVRE AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,P13.MAACTY AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,P13.MARACC AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,P13.MAACNA AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,P13.MAACCH AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,P13.MACHNA AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,P13.MAACRY AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN SUBSTR(P1.CUST_IN_CD,1,2)='81' AND COALESCE(P14.CRTF_TYP,'')<>'' AND COALESCE(P14.CRTF_NO,'')<>''  THEN '1'
          WHEN SUBSTR(P1.CUST_IN_CD,1,2)='82' AND COALESCE(P15.GU01CFTP,'')<>'' AND COALESCE(P15.GU02CFNO,'')<>''  THEN '1'
       ELSE '0'
END  AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,P1.CO_MODE_CD AS CO_MODE_CD -- 合作模式代码
    ,P1.BIZ_PROD_PRVLG_CD AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,P1.ESCR_MERCHT_FLAG AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,P1.PRFT_CUT_FLAG AS PRFT_CUT_FLAG -- 分润标志
    ,P1.INSTALLMENT_MERCHT_FLAG AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,P1.POS_MERCHT_FLAG AS POS_MERCHT_FLAG -- POS商户标志
    ,P1.POS_MIGRATE_MERCHT_FLAG AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,P1.IN_BANK_SCENE_PLAT_CD AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,P1.SAM_OPER_APP_TYPE_CD AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,P1.SPC_ARGMT_MERCHT_STATUS_CD AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,P1.SAM_AUDIT_STAT_CD AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,P1.SUBMIT_APP_MODE_CD AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,P1.SUBMIT_APP_TYPE_CD AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,P1.PRE_COL_INFO_SER_NO AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,P1.OPEN_ACCT_TM_STAMP AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,P1.OPEN_ACCT_DT AS OPEN_ACCT_DT -- 开户日期
    ,P1.CANC_ACCT_TM_STAMP AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,P1.CANC_ACCT_DT AS CANC_ACCT_DT -- 销户日期
    ,P1.AUDIT_NO AS AUDIT_NO -- 审核编号
    ,P1.AUDIT_TM_STAMP AS AUDIT_TM_STAMP -- 审核时间戳
    ,P1.RECV_BIL_PROD_FRZ_RSN_CD AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,P1.CANC_ACCT_RSN_CD AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,P1.AUDIT_FAIL_RSN AS AUDIT_FAIL_RSN -- 审核失败原因
    ,P1.INPUT_TELR_NO AS INPUT_TELR_NO -- 录入柜员编号
    ,P1.INPUT_ORG_NO AS INPUT_ORG_NO -- 录入机构编号
    ,P1.RECNT_MODIF_ORG_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.FINAL_UPDATE_TM_STAMP AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.MIGRATE_MERCHT_IDNT_CD AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,P1.MIGRATE_TM_STAMP AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,P1.FRZ_RSN_REM AS FRZ_RSN_REM -- 冻结原因备注
    ,P1.RECNT_FRZ_TM_STAMP AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,P1.RECNT_UNFRZ_TM_STAMP AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_SMERCHANT_INFO_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_01 AS P1 -- 特约商户表

LEFT JOIN (
select 
 WXSTID,
 WXCSRA,
 row_number ()over(partition by WXSTID order by updtdt desc )rn 
from
ods_mcsp${version_num}.ODS_MCSP_BMS_INDUSTRY_TF
where pt_dt = '${process_date}'
and del_f = '0'
) AS P10 -- 行业类别表
       ON P1.WX_CORP_STL_CD = P10.WXSTID
AND P10.RN =1 
LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_SEPR_INFO_TF AS P11 -- 服务商信息表
       ON P1.SERV_PROVDER_CD = P11.SEPRNM 
AND P11.PT_DT='${process_date}' 
AND DEL_F = '0' 
LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_SMERCHANT_SETM_TF AS P13 -- 特约商户结算信息表
       ON P1.SPC_ARGMT_MERCHT_NO = P13.BUSSNO 
AND P13.IS_DELETE = '0'
AND P13.DEL_F='0'
AND p13.bustyp = '2'
AND P13.PT_DT='${process_date}' 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_TERROR_LIST_TF AS P14 -- 涉恐名单信息表
       ON P1.recdtp = P14.CRTF_TYP 
AND P1.recdno = P14.CRTF_NO 
AND P14.DELETED='0' 
AND P14.CUST_STUS='1' 
AND P14.DEL_F='0' 
AND P14.PT_DT='${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQGU_TF AS P15 -- 恐怖活动客户名单登记簿
       ON P1.recdtp = P15.GU01CFTP 
AND P1.recdno = P15.GU02CFNO  
AND P15.GU05RS1B <>'9' 
AND P15.GU04FLAG='1' 
AND P15.DEL_F='0'  
AND P15.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 码值表
       ON P13.BILACT=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='SMERCHANT_SETM' --来源表英文名 大写
AND S1.SRC_FIELD_EN_NAME='BILACT' --来源字段英文名 大写
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S1.TARGET_FIELD_EN_NAME='RECV_BIL_STL_ACCT_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 码值表
       ON P13.ACCTYP=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='SMERCHANT_SETM' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='ACCTYP' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='RECV_BIL_STL_ACCT_CATEGORY_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S3 -- 码值表
       ON P13.MCFECT=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S3.SRC_TAB_EN_NAME='SMERCHANT_SETM' --来源表英文名 大写
AND S3.SRC_FIELD_EN_NAME='MCFECT' --来源字段英文名 大写
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S3.TARGET_FIELD_EN_NAME='COMM_FEE_EXPNT_ACCT_TYPE_CD' 
;
-- ==============聚合层字段映射（第2组）==============
-- 收单特约商户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     TRIM(P1.MERCHANT_NO) AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCHANT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,CASE WHEN P1.MERCHANT_SPECIES IS NULL OR TRIM(P1.MERCHANT_SPECIES)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.MERCHANT_SPECIES)),'') END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'1' AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS WX_MERCHT_NO -- 微信商户编号
    ,'' AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,TRIM(COALESCE(P3.AA03CSNO,P4.CINOCSNO)) AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,P8.CINOCSNO AS LP_CUST_IN_CD -- 法人客户内码
    ,P2.CINOCSNO AS CORP_CUST_IN_CD -- 企业客户内码
    ,TRIM(COALESCE(P3.AA03CSNO,P4.CINOCSNO)) AS CUST_IN_CD -- 客户内码
    ,CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)),'') END AS DOCTYP_CD -- 证件类型代码
    ,P1.BUSINESS_LICENSE AS DOC_NO -- 证件号码
    ,CASE WHEN P2.MIFLBOOL='1' THEN unifiedTime(P2.ISDTDATE) END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN P2.MIFLBOOL='1' THEN unifiedTime(P2.EXDTDATE) END AS DOC_MATU_DT -- 证件到期日期
    ,P1.REGISTERED_CAPITAL AS REG_CAP -- 注册资金
    ,P6.ADARRGNM AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,P6.ADI1ADDR AS REG_ADDR -- 注册地址
    ,P1.LEGAL_PERSON_CERT_TYPE_ID AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P1.LEGAL_PERSON_CERTIFICATE AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,unifiedTime(P8.ISDTDATE) AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,unifiedTime(P8.EXDTDATE) AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P1.LEGAL_PERSON_NAME AS LP_PRINC_NAME -- 法人负责人名称
    ,P9.PNNOTELN AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,unifiedTime1(P8.BUTSSTAM) AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,unifiedTime1(P8.UPTSSTAM) AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,'' AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,'' AS ASSIS_DOC_NO -- 辅助证件号码
    ,'' AS ASSIS_DOC_NAME -- 辅助证件名称
    ,P1.CONTACT_NAME AS CONT_NAME -- 联系人名称
    ,P1.CONTACT_MOBILE_PHONE AS CONT_TEL_NO -- 联系人电话号码
    ,'' AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,P1.MERCHANT_SHORT_NAME AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,'' AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SUBSTR(TRIM(P1.MCC),1,4) AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,'' AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,'' AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,'' AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'' AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,'' AS INDUS_NAME -- 行业名称
    ,'' AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,'' AS WX_CORP_STL_CD -- 微信对公结算代码
    ,'' AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,'' AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,'' AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,'' AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,NULL AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,'' AS CUST_SERV_TEL_NO -- 客服电话号码
    ,P1.BUSINESS_PROVINCE_CODE AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,P1.BUSINESS_CITY_CODE AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,P1.BUSINESS_DISTRICT_CODE AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,P1.BUSINESS_TOWN_CODE AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,P1.BUSINESS_VILLAGE_CODE AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,P1.BUSINESS_ADDRESS AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,'' AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,'' AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,CASE WHEN P1.MERCHANT_TYPE  IS NULL OR TRIM(P1.MERCHANT_TYPE  )='' 
     THEN '' 
ELSE COALESCE(TRIM(P15.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_TYPE),'') 
END AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,'1' AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,P1.RISK_LEVEL AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,P1.MERCHANT_EXTENSION_METHOD AS EXPAND_MODE_CD -- 拓展方式代码
    ,P1.ORG_CODE AS BELONG_ORG_NO -- 归属机构编号
    ,'' AS MKTING_TELR_NO -- 营销柜员编号
    ,'' AS MKTING_TELR_NAME -- 营销柜员名称
    ,'' AS MATN_TELR_NO -- 维护柜员编号
    ,'' AS MATN_TELR_NAME -- 维护柜员名称
    ,'' AS SERV_PROVDER_CD -- 服务商编码
    ,P1.OUT_SERVICE_INST_NAME AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.OUT_SERVICE_INST_BUSINESS_LICENSE AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,'' AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,NULL AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,NULL AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,'' AS STL_MODE_CD -- 结算方式代码
    ,'' AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,'' AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,CASE WHEN SUBSTR(P1.ACCTNO,1,3)='201' THEN '1' ELSE '2' END AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,P1.ACCTNO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.MERCHANT_USERNAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,'' AS ARBSA_NO -- 实际收单结算账户编号
    ,'' AS ARBSA_NAME -- 实际收单结算账户名称
    ,'' AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,'' AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,'' AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,'' AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,'' AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,'' AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,'' AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,'' AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,CASE WHEN P1.SETTLEMENT_PERIOD  IS NULL OR TRIM(P1.SETTLEMENT_PERIOD  )='' 
     THEN '' 
ELSE COALESCE(TRIM(P16.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEMENT_PERIOD),'') 
END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,'' AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,'' AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,'' AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,'' AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,'' AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,'' AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,'' AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,'' AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,'' AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,'' AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN SUBSTR(P2.CINOCSNO,1,2)='81' AND COALESCE(P10.CRTF_TYP,'')<>'' AND COALESCE(P10.CRTF_NO,'')<>''  THEN '1'
     WHEN SUBSTR(P2.CINOCSNO,1,2)='82' AND COALESCE(P11.GU01CFTP,'')<>'' AND COALESCE(P11.GU02CFNO,'')<>''  THEN '1'
  ELSE '0'
END AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,'1' AS CO_MODE_CD -- 合作模式代码
    ,'1' AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,'' AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,'' AS PRFT_CUT_FLAG -- 分润标志
    ,'' AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,'' AS POS_MERCHT_FLAG -- POS商户标志
    ,'' AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CASE WHEN P1.MERCHANT_STATUS  IS NULL OR TRIM(P1.MERCHANT_STATUS  )='' 
     THEN '' 
ELSE COALESCE(TRIM(P12.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') 
END AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,CASE WHEN P1.MERCHANT_STATUS  IS NULL OR TRIM(P1.MERCHANT_STATUS  )='' 
     THEN '' 
ELSE COALESCE(TRIM(P13.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') 
END AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,CASE WHEN P1.PROCESS_STATUS    IS NULL OR TRIM(P1.PROCESS_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P14.TARGET_CD_VAL), '@'||TRIM(P1.PROCESS_STATUS),'') 
END AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,'' AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,'' AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,'' AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,unifiedTime1(P1.CREATE_TIME) AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,substr(P1.CREATE_TIME,1,10) AS OPEN_ACCT_DT -- 开户日期
    ,NULL AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,NULL AS CANC_ACCT_DT -- 销户日期
    ,'' AS AUDIT_NO -- 审核编号
    ,unifiedTime(P1.REVIEW_TIME) AS AUDIT_TM_STAMP -- 审核时间戳
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,'' AS AUDIT_FAIL_RSN -- 审核失败原因
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,P1.ORG_CODE AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,NULL AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,NULL AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,NULL AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,NULL AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,NULL AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_ACPS_MGM_OPEN_MERCHANT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
select
 *,
 row_number() over(partition by merchant_no order by create_time desc ) rn
from ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_OPEN_MERCHANT_TF
where pt_dt = '${process_date}' and del_f = '0'
) AS P1 -- 开放收单商户信息表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 码值表
       ON P1.BUSINESS_LICENSE_CERT_TYPE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND S1.SRC_FIELD_EN_NAME='BUSINESS_LICENSE_CERT_TYPE' --来源字段英文名 大写
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S1.TARGET_FIELD_EN_NAME='DOCTYP_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 码值表
       ON P1.MERCHANT_SPECIES=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='MERCHANT_SPECIES' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_TYPE_CD' 
LEFT JOIN (SELECT 
 IDNOCFNO
,IDTYCFTP
,CINOCSNO
,ISDTDATE
,EXDTDATE
,MIFLBOOL
FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01) AS P2 -- 客户证件信息表（柜面核心)
       ON CAST(CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)),'') END AS STRING)= P2.IDTYCFTP 
AND P1.BUSINESS_LICENSE=P2.IDNOCFNO 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 AS P6 -- 客户地址信息表
       ON P2.CINOCSNO  = P6.CINOCSNO   
LEFT JOIN (
select
 D2.aa01ac15 
,
 D2.AA03CSNO
from
 ods_core${version_num}.ODS_CORE_BDFMHQAA_TF D2
where
 D2.pt_dt = '${process_date}'
 and D2.DEL_F = '0'
 ) AS P3 -- 活期存款账户主档
       ON substr(trim(P1.ACCTNO),1,15)=substr(P3.aa01ac15,1,15)  
LEFT JOIN (
select
 D3.cdnoac19 
, D3.cinocsno
from
 ods_core${version_num}.ODS_CORE_BWFMDCIM_TF D3
where
 D3.pt_dt = '${process_date}'
 and D3.DEL_F = '0'
 ) AS P4 -- 借记卡信息主档文件
       ON trim(P1.ACCTNO)=P4.cdnoac19  
LEFT JOIN (SELECT 
 IDNOCFNO
,IDTYCFTP
,CINOCSNO
,ISDTDATE
,EXDTDATE
,BUTSSTAM
,UPTSSTAM
FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01) AS P8 -- 客户证件信息表（柜面核心）
       ON P1.legal_person_cert_type_id= P8.IDTYCFTP AND P1.legal_person_certificate = P8.IDNOCFNO 
LEFT JOIN (select PNNOTELN,CINOCSNO from 
(select PNNOTELN,CINOCSNO,row_number()over(partition by CINOCSNO order by BUTSSTAM desc) rn 
from ODS_CORE${version_num}.ODS_CORE_BCFMCPNI_TF P9
where P9.PNTYTLTP='6' AND P9.RCSTRS1B<>'9' AND P9.DEL_F='0'
and pt_dt='${process_date}'
)a where rn=1
) AS P9 -- 联系方式
       ON P8.CINOCSNO = P9.CINOCSNO  
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_TERROR_LIST_TF AS P10 -- 涉恐名单信息表
       ON CAST(CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)),'') END AS STRING)=P10.CRTF_TYP
 AND P1.BUSINESS_LICENSE=P10.CRTF_NO  
AND P10.DELETED='0' 
AND P10.DEL_F='0'
AND P10.CUST_STUS='1' 
AND P10.PT_DT='${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQGU_TF AS P11 -- 恐怖活动客户名单登记簿
       ON CAST(CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)),'') END AS STRING) = P11.GU01CFTP
AND P1.BUSINESS_LICENSE = P11.GU02CFNO 
AND P11.GU05RS1B <>'9' 
AND P11.GU04FLAG='1' 
AND P11.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P12 -- 码值表
       ON CAST(P1.MERCHANT_STATUS AS STRING)=P12.SRC_CD_VAL  
AND P12.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P12.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P12.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND P12.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P12.TARGET_FIELD_EN_NAME='SAM_OPER_APP_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P13 -- 码值表
       ON CAST(P1.MERCHANT_STATUS AS STRING)=P13.SRC_CD_VAL  
AND P13.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P13.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P13.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND P13.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' ---目标表名 大写
AND P13.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_STATUS_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P14 -- 码值表
       ON cast(P1.PROCESS_STATUS as string)=P14.SRC_CD_VAL  
AND P14.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P14.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P14.SRC_FIELD_EN_NAME='PROCESS_STATUS' --来源字段英文名 大写
AND P14.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' ---目标表名 大写
AND P14.TARGET_FIELD_EN_NAME='SAM_AUDIT_STAT_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P15 -- 码值表
       ON CAST(P1.MERCHANT_TYPE AS STRING)=P15.SRC_CD_VAL  
AND P15.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P15.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P15.SRC_FIELD_EN_NAME='MERCHANT_TYPE' --来源字段英文名 大写
AND P15.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' ---目标表名 大写
AND P15.TARGET_FIELD_EN_NAME='PREFR_DERATE_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P16 -- 码值表
       ON CAST(P1.SETTLEMENT_PERIOD AS STRING)=P16.SRC_CD_VAL  
AND P16.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P16.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P16.SRC_FIELD_EN_NAME='SETTLEMENT_PERIOD' --来源字段英文名 大写
AND P16.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' ---目标表名 大写
AND P16.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' 
WHERE P1.PT_DT='${process_date}'
AND P1.DEL_F = '0'
AND NOT EXISTS (SELECT '1' FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM TM WHERE P1.MERCHANT_NO=TM.SPC_ARGMT_MERCHT_NO AND TM.SRC_SYS_CD='MCSP')
;
-- ==============聚合层字段映射（第3组）==============
-- 收单特约商户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     trim(P1.MERNBR) AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P2.MERNAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,CASE WHEN P2.MERTYPE  IS NULL OR TRIM(P2.MERTYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(P15.TARGET_CD_VAL), '@'||TRIM(P2.MERTYPE),'') 
END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS WX_MERCHT_NO -- 微信商户编号
    ,'' AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,P2.COMPANYNAME AS MERCHT_NAME -- 商户名称
    ,P21.STL_ACCT_CUST_IN_CD AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,p5.CINOCSNO AS LP_CUST_IN_CD -- 法人客户内码
    ,P3.CINOCSNO AS CORP_CUST_IN_CD -- 企业客户内码
    ,P21.STL_ACCT_CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P2.CORPORATIONIDTYP AS DOCTYP_CD -- 证件类型代码
    ,P2.CORPORATIONIDNBR AS DOC_NO -- 证件号码
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.ISDTDATE) END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.EXDTDATE) END AS DOC_MATU_DT -- 证件到期日期
    ,P2.MERREGAMT AS REG_CAP -- 注册资金
    ,P7.ADARRGNM AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,P7.ADI1ADDR AS REG_ADDR -- 注册地址
    ,P8.CC01CFTP AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P8.CC01CFNO AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,unifiedTime(P3.ISDTDATE) AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,unifiedTime(P3.EXDTDATE) AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P8.CC01FLNM AS LP_PRINC_NAME -- 法人负责人名称
    ,P9.PNNOTELN AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,unifiedTime1(P3.BUTSSTAM) AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,unifiedTime1(P3.UPTSSTAM) AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,'' AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,'' AS ASSIS_DOC_NO -- 辅助证件号码
    ,'' AS ASSIS_DOC_NAME -- 辅助证件名称
    ,P2.LINKMANNAME AS CONT_NAME -- 联系人名称
    ,P2.LINKMANPHONE AS CONT_TEL_NO -- 联系人电话号码
    ,P2.LINKMANEMAIL AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,P2.MERSHORTNAME AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,'' AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,substr(trim(p1.MERCATCODE),1,4) AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,'' AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,'' AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,'' AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'' AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,'' AS INDUS_NAME -- 行业名称
    ,'' AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,'' AS WX_CORP_STL_CD -- 微信对公结算代码
    ,'' AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,P2.SITENAME    AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,P2.DOMAIN      AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,P2.SITECODE    AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,null AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,P2.SERVICEPHONE AS CUST_SERV_TEL_NO -- 客服电话号码
    ,'' AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,'' AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,'' AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,'' AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,'' AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,P2.MERADDR AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,'' AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,'' AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,'' AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,'' AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,'' AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,CASE WHEN P2.MERDVLPVTYPE  IS NULL OR TRIM(P2.MERDVLPVTYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(P16.TARGET_CD_VAL), '@'||TRIM(P2.MERDVLPVTYPE),'') 
END AS EXPAND_MODE_CD -- 拓展方式代码
    ,CASE WHEN SUBSTR(P1.MERDEVELOPDEPTNBR,1,3)=SUBSTR(NVL(P21.OWONBRNO,P21.AA47BRNO),1,3) 
THEN NVL(TRIM(P21.OWONBRNO),TRIM(P21.AA47BRNO)) 
ELSE P1.MERDEVELOPDEPTNBR END AS BELONG_ORG_NO -- 归属机构编号
    ,'' AS MKTING_TELR_NO -- 营销柜员编号
    ,'' AS MKTING_TELR_NAME -- 营销柜员名称
    ,'' AS MATN_TELR_NO -- 维护柜员编号
    ,'' AS MATN_TELR_NAME -- 维护柜员名称
    ,'' AS SERV_PROVDER_CD -- 服务商编码
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,P2.MEROPLICS AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,'' AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,null AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,null AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,'' AS STL_MODE_CD -- 结算方式代码
    ,'' AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,'' AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,P1.SETTLEACCTTYP AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,P1.SETTLEACCTNBR AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.SETTLEACCTNAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,CASE WHEN P1.SETTLEACCTKIND   IS NULL OR TRIM(P1.SETTLEACCTKIND)='' 
     THEN '' 
ELSE COALESCE(TRIM(P17.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEACCTKIND),'') 
END
 AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,'' AS ARBSA_NO -- 实际收单结算账户编号
    ,'' AS ARBSA_NAME -- 实际收单结算账户名称
    ,'' AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,'' AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,'' AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,'' AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,'' AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,CASE WHEN P1.FEEACCTTYP  IS NULL OR TRIM(P1.FEEACCTTYP)='' 
     THEN '' 
ELSE COALESCE(TRIM(P18.TARGET_CD_VAL), '@'||TRIM(P1.FEEACCTTYP),'') 
END
 AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,P1.FEEACCTNBR AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,P1.FEEACCTNAME AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,'' AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,CASE WHEN P1.SETTPERIOD IS NULL OR TRIM(P1.SETTPERIOD)='' 
     THEN '' 
ELSE COALESCE(TRIM(P19.TARGET_CD_VAL), '@'||TRIM(P1.SETTPERIOD),'') 
END AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN P1.SETTMODE IS NULL OR TRIM(P1.SETTMODE)='' 
     THEN '' 
ELSE COALESCE(TRIM(P20.TARGET_CD_VAL), '@'||TRIM(P1.SETTMODE),'') 
END AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,P1.FEESETTPERIOD AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,'' AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,CASE WHEN P1.REFUNDACCTTYP  IS NULL OR TRIM(P1.REFUNDACCTTYP )='' 
     THEN '' 
ELSE COALESCE(TRIM(P24.TARGET_CD_VAL), '@'||TRIM(P1.REFUNDACCTTYP ),'') 
END AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,P1.REFUNDACCTNBR AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,P1.REFUNDACCTNAME AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,'' AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,'' AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,'' AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,'' AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,'' AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,'' AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN SUBSTR(P3.CINOCSNO,1,2)='81' AND COALESCE(P10.CRTF_TYP,'')<>'' AND COALESCE(P10.CRTF_NO,'')<>''  THEN '1'
     WHEN SUBSTR(P3.CINOCSNO,1,2)='82' AND COALESCE(P11.GU01CFTP,'')<>'' AND COALESCE(P11.GU02CFNO,'')<>''  THEN '1'
ELSE '0'
END AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,'' AS CO_MODE_CD -- 合作模式代码
    ,'' AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,'' AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,'' AS PRFT_CUT_FLAG -- 分润标志
    ,'' AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,'' AS POS_MERCHT_FLAG -- POS商户标志
    ,'' AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,CASE WHEN P1.MERSTATUS  IS NULL OR TRIM(P1.MERSTATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P23.TARGET_CD_VAL), '@'||TRIM(P1.MERSTATUS),'') 
END AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,'' AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,'' AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,'' AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,'' AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,unifiedTime(P1.MEROPENDATE) AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,substr(P1.MEROPENDATE,1,10) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P1.MERCLOSEDATE) AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,substr(P1.MERCLOSEDATE,1,10) AS CANC_ACCT_DT -- 销户日期
    ,'' AS AUDIT_NO -- 审核编号
    ,NULL AS AUDIT_TM_STAMP -- 审核时间戳
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,'' AS AUDIT_FAIL_RSN -- 审核失败原因
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,P1.MEROPENDEPTNBR AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,NULL AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.MODIFYUSERNBR AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.MERMODIFYDATE AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,NULL AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,NULL AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,NULL AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'EPAY' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_EPAY_MERACCTINFO_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_EPAY${version_num}.ODS_EPAY_MERACCTINFO_TF AS P1 -- 商户账务信息

LEFT JOIN ODS_EPAY${version_num}.ODS_EPAY_MERBASEINFO_TF AS P2 -- 商户基本信息
       ON P1.MERNBR=P2.MERNBR AND P2.DEL_F ='0' AND P2.PT_DT='${process_date}'
 
LEFT JOIN (SELECT 
  P1.MERNBR
 ,P4.OWONBRNO
 ,P3.AA47BRNO
 ,TRIM(COALESCE(P3.AA03CSNO,P4.CINOCSNO))  AS STL_ACCT_CUST_IN_CD
FROM ODS_EPAY${version_num}.ODS_EPAY_MERBASEINFO_TF P1
LEFT JOIN ODS_EPAY${version_num}.ODS_EPAY_MERACCTINFO_TF P2
       ON TRIM(P1.MERNBR) = TRIM(P2.MERNBR) AND P2.PT_DT = '${process_date}' AND P2.DEL_F ='0'
LEFT JOIN (
  SELECT
   D2.AA01AC15 
  ,D2.AA03CSNO
  ,D2.AA47BRNO
  FROM ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF D2
  WHERE D2.PT_DT = '${process_date}' AND D2.DEL_F = '0'
   ) P3
ON SUBSTR(TRIM(P2.SETTLEACCTNBR),1,15)=SUBSTR(P3.AA01AC15,1,15) 
LEFT JOIN 
  (SELECT
   D3.CDNOAC19 
  ,D3.CINOCSNO
  ,D3.OWONBRNO
  FROM  ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF D3
  WHERE D3.PT_DT = '${process_date}' AND D3.DEL_F = '0'
   ) P4 
ON TRIM(P2.SETTLEACCTNBR)=P4.CDNOAC19 
WHERE   P1.PT_DT = '${process_date}' AND P1.DEL_F ='0'
) AS P21 -- 结算账户客户内码
       ON TRIM(P1.MERNBR)=TRIM(P21.MERNBR) 
LEFT JOIN (SELECT 
  P1.MERNBR
 ,P1.CORPORATIONPAPERTYP 
 ,P1.CORPORATIONPAPERNBR
 ,P3.IDNOCFNO
 ,P3.IDTYCFTP
 ,TRIM(P3.CINOCSNO)  AS CINOCSNO
FROM ODS_EPAY${version_num}.ODS_EPAY_MERBASEINFO_TF P1
LEFT JOIN ODS_EPAY${version_num}.ODS_EPAY_MERACCTINFO_TF P2
       ON TRIM(P1.MERNBR) = TRIM(P2.MERNBR) AND P2.PT_DT = '${process_date}' AND P2.DEL_F ='0'
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01 P3
       ON P3.IDNOCFNO<>'000000000000000000'
      AND TRIM(P1.CORPORATIONPAPERNBR)=TRIM(P3.IDNOCFNO) --法人证件号码
      AND TRIM(P1.CORPORATIONPAPERTYP)=TRIM(P3.IDTYCFTP) --证件类型 
WHERE TRIM(P1.CORPORATIONPAPERNBR) <> '' AND TRIM(P1.CORPORATIONPAPERTYP) <> ''
  AND TRIM(P1.CORPORATIONPAPERNBR) IS NOT NULL AND TRIM(P1.CORPORATIONPAPERTYP) IS NOT NULL
  AND P2.MERSTATUS  = '0' AND P1.PT_DT = '${process_date}' AND P1.DEL_F ='0'
) AS P5 -- 证件信息
       ON TRIM(P1.MERNBR)=TRIM(P5.MERNBR) 
LEFT JOIN (SELECT * FROM (
SELECT 
  P1.MERNBR
 ,P3.IDNOCFNO
 ,P3.IDTYCFTP
 ,P3.ISDTDATE
 ,P3.EXDTDATE
 ,P3.BUTSSTAM
 ,P3.UPTSSTAM
 ,P3.MIFLBOOL
 ,TRIM(P3.CINOCSNO)  AS CINOCSNO
 ,ROW_NUMBER()OVER(PARTITION BY P1.MERNBR ORDER BY P3.CINOCSNO DESC) RN 
FROM ODS_EPAY${version_num}.ODS_EPAY_MERBASEINFO_TF P1
LEFT JOIN ODS_EPAY${version_num}.ODS_EPAY_MERACCTINFO_TF P2
       ON TRIM(P1.MERNBR) = TRIM(P2.MERNBR) AND P2.MERSTATUS='0' AND P2.PT_DT = '${process_date}' AND P2.DEL_F ='0'
LEFT JOIN (SELECT 
              IDNOCFNO
             ,IDTYCFTP
             ,CINOCSNO
             ,ISDTDATE
             ,EXDTDATE
             ,BUTSSTAM
             ,UPTSSTAM
             ,MIFLBOOL
          FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01 
          WHERE IDNOCFNO<>'000000000000000000'
    ) P3
      ON TRIM(P1.BUSINESSLICENSEID) =TRIM(P3.IDNOCFNO) --法人证件号码
     AND LENGTH(TRIM(P1.BUSINESSLICENSEID)) IN (15,18)  --证件类型 
WHERE   P1.PT_DT = '${process_date}' AND P1.DEL_F ='0' AND P2.MERSTATUS  = '0' AND TRIM(P1.BUSINESSLICENSEID)  <> ''
) WHERE RN = 1) AS P3 -- 客户证件信息表（柜面核心)
       ON TRIM(P1.MERNBR)=TRIM(P3.MERNBR) 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 AS P7 -- 客户地址信息表
       ON P3.CINOCSNO= P7.CINOCSNO 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BCFMCCBA_TF AS P8 -- 对公主要责任人信息
       ON P3.CINOCSNO = P8.CINOCSNO AND P8.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01 AS P9 -- 联系方式
       ON P8.CC01CSNO=P9.CINOCSNO 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_TERROR_LIST_TF AS P10 -- 涉恐名单信息表
       ON P2.CORPORATIONIDTYP = P10.CRTF_TYP 
AND P2.CORPORATIONIDNBR =P10.CRTF_NO 
AND P10.DELETED='0' 
AND P10.CUST_STUS='1'
AND P10.PT_DT='${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQGU_TF AS P11 -- 恐怖活动客户名单登记簿
       ON P2.CORPORATIONIDTYP = P11.GU01CFTP 
AND P2.CORPORATIONIDNBR = P11.GU02CFNO 
AND P11.GU05RS1B <>'9' 
AND P11.GU04FLAG='1' 
AND P11.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P15 -- 码值表
       ON P2.MERTYPE=P15.SRC_CD_VAL  
AND P15.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P15.SRC_TAB_EN_NAME='MERBASEINFO' --来源表英文名 大写
AND P15.SRC_FIELD_EN_NAME='MERTYPE' --来源字段英文名 大写
AND P15.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P15.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P16 -- 码值表
       ON P2.MERDVLPVTYPE=P16.SRC_CD_VAL  
AND P16.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P16.SRC_TAB_EN_NAME='MERBASEINFO' --来源表英文名 大写
AND P16.SRC_FIELD_EN_NAME='MERDVLPVTYPE' --来源字段英文名 大写
AND P16.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P16.TARGET_FIELD_EN_NAME='EXPAND_MODE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P17 -- 码值表
       ON P1.SETTLEACCTKIND=P17.SRC_CD_VAL  
AND P17.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P17.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P17.SRC_FIELD_EN_NAME='SETTLEACCTKIND' --来源字段英文名 大写
AND P17.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P17.TARGET_FIELD_EN_NAME='RECV_BIL_STL_ACCT_CATEGORY_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P18 -- 码值表
       ON P1.FEEACCTTYP=P18.SRC_CD_VAL  
AND P18.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P18.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P18.SRC_FIELD_EN_NAME='FEEACCTTYP' --来源字段英文名 大写
AND P18.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P18.TARGET_FIELD_EN_NAME='COMM_FEE_EXPNT_ACCT_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P19 -- 码值表
       ON P1.SETTPERIOD=P19.SRC_CD_VAL  
AND P19.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P19.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P19.SRC_FIELD_EN_NAME='SETTPERIOD' --来源字段英文名 大写
AND P19.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P19.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P20 -- 码值表
       ON P1.SETTMODE=P20.SRC_CD_VAL  
AND P20.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P20.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P20.SRC_FIELD_EN_NAME='SETTMODE' --来源字段英文名 大写
AND P20.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P20.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_MODE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P24 -- 码值表
       ON P1.REFUNDACCTTYP=P24.SRC_CD_VAL  
AND P24.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P24.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P24.SRC_FIELD_EN_NAME='SETTMODE' --来源字段英文名 大写
AND P24.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P24.TARGET_FIELD_EN_NAME='REFUND_EXPNT_ACCT_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P23 -- 码值表
       ON P1.MERSTATUS=P23.SRC_CD_VAL  
AND P23.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P23.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P23.SRC_FIELD_EN_NAME='MERSTATUS' --来源字段英文名 大写
AND P23.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P23.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_STATUS_CD' 
WHERE P1.PT_DT='${process_date}'
AND P1.DEL_F = '0'
AND P1.ISPARENTMER='0' and p1.MERSTATUS='0'
AND NOT EXISTS (SELECT '1' FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM TM WHERE P1.MERNBR=TM.SPC_ARGMT_MERCHT_NO AND TM.SRC_SYS_CD IN ('MCSP','POSP'))
;
-- ==============聚合层字段映射（第4-3组）==============
-- 收单特约商户信息聚合
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_05;

CREATE TABLE AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_05 (
     MERCHANT_ID STRING COMMENT '特约商户编号'
    ,MERCHANT_NAME STRING COMMENT '特约商户名称'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,RECV_BIL_STL_ACCT_NO STRING COMMENT '收单结算账户编号'
    ,RECV_BIL_STL_ACCT_NAME STRING COMMENT '收单结算账户名称'
    ,CREATE_TM STRING COMMENT '创建时间'
    ,FINAL_UPDATE_TM STRING COMMENT '最后修改时间'
    ,STL_ACCT_CUST_IN_CD STRING COMMENT '结算账户客户内码'
    ,LP_CUST_IN_CD STRING COMMENT '法人客户内码'
    ,CORP_CUST_IN_CD STRING COMMENT '企业客户内码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,DOCTYP_CD STRING COMMENT '证件类型代码'
    ,DOC_NO STRING COMMENT '证件号码'
    ,DOC_ISSUE_DT STRING COMMENT '证件签发日期'
    ,DOC_MATU_DT STRING COMMENT '证件到期日期'
    ,ISDTDATE STRING COMMENT '法人负责人证件签发日期'
    ,EXDTDATE STRING COMMENT '法人负责人证件到期日期'
    ,LP_DOC_INFO_SETUP_TM_STAMP STRING COMMENT '法人证件信息建立时间戳'
    ,LP_DOC_INFO_MODIF_TM_STAMP STRING COMMENT '法人证件信息修改时间戳'
    ,CRTF_TYP STRING COMMENT '证件类型'
    ,CRTF_NO STRING COMMENT '证件号码'
    ,IDTYCFTP STRING COMMENT '证件种类'
    ,IDNOCFNO STRING COMMENT '证件号码'
    ,SETTLEMENT_PATTERN STRING COMMENT '结算模式'
    ,MERCHANT_STATUS STRING COMMENT '商户状态'
    ,LP_PRINC_TEL_NO STRING COMMENT '法人负责人电话号码'
    ,merch_catgory_code STRING COMMENT '特约商户类别代码'
    ,WX_MERCHT_NO STRING COMMENT '微信商户编号'
    ,ZFB_MERCHT_NO STRING COMMENT '支付宝商户编号'
    ,UNPY_MERCHT_NO STRING COMMENT '银联商户编号'
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD STRING COMMENT '特约商户场景大类代码'
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD STRING COMMENT '特约商户场景小类代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '收单特约商户信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_05(
     MERCHANT_ID -- 特约商户编号
    ,MERCHANT_NAME -- 特约商户名称
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,CREATE_TM -- 创建时间
    ,FINAL_UPDATE_TM -- 最后修改时间
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,ISDTDATE -- 法人负责人证件签发日期
    ,EXDTDATE -- 法人负责人证件到期日期
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,CRTF_TYP -- 证件类型
    ,CRTF_NO -- 证件号码
    ,IDTYCFTP -- 证件种类
    ,IDNOCFNO -- 证件号码
    ,SETTLEMENT_PATTERN -- 结算模式
    ,MERCHANT_STATUS -- 商户状态
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,merch_catgory_code -- 特约商户类别代码
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.MERCHANT_ID AS MERCHANT_ID -- 特约商户编号
    ,P1.MERCHANT_NAME AS MERCHANT_NAME -- 特约商户名称
    ,P1.COMPANY_ID AS BELONG_ORG_NO -- 归属机构编号
    ,P1.MERCHANT_ACCOUNT_NUMBER AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.ACCOUNT_NAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,P1.CREATE_DATETIME AS CREATE_TM -- 创建时间
    ,P1.MODIFY_DATETIME AS FINAL_UPDATE_TM -- 最后修改时间
    ,COALESCE(P21.AA03CSNO,P31.cinocsno) AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,'' AS LP_CUST_IN_CD -- 法人客户内码
    ,'' AS CORP_CUST_IN_CD -- 企业客户内码
    ,COALESCE(P21.AA03CSNO,P31.cinocsno) AS CUST_IN_CD -- 客户内码
    ,CASE WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='82' THEN P3.IDTYCFTP
          WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='81' THEN P2.CRTF_TYP
END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='82' THEN P3.IDNOCFNO
          WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='81' THEN P2.CRTF_NO
END AS DOC_NO -- 证件号码
    ,CASE WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='82' THEN unifiedTime(P3.ISDTDATE)
          WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='81' THEN unifiedTime(CAST(P2.CRTF_EFCTV_DT AS VARCHAR(10)) )
END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='82' THEN unifiedTime(P3.EXDTDATE)
          WHEN SUBSTR(COALESCE(P21.AA03CSNO,P31.cinocsno),1,2)='81' THEN  unifiedTime(CAST(P2.CRTF_DUE_DT AS VARCHAR(10)))
END AS DOC_MATU_DT -- 证件到期日期
    ,unifiedTime(P5.ISDTDATE) AS ISDTDATE -- 法人负责人证件签发日期
    ,unifiedTime(P5.EXDTDATE) AS EXDTDATE -- 法人负责人证件到期日期
    ,unifiedTime1(P5.BUTSSTAM) AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,unifiedTime1(P5.UPTSSTAM) AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,P2.CRTF_TYP AS CRTF_TYP -- 证件类型
    ,P2.CRTF_NO AS CRTF_NO -- 证件号码
    ,P3.IDTYCFTP AS IDTYCFTP -- 证件种类
    ,P3.IDNOCFNO AS IDNOCFNO -- 证件号码
    ,P1.SETTLEMENT_PATTERN AS SETTLEMENT_PATTERN -- 结算模式
    ,P1.MERCHANT_STATUS AS MERCHANT_STATUS -- 商户状态
    ,P12.PNNOTELN AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,P1.merch_catgory_code AS merch_catgory_code -- 特约商户类别代码
    ,'' AS WX_MERCHT_NO -- 微信商户编号
    ,'' AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,'' AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,'' AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_SPS${version_num}.ODS_SPS_SP_SHARED_MERCHANT_TF AS P1 -- 商户信息表

LEFT JOIN (
select
 D2.aa01ac15 
, D2.AA03CSNO
from
 ods_core${version_num}.ODS_CORE_BDFMHQAA_TF D2
where
 D2.pt_dt = '${process_date}'
 and D2.DEL_F = '0'
 ) AS P21 -- None
       ON substr(P1.merchant_account_number,1,15)=substr(P21.aa01ac15,1,15)  
LEFT JOIN (
select
 D3.cdnoac19 
, D3.cinocsno
from
 ods_core${version_num}.ODS_CORE_BWFMDCIM_TF D3
where
 D3.pt_dt = '${process_date}'
 and D3.DEL_F = '0'
 ) AS P31 -- 借记卡信息主档文件
       ON trim(P1.merchant_account_number)=P31.cdnoac19  
LEFT JOIN (select 
ID
,CST_IN_CD
,CRTF_TYP
,CRTF_NM
,CRTF_NO
,CRTF_ADM_DV_CD
,CRTF_ADDR
,ISSU_CRTF_RGN
,ISU_INST
,CRTF_EFCTV_DT
,CRTF_DUE_DT
,ANL_EXPR_DT
,ANL_SITN
,MAJOR_FLG
,NW_CHK_SITN
,ISSU_TMS
,CURRENT_NO
,USER_CRTF_FLG
,RESERVE1
,RESERVE2
,RESERVE3
,DELETED
,USER_CREATE
,GMT_CREATE
,ORG_CREATE
,SYS_CREATE
,CHNL_CREATE
,USER_MODIFIED
,GMT_MODIFIED
,ORG_MODIFIED
,SYS_MODIFIED
,CHNL_MODIFIED
,LAST_ETL_ACG_DT
,DEL_F
,PT_DT
from 
(select 
 ID
,CST_IN_CD
,CRTF_TYP
,CRTF_NM
,CRTF_NO
,CRTF_ADM_DV_CD
,CRTF_ADDR
,ISSU_CRTF_RGN
,ISU_INST
,CRTF_EFCTV_DT
,CRTF_DUE_DT
,ANL_EXPR_DT
,ANL_SITN
,MAJOR_FLG
,NW_CHK_SITN
,ISSU_TMS
,CURRENT_NO
,USER_CRTF_FLG
,RESERVE1
,RESERVE2
,RESERVE3
,DELETED
,USER_CREATE
,GMT_CREATE
,ORG_CREATE
,SYS_CREATE
,CHNL_CREATE
,USER_MODIFIED
,GMT_MODIFIED
,ORG_MODIFIED
,SYS_MODIFIED
,CHNL_MODIFIED
,LAST_ETL_ACG_DT
,DEL_F
,PT_DT
,row_number()over(partition by CST_IN_CD order by GMT_CREATE desc)  RN
from ods_eicc${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF
where pt_dt ='${process_date}' and DEL_F='0' and deleted ='0'
) A where RN=1) AS P2 -- 对私商户客户证件信息
       ON COALESCE(P21.AA03CSNO,P31.cinocsno) =P2.CST_IN_CD 
LEFT JOIN (SELECT * FROM (
 SELECT
  IDNOCFNO
 ,IDTYCFTP
 ,CINOCSNO
 ,ISDTDATE
 ,EXDTDATE
 ,MIFLBOOL
 ,BUTSSTAM
 ,UPTSSTAM
 ,ROW_NUMBER()OVER(PARTITION BY CINOCSNO ORDER BY BUTSSTAM DESC) RN  
FROM ODS_CORE${version_num}.ODS_CORE_BCFMCIDI_TF 
WHERE RCSTRS1B<> '9' AND DEL_F = '0' AND PT_DT ='${process_date}'
)WHERE RN = 1) AS P3 -- 对公商户证件信息
       ON COALESCE(P21.AA03CSNO,P31.cinocsno)=P3.CINOCSNO  
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BCFMCCBA_TF AS P4 -- 对公主要责任人信息
       ON COALESCE(P21.AA03CSNO,P31.cinocsno) =P4.CINOCSNO 
AND P4.DEL_F='0' 
AND P4.PT_DT='${process_date}' 
LEFT JOIN (SELECT * FROM (
 SELECT
  IDNOCFNO
 ,IDTYCFTP
 ,CINOCSNO
 ,ISDTDATE
 ,EXDTDATE
 ,MIFLBOOL
 ,BUTSSTAM
 ,UPTSSTAM
 ,ROW_NUMBER()OVER(PARTITION BY CINOCSNO ORDER BY BUTSSTAM DESC) RN  
FROM ODS_CORE${version_num}.ODS_CORE_BCFMCIDI_TF 
WHERE RCSTRS1B<> '9' AND DEL_F = '0' AND PT_DT ='${process_date}'
)WHERE RN = 1) AS P5 -- 证件信息
       ON P4.CC01CSNO=P5.CINOCSNO 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01 AS P12 -- 联系方式
       ON P4.CC01CSNO= P12.CINOCSNO  
WHERE P1.PT_DT= '${process_date}'
AND P1.DEL_F = '0'
and p1.MERCHANT_ID <> '92953993475010M'
AND NOT EXISTS (SELECT '1' FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM TM WHERE P1.MERCHANT_ID=TM.SPC_ARGMT_MERCHT_NO AND TM.SRC_SYS_CD IN ('MCSP','POSP','EPAY'))
;
-- ==============聚合层字段映射（第4-4组）==============
-- 收单特约商户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.MERCHANT_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCHANT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'5' AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS WX_MERCHT_NO -- 微信商户编号
    ,'' AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,P1.STL_ACCT_CUST_IN_CD AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,P1.LP_CUST_IN_CD AS LP_CUST_IN_CD -- 法人客户内码
    ,P1.CORP_CUST_IN_CD AS CORP_CUST_IN_CD -- 企业客户内码
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.DOC_ISSUE_DT AS DOC_ISSUE_DT -- 证件签发日期
    ,P1.DOC_MATU_DT AS DOC_MATU_DT -- 证件到期日期
    ,'' AS REG_CAP -- 注册资金
    ,P8.ADARRGNM AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,P8.ADI1ADDR AS REG_ADDR -- 注册地址
    ,P10.CC01CFTP AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P10.CC01CFNO AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,P1.ISDTDATE AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,P1.EXDTDATE AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P10.CC01FLNM AS LP_PRINC_NAME -- 法人负责人名称
    ,P1.LP_PRINC_TEL_NO AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,P1.LP_DOC_INFO_SETUP_TM_STAMP AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,P1.LP_DOC_INFO_MODIF_TM_STAMP AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,'' AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,'' AS ASSIS_DOC_NO -- 辅助证件号码
    ,'' AS ASSIS_DOC_NAME -- 辅助证件名称
    ,'' AS CONT_NAME -- 联系人名称
    ,'' AS CONT_TEL_NO -- 联系人电话号码
    ,'' AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,'' AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,'' AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,P1.merch_catgory_code AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,'' AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,'' AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,'' AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'' AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,'' AS INDUS_NAME -- 行业名称
    ,'' AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,'' AS WX_CORP_STL_CD -- 微信对公结算代码
    ,'' AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,'' AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,'' AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,'' AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,null AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,'' AS CUST_SERV_TEL_NO -- 客服电话号码
    ,'' AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,'' AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,'' AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,'' AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,'' AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,'' AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,'' AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,'' AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,'' AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,'' AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,'' AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,'' AS EXPAND_MODE_CD -- 拓展方式代码
    ,p1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,'' AS MKTING_TELR_NO -- 营销柜员编号
    ,'' AS MKTING_TELR_NAME -- 营销柜员名称
    ,'' AS MATN_TELR_NO -- 维护柜员编号
    ,'' AS MATN_TELR_NAME -- 维护柜员名称
    ,'' AS SERV_PROVDER_CD -- 服务商编码
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,'' AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,null AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,null AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,'' AS STL_MODE_CD -- 结算方式代码
    ,'' AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,'' AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,'' AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,p1.RECV_BIL_STL_ACCT_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,p1.RECV_BIL_STL_ACCT_NAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,'' AS ARBSA_NO -- 实际收单结算账户编号
    ,'' AS ARBSA_NAME -- 实际收单结算账户名称
    ,'' AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,'' AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,'' AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,'' AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,'' AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,'' AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,'' AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,'' AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,CASE WHEN P1.SETTLEMENT_PATTERN IS NULL OR TRIM(P1.SETTLEMENT_PATTERN)='' 
     THEN '' 
ELSE COALESCE(TRIM(P16.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEMENT_PATTERN),'') 
END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,'' AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,'' AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,'' AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,'' AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,'' AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,'' AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,'' AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,'' AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,'' AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,'' AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN SUBSTR(P1.CUST_IN_CD,1,2)='81' AND COALESCE(P14.CRTF_TYP,'')<>'' AND COALESCE(P14.CRTF_NO,'')<>''  THEN '1'
     WHEN SUBSTR(P1.CUST_IN_CD,1,2)='82' AND COALESCE(P15.GU01CFTP,'')<>'' AND COALESCE(P15.GU02CFNO,'')<>''  THEN '1'
ELSE '0'
END AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,'' AS CO_MODE_CD -- 合作模式代码
    ,'' AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,'' AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,'' AS PRFT_CUT_FLAG -- 分润标志
    ,'' AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,'' AS POS_MERCHT_FLAG -- POS商户标志
    ,'' AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,CASE WHEN P1.MERCHANT_STATUS IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P17.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') 
END AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,'' AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,'' AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,'' AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,'' AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,unifiedTime(P1.CREATE_TM) AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,substr(P1.CREATE_TM,1,10) AS OPEN_ACCT_DT -- 开户日期
    ,'' AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,'' AS CANC_ACCT_DT -- 销户日期
    ,'' AS AUDIT_NO -- 审核编号
    ,NULL AS AUDIT_TM_STAMP -- 审核时间戳
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,'' AS AUDIT_FAIL_RSN -- 审核失败原因
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,unifiedTime(P1.CREATE_TM) AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(P1.FINAL_UPDATE_TM) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间
    ,'' AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,NULL AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,NULL AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,NULL AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SPS_SP_SHARED_MERCHANT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_05 AS P1 -- None

LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 AS P8 -- 客户地址信息表
       ON P1. CUST_IN_CD = P8.CINOCSNO 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BCFMCCBA_TF AS P10 -- 对公主要责任人信息
       ON P1. CUST_IN_CD = P10.CINOCSNO
 AND P10.DEL_F='0' 
AND P10.PT_DT='${process_date}' 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_TERROR_LIST_TF AS P14 -- 涉恐名单信息表
       ON P1.DOCTYP_CD = P14.CRTF_TYP 
and P1.DOC_NO= P14.CRTF_NO 
 AND P14.CUST_STUS='1' 
AND P14.DELETED='0'  
AND P14.PT_DT='${process_date}' 
AND P14.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQGU_TF AS P15 -- 恐怖活动客户名单登记簿
       ON P1.DOCTYP_CD  =P15.GU01CFTP 
and  P1.DOC_NO = P15.GU02CFNO  
AND P15.GU05RS1B <>'9'  
AND P15.GU04FLAG='1'  
AND P15.DEL_F='0' 
AND P15.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P16 -- 码值表
       ON P1.SETTLEMENT_PATTERN=P16.SRC_CD_VAL  
AND P16.SRC_TAB_LIB_NAME ='SPS'  --源系统 简称或中文名 待定
AND P16.SRC_TAB_EN_NAME='SP_SHARED_MERCHANT' --来源表英文名 大写
AND P16.SRC_FIELD_EN_NAME='SETTLEMENT_PATTERN' --来源字段英文名 大写
AND P16.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND P16.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P17 -- 码值表
       ON P1.MERCHANT_STATUS=P17.SRC_CD_VAL  
AND P17.SRC_TAB_LIB_NAME ='SPS'  --源系统 简称或中文名 待定
AND P17.SRC_TAB_EN_NAME='SP_SHARED_MERCHANT' --来源表英文名 大写
AND P17.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND P17.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF'-- 目标表名 大写
AND P17.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_STATUS_CD' 
;
-- ==============聚合层字段映射（第5组）==============
-- 收单特约商户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     trim(P1.MERCHANT_NO) AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCHANT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,CASE WHEN P1.MERCHANT_SPECIES IS NULL OR TRIM(P1.MERCHANT_SPECIES)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_SPECIES),'') 
END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'1' AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS WX_MERCHT_NO -- 微信商户编号
    ,'' AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,TRIM(COALESCE(p21.AA03CSNO,p22.CINOCSNO)) AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,P5.CINOCSNO AS LP_CUST_IN_CD -- 法人客户内码
    ,p3.CINOCSNO AS CORP_CUST_IN_CD -- 企业客户内码
    ,TRIM(COALESCE(p21.AA03CSNO,p22.CINOCSNO)) AS CUST_IN_CD -- 客户内码
    ,CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_LICENSE_CERT_TYPE),'') 
END AS DOCTYP_CD -- 证件类型代码
    ,P1.BUSINESS_LICENSE AS DOC_NO -- 证件号码
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.ISDTDATE) END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.EXDTDATE) END AS DOC_MATU_DT -- 证件到期日期
    ,P1.REGISTERED_CAPITAL AS REG_CAP -- 注册资金
    ,p7.ADARRGNM AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,p7.ADI1ADDR AS REG_ADDR -- 注册地址
    ,P1.legal_person_cert_type_id AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P1.legal_person_certificate AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,unifiedTime(P5.ISDTDATE) AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,unifiedTime(P5.EXDTDATE) AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P1.legal_person_name AS LP_PRINC_NAME -- 法人负责人名称
    ,p9.PNNOTELN AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,unifiedTime1(P5.BUTSSTAM) AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,unifiedTime1(P5.UPTSSTAM) AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,'' AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,'' AS ASSIS_DOC_NO -- 辅助证件号码
    ,'' AS ASSIS_DOC_NAME -- 辅助证件名称
    ,P1.CONTACT AS CONT_NAME -- 联系人名称
    ,P1.CONTACT_MOBILE_PHONE AS CONT_TEL_NO -- 联系人电话号码
    ,'' AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,P1.MERCHANT_SHORT_NAME AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,'' AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SUBSTR(TRIM(p1.MCC),1,4) AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,'' AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,'' AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,'' AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'' AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,'' AS INDUS_NAME -- 行业名称
    ,'' AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,'' AS WX_CORP_STL_CD -- 微信对公结算代码
    ,'' AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,'' AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,'' AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,'' AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,NULL AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,'' AS CUST_SERV_TEL_NO -- 客服电话号码
    ,P1.BUSINESS_PROVINCE_CODE AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,P1.BUSINESS_CITY_CODE AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,P1.BUSINESS_DISTRICT_CODE AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,'' AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,'' AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,P1.BUSINESS_ADDRESS AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,'' AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,'' AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,CASE WHEN P1.MERCHANT_TYPE IS NULL OR TRIM(P1.MERCHANT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S7.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_TYPE),'') 
END AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,'1' AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,P1.RISK_LEVEL AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,P1.MERCHANT_EXTENSION_METHOD AS EXPAND_MODE_CD -- 拓展方式代码
    ,P6.CODE AS BELONG_ORG_NO -- 归属机构编号
    ,P1.MANAGER_NO AS MKTING_TELR_NO -- 营销柜员编号
    ,P1.MANAGER_NAME AS MKTING_TELR_NAME -- 营销柜员名称
    ,'' AS MATN_TELR_NO -- 维护柜员编号
    ,'' AS MATN_TELR_NAME -- 维护柜员名称
    ,'' AS SERV_PROVDER_CD -- 服务商编码
    ,P1.OUT_SERVICE_INST_NAME AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.OUT_SERVICE_INST_BUSINESS_LICENSE AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,'' AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,P1.TRANSFER_DAY_LIMITE AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,P1.TRANSFER_MONTH_LIMITE AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,'' AS STL_MODE_CD -- 结算方式代码
    ,'' AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,'' AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,CASE WHEN P1.ACCOUNT LIKE '201%' THEN '11' ELSE '21' END  AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,P1.ACCOUNT AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,P1.ACCOUNT_NAME AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'10' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,'' AS ARBSA_NO -- 实际收单结算账户编号
    ,'' AS ARBSA_NAME -- 实际收单结算账户名称
    ,'' AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,'' AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,'' AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,'' AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,'' AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,'' AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,'' AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,'' AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,CASE WHEN P1.SETTLEMENT_PERIOD IS NULL OR TRIM(P1.SETTLEMENT_PERIOD)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEMENT_PERIOD),'') 
END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,'' AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,'' AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,'' AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,'' AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,'' AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,'' AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,'' AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,'' AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,'' AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,'' AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN SUBSTR(coalesce(p3.CINOCSNO,p5.CINOCSNO),1,2)='81' AND COALESCE(P10.CRTF_TYP,'')<>'' AND COALESCE(P10.CRTF_NO,'')<>''  THEN '1'
     WHEN SUBSTR(coalesce(p3.CINOCSNO,p5.CINOCSNO),1,2)='82' AND COALESCE(K1.GU01CFTP,'')<>'' AND COALESCE(K1.GU02CFNO,'')<>''  THEN '1'
ELSE '0'
END AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,'' AS CO_MODE_CD -- 合作模式代码
    ,'' AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,'' AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,'' AS PRFT_CUT_FLAG -- 分润标志
    ,'' AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,'' AS POS_MERCHT_FLAG -- POS商户标志
    ,'' AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CASE WHEN P1.MERCHANT_STATUS IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(S4.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') 
END AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,CASE WHEN P1.MERCHANT_STATUS IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(S5.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') 
END AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,CASE WHEN P1.PROCESS_STATUS IS NULL OR TRIM(P1.PROCESS_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(S6.TARGET_CD_VAL), '@'||TRIM(P1.PROCESS_STATUS),'') 
END AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,'' AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,'' AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,'' AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,unifiedTime(P1.APPLY_TIME) AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,substr(P1.APPLY_TIME,1,10) AS OPEN_ACCT_DT -- 开户日期
    ,NULL AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,NULL AS CANC_ACCT_DT -- 销户日期
    ,'' AS AUDIT_NO -- 审核编号
    ,unifiedTime(P1.REVIEW_TIME) AS AUDIT_TM_STAMP -- 审核时间戳
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,'' AS AUDIT_FAIL_RSN -- 审核失败原因
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,NULL AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,NULL AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,NULL AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,unifiedTime(P1.FREEZE_TIME) AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,unifiedTime(P1.UNFREEZE_TIME) AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_ACPS_MGM_MERCHANT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_MERCHANT_TF AS P1 -- 商户账务信息

LEFT JOIN (SELECT MERCHANT_NO,MAX(BIND_ACCOUNT) AS BIND_ACCOUNT FROM ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_TERMINAL_INFO_TF WHERE PT_DT = '${process_date}' and del_f = '0' GROUP BY MERCHANT_NO) AS P11 -- None
       ON TRIM(P1.MERCHANT_NO)=TRIM(P11.MERCHANT_NO) 
LEFT JOIN (
select zhkhac19 
  ,stzhac15 
from ods_core${version_num}.ods_core_bffmdqbe_tf 
where pt_dt  = '${process_date}'
 and del_f  = '0'
 and rmk1rmrk  <> '0'
 and yxbzbool  <> '9'
) AS P12 -- 账户登记表
       ON TRIM(P11.BIND_ACCOUNT) =TRIM(P12.stzhac15) 
LEFT JOIN (
select
 D3.cdnoac19 
, D3.cinocsno
,d3.DFANAC19
from
 ods_core${version_num}.ODS_CORE_BWFMDCIM_TF D3
where
 D3.pt_dt = '${process_date}'
 and D3.DEL_F = '0'
 ) AS P13 -- 借记卡信息主档文件
       ON TRIM(P11.BIND_ACCOUNT)=P13.cdnoac19 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 码值表
       ON P1.BUSINESS_LICENSE_CERT_TYPE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S1.SRC_FIELD_EN_NAME='BUSINESS_LICENSE_CERT_TYPE' --来源字段英文名 大写
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S1.TARGET_FIELD_EN_NAME='DOCTYP_CD' 
LEFT JOIN (
select
 D2.aa01ac15 
,
 D2.AA03CSNO
from
 ods_core${version_num}.ODS_CORE_BDFMHQAA_TF D2
where
 D2.pt_dt = '${process_date}'
 and D2.DEL_F = '0'
 ) AS P21 -- 活期存款账户主档
       ON coalesce(substr(trim(P1.ACCOUNT),1,15),substr(trim(P11.BIND_ACCOUNT),1,15),substr(trim(P12.zhkhac19),1,15))=substr(P21.aa01ac15,1,15) 
LEFT JOIN (
select
 D3.cdnoac19 
, D3.cinocsno
from
 ods_core${version_num}.ODS_CORE_BWFMDCIM_TF D3
where
 D3.pt_dt = '${process_date}'
 and D3.DEL_F = '0'
 ) AS P22 -- 借记卡信息主档文件
       ON coalesce(trim(P1.ACCOUNT),trim(P11.BIND_ACCOUNT),trim(P12.zhkhac19))=P22.cdnoac19 
LEFT JOIN (SELECT 
 IDNOCFNO
,IDTYCFTP
,CINOCSNO
,ISDTDATE
,EXDTDATE
,MIFLBOOL
FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01) AS P3 -- 客户证件信息表（柜面核心)
       ON CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_LICENSE_CERT_TYPE),'') 
END = p3.IDTYCFTP
and p1.BUSINESS_LICENSE = p3.IDNOCFNO 
LEFT JOIN ODS_POSP${version_num}.ODS_POSP_CPAY_INSTITUTION_TF AS P6 -- 机构表
       ON P1.INST_ID=P6.ID
AND P6.PT_DT='${process_date}'
AND P6.DEL_F = '0' 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 AS P7 -- 客户地址信息表
       ON P3.CINOCSNO= P7.CINOCSNO 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01 AS P5 -- 证件信息
       ON TRIM(P1.legal_person_cert_type_id)= P5.IDTYCFTP
and TRIM(P1.legal_person_certificate) = p5.IDNOCFNO
and length(TRIM(P1.legal_person_certificate)) not in (15,18) 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01 AS P9 -- 联系方式
       ON P5.CINOCSNO =P9.CINOCSNO 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_TERROR_LIST_TF AS P10 -- 涉恐名单信息表
       ON CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_LICENSE_CERT_TYPE),'') 
END = P10.CRTF_TYP 
AND p1.BUSINESS_LICENSE  =P10.CRTF_NO 
AND P10.DELETED='0' 
AND P10.CUST_STUS='1'
AND P10.PT_DT='${process_date}'
AND P10.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQGU_TF AS K1 -- 恐怖活动客户名单登记簿
       ON CASE WHEN P1.BUSINESS_LICENSE_CERT_TYPE IS NULL OR TRIM(P1.BUSINESS_LICENSE_CERT_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_LICENSE_CERT_TYPE),'') 
END = K1.GU01CFTP 
AND p1.BUSINESS_LICENSE  = K1.GU02CFNO 
AND K1.GU05RS1B <>'9' 
AND K1.GU04FLAG='1' 
AND K1.PT_DT='${process_date}'
AND K1.DEL_F = '0' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 码值表
       ON P1.MERCHANT_SPECIES=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='MERCHANT_SPECIES' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S3 -- 码值表
       ON P1.SETTLEMENT_PERIOD=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S3.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S3.SRC_FIELD_EN_NAME='SETTLEMENT_PERIOD' --来源字段英文名 大写
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S3.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S4 -- 码值表
       ON P1.MERCHANT_STATUS=S4.SRC_CD_VAL  
AND S4.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S4.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S4.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND S4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S4.TARGET_FIELD_EN_NAME='SAM_OPER_APP_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S5 -- 码值表
       ON P1.MERCHANT_STATUS=S5.SRC_CD_VAL  
AND S5.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S5.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S5.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND S5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S5.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_STATUS_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S6 -- 码值表
       ON P1.PROCESS_STATUS=S6.SRC_CD_VAL  
AND S6.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S6.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S6.SRC_FIELD_EN_NAME='PROCESS_STATUS' --来源字段英文名 大写
AND S6.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S6.TARGET_FIELD_EN_NAME='SAM_AUDIT_STAT_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S7 -- 码值表
       ON P1.MERCHANT_TYPE=S7.SRC_CD_VAL  
AND S7.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S7.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND S7.SRC_FIELD_EN_NAME='MERCHANT_TYPE' --来源字段英文名 大写
AND S7.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S7.TARGET_FIELD_EN_NAME='PREFR_DERATE_TYPE_CD' 
WHERE P1.PT_DT = '${process_date}' and p1.del_f = '0'
and NOT EXISTS (SELECT '1' FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM TM WHERE P1.MERCHANT_NO=TM.SPC_ARGMT_MERCHT_NO AND TM.SRC_SYS_CD IN ('MCSP','POSP','EPAY','SPS'))
;
-- ==============聚合层字段映射（第6组）==============
-- 收单特约商户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM(
     SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,MERCHT_NO -- 商户编号
    ,WX_MERCHT_NO -- 微信商户编号
    ,ZFB_MERCHT_NO -- 支付宝商户编号
    ,UNPY_MERCHT_NO -- 银联商户编号
    ,MERCHT_NAME -- 商户名称
    ,STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,LP_CUST_IN_CD -- 法人客户内码
    ,CORP_CUST_IN_CD -- 企业客户内码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DOC_ISSUE_DT -- 证件签发日期
    ,DOC_MATU_DT -- 证件到期日期
    ,REG_CAP -- 注册资金
    ,REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,REG_ADDR -- 注册地址
    ,LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,LP_PRINC_NAME -- 法人负责人名称
    ,LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,ASSIS_DOC_NO -- 辅助证件号码
    ,ASSIS_DOC_NAME -- 辅助证件名称
    ,CONT_NAME -- 联系人名称
    ,CONT_TEL_NO -- 联系人电话号码
    ,CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,SAM_CATEGORY_DESC -- 特约商户类别描述
    ,SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,INDUS_CATEGORY_NAME -- 行业类别名称
    ,INDUS_NAME -- 行业名称
    ,ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,WX_CORP_STL_CD -- 微信对公结算代码
    ,HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CUST_SERV_TEL_NO -- 客服电话号码
    ,ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,TXN_CURR_CD -- 交易币种代码
    ,PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,EXPAND_MODE_CD -- 拓展方式代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,MATN_TELR_NO -- 维护柜员编号
    ,MATN_TELR_NAME -- 维护柜员名称
    ,SERV_PROVDER_CD -- 服务商编码
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,STL_MODE_CD -- 结算方式代码
    ,RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,ARBSA_NO -- 实际收单结算账户编号
    ,ARBSA_NAME -- 实际收单结算账户名称
    ,ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,REFUND_MODE_CD -- 退款模式代码
    ,REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,EXCESS_REFUND_FLAG -- 超额退款标志
    ,REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CO_MODE_CD -- 合作模式代码
    ,BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,PRFT_CUT_FLAG -- 分润标志
    ,INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,POS_MERCHT_FLAG -- POS商户标志
    ,POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,SUBMIT_APP_MODE_CD -- 进件方式代码
    ,SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CANC_ACCT_DT -- 销户日期
    ,AUDIT_NO -- 审核编号
    ,AUDIT_TM_STAMP -- 审核时间戳
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CANC_ACCT_RSN_CD -- 销户原因代码
    ,AUDIT_FAIL_RSN -- 审核失败原因
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,MIGRATE_TM_STAMP -- 迁移时间戳
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     trim(P1.MERID) AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P2.MER_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P2.MER_TYPE AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'1' AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,P1.MANYQR_ID AS MERCHT_NO -- 商户编号
    ,'' AS WX_MERCHT_NO -- 微信商户编号
    ,'' AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,'' AS UNPY_MERCHT_NO -- 银联商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,TRIM(COALESCE(p21.AA03CSNO,p22.CINOCSNO)) AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,TRIM(P5.CINOCSNO) AS LP_CUST_IN_CD -- 法人客户内码
    ,TRIM(P3.CINOCSNO) AS CORP_CUST_IN_CD -- 企业客户内码
    ,TRIM(COALESCE(p21.AA03CSNO,p22.CINOCSNO)) AS CUST_IN_CD -- 客户内码
    ,CASE WHEN P1.BUSINESS_CARD_TYPE IS NULL OR TRIM(P1.BUSINESS_CARD_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_CARD_TYPE),'') 
END AS DOCTYP_CD -- 证件类型代码
    ,P1.BUSINESS_CARD_NUM AS DOC_NO -- 证件号码
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.ISDTDATE) END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN P3.MIFLBOOL='1' THEN unifiedTime(P3.EXDTDATE) END AS DOC_MATU_DT -- 证件到期日期
    ,P1.REGISTERED_CAPITAL AS REG_CAP -- 注册资金
    ,p7.ADARRGNM AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,p7.ADI1ADDR AS REG_ADDR -- 注册地址
    ,P8.CC01CFTP AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,P8.CC01CFNO AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,unifiedTime(P5.ISDTDATE) AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,unifiedTime(P5.EXDTDATE) AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,P8.CC01FLNM AS LP_PRINC_NAME -- 法人负责人名称
    ,p9.PNNOTELN AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,unifiedTime1(P5.BUTSSTAM) AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,unifiedTime1(P5.UPTSSTAM) AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,'' AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,'' AS ASSIS_DOC_NO -- 辅助证件号码
    ,'' AS ASSIS_DOC_NAME -- 辅助证件名称
    ,P1.CONTACTNAME AS CONT_NAME -- 联系人名称
    ,P1.CONTACTPHONE AS CONT_TEL_NO -- 联系人电话号码
    ,P1.CONTACTEMAIL AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,'' AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,'' AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,substr(trim(P1.MCC),1,4) AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,'' AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,'' AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,'' AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,'' AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,'' AS INDUS_NAME -- 行业名称
    ,'' AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,'' AS WX_CORP_STL_CD -- 微信对公结算代码
    ,'' AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,'' AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,'' AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,'' AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,'' AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,'' AS CUST_SERV_TEL_NO -- 客服电话号码
    ,P1.PROVINCECODE AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,P1.CITYCODE AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,P1.DISTRICTCODE AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,P1.TOWNCODE AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,P1.VILLAGECODE AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,P1.ADDRESS AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,'' AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,'' AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,P2.CURRENCY_TYPE AS TXN_CURR_CD -- 交易币种代码
    ,'' AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,'1' AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,P1.RISK_LEVEL AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,P1.EXPAND_WAY AS EXPAND_MODE_CD -- 拓展方式代码
    ,P4.CODE AS BELONG_ORG_NO -- 归属机构编号
    ,P1.MANAGER_NO AS MKTING_TELR_NO -- 营销柜员编号
    ,P1.MANAGER_NAME AS MKTING_TELR_NAME -- 营销柜员名称
    ,'' AS MATN_TELR_NO -- 维护柜员编号
    ,'' AS MATN_TELR_NAME -- 维护柜员名称
    ,'' AS SERV_PROVDER_CD -- 服务商编码
    ,P1.OUTSOURCING_INSTITUTION_NAME AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.OUTSOURCING_BUSINESS_CARD_NUM AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,'' AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,NULL AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,NULL AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,'' AS STL_MODE_CD -- 结算方式代码
    ,'' AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,'' AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,CASE WHEN P2.ACCT_NO LIKE '201%' THEN '11' ELSE '21' END  AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,P2.ACCT_NO AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,'' AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,'10' AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,'' AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,'' AS ARBSA_NO -- 实际收单结算账户编号
    ,'' AS ARBSA_NAME -- 实际收单结算账户名称
    ,'' AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,'' AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,'' AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,'' AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,'' AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,'' AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,'' AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,'' AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,CASE WHEN P1.SETTLE_METHOD IS NULL OR TRIM(P1.SETTLE_METHOD)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_METHOD),'') 
END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,'' AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,'' AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,'' AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,'' AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,'' AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,'' AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,'' AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,'' AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,'' AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,'' AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN SUBSTR(coalesce(p3.CINOCSNO,p5.CINOCSNO),1,2)='81' AND COALESCE(P10.CRTF_TYP,'')<>'' AND COALESCE(P10.CRTF_NO,'')<>''  THEN '1'
     WHEN SUBSTR(coalesce(p3.CINOCSNO,p5.CINOCSNO),1,2)='82' AND COALESCE(P11.GU01CFTP,'')<>'' AND COALESCE(P11.GU02CFNO,'')<>''  THEN '1'
ELSE '0'
END AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,'1' AS CO_MODE_CD -- 合作模式代码
    ,'1' AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,'' AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,'' AS PRFT_CUT_FLAG -- 分润标志
    ,'' AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,'' AS POS_MERCHT_FLAG -- POS商户标志
    ,'' AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,CASE WHEN P2.EWM_STATUE IS NULL OR TRIM(P2.EWM_STATUE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), '@'||TRIM(P2.EWM_STATUE),'') 
END AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,CASE WHEN P1.FLOW_FLAG_ID IS NULL OR TRIM(P1.FLOW_FLAG_ID)='' 
     THEN '' 
ELSE COALESCE(TRIM(S4.TARGET_CD_VAL), '@'||TRIM(P1.FLOW_FLAG_ID),'') 
END AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,'' AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,'' AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,'' AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,unifiedTime(P2.CREATE_DT) AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,unifiedTime(substr(P2.CREATE_DT,1,8)) AS OPEN_ACCT_DT -- 开户日期
    ,NULL AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,NULL AS CANC_ACCT_DT -- 销户日期
    ,'' AS AUDIT_NO -- 审核编号
    ,unifiedTime(P1.REVIEW_TIME) AS AUDIT_TM_STAMP -- 审核时间戳
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,'' AS AUDIT_FAIL_RSN -- 审核失败原因
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,P2.ORG_CODE AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,unifiedTime(P1.CREATE_TIME) AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(P1.UPDATE_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户代码
    ,NULL AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,unifiedTime(P1.FREEZE_TIME) AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,unifiedTime(P1.UNFREEZE_TIME) AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_ACPS_MGM_ONLINEMANYQRCODE_INFO_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_ONLINEMANYQRCODE_INFO_TF AS P1 -- 一码通商户信息正式表

LEFT JOIN ODS_POSP${version_num}.ODS_POSP_TBL_STATIC_EWM_THREE_CODE_INFO_TF AS P2 -- 三码合一静态二维码表
       ON P1.MERID=P2.MER_ID AND P1.POS_FLAG_ID<>'2' AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN (
select
 D2.aa01ac15 
,
 D2.AA03CSNO
from
 ods_core${version_num}.ODS_CORE_BDFMHQAA_TF D2
where
 D2.pt_dt = '${process_date}'
 and D2.DEL_F = '0'
 ) AS P21 -- 活期存款账户主档
       ON substr(trim(P1.ACCTNO),1,15)=substr(P21.aa01ac15,1,15) 
LEFT JOIN (
select
 D3.cdnoac19 
, D3.cinocsno
from
 ods_core${version_num}.ODS_CORE_BWFMDCIM_TF D3
where
 D3.pt_dt = '${process_date}'
 and D3.DEL_F = '0'
 ) AS P22 -- 借记卡信息主档文件
       ON trim(P1.ACCTNO)=P22.cdnoac19 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 码值表
       ON P1.BUSINESS_CARD_TYPE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='ACPS_MGM_ONLINEMANYQRCODE_INFO' --来源表英文名 大写
AND S1.SRC_FIELD_EN_NAME='BUSINESS_CARD_TYPE' --来源字段英文名 大写
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S1.TARGET_FIELD_EN_NAME='DOCTYP_CD' 
LEFT JOIN (SELECT 
 IDNOCFNO
,IDTYCFTP
,CINOCSNO
,ISDTDATE
,EXDTDATE
,MIFLBOOL
FROM AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01
WHERE IDNOCFNO<>'000000000000000000' AND TRIM(RCSTRS1B)='') AS P3 -- 客户证件信息表（柜面核心)
       ON CASE WHEN P1.BUSINESS_CARD_TYPE IS NULL OR TRIM(P1.BUSINESS_CARD_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_CARD_TYPE),'') 
END = P3.IDTYCFTP
AND TRIM(P1.BUSINESS_CARD_NUM) = P3.IDNOCFNO 
LEFT JOIN ODS_POSP${version_num}.ODS_POSP_CPAY_INSTITUTION_TF AS P4 -- 机构表
       ON P1.ORG_ID=P4.ID AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01 AS P7 -- 客户地址信息表
       ON P3.CINOCSNO= P7.CINOCSNO 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BCFMCCBA_TF AS P8 -- 对公主要责任人信息
       ON P3.CINOCSNO = P8.CINOCSNO AND P8.PT_DT='${process_date}' AND P8.DEL_F = '0' 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01 AS P5 -- 证件信息
       ON P5.IDTYCFTP='101' and P1.IDCARDNUM = p5.IDNOCFNO 
LEFT JOIN AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01 AS P9 -- 联系方式
       ON P8.CC01CSNO=P9.CINOCSNO 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_TERROR_LIST_TF AS P10 -- 涉恐名单信息表
       ON CASE WHEN P1.BUSINESS_CARD_TYPE IS NULL OR TRIM(P1.BUSINESS_CARD_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_CARD_TYPE),'') 
END = P10.CRTF_TYP 
AND P1.BUSINESS_CARD_NUM =P10.CRTF_NO 
AND P10.DELETED='0' 
AND P10.CUST_STUS='1'
AND P10.PT_DT='${process_date}'
AND P10.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQGU_TF AS P11 -- 恐怖活动客户名单登记簿
       ON CASE WHEN P1.BUSINESS_CARD_TYPE IS NULL OR TRIM(P1.BUSINESS_CARD_TYPE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||TRIM(P1.BUSINESS_CARD_TYPE),'') 
END = P11.GU01CFTP 
AND P1.BUSINESS_CARD_NUM = P11.GU02CFNO 
AND P11.GU05RS1B <>'9' 
AND P11.GU04FLAG='1' 
AND P11.PT_DT='${process_date}'
AND P11.DEL_F = '0' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 码值表
       ON P2.EWM_STATUE=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='TBL_STATIC_EWM_THREE_CODE_INFO' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='EWM_STATUE' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_STATUS_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S3 -- 码值表
       ON P2.SETTLE_METHOD=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S3.SRC_TAB_EN_NAME='ACPS_MGM_ONLINEMANYQRCODE_INFO' --来源表英文名 大写
AND S3.SRC_FIELD_EN_NAME='SETTLE_METHOD' --来源字段英文名 大写
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S3.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S4 -- 码值表
       ON P1.FLOW_FLAG_ID=S4.SRC_CD_VAL  
AND S4.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S4.SRC_TAB_EN_NAME='ACPS_MGM_ONLINEMANYQRCODE_INFO' --来源表英文名 大写
AND S4.SRC_FIELD_EN_NAME='FLOW_FLAG_ID' --来源字段英文名 大写
AND S4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF' --目标表名 大写
AND S4.TARGET_FIELD_EN_NAME='SAM_AUDIT_STAT_CD' 
WHERE NOT EXISTS (SELECT '1' FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM TM WHERE P1.MERID=TM.SPC_ARGMT_MERCHT_NO AND TM.SRC_SYS_CD IN ('MCSP','POSP','EPAY','SPS')) AND P1.PT_DT = '${process_date}' and p1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_NO, BF.SPC_ARGMT_MERCHT_NO) END AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_NAME IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_NAME, BF.SPC_ARGMT_MERCHT_NAME) END AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD, BF.SPC_ARGMT_MERCHT_TYPE_CD) END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_ATTR_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_ATTR_CD, BF.SPC_ARGMT_MERCHT_ATTR_CD) END AS SPC_ARGMT_MERCHT_ATTR_CD -- 特约商户属性代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_NO, BF.MERCHT_NO) END AS MERCHT_NO -- 商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WX_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.WX_MERCHT_NO, BF.WX_MERCHT_NO) END AS WX_MERCHT_NO -- 微信商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ZFB_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.ZFB_MERCHT_NO, BF.ZFB_MERCHT_NO) END AS ZFB_MERCHT_NO -- 支付宝商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNPY_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.UNPY_MERCHT_NO, BF.UNPY_MERCHT_NO) END AS UNPY_MERCHT_NO -- 银联商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_NAME IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_NAME, BF.MERCHT_NAME) END AS MERCHT_NAME -- 商户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STL_ACCT_CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.STL_ACCT_CUST_IN_CD, BF.STL_ACCT_CUST_IN_CD) END AS STL_ACCT_CUST_IN_CD -- 结算账户客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.LP_CUST_IN_CD, BF.LP_CUST_IN_CD) END AS LP_CUST_IN_CD -- 法人客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CORP_CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CORP_CUST_IN_CD, BF.CORP_CUST_IN_CD) END AS CORP_CUST_IN_CD -- 企业客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DOCTYP_CD, BF.DOCTYP_CD) END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.DOC_NO, BF.DOC_NO) END AS DOC_NO -- 证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_ISSUE_DT IS NULL THEN NULL ELSE COALESCE(TM.DOC_ISSUE_DT, BF.DOC_ISSUE_DT) END AS DOC_ISSUE_DT -- 证件签发日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_MATU_DT IS NULL THEN NULL ELSE COALESCE(TM.DOC_MATU_DT, BF.DOC_MATU_DT) END AS DOC_MATU_DT -- 证件到期日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REG_CAP IS NULL THEN NULL ELSE COALESCE(TM.REG_CAP, BF.REG_CAP) END AS REG_CAP -- 注册资金
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REG_ADDR_DIST_CD IS NULL THEN NULL ELSE COALESCE(TM.REG_ADDR_DIST_CD, BF.REG_ADDR_DIST_CD) END AS REG_ADDR_DIST_CD -- 注册地址行政区划代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REG_ADDR IS NULL THEN NULL ELSE COALESCE(TM.REG_ADDR, BF.REG_ADDR) END AS REG_ADDR -- 注册地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_PRINC_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.LP_PRINC_DOCTYP_CD, BF.LP_PRINC_DOCTYP_CD) END AS LP_PRINC_DOCTYP_CD -- 法人负责人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_PRINC_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_PRINC_DOC_NO, BF.LP_PRINC_DOC_NO) END AS LP_PRINC_DOC_NO -- 法人负责人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_PRINC_DOC_ISSUE_DT IS NULL THEN NULL ELSE COALESCE(TM.LP_PRINC_DOC_ISSUE_DT, BF.LP_PRINC_DOC_ISSUE_DT) END AS LP_PRINC_DOC_ISSUE_DT -- 法人负责人证件签发日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_PRINC_DOC_MATU_DT IS NULL THEN NULL ELSE COALESCE(TM.LP_PRINC_DOC_MATU_DT, BF.LP_PRINC_DOC_MATU_DT) END AS LP_PRINC_DOC_MATU_DT -- 法人负责人证件到期日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_PRINC_NAME IS NULL THEN NULL ELSE COALESCE(TM.LP_PRINC_NAME, BF.LP_PRINC_NAME) END AS LP_PRINC_NAME -- 法人负责人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_PRINC_TEL_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_PRINC_TEL_NO, BF.LP_PRINC_TEL_NO) END AS LP_PRINC_TEL_NO -- 法人负责人电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_DOC_INFO_SETUP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.LP_DOC_INFO_SETUP_TM_STAMP, BF.LP_DOC_INFO_SETUP_TM_STAMP) END AS LP_DOC_INFO_SETUP_TM_STAMP -- 法人证件信息建立时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_DOC_INFO_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.LP_DOC_INFO_MODIF_TM_STAMP, BF.LP_DOC_INFO_MODIF_TM_STAMP) END AS LP_DOC_INFO_MODIF_TM_STAMP -- 法人证件信息修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ASSIS_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.ASSIS_DOCTYP_CD, BF.ASSIS_DOCTYP_CD) END AS ASSIS_DOCTYP_CD -- 辅助证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ASSIS_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.ASSIS_DOC_NO, BF.ASSIS_DOC_NO) END AS ASSIS_DOC_NO -- 辅助证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ASSIS_DOC_NAME IS NULL THEN NULL ELSE COALESCE(TM.ASSIS_DOC_NAME, BF.ASSIS_DOC_NAME) END AS ASSIS_DOC_NAME -- 辅助证件名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_NAME IS NULL THEN NULL ELSE COALESCE(TM.CONT_NAME, BF.CONT_NAME) END AS CONT_NAME -- 联系人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_TEL_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_TEL_NO, BF.CONT_TEL_NO) END AS CONT_TEL_NO -- 联系人电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_EMAIL_ADDR IS NULL THEN NULL ELSE COALESCE(TM.CONT_EMAIL_ADDR, BF.CONT_EMAIL_ADDR) END AS CONT_EMAIL_ADDR -- 联系人电子邮箱地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_NAME_ABB IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_NAME_ABB, BF.SPC_ARGMT_MERCHT_NAME_ABB) END AS SPC_ARGMT_MERCHT_NAME_ABB -- 特约商户名称简称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_EN_NAME, BF.SPC_ARGMT_MERCHT_EN_NAME) END AS SPC_ARGMT_MERCHT_EN_NAME -- 特约商户英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_CATEGORY_CD, BF.SPC_ARGMT_MERCHT_CATEGORY_CD) END AS SPC_ARGMT_MERCHT_CATEGORY_CD -- 特约商户类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SAM_CATEGORY_DESC IS NULL THEN NULL ELSE COALESCE(TM.SAM_CATEGORY_DESC, BF.SAM_CATEGORY_DESC) END AS SAM_CATEGORY_DESC -- 特约商户类别描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_SCENE_MCLS_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_MCLS_CD, BF.SPC_ARGMT_MERCHT_SCENE_MCLS_CD) END AS SPC_ARGMT_MERCHT_SCENE_MCLS_CD -- 特约商户场景大类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_SCENE_SCLS_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_SCLS_CD, BF.SPC_ARGMT_MERCHT_SCENE_SCLS_CD) END AS SPC_ARGMT_MERCHT_SCENE_SCLS_CD -- 特约商户场景小类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INDUS_CATEGORY_NAME IS NULL THEN NULL ELSE COALESCE(TM.INDUS_CATEGORY_NAME, BF.INDUS_CATEGORY_NAME) END AS INDUS_CATEGORY_NAME -- 行业类别名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INDUS_NAME IS NULL THEN NULL ELSE COALESCE(TM.INDUS_NAME, BF.INDUS_NAME) END AS INDUS_NAME -- 行业名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ZFB_OPER_CAT_CD IS NULL THEN NULL ELSE COALESCE(TM.ZFB_OPER_CAT_CD, BF.ZFB_OPER_CAT_CD) END AS ZFB_OPER_CAT_CD -- 支付宝经营类目代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WX_CORP_STL_CD IS NULL THEN NULL ELSE COALESCE(TM.WX_CORP_STL_CD, BF.WX_CORP_STL_CD) END AS WX_CORP_STL_CD -- 微信对公结算代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.HELP_FMR_POINT_STAR_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.HELP_FMR_POINT_STAR_LVL_CD, BF.HELP_FMR_POINT_STAR_LVL_CD) END AS HELP_FMR_POINT_STAR_LVL_CD -- 助农点星级代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WEB_MERCHT_REG_URL IS NULL THEN NULL ELSE COALESCE(TM.WEB_MERCHT_REG_URL, BF.WEB_MERCHT_REG_URL) END AS WEB_MERCHT_REG_URL -- 网络商户登记网址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WEB_MERCHT_REG_IP_ADDR IS NULL THEN NULL ELSE COALESCE(TM.WEB_MERCHT_REG_IP_ADDR, BF.WEB_MERCHT_REG_IP_ADDR) END AS WEB_MERCHT_REG_IP_ADDR -- 网络商户登记IP地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WEB_MERCHT_IC_REC_LIC_NO IS NULL THEN NULL ELSE COALESCE(TM.WEB_MERCHT_IC_REC_LIC_NO, BF.WEB_MERCHT_IC_REC_LIC_NO) END AS WEB_MERCHT_IC_REC_LIC_NO -- 网络商户ICP备案/许可证号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.WX_COST_SERV_CHARGE_RATE IS NULL THEN NULL ELSE COALESCE(TM.WX_COST_SERV_CHARGE_RATE, BF.WX_COST_SERV_CHARGE_RATE) END AS WX_COST_SERV_CHARGE_RATE -- 微信成本费率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_SERV_TEL_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_SERV_TEL_NO, BF.CUST_SERV_TEL_NO) END AS CUST_SERV_TEL_NO -- 客服电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_OPER_ADDR_LOCAL_PROV_CD IS NULL THEN NULL ELSE COALESCE(TM.ACTL_OPER_ADDR_LOCAL_PROV_CD, BF.ACTL_OPER_ADDR_LOCAL_PROV_CD) END AS ACTL_OPER_ADDR_LOCAL_PROV_CD -- 实际经营地址所在省份代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_OPER_ADDR_LOCAL_CITY_CD IS NULL THEN NULL ELSE COALESCE(TM.ACTL_OPER_ADDR_LOCAL_CITY_CD, BF.ACTL_OPER_ADDR_LOCAL_CITY_CD) END AS ACTL_OPER_ADDR_LOCAL_CITY_CD -- 实际经营地址所在市代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_OPER_ADDR_LOCAL_DIST_CD IS NULL THEN NULL ELSE COALESCE(TM.ACTL_OPER_ADDR_LOCAL_DIST_CD, BF.ACTL_OPER_ADDR_LOCAL_DIST_CD) END AS ACTL_OPER_ADDR_LOCAL_DIST_CD -- 实际经营地址所在区县代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AOA_LOCAL_TOWN_STREET_CD IS NULL THEN NULL ELSE COALESCE(TM.AOA_LOCAL_TOWN_STREET_CD, BF.AOA_LOCAL_TOWN_STREET_CD) END AS AOA_LOCAL_TOWN_STREET_CD -- 实际经营地址所在镇街道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AOA_LOCAL_VILG_COMM_CD IS NULL THEN NULL ELSE COALESCE(TM.AOA_LOCAL_VILG_COMM_CD, BF.AOA_LOCAL_VILG_COMM_CD) END AS AOA_LOCAL_VILG_COMM_CD -- 实际经营地址所在村社区代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_OPER_ADDR_DESC IS NULL THEN NULL ELSE COALESCE(TM.ACTL_OPER_ADDR_DESC, BF.ACTL_OPER_ADDR_DESC) END AS ACTL_OPER_ADDR_DESC -- 实际经营地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_OPER_ADDR_LATD IS NULL THEN NULL ELSE COALESCE(TM.ACTL_OPER_ADDR_LATD, BF.ACTL_OPER_ADDR_LATD) END AS ACTL_OPER_ADDR_LATD -- 实际经营地址纬度
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_OPER_ADDR_LGTD IS NULL THEN NULL ELSE COALESCE(TM.ACTL_OPER_ADDR_LGTD, BF.ACTL_OPER_ADDR_LGTD) END AS ACTL_OPER_ADDR_LGTD -- 实际经营地址经度
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CURR_CD, BF.TXN_CURR_CD) END AS TXN_CURR_CD -- 交易币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PREFR_DERATE_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.PREFR_DERATE_TYPE_CD, BF.PREFR_DERATE_TYPE_CD) END AS PREFR_DERATE_TYPE_CD -- 优惠减免类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SMALL_MICRO_MERCHT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SMALL_MICRO_MERCHT_TYPE_CD, BF.SMALL_MICRO_MERCHT_TYPE_CD) END AS SMALL_MICRO_MERCHT_TYPE_CD -- 小微商户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RISK_ESTIM_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.RISK_ESTIM_LVL_CD, BF.RISK_ESTIM_LVL_CD) END AS RISK_ESTIM_LVL_CD -- 风险评估等级代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EXPAND_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.EXPAND_MODE_CD, BF.EXPAND_MODE_CD) END AS EXPAND_MODE_CD -- 拓展方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MKTING_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.MKTING_TELR_NO, BF.MKTING_TELR_NO) END AS MKTING_TELR_NO -- 营销柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MKTING_TELR_NAME IS NULL THEN NULL ELSE COALESCE(TM.MKTING_TELR_NAME, BF.MKTING_TELR_NAME) END AS MKTING_TELR_NAME -- 营销柜员名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MATN_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.MATN_TELR_NO, BF.MATN_TELR_NO) END AS MATN_TELR_NO -- 维护柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MATN_TELR_NAME IS NULL THEN NULL ELSE COALESCE(TM.MATN_TELR_NAME, BF.MATN_TELR_NAME) END AS MATN_TELR_NAME -- 维护柜员名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_CD IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_CD, BF.SERV_PROVDER_CD) END AS SERV_PROVDER_CD -- 服务商编码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_NAME IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_NAME, BF.SERV_PROVDER_NAME) END AS SERV_PROVDER_NAME -- 服务商名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_DOC_NO, BF.SERV_PROVDER_DOC_NO) END AS SERV_PROVDER_DOC_NO -- 服务商证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_TYPE_CD, BF.SERV_PROVDER_TYPE_CD) END AS SERV_PROVDER_TYPE_CD -- 服务商类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DAILY_ACCUM_TRAN_LMT IS NULL THEN NULL ELSE COALESCE(TM.DAILY_ACCUM_TRAN_LMT, BF.DAILY_ACCUM_TRAN_LMT) END AS DAILY_ACCUM_TRAN_LMT -- 日累计转账限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MONTHLY_ACCUM_TRAN_LMT IS NULL THEN NULL ELSE COALESCE(TM.MONTHLY_ACCUM_TRAN_LMT, BF.MONTHLY_ACCUM_TRAN_LMT) END AS MONTHLY_ACCUM_TRAN_LMT -- 月累计转账限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STL_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.STL_MODE_CD, BF.STL_MODE_CD) END AS STL_MODE_CD -- 结算方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RBSA_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RBSA_OPEN_ACCT_ORG_NO, BF.RBSA_OPEN_ACCT_ORG_NO) END AS RBSA_OPEN_ACCT_ORG_NO -- 收单结算账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RBSA_OPEN_ACCT_ORG_NAME IS NULL THEN NULL ELSE COALESCE(TM.RBSA_OPEN_ACCT_ORG_NAME, BF.RBSA_OPEN_ACCT_ORG_NAME) END AS RBSA_OPEN_ACCT_ORG_NAME -- 收单结算账号开户机构名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_STL_ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_STL_ACCT_TYPE_CD, BF.RECV_BIL_STL_ACCT_TYPE_CD) END AS RECV_BIL_STL_ACCT_TYPE_CD -- 收单结算账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_STL_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_STL_ACCT_NO, BF.RECV_BIL_STL_ACCT_NO) END AS RECV_BIL_STL_ACCT_NO -- 收单结算账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_STL_ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_STL_ACCT_NAME, BF.RECV_BIL_STL_ACCT_NAME) END AS RECV_BIL_STL_ACCT_NAME -- 收单结算账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_STL_ACCT_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_STL_ACCT_CATEGORY_CD, BF.RECV_BIL_STL_ACCT_CATEGORY_CD) END AS RECV_BIL_STL_ACCT_CATEGORY_CD -- 收单结算账户类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_STL_ACCT_OPBANK_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NO, BF.RECV_BIL_STL_ACCT_OPBANK_NO) END AS RECV_BIL_STL_ACCT_OPBANK_NO -- 收单结算账户开户行行号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_STL_ACCT_OPBANK_NAME IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NAME, BF.RECV_BIL_STL_ACCT_OPBANK_NAME) END AS RECV_BIL_STL_ACCT_OPBANK_NAME -- 收单结算账户开户行名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ARBSA_NO IS NULL THEN NULL ELSE COALESCE(TM.ARBSA_NO, BF.ARBSA_NO) END AS ARBSA_NO -- 实际收单结算账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ARBSA_NAME IS NULL THEN NULL ELSE COALESCE(TM.ARBSA_NAME, BF.ARBSA_NAME) END AS ARBSA_NAME -- 实际收单结算账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ARBSA_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NO, BF.ARBSA_OPEN_ACCT_ORG_NO) END AS ARBSA_OPEN_ACCT_ORG_NO -- 实际收单结算账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ARBSA_OPEN_ACCT_ORG_NAME IS NULL THEN NULL ELSE COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NAME, BF.ARBSA_OPEN_ACCT_ORG_NAME) END AS ARBSA_OPEN_ACCT_ORG_NAME -- 实际收单结算账户开户机构名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ARBSA_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ARBSA_TYPE_CD, BF.ARBSA_TYPE_CD) END AS ARBSA_TYPE_CD -- 实际收单结算账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ARBSA_OPBANK_CNAPS_CODE IS NULL THEN NULL ELSE COALESCE(TM.ARBSA_OPBANK_CNAPS_CODE, BF.ARBSA_OPBANK_CNAPS_CODE) END AS ARBSA_OPBANK_CNAPS_CODE -- 实际收单结算账户开户行人行支付行号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CFEA_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CFEA_OPEN_ACCT_ORG_NO, BF.CFEA_OPEN_ACCT_ORG_NO) END AS CFEA_OPEN_ACCT_ORG_NO -- 手续费支出账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMM_FEE_EXPNT_ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.COMM_FEE_EXPNT_ACCT_TYPE_CD, BF.COMM_FEE_EXPNT_ACCT_TYPE_CD) END AS COMM_FEE_EXPNT_ACCT_TYPE_CD -- 手续费支出账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMM_FEE_EXPNT_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.COMM_FEE_EXPNT_ACCT_NO, BF.COMM_FEE_EXPNT_ACCT_NO) END AS COMM_FEE_EXPNT_ACCT_NO -- 手续费支出账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMM_FEE_EXPNT_ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.COMM_FEE_EXPNT_ACCT_NAME, BF.COMM_FEE_EXPNT_ACCT_NAME) END AS COMM_FEE_EXPNT_ACCT_NAME -- 手续费支出账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_CAP_STL_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD, BF.RECV_BIL_CAP_STL_PERIOD_CD) END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_CAP_STL_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD, BF.RECV_BIL_CAP_STL_MODE_CD) END AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMM_FEE_STL_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.COMM_FEE_STL_PERIOD_CD, BF.COMM_FEE_STL_PERIOD_CD) END AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_GOOD_CFM_FLAG IS NULL THEN NULL ELSE COALESCE(TM.RECV_GOOD_CFM_FLAG, BF.RECV_GOOD_CFM_FLAG) END AS RECV_GOOD_CFM_FLAG -- 收货确认标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.REFUND_MODE_CD, BF.REFUND_MODE_CD) END AS REFUND_MODE_CD -- 退款模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_EACCT_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.REFUND_EACCT_OPEN_ACCT_ORG_NO, BF.REFUND_EACCT_OPEN_ACCT_ORG_NO) END AS REFUND_EACCT_OPEN_ACCT_ORG_NO -- 退款支出账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_EXPNT_ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.REFUND_EXPNT_ACCT_TYPE_CD, BF.REFUND_EXPNT_ACCT_TYPE_CD) END AS REFUND_EXPNT_ACCT_TYPE_CD -- 退款支出账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_EXPNT_ACCT_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.REFUND_EXPNT_ACCT_ACCT_NO, BF.REFUND_EXPNT_ACCT_ACCT_NO) END AS REFUND_EXPNT_ACCT_ACCT_NO -- 退款支出账户账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_EXPNT_ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.REFUND_EXPNT_ACCT_NAME, BF.REFUND_EXPNT_ACCT_NAME) END AS REFUND_EXPNT_ACCT_NAME -- 退款支出账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EXCESS_REFUND_FLAG IS NULL THEN NULL ELSE COALESCE(TM.EXCESS_REFUND_FLAG, BF.EXCESS_REFUND_FLAG) END AS EXCESS_REFUND_FLAG -- 超额退款标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_MRGACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.REFUND_MRGACCT_TYPE_CD, BF.REFUND_MRGACCT_TYPE_CD) END AS REFUND_MRGACCT_TYPE_CD -- 退款保证金账户类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_MRGACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.REFUND_MRGACCT_NO, BF.REFUND_MRGACCT_NO) END AS REFUND_MRGACCT_NO -- 退款保证金账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_MRGACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.REFUND_MRGACCT_NAME, BF.REFUND_MRGACCT_NAME) END AS REFUND_MRGACCT_NAME -- 退款保证金账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RMACT_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RMACT_OPEN_ACCT_ORG_NO, BF.RMACT_OPEN_ACCT_ORG_NO) END AS RMACT_OPEN_ACCT_ORG_NO -- 退款保证金账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RMACT_OPEN_ACCT_ORG_NAME IS NULL THEN NULL ELSE COALESCE(TM.RMACT_OPEN_ACCT_ORG_NAME, BF.RMACT_OPEN_ACCT_ORG_NAME) END AS RMACT_OPEN_ACCT_ORG_NAME -- 退款保证金账户开户机构名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_MRG_ACCT_NO_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.REFUND_MRG_ACCT_NO_TYPE_CD, BF.REFUND_MRG_ACCT_NO_TYPE_CD) END AS REFUND_MRG_ACCT_NO_TYPE_CD -- 退款保证金账号类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TERROR_ACT_LIST_FLAG IS NULL THEN NULL ELSE COALESCE(TM.TERROR_ACT_LIST_FLAG, BF.TERROR_ACT_LIST_FLAG) END AS TERROR_ACT_LIST_FLAG -- 恐怖活动名单标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CO_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.CO_MODE_CD, BF.CO_MODE_CD) END AS CO_MODE_CD -- 合作模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_PROD_PRVLG_CD IS NULL THEN NULL ELSE COALESCE(TM.BIZ_PROD_PRVLG_CD, BF.BIZ_PROD_PRVLG_CD) END AS BIZ_PROD_PRVLG_CD -- 业务产品权限代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ESCR_MERCHT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ESCR_MERCHT_FLAG, BF.ESCR_MERCHT_FLAG) END AS ESCR_MERCHT_FLAG -- 特殊费率商户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRFT_CUT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.PRFT_CUT_FLAG, BF.PRFT_CUT_FLAG) END AS PRFT_CUT_FLAG -- 分润标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INSTALLMENT_MERCHT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.INSTALLMENT_MERCHT_FLAG, BF.INSTALLMENT_MERCHT_FLAG) END AS INSTALLMENT_MERCHT_FLAG -- 分期商户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POS_MERCHT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.POS_MERCHT_FLAG, BF.POS_MERCHT_FLAG) END AS POS_MERCHT_FLAG -- POS商户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POS_MIGRATE_MERCHT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.POS_MIGRATE_MERCHT_FLAG, BF.POS_MIGRATE_MERCHT_FLAG) END AS POS_MIGRATE_MERCHT_FLAG -- POS迁移商户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.IN_BANK_SCENE_PLAT_CD IS NULL THEN NULL ELSE COALESCE(TM.IN_BANK_SCENE_PLAT_CD, BF.IN_BANK_SCENE_PLAT_CD) END AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SAM_OPER_APP_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SAM_OPER_APP_TYPE_CD, BF.SAM_OPER_APP_TYPE_CD) END AS SAM_OPER_APP_TYPE_CD -- 特约商户操作申请类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_STATUS_CD, BF.SPC_ARGMT_MERCHT_STATUS_CD) END AS SPC_ARGMT_MERCHT_STATUS_CD -- 特约商户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SAM_AUDIT_STAT_CD IS NULL THEN NULL ELSE COALESCE(TM.SAM_AUDIT_STAT_CD, BF.SAM_AUDIT_STAT_CD) END AS SAM_AUDIT_STAT_CD -- 特约商户审核状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUBMIT_APP_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.SUBMIT_APP_MODE_CD, BF.SUBMIT_APP_MODE_CD) END AS SUBMIT_APP_MODE_CD -- 进件方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUBMIT_APP_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SUBMIT_APP_TYPE_CD, BF.SUBMIT_APP_TYPE_CD) END AS SUBMIT_APP_TYPE_CD -- 进件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRE_COL_INFO_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.PRE_COL_INFO_SER_NO, BF.PRE_COL_INFO_SER_NO) END AS PRE_COL_INFO_SER_NO -- 预采集信息流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_TM_STAMP, BF.OPEN_ACCT_TM_STAMP) END AS OPEN_ACCT_TM_STAMP -- 开户时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DT, BF.OPEN_ACCT_DT) END AS OPEN_ACCT_DT -- 开户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_TM_STAMP, BF.CANC_ACCT_TM_STAMP) END AS CANC_ACCT_TM_STAMP -- 销户时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_DT, BF.CANC_ACCT_DT) END AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUDIT_NO IS NULL THEN NULL ELSE COALESCE(TM.AUDIT_NO, BF.AUDIT_NO) END AS AUDIT_NO -- 审核编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUDIT_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.AUDIT_TM_STAMP, BF.AUDIT_TM_STAMP) END AS AUDIT_TM_STAMP -- 审核时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_FRZ_RSN_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD, BF.RECV_BIL_PROD_FRZ_RSN_CD) END AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_RSN_CD IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_RSN_CD, BF.CANC_ACCT_RSN_CD) END AS CANC_ACCT_RSN_CD -- 销户原因代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUDIT_FAIL_RSN IS NULL THEN NULL ELSE COALESCE(TM.AUDIT_FAIL_RSN, BF.AUDIT_FAIL_RSN) END AS AUDIT_FAIL_RSN -- 审核失败原因
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_TELR_NO, BF.INPUT_TELR_NO) END AS INPUT_TELR_NO -- 录入柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_ORG_NO, BF.INPUT_ORG_NO) END AS INPUT_ORG_NO -- 录入机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_MODIF_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RECNT_MODIF_ORG_NO, BF.RECNT_MODIF_ORG_NO) END AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TM_STAMP, BF.SETUP_TM_STAMP) END AS SETUP_TM_STAMP -- 建立时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_TM_STAMP, BF.FINAL_UPDATE_TM_STAMP) END AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MIGRATE_MERCHT_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.MIGRATE_MERCHT_IDNT_CD, BF.MIGRATE_MERCHT_IDNT_CD) END AS MIGRATE_MERCHT_IDNT_CD -- 迁移商户标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MIGRATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.MIGRATE_TM_STAMP, BF.MIGRATE_TM_STAMP) END AS MIGRATE_TM_STAMP -- 迁移时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_RSN_REM IS NULL THEN NULL ELSE COALESCE(TM.FRZ_RSN_REM, BF.FRZ_RSN_REM) END AS FRZ_RSN_REM -- 冻结原因备注
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_FRZ_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.RECNT_FRZ_TM_STAMP, BF.RECNT_FRZ_TM_STAMP) END AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_UNFRZ_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.RECNT_UNFRZ_TM_STAMP, BF.RECNT_UNFRZ_TM_STAMP) END AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_ATTR_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_ATTR_CD,'') -- 特约商户属性代码 非主键字段相等
         AND COALESCE(TM.MERCHT_NO,'') = COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段相等
         AND COALESCE(TM.WX_MERCHT_NO,'') = COALESCE(BF.WX_MERCHT_NO,'') -- 微信商户编号 非主键字段相等
         AND COALESCE(TM.ZFB_MERCHT_NO,'') = COALESCE(BF.ZFB_MERCHT_NO,'') -- 支付宝商户编号 非主键字段相等
         AND COALESCE(TM.UNPY_MERCHT_NO,'') = COALESCE(BF.UNPY_MERCHT_NO,'') -- 银联商户编号 非主键字段相等
         AND COALESCE(TM.MERCHT_NAME,'') = COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段相等
         AND COALESCE(TM.STL_ACCT_CUST_IN_CD,'') = COALESCE(BF.STL_ACCT_CUST_IN_CD,'') -- 结算账户客户内码 非主键字段相等
         AND COALESCE(TM.LP_CUST_IN_CD,'') = COALESCE(BF.LP_CUST_IN_CD,'') -- 法人客户内码 非主键字段相等
         AND COALESCE(TM.CORP_CUST_IN_CD,'') = COALESCE(BF.CORP_CUST_IN_CD,'') -- 企业客户内码 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.DOC_ISSUE_DT,'') = COALESCE(BF.DOC_ISSUE_DT,'') -- 证件签发日期 非主键字段相等
         AND COALESCE(TM.DOC_MATU_DT,'') = COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段相等
         AND COALESCE(TM.REG_CAP,'') = COALESCE(BF.REG_CAP,'') -- 注册资金 非主键字段相等
         AND COALESCE(TM.REG_ADDR_DIST_CD,'') = COALESCE(BF.REG_ADDR_DIST_CD,'') -- 注册地址行政区划代码 非主键字段相等
         AND COALESCE(TM.REG_ADDR,'') = COALESCE(BF.REG_ADDR,'') -- 注册地址 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOCTYP_CD,'') = COALESCE(BF.LP_PRINC_DOCTYP_CD,'') -- 法人负责人证件类型代码 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOC_NO,'') = COALESCE(BF.LP_PRINC_DOC_NO,'') -- 法人负责人证件号码 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOC_ISSUE_DT,'') = COALESCE(BF.LP_PRINC_DOC_ISSUE_DT,'') -- 法人负责人证件签发日期 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOC_MATU_DT,'') = COALESCE(BF.LP_PRINC_DOC_MATU_DT,'') -- 法人负责人证件到期日期 非主键字段相等
         AND COALESCE(TM.LP_PRINC_NAME,'') = COALESCE(BF.LP_PRINC_NAME,'') -- 法人负责人名称 非主键字段相等
         AND COALESCE(TM.LP_PRINC_TEL_NO,'') = COALESCE(BF.LP_PRINC_TEL_NO,'') -- 法人负责人电话号码 非主键字段相等
         AND COALESCE(TM.LP_DOC_INFO_SETUP_TM_STAMP,'') = COALESCE(BF.LP_DOC_INFO_SETUP_TM_STAMP,'') -- 法人证件信息建立时间戳 非主键字段相等
         AND COALESCE(TM.LP_DOC_INFO_MODIF_TM_STAMP,'') = COALESCE(BF.LP_DOC_INFO_MODIF_TM_STAMP,'') -- 法人证件信息修改时间戳 非主键字段相等
         AND COALESCE(TM.ASSIS_DOCTYP_CD,'') = COALESCE(BF.ASSIS_DOCTYP_CD,'') -- 辅助证件类型代码 非主键字段相等
         AND COALESCE(TM.ASSIS_DOC_NO,'') = COALESCE(BF.ASSIS_DOC_NO,'') -- 辅助证件号码 非主键字段相等
         AND COALESCE(TM.ASSIS_DOC_NAME,'') = COALESCE(BF.ASSIS_DOC_NAME,'') -- 辅助证件名称 非主键字段相等
         AND COALESCE(TM.CONT_NAME,'') = COALESCE(BF.CONT_NAME,'') -- 联系人名称 非主键字段相等
         AND COALESCE(TM.CONT_TEL_NO,'') = COALESCE(BF.CONT_TEL_NO,'') -- 联系人电话号码 非主键字段相等
         AND COALESCE(TM.CONT_EMAIL_ADDR,'') = COALESCE(BF.CONT_EMAIL_ADDR,'') -- 联系人电子邮箱地址 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NAME_ABB,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME_ABB,'') -- 特约商户名称简称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_EN_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_EN_NAME,'') -- 特约商户英文名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_CATEGORY_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_CATEGORY_CD,'') -- 特约商户类别代码 非主键字段相等
         AND COALESCE(TM.SAM_CATEGORY_DESC,'') = COALESCE(BF.SAM_CATEGORY_DESC,'') -- 特约商户类别描述 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') -- 特约商户场景大类代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') -- 特约商户场景小类代码 非主键字段相等
         AND COALESCE(TM.INDUS_CATEGORY_NAME,'') = COALESCE(BF.INDUS_CATEGORY_NAME,'') -- 行业类别名称 非主键字段相等
         AND COALESCE(TM.INDUS_NAME,'') = COALESCE(BF.INDUS_NAME,'') -- 行业名称 非主键字段相等
         AND COALESCE(TM.ZFB_OPER_CAT_CD,'') = COALESCE(BF.ZFB_OPER_CAT_CD,'') -- 支付宝经营类目代码 非主键字段相等
         AND COALESCE(TM.WX_CORP_STL_CD,'') = COALESCE(BF.WX_CORP_STL_CD,'') -- 微信对公结算代码 非主键字段相等
         AND COALESCE(TM.HELP_FMR_POINT_STAR_LVL_CD,'') = COALESCE(BF.HELP_FMR_POINT_STAR_LVL_CD,'') -- 助农点星级代码 非主键字段相等
         AND COALESCE(TM.WEB_MERCHT_REG_URL,'') = COALESCE(BF.WEB_MERCHT_REG_URL,'') -- 网络商户登记网址 非主键字段相等
         AND COALESCE(TM.WEB_MERCHT_REG_IP_ADDR,'') = COALESCE(BF.WEB_MERCHT_REG_IP_ADDR,'') -- 网络商户登记IP地址 非主键字段相等
         AND COALESCE(TM.WEB_MERCHT_IC_REC_LIC_NO,'') = COALESCE(BF.WEB_MERCHT_IC_REC_LIC_NO,'') -- 网络商户ICP备案/许可证号 非主键字段相等
         AND COALESCE(TM.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) -- 微信成本费率 非主键字段相等
         AND COALESCE(TM.CUST_SERV_TEL_NO,'') = COALESCE(BF.CUST_SERV_TEL_NO,'') -- 客服电话号码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') = COALESCE(BF.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') -- 实际经营地址所在省份代码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') = COALESCE(BF.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') -- 实际经营地址所在市代码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') = COALESCE(BF.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') -- 实际经营地址所在区县代码 非主键字段相等
         AND COALESCE(TM.AOA_LOCAL_TOWN_STREET_CD,'') = COALESCE(BF.AOA_LOCAL_TOWN_STREET_CD,'') -- 实际经营地址所在镇街道代码 非主键字段相等
         AND COALESCE(TM.AOA_LOCAL_VILG_COMM_CD,'') = COALESCE(BF.AOA_LOCAL_VILG_COMM_CD,'') -- 实际经营地址所在村社区代码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_DESC,'') = COALESCE(BF.ACTL_OPER_ADDR_DESC,'') -- 实际经营地址 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LATD,'') = COALESCE(BF.ACTL_OPER_ADDR_LATD,'') -- 实际经营地址纬度 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LGTD,'') = COALESCE(BF.ACTL_OPER_ADDR_LGTD,'') -- 实际经营地址经度 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.PREFR_DERATE_TYPE_CD,'') = COALESCE(BF.PREFR_DERATE_TYPE_CD,'') -- 优惠减免类型代码 非主键字段相等
         AND COALESCE(TM.SMALL_MICRO_MERCHT_TYPE_CD,'') = COALESCE(BF.SMALL_MICRO_MERCHT_TYPE_CD,'') -- 小微商户类型代码 非主键字段相等
         AND COALESCE(TM.RISK_ESTIM_LVL_CD,'') = COALESCE(BF.RISK_ESTIM_LVL_CD,'') -- 风险评估等级代码 非主键字段相等
         AND COALESCE(TM.EXPAND_MODE_CD,'') = COALESCE(BF.EXPAND_MODE_CD,'') -- 拓展方式代码 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NO,'') = COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NAME,'') = COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段相等
         AND COALESCE(TM.MATN_TELR_NO,'') = COALESCE(BF.MATN_TELR_NO,'') -- 维护柜员编号 非主键字段相等
         AND COALESCE(TM.MATN_TELR_NAME,'') = COALESCE(BF.MATN_TELR_NAME,'') -- 维护柜员名称 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_CD,'') = COALESCE(BF.SERV_PROVDER_CD,'') -- 服务商编码 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NAME,'') = COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_DOC_NO,'') = COALESCE(BF.SERV_PROVDER_DOC_NO,'') -- 服务商证件号码 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_TYPE_CD,'') = COALESCE(BF.SERV_PROVDER_TYPE_CD,'') -- 服务商类型代码 非主键字段相等
         AND COALESCE(TM.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计转账限额 非主键字段相等
         AND COALESCE(TM.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计转账限额 非主键字段相等
         AND COALESCE(TM.STL_MODE_CD,'') = COALESCE(BF.STL_MODE_CD,'') -- 结算方式代码 非主键字段相等
         AND COALESCE(TM.RBSA_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.RBSA_OPEN_ACCT_ORG_NO,'') -- 收单结算账户开户机构编号 非主键字段相等
         AND COALESCE(TM.RBSA_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.RBSA_OPEN_ACCT_ORG_NAME,'') -- 收单结算账号开户机构名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_TYPE_CD,'') = COALESCE(BF.RECV_BIL_STL_ACCT_TYPE_CD,'') -- 收单结算账户类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NO,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NO,'') -- 收单结算账户编号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NAME,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NAME,'') -- 收单结算账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_CATEGORY_CD,'') = COALESCE(BF.RECV_BIL_STL_ACCT_CATEGORY_CD,'') -- 收单结算账户类别代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NO,'') = COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NO,'') -- 收单结算账户开户行行号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NAME,'') = COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NAME,'') -- 收单结算账户开户行名称 非主键字段相等
         AND COALESCE(TM.ARBSA_NO,'') = COALESCE(BF.ARBSA_NO,'') -- 实际收单结算账户编号 非主键字段相等
         AND COALESCE(TM.ARBSA_NAME,'') = COALESCE(BF.ARBSA_NAME,'') -- 实际收单结算账户名称 非主键字段相等
         AND COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NO,'') -- 实际收单结算账户开户机构编号 非主键字段相等
         AND COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NAME,'') -- 实际收单结算账户开户机构名称 非主键字段相等
         AND COALESCE(TM.ARBSA_TYPE_CD,'') = COALESCE(BF.ARBSA_TYPE_CD,'') -- 实际收单结算账户类型代码 非主键字段相等
         AND COALESCE(TM.ARBSA_OPBANK_CNAPS_CODE,'') = COALESCE(BF.ARBSA_OPBANK_CNAPS_CODE,'') -- 实际收单结算账户开户行人行支付行号 非主键字段相等
         AND COALESCE(TM.CFEA_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.CFEA_OPEN_ACCT_ORG_NO,'') -- 手续费支出账户开户机构编号 非主键字段相等
         AND COALESCE(TM.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') = COALESCE(BF.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') -- 手续费支出账户类型代码 非主键字段相等
         AND COALESCE(TM.COMM_FEE_EXPNT_ACCT_NO,'') = COALESCE(BF.COMM_FEE_EXPNT_ACCT_NO,'') -- 手续费支出账户编号 非主键字段相等
         AND COALESCE(TM.COMM_FEE_EXPNT_ACCT_NAME,'') = COALESCE(BF.COMM_FEE_EXPNT_ACCT_NAME,'') -- 手续费支出账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段相等
         AND COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') = COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段相等
         AND COALESCE(TM.RECV_GOOD_CFM_FLAG,'') = COALESCE(BF.RECV_GOOD_CFM_FLAG,'') -- 收货确认标志 非主键字段相等
         AND COALESCE(TM.REFUND_MODE_CD,'') = COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段相等
         AND COALESCE(TM.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') -- 退款支出账户开户机构编号 非主键字段相等
         AND COALESCE(TM.REFUND_EXPNT_ACCT_TYPE_CD,'') = COALESCE(BF.REFUND_EXPNT_ACCT_TYPE_CD,'') -- 退款支出账户类型代码 非主键字段相等
         AND COALESCE(TM.REFUND_EXPNT_ACCT_ACCT_NO,'') = COALESCE(BF.REFUND_EXPNT_ACCT_ACCT_NO,'') -- 退款支出账户账户编号 非主键字段相等
         AND COALESCE(TM.REFUND_EXPNT_ACCT_NAME,'') = COALESCE(BF.REFUND_EXPNT_ACCT_NAME,'') -- 退款支出账户名称 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_FLAG,'') = COALESCE(BF.EXCESS_REFUND_FLAG,'') -- 超额退款标志 非主键字段相等
         AND COALESCE(TM.REFUND_MRGACCT_TYPE_CD,'') = COALESCE(BF.REFUND_MRGACCT_TYPE_CD,'') -- 退款保证金账户类别代码 非主键字段相等
         AND COALESCE(TM.REFUND_MRGACCT_NO,'') = COALESCE(BF.REFUND_MRGACCT_NO,'') -- 退款保证金账户编号 非主键字段相等
         AND COALESCE(TM.REFUND_MRGACCT_NAME,'') = COALESCE(BF.REFUND_MRGACCT_NAME,'') -- 退款保证金账户名称 非主键字段相等
         AND COALESCE(TM.RMACT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.RMACT_OPEN_ACCT_ORG_NO,'') -- 退款保证金账户开户机构编号 非主键字段相等
         AND COALESCE(TM.RMACT_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.RMACT_OPEN_ACCT_ORG_NAME,'') -- 退款保证金账户开户机构名称 非主键字段相等
         AND COALESCE(TM.REFUND_MRG_ACCT_NO_TYPE_CD,'') = COALESCE(BF.REFUND_MRG_ACCT_NO_TYPE_CD,'') -- 退款保证金账号类型代码 非主键字段相等
         AND COALESCE(TM.TERROR_ACT_LIST_FLAG,'') = COALESCE(BF.TERROR_ACT_LIST_FLAG,'') -- 恐怖活动名单标志 非主键字段相等
         AND COALESCE(TM.CO_MODE_CD,'') = COALESCE(BF.CO_MODE_CD,'') -- 合作模式代码 非主键字段相等
         AND COALESCE(TM.BIZ_PROD_PRVLG_CD,'') = COALESCE(BF.BIZ_PROD_PRVLG_CD,'') -- 业务产品权限代码 非主键字段相等
         AND COALESCE(TM.ESCR_MERCHT_FLAG,'') = COALESCE(BF.ESCR_MERCHT_FLAG,'') -- 特殊费率商户标志 非主键字段相等
         AND COALESCE(TM.PRFT_CUT_FLAG,'') = COALESCE(BF.PRFT_CUT_FLAG,'') -- 分润标志 非主键字段相等
         AND COALESCE(TM.INSTALLMENT_MERCHT_FLAG,'') = COALESCE(BF.INSTALLMENT_MERCHT_FLAG,'') -- 分期商户标志 非主键字段相等
         AND COALESCE(TM.POS_MERCHT_FLAG,'') = COALESCE(BF.POS_MERCHT_FLAG,'') -- POS商户标志 非主键字段相等
         AND COALESCE(TM.POS_MIGRATE_MERCHT_FLAG,'') = COALESCE(BF.POS_MIGRATE_MERCHT_FLAG,'') -- POS迁移商户标志 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段相等
         AND COALESCE(TM.SAM_OPER_APP_TYPE_CD,'') = COALESCE(BF.SAM_OPER_APP_TYPE_CD,'') -- 特约商户操作申请类型代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_STATUS_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_STATUS_CD,'') -- 特约商户状态代码 非主键字段相等
         AND COALESCE(TM.SAM_AUDIT_STAT_CD,'') = COALESCE(BF.SAM_AUDIT_STAT_CD,'') -- 特约商户审核状态代码 非主键字段相等
         AND COALESCE(TM.SUBMIT_APP_MODE_CD,'') = COALESCE(BF.SUBMIT_APP_MODE_CD,'') -- 进件方式代码 非主键字段相等
         AND COALESCE(TM.SUBMIT_APP_TYPE_CD,'') = COALESCE(BF.SUBMIT_APP_TYPE_CD,'') -- 进件类型代码 非主键字段相等
         AND COALESCE(TM.PRE_COL_INFO_SER_NO,'') = COALESCE(BF.PRE_COL_INFO_SER_NO,'') -- 预采集信息流水号 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM_STAMP,'') = COALESCE(BF.OPEN_ACCT_TM_STAMP,'') -- 开户时间戳 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TM_STAMP,'') = COALESCE(BF.CANC_ACCT_TM_STAMP,'') -- 销户时间戳 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.AUDIT_NO,'') = COALESCE(BF.AUDIT_NO,'') -- 审核编号 非主键字段相等
         AND COALESCE(TM.AUDIT_TM_STAMP,'') = COALESCE(BF.AUDIT_TM_STAMP,'') -- 审核时间戳 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') = COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_RSN_CD,'') = COALESCE(BF.CANC_ACCT_RSN_CD,'') -- 销户原因代码 非主键字段相等
         AND COALESCE(TM.AUDIT_FAIL_RSN,'') = COALESCE(BF.AUDIT_FAIL_RSN,'') -- 审核失败原因 非主键字段相等
         AND COALESCE(TM.INPUT_TELR_NO,'') = COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段相等
         AND COALESCE(TM.INPUT_ORG_NO,'') = COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.MIGRATE_MERCHT_IDNT_CD,'') = COALESCE(BF.MIGRATE_MERCHT_IDNT_CD,'') -- 迁移商户标识代码 非主键字段相等
         AND COALESCE(TM.MIGRATE_TM_STAMP,'') = COALESCE(BF.MIGRATE_TM_STAMP,'') -- 迁移时间戳 非主键字段相等
         AND COALESCE(TM.FRZ_RSN_REM,'') = COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段相等
         AND COALESCE(TM.RECNT_FRZ_TM_STAMP,'') = COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') = COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_ATTR_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_ATTR_CD,'') -- 特约商户属性代码 非主键字段不相等
         OR COALESCE(TM.MERCHT_NO,'') <> COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段不相等
         OR COALESCE(TM.WX_MERCHT_NO,'') <> COALESCE(BF.WX_MERCHT_NO,'') -- 微信商户编号 非主键字段不相等
         OR COALESCE(TM.ZFB_MERCHT_NO,'') <> COALESCE(BF.ZFB_MERCHT_NO,'') -- 支付宝商户编号 非主键字段不相等
         OR COALESCE(TM.UNPY_MERCHT_NO,'') <> COALESCE(BF.UNPY_MERCHT_NO,'') -- 银联商户编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_NAME,'') <> COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段不相等
         OR COALESCE(TM.STL_ACCT_CUST_IN_CD,'') <> COALESCE(BF.STL_ACCT_CUST_IN_CD,'') -- 结算账户客户内码 非主键字段不相等
         OR COALESCE(TM.LP_CUST_IN_CD,'') <> COALESCE(BF.LP_CUST_IN_CD,'') -- 法人客户内码 非主键字段不相等
         OR COALESCE(TM.CORP_CUST_IN_CD,'') <> COALESCE(BF.CORP_CUST_IN_CD,'') -- 企业客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.DOC_ISSUE_DT,'') <> COALESCE(BF.DOC_ISSUE_DT,'') -- 证件签发日期 非主键字段不相等
         OR COALESCE(TM.DOC_MATU_DT,'') <> COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段不相等
         OR COALESCE(TM.REG_CAP,'') <> COALESCE(BF.REG_CAP,'') -- 注册资金 非主键字段不相等
         OR COALESCE(TM.REG_ADDR_DIST_CD,'') <> COALESCE(BF.REG_ADDR_DIST_CD,'') -- 注册地址行政区划代码 非主键字段不相等
         OR COALESCE(TM.REG_ADDR,'') <> COALESCE(BF.REG_ADDR,'') -- 注册地址 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOCTYP_CD,'') <> COALESCE(BF.LP_PRINC_DOCTYP_CD,'') -- 法人负责人证件类型代码 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOC_NO,'') <> COALESCE(BF.LP_PRINC_DOC_NO,'') -- 法人负责人证件号码 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOC_ISSUE_DT,'') <> COALESCE(BF.LP_PRINC_DOC_ISSUE_DT,'') -- 法人负责人证件签发日期 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOC_MATU_DT,'') <> COALESCE(BF.LP_PRINC_DOC_MATU_DT,'') -- 法人负责人证件到期日期 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_NAME,'') <> COALESCE(BF.LP_PRINC_NAME,'') -- 法人负责人名称 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_TEL_NO,'') <> COALESCE(BF.LP_PRINC_TEL_NO,'') -- 法人负责人电话号码 非主键字段不相等
         OR COALESCE(TM.LP_DOC_INFO_SETUP_TM_STAMP,'') <> COALESCE(BF.LP_DOC_INFO_SETUP_TM_STAMP,'') -- 法人证件信息建立时间戳 非主键字段不相等
         OR COALESCE(TM.LP_DOC_INFO_MODIF_TM_STAMP,'') <> COALESCE(BF.LP_DOC_INFO_MODIF_TM_STAMP,'') -- 法人证件信息修改时间戳 非主键字段不相等
         OR COALESCE(TM.ASSIS_DOCTYP_CD,'') <> COALESCE(BF.ASSIS_DOCTYP_CD,'') -- 辅助证件类型代码 非主键字段不相等
         OR COALESCE(TM.ASSIS_DOC_NO,'') <> COALESCE(BF.ASSIS_DOC_NO,'') -- 辅助证件号码 非主键字段不相等
         OR COALESCE(TM.ASSIS_DOC_NAME,'') <> COALESCE(BF.ASSIS_DOC_NAME,'') -- 辅助证件名称 非主键字段不相等
         OR COALESCE(TM.CONT_NAME,'') <> COALESCE(BF.CONT_NAME,'') -- 联系人名称 非主键字段不相等
         OR COALESCE(TM.CONT_TEL_NO,'') <> COALESCE(BF.CONT_TEL_NO,'') -- 联系人电话号码 非主键字段不相等
         OR COALESCE(TM.CONT_EMAIL_ADDR,'') <> COALESCE(BF.CONT_EMAIL_ADDR,'') -- 联系人电子邮箱地址 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_NAME_ABB,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NAME_ABB,'') -- 特约商户名称简称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_EN_NAME,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_EN_NAME,'') -- 特约商户英文名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_CATEGORY_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_CATEGORY_CD,'') -- 特约商户类别代码 非主键字段不相等
         OR COALESCE(TM.SAM_CATEGORY_DESC,'') <> COALESCE(BF.SAM_CATEGORY_DESC,'') -- 特约商户类别描述 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') -- 特约商户场景大类代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') -- 特约商户场景小类代码 非主键字段不相等
         OR COALESCE(TM.INDUS_CATEGORY_NAME,'') <> COALESCE(BF.INDUS_CATEGORY_NAME,'') -- 行业类别名称 非主键字段不相等
         OR COALESCE(TM.INDUS_NAME,'') <> COALESCE(BF.INDUS_NAME,'') -- 行业名称 非主键字段不相等
         OR COALESCE(TM.ZFB_OPER_CAT_CD,'') <> COALESCE(BF.ZFB_OPER_CAT_CD,'') -- 支付宝经营类目代码 非主键字段不相等
         OR COALESCE(TM.WX_CORP_STL_CD,'') <> COALESCE(BF.WX_CORP_STL_CD,'') -- 微信对公结算代码 非主键字段不相等
         OR COALESCE(TM.HELP_FMR_POINT_STAR_LVL_CD,'') <> COALESCE(BF.HELP_FMR_POINT_STAR_LVL_CD,'') -- 助农点星级代码 非主键字段不相等
         OR COALESCE(TM.WEB_MERCHT_REG_URL,'') <> COALESCE(BF.WEB_MERCHT_REG_URL,'') -- 网络商户登记网址 非主键字段不相等
         OR COALESCE(TM.WEB_MERCHT_REG_IP_ADDR,'') <> COALESCE(BF.WEB_MERCHT_REG_IP_ADDR,'') -- 网络商户登记IP地址 非主键字段不相等
         OR COALESCE(TM.WEB_MERCHT_IC_REC_LIC_NO,'') <> COALESCE(BF.WEB_MERCHT_IC_REC_LIC_NO,'') -- 网络商户ICP备案/许可证号 非主键字段不相等
         OR COALESCE(TM.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) -- 微信成本费率 非主键字段不相等
         OR COALESCE(TM.CUST_SERV_TEL_NO,'') <> COALESCE(BF.CUST_SERV_TEL_NO,'') -- 客服电话号码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') -- 实际经营地址所在省份代码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') -- 实际经营地址所在市代码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') -- 实际经营地址所在区县代码 非主键字段不相等
         OR COALESCE(TM.AOA_LOCAL_TOWN_STREET_CD,'') <> COALESCE(BF.AOA_LOCAL_TOWN_STREET_CD,'') -- 实际经营地址所在镇街道代码 非主键字段不相等
         OR COALESCE(TM.AOA_LOCAL_VILG_COMM_CD,'') <> COALESCE(BF.AOA_LOCAL_VILG_COMM_CD,'') -- 实际经营地址所在村社区代码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_DESC,'') <> COALESCE(BF.ACTL_OPER_ADDR_DESC,'') -- 实际经营地址 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LATD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LATD,'') -- 实际经营地址纬度 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LGTD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LGTD,'') -- 实际经营地址经度 非主键字段不相等
         OR COALESCE(TM.TXN_CURR_CD,'') <> COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段不相等
         OR COALESCE(TM.PREFR_DERATE_TYPE_CD,'') <> COALESCE(BF.PREFR_DERATE_TYPE_CD,'') -- 优惠减免类型代码 非主键字段不相等
         OR COALESCE(TM.SMALL_MICRO_MERCHT_TYPE_CD,'') <> COALESCE(BF.SMALL_MICRO_MERCHT_TYPE_CD,'') -- 小微商户类型代码 非主键字段不相等
         OR COALESCE(TM.RISK_ESTIM_LVL_CD,'') <> COALESCE(BF.RISK_ESTIM_LVL_CD,'') -- 风险评估等级代码 非主键字段不相等
         OR COALESCE(TM.EXPAND_MODE_CD,'') <> COALESCE(BF.EXPAND_MODE_CD,'') -- 拓展方式代码 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NO,'') <> COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NAME,'') <> COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段不相等
         OR COALESCE(TM.MATN_TELR_NO,'') <> COALESCE(BF.MATN_TELR_NO,'') -- 维护柜员编号 非主键字段不相等
         OR COALESCE(TM.MATN_TELR_NAME,'') <> COALESCE(BF.MATN_TELR_NAME,'') -- 维护柜员名称 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_CD,'') <> COALESCE(BF.SERV_PROVDER_CD,'') -- 服务商编码 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_NAME,'') <> COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_DOC_NO,'') <> COALESCE(BF.SERV_PROVDER_DOC_NO,'') -- 服务商证件号码 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_TYPE_CD,'') <> COALESCE(BF.SERV_PROVDER_TYPE_CD,'') -- 服务商类型代码 非主键字段不相等
         OR COALESCE(TM.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计转账限额 非主键字段不相等
         OR COALESCE(TM.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计转账限额 非主键字段不相等
         OR COALESCE(TM.STL_MODE_CD,'') <> COALESCE(BF.STL_MODE_CD,'') -- 结算方式代码 非主键字段不相等
         OR COALESCE(TM.RBSA_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.RBSA_OPEN_ACCT_ORG_NO,'') -- 收单结算账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.RBSA_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.RBSA_OPEN_ACCT_ORG_NAME,'') -- 收单结算账号开户机构名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_TYPE_CD,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_TYPE_CD,'') -- 收单结算账户类型代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_NO,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_NO,'') -- 收单结算账户编号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_NAME,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_NAME,'') -- 收单结算账户名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_CATEGORY_CD,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_CATEGORY_CD,'') -- 收单结算账户类别代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NO,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NO,'') -- 收单结算账户开户行行号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NAME,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NAME,'') -- 收单结算账户开户行名称 非主键字段不相等
         OR COALESCE(TM.ARBSA_NO,'') <> COALESCE(BF.ARBSA_NO,'') -- 实际收单结算账户编号 非主键字段不相等
         OR COALESCE(TM.ARBSA_NAME,'') <> COALESCE(BF.ARBSA_NAME,'') -- 实际收单结算账户名称 非主键字段不相等
         OR COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NO,'') -- 实际收单结算账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NAME,'') -- 实际收单结算账户开户机构名称 非主键字段不相等
         OR COALESCE(TM.ARBSA_TYPE_CD,'') <> COALESCE(BF.ARBSA_TYPE_CD,'') -- 实际收单结算账户类型代码 非主键字段不相等
         OR COALESCE(TM.ARBSA_OPBANK_CNAPS_CODE,'') <> COALESCE(BF.ARBSA_OPBANK_CNAPS_CODE,'') -- 实际收单结算账户开户行人行支付行号 非主键字段不相等
         OR COALESCE(TM.CFEA_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.CFEA_OPEN_ACCT_ORG_NO,'') -- 手续费支出账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') <> COALESCE(BF.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') -- 手续费支出账户类型代码 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_EXPNT_ACCT_NO,'') <> COALESCE(BF.COMM_FEE_EXPNT_ACCT_NO,'') -- 手续费支出账户编号 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_EXPNT_ACCT_NAME,'') <> COALESCE(BF.COMM_FEE_EXPNT_ACCT_NAME,'') -- 手续费支出账户名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') <> COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段不相等
         OR COALESCE(TM.RECV_GOOD_CFM_FLAG,'') <> COALESCE(BF.RECV_GOOD_CFM_FLAG,'') -- 收货确认标志 非主键字段不相等
         OR COALESCE(TM.REFUND_MODE_CD,'') <> COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段不相等
         OR COALESCE(TM.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') -- 退款支出账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.REFUND_EXPNT_ACCT_TYPE_CD,'') <> COALESCE(BF.REFUND_EXPNT_ACCT_TYPE_CD,'') -- 退款支出账户类型代码 非主键字段不相等
         OR COALESCE(TM.REFUND_EXPNT_ACCT_ACCT_NO,'') <> COALESCE(BF.REFUND_EXPNT_ACCT_ACCT_NO,'') -- 退款支出账户账户编号 非主键字段不相等
         OR COALESCE(TM.REFUND_EXPNT_ACCT_NAME,'') <> COALESCE(BF.REFUND_EXPNT_ACCT_NAME,'') -- 退款支出账户名称 非主键字段不相等
         OR COALESCE(TM.EXCESS_REFUND_FLAG,'') <> COALESCE(BF.EXCESS_REFUND_FLAG,'') -- 超额退款标志 非主键字段不相等
         OR COALESCE(TM.REFUND_MRGACCT_TYPE_CD,'') <> COALESCE(BF.REFUND_MRGACCT_TYPE_CD,'') -- 退款保证金账户类别代码 非主键字段不相等
         OR COALESCE(TM.REFUND_MRGACCT_NO,'') <> COALESCE(BF.REFUND_MRGACCT_NO,'') -- 退款保证金账户编号 非主键字段不相等
         OR COALESCE(TM.REFUND_MRGACCT_NAME,'') <> COALESCE(BF.REFUND_MRGACCT_NAME,'') -- 退款保证金账户名称 非主键字段不相等
         OR COALESCE(TM.RMACT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.RMACT_OPEN_ACCT_ORG_NO,'') -- 退款保证金账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.RMACT_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.RMACT_OPEN_ACCT_ORG_NAME,'') -- 退款保证金账户开户机构名称 非主键字段不相等
         OR COALESCE(TM.REFUND_MRG_ACCT_NO_TYPE_CD,'') <> COALESCE(BF.REFUND_MRG_ACCT_NO_TYPE_CD,'') -- 退款保证金账号类型代码 非主键字段不相等
         OR COALESCE(TM.TERROR_ACT_LIST_FLAG,'') <> COALESCE(BF.TERROR_ACT_LIST_FLAG,'') -- 恐怖活动名单标志 非主键字段不相等
         OR COALESCE(TM.CO_MODE_CD,'') <> COALESCE(BF.CO_MODE_CD,'') -- 合作模式代码 非主键字段不相等
         OR COALESCE(TM.BIZ_PROD_PRVLG_CD,'') <> COALESCE(BF.BIZ_PROD_PRVLG_CD,'') -- 业务产品权限代码 非主键字段不相等
         OR COALESCE(TM.ESCR_MERCHT_FLAG,'') <> COALESCE(BF.ESCR_MERCHT_FLAG,'') -- 特殊费率商户标志 非主键字段不相等
         OR COALESCE(TM.PRFT_CUT_FLAG,'') <> COALESCE(BF.PRFT_CUT_FLAG,'') -- 分润标志 非主键字段不相等
         OR COALESCE(TM.INSTALLMENT_MERCHT_FLAG,'') <> COALESCE(BF.INSTALLMENT_MERCHT_FLAG,'') -- 分期商户标志 非主键字段不相等
         OR COALESCE(TM.POS_MERCHT_FLAG,'') <> COALESCE(BF.POS_MERCHT_FLAG,'') -- POS商户标志 非主键字段不相等
         OR COALESCE(TM.POS_MIGRATE_MERCHT_FLAG,'') <> COALESCE(BF.POS_MIGRATE_MERCHT_FLAG,'') -- POS迁移商户标志 非主键字段不相等
         OR COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') <> COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段不相等
         OR COALESCE(TM.SAM_OPER_APP_TYPE_CD,'') <> COALESCE(BF.SAM_OPER_APP_TYPE_CD,'') -- 特约商户操作申请类型代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_STATUS_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_STATUS_CD,'') -- 特约商户状态代码 非主键字段不相等
         OR COALESCE(TM.SAM_AUDIT_STAT_CD,'') <> COALESCE(BF.SAM_AUDIT_STAT_CD,'') -- 特约商户审核状态代码 非主键字段不相等
         OR COALESCE(TM.SUBMIT_APP_MODE_CD,'') <> COALESCE(BF.SUBMIT_APP_MODE_CD,'') -- 进件方式代码 非主键字段不相等
         OR COALESCE(TM.SUBMIT_APP_TYPE_CD,'') <> COALESCE(BF.SUBMIT_APP_TYPE_CD,'') -- 进件类型代码 非主键字段不相等
         OR COALESCE(TM.PRE_COL_INFO_SER_NO,'') <> COALESCE(BF.PRE_COL_INFO_SER_NO,'') -- 预采集信息流水号 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM_STAMP,'') <> COALESCE(BF.OPEN_ACCT_TM_STAMP,'') -- 开户时间戳 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TM_STAMP,'') <> COALESCE(BF.CANC_ACCT_TM_STAMP,'') -- 销户时间戳 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.AUDIT_NO,'') <> COALESCE(BF.AUDIT_NO,'') -- 审核编号 非主键字段不相等
         OR COALESCE(TM.AUDIT_TM_STAMP,'') <> COALESCE(BF.AUDIT_TM_STAMP,'') -- 审核时间戳 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') <> COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_RSN_CD,'') <> COALESCE(BF.CANC_ACCT_RSN_CD,'') -- 销户原因代码 非主键字段不相等
         OR COALESCE(TM.AUDIT_FAIL_RSN,'') <> COALESCE(BF.AUDIT_FAIL_RSN,'') -- 审核失败原因 非主键字段不相等
         OR COALESCE(TM.INPUT_TELR_NO,'') <> COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段不相等
         OR COALESCE(TM.INPUT_ORG_NO,'') <> COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.MIGRATE_MERCHT_IDNT_CD,'') <> COALESCE(BF.MIGRATE_MERCHT_IDNT_CD,'') -- 迁移商户标识代码 非主键字段不相等
         OR COALESCE(TM.MIGRATE_TM_STAMP,'') <> COALESCE(BF.MIGRATE_TM_STAMP,'') -- 迁移时间戳 非主键字段不相等
         OR COALESCE(TM.FRZ_RSN_REM,'') <> COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段不相等
         OR COALESCE(TM.RECNT_FRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_ATTR_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_ATTR_CD,'') -- 特约商户属性代码 非主键字段相等
         AND COALESCE(TM.MERCHT_NO,'') = COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段相等
         AND COALESCE(TM.WX_MERCHT_NO,'') = COALESCE(BF.WX_MERCHT_NO,'') -- 微信商户编号 非主键字段相等
         AND COALESCE(TM.ZFB_MERCHT_NO,'') = COALESCE(BF.ZFB_MERCHT_NO,'') -- 支付宝商户编号 非主键字段相等
         AND COALESCE(TM.UNPY_MERCHT_NO,'') = COALESCE(BF.UNPY_MERCHT_NO,'') -- 银联商户编号 非主键字段相等
         AND COALESCE(TM.MERCHT_NAME,'') = COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段相等
         AND COALESCE(TM.STL_ACCT_CUST_IN_CD,'') = COALESCE(BF.STL_ACCT_CUST_IN_CD,'') -- 结算账户客户内码 非主键字段相等
         AND COALESCE(TM.LP_CUST_IN_CD,'') = COALESCE(BF.LP_CUST_IN_CD,'') -- 法人客户内码 非主键字段相等
         AND COALESCE(TM.CORP_CUST_IN_CD,'') = COALESCE(BF.CORP_CUST_IN_CD,'') -- 企业客户内码 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.DOC_ISSUE_DT,'') = COALESCE(BF.DOC_ISSUE_DT,'') -- 证件签发日期 非主键字段相等
         AND COALESCE(TM.DOC_MATU_DT,'') = COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段相等
         AND COALESCE(TM.REG_CAP,'') = COALESCE(BF.REG_CAP,'') -- 注册资金 非主键字段相等
         AND COALESCE(TM.REG_ADDR_DIST_CD,'') = COALESCE(BF.REG_ADDR_DIST_CD,'') -- 注册地址行政区划代码 非主键字段相等
         AND COALESCE(TM.REG_ADDR,'') = COALESCE(BF.REG_ADDR,'') -- 注册地址 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOCTYP_CD,'') = COALESCE(BF.LP_PRINC_DOCTYP_CD,'') -- 法人负责人证件类型代码 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOC_NO,'') = COALESCE(BF.LP_PRINC_DOC_NO,'') -- 法人负责人证件号码 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOC_ISSUE_DT,'') = COALESCE(BF.LP_PRINC_DOC_ISSUE_DT,'') -- 法人负责人证件签发日期 非主键字段相等
         AND COALESCE(TM.LP_PRINC_DOC_MATU_DT,'') = COALESCE(BF.LP_PRINC_DOC_MATU_DT,'') -- 法人负责人证件到期日期 非主键字段相等
         AND COALESCE(TM.LP_PRINC_NAME,'') = COALESCE(BF.LP_PRINC_NAME,'') -- 法人负责人名称 非主键字段相等
         AND COALESCE(TM.LP_PRINC_TEL_NO,'') = COALESCE(BF.LP_PRINC_TEL_NO,'') -- 法人负责人电话号码 非主键字段相等
         AND COALESCE(TM.LP_DOC_INFO_SETUP_TM_STAMP,'') = COALESCE(BF.LP_DOC_INFO_SETUP_TM_STAMP,'') -- 法人证件信息建立时间戳 非主键字段相等
         AND COALESCE(TM.LP_DOC_INFO_MODIF_TM_STAMP,'') = COALESCE(BF.LP_DOC_INFO_MODIF_TM_STAMP,'') -- 法人证件信息修改时间戳 非主键字段相等
         AND COALESCE(TM.ASSIS_DOCTYP_CD,'') = COALESCE(BF.ASSIS_DOCTYP_CD,'') -- 辅助证件类型代码 非主键字段相等
         AND COALESCE(TM.ASSIS_DOC_NO,'') = COALESCE(BF.ASSIS_DOC_NO,'') -- 辅助证件号码 非主键字段相等
         AND COALESCE(TM.ASSIS_DOC_NAME,'') = COALESCE(BF.ASSIS_DOC_NAME,'') -- 辅助证件名称 非主键字段相等
         AND COALESCE(TM.CONT_NAME,'') = COALESCE(BF.CONT_NAME,'') -- 联系人名称 非主键字段相等
         AND COALESCE(TM.CONT_TEL_NO,'') = COALESCE(BF.CONT_TEL_NO,'') -- 联系人电话号码 非主键字段相等
         AND COALESCE(TM.CONT_EMAIL_ADDR,'') = COALESCE(BF.CONT_EMAIL_ADDR,'') -- 联系人电子邮箱地址 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NAME_ABB,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME_ABB,'') -- 特约商户名称简称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_EN_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_EN_NAME,'') -- 特约商户英文名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_CATEGORY_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_CATEGORY_CD,'') -- 特约商户类别代码 非主键字段相等
         AND COALESCE(TM.SAM_CATEGORY_DESC,'') = COALESCE(BF.SAM_CATEGORY_DESC,'') -- 特约商户类别描述 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') -- 特约商户场景大类代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') -- 特约商户场景小类代码 非主键字段相等
         AND COALESCE(TM.INDUS_CATEGORY_NAME,'') = COALESCE(BF.INDUS_CATEGORY_NAME,'') -- 行业类别名称 非主键字段相等
         AND COALESCE(TM.INDUS_NAME,'') = COALESCE(BF.INDUS_NAME,'') -- 行业名称 非主键字段相等
         AND COALESCE(TM.ZFB_OPER_CAT_CD,'') = COALESCE(BF.ZFB_OPER_CAT_CD,'') -- 支付宝经营类目代码 非主键字段相等
         AND COALESCE(TM.WX_CORP_STL_CD,'') = COALESCE(BF.WX_CORP_STL_CD,'') -- 微信对公结算代码 非主键字段相等
         AND COALESCE(TM.HELP_FMR_POINT_STAR_LVL_CD,'') = COALESCE(BF.HELP_FMR_POINT_STAR_LVL_CD,'') -- 助农点星级代码 非主键字段相等
         AND COALESCE(TM.WEB_MERCHT_REG_URL,'') = COALESCE(BF.WEB_MERCHT_REG_URL,'') -- 网络商户登记网址 非主键字段相等
         AND COALESCE(TM.WEB_MERCHT_REG_IP_ADDR,'') = COALESCE(BF.WEB_MERCHT_REG_IP_ADDR,'') -- 网络商户登记IP地址 非主键字段相等
         AND COALESCE(TM.WEB_MERCHT_IC_REC_LIC_NO,'') = COALESCE(BF.WEB_MERCHT_IC_REC_LIC_NO,'') -- 网络商户ICP备案/许可证号 非主键字段相等
         AND COALESCE(TM.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) -- 微信成本费率 非主键字段相等
         AND COALESCE(TM.CUST_SERV_TEL_NO,'') = COALESCE(BF.CUST_SERV_TEL_NO,'') -- 客服电话号码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') = COALESCE(BF.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') -- 实际经营地址所在省份代码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') = COALESCE(BF.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') -- 实际经营地址所在市代码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') = COALESCE(BF.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') -- 实际经营地址所在区县代码 非主键字段相等
         AND COALESCE(TM.AOA_LOCAL_TOWN_STREET_CD,'') = COALESCE(BF.AOA_LOCAL_TOWN_STREET_CD,'') -- 实际经营地址所在镇街道代码 非主键字段相等
         AND COALESCE(TM.AOA_LOCAL_VILG_COMM_CD,'') = COALESCE(BF.AOA_LOCAL_VILG_COMM_CD,'') -- 实际经营地址所在村社区代码 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_DESC,'') = COALESCE(BF.ACTL_OPER_ADDR_DESC,'') -- 实际经营地址 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LATD,'') = COALESCE(BF.ACTL_OPER_ADDR_LATD,'') -- 实际经营地址纬度 非主键字段相等
         AND COALESCE(TM.ACTL_OPER_ADDR_LGTD,'') = COALESCE(BF.ACTL_OPER_ADDR_LGTD,'') -- 实际经营地址经度 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.PREFR_DERATE_TYPE_CD,'') = COALESCE(BF.PREFR_DERATE_TYPE_CD,'') -- 优惠减免类型代码 非主键字段相等
         AND COALESCE(TM.SMALL_MICRO_MERCHT_TYPE_CD,'') = COALESCE(BF.SMALL_MICRO_MERCHT_TYPE_CD,'') -- 小微商户类型代码 非主键字段相等
         AND COALESCE(TM.RISK_ESTIM_LVL_CD,'') = COALESCE(BF.RISK_ESTIM_LVL_CD,'') -- 风险评估等级代码 非主键字段相等
         AND COALESCE(TM.EXPAND_MODE_CD,'') = COALESCE(BF.EXPAND_MODE_CD,'') -- 拓展方式代码 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NO,'') = COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NAME,'') = COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段相等
         AND COALESCE(TM.MATN_TELR_NO,'') = COALESCE(BF.MATN_TELR_NO,'') -- 维护柜员编号 非主键字段相等
         AND COALESCE(TM.MATN_TELR_NAME,'') = COALESCE(BF.MATN_TELR_NAME,'') -- 维护柜员名称 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_CD,'') = COALESCE(BF.SERV_PROVDER_CD,'') -- 服务商编码 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NAME,'') = COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_DOC_NO,'') = COALESCE(BF.SERV_PROVDER_DOC_NO,'') -- 服务商证件号码 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_TYPE_CD,'') = COALESCE(BF.SERV_PROVDER_TYPE_CD,'') -- 服务商类型代码 非主键字段相等
         AND COALESCE(TM.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计转账限额 非主键字段相等
         AND COALESCE(TM.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计转账限额 非主键字段相等
         AND COALESCE(TM.STL_MODE_CD,'') = COALESCE(BF.STL_MODE_CD,'') -- 结算方式代码 非主键字段相等
         AND COALESCE(TM.RBSA_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.RBSA_OPEN_ACCT_ORG_NO,'') -- 收单结算账户开户机构编号 非主键字段相等
         AND COALESCE(TM.RBSA_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.RBSA_OPEN_ACCT_ORG_NAME,'') -- 收单结算账号开户机构名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_TYPE_CD,'') = COALESCE(BF.RECV_BIL_STL_ACCT_TYPE_CD,'') -- 收单结算账户类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NO,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NO,'') -- 收单结算账户编号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_NAME,'') = COALESCE(BF.RECV_BIL_STL_ACCT_NAME,'') -- 收单结算账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_CATEGORY_CD,'') = COALESCE(BF.RECV_BIL_STL_ACCT_CATEGORY_CD,'') -- 收单结算账户类别代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NO,'') = COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NO,'') -- 收单结算账户开户行行号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NAME,'') = COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NAME,'') -- 收单结算账户开户行名称 非主键字段相等
         AND COALESCE(TM.ARBSA_NO,'') = COALESCE(BF.ARBSA_NO,'') -- 实际收单结算账户编号 非主键字段相等
         AND COALESCE(TM.ARBSA_NAME,'') = COALESCE(BF.ARBSA_NAME,'') -- 实际收单结算账户名称 非主键字段相等
         AND COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NO,'') -- 实际收单结算账户开户机构编号 非主键字段相等
         AND COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NAME,'') -- 实际收单结算账户开户机构名称 非主键字段相等
         AND COALESCE(TM.ARBSA_TYPE_CD,'') = COALESCE(BF.ARBSA_TYPE_CD,'') -- 实际收单结算账户类型代码 非主键字段相等
         AND COALESCE(TM.ARBSA_OPBANK_CNAPS_CODE,'') = COALESCE(BF.ARBSA_OPBANK_CNAPS_CODE,'') -- 实际收单结算账户开户行人行支付行号 非主键字段相等
         AND COALESCE(TM.CFEA_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.CFEA_OPEN_ACCT_ORG_NO,'') -- 手续费支出账户开户机构编号 非主键字段相等
         AND COALESCE(TM.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') = COALESCE(BF.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') -- 手续费支出账户类型代码 非主键字段相等
         AND COALESCE(TM.COMM_FEE_EXPNT_ACCT_NO,'') = COALESCE(BF.COMM_FEE_EXPNT_ACCT_NO,'') -- 手续费支出账户编号 非主键字段相等
         AND COALESCE(TM.COMM_FEE_EXPNT_ACCT_NAME,'') = COALESCE(BF.COMM_FEE_EXPNT_ACCT_NAME,'') -- 手续费支出账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段相等
         AND COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') = COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段相等
         AND COALESCE(TM.RECV_GOOD_CFM_FLAG,'') = COALESCE(BF.RECV_GOOD_CFM_FLAG,'') -- 收货确认标志 非主键字段相等
         AND COALESCE(TM.REFUND_MODE_CD,'') = COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段相等
         AND COALESCE(TM.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') -- 退款支出账户开户机构编号 非主键字段相等
         AND COALESCE(TM.REFUND_EXPNT_ACCT_TYPE_CD,'') = COALESCE(BF.REFUND_EXPNT_ACCT_TYPE_CD,'') -- 退款支出账户类型代码 非主键字段相等
         AND COALESCE(TM.REFUND_EXPNT_ACCT_ACCT_NO,'') = COALESCE(BF.REFUND_EXPNT_ACCT_ACCT_NO,'') -- 退款支出账户账户编号 非主键字段相等
         AND COALESCE(TM.REFUND_EXPNT_ACCT_NAME,'') = COALESCE(BF.REFUND_EXPNT_ACCT_NAME,'') -- 退款支出账户名称 非主键字段相等
         AND COALESCE(TM.EXCESS_REFUND_FLAG,'') = COALESCE(BF.EXCESS_REFUND_FLAG,'') -- 超额退款标志 非主键字段相等
         AND COALESCE(TM.REFUND_MRGACCT_TYPE_CD,'') = COALESCE(BF.REFUND_MRGACCT_TYPE_CD,'') -- 退款保证金账户类别代码 非主键字段相等
         AND COALESCE(TM.REFUND_MRGACCT_NO,'') = COALESCE(BF.REFUND_MRGACCT_NO,'') -- 退款保证金账户编号 非主键字段相等
         AND COALESCE(TM.REFUND_MRGACCT_NAME,'') = COALESCE(BF.REFUND_MRGACCT_NAME,'') -- 退款保证金账户名称 非主键字段相等
         AND COALESCE(TM.RMACT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.RMACT_OPEN_ACCT_ORG_NO,'') -- 退款保证金账户开户机构编号 非主键字段相等
         AND COALESCE(TM.RMACT_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.RMACT_OPEN_ACCT_ORG_NAME,'') -- 退款保证金账户开户机构名称 非主键字段相等
         AND COALESCE(TM.REFUND_MRG_ACCT_NO_TYPE_CD,'') = COALESCE(BF.REFUND_MRG_ACCT_NO_TYPE_CD,'') -- 退款保证金账号类型代码 非主键字段相等
         AND COALESCE(TM.TERROR_ACT_LIST_FLAG,'') = COALESCE(BF.TERROR_ACT_LIST_FLAG,'') -- 恐怖活动名单标志 非主键字段相等
         AND COALESCE(TM.CO_MODE_CD,'') = COALESCE(BF.CO_MODE_CD,'') -- 合作模式代码 非主键字段相等
         AND COALESCE(TM.BIZ_PROD_PRVLG_CD,'') = COALESCE(BF.BIZ_PROD_PRVLG_CD,'') -- 业务产品权限代码 非主键字段相等
         AND COALESCE(TM.ESCR_MERCHT_FLAG,'') = COALESCE(BF.ESCR_MERCHT_FLAG,'') -- 特殊费率商户标志 非主键字段相等
         AND COALESCE(TM.PRFT_CUT_FLAG,'') = COALESCE(BF.PRFT_CUT_FLAG,'') -- 分润标志 非主键字段相等
         AND COALESCE(TM.INSTALLMENT_MERCHT_FLAG,'') = COALESCE(BF.INSTALLMENT_MERCHT_FLAG,'') -- 分期商户标志 非主键字段相等
         AND COALESCE(TM.POS_MERCHT_FLAG,'') = COALESCE(BF.POS_MERCHT_FLAG,'') -- POS商户标志 非主键字段相等
         AND COALESCE(TM.POS_MIGRATE_MERCHT_FLAG,'') = COALESCE(BF.POS_MIGRATE_MERCHT_FLAG,'') -- POS迁移商户标志 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段相等
         AND COALESCE(TM.SAM_OPER_APP_TYPE_CD,'') = COALESCE(BF.SAM_OPER_APP_TYPE_CD,'') -- 特约商户操作申请类型代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_STATUS_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_STATUS_CD,'') -- 特约商户状态代码 非主键字段相等
         AND COALESCE(TM.SAM_AUDIT_STAT_CD,'') = COALESCE(BF.SAM_AUDIT_STAT_CD,'') -- 特约商户审核状态代码 非主键字段相等
         AND COALESCE(TM.SUBMIT_APP_MODE_CD,'') = COALESCE(BF.SUBMIT_APP_MODE_CD,'') -- 进件方式代码 非主键字段相等
         AND COALESCE(TM.SUBMIT_APP_TYPE_CD,'') = COALESCE(BF.SUBMIT_APP_TYPE_CD,'') -- 进件类型代码 非主键字段相等
         AND COALESCE(TM.PRE_COL_INFO_SER_NO,'') = COALESCE(BF.PRE_COL_INFO_SER_NO,'') -- 预采集信息流水号 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM_STAMP,'') = COALESCE(BF.OPEN_ACCT_TM_STAMP,'') -- 开户时间戳 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TM_STAMP,'') = COALESCE(BF.CANC_ACCT_TM_STAMP,'') -- 销户时间戳 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.AUDIT_NO,'') = COALESCE(BF.AUDIT_NO,'') -- 审核编号 非主键字段相等
         AND COALESCE(TM.AUDIT_TM_STAMP,'') = COALESCE(BF.AUDIT_TM_STAMP,'') -- 审核时间戳 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') = COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_RSN_CD,'') = COALESCE(BF.CANC_ACCT_RSN_CD,'') -- 销户原因代码 非主键字段相等
         AND COALESCE(TM.AUDIT_FAIL_RSN,'') = COALESCE(BF.AUDIT_FAIL_RSN,'') -- 审核失败原因 非主键字段相等
         AND COALESCE(TM.INPUT_TELR_NO,'') = COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段相等
         AND COALESCE(TM.INPUT_ORG_NO,'') = COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.MIGRATE_MERCHT_IDNT_CD,'') = COALESCE(BF.MIGRATE_MERCHT_IDNT_CD,'') -- 迁移商户标识代码 非主键字段相等
         AND COALESCE(TM.MIGRATE_TM_STAMP,'') = COALESCE(BF.MIGRATE_TM_STAMP,'') -- 迁移时间戳 非主键字段相等
         AND COALESCE(TM.FRZ_RSN_REM,'') = COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段相等
         AND COALESCE(TM.RECNT_FRZ_TM_STAMP,'') = COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') = COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_ATTR_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_ATTR_CD,'') -- 特约商户属性代码 非主键字段不相等
         OR COALESCE(TM.MERCHT_NO,'') <> COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段不相等
         OR COALESCE(TM.WX_MERCHT_NO,'') <> COALESCE(BF.WX_MERCHT_NO,'') -- 微信商户编号 非主键字段不相等
         OR COALESCE(TM.ZFB_MERCHT_NO,'') <> COALESCE(BF.ZFB_MERCHT_NO,'') -- 支付宝商户编号 非主键字段不相等
         OR COALESCE(TM.UNPY_MERCHT_NO,'') <> COALESCE(BF.UNPY_MERCHT_NO,'') -- 银联商户编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_NAME,'') <> COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段不相等
         OR COALESCE(TM.STL_ACCT_CUST_IN_CD,'') <> COALESCE(BF.STL_ACCT_CUST_IN_CD,'') -- 结算账户客户内码 非主键字段不相等
         OR COALESCE(TM.LP_CUST_IN_CD,'') <> COALESCE(BF.LP_CUST_IN_CD,'') -- 法人客户内码 非主键字段不相等
         OR COALESCE(TM.CORP_CUST_IN_CD,'') <> COALESCE(BF.CORP_CUST_IN_CD,'') -- 企业客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.DOC_ISSUE_DT,'') <> COALESCE(BF.DOC_ISSUE_DT,'') -- 证件签发日期 非主键字段不相等
         OR COALESCE(TM.DOC_MATU_DT,'') <> COALESCE(BF.DOC_MATU_DT,'') -- 证件到期日期 非主键字段不相等
         OR COALESCE(TM.REG_CAP,'') <> COALESCE(BF.REG_CAP,'') -- 注册资金 非主键字段不相等
         OR COALESCE(TM.REG_ADDR_DIST_CD,'') <> COALESCE(BF.REG_ADDR_DIST_CD,'') -- 注册地址行政区划代码 非主键字段不相等
         OR COALESCE(TM.REG_ADDR,'') <> COALESCE(BF.REG_ADDR,'') -- 注册地址 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOCTYP_CD,'') <> COALESCE(BF.LP_PRINC_DOCTYP_CD,'') -- 法人负责人证件类型代码 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOC_NO,'') <> COALESCE(BF.LP_PRINC_DOC_NO,'') -- 法人负责人证件号码 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOC_ISSUE_DT,'') <> COALESCE(BF.LP_PRINC_DOC_ISSUE_DT,'') -- 法人负责人证件签发日期 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_DOC_MATU_DT,'') <> COALESCE(BF.LP_PRINC_DOC_MATU_DT,'') -- 法人负责人证件到期日期 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_NAME,'') <> COALESCE(BF.LP_PRINC_NAME,'') -- 法人负责人名称 非主键字段不相等
         OR COALESCE(TM.LP_PRINC_TEL_NO,'') <> COALESCE(BF.LP_PRINC_TEL_NO,'') -- 法人负责人电话号码 非主键字段不相等
         OR COALESCE(TM.LP_DOC_INFO_SETUP_TM_STAMP,'') <> COALESCE(BF.LP_DOC_INFO_SETUP_TM_STAMP,'') -- 法人证件信息建立时间戳 非主键字段不相等
         OR COALESCE(TM.LP_DOC_INFO_MODIF_TM_STAMP,'') <> COALESCE(BF.LP_DOC_INFO_MODIF_TM_STAMP,'') -- 法人证件信息修改时间戳 非主键字段不相等
         OR COALESCE(TM.ASSIS_DOCTYP_CD,'') <> COALESCE(BF.ASSIS_DOCTYP_CD,'') -- 辅助证件类型代码 非主键字段不相等
         OR COALESCE(TM.ASSIS_DOC_NO,'') <> COALESCE(BF.ASSIS_DOC_NO,'') -- 辅助证件号码 非主键字段不相等
         OR COALESCE(TM.ASSIS_DOC_NAME,'') <> COALESCE(BF.ASSIS_DOC_NAME,'') -- 辅助证件名称 非主键字段不相等
         OR COALESCE(TM.CONT_NAME,'') <> COALESCE(BF.CONT_NAME,'') -- 联系人名称 非主键字段不相等
         OR COALESCE(TM.CONT_TEL_NO,'') <> COALESCE(BF.CONT_TEL_NO,'') -- 联系人电话号码 非主键字段不相等
         OR COALESCE(TM.CONT_EMAIL_ADDR,'') <> COALESCE(BF.CONT_EMAIL_ADDR,'') -- 联系人电子邮箱地址 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_NAME_ABB,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NAME_ABB,'') -- 特约商户名称简称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_EN_NAME,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_EN_NAME,'') -- 特约商户英文名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_CATEGORY_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_CATEGORY_CD,'') -- 特约商户类别代码 非主键字段不相等
         OR COALESCE(TM.SAM_CATEGORY_DESC,'') <> COALESCE(BF.SAM_CATEGORY_DESC,'') -- 特约商户类别描述 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_MCLS_CD,'') -- 特约商户场景大类代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_SCENE_SCLS_CD,'') -- 特约商户场景小类代码 非主键字段不相等
         OR COALESCE(TM.INDUS_CATEGORY_NAME,'') <> COALESCE(BF.INDUS_CATEGORY_NAME,'') -- 行业类别名称 非主键字段不相等
         OR COALESCE(TM.INDUS_NAME,'') <> COALESCE(BF.INDUS_NAME,'') -- 行业名称 非主键字段不相等
         OR COALESCE(TM.ZFB_OPER_CAT_CD,'') <> COALESCE(BF.ZFB_OPER_CAT_CD,'') -- 支付宝经营类目代码 非主键字段不相等
         OR COALESCE(TM.WX_CORP_STL_CD,'') <> COALESCE(BF.WX_CORP_STL_CD,'') -- 微信对公结算代码 非主键字段不相等
         OR COALESCE(TM.HELP_FMR_POINT_STAR_LVL_CD,'') <> COALESCE(BF.HELP_FMR_POINT_STAR_LVL_CD,'') -- 助农点星级代码 非主键字段不相等
         OR COALESCE(TM.WEB_MERCHT_REG_URL,'') <> COALESCE(BF.WEB_MERCHT_REG_URL,'') -- 网络商户登记网址 非主键字段不相等
         OR COALESCE(TM.WEB_MERCHT_REG_IP_ADDR,'') <> COALESCE(BF.WEB_MERCHT_REG_IP_ADDR,'') -- 网络商户登记IP地址 非主键字段不相等
         OR COALESCE(TM.WEB_MERCHT_IC_REC_LIC_NO,'') <> COALESCE(BF.WEB_MERCHT_IC_REC_LIC_NO,'') -- 网络商户ICP备案/许可证号 非主键字段不相等
         OR COALESCE(TM.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.WX_COST_SERV_CHARGE_RATE,CAST(0 AS DECIMAL(20,7))) -- 微信成本费率 非主键字段不相等
         OR COALESCE(TM.CUST_SERV_TEL_NO,'') <> COALESCE(BF.CUST_SERV_TEL_NO,'') -- 客服电话号码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LOCAL_PROV_CD,'') -- 实际经营地址所在省份代码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LOCAL_CITY_CD,'') -- 实际经营地址所在市代码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LOCAL_DIST_CD,'') -- 实际经营地址所在区县代码 非主键字段不相等
         OR COALESCE(TM.AOA_LOCAL_TOWN_STREET_CD,'') <> COALESCE(BF.AOA_LOCAL_TOWN_STREET_CD,'') -- 实际经营地址所在镇街道代码 非主键字段不相等
         OR COALESCE(TM.AOA_LOCAL_VILG_COMM_CD,'') <> COALESCE(BF.AOA_LOCAL_VILG_COMM_CD,'') -- 实际经营地址所在村社区代码 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_DESC,'') <> COALESCE(BF.ACTL_OPER_ADDR_DESC,'') -- 实际经营地址 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LATD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LATD,'') -- 实际经营地址纬度 非主键字段不相等
         OR COALESCE(TM.ACTL_OPER_ADDR_LGTD,'') <> COALESCE(BF.ACTL_OPER_ADDR_LGTD,'') -- 实际经营地址经度 非主键字段不相等
         OR COALESCE(TM.TXN_CURR_CD,'') <> COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段不相等
         OR COALESCE(TM.PREFR_DERATE_TYPE_CD,'') <> COALESCE(BF.PREFR_DERATE_TYPE_CD,'') -- 优惠减免类型代码 非主键字段不相等
         OR COALESCE(TM.SMALL_MICRO_MERCHT_TYPE_CD,'') <> COALESCE(BF.SMALL_MICRO_MERCHT_TYPE_CD,'') -- 小微商户类型代码 非主键字段不相等
         OR COALESCE(TM.RISK_ESTIM_LVL_CD,'') <> COALESCE(BF.RISK_ESTIM_LVL_CD,'') -- 风险评估等级代码 非主键字段不相等
         OR COALESCE(TM.EXPAND_MODE_CD,'') <> COALESCE(BF.EXPAND_MODE_CD,'') -- 拓展方式代码 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NO,'') <> COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NAME,'') <> COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段不相等
         OR COALESCE(TM.MATN_TELR_NO,'') <> COALESCE(BF.MATN_TELR_NO,'') -- 维护柜员编号 非主键字段不相等
         OR COALESCE(TM.MATN_TELR_NAME,'') <> COALESCE(BF.MATN_TELR_NAME,'') -- 维护柜员名称 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_CD,'') <> COALESCE(BF.SERV_PROVDER_CD,'') -- 服务商编码 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_NAME,'') <> COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_DOC_NO,'') <> COALESCE(BF.SERV_PROVDER_DOC_NO,'') -- 服务商证件号码 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_TYPE_CD,'') <> COALESCE(BF.SERV_PROVDER_TYPE_CD,'') -- 服务商类型代码 非主键字段不相等
         OR COALESCE(TM.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.DAILY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计转账限额 非主键字段不相等
         OR COALESCE(TM.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MONTHLY_ACCUM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计转账限额 非主键字段不相等
         OR COALESCE(TM.STL_MODE_CD,'') <> COALESCE(BF.STL_MODE_CD,'') -- 结算方式代码 非主键字段不相等
         OR COALESCE(TM.RBSA_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.RBSA_OPEN_ACCT_ORG_NO,'') -- 收单结算账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.RBSA_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.RBSA_OPEN_ACCT_ORG_NAME,'') -- 收单结算账号开户机构名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_TYPE_CD,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_TYPE_CD,'') -- 收单结算账户类型代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_NO,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_NO,'') -- 收单结算账户编号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_NAME,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_NAME,'') -- 收单结算账户名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_CATEGORY_CD,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_CATEGORY_CD,'') -- 收单结算账户类别代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NO,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NO,'') -- 收单结算账户开户行行号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_STL_ACCT_OPBANK_NAME,'') <> COALESCE(BF.RECV_BIL_STL_ACCT_OPBANK_NAME,'') -- 收单结算账户开户行名称 非主键字段不相等
         OR COALESCE(TM.ARBSA_NO,'') <> COALESCE(BF.ARBSA_NO,'') -- 实际收单结算账户编号 非主键字段不相等
         OR COALESCE(TM.ARBSA_NAME,'') <> COALESCE(BF.ARBSA_NAME,'') -- 实际收单结算账户名称 非主键字段不相等
         OR COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NO,'') -- 实际收单结算账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.ARBSA_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.ARBSA_OPEN_ACCT_ORG_NAME,'') -- 实际收单结算账户开户机构名称 非主键字段不相等
         OR COALESCE(TM.ARBSA_TYPE_CD,'') <> COALESCE(BF.ARBSA_TYPE_CD,'') -- 实际收单结算账户类型代码 非主键字段不相等
         OR COALESCE(TM.ARBSA_OPBANK_CNAPS_CODE,'') <> COALESCE(BF.ARBSA_OPBANK_CNAPS_CODE,'') -- 实际收单结算账户开户行人行支付行号 非主键字段不相等
         OR COALESCE(TM.CFEA_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.CFEA_OPEN_ACCT_ORG_NO,'') -- 手续费支出账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') <> COALESCE(BF.COMM_FEE_EXPNT_ACCT_TYPE_CD,'') -- 手续费支出账户类型代码 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_EXPNT_ACCT_NO,'') <> COALESCE(BF.COMM_FEE_EXPNT_ACCT_NO,'') -- 手续费支出账户编号 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_EXPNT_ACCT_NAME,'') <> COALESCE(BF.COMM_FEE_EXPNT_ACCT_NAME,'') -- 手续费支出账户名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') <> COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段不相等
         OR COALESCE(TM.RECV_GOOD_CFM_FLAG,'') <> COALESCE(BF.RECV_GOOD_CFM_FLAG,'') -- 收货确认标志 非主键字段不相等
         OR COALESCE(TM.REFUND_MODE_CD,'') <> COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段不相等
         OR COALESCE(TM.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.REFUND_EACCT_OPEN_ACCT_ORG_NO,'') -- 退款支出账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.REFUND_EXPNT_ACCT_TYPE_CD,'') <> COALESCE(BF.REFUND_EXPNT_ACCT_TYPE_CD,'') -- 退款支出账户类型代码 非主键字段不相等
         OR COALESCE(TM.REFUND_EXPNT_ACCT_ACCT_NO,'') <> COALESCE(BF.REFUND_EXPNT_ACCT_ACCT_NO,'') -- 退款支出账户账户编号 非主键字段不相等
         OR COALESCE(TM.REFUND_EXPNT_ACCT_NAME,'') <> COALESCE(BF.REFUND_EXPNT_ACCT_NAME,'') -- 退款支出账户名称 非主键字段不相等
         OR COALESCE(TM.EXCESS_REFUND_FLAG,'') <> COALESCE(BF.EXCESS_REFUND_FLAG,'') -- 超额退款标志 非主键字段不相等
         OR COALESCE(TM.REFUND_MRGACCT_TYPE_CD,'') <> COALESCE(BF.REFUND_MRGACCT_TYPE_CD,'') -- 退款保证金账户类别代码 非主键字段不相等
         OR COALESCE(TM.REFUND_MRGACCT_NO,'') <> COALESCE(BF.REFUND_MRGACCT_NO,'') -- 退款保证金账户编号 非主键字段不相等
         OR COALESCE(TM.REFUND_MRGACCT_NAME,'') <> COALESCE(BF.REFUND_MRGACCT_NAME,'') -- 退款保证金账户名称 非主键字段不相等
         OR COALESCE(TM.RMACT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.RMACT_OPEN_ACCT_ORG_NO,'') -- 退款保证金账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.RMACT_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.RMACT_OPEN_ACCT_ORG_NAME,'') -- 退款保证金账户开户机构名称 非主键字段不相等
         OR COALESCE(TM.REFUND_MRG_ACCT_NO_TYPE_CD,'') <> COALESCE(BF.REFUND_MRG_ACCT_NO_TYPE_CD,'') -- 退款保证金账号类型代码 非主键字段不相等
         OR COALESCE(TM.TERROR_ACT_LIST_FLAG,'') <> COALESCE(BF.TERROR_ACT_LIST_FLAG,'') -- 恐怖活动名单标志 非主键字段不相等
         OR COALESCE(TM.CO_MODE_CD,'') <> COALESCE(BF.CO_MODE_CD,'') -- 合作模式代码 非主键字段不相等
         OR COALESCE(TM.BIZ_PROD_PRVLG_CD,'') <> COALESCE(BF.BIZ_PROD_PRVLG_CD,'') -- 业务产品权限代码 非主键字段不相等
         OR COALESCE(TM.ESCR_MERCHT_FLAG,'') <> COALESCE(BF.ESCR_MERCHT_FLAG,'') -- 特殊费率商户标志 非主键字段不相等
         OR COALESCE(TM.PRFT_CUT_FLAG,'') <> COALESCE(BF.PRFT_CUT_FLAG,'') -- 分润标志 非主键字段不相等
         OR COALESCE(TM.INSTALLMENT_MERCHT_FLAG,'') <> COALESCE(BF.INSTALLMENT_MERCHT_FLAG,'') -- 分期商户标志 非主键字段不相等
         OR COALESCE(TM.POS_MERCHT_FLAG,'') <> COALESCE(BF.POS_MERCHT_FLAG,'') -- POS商户标志 非主键字段不相等
         OR COALESCE(TM.POS_MIGRATE_MERCHT_FLAG,'') <> COALESCE(BF.POS_MIGRATE_MERCHT_FLAG,'') -- POS迁移商户标志 非主键字段不相等
         OR COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') <> COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段不相等
         OR COALESCE(TM.SAM_OPER_APP_TYPE_CD,'') <> COALESCE(BF.SAM_OPER_APP_TYPE_CD,'') -- 特约商户操作申请类型代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_STATUS_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_STATUS_CD,'') -- 特约商户状态代码 非主键字段不相等
         OR COALESCE(TM.SAM_AUDIT_STAT_CD,'') <> COALESCE(BF.SAM_AUDIT_STAT_CD,'') -- 特约商户审核状态代码 非主键字段不相等
         OR COALESCE(TM.SUBMIT_APP_MODE_CD,'') <> COALESCE(BF.SUBMIT_APP_MODE_CD,'') -- 进件方式代码 非主键字段不相等
         OR COALESCE(TM.SUBMIT_APP_TYPE_CD,'') <> COALESCE(BF.SUBMIT_APP_TYPE_CD,'') -- 进件类型代码 非主键字段不相等
         OR COALESCE(TM.PRE_COL_INFO_SER_NO,'') <> COALESCE(BF.PRE_COL_INFO_SER_NO,'') -- 预采集信息流水号 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM_STAMP,'') <> COALESCE(BF.OPEN_ACCT_TM_STAMP,'') -- 开户时间戳 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TM_STAMP,'') <> COALESCE(BF.CANC_ACCT_TM_STAMP,'') -- 销户时间戳 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.AUDIT_NO,'') <> COALESCE(BF.AUDIT_NO,'') -- 审核编号 非主键字段不相等
         OR COALESCE(TM.AUDIT_TM_STAMP,'') <> COALESCE(BF.AUDIT_TM_STAMP,'') -- 审核时间戳 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') <> COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_RSN_CD,'') <> COALESCE(BF.CANC_ACCT_RSN_CD,'') -- 销户原因代码 非主键字段不相等
         OR COALESCE(TM.AUDIT_FAIL_RSN,'') <> COALESCE(BF.AUDIT_FAIL_RSN,'') -- 审核失败原因 非主键字段不相等
         OR COALESCE(TM.INPUT_TELR_NO,'') <> COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段不相等
         OR COALESCE(TM.INPUT_ORG_NO,'') <> COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.MIGRATE_MERCHT_IDNT_CD,'') <> COALESCE(BF.MIGRATE_MERCHT_IDNT_CD,'') -- 迁移商户标识代码 非主键字段不相等
         OR COALESCE(TM.MIGRATE_TM_STAMP,'') <> COALESCE(BF.MIGRATE_TM_STAMP,'') -- 迁移时间戳 非主键字段不相等
         OR COALESCE(TM.FRZ_RSN_REM,'') <> COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段不相等
         OR COALESCE(TM.RECNT_FRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM;
DROP TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_TF_TM_01;
DROP TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCPNI_TF_TM_01;
DROP TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCADI_TF_TM_01;
DROP TABLE AGL${version_num}.TMP_ODS_CORE_BCFMCIDI_IDNOCFNO_TF_TM_01;
DROP TABLE AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_01;
DROP TABLE AGL${version_num}.TMP_AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF_TM_05;
