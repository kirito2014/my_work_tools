-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人数字货币钱包动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA
--     表中文名：个人数字货币钱包动账交易明细聚合
--     创建日期：2024-06-24 00:00:00
--     主键字段：CORE_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-06-24 00:00:00 魏丹丹 新增
--         2024-10-16 00:00:00 魏丹丹 生产问题修复，入湖补入字段同步



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '个人数字货币钱包动账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CORE_SER_NO -- 核心流水号
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,PLAT_BATCH_NO -- 平台批次编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,CNT_CURR_TXN_STATUS_CD -- 数币交易状态代码
    ,CNT_CURR_TXN_MODE_CD -- 数币交易方式代码
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,USER_ID -- 用户id
    ,CUST_IN_CD -- 客户内码
    ,BANK_CARD_NO -- 银行卡号
    ,OPEN_CARD_ORG_NO -- 开卡机构编号
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,WALLET_NO -- 钱包编号
    ,WALLET_NAME -- 钱包名称
    ,WALLET_TYPE_CD -- 钱包类型代码
    ,WALLET_LVL_CD -- 钱包等级代码
    ,WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,TRNOUT_WALLET_NO -- 转出钱包编号
    ,TRPS_PTY_OPER_ORG_NO -- 转出方运营机构编号
    ,TRNOUT_WALLET_TYPE_CD -- 转出钱包类型代码
    ,TRNOUT_WALLET_LVL_CD -- 转出钱包等级代码
    ,TRNOUT_WALLET_NAME -- 转出钱包名称
    ,TRNOUT_ACCT_NO -- 转出账户编号
    ,CNT_CURR_TRNOUT_ACT_TP_CD -- 数币转出账户类型代码
    ,TRNOUT_ACCT_NAME -- 转出账户名称
    ,TRNOUT_ACCT_NO_HANG_AGT_NO -- 转出账号挂接协议编号
    ,TRNIN_WALLET_NO -- 转入钱包编号
    ,TRANEE_OPER_ORG_NO -- 转入方运营机构编号（待治理）
    ,TRNIN_WALLET_TYPE_CD -- 转入钱包类型代码
    ,TRNIN_WALLET_LVL_CD -- 转入钱包等级代码
    ,TRNIN_WALLET_NAME -- 转入钱包名称
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,CNT_CURR_TRNIN_ACT_TP_CD -- 数币转入账户类型代码
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NAME -- 商户名称
    ,FUND_COL_OPER_ORG_MERCHT_NO -- 收款运营机构商户编号
    ,CNT_CURR_PAY_TYPE_CD -- 数币支付类型代码
    ,SHOULD_STL_AMT -- 应结金额
    ,GEN_GOLD_COPN_AMT -- 代金券金额
    ,TERMN_NO -- 终端编号
    ,CNT_CURR_SCENE_TYPE_CD -- 数币场景类型代码
    ,CHNL_MERCHT_SER_NO -- 渠道商户流水号
    ,CHNL_MERCHT_FLOW_TM_STAMP -- 渠道商户流水时间戳
    ,FUND_COL_OPER_ORG_ORDER_NO -- 收款运营机构订单编号
    ,ORDER_PAY_CMPLT_TM_STAMP -- 订单支付完成时间戳
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,ORIG_CHNL_MERCHT_SER_NO -- 原渠道商户流水号
    ,ORIG_CHNL_MERCHT_FLOW_TM_STAMP -- 原渠道商户流水时间戳
    ,ORIG_COL_OPORG_ORDER_NO -- 原收款运营机构订单编号
    ,ORIG_CNT_CURR_PAY_TYPE_CD -- 原数币支付类型代码
    ,DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,SYS_CD -- 系统代码
    ,ANALY_CHNL_CD -- 分析渠道代码
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,OPERR_MOBILE_NO -- 经办人手机号码
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人数字货币钱包动账交易明细聚合

INSERT INTO TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA_TM(
     CORE_SER_NO -- 核心流水号
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,PLAT_BATCH_NO -- 平台批次编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,CNT_CURR_TXN_STATUS_CD -- 数币交易状态代码
    ,CNT_CURR_TXN_MODE_CD -- 数币交易方式代码
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,USER_ID -- 用户id
    ,CUST_IN_CD -- 客户内码
    ,BANK_CARD_NO -- 银行卡号
    ,OPEN_CARD_ORG_NO -- 开卡机构编号
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,WALLET_NO -- 钱包编号
    ,WALLET_NAME -- 钱包名称
    ,WALLET_TYPE_CD -- 钱包类型代码
    ,WALLET_LVL_CD -- 钱包等级代码
    ,WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,TRNOUT_WALLET_NO -- 转出钱包编号
    ,TRPS_PTY_OPER_ORG_NO -- 转出方运营机构编号
    ,TRNOUT_WALLET_TYPE_CD -- 转出钱包类型代码
    ,TRNOUT_WALLET_LVL_CD -- 转出钱包等级代码
    ,TRNOUT_WALLET_NAME -- 转出钱包名称
    ,TRNOUT_ACCT_NO -- 转出账户编号
    ,CNT_CURR_TRNOUT_ACT_TP_CD -- 数币转出账户类型代码
    ,TRNOUT_ACCT_NAME -- 转出账户名称
    ,TRNOUT_ACCT_NO_HANG_AGT_NO -- 转出账号挂接协议编号
    ,TRNIN_WALLET_NO -- 转入钱包编号
    ,TRANEE_OPER_ORG_NO -- 转入方运营机构编号（待治理）
    ,TRNIN_WALLET_TYPE_CD -- 转入钱包类型代码
    ,TRNIN_WALLET_LVL_CD -- 转入钱包等级代码
    ,TRNIN_WALLET_NAME -- 转入钱包名称
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,CNT_CURR_TRNIN_ACT_TP_CD -- 数币转入账户类型代码
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NAME -- 商户名称
    ,FUND_COL_OPER_ORG_MERCHT_NO -- 收款运营机构商户编号
    ,CNT_CURR_PAY_TYPE_CD -- 数币支付类型代码
    ,SHOULD_STL_AMT -- 应结金额
    ,GEN_GOLD_COPN_AMT -- 代金券金额
    ,TERMN_NO -- 终端编号
    ,CNT_CURR_SCENE_TYPE_CD -- 数币场景类型代码
    ,CHNL_MERCHT_SER_NO -- 渠道商户流水号
    ,CHNL_MERCHT_FLOW_TM_STAMP -- 渠道商户流水时间戳
    ,FUND_COL_OPER_ORG_ORDER_NO -- 收款运营机构订单编号
    ,ORDER_PAY_CMPLT_TM_STAMP -- 订单支付完成时间戳
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,ORIG_CHNL_MERCHT_SER_NO -- 原渠道商户流水号
    ,ORIG_CHNL_MERCHT_FLOW_TM_STAMP -- 原渠道商户流水时间戳
    ,ORIG_COL_OPORG_ORDER_NO -- 原收款运营机构订单编号
    ,ORIG_CNT_CURR_PAY_TYPE_CD -- 原数币支付类型代码
    ,DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,SYS_CD -- 系统代码
    ,ANALY_CHNL_CD -- 分析渠道代码
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,OPERR_MOBILE_NO -- 经办人手机号码
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CORE_TXN_SSN AS CORE_SER_NO -- 核心流水号
    ,P1.ORIG_CORE_TXN_SSN AS CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,unifiedTime1(P1.CORE_TXN_TIME) AS CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,unifiedTime1(P1.ORIG_CORE_TXN_TIME) AS ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,P1.CHNL_REQ_TXN_SSN AS CHNL_SER_NO -- 渠道流水号
    ,P1.ORIG_ORDER_TXN_SSN AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,unifiedTime1(P1.CHNL_REQ_TXN_TIME) AS CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,unifiedTime1(P1.ORIG_ORDER_TXN_TIME) AS ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,P1.TXN_TRACE_ID AS TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,P1.BATCH_ID AS PLAT_BATCH_NO -- 平台批次编号
    ,unifiedTime1(P1.GMT_CREATE) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime1(P1.GMT_MODIFIED) AS MODIF_TM_STAMP -- 修改时间戳
    ,unifiedTime1(P1.TXN_EXPIRE_TIME) AS TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,P1.TXN_TYPE_NO AS DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,P1.TXN_SUB_TYPE_NO AS DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,P1.TXN_AMT AS TXN_AMT -- 交易金额
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,P1.TXN_STATE AS CNT_CURR_TXN_STATUS_CD -- 数币交易状态代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.PR_TRY ELSE '' END AS CNT_CURR_TXN_MODE_CD -- 数币交易方式代码
    ,P1.ERROR_CODE AS ERR_CD -- 错误编码
    ,P1.ERROR_MSG AS ERR_DESC -- 错误描述
    ,P1.BIZ_TYP AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,P1.BIZ_KIND AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,P1.CUST_ID AS USER_ID -- 用户id
    ,P3.CST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.ACCT AS BANK_CARD_NO -- 银行卡号
    ,P1.SGN_ORG_NO AS OPEN_CARD_ORG_NO -- 开卡机构编号
    ,P1.TRANS_ORG_ID AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P1.WLT_ID AS WALLET_NO -- 钱包编号
    ,P4.WLT_NM AS WALLET_NAME -- 钱包名称
    ,P4.WLT_TP AS WALLET_TYPE_CD -- 钱包类型代码
    ,P4.WLT_LVL AS WALLET_LVL_CD -- 钱包等级代码
    ,P4.WLT_STS AS WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_WLT_ID 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_WLT_ID
ELSE '' END AS TRNOUT_WALLET_NO -- 转出钱包编号
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_PTY_ID 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_PTY_ID
ELSE '' END AS TRPS_PTY_OPER_ORG_NO -- 转出方运营机构编号
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_WLT_TP 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_WLT_TP
ELSE '' END AS TRNOUT_WALLET_TYPE_CD -- 转出钱包类型代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_WLT_LVL 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_WLT_LVL
ELSE '' END AS TRNOUT_WALLET_LVL_CD -- 转出钱包等级代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P5.DBTR_WLT_NM 
ELSE '' END AS TRNOUT_WALLET_NAME -- 转出钱包名称
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_ACCT 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_ACCT
ELSE '' END AS TRNOUT_ACCT_NO -- 转出账户编号
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P5.DBTR_ACCT_TP 
ELSE '' END AS CNT_CURR_TRNOUT_ACT_TP_CD -- 数币转出账户类型代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_ACCT_NM 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_ACCT_NM
ELSE '' END AS TRNOUT_ACCT_NAME -- 转出账户名称
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.DBTR_SGN_NO 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.DBTR_SGN_NO
ELSE '' END AS TRNOUT_ACCT_NO_HANG_AGT_NO -- 转出账号挂接协议编号
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.CDTR_WLT_ID 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.CDTR_WLT_ID
ELSE '' END AS TRNIN_WALLET_NO -- 转入钱包编号
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.CDTR_PTY_ID 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.CDTR_PTY_ID
ELSE '' END AS TRANEE_OPER_ORG_NO -- 转入方运营机构编号（待治理）
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.CDTR_WLT_TP 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.CDTR_WLT_TP
ELSE '' END AS TRNIN_WALLET_TYPE_CD -- 转入钱包类型代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.CDTR_WLT_LVL 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.CDTR_WLT_LVL
ELSE '' END AS TRNIN_WALLET_LVL_CD -- 转入钱包等级代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P5.CDTR_WLT_NM 
ELSE '' END AS TRNIN_WALLET_NAME -- 转入钱包名称
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.CDTR_ACCT 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.CDTR_ACCT
ELSE '' END AS TRNIN_ACCT_NO -- 转入账户编号
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P5.CDTR_ACCT_TP 
ELSE '' END AS CNT_CURR_TRNIN_ACT_TP_CD -- 数币转入账户类型代码
    ,CASE WHEN P1.TXN_TYPE_NO = 'CHN0021' THEN P2.CDTR_ACCT_NM 
WHEN P1.TXN_TYPE_NO IN ('CHN0013','CHN0015','CHN1012','CHN1013','CHN3001','NDPS.221.001.01','NDPS.225.001.01','NDPS.801.001.01') THEN P5.CDTR_ACCT_NM
ELSE '' END AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'' AS FUND_COL_OPER_ORG_MERCHT_NO -- 收款运营机构商户编号
    ,'' AS CNT_CURR_PAY_TYPE_CD -- 数币支付类型代码
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS GEN_GOLD_COPN_AMT -- 代金券金额
    ,'' AS TERMN_NO -- 终端编号
    ,'' AS CNT_CURR_SCENE_TYPE_CD -- 数币场景类型代码
    ,'' AS CHNL_MERCHT_SER_NO -- 渠道商户流水号
    ,'' AS CHNL_MERCHT_FLOW_TM_STAMP -- 渠道商户流水时间戳
    ,'' AS FUND_COL_OPER_ORG_ORDER_NO -- 收款运营机构订单编号
    ,'' AS ORDER_PAY_CMPLT_TM_STAMP -- 订单支付完成时间戳
    ,'' AS ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,'' AS ORIG_CHNL_MERCHT_SER_NO -- 原渠道商户流水号
    ,'' AS ORIG_CHNL_MERCHT_FLOW_TM_STAMP -- 原渠道商户流水时间戳
    ,'' AS ORIG_COL_OPORG_ORDER_NO -- 原收款运营机构订单编号
    ,'' AS ORIG_CNT_CURR_PAY_TYPE_CD -- 原数币支付类型代码
    ,P1.CHNL_NO AS DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,P1.PAGY_NO AS WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,P1.SYSTEM_ID AS SYS_CD -- 系统代码
    ,P1.ANAY_CHNL_ID AS ANALY_CHNL_CD -- 分析渠道代码
    ,P1.RSPB_PSN_NM AS OPERR_NAME -- 经办人名称
    ,P1.RSPB_PSN_ID_TP AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,P1.RSPB_PSN_ID_NO AS OPERR_DOC_NO -- 经办人证件号码
    ,P1.RSPB_PSN_TEL AS OPERR_MOBILE_NO -- 经办人手机号码
    ,P1.OPERATOR_ID AS VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,'DCEPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_DCEPS_CORE_TXN_SSN_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_DCEPS.ODS_DCEPS_CORE_TXN_SSN_TA AS P1 -- 核心业务交易流水表

LEFT JOIN ODS_DCEPS.ODS_DCEPS_WLT_ACCT_BIZ_LOG_TA AS P2 -- 钱包账务业务流水
       ON P1.CORE_TXN_SSN = P2.CORE_TXN_SSN1 AND P2.DEL_F = '0' AND P2.PT_DT='${process_date}' 
LEFT JOIN ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF AS P3 -- 用户信息表
       ON P1.CUST_ID = P3.USER_ID  AND P3.DEL_F = '0'  AND P3.PT_DT='${process_date}' 
LEFT JOIN (
SELECT
 WII.WLT_NM
,WII.WLT_TP
,WII.WLT_LVL
,WII.WLT_STS
,WII.WLT_ID
,ROW_NUMBER()OVER(PARTITION BY WLT_ID ORDER BY ID DESC) RN
FROM ODS_DCEPS.ODS_DCEPS_WLT_INDV_INF_TF WII -- 对私钱包信息
WHERE WII.DEL_F = '0' AND WII.PT_DT='${process_date}'
) AS P4 -- 对私钱包信息
       ON P1.WLT_ID = P4.WLT_ID  AND P4.RN = 1 
LEFT JOIN ODS_DCEPS.ODS_DCEPS_FUND_INDV_ACCT_TXN_TA AS P5 -- 资金交易流水
       ON P1.CORE_TXN_SSN = P5.CORE_TXN_SSN  AND P5.DEL_F = '0'  AND P5.PT_DT='${process_date}' 
WHERE P1.PT_DT = '${process_date}'  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     CORE_SER_NO -- 核心流水号
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,CHNL_SER_NO -- 渠道流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,PLAT_BATCH_NO -- 平台批次编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,CNT_CURR_TXN_STATUS_CD -- 数币交易状态代码
    ,CNT_CURR_TXN_MODE_CD -- 数币交易方式代码
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,USER_ID -- 用户id
    ,CUST_IN_CD -- 客户内码
    ,BANK_CARD_NO -- 银行卡号
    ,OPEN_CARD_ORG_NO -- 开卡机构编号
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,WALLET_NO -- 钱包编号
    ,WALLET_NAME -- 钱包名称
    ,WALLET_TYPE_CD -- 钱包类型代码
    ,WALLET_LVL_CD -- 钱包等级代码
    ,WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,TRNOUT_WALLET_NO -- 转出钱包编号
    ,TRPS_PTY_OPER_ORG_NO -- 转出方运营机构编号
    ,TRNOUT_WALLET_TYPE_CD -- 转出钱包类型代码
    ,TRNOUT_WALLET_LVL_CD -- 转出钱包等级代码
    ,TRNOUT_WALLET_NAME -- 转出钱包名称
    ,TRNOUT_ACCT_NO -- 转出账户编号
    ,CNT_CURR_TRNOUT_ACT_TP_CD -- 数币转出账户类型代码
    ,TRNOUT_ACCT_NAME -- 转出账户名称
    ,TRNOUT_ACCT_NO_HANG_AGT_NO -- 转出账号挂接协议编号
    ,TRNIN_WALLET_NO -- 转入钱包编号
    ,TRANEE_OPER_ORG_NO -- 转入方运营机构编号（待治理）
    ,TRNIN_WALLET_TYPE_CD -- 转入钱包类型代码
    ,TRNIN_WALLET_LVL_CD -- 转入钱包等级代码
    ,TRNIN_WALLET_NAME -- 转入钱包名称
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,CNT_CURR_TRNIN_ACT_TP_CD -- 数币转入账户类型代码
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,MERCHT_NAME -- 商户名称
    ,FUND_COL_OPER_ORG_MERCHT_NO -- 收款运营机构商户编号
    ,CNT_CURR_PAY_TYPE_CD -- 数币支付类型代码
    ,SHOULD_STL_AMT -- 应结金额
    ,GEN_GOLD_COPN_AMT -- 代金券金额
    ,TERMN_NO -- 终端编号
    ,CNT_CURR_SCENE_TYPE_CD -- 数币场景类型代码
    ,CHNL_MERCHT_SER_NO -- 渠道商户流水号
    ,CHNL_MERCHT_FLOW_TM_STAMP -- 渠道商户流水时间戳
    ,FUND_COL_OPER_ORG_ORDER_NO -- 收款运营机构订单编号
    ,ORDER_PAY_CMPLT_TM_STAMP -- 订单支付完成时间戳
    ,ORDER_INVALID_TM_STAMP -- 订单失效时间戳
    ,ORIG_CHNL_MERCHT_SER_NO -- 原渠道商户流水号
    ,ORIG_CHNL_MERCHT_FLOW_TM_STAMP -- 原渠道商户流水时间戳
    ,ORIG_COL_OPORG_ORDER_NO -- 原收款运营机构订单编号
    ,ORIG_CNT_CURR_PAY_TYPE_CD -- 原数币支付类型代码
    ,DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,SYS_CD -- 系统代码
    ,ANALY_CHNL_CD -- 分析渠道代码
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,OPERR_MOBILE_NO -- 经办人手机号码
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA_TM;
