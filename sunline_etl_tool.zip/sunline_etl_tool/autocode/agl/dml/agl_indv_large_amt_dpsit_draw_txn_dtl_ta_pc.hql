-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人大额存取款交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA
--     表中文名：个人大额存取款交易明细聚合
--     创建日期：2024-05-18 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：翟向阳
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-17 00:00:00 翟向阳 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA_TM
USING ORC
COMMENT '个人大额存取款交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,DEBIT_CARD_NO -- 借记卡编号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,TXN_ORG_NO -- 交易机构编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,CNTPTY_BANK_NAME -- 对方行名
    ,CNTPTY_BANK_NO -- 对方行号
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,TELR_SER_NO -- 柜员流水号
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人大额存取款交易明细聚合

INSERT INTO TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,DEBIT_CARD_NO -- 借记卡编号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,TXN_ORG_NO -- 交易机构编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,CNTPTY_BANK_NAME -- 对方行名
    ,CNTPTY_BANK_NO -- 对方行号
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,TELR_SER_NO -- 柜员流水号
    ,REM -- 备注
    ,SRC_SYS_CD       -- 来源系统代码
    ,SRC_TAB_EN_NAME  -- 来源表英文名称
    ,GRP_SER_NO       -- 组序号         
)
SELECT
     P1.BB06TXSN AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.BB23TSSN AS SUB_TXN_SER_NO -- 子交易流水号
    ,unifiedTime(P1.BB05DATE) AS TXN_DT -- 交易日期
    ,CASE WHEN P1.BB07SSMK='6' THEN COALESCE(P1.BB31RMRK,P1.BB01AC15)
ELSE P1.BB01AC15
END AS ACCT_NO -- 账户编号
    ,P1.BB08FLNM AS ACCT_NAME -- 账户名称
    ,P1.BB01AC15 AS DEBIT_CARD_NO -- 借记卡编号
    ,P1.BB03CCYC AS CURR_CD -- 币种代码
    ,P1.BB04CHSX AS CASH_RMT_CD -- 钞汇代码
    ,P1.BB10CSNO AS CUST_IN_CD -- 客户内码
    ,P3.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,P3.CRTF_NO AS DOC_NO -- 证件号码
    ,P1.BB07SSMK AS DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,CASE WHEN P1.BB11CDFG IS NULL OR TRIM(P1.BB11CDFG)='' 
     THEN '' 
ELSE COALESCE(TRIM(M1.TARGET_CD_VAL),'') END  AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.BB13JYLB AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P4.CH_AID AS TXN_CHNL_CD -- 交易渠道代码
    ,P4.TEL_TXID AS TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,P4.SYS_TXID AS TRAN_CD -- 交易码
    ,P1.BB12AMT AS TXN_AMT -- 交易金额
    ,P1.BB21STAF AS TXN_TELR_NO -- 交易柜员编号
    ,P1.BB30STAF AS AUTH_TELR_NO -- 授权柜员编号
    ,P1.BB22BRNO AS TXN_ORG_NO -- 交易机构编号
    ,P1.BB17AC32 AS CNTPTY_ACCT_NO -- 对方账户编号
    ,P1.BB18FLNM AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,P1.BB19FLNM AS CNTPTY_BANK_NAME -- 对方行名
    ,P1.BB20BK20 AS CNTPTY_BANK_NO -- 对方行号
    ,P1.BB14FLNM AS OPERR_NAME -- 经办人名称
    ,P1.BB15CFTP AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,P1.BB16CFNO AS OPERR_DOC_NO -- 经办人证件号码
    ,P1.BB26BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.BB25BRNO AS LP_ORG_NO -- 法人机构编号
    ,P1.BB24SN11 AS TELR_SER_NO -- 柜员流水号
    ,P1.BB31RMRK AS REM -- 备注
    ,'CORE' AS SRC_SYS_CD       -- 来源系统代码
    ,'ODS_CORE_BDFMHQBB_TA' AS SRC_TAB_EN_NAME  -- 来源表英文名称
    ,1 AS GRP_SER_NO       -- 组序号         
FROM
ods_core.ODS_CORE_BDFMHQBB_TA AS P1 -- 大额存取款登记簿

LEFT JOIN (SELECT CST_IN_CD,CRTF_NO,CRTF_TYP,ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC ) AS NUM1 
FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF 
WHERE MAJOR_FLG='1' AND DELETED = '0' AND PT_DT='${process_date}'  AND DEL_F = '0') AS P3 -- 客户证件信息表
       ON P3.CST_IN_CD = P1.BB10CSNO AND P3.NUM1=1 
LEFT JOIN ods_core.ODS_CORE_BYFTJRN_TA AS P4 -- 会计流水文件
       ON unifiedTime(P1.BB05DATE) =unifiedTime(P4.TX_DATE) AND P1.BB06TXSN =P4.BTX_JNO AND P1.BB23TSSN =P4.ATX_JNO AND P4.PT_DT='${process_date}'  AND P4.DEL_F = '0' AND P1.BB01AC15 =P4.ACC_NO 
LEFT JOIN AGL.PUB_CD_MAP AS M1 -- 码值表
       ON P1.BB11CDFG=M1.SRC_CD_VAL  
AND M1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
AND M1.SRC_TAB_EN_NAME='BDFMHQBB' --来源表英文名 大写
AND M1.SRC_FIELD_EN_NAME='BB11CDFG' --来源字段英文名 大写
AND M1.TARGET_TAB_EN_NAME='AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA' --目标表名 大写
AND M1.TARGET_FIELD_EN_NAME='DEBIT_CRDT_DIR_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}'  AND P1.DEL_F = '0'  AND  ((P1.BB07SSMK='1' AND SUBSTR(P1.BB01AC15,1,1) = '1'   AND P1.RCSTRS1B <> '9' )
   OR (P1.BB07SSMK='2' AND SUBSTR(P1.BB01AC15,1,1) = '1'   AND P1.RCSTRS1B <> '9' )
   OR P1.BB07SSMK='6' AND P1.RCSTRS1B <> '9'
   OR P1.BB07SSMK=' ' AND P1.RCSTRS1B <> '9')
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,DEBIT_CARD_NO -- 借记卡编号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,TXN_ORG_NO -- 交易机构编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,CNTPTY_BANK_NAME -- 对方行名
    ,CNTPTY_BANK_NO -- 对方行号
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,TELR_SER_NO -- 柜员流水号
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA_TM;
