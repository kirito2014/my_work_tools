-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人存款账户计提利息明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA
--     表中文名：个人存款账户计提利息明细聚合
--     创建日期：2024-04-23 00:00:00
--     主键字段：ACCT_NO, EXCH_GATHER_ACCT_SER_NO, CURR_CD, ACRU_DT, CASH_RMT_CD
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         龙耀超 2024-04-23 00:00:00 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM
USING ORC
COMMENT '个人存款账户计提利息明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ACCT_NO -- 账户编号
    ,EXCH_GATHER_ACCT_SER_NO -- 汇集账户序号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACRU_DT -- 计提日期
    ,CUST_IN_CD -- 客户内码
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_DPSTRCP_FLAG -- 活期存单标志
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PERIOD -- 存期
    ,ACRU_INT -- 计提利息
    ,RGL_INT -- 定期利息
    ,RGL_INT_RATE -- 定期利率
    ,CURR_INT -- 活期利息
    ,CURR_INT_RATE -- 活期利率
    ,ADJ_INT -- 调整利息
    ,DPSIT_BAL -- 存款余额
    ,DPSIT_BAL_ACCUM -- 存款余额积数
    ,VAL_DT -- 起息日期
    ,OPEN_ACCT_DT -- 开户日期
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人存款账户计提利息聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM(
     ACCT_NO -- 账户编号
    ,EXCH_GATHER_ACCT_SER_NO -- 汇集账户序号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACRU_DT -- 计提日期
    ,CUST_IN_CD -- 客户内码
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_DPSTRCP_FLAG -- 活期存单标志
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PERIOD -- 存期
    ,ACRU_INT -- 计提利息
    ,RGL_INT -- 定期利息
    ,RGL_INT_RATE -- 定期利率
    ,CURR_INT -- 活期利息
    ,CURR_INT_RATE -- 活期利率
    ,ADJ_INT -- 调整利息
    ,DPSIT_BAL -- 存款余额
    ,DPSIT_BAL_ACCUM -- 存款余额积数
    ,VAL_DT -- 起息日期
    ,OPEN_ACCT_DT -- 开户日期
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CI01AC15 AS ACCT_NO -- 账户编号
    ,P1.CI11NO40 AS EXCH_GATHER_ACCT_SER_NO -- 汇集账户序号
    ,P2.AA04FLNM AS ACCT_NAME -- 账户名称
    ,P1.CI02CCYC AS CURR_CD -- 币种代码
    ,P1.CI03CHSX AS CASH_RMT_CD -- 钞汇代码
    ,SUBSTR(unifiedTime(P1.CI04DATE),1,10) AS ACRU_DT -- 计提日期
    ,P1.CI16CSNO AS CUST_IN_CD -- 客户内码
    ,P1.CI12FLAG AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,P1.CI13FLAG AS CURR_DPSTRCP_FLAG -- 活期存单标志
    ,P1.CI14PDTP||P1.CI15PRON AS DPSIT_PROD_CD -- 存款产品代码
    ,P3.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,P4.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P4.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.CI18SN03 AS DPSIT_PERIOD -- 存期
    ,P1.CI05IAMT AS ACRU_INT -- 计提利息
    ,P1.CI06IAMT AS RGL_INT -- 定期利息
    ,P1.CI23RATE AS RGL_INT_RATE -- 定期利率
    ,P1.CI07IAMT AS CURR_INT -- 活期利息
    ,P1.CI24RATE AS CURR_INT_RATE -- 活期利率
    ,P1.CI08IAMT AS ADJ_INT -- 调整利息
    ,P1.CI09IAMT AS DPSIT_BAL -- 存款余额
    ,P1.CI10CMBL AS DPSIT_BAL_ACCUM -- 存款余额积数
    ,SUBSTR(unifiedTime(P1.CI21DATE),1,10) AS VAL_DT -- 起息日期
    ,SUBSTR(unifiedTime(P1.CI22DATE),1,10) AS OPEN_ACCT_DT -- 开户日期
    ,P1.CI19BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.CI20BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN P1.RCSTRS1B='' OR P1.RCSTRS1B IS NULL THEN '0' ELSE P1.RCSTRS1B END AS REC_STATUS_CD -- 记录状态代码
    ,SUBSTR(unifiedTime(P1.BUDIDATE),1,10) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.BUTSSTAM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.BUTPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BFFMDQCI_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE.ODS_CORE_BFFMDQCI_TA AS P1 -- 账户计提利息明细表（每日计提）

LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款帐户主档
       ON P1.CI01AC15 = P2.AA01AC15 AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQCW_TF AS P3 -- 产品代码名称表
       ON P3.CW03PRON = P1.CI15PRON  AND P3.CW02PDTP = P1.CI14PDTP AND P3.PT_DT='${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BGFDKHDZ_TF AS P4 -- 新会计科目核算码对照表
       ON P4.KHDBACID = P1.CI17ACID AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
WHERE SUBSTR(P1.CI01AC15,1,1) ='1'  AND P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 个人存款账户计提利息聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM(
     ACCT_NO -- 账户编号
    ,EXCH_GATHER_ACCT_SER_NO -- 汇集账户序号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACRU_DT -- 计提日期
    ,CUST_IN_CD -- 客户内码
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_DPSTRCP_FLAG -- 活期存单标志
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PERIOD -- 存期
    ,ACRU_INT -- 计提利息
    ,RGL_INT -- 定期利息
    ,RGL_INT_RATE -- 定期利率
    ,CURR_INT -- 活期利息
    ,CURR_INT_RATE -- 活期利率
    ,ADJ_INT -- 调整利息
    ,DPSIT_BAL -- 存款余额
    ,DPSIT_BAL_ACCUM -- 存款余额积数
    ,VAL_DT -- 起息日期
    ,OPEN_ACCT_DT -- 开户日期
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ACCTNO AS ACCT_NO -- 账户编号
    ,'' AS EXCH_GATHER_ACCT_SER_NO -- 汇集账户序号
    ,P2.ACCTNA AS ACCT_NAME -- 账户名称
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P2.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,SUBSTR(unifiedTime(P1.CABRDT),1,10) AS ACRU_DT -- 计提日期
    ,P3.CUSTCD AS CUST_IN_CD -- 客户内码
    ,P4.PDDPFG AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,'' AS CURR_DPSTRCP_FLAG -- 活期存单标志
    ,P1.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,P4.PRODTX AS DPSIT_PROD_NAME -- 存款产品名称
    ,P5.SUBJECT AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P5.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P2.DEPTTM AS DPSIT_PERIOD -- 存期
    ,P1.CABRIN AS ACRU_INT -- 计提利息
    ,CASE WHEN P4.PDDPFG='0205' THEN CAST(P1.CABRIN AS STRING) ELSE NULL END AS RGL_INT -- 定期利息
    ,CASE WHEN P4.PDDPFG='0205' THEN CAST(P1.INTRVL AS STRING) ELSE NULL END AS RGL_INT_RATE -- 定期利率
    ,CASE WHEN P4.PDDPFG='0204' THEN CAST(P1.CABRIN AS STRING) ELSE NULL END AS CURR_INT -- 活期利息
    ,CASE WHEN P4.PDDPFG='0204' THEN CAST(P1.INTRVL AS STRING) ELSE NULL END AS CURR_INT_RATE -- 活期利率
    ,NULL AS ADJ_INT -- 调整利息
    ,P2.ONLNBL AS DPSIT_BAL -- 存款余额
    ,P1.ACMLTN AS DPSIT_BAL_ACCUM -- 存款余额积数
    ,SUBSTR(unifiedTime(P2.BGINDT),1,10) AS VAL_DT -- 起息日期
    ,SUBSTR(unifiedTime(P2.OPENDT),1,10) AS OPEN_ACCT_DT -- 开户日期
    ,P1.CORPNO||'000' AS STAT_ORG_NO -- 统计机构编号
    ,P1.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,'0' AS REC_STATUS_CD -- 记录状态代码
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNB_CBDL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_NAS.ODS_NAS_KNB_CBDL_TA AS P1 -- 负债账户计提明细

LEFT JOIN ODS_NAS.ODS_NAS_KNA_FXAC_TF AS P2 -- 定期负债账户表
       ON P2.ACCTNO = P1.ACCTNO AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF AS P3 -- 客户信息关联表
       ON P2.CUSTNO  = P3.CUSTNO AND  P3.STATUS='1' AND P3.PT_DT='${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_NAS.ODS_NAS_KUP_DPPB_TF AS P4 -- 产品基础属性表
       ON P4.PRODCD=P1.PRODCD AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
LEFT JOIN   (SELECT A.PRODUCT,A.SUBJECT,C.DESCRIPTION
      FROM (SELECT 
P1.EVENT_TYPE,
P1.PRODUCT,
CASE WHEN P1.SUBJECT_DR<>'' AND P1.SUBJECT_DR <> '30410310' THEN P1.SUBJECT_DR ELSE P1.SUBJECT_CR END  as  SUBJECT
FROM ODS_GAS.ODS_GAS_CUX_EA_RULES_TF P1
WHERE SUBSTR(P1.EVENT_TYPE,1,1) = '1'   AND P1.DEL_F='0'
and P1.PT_DT='${process_date}' ) A 
        LEFT JOIN ODS_GAS.ODS_GAS_CUX_FLEX_VALUES_V_TF C
        ON C.FLEX_VALUE = A.SUBJECT AND 
        C.PT_DT='${process_date}' AND C.DEL_F='0'
        GROUP BY A.PRODUCT,A.SUBJECT,C.DESCRIPTION) AS P5 -- 会计核算规则定义,COA段值视图
       ON P5.PRODUCT = P1.ACCTCD 
WHERE  P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     ACCT_NO -- 账户编号
    ,EXCH_GATHER_ACCT_SER_NO -- 汇集账户序号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACRU_DT -- 计提日期
    ,CUST_IN_CD -- 客户内码
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_DPSTRCP_FLAG -- 活期存单标志
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PERIOD -- 存期
    ,ACRU_INT -- 计提利息
    ,RGL_INT -- 定期利息
    ,RGL_INT_RATE -- 定期利率
    ,CURR_INT -- 活期利息
    ,CURR_INT_RATE -- 活期利率
    ,ADJ_INT -- 调整利息
    ,DPSIT_BAL -- 存款余额
    ,DPSIT_BAL_ACCUM -- 存款余额积数
    ,VAL_DT -- 起息日期
    ,OPEN_ACCT_DT -- 开户日期
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_DPSIT_ACCT_ACRU_INT_DTL_TA_TM;
