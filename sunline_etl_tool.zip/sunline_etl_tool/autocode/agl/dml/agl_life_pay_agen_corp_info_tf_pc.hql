-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-生活缴费代理单位信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_AGEN_CORP_INFO_TF
--     表中文名：生活缴费代理单位信息聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：BIZ_UNIT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：13M
--     描述信息：包括中间业务平台（前置、mid73平台、ODS_MID70平台综合代收付单位信息）和外联支付平台中与生活缴费相关的代理单位数据
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 修改新版本同步 20240724



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM
USING ORC
COMMENT '生活缴费代理单位信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,UNIT_NAME -- 单位名称
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,RGN_NO -- 地区编号
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROD_NO -- 缴费产品编号
    ,BASIC_PROD_NO -- 基础产品编号
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,AGEN_LVL_CD -- 代理级别代码
    ,STL_ACCT_NO -- 结算账户编号
    ,LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,STL_PERIOD_CD -- 结算周期代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,EFFECT_STATUS_FLAG -- 有效状态标志
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,TXN_LMT -- 交易限额
    ,BELONG_ORG_NO -- 归属机构编号
    ,BELONG_LP_ORG_NO -- 归属法人机构编号
    ,MKTING_ORG_NO -- 营销机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,INPUT_DT -- 录入日期
    ,MODIF_DT -- 修改日期
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM(
     BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,UNIT_NAME -- 单位名称
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,RGN_NO -- 地区编号
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROD_NO -- 缴费产品编号
    ,BASIC_PROD_NO -- 基础产品编号
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,AGEN_LVL_CD -- 代理级别代码
    ,STL_ACCT_NO -- 结算账户编号
    ,LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,STL_PERIOD_CD -- 结算周期代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,EFFECT_STATUS_FLAG -- 有效状态标志
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,TXN_LMT -- 交易限额
    ,BELONG_ORG_NO -- 归属机构编号
    ,BELONG_LP_ORG_NO -- 归属法人机构编号
    ,MKTING_ORG_NO -- 营销机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,INPUT_DT -- 录入日期
    ,MODIF_DT -- 修改日期
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     T1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,T1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,T2.ENTR_NAME AS UNIT_NAME -- 单位名称
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,T2.ID_TYPE AS DOCTYP_CD -- 证件类型代码
    ,T2.ID_NO AS DOC_NO -- 证件号码
    ,T2.CUST_CODE AS CUST_IN_CD -- 客户内码
    ,T1.AREA_NO AS RGN_NO -- 地区编号
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,CASE WHEN T1.busi_no = 'SMK'  THEN '01'
    WHEN T1.busi_no = 'ELE' then '02' 
    WHEN T1.busi_no like '%SF%' or T1.busi_no like  '%WT%' or T1.busi_no = 'YJLH' then '03'
    WHEN T1.busi_no like '%RQ%' or  T1.busi_no like '%MQF%' or  T1.busi_no = 'LWXO' then '04'
    WHEN T1.busi_no like '%TEL%' or T1.busi_no in ('MOB','ZJUT') then '05'
    WHEN T1.busi_no like '%HS' or  T1.busi_no like '%GD%' or  T1.busi_no like '%TV%' or T1.busi_no = 'UPAY' then '06'
    WHEN T1.busi_no = 'OLA'  then '08'
    WHEN T1.busi_no in ('%YXT','QZJFT','SCZX','YQDS','LSXXT') then '09'
    WHEN T1.busi_no in ('YHLZF','JNZJDS') then '10'
    WHEN T1.busi_no = 'ROAD' then '11'
    WHEN T1.busi_no in ('ZHTC','CXTC') then '12'
    WHEN T1.busi_no in ('YYYKT','TZXYK','LCXYQC','NBFWK','LAQC') then '13'
ELSE   '14'
END  AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,T1.BUSI_NO AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,'' AS PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,T1.AGT_LEVEL AS AGEN_LVL_CD -- 代理级别代码
    ,T1.SET_ACCT_NO AS STL_ACCT_NO -- 结算账户编号
    ,T1.LATE_ACCT_NO AS LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,T1.HAND_ACCT_NO AS COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,T1.RECV_ACCT AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,T1.CURR_NO AS TXN_CURR_CD -- 交易币种代码
    ,T1.CURR_IDEN AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,T1.TRAN_MODE AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,CASE
         WHEN T1.ENTR_STAT IS NULL  OR TRIM(T1.ENTR_STAT) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.ENTR_STAT),
                   '')
       END AS EFFECT_STATUS_FLAG -- 有效状态标志
    ,T1.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,NULL AS TXN_LMT -- 交易限额
    ,T1.BRCH_NO AS BELONG_ORG_NO -- 归属机构编号
    ,T1.BRCH_NO||'000' AS BELONG_LP_ORG_NO -- 归属法人机构编号
    ,'' AS MKTING_ORG_NO -- 营销机构编号
    ,'' AS MKTING_TELR_NO -- 营销柜员编号
    ,'' AS MKTING_TELR_NAME -- 营销柜员名称
    ,'9999-12-31' AS INPUT_DT -- 录入日期
    ,'9999-12-31' AS MODIF_DT -- 修改日期
    ,'OSCIP' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_OSCIP_T_ENTR_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_ENTR_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OSCIP.ODS_OSCIP_T_ENTR_TF AS T1 -- 代理单位管理表

LEFT JOIN ODS_OSCIP.ODS_OSCIP_T_ENTR_INNER_CODE_TF AS T2 -- 代理单位核心内码登记信息表
       ON T1.entr_no = T2.entr_no
AND T2.PT_DT = '${process_date}'
AND T2.DEL_F = '0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 币种代码转换
       ON T1.ENTR_STAT = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'OSCIP'
AND S1.SRC_FIELD_EN_NAME ='ENTR_STAT'
AND S1.SRC_TAB_EN_NAME = 'T_ENTR'
AND S1.TARGET_TAB_EN_NAME='AGL_LIFE_PAY_AGEN_CORP_INFO_TF'
AND S1.TARGET_FIELD_EN_NAME = 'EFFECT_STATUS_FLAG' 
WHERE T1.ACCT_TYPE='1' 
and 
(T1.busi_no like '%SF%'  
OR T1.busi_no like '%WT%'  
OR T1.busi_no like '%RQ%' 
OR T1.busi_no like  '%MQF%'
OR T1.busi_no like '%TEL%'
OR T1.busi_no like '%GD%'  
OR T1.busi_no like '%TV%'  
OR T1.busi_no LIKE '%HS'
OR T1.busi_no  IN ('SMK','OLA','MOB','ZJUT','LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF','JNZJDS',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX','UPAY' ,'LWXO','ELE','YJLH'   
))
AND T1.busi_no NOT IN ('JXDSF','HGHS','LCESFCG','LCESF')
AND T1.PT_DT = '${process_date}'
AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- None

INSERT INTO TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM(
     BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,UNIT_NAME -- 单位名称
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,RGN_NO -- 地区编号
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROD_NO -- 缴费产品编号
    ,BASIC_PROD_NO -- 基础产品编号
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,AGEN_LVL_CD -- 代理级别代码
    ,STL_ACCT_NO -- 结算账户编号
    ,LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,STL_PERIOD_CD -- 结算周期代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,EFFECT_STATUS_FLAG -- 有效状态标志
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,TXN_LMT -- 交易限额
    ,BELONG_ORG_NO -- 归属机构编号
    ,BELONG_LP_ORG_NO -- 归属法人机构编号
    ,MKTING_ORG_NO -- 营销机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,INPUT_DT -- 录入日期
    ,MODIF_DT -- 修改日期
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     T1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,T1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,T2.ENTR_NAME AS UNIT_NAME -- 单位名称
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,T2.ID_TYPE AS DOCTYP_CD -- 证件类型代码
    ,T2.ID_NO AS DOC_NO -- 证件号码
    ,T2.CUST_CODE AS CUST_IN_CD -- 客户内码
    ,'' AS RGN_NO -- 地区编号
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,CASE WHEN T1.busi_no = 'SMK'  THEN '01'
    WHEN T1.busi_no = 'ELE' then '02' 
    WHEN T1.busi_no like '%SF%' or  T1.busi_no like '%WT%' or T1.busi_no = 'YJLH' then '03'
    WHEN T1.busi_no like '%RQ%' or T1.busi_no like '%MQF%' or  T1.busi_no = 'LWXO' then '04'
    WHEN T1.busi_no like '%TEL%' or T1.busi_no in ('MOB','ZJUT') then '05'
    WHEN T1.busi_no like '%HS' or  T1.busi_no like '%GD%' or  T1.busi_no like '%TV%' or T1.busi_no = 'UPAY' then '06'
    WHEN T1.busi_no = 'OLA'  then '08'
    WHEN T1.busi_no in ('%YXT','QZJFT','SCZX','YQDS','LSXXT') then '09'
    WHEN T1.busi_no in ('YHLZF','JNZJDS') then '10'
    WHEN T1.busi_no = 'ROAD' then '11'
    WHEN T1.busi_no in ('ZHTC','CXTC') then '12'
    WHEN T1.busi_no in ('YYYKT','TZXYK','LCXYQC','NBFWK','LAQC') then '13'
ELSE   '14'
END  AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,T1.BUSI_NO AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,'' AS PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,T1.AGT_LEVEL AS AGEN_LVL_CD -- 代理级别代码
    ,T1.SET_ACCT_NO AS STL_ACCT_NO -- 结算账户编号
    ,T1.LATE_ACCT_NO AS LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,T1.HAND_ACCT_NO AS COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,T1.RECV_ACCT AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,T1.CURR_NO AS TXN_CURR_CD -- 交易币种代码
    ,T1.CURR_IDEN AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,T1.TRAN_MODE AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,CASE
         WHEN T1.ENTR_STAT IS NULL  OR TRIM(T1.ENTR_STAT) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.ENTR_STAT),
                   '')
       END AS EFFECT_STATUS_FLAG -- 有效状态标志
    ,T1.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS TXN_LMT -- 交易限额
    ,T1.BRCH_NO AS BELONG_ORG_NO -- 归属机构编号
    ,T1.BRCH_NO||'000' AS BELONG_LP_ORG_NO -- 归属法人机构编号
    ,'' AS MKTING_ORG_NO -- 营销机构编号
    ,'' AS MKTING_TELR_NO -- 营销柜员编号
    ,'' AS MKTING_TELR_NAME -- 营销柜员名称
    ,'9999-12-31' AS INPUT_DT -- 录入日期
    ,'9999-12-31' AS MODIF_DT -- 修改日期
    ,'MID73' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_MID73_T_ENTR_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MID73_T_ENTR_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MID73.ODS_MID73_T_ENTR_TF AS T1 -- 代理单位管理表

LEFT JOIN ODS_OSCIP.ODS_OSCIP_T_ENTR_INNER_CODE_TF AS T2 -- 代理单位核心内码登记信息表
       ON T1.entr_no = T2.entr_no
AND T2.PT_DT = '${process_date}'
AND T2.DEL_F = '0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 币种代码转换
       ON T1.ENTR_STAT = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'MID73'
AND S1.SRC_FIELD_EN_NAME ='ENTR_STAT'
AND S1.SRC_TAB_EN_NAME = 'T_ENTR'
AND S1.TARGET_TAB_EN_NAME='AGL_LIFE_PAY_AGEN_CORP_INFO_TF'
AND S1.TARGET_FIELD_EN_NAME = 'EFFECT_STATUS_FLAG' 
WHERE T1.ACCT_TYPE='1' 
and 
(T1.busi_no like '%SF%'  
OR T1.busi_no like '%WT%'  
OR T1.busi_no like '%RQ%' 
OR T1.busi_no like  '%MQF%'
OR T1.busi_no like '%TEL%'
OR T1.busi_no like '%GD%'  
OR T1.busi_no like '%TV%'  
OR T1.busi_no LIKE '%HS'
OR T1.busi_no  IN ('SMK','OLA','MOB','ZJUT','LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF','JNZJDS',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX','UPAY' ,'LWXO','ELE','YJLH'   
))
AND T1.busi_no NOT IN ('JXDSF','HGHS','LCESFCG','LCESF')
AND T1.PT_DT = '${process_date}'
AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- None

INSERT INTO TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM(
     BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,UNIT_NAME -- 单位名称
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,RGN_NO -- 地区编号
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROD_NO -- 缴费产品编号
    ,BASIC_PROD_NO -- 基础产品编号
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,AGEN_LVL_CD -- 代理级别代码
    ,STL_ACCT_NO -- 结算账户编号
    ,LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,STL_PERIOD_CD -- 结算周期代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,EFFECT_STATUS_FLAG -- 有效状态标志
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,TXN_LMT -- 交易限额
    ,BELONG_ORG_NO -- 归属机构编号
    ,BELONG_LP_ORG_NO -- 归属法人机构编号
    ,MKTING_ORG_NO -- 营销机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,INPUT_DT -- 录入日期
    ,MODIF_DT -- 修改日期
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     T1.BUSI_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,T1.BUSI_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,T5.smchna AS UNIT_NAME -- 单位名称
    ,T1.ENTR_NO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,T5.recdtp AS DOCTYP_CD -- 证件类型代码
    ,T5.recdno AS DOC_NO -- 证件号码
    ,COALESCE(T6.CINOCSNO,'') AS CUST_IN_CD -- 客户内码
    ,T1.AREA_NO AS RGN_NO -- 地区编号
    ,T1.ENTR_IDEN_NO AS PAY_PROJ_NO -- 缴费项目编号
    ,T1.PROD_NO AS PAY_PROD_NO -- 缴费产品编号
    ,T1.APP_NO AS BASIC_PROD_NO -- 基础产品编号
    ,CASE WHEN T2.BUSI_KIND_NO = 'YWZL0022' THEN '01'
    WHEN T2.BUSI_KIND_NO = 'YWZL0001' THEN '02'
    WHEN T2.BUSI_KIND_NO = 'YWZL0002' THEN '03'
    WHEN T2.BUSI_KIND_NO = 'YWZL0003' THEN '04'
    WHEN T2.BUSI_KIND_NO IN ('YWZL0004','YWZL0005','YWZL0007','YWZL0034','YWZL0036') THEN '05'
    WHEN T2.BUSI_KIND_NO in ('YWZL0006','YWZL0035') THEN '06'
    WHEN T2.BUSI_KIND_NO IN ('YWZL0017','YWZL0018') THEN '07'
    WHEN T2.BUSI_KIND_NO IN ('YWZL0027','YWZL0041','YWZL0048','YWZL0053') THEN '09'
    WHEN T2.BUSI_KIND_NO IN ('YWZL0010','YWZL0011') THEN '10'
    WHEN T2.BUSI_KIND_NO = 'YWZL0008' THEN '12'
    WHEN T2.BUSI_KIND_NO IN ('YWZL0029','YWZL0054') THEN '13'
ELSE '14'
END AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,t2.busi_kind_no AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,t3.BUSI_KIND_NAME AS PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,T1.AGT_LEVEL AS AGEN_LVL_CD -- 代理级别代码
    ,T4.bilacn AS STL_ACCT_NO -- 结算账户编号
    ,T4.bilacn AS LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,T4.mcfeno AS COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,'' AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,T1.SETTLE_CYCLE AS STL_PERIOD_CD -- 结算周期代码
    ,T1.CURR_NO AS TXN_CURR_CD -- 交易币种代码
    ,T1.CURR_IDEN AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,'' AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,T1.ACTCHK_PRE AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,T1.IF_VALID AS EFFECT_STATUS_FLAG -- 有效状态标志
    ,T1.SUM_CD AS SUMMARY_CD -- 摘要代码
    ,T1.SUM_DESC AS SUMMARY_DESC -- 摘要描述
    ,T1.LIMIT_AMT AS TXN_LMT -- 交易限额
    ,T1.OWNER_BRCH AS BELONG_ORG_NO -- 归属机构编号
    ,T1.OWNER_BRCH_SUPER AS BELONG_LP_ORG_NO -- 归属法人机构编号
    ,T1.MKT_BRCH AS MKTING_ORG_NO -- 营销机构编号
    ,T1.MKT_TELLER AS MKTING_TELR_NO -- 营销柜员编号
    ,T1.MKT_NAME AS MKTING_TELR_NAME -- 营销柜员名称
    ,T1.GMT_CREATE AS INPUT_DT -- 录入日期
    ,T1.GMT_MODIFIED AS MODIF_DT -- 修改日期
    ,'NIMBS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_NIMBS_SPIDER_PLAT_BUSI_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'NIMBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NIMBS_SPIDER_PLAT_BUSI_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NIMBS.ODS_NIMBS_SPIDER_PLAT_BUSI_TF AS T1 -- 业务单元表

LEFT JOIN ODS_NIMBS.ODS_NIMBS_SCIP_PRODUCT_BUSI_TF AS T2 -- 业务产品信息表
       ON t1.prod_no=t2.prod_no 
and t2.if_record_valid='1' 
and t2.if_valid='1'
and t2.pt_dt = '${process_date}'
and t2.del_f = '0' 
LEFT JOIN ODS_NIMBS.ODS_NIMBS_SCIP_PRODUCT_BUSI_KIND_TF AS T3 -- 业务种类表
       ON  t2.busi_kind_no=t3.busi_kind_no 
and T3.if_record_valid='1' and T3.if_valid='1'
and t3.pt_dt = '${process_date}'
and t3.del_f = '0' 
LEFT JOIN ODS_MCSP.ODS_MCSP_SMERCHANT_SETM_TF AS T4 -- 特约商户结算信息表
       ON SUBSTR(T1.ENTR_IDEN_NO,1,15) = T4.bussno
and t4.pt_dt = '${process_date}'
and t4.del_f = '0' 
LEFT JOIN ODS_MCSP.ODS_MCSP_SMERCHANT_INFO_TF AS T5 -- 特约商户表
       ON SUBSTR(T1.ENTR_IDEN_NO,1,15)=T5.smchno
and t5.pt_dt = '${process_date}'
and t5.del_f = '0' 
LEFT JOIN (SELECT IDNOCFNO,IDTYCFTP,CINOCSNO,ISDTDATE,EXDTDATE,MIFLBOOL FROM (
select IDNOCFNO,IDTYCFTP,CINOCSNO,ISDTDATE,EXDTDATE,MIFLBOOL,row_number()OVER(PARTITION BY IDNOCFNO,IDTYCFTP ORDER BY butsstam DESC) RN  
from ODS_CORE.ODS_CORE_BCFMCIDI_TF 
where del_f = '0' 
and MIFLBOOL='1'
and RCSTRS1B<> '9'
and pt_dt ='${process_date}'
)
where RN = 1) AS T6 -- 客户证件信息表（柜面核心）
       ON T5.recdtp = T6.IDTYCFTP
AND T5.recdno=T6.IDNOCFNO 
WHERE T1.IF_RECORD_VALID='1' and T1.IF_BUSI='1'
and ((T3.parent_no in ('01','02') and t2.busi_kind_no in ('YWZL0008','YWZL0009') )
or (T3.parent_no in ('03','05','07') and t2.busi_kind_no in ('YWZL0033','YWZL0026','YWZL0025','YWZL0024','YWZL0022','YWZL0021','YWZL0020'))
or (t3.parent_no='08' and t2.busi_kind_no in ('YWZL0053','YWZL0048','YWZL0041','YWZL0029','YWZL0027'))
or (t3.parent_no='09' and t2.busi_kind_no in ('YWZL0031','YWZL0042','YWZL0049','YWZL0050','YWZL0052','YWZL0058')))
and t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- None

INSERT INTO TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM(
     BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,UNIT_NAME -- 单位名称
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,RGN_NO -- 地区编号
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROD_NO -- 缴费产品编号
    ,BASIC_PROD_NO -- 基础产品编号
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,AGEN_LVL_CD -- 代理级别代码
    ,STL_ACCT_NO -- 结算账户编号
    ,LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,STL_PERIOD_CD -- 结算周期代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,EFFECT_STATUS_FLAG -- 有效状态标志
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,TXN_LMT -- 交易限额
    ,BELONG_ORG_NO -- 归属机构编号
    ,BELONG_LP_ORG_NO -- 归属法人机构编号
    ,MKTING_ORG_NO -- 营销机构编号
    ,MKTING_TELR_NO -- 营销柜员编号
    ,MKTING_TELR_NAME -- 营销柜员名称
    ,INPUT_DT -- 录入日期
    ,MODIF_DT -- 修改日期
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     T1.UNIT_CODE AS BIZ_UNIT_NO -- 业务单元编号
    ,T1.UNIT_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS UNIT_NAME -- 单位名称
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'202' AS DOCTYP_CD -- 证件类型代码
    ,T1.CREDIT_CODE AS DOC_NO -- 证件号码
    ,COALESCE(T2.CINOCSNO,'') AS CUST_IN_CD -- 客户内码
    ,T1.AREA_NO AS RGN_NO -- 地区编号
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS BASIC_PROD_NO -- 基础产品编号
    ,case 
WHEN t1.fee_code='00100' THEN '02'
WHEN t1.fee_code='00201' THEN '03'
WHEN t1.fee_code='00302' THEN '04'
WHEN t1.fee_code IN ('00403','00500') THEN '05'
WHEN t1.fee_code='01000' THEN '06'
WHEN t1.fee_code='00703' THEN '10'
WHEN t1.fee_code IN ('00204','00205','00503','01814','04909','09001') THEN  '14'
end  AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,T1.FEE_CODE AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,T1.FEE_NAME AS PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,'' AS AGEN_LVL_CD -- 代理级别代码
    ,'' AS STL_ACCT_NO -- 结算账户编号
    ,'' AS LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,'' AS COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,'' AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,'1' AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,'' AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,T1.STAT AS EFFECT_STATUS_FLAG -- 有效状态标志
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,NULL AS TXN_LMT -- 交易限额
    ,T1.INIT_BRCH_NO AS BELONG_ORG_NO -- 归属机构编号
    ,T1.INIT_BRCH_NO AS BELONG_LP_ORG_NO -- 归属法人机构编号
    ,'' AS MKTING_ORG_NO -- 营销机构编号
    ,'' AS MKTING_TELR_NO -- 营销柜员编号
    ,'' AS MKTING_TELR_NAME -- 营销柜员名称
    ,T1.INIT_DATE AS INPUT_DT -- 录入日期
    ,T1.UPT_DATE AS MODIF_DT -- 修改日期
    ,'OCCPS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_OCCPS_T_ZHDSF_SFDW_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'OCCPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OCCPS_T_ZHDSF_SFDW_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OCCPS.ODS_OCCPS_T_ZHDSF_SFDW_TF AS T1 -- 综合代收付收费单位表

LEFT JOIN  (SELECT IDNOCFNO,IDTYCFTP,CINOCSNO,ISDTDATE,EXDTDATE,MIFLBOOL FROM (
select IDNOCFNO,IDTYCFTP,CINOCSNO,ISDTDATE,EXDTDATE,MIFLBOOL,row_number()OVER(PARTITION BY IDNOCFNO,IDTYCFTP ORDER BY butsstam DESC) RN  
from ODS_CORE.ODS_CORE_BCFMCIDI_TF 
where del_f = '0' 
and MIFLBOOL='1'
and RCSTRS1B<> '9'
and IDTYCFTP = '202'
and pt_dt ='${process_date}'
)
where RN = 1) AS T2 -- 客户证件信息表（柜面核心）
       ON  T2.IDTYCFTP='202'
AND T1.CREDIT_CODE=T2.IDNOCFNO 
WHERE  t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NO IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NO, BF.BIZ_UNIT_NO) END AS BIZ_UNIT_NO -- 业务单元编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NAME IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NAME, BF.BIZ_UNIT_NAME) END AS BIZ_UNIT_NAME -- 业务单元名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIT_NAME IS NULL THEN NULL ELSE COALESCE(TM.UNIT_NAME, BF.UNIT_NAME) END AS UNIT_NAME -- 单位名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_NO, BF.SPC_ARGMT_MERCHT_NO) END AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DOCTYP_CD, BF.DOCTYP_CD) END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.DOC_NO, BF.DOC_NO) END AS DOC_NO -- 证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RGN_NO IS NULL THEN NULL ELSE COALESCE(TM.RGN_NO, BF.RGN_NO) END AS RGN_NO -- 地区编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NO, BF.PAY_PROJ_NO) END AS PAY_PROJ_NO -- 缴费项目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROD_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROD_NO, BF.PAY_PROD_NO) END AS PAY_PROD_NO -- 缴费产品编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BASIC_PROD_NO IS NULL THEN NULL ELSE COALESCE(TM.BASIC_PROD_NO, BF.BASIC_PROD_NO) END AS BASIC_PROD_NO -- 基础产品编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_BIZ_CATEGORY_CD_1 IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD_1, BF.LIFE_PAY_BIZ_CATEGORY_CD_1) END AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_BIZ_CATE_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_BIZ_CATE_NO, BF.PAY_BIZ_CATE_NO) END AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_BIZ_CATE_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_BIZ_CATE_NAME, BF.PAY_BIZ_CATE_NAME) END AS PAY_BIZ_CATE_NAME -- 缴费业务种类名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGEN_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.AGEN_LVL_CD, BF.AGEN_LVL_CD) END AS AGEN_LVL_CD -- 代理级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STL_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.STL_ACCT_NO, BF.STL_ACCT_NO) END AS STL_ACCT_NO -- 结算账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LATE_FEE_STL_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.LATE_FEE_STL_ACCT_NO, BF.LATE_FEE_STL_ACCT_NO) END AS LATE_FEE_STL_ACCT_NO -- 滞纳金结算账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMM_FEE_STL_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.COMM_FEE_STL_ACCT_NO, BF.COMM_FEE_STL_ACCT_NO) END AS COMM_FEE_STL_ACCT_NO -- 手续费结算账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYEE_ACCT_NO  IS NULL THEN NULL ELSE COALESCE(TM.PAYEE_ACCT_NO , BF.PAYEE_ACCT_NO ) END AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STL_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.STL_PERIOD_CD, BF.STL_PERIOD_CD) END AS STL_PERIOD_CD -- 结算周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CURR_CD, BF.TXN_CURR_CD) END AS TXN_CURR_CD -- 交易币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CASH_RMT_CD, BF.TXN_CASH_RMT_CD) END AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BAT_SINGLE_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.BAT_SINGLE_IDNT_CD, BF.BAT_SINGLE_IDNT_CD) END AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CHENK_ACCT_CLS_NO IS NULL THEN NULL ELSE COALESCE(TM.CHENK_ACCT_CLS_NO, BF.CHENK_ACCT_CLS_NO) END AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EFFECT_STATUS_FLAG IS NULL THEN NULL ELSE COALESCE(TM.EFFECT_STATUS_FLAG, BF.EFFECT_STATUS_FLAG) END AS EFFECT_STATUS_FLAG -- 有效状态标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_CD IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_CD, BF.SUMMARY_CD) END AS SUMMARY_CD -- 摘要代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_DESC IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_DESC, BF.SUMMARY_DESC) END AS SUMMARY_DESC -- 摘要描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_LMT IS NULL THEN NULL ELSE COALESCE(TM.TXN_LMT, BF.TXN_LMT) END AS TXN_LMT -- 交易限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_LP_ORG_NO, BF.BELONG_LP_ORG_NO) END AS BELONG_LP_ORG_NO -- 归属法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MKTING_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.MKTING_ORG_NO, BF.MKTING_ORG_NO) END AS MKTING_ORG_NO -- 营销机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MKTING_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.MKTING_TELR_NO, BF.MKTING_TELR_NO) END AS MKTING_TELR_NO -- 营销柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MKTING_TELR_NAME IS NULL THEN NULL ELSE COALESCE(TM.MKTING_TELR_NAME, BF.MKTING_TELR_NAME) END AS MKTING_TELR_NAME -- 营销柜员名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_DT IS NULL THEN NULL ELSE COALESCE(TM.INPUT_DT, BF.INPUT_DT) END AS INPUT_DT -- 录入日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.MODIF_DT, BF.MODIF_DT) END AS MODIF_DT -- 修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.B_SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.B_SRC_SYS_CD, BF.B_SRC_SYS_CD) END AS B_SRC_SYS_CD -- 业务来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.B_SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.B_SRC_TAB_EN_NAME, BF.B_SRC_TAB_EN_NAME) END AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.BIZ_UNIT_NAME,'') = COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段相等
         AND COALESCE(TM.UNIT_NAME,'') = COALESCE(BF.UNIT_NAME,'') -- 单位名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.RGN_NO,'') = COALESCE(BF.RGN_NO,'') -- 地区编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROD_NO,'') = COALESCE(BF.PAY_PROD_NO,'') -- 缴费产品编号 非主键字段相等
         AND COALESCE(TM.BASIC_PROD_NO,'') = COALESCE(BF.BASIC_PROD_NO,'') -- 基础产品编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD_1,'') = COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD_1,'') -- 生活缴费业务类别代码1 非主键字段相等
         AND COALESCE(TM.PAY_BIZ_CATE_NO,'') = COALESCE(BF.PAY_BIZ_CATE_NO,'') -- 缴费业务种类编号 非主键字段相等
         AND COALESCE(TM.PAY_BIZ_CATE_NAME,'') = COALESCE(BF.PAY_BIZ_CATE_NAME,'') -- 缴费业务种类名称 非主键字段相等
         AND COALESCE(TM.AGEN_LVL_CD,'') = COALESCE(BF.AGEN_LVL_CD,'') -- 代理级别代码 非主键字段相等
         AND COALESCE(TM.STL_ACCT_NO,'') = COALESCE(BF.STL_ACCT_NO,'') -- 结算账户编号 非主键字段相等
         AND COALESCE(TM.LATE_FEE_STL_ACCT_NO,'') = COALESCE(BF.LATE_FEE_STL_ACCT_NO,'') -- 滞纳金结算账户编号 非主键字段相等
         AND COALESCE(TM.COMM_FEE_STL_ACCT_NO,'') = COALESCE(BF.COMM_FEE_STL_ACCT_NO,'') -- 手续费结算账户编号 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_NO ,'') = COALESCE(BF.PAYEE_ACCT_NO ,'') -- 收款人账户编号 非主键字段相等
         AND COALESCE(TM.STL_PERIOD_CD,'') = COALESCE(BF.STL_PERIOD_CD,'') -- 结算周期代码 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.TXN_CASH_RMT_CD,'') = COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段相等
         AND COALESCE(TM.BAT_SINGLE_IDNT_CD,'') = COALESCE(BF.BAT_SINGLE_IDNT_CD,'') -- 批量单笔标识代码 非主键字段相等
         AND COALESCE(TM.CHENK_ACCT_CLS_NO,'') = COALESCE(BF.CHENK_ACCT_CLS_NO,'') -- 对账分类编号 非主键字段相等
         AND COALESCE(TM.EFFECT_STATUS_FLAG,'') = COALESCE(BF.EFFECT_STATUS_FLAG,'') -- 有效状态标志 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         AND COALESCE(TM.SUMMARY_DESC,'') = COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段相等
         AND COALESCE(TM.TXN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_LMT,CAST(0 AS DECIMAL(28,2))) -- 交易限额 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_LP_ORG_NO,'') = COALESCE(BF.BELONG_LP_ORG_NO,'') -- 归属法人机构编号 非主键字段相等
         AND COALESCE(TM.MKTING_ORG_NO,'') = COALESCE(BF.MKTING_ORG_NO,'') -- 营销机构编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NO,'') = COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NAME,'') = COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段相等
         AND COALESCE(TM.INPUT_DT,'') = COALESCE(BF.INPUT_DT,'') -- 录入日期 非主键字段相等
         AND COALESCE(TM.MODIF_DT,'') = COALESCE(BF.MODIF_DT,'') -- 修改日期 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.B_SRC_TAB_EN_NAME,'') = COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.BIZ_UNIT_NAME,'') <> COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段不相等
         OR COALESCE(TM.UNIT_NAME,'') <> COALESCE(BF.UNIT_NAME,'') -- 单位名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.RGN_NO,'') <> COALESCE(BF.RGN_NO,'') -- 地区编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROD_NO,'') <> COALESCE(BF.PAY_PROD_NO,'') -- 缴费产品编号 非主键字段不相等
         OR COALESCE(TM.BASIC_PROD_NO,'') <> COALESCE(BF.BASIC_PROD_NO,'') -- 基础产品编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD_1,'') <> COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD_1,'') -- 生活缴费业务类别代码1 非主键字段不相等
         OR COALESCE(TM.PAY_BIZ_CATE_NO,'') <> COALESCE(BF.PAY_BIZ_CATE_NO,'') -- 缴费业务种类编号 非主键字段不相等
         OR COALESCE(TM.PAY_BIZ_CATE_NAME,'') <> COALESCE(BF.PAY_BIZ_CATE_NAME,'') -- 缴费业务种类名称 非主键字段不相等
         OR COALESCE(TM.AGEN_LVL_CD,'') <> COALESCE(BF.AGEN_LVL_CD,'') -- 代理级别代码 非主键字段不相等
         OR COALESCE(TM.STL_ACCT_NO,'') <> COALESCE(BF.STL_ACCT_NO,'') -- 结算账户编号 非主键字段不相等
         OR COALESCE(TM.LATE_FEE_STL_ACCT_NO,'') <> COALESCE(BF.LATE_FEE_STL_ACCT_NO,'') -- 滞纳金结算账户编号 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_STL_ACCT_NO,'') <> COALESCE(BF.COMM_FEE_STL_ACCT_NO,'') -- 手续费结算账户编号 非主键字段不相等
         OR COALESCE(TM.PAYEE_ACCT_NO ,'') <> COALESCE(BF.PAYEE_ACCT_NO ,'') -- 收款人账户编号 非主键字段不相等
         OR COALESCE(TM.STL_PERIOD_CD,'') <> COALESCE(BF.STL_PERIOD_CD,'') -- 结算周期代码 非主键字段不相等
         OR COALESCE(TM.TXN_CURR_CD,'') <> COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段不相等
         OR COALESCE(TM.TXN_CASH_RMT_CD,'') <> COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段不相等
         OR COALESCE(TM.BAT_SINGLE_IDNT_CD,'') <> COALESCE(BF.BAT_SINGLE_IDNT_CD,'') -- 批量单笔标识代码 非主键字段不相等
         OR COALESCE(TM.CHENK_ACCT_CLS_NO,'') <> COALESCE(BF.CHENK_ACCT_CLS_NO,'') -- 对账分类编号 非主键字段不相等
         OR COALESCE(TM.EFFECT_STATUS_FLAG,'') <> COALESCE(BF.EFFECT_STATUS_FLAG,'') -- 有效状态标志 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         OR COALESCE(TM.SUMMARY_DESC,'') <> COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段不相等
         OR COALESCE(TM.TXN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.TXN_LMT,CAST(0 AS DECIMAL(28,2))) -- 交易限额 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_LP_ORG_NO,'') <> COALESCE(BF.BELONG_LP_ORG_NO,'') -- 归属法人机构编号 非主键字段不相等
         OR COALESCE(TM.MKTING_ORG_NO,'') <> COALESCE(BF.MKTING_ORG_NO,'') -- 营销机构编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NO,'') <> COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NAME,'') <> COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段不相等
         OR COALESCE(TM.INPUT_DT,'') <> COALESCE(BF.INPUT_DT,'') -- 录入日期 非主键字段不相等
         OR COALESCE(TM.MODIF_DT,'') <> COALESCE(BF.MODIF_DT,'') -- 修改日期 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.B_SRC_TAB_EN_NAME,'') <> COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.BIZ_UNIT_NAME,'') = COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段相等
         AND COALESCE(TM.UNIT_NAME,'') = COALESCE(BF.UNIT_NAME,'') -- 单位名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.RGN_NO,'') = COALESCE(BF.RGN_NO,'') -- 地区编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROD_NO,'') = COALESCE(BF.PAY_PROD_NO,'') -- 缴费产品编号 非主键字段相等
         AND COALESCE(TM.BASIC_PROD_NO,'') = COALESCE(BF.BASIC_PROD_NO,'') -- 基础产品编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD_1,'') = COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD_1,'') -- 生活缴费业务类别代码1 非主键字段相等
         AND COALESCE(TM.PAY_BIZ_CATE_NO,'') = COALESCE(BF.PAY_BIZ_CATE_NO,'') -- 缴费业务种类编号 非主键字段相等
         AND COALESCE(TM.PAY_BIZ_CATE_NAME,'') = COALESCE(BF.PAY_BIZ_CATE_NAME,'') -- 缴费业务种类名称 非主键字段相等
         AND COALESCE(TM.AGEN_LVL_CD,'') = COALESCE(BF.AGEN_LVL_CD,'') -- 代理级别代码 非主键字段相等
         AND COALESCE(TM.STL_ACCT_NO,'') = COALESCE(BF.STL_ACCT_NO,'') -- 结算账户编号 非主键字段相等
         AND COALESCE(TM.LATE_FEE_STL_ACCT_NO,'') = COALESCE(BF.LATE_FEE_STL_ACCT_NO,'') -- 滞纳金结算账户编号 非主键字段相等
         AND COALESCE(TM.COMM_FEE_STL_ACCT_NO,'') = COALESCE(BF.COMM_FEE_STL_ACCT_NO,'') -- 手续费结算账户编号 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_NO ,'') = COALESCE(BF.PAYEE_ACCT_NO ,'') -- 收款人账户编号 非主键字段相等
         AND COALESCE(TM.STL_PERIOD_CD,'') = COALESCE(BF.STL_PERIOD_CD,'') -- 结算周期代码 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.TXN_CASH_RMT_CD,'') = COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段相等
         AND COALESCE(TM.BAT_SINGLE_IDNT_CD,'') = COALESCE(BF.BAT_SINGLE_IDNT_CD,'') -- 批量单笔标识代码 非主键字段相等
         AND COALESCE(TM.CHENK_ACCT_CLS_NO,'') = COALESCE(BF.CHENK_ACCT_CLS_NO,'') -- 对账分类编号 非主键字段相等
         AND COALESCE(TM.EFFECT_STATUS_FLAG,'') = COALESCE(BF.EFFECT_STATUS_FLAG,'') -- 有效状态标志 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         AND COALESCE(TM.SUMMARY_DESC,'') = COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段相等
         AND COALESCE(TM.TXN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_LMT,CAST(0 AS DECIMAL(28,2))) -- 交易限额 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_LP_ORG_NO,'') = COALESCE(BF.BELONG_LP_ORG_NO,'') -- 归属法人机构编号 非主键字段相等
         AND COALESCE(TM.MKTING_ORG_NO,'') = COALESCE(BF.MKTING_ORG_NO,'') -- 营销机构编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NO,'') = COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段相等
         AND COALESCE(TM.MKTING_TELR_NAME,'') = COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段相等
         AND COALESCE(TM.INPUT_DT,'') = COALESCE(BF.INPUT_DT,'') -- 录入日期 非主键字段相等
         AND COALESCE(TM.MODIF_DT,'') = COALESCE(BF.MODIF_DT,'') -- 修改日期 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.B_SRC_TAB_EN_NAME,'') = COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.BIZ_UNIT_NAME,'') <> COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段不相等
         OR COALESCE(TM.UNIT_NAME,'') <> COALESCE(BF.UNIT_NAME,'') -- 单位名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.RGN_NO,'') <> COALESCE(BF.RGN_NO,'') -- 地区编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROD_NO,'') <> COALESCE(BF.PAY_PROD_NO,'') -- 缴费产品编号 非主键字段不相等
         OR COALESCE(TM.BASIC_PROD_NO,'') <> COALESCE(BF.BASIC_PROD_NO,'') -- 基础产品编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD_1,'') <> COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD_1,'') -- 生活缴费业务类别代码1 非主键字段不相等
         OR COALESCE(TM.PAY_BIZ_CATE_NO,'') <> COALESCE(BF.PAY_BIZ_CATE_NO,'') -- 缴费业务种类编号 非主键字段不相等
         OR COALESCE(TM.PAY_BIZ_CATE_NAME,'') <> COALESCE(BF.PAY_BIZ_CATE_NAME,'') -- 缴费业务种类名称 非主键字段不相等
         OR COALESCE(TM.AGEN_LVL_CD,'') <> COALESCE(BF.AGEN_LVL_CD,'') -- 代理级别代码 非主键字段不相等
         OR COALESCE(TM.STL_ACCT_NO,'') <> COALESCE(BF.STL_ACCT_NO,'') -- 结算账户编号 非主键字段不相等
         OR COALESCE(TM.LATE_FEE_STL_ACCT_NO,'') <> COALESCE(BF.LATE_FEE_STL_ACCT_NO,'') -- 滞纳金结算账户编号 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_STL_ACCT_NO,'') <> COALESCE(BF.COMM_FEE_STL_ACCT_NO,'') -- 手续费结算账户编号 非主键字段不相等
         OR COALESCE(TM.PAYEE_ACCT_NO ,'') <> COALESCE(BF.PAYEE_ACCT_NO ,'') -- 收款人账户编号 非主键字段不相等
         OR COALESCE(TM.STL_PERIOD_CD,'') <> COALESCE(BF.STL_PERIOD_CD,'') -- 结算周期代码 非主键字段不相等
         OR COALESCE(TM.TXN_CURR_CD,'') <> COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段不相等
         OR COALESCE(TM.TXN_CASH_RMT_CD,'') <> COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段不相等
         OR COALESCE(TM.BAT_SINGLE_IDNT_CD,'') <> COALESCE(BF.BAT_SINGLE_IDNT_CD,'') -- 批量单笔标识代码 非主键字段不相等
         OR COALESCE(TM.CHENK_ACCT_CLS_NO,'') <> COALESCE(BF.CHENK_ACCT_CLS_NO,'') -- 对账分类编号 非主键字段不相等
         OR COALESCE(TM.EFFECT_STATUS_FLAG,'') <> COALESCE(BF.EFFECT_STATUS_FLAG,'') -- 有效状态标志 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         OR COALESCE(TM.SUMMARY_DESC,'') <> COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段不相等
         OR COALESCE(TM.TXN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.TXN_LMT,CAST(0 AS DECIMAL(28,2))) -- 交易限额 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_LP_ORG_NO,'') <> COALESCE(BF.BELONG_LP_ORG_NO,'') -- 归属法人机构编号 非主键字段不相等
         OR COALESCE(TM.MKTING_ORG_NO,'') <> COALESCE(BF.MKTING_ORG_NO,'') -- 营销机构编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NO,'') <> COALESCE(BF.MKTING_TELR_NO,'') -- 营销柜员编号 非主键字段不相等
         OR COALESCE(TM.MKTING_TELR_NAME,'') <> COALESCE(BF.MKTING_TELR_NAME,'') -- 营销柜员名称 非主键字段不相等
         OR COALESCE(TM.INPUT_DT,'') <> COALESCE(BF.INPUT_DT,'') -- 录入日期 非主键字段不相等
         OR COALESCE(TM.MODIF_DT,'') <> COALESCE(BF.MODIF_DT,'') -- 修改日期 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.B_SRC_TAB_EN_NAME,'') <> COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_LIFE_PAY_AGEN_CORP_INFO_TF_TM;
