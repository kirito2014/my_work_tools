-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人账户非柜面交易控制信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF
--     表中文名：个人账户非柜面交易控制信息聚合
--     创建日期：2024-08-01 00:00:00
--     主键字段：无主键
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-01 00:00:00 陈艺丹 创建
--         2024-09-14 00:00:00 陈艺丹 修改表名：”个人账户非柜面交易控制明细聚合“改为”个人账户非柜面交易控制信息聚合“



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM
USING ORC
COMMENT '个人账户非柜面交易控制信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     MAIN_ACCT_NO -- 主账户编号
    ,SUB_ACCT_NO -- 子账户编号
    ,ACCT_NAME -- 账户名称
    ,EACCT_CLS_CD -- 电子账户分类代码
    ,CUST_IN_CD -- 客户内码
    ,DOC_NO -- 证件号码
    ,DOCTYP_CD -- 证件类型代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,CTRL_STATUS_CD -- 控制状态代码
    ,EACCT_TXN_SER_NO -- 电子账户交易流水号
    ,CTRL_RSN_DESC -- 控制原因描述
    ,CTRL_TELR_NO -- 控制柜员编号
    ,CTRL_AUTH_TELR_NO -- 控制授权柜员编号
    ,CTRL_DT -- 控制日期
    ,CTRL_TM_STAMP -- 控制时间戳
    ,CTRL_LIFTED_RSN_DESC -- 控制解除原因描述
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_DT -- 解除日期
    ,LIFTED_TM_STAMP -- 解除时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人账户非柜面交易控制信息聚合

INSERT INTO TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM(
     MAIN_ACCT_NO -- 主账户编号
    ,SUB_ACCT_NO -- 子账户编号
    ,ACCT_NAME -- 账户名称
    ,EACCT_CLS_CD -- 电子账户分类代码
    ,CUST_IN_CD -- 客户内码
    ,DOC_NO -- 证件号码
    ,DOCTYP_CD -- 证件类型代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,CTRL_STATUS_CD -- 控制状态代码
    ,EACCT_TXN_SER_NO -- 电子账户交易流水号
    ,CTRL_RSN_DESC -- 控制原因描述
    ,CTRL_TELR_NO -- 控制柜员编号
    ,CTRL_AUTH_TELR_NO -- 控制授权柜员编号
    ,CTRL_DT -- 控制日期
    ,CTRL_TM_STAMP -- 控制时间戳
    ,CTRL_LIFTED_RSN_DESC -- 控制解除原因描述
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_DT -- 解除日期
    ,LIFTED_TM_STAMP -- 解除时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.KR02AC15 AS MAIN_ACCT_NO -- 主账户编号
    ,P1.KR01AC22 AS SUB_ACCT_NO -- 子账户编号
    ,P2.AA04FLNM AS ACCT_NAME -- 账户名称
    ,'' AS EACCT_CLS_CD -- 电子账户分类代码
    ,P2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P2.AA61CFTP AS DOC_NO -- 证件号码
    ,P2.AA62CFNO AS DOCTYP_CD -- 证件类型代码
    ,P1.KR03BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.KR04BRNO AS LP_ORG_NO -- 法人机构编号
    ,P1.KR05FLAG AS CTRL_STATUS_CD -- 控制状态代码
    ,'' AS EACCT_TXN_SER_NO -- 电子账户交易流水号
    ,P1.KR06YYSM AS CTRL_RSN_DESC -- 控制原因描述
    ,P1.KR07STAF AS CTRL_TELR_NO -- 控制柜员编号
    ,P1.KR08STAF AS CTRL_AUTH_TELR_NO -- 控制授权柜员编号
    ,SUBSTR(unifiedTime(P1.KR09DATE),1,10) AS CTRL_DT -- 控制日期
    ,unifiedTime(P1.KR10STAM) AS CTRL_TM_STAMP -- 控制时间戳
    ,P1.KR07YYSM AS CTRL_LIFTED_RSN_DESC -- 控制解除原因描述
    ,P1.KR11STAF AS LIFTED_TELR_NO -- 解除柜员编号
    ,P1.KR12STAF AS LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,SUBSTR(unifiedTime(P1.KR13DATE),1,10) AS LIFTED_DT -- 解除日期
    ,unifiedTime(P1.KR14STAM) AS LIFTED_TM_STAMP -- 解除时间戳
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NIM_TM_PRODUCT_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
(SELECT  KR02AC15
,KR01AC22
,KR03BRNO
,KR04BRNO
,KR05FLAG
,KR06YYSM
,KR07STAF
,KR08STAF
,KR09DATE
,KR10STAM
,KR07YYSM
,KR11STAF
,KR12STAF
,KR13DATE
,KR14STAM
FROM ODS_CORE.ODS_CORE_BDFMHQKR_TF
WHERE SUBSTR(KR02AC15,1,1) = '1' AND PT_DT= '${process_date}' AND DEL_F='0'
GROUP BY KR02AC15
,KR01AC22
,KR03BRNO
,KR04BRNO
,KR05FLAG
,KR06YYSM
,KR07STAF
,KR08STAF
,KR09DATE
,KR10STAM
,KR07YYSM
,KR11STAF
,KR12STAF
,KR13DATE
,KR14STAM) AS P1 -- 非柜面交易控制账户登记簿

LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款帐户主档
       ON P1.KR02AC15 = P2.AA01AC15
AND P2.PT_DT='${process_date}' 
AND P2.DEL_F='0' 
;
-- ==============聚合层字段映射（第2组）==============
-- 个人账户非柜面交易控制信息聚合

INSERT INTO TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM(
     MAIN_ACCT_NO -- 主账户编号
    ,SUB_ACCT_NO -- 子账户编号
    ,ACCT_NAME -- 账户名称
    ,EACCT_CLS_CD -- 电子账户分类代码
    ,CUST_IN_CD -- 客户内码
    ,DOC_NO -- 证件号码
    ,DOCTYP_CD -- 证件类型代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,CTRL_STATUS_CD -- 控制状态代码
    ,EACCT_TXN_SER_NO -- 电子账户交易流水号
    ,CTRL_RSN_DESC -- 控制原因描述
    ,CTRL_TELR_NO -- 控制柜员编号
    ,CTRL_AUTH_TELR_NO -- 控制授权柜员编号
    ,CTRL_DT -- 控制日期
    ,CTRL_TM_STAMP -- 控制时间戳
    ,CTRL_LIFTED_RSN_DESC -- 控制解除原因描述
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_DT -- 解除日期
    ,LIFTED_TM_STAMP -- 解除时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P2.CUSTAC AS MAIN_ACCT_NO -- 主账户编号
    ,P1.CARDNO AS SUB_ACCT_NO -- 子账户编号
    ,P1.CUSTNA AS ACCT_NAME -- 账户名称
    ,P1.ACCATP AS EACCT_CLS_CD -- 电子账户分类代码
    ,P4.CUSTCD AS CUST_IN_CD -- 客户内码
    ,P1.IDTFNO AS DOC_NO -- 证件号码
    ,P1.IDTFTP AS DOCTYP_CD -- 证件类型代码
    ,P1.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.CORPNO AS LP_ORG_NO -- 法人机构编号
    ,P1.CTRLST AS CTRL_STATUS_CD -- 控制状态代码
    ,P1.TRANSQ AS EACCT_TXN_SER_NO -- 电子账户交易流水号
    ,P1.CTRLRS AS CTRL_RSN_DESC -- 控制原因描述
    ,P1.CTRLUS AS CTRL_TELR_NO -- 控制柜员编号
    ,P1.CTATUS AS CTRL_AUTH_TELR_NO -- 控制授权柜员编号
    ,SUBSTR(unifiedTime(P1.CTRLDT),1,10) AS CTRL_DT -- 控制日期
    ,unifiedTime(P1.CTRLTS) AS CTRL_TM_STAMP -- 控制时间戳
    ,P1.RSDETL AS CTRL_LIFTED_RSN_DESC -- 控制解除原因描述
    ,P1.REMVUS AS LIFTED_TELR_NO -- 解除柜员编号
    ,P1.RMATUS AS LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,SUBSTR(unifiedTime(P1.REMVDT),1,10) AS LIFTED_DT -- 解除日期
    ,unifiedTime(P1.REMVTS) AS LIFTED_TM_STAMP -- 解除时间戳
    ,'NFCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNB_CTRL_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
(SELECT CARDNO
,CUSTNA
,ACCATP
,IDTFNO
,IDTFTP
,BRCHNO
,CORPNO
,CTRLST
,TRANSQ
,CTRLRS
,CTRLUS
,CTATUS
,CTRLDT
,CTRLTS
,RSDETL
,REMVUS
,RMATUS
,REMVDT
,REMVTS
FROM ODS_NAS.ODS_NAS_KNB_CTRL_TF 
WHERE  PT_DT= '${process_date}' AND DEL_F='0'
GROUP BY CARDNO
,CUSTNA
,ACCATP
,IDTFNO
,IDTFTP
,BRCHNO
,CORPNO
,CTRLST
,TRANSQ
,CTRLRS
,CTRLUS
,CTATUS
,CTRLDT
,CTRLTS
,RSDETL
,REMVUS
,RMATUS
,REMVDT
,REMVTS) AS P1 -- 非柜面控制登记簿

LEFT JOIN ODS_NAS.ODS_NAS_KNA_ACDC_TF AS P2 -- 卡客户账号对照表
       ON P1.CARDNO = P2.CARDNO
AND P2.PT_DT='${process_date}' 
AND P2.DEL_F='0' 
LEFT JOIN (SELECT CUSTAC,CUSTNO 
FROM ODS_NAS.ODS_NAS_KNA_ACCT_TF 
WHERE PT_DT='${process_date}' 
AND DEL_F='0' 
GROUP BY CUSTAC,CUSTNO) AS P3 -- None
       ON P2.CUSTAC = P3.CUSTAC 
LEFT JOIN ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF AS P4 -- 客户信息关联表
       ON P3.CUSTNO  = P4.CUSTNO 
AND P4.STATUS='1'
AND P4.PT_DT='${process_date}' 
AND P4.DEL_F='0' 
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     MAIN_ACCT_NO -- 主账户编号
    ,SUB_ACCT_NO -- 子账户编号
    ,ACCT_NAME -- 账户名称
    ,EACCT_CLS_CD -- 电子账户分类代码
    ,CUST_IN_CD -- 客户内码
    ,DOC_NO -- 证件号码
    ,DOCTYP_CD -- 证件类型代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,CTRL_STATUS_CD -- 控制状态代码
    ,EACCT_TXN_SER_NO -- 电子账户交易流水号
    ,CTRL_RSN_DESC -- 控制原因描述
    ,CTRL_TELR_NO -- 控制柜员编号
    ,CTRL_AUTH_TELR_NO -- 控制授权柜员编号
    ,CTRL_DT -- 控制日期
    ,CTRL_TM_STAMP -- 控制时间戳
    ,CTRL_LIFTED_RSN_DESC -- 控制解除原因描述
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_DT -- 解除日期
    ,LIFTED_TM_STAMP -- 解除时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF_TM;
