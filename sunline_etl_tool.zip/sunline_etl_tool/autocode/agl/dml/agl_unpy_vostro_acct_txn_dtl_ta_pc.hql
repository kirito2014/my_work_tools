-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-银联来账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA
--     表中文名：银联来账交易明细聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO, UNPY_MSG_TYPE_NO, UNPY_TXN_PROC_CD, UNPY_TXN_TRANS_TM_STAMP, UNPY_EQUIP_SYS_TRACK_NO, ACPTD_TXN_UNPY_ORG_NO, SEND_TXN_UNPY_ORG_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '银联来账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,UNPY_VOSTRO_ACCT_TXN_TYPE_CD -- 银联来账交易类型代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,MVACCT_FLAG -- 动账标志
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,UNPY_VOSTRO_ACCT_TXN_STATUS_CD -- 银联来账交易状态代码
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,TXN_CNTRA_ACCT_NO -- 交易对手账户编号
    ,TXN_CNTRA_NAME -- 交易对手名称
    ,TXN_REM -- 交易备注
    ,REFUND_AMT -- 退款金额
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CLEAR_AMT -- 清算金额
    ,CHDER_STATUS_CERT_INFO_DESC -- 持卡人身份认证信息描述
    ,CARD_HOLDER_ACCT_NO_CURR_CD -- 持卡人账号币种代码
    ,CARD_HOLDER_DEDUCT_EXCH_RATE -- 持卡人扣账汇率
    ,CARD_HOLDER_DEDUCT_AMT -- 持卡人扣账金额
    ,ACPTD_ORG_CTRY_CD -- 受理机构国家代码
    ,ERR_INFO_DESC -- 错误信息描述
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,UNPY_MSG_TYPE_NO -- 银联报文类型编号
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,UNPY_TXN_TRANS_TM_STAMP -- 银联交易传输时间戳
    ,UNPY_EQUIP_SYS_TRACK_NO -- 银联设备系统跟踪号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RETRIV_REF_NO -- 检索参考号
    ,PRE_AUTH_NO -- 预授权编号
    ,UNPY_VOSTRO_ACCT_TERMN_TYPE_CD -- 银联来账终端类型代码
    ,USER_DEF_ADDIT_INFO_DESC -- 自定义附加信息描述
    ,RISK_ADDIT_INFO_DESC -- 风险附加信息描述
    ,RTN_GOODS_TXN_SER_NO -- 退货交易流水号
    ,BIZ_ADDIT_INFO_DESC -- 业务附加信息描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 银联来账交易明细聚合

INSERT INTO TABLE AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,UNPY_VOSTRO_ACCT_TXN_TYPE_CD -- 银联来账交易类型代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,MVACCT_FLAG -- 动账标志
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,UNPY_VOSTRO_ACCT_TXN_STATUS_CD -- 银联来账交易状态代码
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,TXN_CNTRA_ACCT_NO -- 交易对手账户编号
    ,TXN_CNTRA_NAME -- 交易对手名称
    ,TXN_REM -- 交易备注
    ,REFUND_AMT -- 退款金额
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CLEAR_AMT -- 清算金额
    ,CHDER_STATUS_CERT_INFO_DESC -- 持卡人身份认证信息描述
    ,CARD_HOLDER_ACCT_NO_CURR_CD -- 持卡人账号币种代码
    ,CARD_HOLDER_DEDUCT_EXCH_RATE -- 持卡人扣账汇率
    ,CARD_HOLDER_DEDUCT_AMT -- 持卡人扣账金额
    ,ACPTD_ORG_CTRY_CD -- 受理机构国家代码
    ,ERR_INFO_DESC -- 错误信息描述
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,UNPY_MSG_TYPE_NO -- 银联报文类型编号
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,UNPY_TXN_TRANS_TM_STAMP -- 银联交易传输时间戳
    ,UNPY_EQUIP_SYS_TRACK_NO -- 银联设备系统跟踪号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RETRIV_REF_NO -- 检索参考号
    ,PRE_AUTH_NO -- 预授权编号
    ,UNPY_VOSTRO_ACCT_TERMN_TYPE_CD -- 银联来账终端类型代码
    ,USER_DEF_ADDIT_INFO_DESC -- 自定义附加信息描述
    ,RISK_ADDIT_INFO_DESC -- 风险附加信息描述
    ,RTN_GOODS_TXN_SER_NO -- 退货交易流水号
    ,BIZ_ADDIT_INFO_DESC -- 业务附加信息描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.QDLSH_62 AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(SUBSTR(P1.QZJYRQ,1,8)) AS TXN_DT -- 交易日期
    ,unifiedTime(P1.QZJYRQ) AS TXN_TM_STAMP -- 交易时间戳
    ,CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) AS UNPY_VOSTRO_ACCT_TXN_TYPE_CD -- 银联来账交易类型代码
    ,P1.F_4/100 AS TXN_AMT -- 交易金额
    ,P1.F_49 AS TXN_CURR_CD -- 交易币种代码
    ,P1.SXFJE AS COMM_FEE_AMT -- 手续费金额
    ,CASE WHEN CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) IN 
('010000'
,'010003'
,'010020'
,'010030'
,'010033'
,'020030'
,'020089'
,'042000'
,'010089'
,'010092'
,'011033'
,'020020'
,'021020'
,'021030'
,'022000'
) THEN '不动账'
WHEN CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) IN('020000'
,'020001'
,'020021'
,'020029'
,'020046'
,'020047'
,'042001'
,'010024'
,'020060'
,'021046'
,'022020'
,'022029'
,'022047'
,'042046') THEN  '动账'
ELSE '' 
END  AS MVACCT_FLAG -- 动账标志
    ,CASE WHEN CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) IN 
('020001','020029','020046','010024','020060','021046','042046') THEN 'D'
 WHEN CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) IN 
 ( '020021','020047','042001','022020','022029','022047') THEN 'C'
 WHEN CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) = '020000' AND P1.F_25 = '28' THEN 'C'
 WHEN CONCAT(P1.F_1,SUBSTR(P1.F_3,1,2)) = '020000' AND P1.F_25 <> '28' THEN 'D'
 ELSE '' END  AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.JYZT AS UNPY_VOSTRO_ACCT_TXN_STATUS_CD -- 银联来账交易状态代码
    ,P1.F_2 AS TXN_CARD_NO -- 交易卡片编号
    ,CASE WHEN SUBSTR(P1.F_2,1,6) <> '623540' THEN P2.DFANAC19
WHEN SUBSTR(P1.F_2,1,6) = '623540' THEN P3.CUSTAC 
END  AS TXN_ACCT_NO -- 交易账户编号
    ,P1.KHJGH AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN SUBSTR(P1.F_2,1,6) <> '623540' THEN P2.CHNMNM40
 WHEN SUBSTR(P1.F_2,1,6) = '623540' THEN P4.CUSTNA 
END  AS CUST_NAME -- 客户名称
    ,CASE WHEN SUBSTR(P1.F_2,1,6) <> '623540' THEN P2.CINOCSNO
WHEN SUBSTR(P1.F_2,1,6) = '623540' THEN P5.CST_IN_CD 
END  AS CUST_IN_CD -- 客户内码
    ,CASE WHEN SUBSTR(P1.F_2,1,6) <> '623540' THEN P6.CRTF_TYP
WHEN  SUBSTR(P1.F_2,1,6)= '623540' THEN P4.IDTFTP 
END AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,CASE WHEN SUBSTR(P1.F_2,1,6) <> '623540' THEN P6.CRTF_NO
WHEN  SUBSTR(P1.F_2,1,6)= '623540' THEN P4.IDTFNO 
END AS CUST_DOC_NO -- 客户证件号码
    ,P1.F_102 AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,P1.F_103 AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,P1.DFZH AS TXN_CNTRA_ACCT_NO -- 交易对手账户编号
    ,P1.DFHM AS TXN_CNTRA_NAME -- 交易对手名称
    ,P1.F_48 AS TXN_REM -- 交易备注
    ,P1.YTJE AS REFUND_AMT -- 退款金额
    ,P1.F_42 AS MERCHT_NO -- 商户编号
    ,P1.F_43 AS MERCHT_NAME -- 商户名称
    ,P1.F_18 AS MERCHT_MCC_CD -- 商户MCC代码
    ,P1.F_15 AS PLAT_CLEAR_DT -- 平台清算日期
    ,P1.F_50 AS CLEAR_CURR_CD -- 清算币种代码
    ,P1.F_9 AS CLEAR_EXCH_RATE -- 清算汇率
    ,P1.QSJE AS CLEAR_AMT -- 清算金额
    ,P1.F_61 AS CHDER_STATUS_CERT_INFO_DESC -- 持卡人身份认证信息描述
    ,P1.F_51 AS CARD_HOLDER_ACCT_NO_CURR_CD -- 持卡人账号币种代码
    ,P1.F_10 AS CARD_HOLDER_DEDUCT_EXCH_RATE -- 持卡人扣账汇率
    ,P1.F_6 AS CARD_HOLDER_DEDUCT_AMT -- 持卡人扣账金额
    ,P1.F_19 AS ACPTD_ORG_CTRY_CD -- 受理机构国家代码
    ,P1.ERRMSG AS ERR_INFO_DESC -- 错误信息描述
    ,SUBSTR(F_22,1,2) AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,P1.F_25 AS SERV_POINT_COND_CD -- 服务点条件代码
    ,P1.F_1 AS UNPY_MSG_TYPE_NO -- 银联报文类型编号
    ,P1.F_3 AS UNPY_TXN_PROC_CD -- 银联交易处理码
    ,unifiedTime(P1.F_7) AS UNPY_TXN_TRANS_TM_STAMP -- 银联交易传输时间戳
    ,P1.F_11 AS UNPY_EQUIP_SYS_TRACK_NO -- 银联设备系统跟踪号
    ,P1.F_32 AS ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,P1.F_33 AS SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,P1.F_100 AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,P1.F_37 AS RETRIV_REF_NO -- 检索参考号
    ,P1.F_38 AS PRE_AUTH_NO -- 预授权编号
    ,P1.F_60_2_5 AS UNPY_VOSTRO_ACCT_TERMN_TYPE_CD -- 银联来账终端类型代码
    ,P1.F_60 AS USER_DEF_ADDIT_INFO_DESC -- 自定义附加信息描述
    ,P1.F_125 AS RISK_ADDIT_INFO_DESC -- 风险附加信息描述
    ,P1.YLF_90 AS RTN_GOODS_TXN_SER_NO -- 退货交易流水号
    ,P1.F_104 AS BIZ_ADDIT_INFO_DESC -- 业务附加信息描述
    ,'CARD' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CARD_YLLSB_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CARD.ODS_CARD_YLLSB_TA AS P1 -- 银联来账交易流水表

LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P2 -- 借记卡信息主档
       ON P1.F_2 = P2.CDNOAC19
      AND P2.DEL_F = '0'
      AND P2.PT_DT = '${process_date}' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_ACDC_TF AS P3 -- 卡客户账号对照表
       ON P1.F_2 = P3.CARDNO
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_CUST_TF AS P4 -- 电子账户表
       ON P3.CUSTAC = P4.CUSTAC
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT
 CCPC.CST_IN_CD
,CCPC.CRTF_TYP
,CCPC.CRTF_NO
,ROW_NUMBER()OVER(PARTITION BY CRTF_NO ORDER BY GMT_MODIFIED DESC) RN
FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF CCPC -- 客户证件信息表
WHERE CCPC.DEL_F = '0' AND CCPC.PT_DT='${process_date}'
  AND CCPC.MAJOR_FLG = '1'
  AND CCPC.DELETED = '0'
) AS P5 -- 客户证件信息表
       ON P4.IDTFNO = P5.CRTF_NO
      AND P5.RN = 1 
LEFT JOIN (
SELECT
 CCPC.CST_IN_CD
,CCPC.CRTF_TYP
,CCPC.CRTF_NO
,ROW_NUMBER()OVER(PARTITION BY CST_IN_CD ORDER BY GMT_MODIFIED DESC) RN
FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF CCPC -- 客户证件信息表
WHERE CCPC.DEL_F = '0' AND CCPC.PT_DT='${process_date}'
  AND CCPC.MAJOR_FLG = '1'
  AND CCPC.DELETED = '0'
) AS P6 -- 客户证件信息表
       ON P2.CINOCSNO = P6.CST_IN_CD
      AND P6.RN = 1 
WHERE P1.PT_DT = '${process_date}'  AND SUBSTR(P1.F_2,1,6) NOT IN ('628280','621842')  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,UNPY_VOSTRO_ACCT_TXN_TYPE_CD -- 银联来账交易类型代码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,MVACCT_FLAG -- 动账标志
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,UNPY_VOSTRO_ACCT_TXN_STATUS_CD -- 银联来账交易状态代码
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,TXN_CNTRA_ACCT_NO -- 交易对手账户编号
    ,TXN_CNTRA_NAME -- 交易对手名称
    ,TXN_REM -- 交易备注
    ,REFUND_AMT -- 退款金额
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CLEAR_AMT -- 清算金额
    ,CHDER_STATUS_CERT_INFO_DESC -- 持卡人身份认证信息描述
    ,CARD_HOLDER_ACCT_NO_CURR_CD -- 持卡人账号币种代码
    ,CARD_HOLDER_DEDUCT_EXCH_RATE -- 持卡人扣账汇率
    ,CARD_HOLDER_DEDUCT_AMT -- 持卡人扣账金额
    ,ACPTD_ORG_CTRY_CD -- 受理机构国家代码
    ,ERR_INFO_DESC -- 错误信息描述
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,UNPY_MSG_TYPE_NO -- 银联报文类型编号
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,UNPY_TXN_TRANS_TM_STAMP -- 银联交易传输时间戳
    ,UNPY_EQUIP_SYS_TRACK_NO -- 银联设备系统跟踪号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RETRIV_REF_NO -- 检索参考号
    ,PRE_AUTH_NO -- 预授权编号
    ,UNPY_VOSTRO_ACCT_TERMN_TYPE_CD -- 银联来账终端类型代码
    ,USER_DEF_ADDIT_INFO_DESC -- 自定义附加信息描述
    ,RISK_ADDIT_INFO_DESC -- 风险附加信息描述
    ,RTN_GOODS_TXN_SER_NO -- 退货交易流水号
    ,BIZ_ADDIT_INFO_DESC -- 业务附加信息描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TA_TM;
