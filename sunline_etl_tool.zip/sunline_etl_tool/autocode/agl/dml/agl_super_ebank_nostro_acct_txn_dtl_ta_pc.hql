-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-超级网银往账交易明细
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA
--     表中文名：超级网银往账交易明细
--     创建日期：2024-06-13 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：取超级网银T_IBPS_BOOK表的贷记往账、借记往账。剔除借记来账、三方来账（指如国家电网等代收付单位）
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 同步20240822 设计



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '超级网银往账交易明细-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,PAYER_NO -- 付款人编号
    ,PAYER_NAME -- 付款人名称
    ,PAYER_TYPE_CD -- 付款人类型代码
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_BANK_NO -- 付款行行号
    ,PAY_BANK_NAME -- 付款行名称
    ,PAY_BANK_IDNT_CD -- 付款行标识代码
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_CN_NAME -- 收款人中文名称
    ,PAYEE_TYPE_CD -- 收款人类型代码
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,RECV_BANK_NAME -- 收款行名称/接收行名称
    ,RECV_BANK_DIST_CD -- 收款行行政区划代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,BIZ_TYPE_NO -- 业务类型编号
    ,TXN_BIZ_CATE_CD -- 交易业务种类代码
    ,CURR_CD -- 币种代码
    ,STL_AMT -- 结算金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,SUPER_EBANK_BIZ_STATUS_CD -- 超级网银业务状态代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,DEAL_RESLT_CD -- 处理结果码
    ,DEAL_RESLT_DESC -- 处理结果描述
    ,BIZ_REFUS_CD -- 业务拒绝码
    ,BIZ_REFUS_DESC -- 业务拒绝描述
    ,ACCTN_DT -- 记账日期
    ,ACCTN_SER_NO -- 记账流水号
    ,ACCTN_SRC_SYS_CD -- 记账来源系统代码
    ,MSG_SEND_DT -- 报文发送日期
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INITR_SYS_CD -- 发起方系统代码
    ,START_BANK_DIST_CD -- 发起行行政区划代码
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECER_SYS_CD -- 接收方系统代码
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,TXN_ORG_NO -- 交易机构编号
    ,RECORD_ORG_NO -- 入账机构编号
    ,CHNL_CD -- 渠道代码
    ,CHNL_DT -- 渠道日期
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_FLOW_MSG_SEND_FLAG -- 渠道流水报文发送标志
    ,CHNL_USER_ID -- 渠道用户ID
    ,CERT_MODE_CD -- 认证方式代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,BAT_ACCTN_SUBJ_NO -- 批量会计科目编号
    ,BAT_ACTL_PAYER_ACCT_NO -- 批量实际付款人账户编号
    ,BAT_ACTL_PAYER_ACCT_NAME -- 批量实际付款人账户名称
    ,ONLINE_TXN_TM_STAMP -- 网上交易时间戳
    ,ONLINE_TXN_SER_NO -- 网上交易流水号
    ,ONLINE_TXN_ILUS -- 网上交易说明
    ,INTFC_FLAG_BIT -- 接口标志位
    ,ORIG_PAY_BANK_CNAPS_CODE -- 原付款行人行支付行号
    ,ORIG_SEND_DT -- 原发送日期
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_END_TO_END_IDE_NO -- 原端到端标识号
    ,ORIG_SUPER_EBANK_BIZ_STATUS_CD -- 原超级网银业务状态代码
    ,ORIG_PLAT_DT -- 原平台日期
    ,ORIG_PLAT_SER_NO -- 原平台流水号
    ,NOTICE_DT -- 通知日期
    ,NOTICE_MSG_NO -- 通知报文编号
    ,NTTG_SITE_CNT -- 轧差场次
    ,NTTG_DT -- 轧差日期
    ,MSG_CATEGORY_CD -- 报文类别代码
    ,MSG_NO -- 报文编号
    ,MSG_FORMAT_DESC -- 报文格式描述
    ,WORK_DT -- 工作日期
    ,COMMUNIC_IDE_NO -- 通讯标识号
    ,MSG_IDE_NO -- 报文标识号
    ,SUPER_EBANK_REF_CONT_IDNT_CD -- 超级网银参考往来往标识代码
    ,RCPT_MSG_DT -- 回执报文日期
    ,RCPT_MSG_NO -- 回执报文编号
    ,ENTRED_PAY_TXN_SER_NO -- 受托支付交易流水号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,PAYER_NO -- 付款人编号
    ,PAYER_NAME -- 付款人名称
    ,PAYER_TYPE_CD -- 付款人类型代码
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_BANK_NO -- 付款行行号
    ,PAY_BANK_NAME -- 付款行名称
    ,PAY_BANK_IDNT_CD -- 付款行标识代码
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_CN_NAME -- 收款人中文名称
    ,PAYEE_TYPE_CD -- 收款人类型代码
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,RECV_BANK_NAME -- 收款行名称/接收行名称
    ,RECV_BANK_DIST_CD -- 收款行行政区划代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,BIZ_TYPE_NO -- 业务类型编号
    ,TXN_BIZ_CATE_CD -- 交易业务种类代码
    ,CURR_CD -- 币种代码
    ,STL_AMT -- 结算金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,SUPER_EBANK_BIZ_STATUS_CD -- 超级网银业务状态代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,DEAL_RESLT_CD -- 处理结果码
    ,DEAL_RESLT_DESC -- 处理结果描述
    ,BIZ_REFUS_CD -- 业务拒绝码
    ,BIZ_REFUS_DESC -- 业务拒绝描述
    ,ACCTN_DT -- 记账日期
    ,ACCTN_SER_NO -- 记账流水号
    ,ACCTN_SRC_SYS_CD -- 记账来源系统代码
    ,MSG_SEND_DT -- 报文发送日期
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INITR_SYS_CD -- 发起方系统代码
    ,START_BANK_DIST_CD -- 发起行行政区划代码
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECER_SYS_CD -- 接收方系统代码
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,TXN_ORG_NO -- 交易机构编号
    ,RECORD_ORG_NO -- 入账机构编号
    ,CHNL_CD -- 渠道代码
    ,CHNL_DT -- 渠道日期
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_FLOW_MSG_SEND_FLAG -- 渠道流水报文发送标志
    ,CHNL_USER_ID -- 渠道用户ID
    ,CERT_MODE_CD -- 认证方式代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,BAT_ACCTN_SUBJ_NO -- 批量会计科目编号
    ,BAT_ACTL_PAYER_ACCT_NO -- 批量实际付款人账户编号
    ,BAT_ACTL_PAYER_ACCT_NAME -- 批量实际付款人账户名称
    ,ONLINE_TXN_TM_STAMP -- 网上交易时间戳
    ,ONLINE_TXN_SER_NO -- 网上交易流水号
    ,ONLINE_TXN_ILUS -- 网上交易说明
    ,INTFC_FLAG_BIT -- 接口标志位
    ,ORIG_PAY_BANK_CNAPS_CODE -- 原付款行人行支付行号
    ,ORIG_SEND_DT -- 原发送日期
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_END_TO_END_IDE_NO -- 原端到端标识号
    ,ORIG_SUPER_EBANK_BIZ_STATUS_CD -- 原超级网银业务状态代码
    ,ORIG_PLAT_DT -- 原平台日期
    ,ORIG_PLAT_SER_NO -- 原平台流水号
    ,NOTICE_DT -- 通知日期
    ,NOTICE_MSG_NO -- 通知报文编号
    ,NTTG_SITE_CNT -- 轧差场次
    ,NTTG_DT -- 轧差日期
    ,MSG_CATEGORY_CD -- 报文类别代码
    ,MSG_NO -- 报文编号
    ,MSG_FORMAT_DESC -- 报文格式描述
    ,WORK_DT -- 工作日期
    ,COMMUNIC_IDE_NO -- 通讯标识号
    ,MSG_IDE_NO -- 报文标识号
    ,SUPER_EBANK_REF_CONT_IDNT_CD -- 超级网银参考往来往标识代码
    ,RCPT_MSG_DT -- 回执报文日期
    ,RCPT_MSG_NO -- 回执报文编号
    ,ENTRED_PAY_TXN_SER_NO -- 受托支付交易流水号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(T1.plat_date) AS PLAT_DT -- 平台日期
    ,T1.seq_no AS PLAT_SER_NO -- 平台流水号
    ,T1.pay_act_no AS PAYER_NO -- 付款人编号
    ,T1.pay_act_name AS PAYER_NAME -- 付款人名称
    ,T1.pay_act_type AS PAYER_TYPE_CD -- 付款人类型代码
    ,T1.pay_clear_bank AS PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,T1.pay_bank AS PAY_BANK_BANK_NO -- 付款行行号
    ,T1.pay_bank_name AS PAY_BANK_NAME -- 付款行名称
    ,T1.pay_flag AS PAY_BANK_IDNT_CD -- 付款行标识代码
    ,T1.pme_act_no AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,T1.pme_act_name AS PAYEE_CN_NAME -- 收款人中文名称
    ,T1.pme_act_type AS PAYEE_TYPE_CD -- 收款人类型代码
    ,T1.pme_clear_bank AS FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,T1.pme_bank AS RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,T1.pme_bank_name AS RECV_BANK_NAME -- 收款行名称/接收行名称
    ,T1.pme_city AS RECV_BANK_DIST_CD -- 收款行行政区划代码
    ,T1.clear_type AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,T1.busi_type AS BIZ_TYPE_NO -- 业务类型编号
    ,T1.busi_prt_type AS TXN_BIZ_CATE_CD -- 交易业务种类代码
    ,T1.curr_no AS CURR_CD -- 币种代码
    ,T1.set_amt AS STL_AMT -- 结算金额
    ,T1.tx_amt AS TXN_AMT -- 交易金额
    ,T1.fee_amt AS COMM_FEE_AMT -- 手续费金额
    ,T1.busi_stat AS SUPER_EBANK_BIZ_STATUS_CD -- 超级网银业务状态代码
    ,T1.tran_stat AS MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,T1.tran_code AS DEAL_RESLT_CD -- 处理结果码
    ,T1.tran_msg AS DEAL_RESLT_DESC -- 处理结果描述
    ,T1.reject_code AS BIZ_REFUS_CD -- 业务拒绝码
    ,T1.reject_msg AS BIZ_REFUS_DESC -- 业务拒绝描述
    ,unifiedTime(T1.act_date) AS ACCTN_DT -- 记账日期
    ,T1.act_seq AS ACCTN_SER_NO -- 记账流水号
    ,CASE WHEN t1.DAC='2' THEN 'NAS' ELSE 'CORE' END  AS ACCTN_SRC_SYS_CD -- 记账来源系统代码
    ,unifiedTime(T1.send_date) AS MSG_SEND_DT -- 报文发送日期
    ,unifiedTime(T1.send_time) AS MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,T1.send_bank AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T1.send_sysid AS INITR_SYS_CD -- 发起方系统代码
    ,T1.pay_bank_city AS START_BANK_DIST_CD -- 发起行行政区划代码
    ,T1.recv_bank AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T1.recv_sysid AS RECER_SYS_CD -- 接收方系统代码
    ,T1.ent_id AS END_TO_END_IDE_NO -- 端到端标识号
    ,T1.brch_no AS TXN_ORG_NO -- 交易机构编号
    ,T1.act_brch AS RECORD_ORG_NO -- 入账机构编号
    ,T1.chn_type AS CHNL_CD -- 渠道代码
    ,unifiedTime(T1.chn_date) AS CHNL_DT -- 渠道日期
    ,T1.chn_seq AS CHNL_SER_NO -- 渠道流水号
    ,T1.chn_usr_type AS CHNL_FLOW_MSG_SEND_FLAG -- 渠道流水报文发送标志
    ,T1.chn_usr_id AS CHNL_USER_ID -- 渠道用户ID
    ,T1.use_type AS CERT_MODE_CD -- 认证方式代码
    ,T1.psn_no AS BATCH_SEQ_NO -- 批次顺序号
    ,T1.cust_no AS BAT_ACCTN_SUBJ_NO -- 批量会计科目编号
    ,T1.busi_no AS BAT_ACTL_PAYER_ACCT_NO -- 批量实际付款人账户编号
    ,T1.busi_name AS BAT_ACTL_PAYER_ACCT_NAME -- 批量实际付款人账户名称
    ,unifiedTime(T1.int_tx_time) AS ONLINE_TXN_TM_STAMP -- 网上交易时间戳
    ,T1.int_tx_no AS ONLINE_TXN_SER_NO -- 网上交易流水号
    ,T1.int_tx_summary AS ONLINE_TXN_ILUS -- 网上交易说明
    ,T1.oth_bank AS INTFC_FLAG_BIT -- 接口标志位
    ,T1.old_pay_flag AS ORIG_PAY_BANK_CNAPS_CODE -- 原付款行人行支付行号
    ,unifiedTime(T1.old_agt_date) AS ORIG_SEND_DT -- 原发送日期
    ,T1.old_msg_id AS ORIG_MSG_NO -- 原报文编号
    ,T1.old_book_id AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.old_ent_id AS ORIG_END_TO_END_IDE_NO -- 原端到端标识号
    ,T1.old_busi_stat AS ORIG_SUPER_EBANK_BIZ_STATUS_CD -- 原超级网银业务状态代码
    ,unifiedTime(T1.old_date) AS ORIG_PLAT_DT -- 原平台日期
    ,T1.old_seq AS ORIG_PLAT_SER_NO -- 原平台流水号
    ,unifiedTime(T1.set_date) AS NOTICE_DT -- 通知日期
    ,T1.set_msg_id AS NOTICE_MSG_NO -- 通知报文编号
    ,T1.clear_num AS NTTG_SITE_CNT -- 轧差场次
    ,unifiedTime(T1.clear_date) AS NTTG_DT -- 轧差日期
    ,T1.msg_flag AS MSG_CATEGORY_CD -- 报文类别代码
    ,T1.msg_type AS MSG_NO -- 报文编号
    ,T1.stu_type AS MSG_FORMAT_DESC -- 报文格式描述
    ,unifiedTime(T1.agt_date) AS WORK_DT -- 工作日期
    ,T1.mesg_id AS COMMUNIC_IDE_NO -- 通讯标识号
    ,T1.msg_id AS MSG_IDE_NO -- 报文标识号
    ,T1.msg_ref_id AS SUPER_EBANK_REF_CONT_IDNT_CD -- 超级网银参考往来往标识代码
    ,unifiedTime(T1.back_date) AS RCPT_MSG_DT -- 回执报文日期
    ,T1.back_msg_id AS RCPT_MSG_NO -- 回执报文编号
    ,T1.detail1 AS ENTRED_PAY_TXN_SER_NO -- 受托支付交易流水号
    ,'EPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_EPS_T_IBPS_BOOK_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ods_eps.ods_eps_t_ibps_book_ta AS T1 -- 网上跨行支付清算登记薄

WHERE t1.clear_type='0'
and  t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,PAYER_NO -- 付款人编号
    ,PAYER_NAME -- 付款人名称
    ,PAYER_TYPE_CD -- 付款人类型代码
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_BANK_NO -- 付款行行号
    ,PAY_BANK_NAME -- 付款行名称
    ,PAY_BANK_IDNT_CD -- 付款行标识代码
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_CN_NAME -- 收款人中文名称
    ,PAYEE_TYPE_CD -- 收款人类型代码
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,RECV_BANK_NAME -- 收款行名称/接收行名称
    ,RECV_BANK_DIST_CD -- 收款行行政区划代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,BIZ_TYPE_NO -- 业务类型编号
    ,TXN_BIZ_CATE_CD -- 交易业务种类代码
    ,CURR_CD -- 币种代码
    ,STL_AMT -- 结算金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,SUPER_EBANK_BIZ_STATUS_CD -- 超级网银业务状态代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,DEAL_RESLT_CD -- 处理结果码
    ,DEAL_RESLT_DESC -- 处理结果描述
    ,BIZ_REFUS_CD -- 业务拒绝码
    ,BIZ_REFUS_DESC -- 业务拒绝描述
    ,ACCTN_DT -- 记账日期
    ,ACCTN_SER_NO -- 记账流水号
    ,ACCTN_SRC_SYS_CD -- 记账来源系统代码
    ,MSG_SEND_DT -- 报文发送日期
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INITR_SYS_CD -- 发起方系统代码
    ,START_BANK_DIST_CD -- 发起行行政区划代码
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECER_SYS_CD -- 接收方系统代码
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,TXN_ORG_NO -- 交易机构编号
    ,RECORD_ORG_NO -- 入账机构编号
    ,CHNL_CD -- 渠道代码
    ,CHNL_DT -- 渠道日期
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_FLOW_MSG_SEND_FLAG -- 渠道流水报文发送标志
    ,CHNL_USER_ID -- 渠道用户ID
    ,CERT_MODE_CD -- 认证方式代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,BAT_ACCTN_SUBJ_NO -- 批量会计科目编号
    ,BAT_ACTL_PAYER_ACCT_NO -- 批量实际付款人账户编号
    ,BAT_ACTL_PAYER_ACCT_NAME -- 批量实际付款人账户名称
    ,ONLINE_TXN_TM_STAMP -- 网上交易时间戳
    ,ONLINE_TXN_SER_NO -- 网上交易流水号
    ,ONLINE_TXN_ILUS -- 网上交易说明
    ,INTFC_FLAG_BIT -- 接口标志位
    ,ORIG_PAY_BANK_CNAPS_CODE -- 原付款行人行支付行号
    ,ORIG_SEND_DT -- 原发送日期
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_END_TO_END_IDE_NO -- 原端到端标识号
    ,ORIG_SUPER_EBANK_BIZ_STATUS_CD -- 原超级网银业务状态代码
    ,ORIG_PLAT_DT -- 原平台日期
    ,ORIG_PLAT_SER_NO -- 原平台流水号
    ,NOTICE_DT -- 通知日期
    ,NOTICE_MSG_NO -- 通知报文编号
    ,NTTG_SITE_CNT -- 轧差场次
    ,NTTG_DT -- 轧差日期
    ,MSG_CATEGORY_CD -- 报文类别代码
    ,MSG_NO -- 报文编号
    ,MSG_FORMAT_DESC -- 报文格式描述
    ,WORK_DT -- 工作日期
    ,COMMUNIC_IDE_NO -- 通讯标识号
    ,MSG_IDE_NO -- 报文标识号
    ,SUPER_EBANK_REF_CONT_IDNT_CD -- 超级网银参考往来往标识代码
    ,RCPT_MSG_DT -- 回执报文日期
    ,RCPT_MSG_NO -- 回执报文编号
    ,ENTRED_PAY_TXN_SER_NO -- 受托支付交易流水号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA_TM;
