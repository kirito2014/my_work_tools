-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人借记卡变更明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_DEBIT_CARD_CHANGE_DTL_TF
--     表中文名：个人借记卡变更明细聚合
--     创建日期：2023-12-14 00:00:00
--     主键字段：CARD_NO, CARD_CHG_TM_STAMP, CARD_CHG_EVENT_NO, CARD_CHG_TYPE_CD, CURR_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军/魏丹丹
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-14 00:00:00 游崔龙 新增
--         2023-01-11 00:00:00 游崔龙 对标
--         2024-02-22 00:00:00 王穆军/魏丹丹 修改问题
--         2024-07-23 00:00:00 王穆军/魏丹丹 修改同步设计文档
--         2024-08-05 00:00:00 王穆军/魏丹丹 修改第7-8组字段映射 拼接000,补充缺失码值映射
--         2024-08-19 00:00:00 王穆军/魏丹丹 修改生产验证反馈问题
--         2024-09-24 00:00:00 王穆军/魏丹丹 新增字段 联合主键



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM
USING ORC
COMMENT '个人借记卡变更明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人借记卡变更明细聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01;

CREATE TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01 (
     CDNOAC19 STRING COMMENT '卡号'
    ,CINOCSNO STRING COMMENT '客户内码'
    ,CUST_NM STRING COMMENT '客户名称'
    ,CRTF_TYP STRING COMMENT '证件类型'
    ,CRTF_NO STRING COMMENT '证件号码'
    ,CONT_NBR STRING COMMENT '联系号码'
    ,ADDR STRING COMMENT '详细地址'
    ,MECDMECD STRING COMMENT '联名认同单位号'
    ,CRDNCRDN STRING COMMENT '卡性质'
    ,CRDMCRDM STRING COMMENT '卡介质'
    ,CFLGCFLG STRING COMMENT '协议卡标志'
    ,OPONBRNO STRING COMMENT '统计机构'
    ,HSJGBRNO STRING COMMENT '法人机构编号'
    ,OWONBRNO STRING COMMENT '归属机构编号'
    ,DFANAC19 STRING COMMENT '账户编号'
    ,PTCDPDTP STRING COMMENT '卡产品代码'
    ,PDCDPRON STRING COMMENT '卡产品代码'
    ,pccyccyc STRING COMMENT '币种代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡变更明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01(
     CDNOAC19 -- 卡号
    ,CINOCSNO -- 客户内码
    ,CUST_NM -- 客户名称
    ,CRTF_TYP -- 证件类型
    ,CRTF_NO -- 证件号码
    ,CONT_NBR -- 联系号码
    ,ADDR -- 详细地址
    ,MECDMECD -- 联名认同单位号
    ,CRDNCRDN -- 卡性质
    ,CRDMCRDM -- 卡介质
    ,CFLGCFLG -- 协议卡标志
    ,OPONBRNO -- 统计机构
    ,HSJGBRNO -- 法人机构编号
    ,OWONBRNO -- 归属机构编号
    ,DFANAC19 -- 账户编号
    ,PTCDPDTP -- 卡产品代码
    ,PDCDPRON -- 卡产品代码
    ,pccyccyc -- 币种代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CDNOAC19 AS CDNOAC19 -- 卡号
    ,P1.CINOCSNO AS CINOCSNO -- 客户内码
    ,p5.CUST_NM AS CUST_NM -- 客户名称
    ,P2.CRTF_TYP AS CRTF_TYP -- 证件类型
    ,P2.CRTF_NO AS CRTF_NO -- 证件号码
    ,P3.CONT_NBR AS CONT_NBR -- 联系号码
    ,P4.ADDR AS ADDR -- 详细地址
    ,P1.MECDMECD AS MECDMECD -- 联名认同单位号
    ,P1.CRDNCRDN AS CRDNCRDN -- 卡性质
    ,P1.CRDMCRDM AS CRDMCRDM -- 卡介质
    ,P1.CFLGCFLG AS CFLGCFLG -- 协议卡标志
    ,P1.OPONBRNO AS OPONBRNO -- 统计机构
    ,P1.HSJGBRNO AS HSJGBRNO -- 法人机构编号
    ,P1.OWONBRNO AS OWONBRNO -- 归属机构编号
    ,P1.DFANAC19 AS DFANAC19 -- 账户编号
    ,P1.PTCDPDTP AS PTCDPDTP -- 卡产品代码
    ,P1.PDCDPRON AS PDCDPRON -- 卡产品代码
    ,P1.pccyccyc AS pccyccyc -- 币种代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
         D1.OPONBRNO
        ,D1.MECDMECD
        ,D1.CRDNCRDN
        ,D1.CRDMCRDM
        ,D1.CFLGCFLG
        ,D1.CDNOAC19
        ,D1.CINOCSNO
        ,D1.CHNMNM40
        ,D1.HSJGBRNO
        ,D1.OWONBRNO
        ,D1.DFANAC19
        ,D1.PTCDPDTP
        ,D1.PDCDPRON
        ,D1.pccyccyc

 FROM 
 ODS_CORE.ODS_CORE_BWFMDCIM_TF D1 --借记卡主档
 WHERE 
    D1.PT_DT = '${process_date}'   
AND DEL_F = '0'  
) AS P1 -- 借记卡主档

LEFT JOIN (
 SELECT  D2.CST_IN_CD
        ,D2.CRTF_TYP
        ,D2.CRTF_NO
 FROM (
       SELECT T1.CST_IN_CD
             ,T1.CRTF_TYP
             ,T1.CRTF_NO
             ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
       FROM  ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF T1  --证件信息表
       WHERE  T1.MAJOR_FLG='1'
       AND    T1.PT_DT = '${process_date}'
AND DEL_F ='0'
      ) D2
 WHERE  D2.RN= 1
)
 AS P2 -- 证件信息
       ON P1.CINOCSNO = P2.CST_IN_CD  
LEFT JOIN (
SELECT  D3.CST_IN_CD
       ,D3.CONT_NBR
       ,D3.CORP_ORG_NO
FROM (
      SELECT T1.CST_IN_CD
            ,T1.CONT_NBR
            ,T1.CORP_ORG_NO
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
   FROM   ODS_EICC.ODS_EICC_C_CUS_PRIV_CONT_TF T1  --客户联系方式信息表
   WHERE  T1.PT_DT = '${process_date}'
AND DEL_F = '0'
  ) D3
WHERE D3.RN = 1
)
 AS P3 -- 联系信息
       ON P1.CINOCSNO = P3.CST_IN_CD 
and left(p1.OWONBRNO,3)= left(p3.CORP_ORG_NO,3) 
LEFT JOIN (
 SELECT D4.CST_IN_CD
       ,D4.ADDR
       ,D4.CORP_ORG_NO
 FROM(
      SELECT T1.CST_IN_CD
            ,T1.ADDR
            ,T1.CORP_ORG_NO
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
   FROM   ODS_EICC.ODS_EICC_C_CUS_PRIV_ADDR_TF T1  --客户地址信息表
   WHERE  T1.PT_DT = '${process_date}'
AND DEL_F = '0'
  ) D4
 WHERE D4.RN = 1 
) AS P4 -- 地址信息
       ON P1.CINOCSNO = P4.CST_IN_CD 
and left(p1.OWONBRNO,3) = left(p4.CORP_ORG_NO,3) 
LEFT JOIN ODS_EICC.ODS_EICC_C_CUS_PRIV_BAS_TF AS P5 -- 客户基础信息表
       ON P1.CINOCSNO=P5.CST_IN_CD 
and SUBSTR(p5.CUST_ORG_NO,1,3)=substr(p1.OWONBRNO,1,3)
and p5.pt_dt = '${process_date}'
and p5.del_f = '0' 
;
-- ==============聚合层字段映射（第2组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.BC01AC22 AS CARD_NO -- 卡片编号
    ,CONCAT(SUBSTR(P1.BC31DATE,1,4),'-',SUBSTR(P1.BC31DATE,5,2),'-',SUBSTR(P1.BC31DATE,7,2),' 00:00:00') AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CONCAT(SUBSTR(P1.BC31DATE,1,4),'-',SUBSTR(P1.BC31DATE,5,2),'-',SUBSTR(P1.BC31DATE,7,2),' 00:00:00') AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'1' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,P1.BC03CCYC AS CURR_CD -- 币种代码
    ,'开卡' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,P1.BC32BRNO AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.BC34STAF AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,'' AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,P1.BC30BRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BC25BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.BC05AC15 AS ACCT_NO -- 账户编号
    ,P1.BC37FLNM AS ACCT_NAME -- 账户名称
    ,CASE WHEN P1.BC08ZHTP IS NULL OR TRIM(P1.BC08ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.BC08ZHTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.BC07CSNO AS CUST_IN_CD -- 客户内码
    ,P5.CUST_NM AS CUST_NAME -- 客户名称
    ,P21.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P21.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P3.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P4.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,P6.DL01NM80 AS AGENT_NAME -- 代理人名称
    ,P6.DL01CFTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P6.DL01CFNO AS AGENT_DOC_NO -- 代理人证件号码
    ,p2.PTCDPDTP||p2.PDCDPRON AS CARD_PROD_CD -- 卡产品代码
    ,P2.MECDMECD AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,P2.CRDNCRDN AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,P2.CRDMCRDM AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,P2.CFLGCFLG AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,'' AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,'' AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,'' AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,'' AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,'' AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,P1.BC35CNCD AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,'' AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,'' AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,'' AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,P1.BC19AMT AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,P1.BC21AC15 AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,P1.BC22AMT AS MAX_LMT -- 最高限额
    ,P1.BC24DATE AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,CASE WHEN P1.RCSTRS1B = '' THEN '0' 
WHEN P1.RCSTRS1B = '9' THEN '9' ELSE P1.RCSTRS1B END  AS REC_STATUS_CD -- 记录状态代码
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'' AS FINAL_MODIF_DT -- 最后修改日期
    ,'' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQBC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
 
   D1.BC01AC22
  ,D1.BC31DATE
  ,D1.BC32BRNO
  ,D1.BC34STAF
  ,D1.BC30BRNO
  ,D1.BC25BRNO
  ,D1.BC05AC15
  ,D1.BC37FLNM
  ,D1.BC08ZHTP
  ,D1.BC07CSNO
  ,D1.BC39PDTP
  ,D1.BC40PRON
  ,D1.BC35CNCD
  ,D1.BC19AMT
  ,D1.BC21AC15
  ,D1.BC22AMT
  ,D1.BC24DATE
  ,D1.RCSTRS1B
  ,D1.BC03CCYC
  
 FROM 
 ODS_CORE.ODS_CORE_BDFMHQBC_TF D1
 WHERE 
   D1.BC05SSMK='2' 
   AND length(D1.BC01AC22)=19 
   AND D1.PT_DT = '${process_date}'     
AND DEL_F = '0'  
) AS P1 -- 开户登记簿

LEFT JOIN (
 SELECT 
         D1.OPONBRNO
        ,D1.MECDMECD
        ,D1.CRDNCRDN
        ,D1.CRDMCRDM
        ,D1.CFLGCFLG
        ,D1.CDNOAC19
        ,D1.CINOCSNO
        ,D1.CHNMNM40
        ,D1.HSJGBRNO
        ,D1.OWONBRNO
        ,D1.DFANAC19
        ,D1.PTCDPDTP
        ,D1.PDCDPRON

 FROM 
 ODS_CORE.ODS_CORE_BWFMDCIM_TF D1 --借记卡主档
 WHERE 
    D1.PT_DT = '${process_date}'   
AND DEL_F = '0'  
) AS P2 -- 借记卡主档
       ON P1.BC01AC22 = P2.CDNOAC19  
LEFT JOIN (
 SELECT  D2.CST_IN_CD
        ,D2.CRTF_TYP
        ,D2.CRTF_NO
 FROM (
       SELECT T1.CST_IN_CD
             ,T1.CRTF_TYP
             ,T1.CRTF_NO
             ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
       FROM  ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF T1  --证件信息表
       WHERE  T1.MAJOR_FLG='1'
       AND    T1.PT_DT = '${process_date}'
AND DEL_F ='0'
      ) D2
 WHERE  D2.RN= 1
)
 AS P21 -- 证件信息
       ON P1.BC07CSNO = P21.CST_IN_CD  
LEFT JOIN (
SELECT  D3.CST_IN_CD
       ,D3.CONT_NBR
       ,D3.CORP_ORG_NO
FROM (
      SELECT T1.CST_IN_CD
            ,T1.CONT_NBR
            ,T1.CORP_ORG_NO
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
   FROM   ODS_EICC.ODS_EICC_C_CUS_PRIV_CONT_TF T1  --客户联系方式信息表
   WHERE  T1.PT_DT = '${process_date}'
AND DEL_F = '0'
  ) D3
WHERE D3.RN = 1
)
 AS P3 -- 联系信息
       ON P1.BC07CSNO = P3.CST_IN_CD 
and substr(p1.BC25BRNO,1,3)= substr(p3.CORP_ORG_NO,1,3) 
LEFT JOIN (
 SELECT D4.CST_IN_CD
       ,D4.ADDR
       ,D4.CORP_ORG_NO
 FROM(
      SELECT T1.CST_IN_CD
            ,T1.ADDR
            ,T1.CORP_ORG_NO
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
   FROM   ODS_EICC.ODS_EICC_C_CUS_PRIV_ADDR_TF T1  --客户地址信息表
   WHERE  T1.PT_DT = '${process_date}'
AND DEL_F = '0'
  ) D4
 WHERE D4.RN = 1 
) AS P4 -- 地址信息
       ON P1.BC07CSNO = P4.CST_IN_CD 
and substr(p1.BC25BRNO,1,3)= substr(p4.CORP_ORG_NO,1,3) 
LEFT JOIN ODS_EICC.ODS_EICC_C_CUS_PRIV_BAS_TF AS P5 -- 客户基础信息表
       ON P1.BC07CSNO=P5.CST_IN_CD 
and SUBSTR(p5.CUST_ORG_NO,1,3)=substr(p1.BC25BRNO,1,3)
and p5.PT_DT = '${process_date}'     
AND p5.DEL_F = '0'   
LEFT JOIN (
 SELECT 
         D3.DL01NM80
        ,D3.DL01CFTP
        ,D3.DL01CFNO
        ,D3.DL01AC19 
 FROM 
 ODS_CORE.ODS_CORE_BWFMDLKK_TF D3 --代理人开卡数量统计登记簿
 WHERE 
    D3.PT_DT = '${process_date}'  
AND DEL_F = '0'     
) AS P6 -- 代理人开卡数量统计登记簿
       ON P1.BC01AC22 = P6.DL01AC19 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BDFMHQBC' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='BC08ZHTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P1.BC08ZHTP=S1.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第3组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.BQ01AC22 AS CARD_NO -- 卡片编号
    ,CONCAT(SUBSTR(P1.BQ06DATE,1,4),'-',SUBSTR(P1.BQ06DATE,5,2),'-',SUBSTR(P1.BQ06DATE,7,2),' 00:00:00') AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CONCAT(SUBSTR(P1.BQ06DATE,1,4),'-',SUBSTR(P1.BQ06DATE,5,2),'-',SUBSTR(P1.BQ06DATE,7,2),' 00:00:00') AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'2' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,p1.bq03ccyc AS CURR_CD -- 币种代码
    ,'销卡' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,P1.BQ07BRNO AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.BQ08STAF AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,'' AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,P1.BQ15BRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BQ14BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.BQ05AC15 AS ACCT_NO -- 账户编号
    ,P3.AA04FLNM AS ACCT_NAME -- 账户名称
    ,CASE WHEN P3.AA13ZHTP IS NULL OR TRIM(P3.AA13ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P3.AA13ZHTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P2.CINOCSNO AS CUST_IN_CD -- 客户内码
    ,P2.CUST_NM AS CUST_NAME -- 客户名称
    ,P2.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P2.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P2.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P2.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,'' AS AGENT_NAME -- 代理人名称
    ,'' AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,'' AS AGENT_DOC_NO -- 代理人证件号码
    ,p2.PTCDPDTP||p2.PDCDPRON AS CARD_PROD_CD -- 卡产品代码
    ,'' AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,'' AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,'' AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,'' AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,'' AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,'' AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,'' AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,P1.BQ09CNCD AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CASE WHEN P1.BQ10CLSN IS NULL OR TRIM(P1.BQ10CLSN)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.BQ10CLSN)),'') END AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,'' AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,'' AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,P1.BQ11AMT AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,P1.BQ12AMT AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,P1.BQ13AMT AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,P1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'' AS FINAL_MODIF_DT -- 最后修改日期
    ,'' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQBQ_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
     SELECT 
     
         D1.BQ01AC22
        ,D1.BQ06DATE
        ,D1.BQ07BRNO
        ,D1.BQ08STAF
        ,D1.BQ15BRNO
        ,D1.BQ14BRNO
        ,D1.BQ05AC15
        ,D1.BQ16PDTP
        ,D1.BQ17PRON
        ,D1.BQ09CNCD
        ,D1.BQ10CLSN
        ,D1.BQ11AMT
        ,D1.BQ12AMT
        ,D1.BQ13AMT
        ,D1.RCSTRS1B
        ,d1.bq03ccyc
     FROM 
     ODS_CORE.ODS_CORE_BDFMHQBQ_TF D1 --销户登记簿
     WHERE 
        D1.BQ05SSMK = '2' 
        and length(D1.BQ01AC22) = 19 
        AND D1.PT_DT = '${process_date}' 
AND DEL_F = '0'  
) AS P1 -- 销户登记簿

LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01 AS P2 -- 借记卡主档
       ON P1.BQ01AC22 = P2.CDNOAC19 
LEFT JOIN (
 SELECT 
        D3.AA04FLNM
        ,D3.AA13ZHTP
        ,D3.AA01AC15
 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAA_TF D3 --活期存款帐户主档
 WHERE 
    D3.PT_DT = '${process_date}'   
AND DEL_F = '0'   
) AS P3 -- 活期存款帐户主档
       ON P1.BQ05AC15 = P3.AA01AC15  
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BDFMHQAA' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='AA13ZHTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P3.AA13ZHTP=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='BDFMHQBQ' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='BQ10CLSN' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='CARD_CHG_RSN_CD' --目标字段 
) AS S2 -- 代码转换
       ON P1.BQ10CLSN=S2.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第4组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AP02AC22 AS CARD_NO -- 卡片编号
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN P1.AP19STAM ELSE P1.AP25STAM END AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,P1.AP01LRSN AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN '3' ELSE '4' END AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,P1.ap03ccyc AS CURR_CD -- 币种代码
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN '挂失' ELSE '解挂' END AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN P1.AP20BRNO ELSE P1.AP26BRNO END AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN P1.AP21STAF ELSE P1.AP27STAF END AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,P1.AP40STAF AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,P2.HSJGBRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.OWONBRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.DFANAC19 AS ACCT_NO -- 账户编号
    ,P3.AA04FLNM AS ACCT_NAME -- 账户名称
    ,CASE WHEN P3.AA13ZHTP IS NULL OR TRIM(P3.AA13ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P3.AA13ZHTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P2.CINOCSNO AS CUST_IN_CD -- 客户内码
    ,P2.CUST_NM AS CUST_NAME -- 客户名称
    ,P2.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P2.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P2.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P2.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,P1.AP15FLNM AS AGENT_NAME -- 代理人名称
    ,P1.AP13CFTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P1.AP14CFNO AS AGENT_DOC_NO -- 代理人证件号码
    ,CONCAT(P2.PTCDPDTP,P2.PDCDPRON) AS CARD_PROD_CD -- 卡产品代码
    ,'' AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,'' AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,P1.AP02AC22 AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,'' AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,'' AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,'' AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,'' AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,'' AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CASE WHEN P1.AP31YYDM IS NULL OR TRIM(P1.AP31YYDM)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AP31YYDM)),'') END
 AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,P1.AP23RMRK AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CASE WHEN P1.AP07FLAG IS NULL OR TRIM(P1.AP07FLAG)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AP07FLAG)),'') END AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,P1.AP10AMT AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN CONCAT(SUBSTR(P1.AP36DATE,1,4),'-',SUBSTR(P1.AP36DATE,5,2),'-',SUBSTR(P1.AP36DATE,7,2)) ELSE '' END AS REPLOS_MATU_DT -- 挂失到期日期
    ,CASE WHEN P1.AP09LSTP IN ('1','2') THEN CONCAT(SUBSTR(P1.AP37DATE,1,4),'-',SUBSTR(P1.AP37DATE,5,2),'-',SUBSTR(P1.AP37DATE,7,2)) ELSE '' END AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,P1.AP32RMRK AS REM -- 备注
    ,P1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,unifiedTime(P1.BUOPDATE) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.BUDISTAM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.BUTSSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.UPOPDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPDTSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.UPTSSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAP_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
        D1.AP02AC22
        ,D1.AP09LSTP
        ,D1.AP19STAM
        ,D1.AP01LRSN
        ,D1.AP20BRNO
        ,D1.AP26BRNO
        ,D1.AP21STAF
        ,D1.AP27STAF
        ,D1.AP40STAF
        ,D1.AP15FLNM
        ,D1.AP13CFTP
        ,D1.AP14CFNO
        ,D1.AP31YYDM
        ,D1.AP23RMRK
        ,D1.AP07FLAG
        ,D1.AP10AMT
        ,D1.AP36DATE
        ,D1.AP32RMRK
        ,D1.RCSTRS1B
        ,D1.BUOPDATE
        ,D1.BUDISTAM
        ,D1.BUTSSTAF
        ,D1.UPOPDATE
        ,D1.UPDTSTAM
        ,D1.UPTSSTAF
        ,d1.ap25stam
        ,d1.ap37date
        ,D1.ap03ccyc

 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAP_TF D1 --事故登记簿_挂失登记簿
 WHERE 
  D1.AP06SSMK='5' 
AND DEL_F = '0'    
and length(D1.AP02AC22)=19 
  AND D1.PT_DT = '${process_date}'         

) AS P1 -- 事故登记簿_挂失登记簿

LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01 AS P2 -- 借记卡主档
       ON P1.AP02AC22 = P2.CDNOAC19 
LEFT JOIN (
 SELECT 
        D3.AA04FLNM
        ,D3.AA13ZHTP
        ,D3.AA01AC15
 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAA_TF D3 --活期存款帐户主档
 WHERE 
    D3.PT_DT = '${process_date}' 
AND DEL_F = '0'      
) AS P3 -- 活期存款帐户主档
       ON P2.DFANAC19 = P3.AA01AC15 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BDFMHQAA' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='AA13ZHTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P3.AA13ZHTP=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='BDFMHQAP' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='AP31YYDM' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='CARD_CHG_RSN_CD' --目标字段 
) AS S2 -- 代码转换
       ON P1.AP31YYDM=S2.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P3.TARGET_CD_VAL
     ,P3.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P3
     WHERE P3.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P3.SRC_TAB_EN_NAME='BDFMHQAP' --来源表英文名  
     AND P3.SRC_FIELD_EN_NAME='AP07FLAG' --来源字段英文名 
     AND P3.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P3.TARGET_FIELD_EN_NAME='CARD_CHG_EVENT_CATE_CD' --目标字段 
) AS S3 -- 代码转换
       ON P1.AP07FLAG=S3.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第5组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CNO1AC19 AS CARD_NO -- 卡片编号
    ,P1.UPTSSTAM AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,P1.UPTSSTAM AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'5' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,p2.pccyccyc AS CURR_CD -- 币种代码
    ,'异卡号换卡' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,'' AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.UPOPSTAF AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,'' AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,P2.HSJGBRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.OWONBRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.DFANAC19 AS ACCT_NO -- 账户编号
    ,P3.AA04FLNM AS ACCT_NAME -- 账户名称
    ,CASE WHEN P3.AA13ZHTP IS NULL OR TRIM(P3.AA13ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P3.AA13ZHTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P2.CINOCSNO AS CUST_IN_CD -- 客户内码
    ,P2.CUST_NM AS CUST_NAME -- 客户名称
    ,P2.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P2.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P2.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P2.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,'' AS AGENT_NAME -- 代理人名称
    ,'' AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,'' AS AGENT_DOC_NO -- 代理人证件号码
    ,CONCAT(P2.PTCDPDTP,P2.PDCDPRON) AS CARD_PROD_CD -- 卡产品代码
    ,P2.MECDMECD AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,P2.CRDNCRDN AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,P2.CRDMCRDM AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,P2.CFLGCFLG AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,P1.CNO2AC19 AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,P21.MECDMECD AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,P21.CRDNCRDN AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,P21.CRDMCRDM AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,P21.CFLGCFLG AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,'' AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,'' AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,'' AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CASE WHEN P1.CGCDCGCD IS NULL OR TRIM(P1.CGCDCGCD)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CGCDCGCD)),'') END AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,'' AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,P1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,unifiedTime(P1.BUDIDATE) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.BUTSSTAM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.BUOPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.UPDTDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPTSSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.UPOPSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BWFMCCON_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
    D1.CNO1AC19
    ,D1.UPTSSTAM
    ,D1.UPOPSTAF
    ,D1.CNO2AC19
    ,D1.CGCDCGCD
    ,D1.RCSTRS1B
    ,D1.BUDIDATE
    ,D1.BUTSSTAM
    ,D1.BUOPSTAF
    ,D1.UPDTDATE


 FROM 
 ODS_CORE.ODS_CORE_BWFMCCON_TF D1 --借记卡与卡关系表
 WHERE 
   D1.PT_DT = '${process_date}'    
AND DEL_F = '0'       

) AS P1 -- 借记卡与卡关系表

LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01 AS P2 -- 借记卡主档
       ON P1.CNO1AC19 = P2.CDNOAC19 
LEFT JOIN (
 SELECT 
         D1.OPONBRNO
        ,D1.MECDMECD
        ,D1.CRDNCRDN
        ,D1.CRDMCRDM
        ,D1.CFLGCFLG
        ,D1.CDNOAC19
        ,D1.CINOCSNO
        ,D1.CHNMNM40
        ,D1.HSJGBRNO
        ,D1.OWONBRNO
        ,D1.DFANAC19
        ,D1.PTCDPDTP
        ,D1.PDCDPRON

 FROM 
 ODS_CORE.ODS_CORE_BWFMDCIM_TF D1 --借记卡主档
 WHERE 
    D1.PT_DT = '${process_date}'   
AND DEL_F = '0'  
) AS P21 -- 借记卡主档
       ON P1.CNO2AC19 = P21.CDNOAC19 
LEFT JOIN (
 SELECT 
        D3.AA04FLNM
        ,D3.AA13ZHTP
        ,D3.AA01AC15
 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAA_TF D3 --活期存款帐户主档
 WHERE 
    D3.PT_DT = '${process_date}'     
AND DEL_F = '0'  
) AS P3 -- 活期存款帐户主档
       ON P2.DFANAC19 = P3.AA01AC15 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BDFMHQAA' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='AA13ZHTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P3.AA13ZHTP=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='BWFMCCON' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='CGCDCGCD' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='CARD_CHG_EVENT_CATE_CD' --目标字段 
) AS S2 -- 代码转换
       ON P1.CGCDCGCD=S2.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第6组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CDNOAC19 AS CARD_NO -- 卡片编号
    ,CONCAT(SUBSTR(P1.CDSQDATE,1,4),'-',SUBSTR(P1.CDSQDATE,5,2),'-',SUBSTR(P1.CDSQDATE,7,2),' 00:00:00') AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,P1.SQNCDATE AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'6' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,p2.pccyccyc AS CURR_CD -- 币种代码
    ,'同卡号换卡' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,P1.SQQRBRNO AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.QRJGSTLR AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,P1.SQJGSTLR AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,P2.HSJGBRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.OWONBRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.DFANAC19 AS ACCT_NO -- 账户编号
    ,P3.AA04FLNM AS ACCT_NAME -- 账户名称
    ,CASE WHEN P3.AA13ZHTP IS NULL OR TRIM(P3.AA13ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P3.AA13ZHTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P2.CINOCSNO AS CUST_IN_CD -- 客户内码
    ,P2.CUST_NM AS CUST_NAME -- 客户名称
    ,P2.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P2.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P2.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P2.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,'' AS AGENT_NAME -- 代理人名称
    ,'' AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,'' AS AGENT_DOC_NO -- 代理人证件号码
    ,CONCAT(P2.PTCDPDTP,P2.PDCDPRON) AS CARD_PROD_CD -- 卡产品代码
    ,P1.LMBHLMBH AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,substr(P1.BZKRMRK1,4,1) AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,substr(P1.BZKRMRK1,2,1) AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,P1.CFLGCFLG AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,P1.CDNOAC19 AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,substr(P1.BZKRMRK1,6,4) AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,substr(P1.BZKRMRK1,3,1) AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,substr(P1.BZKRMRK1,1,1) AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,substr(P1.BZKRMRK1,5,1) AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,'' AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,'' AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,'' AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CASE WHEN P1.CGCDCGCD IS NULL OR TRIM(P1.CGCDCGCD)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CGCDCGCD)),'') END AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,'' AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,P1.CARDCRDS AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,P1.SQSQBRNO AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,P1.SQZSDATE AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,'' AS REC_STATUS_CD -- 记录状态代码
    ,unifiedTime(P1.BUDIDATE) AS SETUP_DT -- 建立日期
    ,P1.BUTSSTAM AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.BUOPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.UPDTDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.UPTSSTAM AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.UPOPSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BWFMTKSQ_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
    D1.CDNOAC19
    ,D1.CDSQDATE
    ,D1.SQQRBRNO
    ,D1.QRJGSTLR
    ,D1.SQJGSTLR
    ,D1.LMBHLMBH
    ,D1.BZKRMRK1
    ,D1.CFLGCFLG
    ,D1.CGCDCGCD
    ,D1.CARDCRDS
    ,D1.SQSQBRNO
    ,D1.SQZSDATE
    ,D1.BUDIDATE
    ,D1.BUTSSTAM
    ,D1.BUOPSTAF
    ,D1.UPDTDATE
    ,D1.UPTSSTAM
    ,D1.UPOPSTAF
    ,D1.SQNCDATE

 FROM 
 ODS_CORE.ODS_CORE_BWFMTKSQ_TF D1 --同卡号换卡申请登记簿

 WHERE 
    D1.PT_DT = '${process_date}' 
AND DEL_F = '0'      
) AS P1 -- 同卡号换卡申请登记簿

LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01 AS P2 -- 借记卡主档
       ON P1.CDNOAC19 = P2.CDNOAC19  
LEFT JOIN (
 SELECT 
        D3.AA04FLNM
        ,D3.AA13ZHTP
        ,D3.AA01AC15
 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAA_TF D3 --活期存款帐户主档
 WHERE 
    D3.PT_DT = '${process_date}'   
AND DEL_F = '0'    
) AS P3 -- 活期存款帐户主档
       ON P2.DFANAC19 = P3.AA01AC15 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BDFMHQAA' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='AA13ZHTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P3.AA13ZHTP=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='BWFMTKSQ' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='CGCDCGCD' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='CARD_CHG_EVENT_CATE_CD' --目标字段 
) AS S2 -- 代码转换
       ON P1.CGCDCGCD=S2.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第7组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AV04AC22 AS CARD_NO -- 卡片编号
    ,CONCAT(SUBSTR(P1.AV01DATE,1,4),'-',SUBSTR(P1.AV01DATE,5,2),'-',SUBSTR(P1.AV01DATE,7,2),' 00:00:00') AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,P1.AV02TXSN||P1.AV19TSSN AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'7' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,P1.av06ccyc AS CURR_CD -- 币种代码
    ,'信息更改' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,P1.AV21BRNO AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.AV15STAF AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,P1.AV30STAF AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,P2.HSJGBRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.OWONBRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.DFANAC19 AS ACCT_NO -- 账户编号
    ,P1.AV08FLNM AS ACCT_NAME -- 账户名称
    ,CASE WHEN P3.AA13ZHTP IS NULL OR TRIM(P3.AA13ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P3.AA13ZHTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P2.CINOCSNO AS CUST_IN_CD -- 客户内码
    ,P2.CUST_NM AS CUST_NAME -- 客户名称
    ,P2.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P2.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P2.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P2.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,P1.AV16FLNM AS AGENT_NAME -- 代理人名称
    ,P1.AV17CFTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P1.AV18CFNO AS AGENT_DOC_NO -- 代理人证件号码
    ,CONCAT(P2.PTCDPDTP,P2.PDCDPRON) AS CARD_PROD_CD -- 卡产品代码
    ,'' AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,'' AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,'' AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,'' AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,'' AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,'' AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,'' AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,'' AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,'' AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,'' AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CASE WHEN P1.AV03GGLX IS NULL OR TRIM(P1.AV03GGLX)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AV03GGLX)),'') END
 AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,'' AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,P1.AV02TXSN AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,P1.AV19TSSN AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,unifiedTime(P1.AV20DATE) AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,P1.AV13F300 AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,P1.AV12F300 AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,P1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'' AS FINAL_MODIF_DT -- 最后修改日期
    ,'' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAV_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
     D1.AV04AC22
    ,D1.AV01DATE
    ,D1.AV21BRNO
    ,D1.AV15STAF
    ,D1.AV30STAF
    ,D1.AV08FLNM
    ,D1.AV16FLNM
    ,D1.AV17CFTP
    ,D1.AV18CFNO
    ,D1.AV03GGLX
    ,cast(D1.AV02TXSN as  string) as AV02TXSN 
    ,cast(D1.AV19TSSN as  string) as AV19TSSN
    ,D1.AV20DATE
    ,D1.AV13F300
    ,D1.AV12F300
    ,D1.RCSTRS1B
    ,d1.av06ccyc

 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAV_TF D1 --账户信息更改登记簿
 WHERE 
    D1.AV09SSMK = '2' 
    AND length(D1.AV04AC22) = 19 
    AND D1.PT_DT = '${process_date}'    
AND DEL_F = '0'       

) AS P1 -- 账户信息更改登记簿

LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01 AS P2 -- 借记卡主档
       ON P1.AV04AC22 = P2.CDNOAC19  
LEFT JOIN (
 SELECT 
        D3.AA04FLNM
        ,D3.AA13ZHTP
        ,D3.AA01AC15
 FROM 
 ODS_CORE.ODS_CORE_BDFMHQAA_TF D3 --活期存款帐户主档
 WHERE 
    D3.PT_DT = '${process_date}'     
AND DEL_F = '0'  
) AS P3 -- 活期存款帐户主档
       ON P2.DFANAC19 = P3.AA01AC15 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BDFMHQAA' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='AA13ZHTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P3.AA13ZHTP=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='BDFMHQAV' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='AV03GGLX' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='CARD_CHG_EVENT_CATE_CD' --目标字段 
) AS S2 -- 代码转换
       ON P1.AV03GGLX=S2.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第8组）==============
-- 个人借记卡变更明细聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_02;

CREATE TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_02 (
     CARDNO STRING COMMENT '卡片编号'
    ,CUSTAC STRING COMMENT '账户编号'
    ,PRODCD STRING COMMENT '卡产品代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡变更明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_02(
     CARDNO -- 卡片编号
    ,CUSTAC -- 账户编号
    ,PRODCD -- 卡产品代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CARDNO AS CARDNO -- 卡片编号
    ,P1.CUSTAC AS CUSTAC -- 账户编号
    ,P2.prodcd AS PRODCD -- 卡产品代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 

     D1.CUSTAC
  ,D1.CARDNO

 FROM 
 ODS_NAS.ODS_NAS_KNA_ACDC_TF D1 --电子账户开户登记簿
 WHERE 
    D1.PT_DT = '${process_date}'     
AND DEL_F = '0'      

) AS P1 -- 卡客户账号对照表

LEFT JOIN (
 SELECT 

     D2.CARDNO
  ,D2.PRODCD
 FROM 
 ODS_NAS.ODS_NAS_KCD_CARD_TF D2 --电子借记卡信息
 WHERE 
    D2.PT_DT = '${process_date}' 
AND DEL_F = '0'          

) AS P2 -- 电子借记卡信息
       ON P1.CARDNO=P2.CARDNO  
;
-- ==============聚合层字段映射（第9组）==============
-- 个人借记卡变更明细聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_03;

CREATE TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_03 (
     CUSTAC STRING COMMENT '电子账户'
    ,CST_IN_CD STRING COMMENT '客户内码'
    ,CRTF_TYP STRING COMMENT '证件类型'
    ,CRTF_NO STRING COMMENT '证件号码'
    ,CONT_NBR STRING COMMENT '联系号码'
    ,ADDR STRING COMMENT '详细地址'
    ,USER_NM STRING COMMENT '账户名称'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡变更明细聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_03(
     CUSTAC -- 电子账户
    ,CST_IN_CD -- 客户内码
    ,CRTF_TYP -- 证件类型
    ,CRTF_NO -- 证件号码
    ,CONT_NBR -- 联系号码
    ,ADDR -- 详细地址
    ,USER_NM -- 账户名称
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CUSTAC AS CUSTAC -- 电子账户
    ,p1.CST_IN_CD AS CST_IN_CD -- 客户内码
    ,P3.CRTF_TYP AS CRTF_TYP -- 证件类型
    ,P3.CRTF_NO AS CRTF_NO -- 证件号码
    ,P4.CONT_NBR AS CONT_NBR -- 联系号码
    ,P5.ADDR AS ADDR -- 详细地址
    ,P1.USER_NM AS USER_NM -- 账户名称
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
select a.CUSTAC,c.CST_IN_CD,c.user_nm,c.user_corp_org_no from 
(
 SELECT 

     D2.CUSTAC
    ,D2.CUSTNO
    ,D2.CUSTNA

 FROM  ODS_NAS.ODS_NAS_KNA_CUST_TF D2 --电子账户
 WHERE 
    D2.PT_DT = '${process_date}'  
 AND DEL_F = '0'    

)
a left join 
(
  select
   D1.custno,
   D1.custcd ,
   d1.custid,
   row_number() over(partition by D1.custno,
   D1.custcd
  order by
   D1.custid desc)RN
  from
   ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF D1
  where
   D1.PT_DT = '${process_date}'
   AND D1.STATUS = '1'
  AND DEL_F = '0'  
)
b 
on a.CUSTNO = b.CUSTNO 
left  join 
(
 select d2.CST_IN_CD,d2.user_id,d2.user_nm ,d2.user_corp_org_no,row_number ()over(partition by d2.user_id order by d2.id desc )  rn from ods_eicc.ods_eicc_U_USER_INNER_BAS_tf  d2 
  where
   D2.PT_DT = '${process_date}'
  AND d2.DEL_F = '0'  
  and coalesce(trim(cst_in_cd),'') <> ''
) c
on b.custid = c.user_id 
and c.rn =1 
) AS P1 -- 电子账户表  

LEFT JOIN (
 SELECT  D2.CST_IN_CD
        ,D2.CRTF_TYP
        ,D2.CRTF_NO
 FROM (
       SELECT T1.CST_IN_CD
             ,T1.CRTF_TYP
             ,T1.CRTF_NO
             ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
       FROM  ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF T1  --证件信息表
       WHERE  T1.MAJOR_FLG='1'
       AND    T1.PT_DT = '${process_date}'
AND DEL_F = '0'  
      ) D2
 WHERE  D2.RN= 1
)
 AS P3 -- 证件信息
       ON P1.CST_IN_CD = P3.CST_IN_CD  
LEFT JOIN (
SELECT  D3.CST_IN_CD
       ,D3.CONT_NBR
  ,d3.CORP_ORG_NO
FROM (
      SELECT T1.CST_IN_CD
            ,T1.CONT_NBR
      ,substr(t1.CORP_ORG_NO,1,3) as CORP_ORG_NO
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD,substr(t1.CORP_ORG_NO,1,3)ORDER BY T1.GMT_MODIFIED DESC ) RN 
   FROM   ODS_EICC.ODS_EICC_C_CUS_PRIV_CONT_TF T1  --客户联系方式信息表
   WHERE  T1.PT_DT = '${process_date}'
AND DEL_F = '0'  
  ) D3
WHERE D3.RN = 1
) AS P4 -- 联系信息
       ON P1.CST_IN_CD  = P4.CST_IN_CD 
and substr(p1.user_corp_org_no,1,3) = p4.CORP_ORG_NO 
LEFT JOIN (
 SELECT D4.CST_IN_CD
       ,D4.ADDR
,d4.corp_org_no
 FROM(
      SELECT T1.CST_IN_CD
            ,T1.ADDR
,substr(t1.CORP_ORG_NO,1,3) as corp_org_no
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD,substr(t1.CORP_ORG_NO,1,3) ORDER BY T1.GMT_MODIFIED DESC ) RN 
   FROM   ODS_EICC.ODS_EICC_C_CUS_PRIV_ADDR_TF T1  --客户地址信息表
   WHERE  T1.PT_DT = '${process_date}'
AND DEL_F = '0'  
  ) D4
 WHERE D4.RN = 1 
) AS P5 -- 地址信息
       ON P1.CST_IN_CD  = P5.CST_IN_CD 
and substr(p1.user_corp_org_no,1,3) = p5.CORP_ORG_NO 
;
-- ==============聚合层字段映射（第10组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P2.CARDNO AS CARD_NO -- 卡片编号
    ,CONCAT(SUBSTR(P1.OPENDT,1,4),'-',SUBSTR(P1.OPENDT,5,2),'-',SUBSTR(P1.OPENDT,7,2),' 00:00:00') AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CONCAT(P1.OPENSQ,' 00:00:00') AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'1' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,P1.crcycd AS CURR_CD -- 币种代码
    ,'开卡' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,'' AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.OPENUS AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,'' AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,'' AS LP_ORG_NO -- 法人机构编号
    ,'' AS STAT_ORG_NO -- 统计机构编号
    ,P1.CORPNO||'000' AS BELONG_ORG_NO -- 归属机构编号
    ,P1.CUSTAC AS ACCT_NO -- 账户编号
    ,P1.CUSTNA AS ACCT_NAME -- 账户名称
    ,CASE WHEN P1.ACCTTP IS NULL OR TRIM(P1.ACCTTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACCTTP)),'') END
 AS ACCT_PROPTY_CD -- 账户性质代码
    ,P3.CST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P3.USER_NM AS CUST_NAME -- 客户名称
    ,P3.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P3.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P3.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P3.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,'' AS AGENT_NAME -- 代理人名称
    ,'' AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,'' AS AGENT_DOC_NO -- 代理人证件号码
    ,P2.prodcd AS CARD_PROD_CD -- 卡产品代码
    ,'' AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,'' AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,'' AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,'' AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,'' AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,'' AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,'' AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,P1.OPENSV AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,'' AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,'' AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,'' AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,'' AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,'' AS REC_STATUS_CD -- 记录状态代码
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,CASE WHEN COALESCE(P1.MTDATE,'') = '' THEN P1.MTDATE ELSE unifiedTime(P1.MTDATE) END  AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNB_OPAC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,7 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
    D1.OPENDT
    ,D1.OPENSQ
    ,D1.OPENUS
    ,D1.CORPNO
    ,D1.CUSTAC
    ,D1.CUSTNA
    ,D1.ACCTTP
    ,D1.OPENSV
    ,D1.MTDATE
    ,D1.TIMETM
    ,d1.crcycd

 FROM 
 ODS_NAS.ODS_NAS_KNB_OPAC_TF D1 --电子账户开户登记簿
 WHERE 
    D1.PT_DT = '${process_date}'    
AND DEL_F = '0'       

) AS P1 -- 电子账户开户登记簿

INNER JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_02 AS P2 -- 卡客户账号对照表
       ON P1.CUSTAC = P2.CUSTAC 
LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_03 AS P3 -- 电子账户表  
       ON P1.CUSTAC = P3.CUSTAC  
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='NAS'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='KNB_OPAC' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='ACCTTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
)
 AS S1 -- 代码转换
       ON P1.ACCTTP=S1.SRC_CD_VAL 
;
-- ==============聚合层字段映射（第11组）==============
-- 个人借记卡变更明细聚合

INSERT INTO TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM(
     CARD_NO -- 卡片编号
    ,CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CURR_CD -- 币种代码
    ,CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_CONT_NO_NO -- 客户联系电话号码
    ,CUST_CONT_ADDR -- 客户联系地址
    ,AGENT_NAME -- 代理人名称
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,CARD_PROD_CD -- 卡产品代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,DRAW_INT_ACCT_NO -- 收息账户编号
    ,MAX_LMT -- 最高限额
    ,ACCT_EXPIR_DT -- 账户失效日期
    ,CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CANC_ACCT_INT_TAX -- 销户利息税
    ,REPLOS_MATU_DT -- 挂失到期日期
    ,MIN_CANCLR_DT -- 最小解挂日期
    ,SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,REM -- 备注
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P2.CARDNO AS CARD_NO -- 卡片编号
    ,CONCAT(SUBSTR(P1.CLOSDT,1,4),'-',SUBSTR(P1.CLOSDT,5,2),'-',SUBSTR(P1.CLOSDT,7,2),' 00:00:00') AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,P1.CLOSSQ AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,'2' AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,P1.crcycd AS CURR_CD -- 币种代码
    ,'销卡' AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,P1.CLOSBR AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,P1.CLOSUS AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,'' AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,'' AS LP_ORG_NO -- 法人机构编号
    ,'' AS STAT_ORG_NO -- 统计机构编号
    ,P1.CORPNO||'000' AS BELONG_ORG_NO -- 归属机构编号
    ,P1.CUSTAC AS ACCT_NO -- 账户编号
    ,P1.CUSTNA AS ACCT_NAME -- 账户名称
    ,CASE WHEN P1.ACCTTP IS NULL OR TRIM(P1.ACCTTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACCTTP)),'') END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P3.CST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P3.USER_NM AS CUST_NAME -- 客户名称
    ,P3.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P3.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P3.CONT_NBR AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,P3.ADDR AS CUST_CONT_ADDR -- 客户联系地址
    ,P1.AGNTNA AS AGENT_NAME -- 代理人名称
    ,P1.AGIDTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P1.AGIDNO AS AGENT_DOC_NO -- 代理人证件号码
    ,P2.prodcd AS CARD_PROD_CD -- 卡产品代码
    ,'' AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,'' AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,'' AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,'' AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,'' AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,'' AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,'' AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,P1.CLOSSV AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,'' AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,P1.CLOSRS AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CASE WHEN P1.CLOSWY IS NULL OR TRIM(P1.CLOSWY)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CLOSWY)),'') END AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,P1.CLOSAM AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,'' AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,'' AS MAX_LMT -- 最高限额
    ,'' AS ACCT_EXPIR_DT -- 账户失效日期
    ,'' AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,'' AS CANC_ACCT_INT_TAX -- 销户利息税
    ,'' AS REPLOS_MATU_DT -- 挂失到期日期
    ,'' AS MIN_CANCLR_DT -- 最小解挂日期
    ,'' AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,'' AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,'' AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,'' AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,'' AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,'' AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,'' AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,'' AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,'' AS REM -- 备注
    ,'' AS REC_STATUS_CD -- 记录状态代码
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,substr(unifiedTime(P1.TIMETM),1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNB_CLAC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,8 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
    D1.CLOSDT
    ,D1.CLOSSQ
    ,D1.CLOSBR
    ,D1.CLOSUS
    ,D1.CORPNO
    ,D1.CUSTAC
    ,D1.CUSTNA
    ,D1.ACCTTP
    ,D1.AGNTNA
    ,D1.AGIDTP
    ,D1.AGIDNO
    ,D1.CLOSSV
    ,D1.CLOSRS
    ,D1.CLOSWY
    ,D1.CLOSAM
    ,D1.TIMETM
    ,D1.crcycd

 FROM 
 ODS_NAS.ODS_NAS_KNB_CLAC_TF D1 --电子账户销户登记簿
 WHERE 
    D1.PT_DT = '${process_date}'     
AND DEL_F = '0'      

) AS P1 -- 电子账户销户登记簿

INNER JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_02 AS P2 -- 卡客户账号对照表
       ON P1.CUSTAC = P2.CUSTAC 
LEFT JOIN AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_03 AS P3 -- 电子账户表  
       ON P1.CUSTAC = P3.CUSTAC  
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='NAS'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='KNB_CLAC' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='ACCTTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
) AS S1 -- 代码转换
       ON P1.ACCTTP=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='NAS'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='KNB_CLAC' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='CLOSWY' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_DEBIT_CARD_CHANGE_DTL_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='CARD_CHG_EVENT_CATE_CD' --目标字段 
) AS S2 -- 代码转换
       ON P1.CLOSWY=S2.SRC_CD_VAL  
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_NO, BF.CARD_NO) END AS CARD_NO -- 卡片编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_TM_STAMP, BF.CARD_CHG_TM_STAMP) END AS CARD_CHG_TM_STAMP -- 卡变更时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_EVENT_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_EVENT_NO, BF.CARD_CHG_EVENT_NO) END AS CARD_CHG_EVENT_NO -- 卡变更事件编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_TYPE_CD, BF.CARD_CHG_TYPE_CD) END AS CARD_CHG_TYPE_CD -- 卡变更类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_TYPE_NAME IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_TYPE_NAME, BF.CARD_CHG_TYPE_NAME) END AS CARD_CHG_TYPE_NAME -- 卡变更类型名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_PROC_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_PROC_ORG_NO, BF.CARD_CHG_PROC_ORG_NO) END AS CARD_CHG_PROC_ORG_NO -- 卡变更办理机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_PROC_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_PROC_TELR_NO, BF.CARD_CHG_PROC_TELR_NO) END AS CARD_CHG_PROC_TELR_NO -- 卡变更办理柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_AUTH_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_AUTH_TELR_NO, BF.CARD_CHG_AUTH_TELR_NO) END AS CARD_CHG_AUTH_TELR_NO -- 卡变更授权柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STAT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.STAT_ORG_NO, BF.STAT_ORG_NO) END AS STAT_ORG_NO -- 统计机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_PROPTY_CD, BF.ACCT_PROPTY_CD) END AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_DOCTYP_CD, BF.CUST_DOCTYP_CD) END AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_DOC_NO, BF.CUST_DOC_NO) END AS CUST_DOC_NO -- 客户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_CONT_NO_NO, BF.CUST_CONT_NO_NO) END AS CUST_CONT_NO_NO -- 客户联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_CONT_ADDR IS NULL THEN NULL ELSE COALESCE(TM.CUST_CONT_ADDR, BF.CUST_CONT_ADDR) END AS CUST_CONT_ADDR -- 客户联系地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_NAME IS NULL THEN NULL ELSE COALESCE(TM.AGENT_NAME, BF.AGENT_NAME) END AS AGENT_NAME -- 代理人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.AGENT_DOCTYP_CD, BF.AGENT_DOCTYP_CD) END AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGENT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.AGENT_DOC_NO, BF.AGENT_DOC_NO) END AS AGENT_DOC_NO -- 代理人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_PROD_CD, BF.CARD_PROD_CD) END AS CARD_PROD_CD -- 卡产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CO_SIGN_IDTFY_CERT_CORP_NO IS NULL THEN NULL ELSE COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO, BF.CO_SIGN_IDTFY_CERT_CORP_NO) END AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_PROPTY_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_PROPTY_TYPE_CD, BF.CARD_PROPTY_TYPE_CD) END AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_MED_TYPE_CD, BF.CARD_MED_TYPE_CD) END AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_AGT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_AGT_TYPE_CD, BF.CARD_AGT_TYPE_CD) END AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_CARD_CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.ORIG_CARD_CARD_NO, BF.ORIG_CARD_CARD_NO) END AS ORIG_CARD_CARD_NO -- 原卡卡片编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_CARD_CSICC_NO IS NULL THEN NULL ELSE COALESCE(TM.ORIG_CARD_CSICC_NO, BF.ORIG_CARD_CSICC_NO) END AS ORIG_CARD_CSICC_NO -- 原卡联名认同单位编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_CARD_PROPTY_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ORIG_CARD_PROPTY_TYPE_CD, BF.ORIG_CARD_PROPTY_TYPE_CD) END AS ORIG_CARD_PROPTY_TYPE_CD -- 原卡性质类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_CARD_MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ORIG_CARD_MED_TYPE_CD, BF.ORIG_CARD_MED_TYPE_CD) END AS ORIG_CARD_MED_TYPE_CD -- 原卡介质类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_CARD_AGT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ORIG_CARD_AGT_TYPE_CD, BF.ORIG_CARD_AGT_TYPE_CD) END AS ORIG_CARD_AGT_TYPE_CD -- 原卡协议类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_TXN_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_TXN_CHNL_CD, BF.CARD_CHG_TXN_CHNL_CD) END AS CARD_CHG_TXN_CHNL_CD -- 卡变更交易渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_RSN_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_RSN_CD, BF.CARD_CHG_RSN_CD) END AS CARD_CHG_RSN_CD -- 卡变更原因代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_RSN_DESC IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_RSN_DESC, BF.CARD_CHG_RSN_DESC) END AS CARD_CHG_RSN_DESC -- 卡变更原因描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_EVENT_CATE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_EVENT_CATE_CD, BF.CARD_CHG_EVENT_CATE_CD) END AS CARD_CHG_EVENT_CATE_CD -- 卡变更事件种类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_CHG_ACCT_AMT IS NULL THEN NULL ELSE COALESCE(TM.CARD_CHG_ACCT_AMT, BF.CARD_CHG_ACCT_AMT) END AS CARD_CHG_ACCT_AMT -- 卡变更账户金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_INT_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.DRAW_INT_ACCT_NO, BF.DRAW_INT_ACCT_NO) END AS DRAW_INT_ACCT_NO -- 收息账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAX_LMT IS NULL THEN NULL ELSE COALESCE(TM.MAX_LMT, BF.MAX_LMT) END AS MAX_LMT -- 最高限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_EXPIR_DT IS NULL THEN NULL ELSE COALESCE(TM.ACCT_EXPIR_DT, BF.ACCT_EXPIR_DT) END AS ACCT_EXPIR_DT -- 账户失效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_INCLD_TAX_INT IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_INCLD_TAX_INT, BF.CANC_ACCT_INCLD_TAX_INT) END AS CANC_ACCT_INCLD_TAX_INT -- 销户含税利息
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_INT_TAX IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_INT_TAX, BF.CANC_ACCT_INT_TAX) END AS CANC_ACCT_INT_TAX -- 销户利息税
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REPLOS_MATU_DT IS NULL THEN NULL ELSE COALESCE(TM.REPLOS_MATU_DT, BF.REPLOS_MATU_DT) END AS REPLOS_MATU_DT -- 挂失到期日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MIN_CANCLR_DT IS NULL THEN NULL ELSE COALESCE(TM.MIN_CANCLR_DT, BF.MIN_CANCLR_DT) END AS MIN_CANCLR_DT -- 最小解挂日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SCNCC_STAT_CD IS NULL THEN NULL ELSE COALESCE(TM.SCNCC_STAT_CD, BF.SCNCC_STAT_CD) END AS SCNCC_STAT_CD -- 同卡号换卡状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SCNCC_APP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SCNCC_APP_ORG_NO, BF.SCNCC_APP_ORG_NO) END AS SCNCC_APP_ORG_NO -- 同卡号换卡申请机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SCNCC_CERT_VALID IS NULL THEN NULL ELSE COALESCE(TM.SCNCC_CERT_VALID, BF.SCNCC_CERT_VALID) END AS SCNCC_CERT_VALID -- 同卡号换卡证书有效期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INFO_CHG_ORIG_TXN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.INFO_CHG_ORIG_TXN_SER_NO, BF.INFO_CHG_ORIG_TXN_SER_NO) END AS INFO_CHG_ORIG_TXN_SER_NO -- 信息变更原交易流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INFO_CHG_SUB_TXN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.INFO_CHG_SUB_TXN_SER_NO, BF.INFO_CHG_SUB_TXN_SER_NO) END AS INFO_CHG_SUB_TXN_SER_NO -- 信息变更子交易流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INFO_CHG_ENABLED_DT IS NULL THEN NULL ELSE COALESCE(TM.INFO_CHG_ENABLED_DT, BF.INFO_CHG_ENABLED_DT) END AS INFO_CHG_ENABLED_DT -- 信息变更启用日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INFO_CHG_NEW_CONTENT_ILUS IS NULL THEN NULL ELSE COALESCE(TM.INFO_CHG_NEW_CONTENT_ILUS, BF.INFO_CHG_NEW_CONTENT_ILUS) END AS INFO_CHG_NEW_CONTENT_ILUS -- 信息变更新内容说明
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INFO_CHG_ORIG_CONTENT_ILUS IS NULL THEN NULL ELSE COALESCE(TM.INFO_CHG_ORIG_CONTENT_ILUS, BF.INFO_CHG_ORIG_CONTENT_ILUS) END AS INFO_CHG_ORIG_CONTENT_ILUS -- 信息变更原内容说明
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REM IS NULL THEN NULL ELSE COALESCE(TM.REM, BF.REM) END AS REM -- 备注
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REC_STATUS_CD, BF.REC_STATUS_CD) END AS REC_STATUS_CD -- 记录状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_DT IS NULL THEN NULL ELSE COALESCE(TM.SETUP_DT, BF.SETUP_DT) END AS SETUP_DT -- 建立日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TM_STAMP, BF.SETUP_TM_STAMP) END AS SETUP_TM_STAMP -- 建立时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TELR_NO, BF.SETUP_TELR_NO) END AS SETUP_TELR_NO -- 建立柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CARD_CHG_TYPE_NAME,'') = COALESCE(BF.CARD_CHG_TYPE_NAME,'') -- 卡变更类型名称 非主键字段相等
         AND COALESCE(TM.CARD_CHG_PROC_ORG_NO,'') = COALESCE(BF.CARD_CHG_PROC_ORG_NO,'') -- 卡变更办理机构编号 非主键字段相等
         AND COALESCE(TM.CARD_CHG_PROC_TELR_NO,'') = COALESCE(BF.CARD_CHG_PROC_TELR_NO,'') -- 卡变更办理柜员编号 非主键字段相等
         AND COALESCE(TM.CARD_CHG_AUTH_TELR_NO,'') = COALESCE(BF.CARD_CHG_AUTH_TELR_NO,'') -- 卡变更授权柜员编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.CUST_CONT_NO_NO,'') = COALESCE(BF.CUST_CONT_NO_NO,'') -- 客户联系电话号码 非主键字段相等
         AND COALESCE(TM.CUST_CONT_ADDR,'') = COALESCE(BF.CUST_CONT_ADDR,'') -- 客户联系地址 非主键字段相等
         AND COALESCE(TM.AGENT_NAME,'') = COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段相等
         AND COALESCE(TM.AGENT_DOCTYP_CD,'') = COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.AGENT_DOC_NO,'') = COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段相等
         AND COALESCE(TM.CARD_PROD_CD,'') = COALESCE(BF.CARD_PROD_CD,'') -- 卡产品代码 非主键字段相等
         AND COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') = COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段相等
         AND COALESCE(TM.CARD_PROPTY_TYPE_CD,'') = COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段相等
         AND COALESCE(TM.CARD_MED_TYPE_CD,'') = COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段相等
         AND COALESCE(TM.CARD_AGT_TYPE_CD,'') = COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_CARD_NO,'') = COALESCE(BF.ORIG_CARD_CARD_NO,'') -- 原卡卡片编号 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_CSICC_NO,'') = COALESCE(BF.ORIG_CARD_CSICC_NO,'') -- 原卡联名认同单位编号 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_PROPTY_TYPE_CD,'') = COALESCE(BF.ORIG_CARD_PROPTY_TYPE_CD,'') -- 原卡性质类别代码 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_MED_TYPE_CD,'') = COALESCE(BF.ORIG_CARD_MED_TYPE_CD,'') -- 原卡介质类别代码 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_AGT_TYPE_CD,'') = COALESCE(BF.ORIG_CARD_AGT_TYPE_CD,'') -- 原卡协议类别代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_TXN_CHNL_CD,'') = COALESCE(BF.CARD_CHG_TXN_CHNL_CD,'') -- 卡变更交易渠道代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_RSN_CD,'') = COALESCE(BF.CARD_CHG_RSN_CD,'') -- 卡变更原因代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_RSN_DESC,'') = COALESCE(BF.CARD_CHG_RSN_DESC,'') -- 卡变更原因描述 非主键字段相等
         AND COALESCE(TM.CARD_CHG_EVENT_CATE_CD,'') = COALESCE(BF.CARD_CHG_EVENT_CATE_CD,'') -- 卡变更事件种类代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 卡变更账户金额 非主键字段相等
         AND COALESCE(TM.DRAW_INT_ACCT_NO,'') = COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段相等
         AND COALESCE(TM.MAX_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MAX_LMT,CAST(0 AS DECIMAL(28,2))) -- 最高限额 非主键字段相等
         AND COALESCE(TM.ACCT_EXPIR_DT,'') = COALESCE(BF.ACCT_EXPIR_DT,'') -- 账户失效日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) -- 销户含税利息 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 销户利息税 非主键字段相等
         AND COALESCE(TM.REPLOS_MATU_DT,'') = COALESCE(BF.REPLOS_MATU_DT,'') -- 挂失到期日期 非主键字段相等
         AND COALESCE(TM.MIN_CANCLR_DT,'') = COALESCE(BF.MIN_CANCLR_DT,'') -- 最小解挂日期 非主键字段相等
         AND COALESCE(TM.SCNCC_STAT_CD,'') = COALESCE(BF.SCNCC_STAT_CD,'') -- 同卡号换卡状态代码 非主键字段相等
         AND COALESCE(TM.SCNCC_APP_ORG_NO,'') = COALESCE(BF.SCNCC_APP_ORG_NO,'') -- 同卡号换卡申请机构编号 非主键字段相等
         AND COALESCE(TM.SCNCC_CERT_VALID,'') = COALESCE(BF.SCNCC_CERT_VALID,'') -- 同卡号换卡证书有效期 非主键字段相等
         AND COALESCE(TM.INFO_CHG_ORIG_TXN_SER_NO,'') = COALESCE(BF.INFO_CHG_ORIG_TXN_SER_NO,'') -- 信息变更原交易流水号 非主键字段相等
         AND COALESCE(TM.INFO_CHG_SUB_TXN_SER_NO,'') = COALESCE(BF.INFO_CHG_SUB_TXN_SER_NO,'') -- 信息变更子交易流水号 非主键字段相等
         AND COALESCE(TM.INFO_CHG_ENABLED_DT,'') = COALESCE(BF.INFO_CHG_ENABLED_DT,'') -- 信息变更启用日期 非主键字段相等
         AND COALESCE(TM.INFO_CHG_NEW_CONTENT_ILUS,'') = COALESCE(BF.INFO_CHG_NEW_CONTENT_ILUS,'') -- 信息变更新内容说明 非主键字段相等
         AND COALESCE(TM.INFO_CHG_ORIG_CONTENT_ILUS,'') = COALESCE(BF.INFO_CHG_ORIG_CONTENT_ILUS,'') -- 信息变更原内容说明 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CARD_CHG_TYPE_NAME,'') <> COALESCE(BF.CARD_CHG_TYPE_NAME,'') -- 卡变更类型名称 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_PROC_ORG_NO,'') <> COALESCE(BF.CARD_CHG_PROC_ORG_NO,'') -- 卡变更办理机构编号 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_PROC_TELR_NO,'') <> COALESCE(BF.CARD_CHG_PROC_TELR_NO,'') -- 卡变更办理柜员编号 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_AUTH_TELR_NO,'') <> COALESCE(BF.CARD_CHG_AUTH_TELR_NO,'') -- 卡变更授权柜员编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_DOCTYP_CD,'') <> COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_DOC_NO,'') <> COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_CONT_NO_NO,'') <> COALESCE(BF.CUST_CONT_NO_NO,'') -- 客户联系电话号码 非主键字段不相等
         OR COALESCE(TM.CUST_CONT_ADDR,'') <> COALESCE(BF.CUST_CONT_ADDR,'') -- 客户联系地址 非主键字段不相等
         OR COALESCE(TM.AGENT_NAME,'') <> COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段不相等
         OR COALESCE(TM.AGENT_DOCTYP_CD,'') <> COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.AGENT_DOC_NO,'') <> COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段不相等
         OR COALESCE(TM.CARD_PROD_CD,'') <> COALESCE(BF.CARD_PROD_CD,'') -- 卡产品代码 非主键字段不相等
         OR COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') <> COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段不相等
         OR COALESCE(TM.CARD_PROPTY_TYPE_CD,'') <> COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_MED_TYPE_CD,'') <> COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_AGT_TYPE_CD,'') <> COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_CARD_NO,'') <> COALESCE(BF.ORIG_CARD_CARD_NO,'') -- 原卡卡片编号 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_CSICC_NO,'') <> COALESCE(BF.ORIG_CARD_CSICC_NO,'') -- 原卡联名认同单位编号 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_PROPTY_TYPE_CD,'') <> COALESCE(BF.ORIG_CARD_PROPTY_TYPE_CD,'') -- 原卡性质类别代码 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_MED_TYPE_CD,'') <> COALESCE(BF.ORIG_CARD_MED_TYPE_CD,'') -- 原卡介质类别代码 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_AGT_TYPE_CD,'') <> COALESCE(BF.ORIG_CARD_AGT_TYPE_CD,'') -- 原卡协议类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_TXN_CHNL_CD,'') <> COALESCE(BF.CARD_CHG_TXN_CHNL_CD,'') -- 卡变更交易渠道代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_RSN_CD,'') <> COALESCE(BF.CARD_CHG_RSN_CD,'') -- 卡变更原因代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_RSN_DESC,'') <> COALESCE(BF.CARD_CHG_RSN_DESC,'') -- 卡变更原因描述 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_EVENT_CATE_CD,'') <> COALESCE(BF.CARD_CHG_EVENT_CATE_CD,'') -- 卡变更事件种类代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 卡变更账户金额 非主键字段不相等
         OR COALESCE(TM.DRAW_INT_ACCT_NO,'') <> COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段不相等
         OR COALESCE(TM.MAX_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MAX_LMT,CAST(0 AS DECIMAL(28,2))) -- 最高限额 非主键字段不相等
         OR COALESCE(TM.ACCT_EXPIR_DT,'') <> COALESCE(BF.ACCT_EXPIR_DT,'') -- 账户失效日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) -- 销户含税利息 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 销户利息税 非主键字段不相等
         OR COALESCE(TM.REPLOS_MATU_DT,'') <> COALESCE(BF.REPLOS_MATU_DT,'') -- 挂失到期日期 非主键字段不相等
         OR COALESCE(TM.MIN_CANCLR_DT,'') <> COALESCE(BF.MIN_CANCLR_DT,'') -- 最小解挂日期 非主键字段不相等
         OR COALESCE(TM.SCNCC_STAT_CD,'') <> COALESCE(BF.SCNCC_STAT_CD,'') -- 同卡号换卡状态代码 非主键字段不相等
         OR COALESCE(TM.SCNCC_APP_ORG_NO,'') <> COALESCE(BF.SCNCC_APP_ORG_NO,'') -- 同卡号换卡申请机构编号 非主键字段不相等
         OR COALESCE(TM.SCNCC_CERT_VALID,'') <> COALESCE(BF.SCNCC_CERT_VALID,'') -- 同卡号换卡证书有效期 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_ORIG_TXN_SER_NO,'') <> COALESCE(BF.INFO_CHG_ORIG_TXN_SER_NO,'') -- 信息变更原交易流水号 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_SUB_TXN_SER_NO,'') <> COALESCE(BF.INFO_CHG_SUB_TXN_SER_NO,'') -- 信息变更子交易流水号 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_ENABLED_DT,'') <> COALESCE(BF.INFO_CHG_ENABLED_DT,'') -- 信息变更启用日期 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_NEW_CONTENT_ILUS,'') <> COALESCE(BF.INFO_CHG_NEW_CONTENT_ILUS,'') -- 信息变更新内容说明 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_ORIG_CONTENT_ILUS,'') <> COALESCE(BF.INFO_CHG_ORIG_CONTENT_ILUS,'') -- 信息变更原内容说明 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CARD_CHG_TYPE_NAME,'') = COALESCE(BF.CARD_CHG_TYPE_NAME,'') -- 卡变更类型名称 非主键字段相等
         AND COALESCE(TM.CARD_CHG_PROC_ORG_NO,'') = COALESCE(BF.CARD_CHG_PROC_ORG_NO,'') -- 卡变更办理机构编号 非主键字段相等
         AND COALESCE(TM.CARD_CHG_PROC_TELR_NO,'') = COALESCE(BF.CARD_CHG_PROC_TELR_NO,'') -- 卡变更办理柜员编号 非主键字段相等
         AND COALESCE(TM.CARD_CHG_AUTH_TELR_NO,'') = COALESCE(BF.CARD_CHG_AUTH_TELR_NO,'') -- 卡变更授权柜员编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.CUST_CONT_NO_NO,'') = COALESCE(BF.CUST_CONT_NO_NO,'') -- 客户联系电话号码 非主键字段相等
         AND COALESCE(TM.CUST_CONT_ADDR,'') = COALESCE(BF.CUST_CONT_ADDR,'') -- 客户联系地址 非主键字段相等
         AND COALESCE(TM.AGENT_NAME,'') = COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段相等
         AND COALESCE(TM.AGENT_DOCTYP_CD,'') = COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.AGENT_DOC_NO,'') = COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段相等
         AND COALESCE(TM.CARD_PROD_CD,'') = COALESCE(BF.CARD_PROD_CD,'') -- 卡产品代码 非主键字段相等
         AND COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') = COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段相等
         AND COALESCE(TM.CARD_PROPTY_TYPE_CD,'') = COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段相等
         AND COALESCE(TM.CARD_MED_TYPE_CD,'') = COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段相等
         AND COALESCE(TM.CARD_AGT_TYPE_CD,'') = COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_CARD_NO,'') = COALESCE(BF.ORIG_CARD_CARD_NO,'') -- 原卡卡片编号 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_CSICC_NO,'') = COALESCE(BF.ORIG_CARD_CSICC_NO,'') -- 原卡联名认同单位编号 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_PROPTY_TYPE_CD,'') = COALESCE(BF.ORIG_CARD_PROPTY_TYPE_CD,'') -- 原卡性质类别代码 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_MED_TYPE_CD,'') = COALESCE(BF.ORIG_CARD_MED_TYPE_CD,'') -- 原卡介质类别代码 非主键字段相等
         AND COALESCE(TM.ORIG_CARD_AGT_TYPE_CD,'') = COALESCE(BF.ORIG_CARD_AGT_TYPE_CD,'') -- 原卡协议类别代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_TXN_CHNL_CD,'') = COALESCE(BF.CARD_CHG_TXN_CHNL_CD,'') -- 卡变更交易渠道代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_RSN_CD,'') = COALESCE(BF.CARD_CHG_RSN_CD,'') -- 卡变更原因代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_RSN_DESC,'') = COALESCE(BF.CARD_CHG_RSN_DESC,'') -- 卡变更原因描述 非主键字段相等
         AND COALESCE(TM.CARD_CHG_EVENT_CATE_CD,'') = COALESCE(BF.CARD_CHG_EVENT_CATE_CD,'') -- 卡变更事件种类代码 非主键字段相等
         AND COALESCE(TM.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 卡变更账户金额 非主键字段相等
         AND COALESCE(TM.DRAW_INT_ACCT_NO,'') = COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段相等
         AND COALESCE(TM.MAX_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MAX_LMT,CAST(0 AS DECIMAL(28,2))) -- 最高限额 非主键字段相等
         AND COALESCE(TM.ACCT_EXPIR_DT,'') = COALESCE(BF.ACCT_EXPIR_DT,'') -- 账户失效日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) -- 销户含税利息 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 销户利息税 非主键字段相等
         AND COALESCE(TM.REPLOS_MATU_DT,'') = COALESCE(BF.REPLOS_MATU_DT,'') -- 挂失到期日期 非主键字段相等
         AND COALESCE(TM.MIN_CANCLR_DT,'') = COALESCE(BF.MIN_CANCLR_DT,'') -- 最小解挂日期 非主键字段相等
         AND COALESCE(TM.SCNCC_STAT_CD,'') = COALESCE(BF.SCNCC_STAT_CD,'') -- 同卡号换卡状态代码 非主键字段相等
         AND COALESCE(TM.SCNCC_APP_ORG_NO,'') = COALESCE(BF.SCNCC_APP_ORG_NO,'') -- 同卡号换卡申请机构编号 非主键字段相等
         AND COALESCE(TM.SCNCC_CERT_VALID,'') = COALESCE(BF.SCNCC_CERT_VALID,'') -- 同卡号换卡证书有效期 非主键字段相等
         AND COALESCE(TM.INFO_CHG_ORIG_TXN_SER_NO,'') = COALESCE(BF.INFO_CHG_ORIG_TXN_SER_NO,'') -- 信息变更原交易流水号 非主键字段相等
         AND COALESCE(TM.INFO_CHG_SUB_TXN_SER_NO,'') = COALESCE(BF.INFO_CHG_SUB_TXN_SER_NO,'') -- 信息变更子交易流水号 非主键字段相等
         AND COALESCE(TM.INFO_CHG_ENABLED_DT,'') = COALESCE(BF.INFO_CHG_ENABLED_DT,'') -- 信息变更启用日期 非主键字段相等
         AND COALESCE(TM.INFO_CHG_NEW_CONTENT_ILUS,'') = COALESCE(BF.INFO_CHG_NEW_CONTENT_ILUS,'') -- 信息变更新内容说明 非主键字段相等
         AND COALESCE(TM.INFO_CHG_ORIG_CONTENT_ILUS,'') = COALESCE(BF.INFO_CHG_ORIG_CONTENT_ILUS,'') -- 信息变更原内容说明 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CARD_CHG_TYPE_NAME,'') <> COALESCE(BF.CARD_CHG_TYPE_NAME,'') -- 卡变更类型名称 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_PROC_ORG_NO,'') <> COALESCE(BF.CARD_CHG_PROC_ORG_NO,'') -- 卡变更办理机构编号 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_PROC_TELR_NO,'') <> COALESCE(BF.CARD_CHG_PROC_TELR_NO,'') -- 卡变更办理柜员编号 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_AUTH_TELR_NO,'') <> COALESCE(BF.CARD_CHG_AUTH_TELR_NO,'') -- 卡变更授权柜员编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_DOCTYP_CD,'') <> COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_DOC_NO,'') <> COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_CONT_NO_NO,'') <> COALESCE(BF.CUST_CONT_NO_NO,'') -- 客户联系电话号码 非主键字段不相等
         OR COALESCE(TM.CUST_CONT_ADDR,'') <> COALESCE(BF.CUST_CONT_ADDR,'') -- 客户联系地址 非主键字段不相等
         OR COALESCE(TM.AGENT_NAME,'') <> COALESCE(BF.AGENT_NAME,'') -- 代理人名称 非主键字段不相等
         OR COALESCE(TM.AGENT_DOCTYP_CD,'') <> COALESCE(BF.AGENT_DOCTYP_CD,'') -- 代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.AGENT_DOC_NO,'') <> COALESCE(BF.AGENT_DOC_NO,'') -- 代理人证件号码 非主键字段不相等
         OR COALESCE(TM.CARD_PROD_CD,'') <> COALESCE(BF.CARD_PROD_CD,'') -- 卡产品代码 非主键字段不相等
         OR COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') <> COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段不相等
         OR COALESCE(TM.CARD_PROPTY_TYPE_CD,'') <> COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_MED_TYPE_CD,'') <> COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_AGT_TYPE_CD,'') <> COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_CARD_NO,'') <> COALESCE(BF.ORIG_CARD_CARD_NO,'') -- 原卡卡片编号 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_CSICC_NO,'') <> COALESCE(BF.ORIG_CARD_CSICC_NO,'') -- 原卡联名认同单位编号 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_PROPTY_TYPE_CD,'') <> COALESCE(BF.ORIG_CARD_PROPTY_TYPE_CD,'') -- 原卡性质类别代码 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_MED_TYPE_CD,'') <> COALESCE(BF.ORIG_CARD_MED_TYPE_CD,'') -- 原卡介质类别代码 非主键字段不相等
         OR COALESCE(TM.ORIG_CARD_AGT_TYPE_CD,'') <> COALESCE(BF.ORIG_CARD_AGT_TYPE_CD,'') -- 原卡协议类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_TXN_CHNL_CD,'') <> COALESCE(BF.CARD_CHG_TXN_CHNL_CD,'') -- 卡变更交易渠道代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_RSN_CD,'') <> COALESCE(BF.CARD_CHG_RSN_CD,'') -- 卡变更原因代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_RSN_DESC,'') <> COALESCE(BF.CARD_CHG_RSN_DESC,'') -- 卡变更原因描述 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_EVENT_CATE_CD,'') <> COALESCE(BF.CARD_CHG_EVENT_CATE_CD,'') -- 卡变更事件种类代码 非主键字段不相等
         OR COALESCE(TM.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CARD_CHG_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 卡变更账户金额 非主键字段不相等
         OR COALESCE(TM.DRAW_INT_ACCT_NO,'') <> COALESCE(BF.DRAW_INT_ACCT_NO,'') -- 收息账户编号 非主键字段不相等
         OR COALESCE(TM.MAX_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MAX_LMT,CAST(0 AS DECIMAL(28,2))) -- 最高限额 非主键字段不相等
         OR COALESCE(TM.ACCT_EXPIR_DT,'') <> COALESCE(BF.ACCT_EXPIR_DT,'') -- 账户失效日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CANC_ACCT_INCLD_TAX_INT,CAST(0 AS DECIMAL(28,2))) -- 销户含税利息 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CANC_ACCT_INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 销户利息税 非主键字段不相等
         OR COALESCE(TM.REPLOS_MATU_DT,'') <> COALESCE(BF.REPLOS_MATU_DT,'') -- 挂失到期日期 非主键字段不相等
         OR COALESCE(TM.MIN_CANCLR_DT,'') <> COALESCE(BF.MIN_CANCLR_DT,'') -- 最小解挂日期 非主键字段不相等
         OR COALESCE(TM.SCNCC_STAT_CD,'') <> COALESCE(BF.SCNCC_STAT_CD,'') -- 同卡号换卡状态代码 非主键字段不相等
         OR COALESCE(TM.SCNCC_APP_ORG_NO,'') <> COALESCE(BF.SCNCC_APP_ORG_NO,'') -- 同卡号换卡申请机构编号 非主键字段不相等
         OR COALESCE(TM.SCNCC_CERT_VALID,'') <> COALESCE(BF.SCNCC_CERT_VALID,'') -- 同卡号换卡证书有效期 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_ORIG_TXN_SER_NO,'') <> COALESCE(BF.INFO_CHG_ORIG_TXN_SER_NO,'') -- 信息变更原交易流水号 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_SUB_TXN_SER_NO,'') <> COALESCE(BF.INFO_CHG_SUB_TXN_SER_NO,'') -- 信息变更子交易流水号 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_ENABLED_DT,'') <> COALESCE(BF.INFO_CHG_ENABLED_DT,'') -- 信息变更启用日期 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_NEW_CONTENT_ILUS,'') <> COALESCE(BF.INFO_CHG_NEW_CONTENT_ILUS,'') -- 信息变更新内容说明 非主键字段不相等
         OR COALESCE(TM.INFO_CHG_ORIG_CONTENT_ILUS,'') <> COALESCE(BF.INFO_CHG_ORIG_CONTENT_ILUS,'') -- 信息变更原内容说明 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.CARD_NO,'') = COALESCE(BF.CARD_NO,'') -- 卡片编号 主键字段关联
    AND COALESCE(TM.CARD_CHG_TM_STAMP,'') = COALESCE(BF.CARD_CHG_TM_STAMP,'') -- 卡变更时间戳 主键字段关联
    AND COALESCE(TM.CARD_CHG_EVENT_NO,'') = COALESCE(BF.CARD_CHG_EVENT_NO,'') -- 卡变更事件编号 主键字段关联
    AND COALESCE(TM.CARD_CHG_TYPE_CD,'') = COALESCE(BF.CARD_CHG_TYPE_CD,'') -- 卡变更类型代码 主键字段关联
    AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF_TM;
DROP TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_01;
DROP TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_02;
DROP TABLE AGL.TMP_AGL_DEBIT_CARD_CHANGE_DTL_TF_03;
