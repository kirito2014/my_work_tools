-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-ATM非动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ATM_UN_MVACCT_TXN_DTL_TA
--     表中文名：ATM非动账交易明细聚合
--     创建日期：None
--     主键字段：TXN_DT, TXN_TM_STAMP, EQUIP_NO, EQUIP_SYS_TRACK_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-15 00:00:00 万香 新增
--         2024-10-21 00:00:00 魏丹丹 修改临时表1,2,3的开窗分组字段
--         2024-10-28 00:00:00 魏丹丹 重写



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA_TM
USING ORC
COMMENT 'ATM非动账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,ORIG_SER_NO -- 原始流水号
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CARD_HOLDER_NAME -- 持卡人名称
    ,CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CARD_HOLDER_DOCTYP_CD -- 持卡人证件类型代码
    ,CARD_HOLDER_DOC_NO -- 持卡人证件号码
    ,EQUIP_NO -- 设备编号
    ,EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,EQUIP_RGN_CD -- 设备地区代码
    ,EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,ACPTD_TXN_ORG_NAME -- 受理交易机构名称
    ,RETRIV_REF_NO -- 检索参考号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,ERR_DESC -- 错误描述
    ,SERV_SIDE_ADDIT_INFO_DESC -- 服务端附加信息
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- ATM非动账交易明细聚合

INSERT INTO TABLE AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,ORIG_SER_NO -- 原始流水号
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CARD_HOLDER_NAME -- 持卡人名称
    ,CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CARD_HOLDER_DOCTYP_CD -- 持卡人证件类型代码
    ,CARD_HOLDER_DOC_NO -- 持卡人证件号码
    ,EQUIP_NO -- 设备编号
    ,EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,EQUIP_RGN_CD -- 设备地区代码
    ,EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,ACPTD_TXN_ORG_NAME -- 受理交易机构名称
    ,RETRIV_REF_NO -- 检索参考号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,ERR_DESC -- 错误描述
    ,SERV_SIDE_ADDIT_INFO_DESC -- 服务端附加信息
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     cast(P1.YLF_11 as string) AS TXN_SER_NO -- 交易流水号
    ,unifiedTime(P1.QZJYRQ) AS TXN_DT -- 交易日期
    ,unifiedTime(P1.F_7) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.LSH AS ORIG_SER_NO -- 原始流水号
    ,P1.F_2 AS TXN_CARD_NO -- 交易卡片编号
    ,CASE WHEN P1.F2_BINTYPE = '1' THEN P2.DFANAC19
     WHEN P1.F2_BINTYPE = '2' THEN cast(P3.XACCOUNT as string)
     WHEN P1.F2_BINTYPE = '3' THEN ''
     ELSE '' END AS TXN_ACCT_NO -- 交易账户编号
    ,P1.TYPE AS ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,P1.F_49 AS TXN_CURR_CD -- 交易币种代码
    ,P1.F2_BINTYPE AS TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,P1.F_23 AS TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CASE WHEN P1.F2_BINTYPE ='1' THEN P2.CHNMNM40
     WHEN P1.F2_BINTYPE ='2' THEN P4.CRTF_NM
     WHEN P1.F2_BINTYPE ='3' THEN ''
     ELSE ''
END AS CARD_HOLDER_NAME -- 持卡人名称
    ,CASE WHEN P1.F2_BINTYPE = '1' THEN P2.CINOCSNO
     WHEN P1.F2_BINTYPE = '2' THEN P4.CST_IN_CD
     WHEN P1.F2_BINTYPE = '3' THEN ''
     ELSE ''
END AS CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CASE WHEN P1.F2_BINTYPE ='1' THEN P4.CRTF_TYP
     WHEN P1.F2_BINTYPE ='2' THEN P5.CRTF_TYP
     WHEN P1.F2_BINTYPE ='3' THEN ''
     ELSE ''
END AS CARD_HOLDER_DOCTYP_CD -- 持卡人证件类型代码
    ,CASE WHEN P1.F2_BINTYPE = '1' THEN P4.CRTF_NO
     WHEN P1.F2_BINTYPE = '2' THEN P3.CUSTR_NBR
     WHEN P1.F2_BINTYPE = '3' THEN ''
     ELSE ''
END AS CARD_HOLDER_DOC_NO -- 持卡人证件号码
    ,P1.F_41 AS EQUIP_NO -- 设备编号
    ,P1.F_11 AS EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,P1.YLDQDM AS EQUIP_RGN_CD -- 设备地区代码
    ,concat(SUBSTR(P1.JGM,3,3),'000') AS EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,SUBSTR(P1.JGM,3,6) AS EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,P1.CZY AS EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,P1.F_42 AS ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,P6.TRANS_ORG_NAME AS ACPTD_TXN_ORG_NAME -- 受理交易机构名称
    ,P1.F_37 AS RETRIV_REF_NO -- 检索参考号
    ,P1.F_18 AS MERCHT_MCC_CD -- 商户MCC代码
    ,substr(P1.f_22,1,2) AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,P1.ERRMSG AS ERR_DESC -- 错误描述
    ,P1.F_60 AS SERV_SIDE_ADDIT_INFO_DESC -- 服务端附加信息
    ,'CARD' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CARD_ATMJYLS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CARD.ODS_CARD_ATMJYLS_TA AS P1 -- ATM交易流水表

LEFT JOIN (
SELECT
 DFANAC19
,CDNOAC19
,CINOCSNO
,CHNMNM40
FROM ODS_CORE.ODS_CORE_BWFMDCIM_TF
WHERE PT_DT='${process_date}' AND DEL_F = '0'
) AS P2 -- 借记卡信息主档文件
       ON P1.F_2 = P2.CDNOAC19 
LEFT JOIN (
SELECT
   CARD_NBR    
  ,CUSTR_NBR
  ,XACCOUNT
FROM ODS_CCRD.ODS_CCRD_CARD_TF
WHERE PT_DT='${process_date}'  AND  DEL_F = '0'
) AS P3 -- 卡片资料表
       ON P1.F_2 = P3.CARD_NBR 
LEFT JOIN (SELECT T.* FROM (
    SELECT
      CST_IN_CD
     ,CRTF_NO
     ,CRTF_NM
     ,CRTF_TYP
     ,ROW_NUMBER() OVER(PARTITION BY CRTF_NO ORDER BY GMT_MODIFIED DESC ) RN 
    FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF 
    WHERE MAJOR_FLG='1' AND PT_DT='${process_date}' AND DEL_F = '0' 
)T WHERE T.RN=1
) AS P4 -- None
       ON P3.CUSTR_NBR = P4.CRTF_NO 
LEFT JOIN (SELECT T.* FROM (
    SELECT
      CST_IN_CD
     ,CRTF_TYP
     ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY GMT_MODIFIED DESC ) RN 
    FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF 
    WHERE MAJOR_FLG='1' AND PT_DT='${process_date}' AND DEL_F = '0' 
)T WHERE T.RN=1
) AS P5 -- None
       ON P2.CINOCSNO = P5.CST_IN_CD 
LEFT JOIN (
SELECT
 TRANS_ORG_NAME
,TRANS_ORG_NO
FROM ODS_CCPT.ODS_CCPT_JC_TRANS_ORG_STATUS_TF
WHERE PT_DT='${process_date}' AND DEL_F = '0'
) AS P6 -- 银联交易机构代码表
       ON P1.f_42 =P6.TRANS_ORG_NO 
WHERE P1.PT_DT='${process_date}'    AND    P1.DEL_F = '0'   AND length(trim(P1.f_4)) = 0  OR trim(P1.f_4)='000000000000' OR P1.f_4 IS NULL OR P1.f_4=''
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,ORIG_SER_NO -- 原始流水号
    ,TXN_CARD_NO -- 交易卡片编号
    ,TXN_ACCT_NO -- 交易账户编号
    ,ATM_TXN_TYPE_CD -- ATM交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CARD_TYPE_CD -- 交易卡片类型代码
    ,TXN_CARD_SEQ_NO -- 交易卡片序列编号
    ,CARD_HOLDER_NAME -- 持卡人名称
    ,CARD_HOLDER_CUST_IN_CD -- 持卡人客户内码
    ,CARD_HOLDER_DOCTYP_CD -- 持卡人证件类型代码
    ,CARD_HOLDER_DOC_NO -- 持卡人证件号码
    ,EQUIP_NO -- 设备编号
    ,EQUIP_SYS_TRACK_NO -- 设备系统跟踪号
    ,EQUIP_RGN_CD -- 设备地区代码
    ,EQUIP_BELONG_BNKOUTLS_NO -- 设备归属网点编号
    ,EQUIP_BELONG_ORG_NO -- 设备归属机构编号
    ,EQUIP_VIRTUAL_TELR_NO -- 设备虚拟柜员编号
    ,ACPTD_TXN_UNPY_ORG_NO -- 受理交易银联机构编号
    ,ACPTD_TXN_ORG_NAME -- 受理交易机构名称
    ,RETRIV_REF_NO -- 检索参考号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,ERR_DESC -- 错误描述
    ,SERV_SIDE_ADDIT_INFO_DESC -- 服务端附加信息
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA_TM;
