-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人数字货币钱包非动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA
--     表中文名：个人数字货币钱包非动账交易明细聚合
--     创建日期：2024-06-11 00:00:00
--     主键字段：CORE_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：13M
--     描述信息：个人数字货币钱包非动账交易明细信息
--     更新记录：
--         2024-06-11 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 设计同步更新 20240711 修改时间戳字段
--         2024-09-23 00:00:00 王穆军 修改筛选条件
--         2024-11-10 00:00:00 魏丹丹 修改主表筛选条件



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '个人数字货币钱包非动账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CORE_SER_NO -- 核心流水号
    ,CHNL_SER_NO -- 渠道流水号
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,PLAT_BATCH_NO -- 平台批次编号
    ,CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,TXN_AMT -- 交易金额
    ,DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,WALLET_NO -- 钱包编号
    ,WALLET_NAME -- 钱包名称
    ,WALLET_TYPE_CD -- 钱包类型代码
    ,WALLET_LVL_CD -- 钱包等级代码
    ,WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,BANK_CARD_NO -- 银行卡号
    ,USER_ID -- 用户id
    ,CUST_IN_CD -- 客户内码
    ,OPEN_CARD_ORG_NO -- 开卡机构编号
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,SYS_CD -- 系统代码
    ,ANALY_CHNL_CD -- 分析渠道代码
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,OPERR_MOBILE_NO -- 经办人手机号码
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA_TM(
     CORE_SER_NO -- 核心流水号
    ,CHNL_SER_NO -- 渠道流水号
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,PLAT_BATCH_NO -- 平台批次编号
    ,CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,TXN_AMT -- 交易金额
    ,DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,WALLET_NO -- 钱包编号
    ,WALLET_NAME -- 钱包名称
    ,WALLET_TYPE_CD -- 钱包类型代码
    ,WALLET_LVL_CD -- 钱包等级代码
    ,WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,BANK_CARD_NO -- 银行卡号
    ,USER_ID -- 用户id
    ,CUST_IN_CD -- 客户内码
    ,OPEN_CARD_ORG_NO -- 开卡机构编号
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,SYS_CD -- 系统代码
    ,ANALY_CHNL_CD -- 分析渠道代码
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,OPERR_MOBILE_NO -- 经办人手机号码
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.CORE_TXN_SSN AS CORE_SER_NO -- 核心流水号
    ,T1.CHNL_REQ_TXN_SSN AS CHNL_SER_NO -- 渠道流水号
    ,T1.ORIG_CORE_TXN_SSN AS CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,T1.ORIG_ORDER_TXN_SSN AS ORIG_CHNL_SER_NO -- 原渠道流水号
    ,T1.TXN_TRACE_ID AS TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,T1.BATCH_ID AS PLAT_BATCH_NO -- 平台批次编号
    ,unifiedTime(T1.CORE_TXN_TIME) AS CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,unifiedTime(T1.CHNL_REQ_TXN_TIME) AS CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,unifiedTime(T1.ORIG_CORE_TXN_TIME) AS ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,unifiedTime(T1.ORIG_ORDER_TXN_TIME) AS ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,unifiedTime(T1.TXN_EXPIRE_TIME) AS TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,T1.TXN_AMT AS TXN_AMT -- 交易金额
    ,T1.TXN_TYPE_NO AS DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,T1.TXN_CURRENY_CODE AS TXN_CURR_CD -- 交易币种代码
    ,T1.TXN_SUB_TYPE_NO AS DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,T1.TXN_STATE AS TXN_STATUS_CD -- 交易状态代码
    ,T1.ERROR_CODE AS ERR_CD -- 错误编码
    ,T1.ERROR_MSG AS ERR_DESC -- 错误描述
    ,T1.BIZ_TYP AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,T1.BIZ_KIND AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,T2.FINANCE_CD AS WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,T1.WLT_ID AS WALLET_NO -- 钱包编号
    ,T3.WLT_NM AS WALLET_NAME -- 钱包名称
    ,T3.WLT_TP AS WALLET_TYPE_CD -- 钱包类型代码
    ,T3.WLT_LVL AS WALLET_LVL_CD -- 钱包等级代码
    ,T3.WLT_STS AS WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,T1.ACCT AS BANK_CARD_NO -- 银行卡号
    ,T1.CUST_ID AS USER_ID -- 用户id
    ,T4.CST_IN_CD AS CUST_IN_CD -- 客户内码
    ,T1.SGN_ORG_NO AS OPEN_CARD_ORG_NO -- 开卡机构编号
    ,T1.TRANS_ORG_ID AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,unifiedTime(T1.GMT_CREATE) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(T1.GMT_MODIFIED) AS MODIF_TM_STAMP -- 修改时间戳
    ,T1.CHNL_NO AS DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,T1.SYSTEM_ID AS SYS_CD -- 系统代码
    ,T1.ANAY_CHNL_ID AS ANALY_CHNL_CD -- 分析渠道代码
    ,T1.RSPB_PSN_NM AS OPERR_NAME -- 经办人名称
    ,T1.RSPB_PSN_ID_TP AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,T1.RSPB_PSN_ID_NO AS OPERR_DOC_NO -- 经办人证件号码
    ,T1.RSPB_PSN_TEL AS OPERR_MOBILE_NO -- 经办人手机号码
    ,T1.OPERATOR_ID AS VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,'DCEPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_DCEPS_CORE_TXN_SSN_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_DCEPS${version_num}.ODS_DCEPS_CORE_TXN_SSN_TA AS T1 -- 核心业务交易流水表

LEFT JOIN ODS_DCEPS${version_num}.ODS_DCEPS_DCEP_ORG_FINANCE_CD_TF AS T2 -- DCEP机构金融机构编码映射表
       ON T1.PAGY_NO=T2.DCEP_ORG_NO
AND T2.PT_DT = '${process_date}'
AND T2.DEL_F = '0' 
LEFT JOIN (
select
 *
,
 row_number () over(partition by WLT_ID
order by
 gmt_modified DESC, gmt_create desc ) rn
from
 ODS_DCEPS${version_num}.ODS_DCEPS_WLT_INDV_INF_TF t3
where
 T3.PT_DT = '${process_date}'
 and T3.DEL_F = '0' 
) AS T3 -- 对私钱包信息
       ON T1.WLT_ID = T3.WLT_ID
AND T3.RN =1 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF AS T4 -- 用户信息表
       ON T1.CUST_ID = T4.USER_ID
AND T4.PT_DT = '${process_date}'
AND T4.DEL_F = '0' 
WHERE T1.TXN_AMT<=0 AND T1.PT_DT = '${process_date}' and T1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     CORE_SER_NO -- 核心流水号
    ,CHNL_SER_NO -- 渠道流水号
    ,CORE_ORIG_TXN_SER_NO -- 核心原交易流水号
    ,ORIG_CHNL_SER_NO -- 原渠道流水号
    ,TXN_TRACK_SER_NO -- 交易跟踪流水号
    ,PLAT_BATCH_NO -- 平台批次编号
    ,CORE_FLOW_TM_STAMP -- 核心流水时间戳
    ,CHNL_REQE_FLOW_TM_STAMP -- 渠道请求流水时间戳
    ,ORIG_TXN_CORE_FLOW_TM_STAMP -- 原交易核心流水时间戳
    ,ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP -- 原交易渠道请求流水时间戳
    ,TXN_OVERTM_TM_STAMP -- 交易超时时间戳
    ,TXN_AMT -- 交易金额
    ,DIGIT_MNTYTIE_TXN_TYPE_CD -- 数币交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,DIGIT_MNTYTIE_SUB_TXN_TYPE_CD -- 数币子交易类型代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,ERR_CD -- 错误编码
    ,ERR_DESC -- 错误描述
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,WALLET_ESTB_AFLT_FIN_ORG_CD -- 钱包开立所属金融机构编码
    ,WALLET_NO -- 钱包编号
    ,WALLET_NAME -- 钱包名称
    ,WALLET_TYPE_CD -- 钱包类型代码
    ,WALLET_LVL_CD -- 钱包等级代码
    ,WALLET_ACCT_STATUS_CD -- 钱包账户状态代码
    ,BANK_CARD_NO -- 银行卡号
    ,USER_ID -- 用户id
    ,CUST_IN_CD -- 客户内码
    ,OPEN_CARD_ORG_NO -- 开卡机构编号
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,DIGIT_MNTYTIE_TXN_CHNL_CD -- 数币交易渠道代码
    ,SYS_CD -- 系统代码
    ,ANALY_CHNL_CD -- 分析渠道代码
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,OPERR_MOBILE_NO -- 经办人手机号码
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_INDV_DIGIT_MNTY_WALLET_UN_MVACCT_TXN_DTL_TA_TM;
