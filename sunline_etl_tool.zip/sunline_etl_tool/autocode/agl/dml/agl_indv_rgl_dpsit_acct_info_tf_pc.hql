-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人定期存款账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_RGL_DPSIT_ACCT_INFO_TF
--     表中文名：个人定期存款账户信息聚合
--     创建日期：2023-12-19 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-19 00:00:00 游崔龙 新增
--         2024-01-18 00:00:00 游崔龙 对标
--         2024-09-09 00:00:00 魏丹丹 新增表，新增昨日积数折人民币等11个字段，新加表
--         2024-09-20 00:00:00 魏丹丹 新增表，客户基础信息表  ODS_CIF_T_CIF_CUST_BASE_INFO_TF
--         2024-09-27 00:00:00 魏丹丹 修改两组 客户内码,存期天数 的取数逻辑
--         2024-11-05 00:00:00 魏丹丹 调整昨日余额取数逻辑，新增字段:电子负债账户性质代码,电子负债账户类型代码



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM
USING ORC
COMMENT '个人定期存款账户信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CUST_TYPE_CD -- 客户类型代码
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,ACCT_STATUS_CD -- 账户状态代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,ORIG_DPSIT_TERM -- 原始存款期限
    ,DPSIT_PERIOD_DAYS -- 存期天数
    ,EACCT_NO -- 电子账户编号
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,EACCT_BIND_CARD_NO -- 电子账户绑定卡号
    ,VOCH_NO -- 凭证号码
    ,MED_TYPE_CD -- 介质类型代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REDT_FLAG -- 转存标志
    ,AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,AGREE_FLAG -- 协定标志
    ,PLEDGE_FLAG -- 质押标志
    ,DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,OPEN_ACCT_AMT -- 开户金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_BAL -- 当前余额
    ,CTRL_AMT -- 控制金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,INTACR_MODE_CD -- 计息方式代码
    ,INTACR_BASE_CD -- 计息基础代码
    ,INT_TAX -- 利息税
    ,INT_TXBL_AMT -- 利息应税金额
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,BNCHMK_INT_RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,MNYITM_SRC_CD -- 款项来源代码
    ,OPEN_ACCT_DT -- 开户日期
    ,OPEN_ACCT_TM -- 开户时间
    ,OPEN_ACCT_TELR -- 开户柜员
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,PAYOFF_DT -- 结清日期
    ,NEXT_CAN_DRAW_DT -- 下次可支取日期
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 临时表1
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_01;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_01 (
     ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,CUST_TYPE_CD STRING COMMENT '客户类型代码'
    ,MAIN_DOCTYP_CD STRING COMMENT '主证件类型代码'
    ,MAIN_DOC_NO STRING COMMENT '主证件号码'
    ,OPEN_ACCT_DOC_NO STRING COMMENT '开户证件号码'
    ,UNIVERSAL_WITHDR_LVL_CD STRING COMMENT '通兑级别代码'
    ,UNIVERSAL_SAVING_LVL_CD STRING COMMENT '通存级别代码'
    ,MRG_BIZ_CATE_CD STRING COMMENT '保证金业务种类代码'
    ,AGREE_REDT_ACCT_NO STRING COMMENT '约定转存账户编号'
    ,VOCH_NO STRING COMMENT '凭证号码'
    ,MED_TYPE_CD STRING COMMENT '介质类型代码'
    ,REPLOS_STATUS_CD STRING COMMENT '挂失状态代码'
    ,DRAW_MODE_CD STRING COMMENT '支取方式代码'
    ,AGREE_FLAG STRING COMMENT '协定标志'
    ,INT_FREE_TAX_FLAG STRING COMMENT '豁免利息税标志'
    ,MNYITM_SRC_CD STRING COMMENT '款项来源代码'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,CANC_ACCT_DT STRING COMMENT '销户日期'
    ,OPEN_ACCT_DOCTYP_CD STRING COMMENT '开户证件类型代码'
    ,FX_ACCT_PROPTY_CD STRING COMMENT '外汇账户性质代码'
    ,AA12ZHZT STRING COMMENT '关联字段'
    ,INDV_CORP_IDNT_CD STRING COMMENT '个人企业标识代码'
    ,MRGACCT_FLAG STRING COMMENT '保证金账户标志'
    ,DPSIT_COMB_PROD_CD STRING COMMENT '存款组合产品代码'
    ,DPSIT_COMB_PROD_NAME STRING COMMENT '存款组合产品名称'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '临时表1'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_01(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_TYPE_CD -- 客户类型代码
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,VOCH_NO -- 凭证号码
    ,MED_TYPE_CD -- 介质类型代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,AGREE_FLAG -- 协定标志
    ,INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,MNYITM_SRC_CD -- 款项来源代码
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_DT -- 销户日期
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,AA12ZHZT -- 关联字段
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,LP_ORG_NO -- 法人机构编号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AA01AC15 AS ACCT_NO -- 账户编号
    ,P1.AA04FLNM AS ACCT_NAME -- 账户名称
    ,P1.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,COALESCE(P2.USER_ID,P5.CUSTID) AS USER_ID -- 用户ID
    ,P3.CUST_NM AS CUST_NAME -- 客户名称
    ,CASE WHEN SUBSTR(P1.AA03CSNO,1,2)='81' THEN '1' WHEN SUBSTR(P1.AA03CSNO,1,2)='82' THEN '2' ELSE '3' END AS CUST_TYPE_CD -- 客户类型代码
    ,P4.CRTF_TYP AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P4.CRTF_NO AS MAIN_DOC_NO -- 主证件号码
    ,P1.AA50CFNO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.AA31SSLV AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,P1.AA32SWLV AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,P1.AA53SDTP AS MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,P6.AK07AC15 AS AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,CAST(P1.AA23BLNO AS STRING) AS VOCH_NO -- 凭证号码
    ,P1.AA09ACT2 AS MED_TYPE_CD -- 介质类型代码
    ,P1.AA11PZZT AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P1.AA13DRWT AS DRAW_MODE_CD -- 支取方式代码
    ,P1.AA51BOOL AS AGREE_FLAG -- 协定标志
    ,P1.AA34BOOL AS INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,P1.AA46MNFM AS MNYITM_SRC_CD -- 款项来源代码
    ,unifiedTime(CAST(P1.AA38DATE AS STRING)) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(CAST(P1.AA39DATE AS STRING)) AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN P1.AA49CFTP IS NULL OR TRIM(P1.AA49CFTP)=''
     THEN ''
     ELSE COALESCE(TRIM(P10.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AA49CFTP)),'')
END AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,CASE WHEN P1.AA47WZDM IS NULL OR TRIM(P1.AA47WZDM)=''
     THEN ''
     ELSE COALESCE(TRIM(P11.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AA47WZDM)),'')
END AS FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,P1.AA12ZHZT AS AA12ZHZT -- 关联字段
    ,P1.AA07CSTP AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN TRIM(P1.AA53SDTP)='' THEN '0' ELSE '1' END AS MRGACCT_FLAG -- 保证金账户标志
    ,CASE WHEN SUBSTR(P1.AA37RMRK,1,5)='91107' THEN '1'
     WHEN SUBSTR(P1.AA37RMRK,1,5)='91109' THEN '2'
     WHEN SUBSTR(P1.AA37RMRK,1,5)='91111' THEN '3'
     ELSE ''
END AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,CASE WHEN SUBSTR(P1.AA37RMRK,1,5)='91107' THEN '定活互转'
     WHEN SUBSTR(P1.AA37RMRK,1,5)='91109' THEN '定活通'
     WHEN SUBSTR(P1.AA37RMRK,1,5)='91111' THEN '定盈宝'
     ELSE ''
END AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P1.AA43BRNO AS LP_ORG_NO -- 法人机构编号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE${version_num}.ODS_CORE_BFFMDQAA_TF AS P1 -- 定期存款帐户控制文件

LEFT JOIN (SELECT * FROM(
SELECT
    P2.USER_ID
   ,P2.CST_IN_CD
   ,ROW_NUMBER()OVER(PARTITION BY CST_IN_CD ORDER BY USER_ID DESC) RN
FROM ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF P2
where P2.PT_DT = '${process_date}' AND P2.DELETED='0' AND P2.DEL_F='0'
)WHERE RN=1) AS P2 -- 用户信息表
       ON P1.AA03CSNO = P2.CST_IN_CD 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF AS P3 -- 客户基础信息表
       ON P1.AA03CSNO = P3.CST_IN_CD AND P3.DEL_F='0' AND P3.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT
   CST_IN_CD
  ,CRTF_TYP
  ,CRTF_NO
  ,ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) RN
FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF  
WHERE MAJOR_FLG='1' AND DELETED='0' AND DEL_F='0'  AND PT_DT = '${process_date}'
) AS P4 -- 客户证件信息表
       ON P1.AA03CSNO = P4.CST_IN_CD AND P4.RN=1 
LEFT JOIN (SELECT * FROM(
SELECT
   CUSTCD
  ,CUSTID
  ,ROW_NUMBER()OVER(PARTITION BY CUSTCD ORDER BY STATUS) RN
FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF 
WHERE PT_DT = '${process_date}' AND DEL_F='0'
)WHERE RN=1) AS P5 -- 客户信息关联表
       ON P1.AA03CSNO = P5.CUSTCD 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFCDQAK_TF AS P6 -- 定期签约信息
       ON P1.AA01AC15 = P6.AK01AC15 AND P6.AK03QYLX = '3'  AND P6.DEL_F='0'  AND P6.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P10 -- 代码转换
       ON P1.AA49CFTP=P10.SRC_CD_VAL  
AND P10.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND P10.SRC_TAB_EN_NAME='BFFMDQAA' --来源表英文名  
AND P10.SRC_FIELD_EN_NAME='AA49CFTP' --来源字段英文名 
AND P10.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P10.TARGET_FIELD_EN_NAME='OPEN_ACCT_DOCTYP_CD' --目标字段 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P11 -- 代码转换
       ON P1.AA47WZDM=P11.SRC_CD_VAL  
AND P11.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND P11.SRC_TAB_EN_NAME='BFFMDQAA' --来源表英文名  
AND P11.SRC_FIELD_EN_NAME='AA47WZDM' --来源字段英文名 
AND P11.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P11.TARGET_FIELD_EN_NAME='FX_ACCT_PROPTY_CD' --目标字段 
WHERE SUBSTR(P1.AA01AC15,1,1) = '1'  AND P1.DEL_F='0' AND P1.PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第1-2组）==============
-- 临时表2
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_02;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_02 (
     ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,CUST_TYPE_CD STRING COMMENT '客户类型代码'
    ,MAIN_DOCTYP_CD STRING COMMENT '主证件类型代码'
    ,MAIN_DOC_NO STRING COMMENT '主证件号码'
    ,OPEN_ACCT_DOCTYP_CD STRING COMMENT '开户证件类型代码'
    ,OPEN_ACCT_DOC_NO STRING COMMENT '开户证件号码'
    ,FX_ACCT_PROPTY_CD STRING COMMENT '外汇账户性质代码'
    ,FX_CUST_TYPE_CD STRING COMMENT '外汇客户类别代码'
    ,UNIVERSAL_WITHDR_LVL_CD STRING COMMENT '通兑级别代码'
    ,UNIVERSAL_SAVING_LVL_CD STRING COMMENT '通存级别代码'
    ,ACCT_TYPE_CD STRING COMMENT '账户类型代码'
    ,ACCT_PROPTY_CD STRING COMMENT '账户性质代码'
    ,ACCT_STATUS_CD STRING COMMENT '账户状态代码'
    ,DPSIT_BIZ_CATEGORY_CD STRING COMMENT '存款业务类别代码'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,MRG_BIZ_CATE_CD STRING COMMENT '保证金业务种类代码'
    ,AGREE_REDT_ACCT_NO STRING COMMENT '约定转存账户编号'
    ,ORIG_DPSIT_TERM STRING COMMENT '原始存款期限'
    ,DPSIT_PERIOD_DAYS BIGINT COMMENT '存期天数'
    ,ALL_IN_ONE_PSBOOK_NO STRING COMMENT '一本通册号'
    ,ALL_IN_ONE_PSBOOK_ACCT_NO STRING COMMENT '一本通账号'
    ,VOCH_NO STRING COMMENT '凭证号码'
    ,MED_TYPE_CD STRING COMMENT '介质类型代码'
    ,REPLOS_STATUS_CD STRING COMMENT '挂失状态代码'
    ,FRZ_STATUS_CD STRING COMMENT '冻结状态代码'
    ,STOP_PAY_STATUS_CD STRING COMMENT '止付状态代码'
    ,AUTO_REDT_IDNT_CD STRING COMMENT '自动转存标识代码'
    ,DRAW_MODE_CD STRING COMMENT '支取方式代码'
    ,AGREE_FLAG STRING COMMENT '协定标志'
    ,PLEDGE_FLAG STRING COMMENT '质押标志'
    ,DEPT_OR_DEFLT_TMS BIGINT COMMENT '部支或违约次数'
    ,OPEN_ACCT_AMT DECIMAL(28,2) COMMENT '开户金额'
    ,YESTD_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,CURR_BAL DECIMAL(28,2) COMMENT '当前余额'
    ,CTRL_AMT DECIMAL(28,2) COMMENT '控制金额'
    ,FRZ_AMT DECIMAL(28,2) COMMENT '冻结金额'
    ,STOP_PAY_AMT DECIMAL(28,2) COMMENT '止付金额'
    ,YESTD_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,INT_FREE_TAX_FLAG STRING COMMENT '豁免利息税标志'
    ,INTACR_MODE_CD STRING COMMENT '计息方式代码'
    ,INTACR_BASE_CD STRING COMMENT '计息基础代码'
    ,OPEN_ACCT_INT_RATE DECIMAL(20,7) COMMENT '开户利率'
    ,FLOT_INT_RATE_PERIOD_CD STRING COMMENT '浮动利率周期代码'
    ,MNYITM_SRC_CD STRING COMMENT '款项来源代码'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,VAL_DT STRING COMMENT '起息日期'
    ,MATU_DT STRING COMMENT '到期日期'
    ,FINAL_TXN_DT STRING COMMENT '最后交易日期'
    ,PAYOFF_DT STRING COMMENT '结清日期'
    ,OPEN_ACCT_CHNL_CD STRING COMMENT '开户渠道代码'
    ,CANC_ACCT_DT STRING COMMENT '销户日期'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,REC_STATUS_CD STRING COMMENT '记录状态代码'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,SETUP_TELR_NO STRING COMMENT '建立柜员编号'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,FINAL_MODIF_TELR_NO STRING COMMENT '最后修改柜员编号'
    ,AB01AC15  STRING COMMENT '关联字段'
    ,PT_DT STRING COMMENT '关联字段'
    ,INDV_CORP_IDNT_CD STRING COMMENT '个人企业标识代码'
    ,MRGACCT_FLAG STRING COMMENT '保证金账户标志'
    ,DPSIT_COMB_PROD_CD STRING COMMENT '存款组合产品代码'
    ,DPSIT_COMB_PROD_NAME STRING COMMENT '存款组合产品名称'
    ,OPEN_ACCT_TELR STRING COMMENT '开户柜员'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '临时表2'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_02(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_TYPE_CD -- 客户类型代码
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,ORIG_DPSIT_TERM -- 原始存款期限
    ,DPSIT_PERIOD_DAYS -- 存期天数
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,VOCH_NO -- 凭证号码
    ,MED_TYPE_CD -- 介质类型代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,AGREE_FLAG -- 协定标志
    ,PLEDGE_FLAG -- 质押标志
    ,DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,OPEN_ACCT_AMT -- 开户金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_BAL -- 当前余额
    ,CTRL_AMT -- 控制金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,INTACR_MODE_CD -- 计息方式代码
    ,INTACR_BASE_CD -- 计息基础代码
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,MNYITM_SRC_CD -- 款项来源代码
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,PAYOFF_DT -- 结清日期
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_DT -- 销户日期
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,AB01AC15  -- 关联字段
    ,PT_DT -- 关联字段
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,OPEN_ACCT_TELR -- 开户柜员
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P2.AB03CCYC AS CURR_CD -- 币种代码
    ,P2.AB05CHSX AS CASH_RMT_CD -- 钞汇代码
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_TYPE_CD AS CUST_TYPE_CD -- 客户类型代码
    ,P1.MAIN_DOCTYP_CD AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P1.MAIN_DOC_NO AS MAIN_DOC_NO -- 主证件号码
    ,P1.OPEN_ACCT_DOCTYP_CD AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.OPEN_ACCT_DOC_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.FX_ACCT_PROPTY_CD AS FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,P2.AB04WBZL AS FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,P1.UNIVERSAL_WITHDR_LVL_CD AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,P1.UNIVERSAL_SAVING_LVL_CD AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,P2.AB06ACFG AS ACCT_TYPE_CD -- 账户类型代码
    ,CASE WHEN P10.BC08ZHTP IS NULL OR TRIM(P10.BC08ZHTP)=''
     THEN ''
     ELSE COALESCE(TRIM(P11.TARGET_CD_VAL), CONCAT('@',TRIM(P10.BC08ZHTP)),'')
END AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN  P2.AB13ACST='2' AND  SUBSTR(P2.AB14NO16,7,1)='1' AND  T2.CB15BDHS<>'3' THEN '5'
     ELSE  P2.AB13ACST
END AS ACCT_STATUS_CD -- 账户状态代码
    ,P2.AB09BUST AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,CONCAT(P2.AB10PDTP,P2.AB11PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,P3.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,P4.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P4.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.MRG_BIZ_CATE_CD AS MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,P1.AGREE_REDT_ACCT_NO AS AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,CAST(P2.AB16SN03 AS STRING) AS ORIG_DPSIT_TERM -- 原始存款期限
    ,CASE WHEN P2.AB10PDTP IN ('17','27') THEN P2.AB16SN03 ELSE P2.AB16SN03*30 END AS DPSIT_PERIOD_DAYS -- 存期天数
    ,CAST(P2.AB06SN03 AS STRING) AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,P5.HJZHAC15 AS ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,P1.VOCH_NO AS VOCH_NO -- 凭证号码
    ,P1.MED_TYPE_CD AS MED_TYPE_CD -- 介质类型代码
    ,P1.REPLOS_STATUS_CD AS REPLOS_STATUS_CD -- 挂失状态代码
    ,CASE WHEN SUBSTR(P2.AB14NO16,2,1)='1' 
     THEN '1' 
     WHEN SUBSTR(P2.AB14NO16,1,1)='1' 
     THEN '3' 
     WHEN SUBSTR(P2.AB44NO02,1,1)='1' 
     THEN '2' 
     ELSE '0' 
END AS FRZ_STATUS_CD -- 冻结状态代码
    ,CASE WHEN SUBSTR(P2.AB14NO16,3,1)='1' 
     THEN '1' 
     WHEN SUBSTR(P2.AB44NO02,2,1)='1' 
     THEN '2' 
     ELSE '0'
END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,CASE WHEN P2.AB42FLAG IS NULL OR TRIM(P2.AB42FLAG)=''
     THEN ''
     ELSE COALESCE(TRIM(P9.TARGET_CD_VAL), CONCAT('@',TRIM(P2.AB42FLAG)),'')
END AS AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,P1.AGREE_FLAG AS AGREE_FLAG -- 协定标志
    ,CASE WHEN SUBSTR(P2.AB14NO16,5,1)='1'
     THEN '1'
     else '0'
end AS PLEDGE_FLAG -- 质押标志
    ,P2.AB29SN03 AS DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,P2.AB19AMT AS OPEN_ACCT_AMT -- 开户金额
    ,P2.AB20BAL AS YESTD_BAL -- 昨日余额
    ,P2.AB22BAL AS CURR_BAL -- 当前余额
    ,P2.AB23AMT AS CTRL_AMT -- 控制金额
    ,P2.AB45AMT AS FRZ_AMT -- 冻结金额
    ,P2.AB46AMT AS STOP_PAY_AMT -- 止付金额
    ,CASE WHEN P2.AB03CCYC <> 'CNY' 
     THEN P2.AB20BAL*P7.YRCAEXRT/P7.YRCACUNO 
     ELSE P2.AB20BAL
END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,P1.INT_FREE_TAX_FLAG AS INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,P2.AB31ICTP AS INTACR_MODE_CD -- 计息方式代码
    ,P6.C2__BSDY AS INTACR_BASE_CD -- 计息基础代码
    ,P2.AB25RATE AS OPEN_ACCT_INT_RATE -- 开户利率
    ,P2.AB27FLTP AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,P1.MNYITM_SRC_CD AS MNYITM_SRC_CD -- 款项来源代码
    ,P1.OPEN_ACCT_DT AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(CAST(P2.AB17DATE AS STRING)) AS VAL_DT -- 起息日期
    ,unifiedTime(CAST(P2.AB18DATE AS STRING)) AS MATU_DT -- 到期日期
    ,unifiedTime(CAST(P2.AB30DATE AS STRING)) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(CAST(P2.AB34DATE AS STRING)) AS PAYOFF_DT -- 结清日期
    ,CASE WHEN P10.BC35CNCD = 'CC' THEN 'IC' ELSE P10.BC35CNCD END AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,P1.CANC_ACCT_DT AS CANC_ACCT_DT -- 销户日期
    ,P2.AB33BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.AB35BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN P2.RCSTRS1B=''OR P2.RCSTRS1B IS NULL THEN '0' ELSE P2.RCSTRS1B END AS REC_STATUS_CD -- 记录状态代码
    ,unifiedTime(CAST(P2.BUDIDATE AS STRING)) AS SETUP_DT -- 建立日期
    ,unifiedTime(CAST(P2.BUTSSTAM AS STRING)) AS SETUP_TM_STAMP -- 建立时间戳
    ,P2.BUTPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(CAST(P2.UPDTDATE AS STRING)) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(CAST(P2.UPTSSTAM AS STRING)) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P2.UPOPSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P2.AB01AC15 AS AB01AC15  -- 关联字段
    ,P2.PT_DT AS PT_DT -- 关联字段
    ,P1.INDV_CORP_IDNT_CD AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,P1.MRGACCT_FLAG AS MRGACCT_FLAG -- 保证金账户标志
    ,P1.DPSIT_COMB_PROD_CD AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,P1.DPSIT_COMB_PROD_NAME AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P10.BC34STAF AS OPEN_ACCT_TELR -- 开户柜员
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_01 AS P1 -- 临时表1

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAB_TF AS P2 -- 定期模块账户分户余额信息
       ON P1.ACCT_NO = P2.AB01AC15 AND P2.DEL_F='0' AND P2.PT_DT = '${process_date}' 
LEFT JOIN (SELECT CB01AC22,CB15BDHS FROM  ODS_CORE${version_num}.ODS_CORE_BDFMHQCB_TF WHERE DEL_F='0' AND PT_DT = '${process_date}') AS T2 -- None
       ON P1.ACCT_NO = T2.CB01AC22 
LEFT JOIN (
SELECT
    P3.CW02PDTP 
   ,P3.CW03PRON
   ,P3.CW05FLNM 
   ,ROW_NUMBER()OVER(PARTITION BY CW03PRON,CW02PDTP ORDER BY CW05FLNM ) RN
FROM ODS_CORE${version_num}.ODS_CORE_BDFMHQCW_TF P3
where P3.PT_DT = '${process_date}' AND P3.DEL_F='0'
) AS P3 -- 产品代码名称表
       ON P3.CW03PRON = P2.AB11PRON  AND P3.CW02PDTP = P2.AB10PDTP AND P3.RN=1 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS P4 -- 新会计科目核算码对照表
       ON P2.AB12ACID = P4.KHDBACID AND P4.DEL_F='0' AND P4.PT_DT = '${process_date}' 
LEFT JOIN ( 
SELECT  STZHAC15,HJZHAC15  
FROM(
  SELECT  STZHAC15,HJZHAC15,ROW_NUMBER()OVER(PARTITION BY STZHAC15 ORDER BY HJZHAC15 DESC) RN
  FROM ODS_CORE${version_num}.ODS_CORE_BFFMDQBG_TF 
  WHERE DEL_F='0' AND ZHZTACST<>'2'  AND PT_DT = '${process_date}'  
    )
WHERE RN=1
) AS P5 -- 定期一本通账户明细表
       ON P2.AB01AC15 = P5.STZHAC15 
LEFT JOIN (
SELECT
   MAX(C2__BSDY) AS C2__BSDY
  ,C2__PRON
  ,C2__PDTP
  ,C2__CCYC
FROM ODS_CORE${version_num}.ODS_CORE_BIFCPCCT_TF
WHERE PT_DT = '${process_date}' AND DEL_F='0'
GROUP BY C2__PRON,C2__PDTP,C2__CCYC
) AS P6 -- 产品/币种/利息种类控制定义表
       ON P2.AB11PRON = P6.C2__PRON AND P2.AB10PDTP=P6.C2__PDTP AND P2.AB03CCYC=P6.C2__CCYC 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P7 -- 年度报表汇率文件
       ON P2.AB03CCYC = P7.YRCACCYC 
AND CAST(P7.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日
AND P7.YRCARS1B <> '9'
AND P7.DEL_F='0'
AND P7.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P9 -- 代码转换
       ON P2.AB42FLAG=P9.SRC_CD_VAL  
AND P9.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND P9.SRC_TAB_EN_NAME='BFFMDQAB' --来源表英文名  
AND P9.SRC_FIELD_EN_NAME='AB42FLAG' --来源字段英文名 
AND P9.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P9.TARGET_FIELD_EN_NAME='AUTO_REDT_IDNT_CD' --目标字段 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBC_TF AS P10 -- 开户登记簿
       ON TRIM(P10.BC01AC22) = TRIM(P2.AB01AC15)  
AND TRIM(P10.BC03CCYC) = TRIM(P2.AB03CCYC) 
AND TRIM(P10.BC04CHSX) = TRIM(P2.AB05CHSX) 
AND TRIM(P2.AB32DATE)= TRIM(P10.BC31DATE) 
AND P10.DEL_F='0'  
AND P10.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P11 -- 代码转换
       ON P10.BC08ZHTP=P11.SRC_CD_VAL  
AND P11.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND P11.SRC_TAB_EN_NAME='BDFMHQBC' --来源表英文名  
AND P11.SRC_FIELD_EN_NAME='BC08ZHTP' --来源字段英文名 
AND P11.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P11.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
;
-- ==============聚合层字段映射（第1-3组）==============
-- 个人定期存款账户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_TYPE_CD -- 客户类型代码
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,ORIG_DPSIT_TERM -- 原始存款期限
    ,DPSIT_PERIOD_DAYS -- 存期天数
    ,EACCT_NO -- 电子账户编号
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,VOCH_NO -- 凭证号码
    ,MED_TYPE_CD -- 介质类型代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,AGREE_FLAG -- 协定标志
    ,PLEDGE_FLAG -- 质押标志
    ,DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,OPEN_ACCT_AMT -- 开户金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_BAL -- 当前余额
    ,CTRL_AMT -- 控制金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,INTACR_MODE_CD -- 计息方式代码
    ,INTACR_BASE_CD -- 计息基础代码
    ,INT_TAX -- 利息税
    ,INT_TXBL_AMT -- 利息应税金额
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,BNCHMK_INT_RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,MNYITM_SRC_CD -- 款项来源代码
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,PAYOFF_DT -- 结清日期
    ,NEXT_CAN_DRAW_DT -- 下次可支取日期
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,REDT_FLAG -- 转存标志
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,OPEN_ACCT_TELR -- 开户柜员
    ,EACCT_BIND_CARD_NO -- 电子账户绑定卡号
    ,OPEN_ACCT_TM -- 开户时间
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_TYPE_CD AS CUST_TYPE_CD -- 客户类型代码
    ,P1.MAIN_DOCTYP_CD AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P1.MAIN_DOC_NO AS MAIN_DOC_NO -- 主证件号码
    ,P1.OPEN_ACCT_DOCTYP_CD AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.OPEN_ACCT_DOC_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.FX_ACCT_PROPTY_CD AS FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,P1.FX_CUST_TYPE_CD AS FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,P1.UNIVERSAL_WITHDR_LVL_CD AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,P1.UNIVERSAL_SAVING_LVL_CD AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,P1.ACCT_TYPE_CD AS ACCT_TYPE_CD -- 账户类型代码
    ,P1.ACCT_PROPTY_CD AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.ACCT_STATUS_CD AS ACCT_STATUS_CD -- 账户状态代码
    ,P1.DPSIT_BIZ_CATEGORY_CD AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P1.DPSIT_PROD_NAME AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.ACCTN_SUBJ_NO AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.ACCTN_SUBJ_NAME AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.MRG_BIZ_CATE_CD AS MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,P1.AGREE_REDT_ACCT_NO AS AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,P1.ORIG_DPSIT_TERM AS ORIG_DPSIT_TERM -- 原始存款期限
    ,P1.DPSIT_PERIOD_DAYS AS DPSIT_PERIOD_DAYS -- 存期天数
    ,'' AS EACCT_NO -- 电子账户编号
    ,'' AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,'' AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,P1.ALL_IN_ONE_PSBOOK_NO AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,P1.ALL_IN_ONE_PSBOOK_ACCT_NO AS ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,P1.VOCH_NO AS VOCH_NO -- 凭证号码
    ,P1.MED_TYPE_CD AS MED_TYPE_CD -- 介质类型代码
    ,P1.REPLOS_STATUS_CD AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P1.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,P1.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P1.AUTO_REDT_IDNT_CD AS AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,P1.AGREE_FLAG AS AGREE_FLAG -- 协定标志
    ,P1.PLEDGE_FLAG AS PLEDGE_FLAG -- 质押标志
    ,P1.DEPT_OR_DEFLT_TMS AS DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,P1.OPEN_ACCT_AMT AS OPEN_ACCT_AMT -- 开户金额
    ,P1.YESTD_BAL AS YESTD_BAL -- 昨日余额
    ,P1.CURR_BAL AS CURR_BAL -- 当前余额
    ,P1.CTRL_AMT AS CTRL_AMT -- 控制金额
    ,P1.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,P1.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','MM') AS STRING )  THEN  COALESCE(P1.YESTD_BAL,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM,0) + COALESCE(P1.YESTD_BAL,0) END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','quarter') AS STRING )  THEN  COALESCE(P1.YESTD_BAL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM,0) + COALESCE(P1.YESTD_BAL,0) END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','YY') AS STRING )  THEN  COALESCE(P1.YESTD_BAL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM,0) + COALESCE(P1.YESTD_BAL,0) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,P1.YESTD_BAL_CONVT_RMB AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','MM') AS STRING )  THEN  COALESCE(P1.YESTD_BAL_CONVT_RMB,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + COALESCE(P1.YESTD_BAL_CONVT_RMB,0) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','quarter') AS STRING )  THEN  COALESCE(P1.YESTD_BAL_CONVT_RMB,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + COALESCE(P1.YESTD_BAL_CONVT_RMB,0) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','YY') AS STRING )  THEN  COALESCE(P1.YESTD_BAL_CONVT_RMB,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + COALESCE(P1.YESTD_BAL_CONVT_RMB,0) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','YY') AS STRING )  THEN  COALESCE(P2.MGYSAMT,0)  --当为年初时，取当日余额
ELSE COALESCE(S1.ACTL_INT_AMT_YEAR_CUM,0)+ COALESCE(P2.MGYSAMT,0) END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,P1.INT_FREE_TAX_FLAG AS INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,P1.INTACR_MODE_CD AS INTACR_MODE_CD -- 计息方式代码
    ,P1.INTACR_BASE_CD AS INTACR_BASE_CD -- 计息基础代码
    ,P2.MGTXAMT AS INT_TAX -- 利息税
    ,P2.MGYSAMT AS INT_TXBL_AMT -- 利息应税金额
    ,P1.OPEN_ACCT_INT_RATE AS OPEN_ACCT_INT_RATE -- 开户利率
    ,P4.D1__RATE AS BNCHMK_INT_RATE -- 基准利率
    ,CASE WHEN P3.D2__RATE<>0 
     THEN P4.D1__RATE+P3.D2__RATE 
     WHEN P3.D2__RTIO<>0 
     THEN P4.D1__RATE*(P3.D2__RTIO/100+1) 
     ELSE 0 
END AS FLOT_INT_RATE -- 浮动利率
    ,P1.FLOT_INT_RATE_PERIOD_CD AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,CASE WHEN P3.D2__RATE<>0 
     THEN '2' 
     WHEN P3.D2__RTIO<>0 
     THEN '1' 
     ELSE '0'
END AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,P1.MNYITM_SRC_CD AS MNYITM_SRC_CD -- 款项来源代码
    ,unifiedTime(P1.OPEN_ACCT_DT) AS OPEN_ACCT_DT -- 开户日期
    ,P1.VAL_DT AS VAL_DT -- 起息日期
    ,P1.MATU_DT AS MATU_DT -- 到期日期
    ,P1.FINAL_TXN_DT AS FINAL_TXN_DT -- 最后交易日期
    ,P1.PAYOFF_DT AS PAYOFF_DT -- 结清日期
    ,unifiedTime(CAST(P5.AO10DATE AS STRING)) AS NEXT_CAN_DRAW_DT -- 下次可支取日期
    ,P1.OPEN_ACCT_CHNL_CD AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,unifiedTime(P1.CANC_ACCT_DT) AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN P6.BQ09CNCD = 'CC' THEN 'IC' ELSE P6.BQ09CNCD END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,P6.BQ07BRNO AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,P6.BQ08STAF AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,P1.STAT_ORG_NO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,P1.REC_STATUS_CD AS REC_STATUS_CD -- 记录状态代码
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.SETUP_TELR_NO AS SETUP_TELR_NO -- 建立柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_MODIF_TM_STAMP AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS REDT_FLAG -- 转存标志
    ,P1.INDV_CORP_IDNT_CD AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,P1.MRGACCT_FLAG AS MRGACCT_FLAG -- 保证金账户标志
    ,P1.DPSIT_COMB_PROD_CD AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,P1.DPSIT_COMB_PROD_NAME AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P1.OPEN_ACCT_TELR AS OPEN_ACCT_TELR -- 开户柜员
    ,'' AS EACCT_BIND_CARD_NO -- 电子账户绑定卡号
    ,'' AS OPEN_ACCT_TM -- 开户时间
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BFFMDQAA_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_02 AS P1 -- 临时表2

LEFT JOIN (
 select
     TRIM(MG__AC22) AS MG__AC22
    ,MG__DATE
    ,SUM(MGTXAMT) AS MGTXAMT
    ,SUM(MGYSAMT) AS MGYSAMT
  FROM ODS_CORE${version_num}.ODS_CORE_BIFMLXDJ_TF  --账户利息登记簿
  WHERE CAST(MG__DATE AS STRING) =REPLACE('${process_date}','-','')  
     AND RCSTRS1B NOT IN ('1','9') 
     AND DEL_F='0' AND PT_DT='${process_date}'
  GROUP BY TRIM(MG__AC22),MG__DATE
) AS P2 -- 账户利息登记簿
       ON P1.ACCT_NO = P2.MG__AC22 
LEFT JOIN (
SELECT 
   MAX(D2__RATE)  AS D2__RATE
  ,MAX(D2__RTIO)  AS D2__RTIO
  ,TRIM(D2__PRON) AS D2__PRON
  ,TRIM(D2__PDTP) AS D2__PDTP
  ,TRIM(D2__BKNO) AS D2__BKNO
  ,TRIM(D2__CCYC) AS D2__CCYC
  ,TRIM(D2__TRCD) AS D2__TRCD
  ,TRIM(D2__BIRC) AS D2__BIRC
FROM ODS_CORE${version_num}.ODS_CORE_BIFDPDIR_TF 
WHERE D2LSDATE =18991231 AND TRIM(D2__BIRC)<>'' AND DEL_F='0' AND PT_DT = '${process_date}'
GROUP BY TRIM(D2__PRON),TRIM(D2__PDTP),TRIM(D2__BKNO) ,TRIM(D2__CCYC) ,TRIM(D2__TRCD),TRIM(D2__BIRC)
) AS P3 -- 银行/分行基本利率表
       ON P1.DPSIT_PROD_CD = CONCAT(P3.D2__PDTP,P3.D2__PRON)
AND SUBSTR(P1.LP_ORG_NO,1,3) = P3.D2__BKNO
AND P3.D2__CCYC = P1.CURR_CD  AND P1.ORIG_DPSIT_TERM =P3.D2__TRCD  
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BIFDBRIR_TF AS P4 -- 分行产品利率表
       ON P4.D1__BIRC = P3.D2__BIRC
AND P4.D1__CCYC = P1.CURR_CD
AND P4.D1LSDATE = 18991231 AND P4.DEL_F='0' AND P4.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFTDQAO_TF AS P5 -- 分户补充信息
       ON P1.ACCT_NO = P5.AO01AC15 AND P5.DEL_F='0' AND P5.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBQ_TF AS P6 -- 销户登记薄
       ON TRIM(P6.BQ05AC15)= TRIM(P1.AB01AC15) 
AND TRIM(P6.BQ04CHSX) = TRIM(P1.CASH_RMT_CD)   
AND TRIM(P6.BQ03CCYC)  =TRIM(P1.CURR_CD) 
AND TRIM(P6.BQ06DATE)=TRIM(P1.CANC_ACCT_DT) 
AND P6.DEL_F='0' AND P6.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT
    T1.ACCT_NO
   ,T1.CURR_CD
   ,T1.CASH_RMT_CD
   ,T1.YESTD_BAL_MONTH_ACCUM
   ,T1.YESTD_BAL_QUAR_ACCUM
   ,T1.YESTD_BAL_YEAR_ACCUM
   ,T1.ACTL_INT_AMT_YEAR_CUM
   ,T1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
   ,T1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
   ,T1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF  T1
WHERE T1.PT_DT = CAST(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND T1.SRC_SYS_CD='CORE' AND T1.DEL_F='0'
) AS S1 -- 个人定期存款账户信息聚合上日积数
       ON COALESCE(P1.ACCT_NO,'') = COALESCE(S1.ACCT_NO,'') 
AND COALESCE(P1.CURR_CD,'') = COALESCE(S1.CURR_CD,'') 
AND COALESCE(P1.CASH_RMT_CD,'') = COALESCE(S1.CASH_RMT_CD,'') 
;
-- ==============聚合层字段映射（第2-1组）==============
-- 临时表3
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_03;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_03 (
     ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,MAIN_DOCTYP_CD STRING COMMENT '主证件类型代码'
    ,MAIN_DOC_NO STRING COMMENT '主证件号码'
    ,OPEN_ACCT_DOCTYP_CD STRING COMMENT '开户证件类型代码'
    ,OPEN_ACCT_DOC_NO STRING COMMENT '开户证件号码'
    ,ACCT_TYPE_CD STRING COMMENT '账户类型代码'
    ,ACCT_PROPTY_CD STRING COMMENT '账户性质代码'
    ,ACCT_STATUS_CD STRING COMMENT '账户状态代码'
    ,DPSIT_BIZ_CATEGORY_CD STRING COMMENT '存款业务类别代码'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,ORIG_DPSIT_TERM STRING COMMENT '原始存款期限'
    ,DPSIT_PERIOD_DAYS BIGINT COMMENT '存期天数'
    ,EACCT_NO STRING COMMENT '电子账户编号'
    ,OPEN_ACCT_AMT DECIMAL(28,2) COMMENT '开户金额'
    ,YESTD_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,CURR_BAL DECIMAL(28,2) COMMENT '当前余额'
    ,YESTD_BAL_MONTH_ACCUM DECIMAL(28,2) COMMENT '昨日余额月积数'
    ,YESTD_BAL_QUAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额季积数'
    ,YESTD_BAL_YEAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额年积数'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,VAL_DT STRING COMMENT '起息日期'
    ,MATU_DT STRING COMMENT '到期日期'
    ,FINAL_TXN_DT STRING COMMENT '最后交易日期'
    ,PAYOFF_DT STRING COMMENT '结清日期'
    ,CANC_ACCT_DT STRING COMMENT '销户日期'
    ,CANC_ACCT_CHNL STRING COMMENT '销户渠道代码'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,DCMTNO STRING COMMENT '关联字段'
    ,PT_DT STRING COMMENT '关联字段'
    ,LASTBL DECIMAL(28,2) COMMENT '关联字段'
    ,CORPNO STRING COMMENT '关联字段'
    ,OPEN_ACCT_CHNL_CD STRING COMMENT '开户渠道代码'
    ,ELEC_LIACCT_PROPTY_CD STRING COMMENT '电子负债账户性质代码'
    ,ELEC_LIACCT_TYPE_CD STRING COMMENT '电子负债账户类型代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '临时表3'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_03(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,ORIG_DPSIT_TERM -- 原始存款期限
    ,DPSIT_PERIOD_DAYS -- 存期天数
    ,EACCT_NO -- 电子账户编号
    ,OPEN_ACCT_AMT -- 开户金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,DCMTNO -- 关联字段
    ,PT_DT -- 关联字段
    ,LASTBL -- 关联字段
    ,CORPNO -- 关联字段
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCTNO AS ACCT_NO -- 账户编号
    ,P1.ACCTNA AS ACCT_NAME -- 账户名称
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TRIM(T2.CUST_INNER_ID)<>'' THEN TRIM(T2.CUST_INNER_ID) ELSE P2.CUSTCD END AS CUST_IN_CD -- 客户内码
    ,P2.CUSTID AS USER_ID -- 用户ID
    ,P3.CUST_NM AS CUST_NAME -- 客户名称
    ,P4.CRTF_TYP AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P4.CRTF_NO AS MAIN_DOC_NO -- 主证件号码
    ,P5.IDTFTP AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P5.IDTFNO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CASE WHEN P1.ACSETP IS NULL OR TRIM(P1.ACSETP)=''
     THEN ''
     ELSE COALESCE(TRIM(P9.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACSETP)),'')
END AS ACCT_TYPE_CD -- 账户类型代码
    ,CASE WHEN P1.SPECTP IS NULL OR TRIM(P1.SPECTP)=''
     THEN ''
     ELSE COALESCE(TRIM(P10.TARGET_CD_VAL), CONCAT('@',TRIM(P1.SPECTP)),'')
END AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN P1.ACCTST IS NULL OR TRIM(P1.ACCTST)=''
     THEN ''
     ELSE COALESCE(TRIM(P12.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACCTST)),'')
END AS ACCT_STATUS_CD -- 账户状态代码
    ,CASE WHEN P1.DEBTTP IS NULL OR TRIM(P1.DEBTTP)=''
     THEN ''
     ELSE COALESCE(TRIM(P11.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DEBTTP)),'')
END AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,P6.PRODTX AS DPSIT_PROD_NAME -- 存款产品名称
    ,P7.SUBJECT AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P7.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.DEPTTM AS ORIG_DPSIT_TERM -- 原始存款期限
    ,CASE WHEN SUBSTR(P1.DEPTTM,1,1)='0' THEN '000' 
     WHEN SUBSTR(P1.DEPTTM,1,1)='1' AND P1.DEPTTM<>'114' THEN SUBSTR(P1.DEPTTM,-1,1) 
     WHEN SUBSTR(P1.DEPTTM,1,1)='2' THEN SUBSTR(P1.DEPTTM,-1,1)*30
     WHEN SUBSTR(P1.DEPTTM,1,1)='3' THEN SUBSTR(P1.DEPTTM,-1,1)*365
     WHEN P1.DEPTTM='114' THEN P1.DEPTTM
     WHEN P1.DEPTTM='330' THEN 30*365
     WHEN P1.DEPTTM='901' THEN P1.DEPTDY
     WHEN P1.DEPTTM='902' THEN P1.DEPTDY*30
     WHEN P1.DEPTTM='903' THEN P1.DEPTDY*365
END AS DPSIT_PERIOD_DAYS -- 存期天数
    ,P1.CUSTAC AS EACCT_NO -- 电子账户编号
    ,P1.OPMONY AS OPEN_ACCT_AMT -- 开户金额
    ,CASE WHEN P1.UPBLDT<=REPLACE('${process_date}','-') OR P1.UPBLDT IS NULL THEN P1.ONLNBL ELSE P1.LASTBL END AS YESTD_BAL -- 昨日余额
    ,P1.ONLNBL AS CURR_BAL -- 当前余额
    ,CASE WHEN P1.UPBLDT<=REPLACE('${process_date}','-') OR P1.UPBLDT IS NULL THEN P1.ONLNBL ELSE P1.LASTBL END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN P1.UPBLDT<=REPLACE('${process_date}','-') OR P1.UPBLDT IS NULL THEN P1.ONLNBL ELSE P1.LASTBL END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN P1.UPBLDT<=REPLACE('${process_date}','-') OR P1.UPBLDT IS NULL THEN P1.ONLNBL ELSE P1.LASTBL END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,unifiedTime(P1.OPENDT) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P1.BGINDT) AS VAL_DT -- 起息日期
    ,unifiedTime(COALESCE(TRIM(P1.MATUDT),TRIM(T8.CNCLDT),T8.EFFEDT)) AS MATU_DT -- 到期日期
    ,unifiedTime(P1.LSTRDT) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(P1.MATUDT) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(P1.CLOSDT) AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN P1.ACCTST = '2' THEN 'NM' ELSE '' END  AS CANC_ACCT_CHNL -- 销户渠道代码
    ,P1.BRCHNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.BRCHNO AS LP_ORG_NO -- 法人机构编号
    ,unifiedTime(SUBSTR(P1.TIMETM,1,8)) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.TIMETM) AS SETUP_TM_STAMP -- 建立时间戳
    ,unifiedTime(SUBSTR(P1.TIMETM,1,8)) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P8.DCMTNO AS DCMTNO -- 关联字段
    ,P1.PT_DT AS PT_DT -- 关联字段
    ,P1.LASTBL AS LASTBL -- 关联字段
    ,P1.CORPNO AS CORPNO -- 关联字段
    ,CASE WHEN P1.ACSETP IN ('01','02','03','04') THEN 'NM' ELSE 'TE' END AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,P1.SPECTP AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,P1.ACSETP AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS${version_num}.ODS_NAS_KNA_FXAC_TF AS P1 -- 定期负债账户表

LEFT JOIN (SELECT * FROM(
SELECT
  CUSTNO
 ,CUSTID
 ,CUSTCD
 ,ROW_NUMBER() OVER (PARTITION BY CUSTNO ORDER BY STATUS) AS RN
FROM ODS_NAS${version_num}.ODS_NAS_CIF_CUST_ACCS_TF
WHERE DEL_F='0' AND PT_DT= '${process_date}'
)WHERE RN=1) AS P2 -- 客户信息关联表
       ON P1.CUSTNO = P2.CUSTNO 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_U_USER_INNER_BAS_TF AS T2 -- 客户基础信息表
       ON T2.USER_ID=P2.CUSTID AND T2.DEL_F='0' AND T2.PT_DT='${process_date}' 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF AS P3 -- 客户基础信息表
       ON P2.CUSTCD = P3.CST_IN_CD AND P3.DEL_F='0' AND P3.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT
   CRTF_TYP
  ,CRTF_NO
  ,CST_IN_CD
FROM(
  SELECT 
     CRTF_TYP
    ,CRTF_NO
    ,CST_IN_CD
    ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC) AS RN
  FROM  ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF
  WHERE MAJOR_FLG='1' AND DELETED ='0' AND DEL_F='0' AND PT_DT = '${process_date}'
   )
WHERE RN=1
) AS P4 -- 客户证件信息表
       ON P2.CUSTCD = P4.CST_IN_CD 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_CUST_TF AS P5 -- 电子账户表
       ON p1.CUSTAC = p5.CUSTAC AND P5.DEL_F='0' AND P5.PT_DT = '${process_date}' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KUP_DPPB_TF AS P6 -- NAS产品表
       ON P1.PRODCD = P6.prodcd AND P6.DEL_F='0' AND P6.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT  T1.PRODUCT
       ,T1.SUBJECT
       ,T2.DESCRIPTION
FROM 
    (
     SELECT  EVENT_TYPE
            ,PRODUCT
            ,CASE WHEN SUBJECT_DR<>'' AND SUBJECT_DR <> '30410310' 
                  THEN SUBJECT_DR 
                  ELSE SUBJECT_CR
             END       SUBJECT
      FROM  ODS_GAS${version_num}.ODS_GAS_CUX_EA_RULES_TF 
      WHERE SUBSTR(EVENT_TYPE,1,1) = '1' 
      AND DEL_F='0'
      AND   PT_DT = '${process_date}' 
  ) T1
LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_FLEX_VALUES_V_TF T2
ON        T2.FLEX_VALUE = T1.SUBJECT
AND       T2.PT_DT = '${process_date}'  AND T2.DEL_F='0'
GROUP BY  T1.PRODUCT
         ,T1.SUBJECT
         ,T2.DESCRIPTION
) AS P7 -- None
       ON P1.ACCTCD = p7.PRODUCT 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNB_DCMT_TF AS P8 -- 凭证登记簿
       ON P1.ACCTNO = P8.ACCTNO and p8.del_f='0' AND P8.PT_DT = '${process_date}' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_SIGN_DETL_TF AS T8 -- None
       ON TRIM(P1.ACCTNO)=TRIM(T8.FXACCT) AND T8.DEL_F='0' AND T8.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P9 -- 代码转换
       ON P1.ACSETP=P9.SRC_CD_VAL  
AND P9.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P9.SRC_TAB_EN_NAME='KNA_FXAC' --来源表英文名  
AND P9.SRC_FIELD_EN_NAME='ACSETP' --来源字段英文名 
AND P9.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P9.TARGET_FIELD_EN_NAME='ACCT_TYPE_CD' --目标字段 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P10 -- 代码转换
       ON P1.SPECTP=P10.SRC_CD_VAL  
AND P10.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P10.SRC_TAB_EN_NAME='KNA_FXAC' --来源表英文名  
AND P10.SRC_FIELD_EN_NAME='SPECTP' --来源字段英文名 
AND P10.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P10.TARGET_FIELD_EN_NAME='ACCT_PROPTY_CD' --目标字段 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P11 -- 代码转换
       ON P1.DEBTTP=P11.SRC_CD_VAL  
AND P11.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P11.SRC_TAB_EN_NAME='KNA_FXAC' --来源表英文名  
AND P11.SRC_FIELD_EN_NAME='DEBTTP' --来源字段英文名 
AND P11.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P11.TARGET_FIELD_EN_NAME='DPSIT_BIZ_CATEGORY_CD' --目标字段 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P12 -- 代码转换
       ON P1.ACCTST=P12.SRC_CD_VAL  
AND P12.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P12.SRC_TAB_EN_NAME='KNA_FXAC' --来源表英文名  
AND P12.SRC_FIELD_EN_NAME='ACCTST' --来源字段英文名 
AND P12.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P12.TARGET_FIELD_EN_NAME='ACCT_STATUS_CD' --目标字段 
WHERE P1.pddpfg IN ('0205','0204') AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2-2组）==============
-- 临时表4
DROP TABLE IF EXISTS AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_04;

CREATE TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_04 (
     ACCT_NO STRING COMMENT '账户编号'
    ,ACCT_NAME STRING COMMENT '账户名称'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,CUST_IN_CD STRING COMMENT '客户内码'
    ,USER_ID STRING COMMENT '用户ID'
    ,CUST_NAME STRING COMMENT '客户名称'
    ,MAIN_DOCTYP_CD STRING COMMENT '主证件类型代码'
    ,MAIN_DOC_NO STRING COMMENT '主证件号码'
    ,OPEN_ACCT_DOCTYP_CD STRING COMMENT '开户证件类型代码'
    ,OPEN_ACCT_DOC_NO STRING COMMENT '开户证件号码'
    ,ACCT_TYPE_CD STRING COMMENT '账户类型代码'
    ,ACCT_PROPTY_CD STRING COMMENT '账户性质代码'
    ,ACCT_STATUS_CD STRING COMMENT '账户状态代码'
    ,DPSIT_BIZ_CATEGORY_CD STRING COMMENT '存款业务类别代码'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,DPSIT_PROD_NAME STRING COMMENT '存款产品名称'
    ,ACCTN_SUBJ_NO STRING COMMENT '会计科目编号'
    ,ACCTN_SUBJ_NAME STRING COMMENT '会计科目名称'
    ,ORIG_DPSIT_TERM STRING COMMENT '原始存款期限'
    ,DPSIT_PERIOD_DAYS BIGINT COMMENT '存期天数'
    ,EACCT_NO STRING COMMENT '电子账户编号'
    ,VOCH_NO STRING COMMENT '凭证号码'
    ,REPLOS_STATUS_CD STRING COMMENT '挂失状态代码'
    ,FRZ_STATUS_CD STRING COMMENT '冻结状态代码'
    ,STOP_PAY_STATUS_CD STRING COMMENT '止付状态代码'
    ,AUTO_REDT_IDNT_CD STRING COMMENT '自动转存标识代码'
    ,DRAW_MODE_CD STRING COMMENT '支取方式代码'
    ,OPEN_ACCT_AMT DECIMAL(28,2) COMMENT '开户金额'
    ,YESTD_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,CURR_BAL DECIMAL(28,2) COMMENT '当前余额'
    ,FRZ_AMT DECIMAL(28,2) COMMENT '冻结金额'
    ,STOP_PAY_AMT DECIMAL(28,2) COMMENT '止付金额'
    ,YESTD_BAL_MONTH_ACCUM DECIMAL(28,2) COMMENT '昨日余额月积数'
    ,YESTD_BAL_QUAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额季积数'
    ,YESTD_BAL_YEAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额年积数'
    ,YESTD_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,OPEN_ACCT_DT STRING COMMENT '开户日期'
    ,VAL_DT STRING COMMENT '起息日期'
    ,MATU_DT STRING COMMENT '到期日期'
    ,FINAL_TXN_DT STRING COMMENT '最后交易日期'
    ,PAYOFF_DT STRING COMMENT '结清日期'
    ,CANC_ACCT_DT STRING COMMENT '销户日期'
    ,CANC_ACCT_CHNL STRING COMMENT '销户渠道代码'
    ,STAT_ORG_NO STRING COMMENT '统计机构编号'
    ,BELONG_ORG_NO STRING COMMENT '归属机构编号'
    ,LP_ORG_NO STRING COMMENT '法人机构编号'
    ,SETUP_DT STRING COMMENT '建立日期'
    ,SETUP_TM_STAMP STRING COMMENT '建立时间戳'
    ,FINAL_MODIF_DT STRING COMMENT '最后修改日期'
    ,FINAL_MODIF_TM_STAMP STRING COMMENT '最后修改时间戳'
    ,REDT_FLAG STRING COMMENT '转存标志'
    ,PT_DT STRING COMMENT '关联字段'
    ,LASTBL DECIMAL(28,2) COMMENT '关联字段'
    ,CORPNO STRING COMMENT '关联字段'
    ,OPEN_ACCT_CHNL_CD STRING COMMENT '开户渠道代码'
    ,ELEC_LIACCT_PROPTY_CD STRING COMMENT '电子负债账户性质代码'
    ,ELEC_LIACCT_TYPE_CD STRING COMMENT '电子负债账户类型代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '临时表4'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_04(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,ORIG_DPSIT_TERM -- 原始存款期限
    ,DPSIT_PERIOD_DAYS -- 存期天数
    ,EACCT_NO -- 电子账户编号
    ,VOCH_NO -- 凭证号码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,OPEN_ACCT_AMT -- 开户金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_BAL -- 当前余额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,REDT_FLAG -- 转存标志
    ,PT_DT -- 关联字段
    ,LASTBL -- 关联字段
    ,CORPNO -- 关联字段
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.MAIN_DOCTYP_CD AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P1.MAIN_DOC_NO AS MAIN_DOC_NO -- 主证件号码
    ,P1.OPEN_ACCT_DOCTYP_CD AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.OPEN_ACCT_DOC_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.ACCT_TYPE_CD AS ACCT_TYPE_CD -- 账户类型代码
    ,P1.ACCT_PROPTY_CD AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.ACCT_STATUS_CD AS ACCT_STATUS_CD -- 账户状态代码
    ,P1.DPSIT_BIZ_CATEGORY_CD AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P1.DPSIT_PROD_NAME AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.ACCTN_SUBJ_NO AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.ACCTN_SUBJ_NAME AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.ORIG_DPSIT_TERM AS ORIG_DPSIT_TERM -- 原始存款期限
    ,P1.DPSIT_PERIOD_DAYS AS DPSIT_PERIOD_DAYS -- 存期天数
    ,P1.EACCT_NO AS EACCT_NO -- 电子账户编号
    ,coalesce(P1.DCMTNO,CASE WHEN P6.ACCTST = '1' THEN P6.CARDNO WHEN P6.ACCTST = '0' AND SUBSTR(P2.CARDNO,1,6) ='623540' THEN P2.CARDNO ELSE '' END) AS VOCH_NO -- 凭证号码
    ,case when P3.rplstp='1'  THEN '6'
     when P3.rplstp='2'  THEN '8' 
     else '1' 
end AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P4.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,P4.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,CASE WHEN P5.TRSVTP IS NULL OR TRIM(P5.TRSVTP)=''
     THEN ''
     ELSE COALESCE(TRIM(P10.TARGET_CD_VAL), CONCAT('@',TRIM(P5.TRSVTP)),'')
END AS AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,case when P6.drawty='1' THEN '2' else '3' end  AS DRAW_MODE_CD -- 支取方式代码
    ,P1.OPEN_ACCT_AMT AS OPEN_ACCT_AMT -- 开户金额
    ,P1.YESTD_BAL AS YESTD_BAL -- 昨日余额
    ,P1.CURR_BAL AS CURR_BAL -- 当前余额
    ,P4.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,P4.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,P1.YESTD_BAL_MONTH_ACCUM AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,P1.YESTD_BAL_QUAR_ACCUM AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,P1.YESTD_BAL_YEAR_ACCUM AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CASE WHEN P1.CURR_CD <> 'CNY' 
     THEN P1.YESTD_BAL*P9.YRCAEXRT/P9.YRCACUNO 
     ELSE P1.YESTD_BAL
END  AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,P1.OPEN_ACCT_DT AS OPEN_ACCT_DT -- 开户日期
    ,P1.VAL_DT AS VAL_DT -- 起息日期
    ,P1.MATU_DT AS MATU_DT -- 到期日期
    ,P1.FINAL_TXN_DT AS FINAL_TXN_DT -- 最后交易日期
    ,P1.PAYOFF_DT AS PAYOFF_DT -- 结清日期
    ,P1.CANC_ACCT_DT AS CANC_ACCT_DT -- 销户日期
    ,P1.CANC_ACCT_CHNL AS CANC_ACCT_CHNL -- 销户渠道代码
    ,P1.STAT_ORG_NO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_MODIF_TM_STAMP AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P5.TRDPFG AS REDT_FLAG -- 转存标志
    ,P1.PT_DT AS PT_DT -- 关联字段
    ,P1.LASTBL AS LASTBL -- 关联字段
    ,P1.CORPNO AS CORPNO -- 关联字段
    ,P1.OPEN_ACCT_CHNL_CD AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,P1.ELEC_LIACCT_PROPTY_CD AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,P1.ELEC_LIACCT_TYPE_CD AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_03 AS P1 -- 临时表3

LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_CACD_TF AS P2 -- 外部卡与客户账号对照表
       ON P2.CUSTAC = P1.EACCT_NO  and SUBSTR(P2.CARDNO,1,6) ='623540' AND P2.STATUS<>'2' AND P2.DEL_F='0'  and P2.PT_DT = '${process_date}' 
LEFT JOIN (
SELECT 
   ACCTNO
  ,RPLSTP
FROM(
    SELECT 
       ACCTNO
      ,RPLSTP
      ,ROW_NUMBER() OVER (PARTITION BY ACCTNO ORDER BY RPTLNO DESC) AS RN
    FROM  ODS_NAS${version_num}.ODS_NAS_KNB_RPVO_TF
    WHERE DEL_F='0' AND PT_DT = '${process_date}'
    ) 
WHERE RN=1
) AS P3 -- 挂失登记簿
       ON p1.ACCT_NO =P3.ACCTNO 
LEFT JOIN  (
SELECT 
  T1.CUSTAC
 ,CASE WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP = '1' THEN '2'
      WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP = '2' THEN '3'
      WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP = '3' THEN '1'
      WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP = '4' THEN '4'
      ELSE '0' END AS FRZ_STATUS_CD  --冻结状态
 ,CASE WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP = '1' THEN '2'
      WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP = '3' THEN '1'
      WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP IN ('2','4') THEN '3'
      ELSE '0'  END AS STOP_PAY_STATUS_CD  --止付状态 
 ,SUM(CASE WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP IN ('1','2','3','4') THEN T2.FROZAM  ELSE 0  END) AS  STOP_PAY_AMT --冻结金额
 ,SUM(CASE WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP IN ('1','2','3','4') THEN T2.FROZAM ELSE 0 END ) AS  FRZ_AMT --止付金额
FROM ODS_NAS${version_num}.ODS_NAS_KNB_FROZ_TF  T1   --冻结登记簿 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNB_FROZ_DETL_TF T2   --冻结明细登记簿
ON  T1.FROZNO = T2.FROZNO AND T1.FROZSQ =T2.FROZSQ   AND T2.FROZST='0' AND T2.DEL_F= '0' AND T2.PT_DT = '${process_date}'
WHERE T1.FREDDT = '20990101' AND T1.DEL_F='0' AND T1.FROZST='0' AND T1.PT_DT = '${process_date}'
GROUP BY T1.CUSTAC,T1.FROZTP,T1.FRLMTP 
) AS P4 -- 冻结登记簿/冻结明细登记簿
       ON p1.EACCT_NO = P4.CUSTAC 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_FXAC_MATU_TF AS P5 -- 负债定期账户到期信息表
       ON p1.ACCT_NO =P5.ACCTNO AND P5.DEL_F='0' AND P5.PT_DT = '${process_date}' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_SVAC_TF AS P6 -- 储蓄账户表
       ON p1.ACCT_NO =P6.ACCTNO AND P6.DEL_F='0' AND  P6.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_AFFMYRPT_TF AS P9 -- 年度报表汇率文件
       ON p1.CURR_CD = P9.YRCACCYC 
AND CAST(P9.YRCADATE AS STRING) = REPLACE('${process_date}','-','') --跑批日
AND P9.YRCARS1B <> '9'
AND P9.DEL_F='0'
AND P9.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P10 -- 代码转换
       ON P5.TRSVTP=P10.SRC_CD_VAL  
AND P10.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P10.SRC_TAB_EN_NAME='KNA_FXAC_MATU' --来源表英文名  
AND P10.SRC_FIELD_EN_NAME='TRSVTP' --来源字段英文名 
AND P10.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P10.TARGET_FIELD_EN_NAME='AUTO_REDT_IDNT_CD' --目标字段 
;
-- ==============聚合层字段映射（第2-3组）==============
-- 个人定期存款账户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_TYPE_CD -- 客户类型代码
    ,MAIN_DOCTYP_CD -- 主证件类型代码
    ,MAIN_DOC_NO -- 主证件号码
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,ACCT_STATUS_CD -- 账户状态代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,ORIG_DPSIT_TERM -- 原始存款期限
    ,DPSIT_PERIOD_DAYS -- 存期天数
    ,EACCT_NO -- 电子账户编号
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,VOCH_NO -- 凭证号码
    ,MED_TYPE_CD -- 介质类型代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,AGREE_FLAG -- 协定标志
    ,PLEDGE_FLAG -- 质押标志
    ,DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,OPEN_ACCT_AMT -- 开户金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_BAL -- 当前余额
    ,CTRL_AMT -- 控制金额
    ,FRZ_AMT -- 冻结金额
    ,STOP_PAY_AMT -- 止付金额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,INTACR_MODE_CD -- 计息方式代码
    ,INTACR_BASE_CD -- 计息基础代码
    ,INT_TAX -- 利息税
    ,INT_TXBL_AMT -- 利息应税金额
    ,OPEN_ACCT_INT_RATE -- 开户利率
    ,BNCHMK_INT_RATE -- 基准利率
    ,FLOT_INT_RATE -- 浮动利率
    ,FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,MNYITM_SRC_CD -- 款项来源代码
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,PAYOFF_DT -- 结清日期
    ,NEXT_CAN_DRAW_DT -- 下次可支取日期
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_DT -- 销户日期
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,REDT_FLAG -- 转存标志
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,OPEN_ACCT_TM -- 开户时间
    ,OPEN_ACCT_TELR -- 开户柜员
    ,EACCT_BIND_CARD_NO -- 电子账户绑定卡号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,'1' AS CUST_TYPE_CD -- 客户类型代码
    ,P1.MAIN_DOCTYP_CD AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,P1.MAIN_DOC_NO AS MAIN_DOC_NO -- 主证件号码
    ,P1.OPEN_ACCT_DOCTYP_CD AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.OPEN_ACCT_DOC_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,'' AS FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,'' AS FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,'1' AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,'1' AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,P1.ACCT_TYPE_CD AS ACCT_TYPE_CD -- 账户类型代码
    ,P1.ACCT_PROPTY_CD AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.ACCT_STATUS_CD AS ACCT_STATUS_CD -- 账户状态代码
    ,P1.DPSIT_BIZ_CATEGORY_CD AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P1.DPSIT_PROD_NAME AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.ACCTN_SUBJ_NO AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.ACCTN_SUBJ_NAME AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,'' AS MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,'' AS AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,P1.ORIG_DPSIT_TERM AS ORIG_DPSIT_TERM -- 原始存款期限
    ,P1.DPSIT_PERIOD_DAYS AS DPSIT_PERIOD_DAYS -- 存期天数
    ,P1.EACCT_NO AS EACCT_NO -- 电子账户编号
    ,P1.ELEC_LIACCT_PROPTY_CD AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,P1.ELEC_LIACCT_TYPE_CD AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,'' AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,'' AS ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,P1.VOCH_NO AS VOCH_NO -- 凭证号码
    ,'8' AS MED_TYPE_CD -- 介质类型代码
    ,P1.REPLOS_STATUS_CD AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P1.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,P1.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P1.AUTO_REDT_IDNT_CD AS AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,'' AS AGREE_FLAG -- 协定标志
    ,'' AS PLEDGE_FLAG -- 质押标志
    ,'' AS DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,P1.OPEN_ACCT_AMT AS OPEN_ACCT_AMT -- 开户金额
    ,P1.YESTD_BAL AS YESTD_BAL -- 昨日余额
    ,P1.CURR_BAL AS CURR_BAL -- 当前余额
    ,'' AS CTRL_AMT -- 控制金额
    ,P1.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,P1.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P1.YESTD_BAL,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM,0) + COALESCE(P1.YESTD_BAL,0) END  AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P1.YESTD_BAL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM,0) + COALESCE(P1.YESTD_BAL,0) END  AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P1.YESTD_BAL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM,0) + COALESCE(P1.YESTD_BAL,0) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,P1.YESTD_BAL_CONVT_RMB AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','MM') AS STRING )  THEN  COALESCE(P1.YESTD_BAL_CONVT_RMB,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + COALESCE(P1.YESTD_BAL_CONVT_RMB,0) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','quarter') AS STRING )  THEN  COALESCE(P1.YESTD_BAL_CONVT_RMB,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + COALESCE(P1.YESTD_BAL_CONVT_RMB,0) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','YY') AS STRING )  THEN  COALESCE(P1.YESTD_BAL_CONVT_RMB,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + COALESCE(P1.YESTD_BAL_CONVT_RMB,0) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CASE WHEN P1.PT_DT = CAST(TRUNC('${process_date}','YY') AS STRING )  THEN  COALESCE(P2.RLINTR,0)  --当为年初时，取当日余额
ELSE COALESCE(S1.ACTL_INT_AMT_YEAR_CUM,0)+ COALESCE(P2.RLINTR,0) END  AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,'1' AS INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,CASE WHEN P3.INBEFG='1' THEN '7' ELSE '0' END AS INTACR_MODE_CD -- 计息方式代码
    ,CASE WHEN P3.TXBEBS IS NULL OR TRIM(P3.TXBEBS)=''
     THEN ''
     ELSE COALESCE(TRIM(P10.TARGET_CD_VAL), CONCAT('@',TRIM(P3.TXBEBS)),'')
END AS INTACR_BASE_CD -- 计息基础代码
    ,P2.RLINTX AS INT_TAX -- 利息税
    ,P2.RLINTX AS INT_TXBL_AMT -- 利息应税金额
    ,P5.OPINTR AS OPEN_ACCT_INT_RATE -- 开户利率
    ,P7.BASEIR AS BNCHMK_INT_RATE -- 基准利率
    ,CASE WHEN P8.FLIRWY = '1' 
     THEN P7.baseir*((P8.FLIRRT/100)+1)  
     WHEN P8.FLIRWY = '2' 
     THEN P7.baseir+P8.FLIRVL 
     ELSE 0 
END AS FLOT_INT_RATE -- 浮动利率
    ,CASE WHEN P8.RFIRTM IS NULL OR TRIM(P8.RFIRTM)=''
     THEN ''
     ELSE COALESCE(TRIM(P11.TARGET_CD_VAL), CONCAT('@',TRIM(P8.RFIRTM)),'')
END AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,CASE WHEN P8.FLIRWY='1' THEN '2' WHEN P8.FLIRWY='2' THEN '1' ELSE '0' END AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,'' AS MNYITM_SRC_CD -- 款项来源代码
    ,P1.OPEN_ACCT_DT AS OPEN_ACCT_DT -- 开户日期
    ,P1.VAL_DT AS VAL_DT -- 起息日期
    ,P1.MATU_DT AS MATU_DT -- 到期日期
    ,P1.FINAL_TXN_DT AS FINAL_TXN_DT -- 最后交易日期
    ,P1.PAYOFF_DT AS PAYOFF_DT -- 结清日期
    ,'' AS NEXT_CAN_DRAW_DT -- 下次可支取日期
    ,P1.OPEN_ACCT_CHNL_CD AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,P1.CANC_ACCT_DT AS CANC_ACCT_DT -- 销户日期
    ,P1.CANC_ACCT_CHNL AS CANC_ACCT_CHNL -- 销户渠道代码
    ,'' AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,'' AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,P1.STAT_ORG_NO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BELONG_ORG_NO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.LP_ORG_NO AS LP_ORG_NO -- 法人机构编号
    ,'0' AS REC_STATUS_CD -- 记录状态代码
    ,P1.SETUP_DT AS SETUP_DT -- 建立日期
    ,P1.SETUP_TM_STAMP AS SETUP_TM_STAMP -- 建立时间戳
    ,'999S000' AS SETUP_TELR_NO -- 建立柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_MODIF_TM_STAMP AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.REDT_FLAG AS REDT_FLAG -- 转存标志
    ,'999S000' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'1' AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,'' AS MRGACCT_FLAG -- 保证金账户标志
    ,'1' AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,'定活互转' AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,P9.TIMETM AS OPEN_ACCT_TM -- 开户时间
    ,P9.OPENUS AS OPEN_ACCT_TELR -- 开户柜员
    ,P4.CARDNO AS EACCT_BIND_CARD_NO -- 电子账户绑定卡号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNA_FXAC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_04 AS P1 -- 临时表4

LEFT JOIN (
SELECT   T1.ACCTNO
        ,SUM(T1.RLINTR) AS RLINTR
        ,SUM(T1.RLINTX) AS RLINTX
FROM  ODS_NAS${version_num}.ODS_NAS_KNB_PIDL_TF T1  --负债账户付息明细
WHERE T1.PYINDT = REPLACE(CAST(TRUNC('${process_date}','YY') AS VARCHAR(10)),'-','')
AND   T1.PYINDT = REPLACE('${process_date}','-','')
AND   T1.DEL_F='0'
AND   T1.PT_DT = '${process_date}'
GROUP BY  T1.ACCTNO
) AS P2 -- 负债账户付息明细
       ON P1.ACCT_NO=P2.acctno 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNB_ACIN_TF AS P3 -- 负债账户计息表
       ON P1.ACCT_NO=P3.acctno AND P3.DEL_F='0' AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KNA_ACDC_TF AS P4 -- 卡客户账号对照表
       ON P4.CUSTAC =P1.EACCT_NO AND P4.CORPNO =P1.CORPNO  AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KUB_INRT_TF AS P5 -- 账户利率信息
       ON P1.ACCT_NO=P5.acctno AND P5.DEL_F='0'AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KUP_DPPB_INTR_TF AS P6 -- 产品利息利率定义
       ON P1.DPSIT_PROD_CD= P6.prodcd AND P6.PT_DT = '${process_date}' AND P6.DEL_F='0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KUP_RFIR_TF AS P7 -- 基础利率表
       ON P6.INTRCD = P7.RFIRSQ AND P6.INCDTP = '1' AND P7.PT_DT = '${process_date}' AND P7.DEL_F='0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_KUP_BKIR_TF AS P8 -- 浮动利率表
       ON P6.INTRCD = P8.BKIRSQ AND P6.INCDTP = '2' AND P8.PT_DT = '${process_date}' AND P8.DEL_F='0' 
LEFT JOIN (SELECT * FROM(
   SELECT
      CUSTAC
     ,TIMETM
     ,OPENUS
     ,CORPNO
     ,ROW_NUMBER() OVER(PARTITION BY CUSTAC,CORPNO ORDER BY OPENSQ DESC)RN
   FROM ODS_NAS${version_num}.ODS_NAS_KNB_OPAC_TF
   WHERE DEL_F='0' AND PT_DT = '${process_date}'
 )WHERE RN=1
) AS P9 -- 电子账户开户登记簿
       ON P9.CUSTAC = P1.EACCT_NO AND P9.CORPNO = P1.CORPNO 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P10 -- 代码转换
       ON P3.TXBEBS=P10.SRC_CD_VAL  
AND P10.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P10.SRC_TAB_EN_NAME='KNB_ACIN' --来源表英文名  
AND P10.SRC_FIELD_EN_NAME='TXBEBS' --来源字段英文名 
AND P10.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P10.TARGET_FIELD_EN_NAME='INTACR_BASE_CD' --目标字段 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P11 -- 代码转换
       ON P8.RFIRTM=P11.SRC_CD_VAL  
AND P11.SRC_TAB_LIB_NAME ='NAS'  --源系统
AND P11.SRC_TAB_EN_NAME='KUP_BKIR' --来源表英文名  
AND P11.SRC_FIELD_EN_NAME='RFIRTM' --来源字段英文名 
AND P11.TARGET_TAB_EN_NAME='AGL_INDV_RGL_DPSIT_ACCT_INFO_TF'  --目标表名   
AND P11.TARGET_FIELD_EN_NAME='FLOT_INT_RATE_PERIOD_CD' --目标字段 
LEFT JOIN (
SELECT
    T1.ACCT_NO
   ,T1.CURR_CD
   ,T1.CASH_RMT_CD
   ,T1.YESTD_BAL_MONTH_ACCUM
   ,T1.YESTD_BAL_QUAR_ACCUM
   ,T1.YESTD_BAL_YEAR_ACCUM
   ,T1.ACTL_INT_AMT_YEAR_CUM
   ,T1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
   ,T1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
   ,T1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF  T1
WHERE T1.PT_DT = CAST(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND T1.SRC_SYS_CD='NAS' AND T1.DEL_F='0'
) AS S1 -- 个人定期存款账户信息聚合上日积数
       ON COALESCE(P1.ACCT_NO,'') = COALESCE(S1.ACCT_NO,'') 
AND COALESCE(P1.CURR_CD,'') = COALESCE(S1.CURR_CD,'') 
AND COALESCE(P1.CASH_RMT_CD,'') = COALESCE(S1.CASH_RMT_CD,'') 
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.CASH_RMT_CD, BF.CASH_RMT_CD) END AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INDV_CORP_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.INDV_CORP_IDNT_CD, BF.INDV_CORP_IDNT_CD) END AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_TYPE_CD, BF.CUST_TYPE_CD) END AS CUST_TYPE_CD -- 客户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAIN_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.MAIN_DOCTYP_CD, BF.MAIN_DOCTYP_CD) END AS MAIN_DOCTYP_CD -- 主证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAIN_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.MAIN_DOC_NO, BF.MAIN_DOC_NO) END AS MAIN_DOC_NO -- 主证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DOCTYP_CD, BF.OPEN_ACCT_DOCTYP_CD) END AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DOC_NO, BF.OPEN_ACCT_DOC_NO) END AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FX_ACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.FX_ACCT_PROPTY_CD, BF.FX_ACCT_PROPTY_CD) END AS FX_ACCT_PROPTY_CD -- 外汇账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FX_CUST_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.FX_CUST_TYPE_CD, BF.FX_CUST_TYPE_CD) END AS FX_CUST_TYPE_CD -- 外汇客户类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIVERSAL_WITHDR_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD, BF.UNIVERSAL_WITHDR_LVL_CD) END AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIVERSAL_SAVING_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.UNIVERSAL_SAVING_LVL_CD, BF.UNIVERSAL_SAVING_LVL_CD) END AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_TYPE_CD, BF.ACCT_TYPE_CD) END AS ACCT_TYPE_CD -- 账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_PROPTY_CD, BF.ACCT_PROPTY_CD) END AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MRGACCT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.MRGACCT_FLAG, BF.MRGACCT_FLAG) END AS MRGACCT_FLAG -- 保证金账户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_STATUS_CD, BF.ACCT_STATUS_CD) END AS ACCT_STATUS_CD -- 账户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_BIZ_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_BIZ_CATEGORY_CD, BF.DPSIT_BIZ_CATEGORY_CD) END AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PROD_CD, BF.DPSIT_PROD_CD) END AS DPSIT_PROD_CD -- 存款产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PROD_NAME, BF.DPSIT_PROD_NAME) END AS DPSIT_PROD_NAME -- 存款产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_COMB_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_COMB_PROD_CD, BF.DPSIT_COMB_PROD_CD) END AS DPSIT_COMB_PROD_CD -- 存款组合产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_COMB_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_COMB_PROD_NAME, BF.DPSIT_COMB_PROD_NAME) END AS DPSIT_COMB_PROD_NAME -- 存款组合产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NO, BF.ACCTN_SUBJ_NO) END AS ACCTN_SUBJ_NO -- 会计科目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NAME, BF.ACCTN_SUBJ_NAME) END AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MRG_BIZ_CATE_CD IS NULL THEN NULL ELSE COALESCE(TM.MRG_BIZ_CATE_CD, BF.MRG_BIZ_CATE_CD) END AS MRG_BIZ_CATE_CD -- 保证金业务种类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGREE_REDT_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.AGREE_REDT_ACCT_NO, BF.AGREE_REDT_ACCT_NO) END AS AGREE_REDT_ACCT_NO -- 约定转存账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_DPSIT_TERM IS NULL THEN NULL ELSE COALESCE(TM.ORIG_DPSIT_TERM, BF.ORIG_DPSIT_TERM) END AS ORIG_DPSIT_TERM -- 原始存款期限
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PERIOD_DAYS IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PERIOD_DAYS, BF.DPSIT_PERIOD_DAYS) END AS DPSIT_PERIOD_DAYS -- 存期天数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.EACCT_NO, BF.EACCT_NO) END AS EACCT_NO -- 电子账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_PROPTY_CD, BF.ELEC_LIACCT_PROPTY_CD) END AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_TYPE_CD, BF.ELEC_LIACCT_TYPE_CD) END AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ALL_IN_ONE_PSBOOK_NO IS NULL THEN NULL ELSE COALESCE(TM.ALL_IN_ONE_PSBOOK_NO, BF.ALL_IN_ONE_PSBOOK_NO) END AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ALL_IN_ONE_PSBOOK_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ALL_IN_ONE_PSBOOK_ACCT_NO, BF.ALL_IN_ONE_PSBOOK_ACCT_NO) END AS ALL_IN_ONE_PSBOOK_ACCT_NO -- 一本通账号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EACCT_BIND_CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.EACCT_BIND_CARD_NO, BF.EACCT_BIND_CARD_NO) END AS EACCT_BIND_CARD_NO -- 电子账户绑定卡号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VOCH_NO IS NULL THEN NULL ELSE COALESCE(TM.VOCH_NO, BF.VOCH_NO) END AS VOCH_NO -- 凭证号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.MED_TYPE_CD, BF.MED_TYPE_CD) END AS MED_TYPE_CD -- 介质类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REPLOS_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REPLOS_STATUS_CD, BF.REPLOS_STATUS_CD) END AS REPLOS_STATUS_CD -- 挂失状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.FRZ_STATUS_CD, BF.FRZ_STATUS_CD) END AS FRZ_STATUS_CD -- 冻结状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_PAY_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.STOP_PAY_STATUS_CD, BF.STOP_PAY_STATUS_CD) END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REDT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.REDT_FLAG, BF.REDT_FLAG) END AS REDT_FLAG -- 转存标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUTO_REDT_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.AUTO_REDT_IDNT_CD, BF.AUTO_REDT_IDNT_CD) END AS AUTO_REDT_IDNT_CD -- 自动转存标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.DRAW_MODE_CD, BF.DRAW_MODE_CD) END AS DRAW_MODE_CD -- 支取方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGREE_FLAG IS NULL THEN NULL ELSE COALESCE(TM.AGREE_FLAG, BF.AGREE_FLAG) END AS AGREE_FLAG -- 协定标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PLEDGE_FLAG IS NULL THEN NULL ELSE COALESCE(TM.PLEDGE_FLAG, BF.PLEDGE_FLAG) END AS PLEDGE_FLAG -- 质押标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEPT_OR_DEFLT_TMS IS NULL THEN NULL ELSE COALESCE(TM.DEPT_OR_DEFLT_TMS, BF.DEPT_OR_DEFLT_TMS) END AS DEPT_OR_DEFLT_TMS -- 部支或违约次数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_AMT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_AMT, BF.OPEN_ACCT_AMT) END AS OPEN_ACCT_AMT -- 开户金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL, BF.YESTD_BAL) END AS YESTD_BAL -- 昨日余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_BAL IS NULL THEN NULL ELSE COALESCE(TM.CURR_BAL, BF.CURR_BAL) END AS CURR_BAL -- 当前余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CTRL_AMT IS NULL THEN NULL ELSE COALESCE(TM.CTRL_AMT, BF.CTRL_AMT) END AS CTRL_AMT -- 控制金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_AMT IS NULL THEN NULL ELSE COALESCE(TM.FRZ_AMT, BF.FRZ_AMT) END AS FRZ_AMT -- 冻结金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_PAY_AMT IS NULL THEN NULL ELSE COALESCE(TM.STOP_PAY_AMT, BF.STOP_PAY_AMT) END AS STOP_PAY_AMT -- 止付金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM, BF.YESTD_BAL_MONTH_ACCUM) END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM, BF.YESTD_BAL_QUAR_ACCUM) END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM, BF.YESTD_BAL_YEAR_ACCUM) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_CONVT_RMB, BF.YESTD_BAL_CONVT_RMB) END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB, BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_INT_AMT_YEAR_CUM IS NULL THEN NULL ELSE COALESCE(TM.ACTL_INT_AMT_YEAR_CUM, BF.ACTL_INT_AMT_YEAR_CUM) END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INT_FREE_TAX_FLAG IS NULL THEN NULL ELSE COALESCE(TM.INT_FREE_TAX_FLAG, BF.INT_FREE_TAX_FLAG) END AS INT_FREE_TAX_FLAG -- 豁免利息税标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INTACR_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.INTACR_MODE_CD, BF.INTACR_MODE_CD) END AS INTACR_MODE_CD -- 计息方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INTACR_BASE_CD IS NULL THEN NULL ELSE COALESCE(TM.INTACR_BASE_CD, BF.INTACR_BASE_CD) END AS INTACR_BASE_CD -- 计息基础代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INT_TAX IS NULL THEN NULL ELSE COALESCE(TM.INT_TAX, BF.INT_TAX) END AS INT_TAX -- 利息税
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INT_TXBL_AMT IS NULL THEN NULL ELSE COALESCE(TM.INT_TXBL_AMT, BF.INT_TXBL_AMT) END AS INT_TXBL_AMT -- 利息应税金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_INT_RATE IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_INT_RATE, BF.OPEN_ACCT_INT_RATE) END AS OPEN_ACCT_INT_RATE -- 开户利率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BNCHMK_INT_RATE IS NULL THEN NULL ELSE COALESCE(TM.BNCHMK_INT_RATE, BF.BNCHMK_INT_RATE) END AS BNCHMK_INT_RATE -- 基准利率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FLOT_INT_RATE IS NULL THEN NULL ELSE COALESCE(TM.FLOT_INT_RATE, BF.FLOT_INT_RATE) END AS FLOT_INT_RATE -- 浮动利率
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FLOT_INT_RATE_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.FLOT_INT_RATE_PERIOD_CD, BF.FLOT_INT_RATE_PERIOD_CD) END AS FLOT_INT_RATE_PERIOD_CD -- 浮动利率周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FLOT_INT_RATE_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.FLOT_INT_RATE_TYPE_CD, BF.FLOT_INT_RATE_TYPE_CD) END AS FLOT_INT_RATE_TYPE_CD -- 浮动利率类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MNYITM_SRC_CD IS NULL THEN NULL ELSE COALESCE(TM.MNYITM_SRC_CD, BF.MNYITM_SRC_CD) END AS MNYITM_SRC_CD -- 款项来源代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DT, BF.OPEN_ACCT_DT) END AS OPEN_ACCT_DT -- 开户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_TM IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_TM, BF.OPEN_ACCT_TM) END AS OPEN_ACCT_TM -- 开户时间
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_TELR IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_TELR, BF.OPEN_ACCT_TELR) END AS OPEN_ACCT_TELR -- 开户柜员
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VAL_DT IS NULL THEN NULL ELSE COALESCE(TM.VAL_DT, BF.VAL_DT) END AS VAL_DT -- 起息日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MATU_DT IS NULL THEN NULL ELSE COALESCE(TM.MATU_DT, BF.MATU_DT) END AS MATU_DT -- 到期日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_TXN_DT, BF.FINAL_TXN_DT) END AS FINAL_TXN_DT -- 最后交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYOFF_DT IS NULL THEN NULL ELSE COALESCE(TM.PAYOFF_DT, BF.PAYOFF_DT) END AS PAYOFF_DT -- 结清日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.NEXT_CAN_DRAW_DT IS NULL THEN NULL ELSE COALESCE(TM.NEXT_CAN_DRAW_DT, BF.NEXT_CAN_DRAW_DT) END AS NEXT_CAN_DRAW_DT -- 下次可支取日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_CHNL_CD, BF.OPEN_ACCT_CHNL_CD) END AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_DT, BF.CANC_ACCT_DT) END AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_CHNL IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_CHNL, BF.CANC_ACCT_CHNL) END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_ORG_NO, BF.CANC_ACCT_ORG_NO) END AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_TELR_NO, BF.CANC_ACCT_TELR_NO) END AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STAT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.STAT_ORG_NO, BF.STAT_ORG_NO) END AS STAT_ORG_NO -- 统计机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REC_STATUS_CD, BF.REC_STATUS_CD) END AS REC_STATUS_CD -- 记录状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_DT IS NULL THEN NULL ELSE COALESCE(TM.SETUP_DT, BF.SETUP_DT) END AS SETUP_DT -- 建立日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TM_STAMP, BF.SETUP_TM_STAMP) END AS SETUP_TM_STAMP -- 建立时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TELR_NO, BF.SETUP_TELR_NO) END AS SETUP_TELR_NO -- 建立柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.INDV_CORP_IDNT_CD,'') = COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.MAIN_DOCTYP_CD,'') = COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段相等
         AND COALESCE(TM.MAIN_DOC_NO,'') = COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') = COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOC_NO,'') = COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段相等
         AND COALESCE(TM.FX_ACCT_PROPTY_CD,'') = COALESCE(BF.FX_ACCT_PROPTY_CD,'') -- 外汇账户性质代码 非主键字段相等
         AND COALESCE(TM.FX_CUST_TYPE_CD,'') = COALESCE(BF.FX_CUST_TYPE_CD,'') -- 外汇客户类别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') = COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') = COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段相等
         AND COALESCE(TM.ACCT_TYPE_CD,'') = COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.MRGACCT_FLAG,'') = COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段相等
         AND COALESCE(TM.ACCT_STATUS_CD,'') = COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段相等
         AND COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') = COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_CD,'') = COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_NAME,'') = COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_CD,'') = COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_NAME,'') = COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.MRG_BIZ_CATE_CD,'') = COALESCE(BF.MRG_BIZ_CATE_CD,'') -- 保证金业务种类代码 非主键字段相等
         AND COALESCE(TM.AGREE_REDT_ACCT_NO,'') = COALESCE(BF.AGREE_REDT_ACCT_NO,'') -- 约定转存账户编号 非主键字段相等
         AND COALESCE(TM.ORIG_DPSIT_TERM,'') = COALESCE(BF.ORIG_DPSIT_TERM,'') -- 原始存款期限 非主键字段相等
         AND COALESCE(TM.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) = COALESCE(BF.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) -- 存期天数 非主键字段相等
         AND COALESCE(TM.EACCT_NO,'') = COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') = COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') = COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段相等
         AND COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') = COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段相等
         AND COALESCE(TM.ALL_IN_ONE_PSBOOK_ACCT_NO,'') = COALESCE(BF.ALL_IN_ONE_PSBOOK_ACCT_NO,'') -- 一本通账号 非主键字段相等
         AND COALESCE(TM.EACCT_BIND_CARD_NO,'') = COALESCE(BF.EACCT_BIND_CARD_NO,'') -- 电子账户绑定卡号 非主键字段相等
         AND COALESCE(TM.VOCH_NO,'') = COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段相等
         AND COALESCE(TM.MED_TYPE_CD,'') = COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段相等
         AND COALESCE(TM.REPLOS_STATUS_CD,'') = COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段相等
         AND COALESCE(TM.FRZ_STATUS_CD,'') = COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段相等
         AND COALESCE(TM.STOP_PAY_STATUS_CD,'') = COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段相等
         AND COALESCE(TM.REDT_FLAG,'') = COALESCE(BF.REDT_FLAG,'') -- 转存标志 非主键字段相等
         AND COALESCE(TM.AUTO_REDT_IDNT_CD,'') = COALESCE(BF.AUTO_REDT_IDNT_CD,'') -- 自动转存标识代码 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.AGREE_FLAG,'') = COALESCE(BF.AGREE_FLAG,'') -- 协定标志 非主键字段相等
         AND COALESCE(TM.PLEDGE_FLAG,'') = COALESCE(BF.PLEDGE_FLAG,'') -- 质押标志 非主键字段相等
         AND COALESCE(TM.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) = COALESCE(BF.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) -- 部支或违约次数 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段相等
         AND COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段相等
         AND COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段相等
         AND COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段相等
         AND COALESCE(TM.INT_FREE_TAX_FLAG,'') = COALESCE(BF.INT_FREE_TAX_FLAG,'') -- 豁免利息税标志 非主键字段相等
         AND COALESCE(TM.INTACR_MODE_CD,'') = COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段相等
         AND COALESCE(TM.INTACR_BASE_CD,'') = COALESCE(BF.INTACR_BASE_CD,'') -- 计息基础代码 非主键字段相等
         AND COALESCE(TM.INT_TAX,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 利息税 非主键字段相等
         AND COALESCE(TM.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) -- 利息应税金额 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段相等
         AND COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') = COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') = COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段相等
         AND COALESCE(TM.MNYITM_SRC_CD,'') = COALESCE(BF.MNYITM_SRC_CD,'') -- 款项来源代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM,'') = COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TELR,'') = COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段相等
         AND COALESCE(TM.VAL_DT,'') = COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段相等
         AND COALESCE(TM.MATU_DT,'') = COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段相等
         AND COALESCE(TM.FINAL_TXN_DT,'') = COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段相等
         AND COALESCE(TM.PAYOFF_DT,'') = COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段相等
         AND COALESCE(TM.NEXT_CAN_DRAW_DT,'') = COALESCE(BF.NEXT_CAN_DRAW_DT,'') -- 下次可支取日期 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_CHNL_CD,'') = COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_CHNL,'') = COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_ORG_NO,'') = COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TELR_NO,'') = COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.INDV_CORP_IDNT_CD,'') <> COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.MAIN_DOCTYP_CD,'') <> COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段不相等
         OR COALESCE(TM.MAIN_DOC_NO,'') <> COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') <> COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOC_NO,'') <> COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段不相等
         OR COALESCE(TM.FX_ACCT_PROPTY_CD,'') <> COALESCE(BF.FX_ACCT_PROPTY_CD,'') -- 外汇账户性质代码 非主键字段不相等
         OR COALESCE(TM.FX_CUST_TYPE_CD,'') <> COALESCE(BF.FX_CUST_TYPE_CD,'') -- 外汇客户类别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段不相等
         OR COALESCE(TM.ACCT_TYPE_CD,'') <> COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.MRGACCT_FLAG,'') <> COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段不相等
         OR COALESCE(TM.ACCT_STATUS_CD,'') <> COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') <> COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_CD,'') <> COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_NAME,'') <> COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_CD,'') <> COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_NAME,'') <> COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.MRG_BIZ_CATE_CD,'') <> COALESCE(BF.MRG_BIZ_CATE_CD,'') -- 保证金业务种类代码 非主键字段不相等
         OR COALESCE(TM.AGREE_REDT_ACCT_NO,'') <> COALESCE(BF.AGREE_REDT_ACCT_NO,'') -- 约定转存账户编号 非主键字段不相等
         OR COALESCE(TM.ORIG_DPSIT_TERM,'') <> COALESCE(BF.ORIG_DPSIT_TERM,'') -- 原始存款期限 非主键字段不相等
         OR COALESCE(TM.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) <> COALESCE(BF.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) -- 存期天数 非主键字段不相等
         OR COALESCE(TM.EACCT_NO,'') <> COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') <> COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') <> COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段不相等
         OR COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') <> COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段不相等
         OR COALESCE(TM.ALL_IN_ONE_PSBOOK_ACCT_NO,'') <> COALESCE(BF.ALL_IN_ONE_PSBOOK_ACCT_NO,'') -- 一本通账号 非主键字段不相等
         OR COALESCE(TM.EACCT_BIND_CARD_NO,'') <> COALESCE(BF.EACCT_BIND_CARD_NO,'') -- 电子账户绑定卡号 非主键字段不相等
         OR COALESCE(TM.VOCH_NO,'') <> COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段不相等
         OR COALESCE(TM.MED_TYPE_CD,'') <> COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段不相等
         OR COALESCE(TM.REPLOS_STATUS_CD,'') <> COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段不相等
         OR COALESCE(TM.FRZ_STATUS_CD,'') <> COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_STATUS_CD,'') <> COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段不相等
         OR COALESCE(TM.REDT_FLAG,'') <> COALESCE(BF.REDT_FLAG,'') -- 转存标志 非主键字段不相等
         OR COALESCE(TM.AUTO_REDT_IDNT_CD,'') <> COALESCE(BF.AUTO_REDT_IDNT_CD,'') -- 自动转存标识代码 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.AGREE_FLAG,'') <> COALESCE(BF.AGREE_FLAG,'') -- 协定标志 非主键字段不相等
         OR COALESCE(TM.PLEDGE_FLAG,'') <> COALESCE(BF.PLEDGE_FLAG,'') -- 质押标志 非主键字段不相等
         OR COALESCE(TM.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) <> COALESCE(BF.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) -- 部支或违约次数 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段不相等
         OR COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段不相等
         OR COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段不相等
         OR COALESCE(TM.INT_FREE_TAX_FLAG,'') <> COALESCE(BF.INT_FREE_TAX_FLAG,'') -- 豁免利息税标志 非主键字段不相等
         OR COALESCE(TM.INTACR_MODE_CD,'') <> COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段不相等
         OR COALESCE(TM.INTACR_BASE_CD,'') <> COALESCE(BF.INTACR_BASE_CD,'') -- 计息基础代码 非主键字段不相等
         OR COALESCE(TM.INT_TAX,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 利息税 非主键字段不相等
         OR COALESCE(TM.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) -- 利息应税金额 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段不相等
         OR COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') <> COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') <> COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段不相等
         OR COALESCE(TM.MNYITM_SRC_CD,'') <> COALESCE(BF.MNYITM_SRC_CD,'') -- 款项来源代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM,'') <> COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TELR,'') <> COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段不相等
         OR COALESCE(TM.VAL_DT,'') <> COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段不相等
         OR COALESCE(TM.MATU_DT,'') <> COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段不相等
         OR COALESCE(TM.FINAL_TXN_DT,'') <> COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段不相等
         OR COALESCE(TM.PAYOFF_DT,'') <> COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段不相等
         OR COALESCE(TM.NEXT_CAN_DRAW_DT,'') <> COALESCE(BF.NEXT_CAN_DRAW_DT,'') -- 下次可支取日期 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_CHNL_CD,'') <> COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_CHNL,'') <> COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_ORG_NO,'') <> COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TELR_NO,'') <> COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.INDV_CORP_IDNT_CD,'') = COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.MAIN_DOCTYP_CD,'') = COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段相等
         AND COALESCE(TM.MAIN_DOC_NO,'') = COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') = COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOC_NO,'') = COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段相等
         AND COALESCE(TM.FX_ACCT_PROPTY_CD,'') = COALESCE(BF.FX_ACCT_PROPTY_CD,'') -- 外汇账户性质代码 非主键字段相等
         AND COALESCE(TM.FX_CUST_TYPE_CD,'') = COALESCE(BF.FX_CUST_TYPE_CD,'') -- 外汇客户类别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') = COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') = COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段相等
         AND COALESCE(TM.ACCT_TYPE_CD,'') = COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.MRGACCT_FLAG,'') = COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段相等
         AND COALESCE(TM.ACCT_STATUS_CD,'') = COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段相等
         AND COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') = COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_CD,'') = COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_NAME,'') = COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_CD,'') = COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_COMB_PROD_NAME,'') = COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.MRG_BIZ_CATE_CD,'') = COALESCE(BF.MRG_BIZ_CATE_CD,'') -- 保证金业务种类代码 非主键字段相等
         AND COALESCE(TM.AGREE_REDT_ACCT_NO,'') = COALESCE(BF.AGREE_REDT_ACCT_NO,'') -- 约定转存账户编号 非主键字段相等
         AND COALESCE(TM.ORIG_DPSIT_TERM,'') = COALESCE(BF.ORIG_DPSIT_TERM,'') -- 原始存款期限 非主键字段相等
         AND COALESCE(TM.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) = COALESCE(BF.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) -- 存期天数 非主键字段相等
         AND COALESCE(TM.EACCT_NO,'') = COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') = COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') = COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段相等
         AND COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') = COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段相等
         AND COALESCE(TM.ALL_IN_ONE_PSBOOK_ACCT_NO,'') = COALESCE(BF.ALL_IN_ONE_PSBOOK_ACCT_NO,'') -- 一本通账号 非主键字段相等
         AND COALESCE(TM.EACCT_BIND_CARD_NO,'') = COALESCE(BF.EACCT_BIND_CARD_NO,'') -- 电子账户绑定卡号 非主键字段相等
         AND COALESCE(TM.VOCH_NO,'') = COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段相等
         AND COALESCE(TM.MED_TYPE_CD,'') = COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段相等
         AND COALESCE(TM.REPLOS_STATUS_CD,'') = COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段相等
         AND COALESCE(TM.FRZ_STATUS_CD,'') = COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段相等
         AND COALESCE(TM.STOP_PAY_STATUS_CD,'') = COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段相等
         AND COALESCE(TM.REDT_FLAG,'') = COALESCE(BF.REDT_FLAG,'') -- 转存标志 非主键字段相等
         AND COALESCE(TM.AUTO_REDT_IDNT_CD,'') = COALESCE(BF.AUTO_REDT_IDNT_CD,'') -- 自动转存标识代码 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.AGREE_FLAG,'') = COALESCE(BF.AGREE_FLAG,'') -- 协定标志 非主键字段相等
         AND COALESCE(TM.PLEDGE_FLAG,'') = COALESCE(BF.PLEDGE_FLAG,'') -- 质押标志 非主键字段相等
         AND COALESCE(TM.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) = COALESCE(BF.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) -- 部支或违约次数 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段相等
         AND COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段相等
         AND COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段相等
         AND COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段相等
         AND COALESCE(TM.INT_FREE_TAX_FLAG,'') = COALESCE(BF.INT_FREE_TAX_FLAG,'') -- 豁免利息税标志 非主键字段相等
         AND COALESCE(TM.INTACR_MODE_CD,'') = COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段相等
         AND COALESCE(TM.INTACR_BASE_CD,'') = COALESCE(BF.INTACR_BASE_CD,'') -- 计息基础代码 非主键字段相等
         AND COALESCE(TM.INT_TAX,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 利息税 非主键字段相等
         AND COALESCE(TM.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) -- 利息应税金额 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段相等
         AND COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) = COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') = COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段相等
         AND COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') = COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段相等
         AND COALESCE(TM.MNYITM_SRC_CD,'') = COALESCE(BF.MNYITM_SRC_CD,'') -- 款项来源代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM,'') = COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TELR,'') = COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段相等
         AND COALESCE(TM.VAL_DT,'') = COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段相等
         AND COALESCE(TM.MATU_DT,'') = COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段相等
         AND COALESCE(TM.FINAL_TXN_DT,'') = COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段相等
         AND COALESCE(TM.PAYOFF_DT,'') = COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段相等
         AND COALESCE(TM.NEXT_CAN_DRAW_DT,'') = COALESCE(BF.NEXT_CAN_DRAW_DT,'') -- 下次可支取日期 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_CHNL_CD,'') = COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_CHNL,'') = COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_ORG_NO,'') = COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TELR_NO,'') = COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.INDV_CORP_IDNT_CD,'') <> COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.MAIN_DOCTYP_CD,'') <> COALESCE(BF.MAIN_DOCTYP_CD,'') -- 主证件类型代码 非主键字段不相等
         OR COALESCE(TM.MAIN_DOC_NO,'') <> COALESCE(BF.MAIN_DOC_NO,'') -- 主证件号码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') <> COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOC_NO,'') <> COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段不相等
         OR COALESCE(TM.FX_ACCT_PROPTY_CD,'') <> COALESCE(BF.FX_ACCT_PROPTY_CD,'') -- 外汇账户性质代码 非主键字段不相等
         OR COALESCE(TM.FX_CUST_TYPE_CD,'') <> COALESCE(BF.FX_CUST_TYPE_CD,'') -- 外汇客户类别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段不相等
         OR COALESCE(TM.ACCT_TYPE_CD,'') <> COALESCE(BF.ACCT_TYPE_CD,'') -- 账户类型代码 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.MRGACCT_FLAG,'') <> COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段不相等
         OR COALESCE(TM.ACCT_STATUS_CD,'') <> COALESCE(BF.ACCT_STATUS_CD,'') -- 账户状态代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') <> COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_CD,'') <> COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_NAME,'') <> COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_CD,'') <> COALESCE(BF.DPSIT_COMB_PROD_CD,'') -- 存款组合产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_COMB_PROD_NAME,'') <> COALESCE(BF.DPSIT_COMB_PROD_NAME,'') -- 存款组合产品名称 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.MRG_BIZ_CATE_CD,'') <> COALESCE(BF.MRG_BIZ_CATE_CD,'') -- 保证金业务种类代码 非主键字段不相等
         OR COALESCE(TM.AGREE_REDT_ACCT_NO,'') <> COALESCE(BF.AGREE_REDT_ACCT_NO,'') -- 约定转存账户编号 非主键字段不相等
         OR COALESCE(TM.ORIG_DPSIT_TERM,'') <> COALESCE(BF.ORIG_DPSIT_TERM,'') -- 原始存款期限 非主键字段不相等
         OR COALESCE(TM.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) <> COALESCE(BF.DPSIT_PERIOD_DAYS,CAST(0 AS BIGINT)) -- 存期天数 非主键字段不相等
         OR COALESCE(TM.EACCT_NO,'') <> COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') <> COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') <> COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段不相等
         OR COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') <> COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段不相等
         OR COALESCE(TM.ALL_IN_ONE_PSBOOK_ACCT_NO,'') <> COALESCE(BF.ALL_IN_ONE_PSBOOK_ACCT_NO,'') -- 一本通账号 非主键字段不相等
         OR COALESCE(TM.EACCT_BIND_CARD_NO,'') <> COALESCE(BF.EACCT_BIND_CARD_NO,'') -- 电子账户绑定卡号 非主键字段不相等
         OR COALESCE(TM.VOCH_NO,'') <> COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段不相等
         OR COALESCE(TM.MED_TYPE_CD,'') <> COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段不相等
         OR COALESCE(TM.REPLOS_STATUS_CD,'') <> COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段不相等
         OR COALESCE(TM.FRZ_STATUS_CD,'') <> COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_STATUS_CD,'') <> COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段不相等
         OR COALESCE(TM.REDT_FLAG,'') <> COALESCE(BF.REDT_FLAG,'') -- 转存标志 非主键字段不相等
         OR COALESCE(TM.AUTO_REDT_IDNT_CD,'') <> COALESCE(BF.AUTO_REDT_IDNT_CD,'') -- 自动转存标识代码 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.AGREE_FLAG,'') <> COALESCE(BF.AGREE_FLAG,'') -- 协定标志 非主键字段不相等
         OR COALESCE(TM.PLEDGE_FLAG,'') <> COALESCE(BF.PLEDGE_FLAG,'') -- 质押标志 非主键字段不相等
         OR COALESCE(TM.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) <> COALESCE(BF.DEPT_OR_DEFLT_TMS,CAST(0 AS BIGINT)) -- 部支或违约次数 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.OPEN_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 开户金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段不相等
         OR COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段不相等
         OR COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段不相等
         OR COALESCE(TM.INT_FREE_TAX_FLAG,'') <> COALESCE(BF.INT_FREE_TAX_FLAG,'') -- 豁免利息税标志 非主键字段不相等
         OR COALESCE(TM.INTACR_MODE_CD,'') <> COALESCE(BF.INTACR_MODE_CD,'') -- 计息方式代码 非主键字段不相等
         OR COALESCE(TM.INTACR_BASE_CD,'') <> COALESCE(BF.INTACR_BASE_CD,'') -- 计息基础代码 非主键字段不相等
         OR COALESCE(TM.INT_TAX,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.INT_TAX,CAST(0 AS DECIMAL(28,2))) -- 利息税 非主键字段不相等
         OR COALESCE(TM.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.INT_TXBL_AMT,CAST(0 AS DECIMAL(28,2))) -- 利息应税金额 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.OPEN_ACCT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 开户利率 非主键字段不相等
         OR COALESCE(TM.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.BNCHMK_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 基准利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) <> COALESCE(BF.FLOT_INT_RATE,CAST(0 AS DECIMAL(20,7))) -- 浮动利率 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_PERIOD_CD,'') <> COALESCE(BF.FLOT_INT_RATE_PERIOD_CD,'') -- 浮动利率周期代码 非主键字段不相等
         OR COALESCE(TM.FLOT_INT_RATE_TYPE_CD,'') <> COALESCE(BF.FLOT_INT_RATE_TYPE_CD,'') -- 浮动利率类型代码 非主键字段不相等
         OR COALESCE(TM.MNYITM_SRC_CD,'') <> COALESCE(BF.MNYITM_SRC_CD,'') -- 款项来源代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM,'') <> COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TELR,'') <> COALESCE(BF.OPEN_ACCT_TELR,'') -- 开户柜员 非主键字段不相等
         OR COALESCE(TM.VAL_DT,'') <> COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段不相等
         OR COALESCE(TM.MATU_DT,'') <> COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段不相等
         OR COALESCE(TM.FINAL_TXN_DT,'') <> COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段不相等
         OR COALESCE(TM.PAYOFF_DT,'') <> COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段不相等
         OR COALESCE(TM.NEXT_CAN_DRAW_DT,'') <> COALESCE(BF.NEXT_CAN_DRAW_DT,'') -- 下次可支取日期 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_CHNL_CD,'') <> COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_CHNL,'') <> COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_ORG_NO,'') <> COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TELR_NO,'') <> COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 主键字段关联
    AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 主键字段关联
    AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_TM;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_01;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_02;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_03;
DROP TABLE AGL${version_num}.TMP_AGL_INDV_RGL_DPSIT_ACCT_INFO_TF_04;
