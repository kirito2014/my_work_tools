-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-银联对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：银联对账差错明细聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：UNPY_CLEAR_DT, UNPY_TXN_TM_STAMP, TXN_TYPE_CD, MSG_TYPE_CD, AGEN_TXN_UNPY_ORG_NO, SEND_TXN_UNPY_ORG_NO, SYS_TRACK_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-16 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM
USING ORC
COMMENT '银联对账差错明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     UNPY_CLEAR_DT -- 银联清算日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,TXN_TYPE_CD -- 交易类型代码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TRANS_CODE -- 交易编码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,ERR_NO -- 差错编号
    ,ERR_TYPE_CD -- 差错类型代码
    ,UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,REM -- 备注
    ,CORE_ACCTN_DT -- 核心会计日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 银联对账差错明细聚合

INSERT INTO TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM(
     UNPY_CLEAR_DT -- 银联清算日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,TXN_TYPE_CD -- 交易类型代码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TRANS_CODE -- 交易编码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,ERR_NO -- 差错编号
    ,ERR_TYPE_CD -- 差错类型代码
    ,UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,REM -- 备注
    ,CORE_ACCTN_DT -- 核心会计日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.UNION_SETTLE_DT) AS UNPY_CLEAR_DT -- 银联清算日期
    ,unifiedTime1(P1.UNION_TRANS_DT_TM) AS UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,P1.TRANS_TP_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.MSG_TP AS MSG_TYPE_CD -- 报文类型代码
    ,P1.ACQ_INS_ID_CD AS AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,P1.FWD_INS_ID_CD AS SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,P1.SYS_TRA_NUMBER AS SYS_TRACK_NO -- 系统跟踪号
    ,unifiedTime(P1.ERROR_GENERATE_DT) AS ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,unifiedTime(P1.ORIG_TRANS_DT_TM) AS ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,P1.PRI_ACCOUNT_NUMBER AS TXN_CARD_NO -- 交易卡片编号
    ,P1.TRANS_CARD_NO_BELONG_ORG AS BELONG_ORG_NO -- 归属机构编号
    ,P1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,P1.TRANS_CURRENCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRANS_MARK AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.TRANS_CODE AS TXN_TRANS_CODE -- 交易编码
    ,P1.BUSINESS_CHANNEL AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.TERM_ID AS EQUIP_NO -- 设备编号
    ,P1.BUSI_TYPE AS UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,P1.MCHNT_TP AS MERCHT_MCC_CD -- 商户MCC代码
    ,P1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,P1.MCHNT_NAME_ADRESS AS MERCHT_NAME -- 商户名称
    ,P1.ORDER_ID AS ORDER_SER_NO -- 订单流水号
    ,P1.RCV_INS_ID_CD AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,P1.ISS_INS_ID_CD AS CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,P1.ORIG_SYS_TRA_NUMBER AS ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,P1.RETR_REF_NO AS RETRIV_REF_NO -- 检索参考号
    ,P1.POS_COND_CD AS SERV_POINT_COND_CD -- 服务点条件代码
    ,P1.TFR_OUT_ORG_ID AS TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,P1.TFR_OUT_ORG_NO AS TRNOUT_ORG_NO -- 转出机构编号
    ,P1.TFR_OUT_CARD_NUMBER AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,P1.TFR_IN_ORG_ID AS TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,P1.TFR_IN_ORG_NO AS TRNIN_ORG_NO -- 转入机构编号
    ,P1.TFR_IN_CARD_NUMBER AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,P1.AUTH_RESP_CD AS AUTH_ANSWER_CD -- 授权应答码
    ,P1.SERV_INPUT_WAY AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,P1.TERM_TP AS TERMN_TYPE_CD -- 终端类型代码
    ,P1.TRANS_AREA_ID AS TXN_RGN_CD -- 交易地区代码
    ,unifiedTime(P1.SETTLE_DT) AS CLEAR_DT -- 清算日期
    ,P1.SETTLE_PERIOD AS CLEAR_PERIOD_DESC -- 清算周期描述
    ,P1.SETTLE_AMOUNT AS CLEAR_AMT -- 清算金额
    ,P1.SETTLE_EXCH_RATE AS CLEAR_EXCH_RATE -- 清算汇率
    ,P1.CARD_HOLDER_TRANS_COMMISSION AS CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,P1.ACQ_REC_COMMISSION AS RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,P1.ACQ_PAY_COMMISSION AS RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,P1.TRANS_SERV_CHARGE_AMOUNT AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,P1.MCHNT_COMMISSION AS ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,P1.INNER_COMMISSION AS IN_BANK_COMM_FEE -- 行内手续费
    ,P1.INSTALLMENT_SERVICE_CHARGE AS INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,P1.ADJUST_MODE AS ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,P1.BATCH_FLAG AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,P1.INTEGRATE_ID AS ERR_NO -- 差错编号
    ,P1.ERROR_TYPE AS ERR_TYPE_CD -- 差错类型代码
    ,P1.ERROR_NAME AS UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,P1.DEAL_STATE AS UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,P1.FAIL_REASON AS CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,P1.UNION_FILE_TP AS UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,P1.FILE_SOURCE AS DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,P1.REMARK AS REM -- 备注
    ,unifiedTime(P1.TRANS_DT) AS CORE_ACCTN_DT -- 核心会计日期
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_CC_ACCOUNT_UNIONTOAS400_ERROR_DATA_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT.ODS_CCPT_CC_ACCOUNT_UNIONTOAS400_ERROR_DATA_TA AS P1 -- 银联核心对账差错数据表

WHERE P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 银联对账差错明细聚合

INSERT INTO TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM(
     UNPY_CLEAR_DT -- 银联清算日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,TXN_TYPE_CD -- 交易类型代码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TRANS_CODE -- 交易编码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,ERR_NO -- 差错编号
    ,ERR_TYPE_CD -- 差错类型代码
    ,UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,REM -- 备注
    ,CORE_ACCTN_DT -- 核心会计日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.UNION_SETTLE_DT) AS UNPY_CLEAR_DT -- 银联清算日期
    ,unifiedTime1(P1.UNION_TRANS_DT_TM) AS UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,P1.TRANS_TP_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.MSG_TP AS MSG_TYPE_CD -- 报文类型代码
    ,P1.ACQ_INS_ID_CD AS AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,P1.FWD_INS_ID_CD AS SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,P1.SYS_TRA_NUMBER AS SYS_TRACK_NO -- 系统跟踪号
    ,unifiedTime(P1.ERROR_GENERATE_DT) AS ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,unifiedTime1(P1.ORIG_TRANS_DT_TM) AS ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,P1.PRI_ACCOUNT_NUMBER AS TXN_CARD_NO -- 交易卡片编号
    ,P1.TRANS_CARD_NO_BELONG_ORG AS BELONG_ORG_NO -- 归属机构编号
    ,P1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,P1.TRANS_CURRENCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRANS_MARK AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.TRANS_CODE AS TXN_TRANS_CODE -- 交易编码
    ,P1.ANALYZE_CHANNEL AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.TERM_ID AS EQUIP_NO -- 设备编号
    ,P1.BUSI_TYPE AS UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,P1.MCHNT_TP AS MERCHT_MCC_CD -- 商户MCC代码
    ,P1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,P1.MCHNT_NAME_ADRESS AS MERCHT_NAME -- 商户名称
    ,P1.ORDER_ID AS ORDER_SER_NO -- 订单流水号
    ,P1.RCV_INS_ID_CD AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,P1.ISS_INS_ID_CD AS CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,P1.ORIG_SYS_TRA_NUMBER AS ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,P1.RETR_REF_NO AS RETRIV_REF_NO -- 检索参考号
    ,P1.POS_COND_CD AS SERV_POINT_COND_CD -- 服务点条件代码
    ,P1.TFR_OUT_ORG_ID AS TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,P1.TFR_OUT_ORG_NO AS TRNOUT_ORG_NO -- 转出机构编号
    ,P1.TFR_OUT_CARD_NUMBER AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,P1.TFR_IN_ORG_ID AS TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,P1.TFR_IN_ORG_NO AS TRNIN_ORG_NO -- 转入机构编号
    ,P1.TFR_IN_CARD_NUMBER AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,P1.AUTH_RESP_CD AS AUTH_ANSWER_CD -- 授权应答码
    ,P1.SERV_INPUT_WAY AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,P1.TERM_TP AS TERMN_TYPE_CD -- 终端类型代码
    ,P1.TRANS_AREA_ID AS TXN_RGN_CD -- 交易地区代码
    ,unifiedTime(P1.SETTLE_DT) AS CLEAR_DT -- 清算日期
    ,P1.SETTLE_PERIOD AS CLEAR_PERIOD_DESC -- 清算周期描述
    ,P1.SETTLE_AMOUNT AS CLEAR_AMT -- 清算金额
    ,P1.SETTLE_EXCH_RATE AS CLEAR_EXCH_RATE -- 清算汇率
    ,P1.CARD_HOLDER_TRANS_COMMISSION AS CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,P1.ACQ_REC_COMMISSION AS RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,P1.ACQ_PAY_COMMISSION AS RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,P1.TRANS_SERV_CHARGE_AMOUNT AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,P1.MCHNT_COMMISSION AS ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,P1.INNER_COMMISSION AS IN_BANK_COMM_FEE -- 行内手续费
    ,P1.INSTALLMENT_SERVICE_CHARGE AS INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,P1.ADJUST_MODE AS ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,P1.BATCH_FLAG AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,P1.INTEGRATE_ID AS ERR_NO -- 差错编号
    ,P1.ERROR_TYPE AS ERR_TYPE_CD -- 差错类型代码
    ,P1.ERROR_NAME AS UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,P1.DEAL_STATE AS UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,P1.FAIL_REASON AS CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,P1.UNION_FILE_TP AS UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,P1.FILE_SOURCE AS DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,P1.REMARK AS REM -- 备注
    ,unifiedTime(P1.TRANS_DT) AS CORE_ACCTN_DT -- 核心会计日期
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_CC_ACCOUNT_UNIONNETWORK_ERROR_DATA_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT.ODS_CCPT_CC_ACCOUNT_UNIONNETWORK_ERROR_DATA_TA AS P1 -- 银联网络核心对账差错数据表

WHERE P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 银联对账差错明细聚合

INSERT INTO TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM(
     UNPY_CLEAR_DT -- 银联清算日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,TXN_TYPE_CD -- 交易类型代码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TRANS_CODE -- 交易编码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,ERR_NO -- 差错编号
    ,ERR_TYPE_CD -- 差错类型代码
    ,UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,REM -- 备注
    ,CORE_ACCTN_DT -- 核心会计日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.UNION_SETTLE_DT) AS UNPY_CLEAR_DT -- 银联清算日期
    ,unifiedTime1(P1.UNION_ORIG_DT_TM) AS UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,P1.TRANS_TP_CD AS TXN_TYPE_CD -- 交易类型代码
    ,P1.MSG_TP AS MSG_TYPE_CD -- 报文类型代码
    ,P1.ACQ_INS_ID_CD AS AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,P1.FWD_INS_ID_CD AS SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,P1.SYS_TRA_NUMBER AS SYS_TRACK_NO -- 系统跟踪号
    ,unifiedTime(P1.ERROR_GENERATE_DT) AS ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,unifiedTime1(P1.PREP_TRANS_DT_TM) AS ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,P1.PRI_ACCOUNT_NUMBER AS TXN_CARD_NO -- 交易卡片编号
    ,P1.TRANS_CARD_NO_BELONG_ORG AS BELONG_ORG_NO -- 归属机构编号
    ,P1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,P1.TRANS_CURRENCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.TRANS_MARK AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.TRANS_CODE AS TXN_TRANS_CODE -- 交易编码
    ,P1.ANALYZE_CHANNEL AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.TERM_ID AS EQUIP_NO -- 设备编号
    ,'' AS UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,P1.MCHNT_TP AS MERCHT_MCC_CD -- 商户MCC代码
    ,P1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,'' AS CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,P1.ORIG_SYS_TRA_NUMBER AS ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,'' AS RETRIV_REF_NO -- 检索参考号
    ,'' AS SERV_POINT_COND_CD -- 服务点条件代码
    ,'' AS TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,P1.TFR_OUT_ORG_NO AS TRNOUT_ORG_NO -- 转出机构编号
    ,P1.TFR_OUT_CARD_NUMBER AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,'' AS TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,P1.TFR_IN_ORG_NO AS TRNIN_ORG_NO -- 转入机构编号
    ,P1.TFR_IN_CARD_NUMBER AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,P1.AUTH_RESP_CD AS AUTH_ANSWER_CD -- 授权应答码
    ,'' AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,P1.UNION_TERM_TP AS TERMN_TYPE_CD -- 终端类型代码
    ,'' AS TXN_RGN_CD -- 交易地区代码
    ,'' AS CLEAR_DT -- 清算日期
    ,'' AS CLEAR_PERIOD_DESC -- 清算周期描述
    ,'' AS CLEAR_AMT -- 清算金额
    ,'' AS CLEAR_EXCH_RATE -- 清算汇率
    ,'' AS CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,'' AS RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,'' AS RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,P1.INNER_COMMISSION AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,P1.ADJUST_MODE AS ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,P1.BATCH_FLAG AS BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,P1.INTEGRATE_ID AS ERR_NO -- 差错编号
    ,P1.ERROR_TYPE AS ERR_TYPE_CD -- 差错类型代码
    ,P1.ERROR_NAME AS UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,P1.DEAL_STATE AS UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,P1.FAIL_REASON AS CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,'' AS UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,'' AS DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,P1.REMARK AS REM -- 备注
    ,unifiedTime(P1.CREDIT_TRANS_DT) AS CORE_ACCTN_DT -- 核心会计日期
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_CC_ACCOUNT_UNIONCREDIT_ERROR_DATA_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT.ODS_CCPT_CC_ACCOUNT_UNIONCREDIT_ERROR_DATA_TA AS P1 -- 银联贷记卡对账差错表

WHERE P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     UNPY_CLEAR_DT -- 银联清算日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,TXN_TYPE_CD -- 交易类型代码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_TXN_UNPY_ORG_NO -- 发送交易银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,ERR_DATA_CREATE_DT -- 差错数据生成日期
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TRANS_CODE -- 交易编码
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,UNPY_TXN_BIZ_TYPE_CD -- 银联交易业务类型代码
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,ACOMA_MERCHT_COMM_FEE -- ACOMA商户手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_ADDIT_COMM_FEE -- 分期付款附加手续费
    ,ADJ_ENTRY_MODE_CD -- 调账方式代码
    ,BAT_SINGLE_IDNT_CD -- 批量单笔标识代码
    ,ERR_NO -- 差错编号
    ,ERR_TYPE_CD -- 差错类型代码
    ,UNPY_ERR_DEAL_STATUS_CD -- 银联差错处理状态代码
    ,UNPY_DEAL_STATUS_CD -- 银联处理状态代码
    ,CENTR_FAIL_RSN_DESC -- 集中失败原因描述
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,REM -- 备注
    ,CORE_ACCTN_DT -- 核心会计日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_UNPY_CHECK_ENTRY_ERR_DTL_TA_TM;
