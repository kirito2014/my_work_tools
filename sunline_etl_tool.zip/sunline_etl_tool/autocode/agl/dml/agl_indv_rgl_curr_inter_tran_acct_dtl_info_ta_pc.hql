-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人定活互转账户明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA
--     表中文名：个人定活互转账户明细聚合
--     创建日期：2024-07-23 00:00:00
--     主键字段：CURR_ACCT_NO, RGL_DPSIT_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-07-23 00:00:00 陈艺丹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA_TM
USING ORC
COMMENT '个人定活互转账户明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CURR_ACCT_NO -- 活期账户编号
    ,RGL_ACCT_NO -- 定期账户编号
    ,EXCH_GATHER_ACCT_MAIN_ACCT_NO -- 汇集户主账户编号
    ,SIGN_CARD_NO -- 签约卡号
    ,RGL_DPSIT_SER_NO -- 定期存款序号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,BIZ_SUBCLS_CD -- 业务细类代码
    ,RGL_ACCT_STATUS_CD -- 定期账户状态代码
    ,DPSIT_PERIOD -- 存期
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FIRST_TXN_TRNOUT_DT -- 首笔转出日期
    ,END_TXN_TURN_BACK_MV_OUT_DT -- 末笔转回移出日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,OPEN_ACCT_AMT -- 开户金额
    ,CURR_BAL -- 当前余额
    ,TURN_BACK_AMT -- 转回金额
    ,TURN_BACK_INT -- 转回利息
    ,AUTO_REDT_FLAG -- 自动转存标志
    ,RELA_ACCT_CANC_ACCT_FLAG -- 关联账户销户标志
    ,REC_STATUS_CD -- 记录状态代码
    ,CURR_EFFECT_CNT -- 当前有效笔数
    ,TURN_BACK_TOTAL_CNT -- 转回总笔数
    ,MV_OUT_TOTAL_CNT -- 移出总笔数
    ,LP_ORG_NO -- 法人机构编号
    ,BELONG_BNKOUTLS_ORG_NO -- 归属网点机构编号
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人定活互转账户明细聚合

INSERT INTO TABLE AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA_TM(
     CURR_ACCT_NO -- 活期账户编号
    ,RGL_ACCT_NO -- 定期账户编号
    ,EXCH_GATHER_ACCT_MAIN_ACCT_NO -- 汇集户主账户编号
    ,SIGN_CARD_NO -- 签约卡号
    ,RGL_DPSIT_SER_NO -- 定期存款序号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,BIZ_SUBCLS_CD -- 业务细类代码
    ,RGL_ACCT_STATUS_CD -- 定期账户状态代码
    ,DPSIT_PERIOD -- 存期
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FIRST_TXN_TRNOUT_DT -- 首笔转出日期
    ,END_TXN_TURN_BACK_MV_OUT_DT -- 末笔转回移出日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,OPEN_ACCT_AMT -- 开户金额
    ,CURR_BAL -- 当前余额
    ,TURN_BACK_AMT -- 转回金额
    ,TURN_BACK_INT -- 转回利息
    ,AUTO_REDT_FLAG -- 自动转存标志
    ,RELA_ACCT_CANC_ACCT_FLAG -- 关联账户销户标志
    ,REC_STATUS_CD -- 记录状态代码
    ,CURR_EFFECT_CNT -- 当前有效笔数
    ,TURN_BACK_TOTAL_CNT -- 转回总笔数
    ,MV_OUT_TOTAL_CNT -- 移出总笔数
    ,LP_ORG_NO -- 法人机构编号
    ,BELONG_BNKOUTLS_ORG_NO -- 归属网点机构编号
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.FU01AC15 AS CURR_ACCT_NO -- 活期账户编号
    ,P1.FU03AC15 AS RGL_ACCT_NO -- 定期账户编号
    ,P1.FU02AC15 AS EXCH_GATHER_ACCT_MAIN_ACCT_NO -- 汇集户主账户编号
    ,P2.FT01AC19 AS SIGN_CARD_NO -- 签约卡号
    ,P1.FU04SN08 AS RGL_DPSIT_SER_NO -- 定期存款序号
    ,P1.FU05CCYC AS CURR_CD -- 币种代码
    ,P1.FU06CHSX AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN CONCAT(P1.FU07PDTP,P1.FU08PRON) IS NULL OR TRIM(CONCAT(P1.FU07PDTP,P1.FU08PRON))='' THEN '' 
ELSE COALESCE(TRIM(M1.TARGET_CD_VAL), '@'||TRIM(CONCAT(P1.FU07PDTP,P1.FU08PRON)),'') END AS BIZ_SUBCLS_CD -- 业务细类代码
    ,P1.FU09ACST AS RGL_ACCT_STATUS_CD -- 定期账户状态代码
    ,P1.FU11SN03 AS DPSIT_PERIOD -- 存期
    ,unifiedTime(P1.FU12DATE) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P1.FU13DATE) AS VAL_DT -- 起息日期
    ,unifiedTime(P1.FU14DATE) AS MATU_DT -- 到期日期
    ,unifiedTime(P2.FT06DATE) AS FIRST_TXN_TRNOUT_DT -- 首笔转出日期
    ,unifiedTime(P2.FT07DATE) AS END_TXN_TURN_BACK_MV_OUT_DT -- 末笔转回移出日期
    ,unifiedTime(P1.FU15DATE) AS FINAL_TXN_DT -- 最后交易日期
    ,P1.FU16AMT AS OPEN_ACCT_AMT -- 开户金额
    ,P1.FU17BAL AS CURR_BAL -- 当前余额
    ,P1.FU20AMT AS TURN_BACK_AMT -- 转回金额
    ,P1.FU21AMT AS TURN_BACK_INT -- 转回利息
    ,P1.FU10FLAG AS AUTO_REDT_FLAG -- 自动转存标志
    ,P2.FT20ZHZT AS RELA_ACCT_CANC_ACCT_FLAG -- 关联账户销户标志
    ,CASE WHEN P1.RCSTRS1B IS NULL OR TRIM(P1.RCSTRS1B)=''
     THEN ''
     ELSE COALESCE(TRIM(M2.TARGET_CD_VAL), '@'||TRIM(P1.RCSTRS1B),'')
END AS REC_STATUS_CD -- 记录状态代码
    ,P2.FT08SN08 AS CURR_EFFECT_CNT -- 当前有效笔数
    ,P2.FT10SN08 AS TURN_BACK_TOTAL_CNT -- 转回总笔数
    ,P2.FT12SN08 AS MV_OUT_TOTAL_CNT -- 移出总笔数
    ,P1.FU19BRNO AS LP_ORG_NO -- 法人机构编号
    ,P1.FU18BRNO AS BELONG_BNKOUTLS_ORG_NO -- 归属网点机构编号
    ,P2.FT19BRNO AS HANDLE_ORG_NO -- 经办机构编号
    ,P2.FT18STAF AS HANDLE_TELR_NO -- 经办柜员编号
    ,unifiedTime(P1.BUDIDATE) AS SETUP_DT -- 建立日期
    ,unifiedTime(P1.BUTSSTAM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.BUTPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.UPDTDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPTSSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.UPOPSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQFU_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE.ODS_CORE_BDFMHQFU_TF AS P1 -- 定活互转定期状态登记簿

LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQFT_TF AS P2 -- 定活互转信息登记表
       ON P1.FU01AC15=P2.FT02AC15 AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN AGL.PUB_CD_MAP AS M1 -- 码值表
       ON CONCAT(P1.FU07PDTP,P1.FU08PRON)=M1.SRC_CD_VAL  
AND M1.SRC_TAB_LIB_NAME ='BODTALIBP'  --源系统 简称或中文名 待定
AND M1.SRC_TAB_EN_NAME='BDFMHQFU' --来源表英文名 大写
AND M1.SRC_FIELD_EN_NAME='FU07PDTP||FU08PRON' --来源字段英文名 大写
AND M1.TARGET_TAB_EN_NAME='AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA'--目标表名 大写
AND M1.TARGET_FIELD_EN_NAME='BIZ_SUBCLS_CD' --目标字段 大写 
LEFT JOIN AGL.PUB_CD_MAP AS M2 -- 码值表
       ON TRIM(P1.RCSTRS1B)=M2.SRC_CD_VAL  
AND M2.SRC_TAB_LIB_NAME ='BODTALIBP'  --源系统 简称或中文名 待定
AND M2.SRC_TAB_EN_NAME='BDFMHQFU' --来源表英文名 大写
AND M2.SRC_FIELD_EN_NAME='RCSTRS1B' --来源字段英文名 大写
AND M2.TARGET_TAB_EN_NAME='AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA'--目标表名 大写
AND M2.TARGET_FIELD_EN_NAME='REC_STATUS_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND SUBSTR(P1.FU01AC15,1,3)='101'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA PARTITION(PT_DT = '${process_date}')
SELECT
     CURR_ACCT_NO -- 活期账户编号
    ,RGL_ACCT_NO -- 定期账户编号
    ,EXCH_GATHER_ACCT_MAIN_ACCT_NO -- 汇集户主账户编号
    ,SIGN_CARD_NO -- 签约卡号
    ,RGL_DPSIT_SER_NO -- 定期存款序号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,BIZ_SUBCLS_CD -- 业务细类代码
    ,RGL_ACCT_STATUS_CD -- 定期账户状态代码
    ,DPSIT_PERIOD -- 存期
    ,OPEN_ACCT_DT -- 开户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,FIRST_TXN_TRNOUT_DT -- 首笔转出日期
    ,END_TXN_TURN_BACK_MV_OUT_DT -- 末笔转回移出日期
    ,FINAL_TXN_DT -- 最后交易日期
    ,OPEN_ACCT_AMT -- 开户金额
    ,CURR_BAL -- 当前余额
    ,TURN_BACK_AMT -- 转回金额
    ,TURN_BACK_INT -- 转回利息
    ,AUTO_REDT_FLAG -- 自动转存标志
    ,RELA_ACCT_CANC_ACCT_FLAG -- 关联账户销户标志
    ,REC_STATUS_CD -- 记录状态代码
    ,CURR_EFFECT_CNT -- 当前有效笔数
    ,TURN_BACK_TOTAL_CNT -- 转回总笔数
    ,MV_OUT_TOTAL_CNT -- 移出总笔数
    ,LP_ORG_NO -- 法人机构编号
    ,BELONG_BNKOUTLS_ORG_NO -- 归属网点机构编号
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_RGL_CURR_INTER_TRAN_ACCT_DTL_INFO_TA_TM;
