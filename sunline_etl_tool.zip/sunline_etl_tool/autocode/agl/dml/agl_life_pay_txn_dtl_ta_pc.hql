-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-生活缴费交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_TXN_DTL_TA
--     表中文名：生活缴费交易明细聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM
USING ORC
COMMENT '生活缴费交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_01 WHERE PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第2组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_02 WHERE PT_DT = '${process_date}'
;

-- ==============聚合层字段映射（第3组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_03 WHERE PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第4组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_04 WHERE PT_DT = '${process_date}'
;


/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM;
