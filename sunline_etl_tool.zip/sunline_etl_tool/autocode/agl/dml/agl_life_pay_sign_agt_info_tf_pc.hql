-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-生活缴费签约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_SIGN_AGT_INFO_TF
--     表中文名：生活缴费签约协议信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：SIGN_ISNO,AGT_NO, THIRD_PTY_USER_NO, BIZ_UNIT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改中间业务库名，增加95组
--         2024-09-10 00:00:00 魏丹丹 新增字段：摘要代码，修改客户内码/签约账户开户机构编号 的取数逻辑，增加1组
--         2024-10-17 00:00:00 魏丹丹 拆分生活缴费签约协议信息聚合



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM
USING ORC
COMMENT '生活缴费签约协议信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     SIGN_ISNO -- 签约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PLAT_DT -- 平台日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SUMMARY_CD -- 摘要代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 生活缴费签约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM(
     SIGN_ISNO -- 签约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,PLAT_DT -- 平台日期
    ,MGMT_ORG_NO -- 管理机构编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.SIGN_ISNO AS SIGN_ISNO -- 签约自增序号
    ,P1.AGT_NO AS AGT_NO -- 协议编号
    ,P1.THIRD_PTY_AGT_NO AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,P1.CONT_CENTER_AGT_NO AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,P1.AGT_EFFECT_DT AS AGT_EFFECT_DT -- 协议生效日期
    ,P1.AGT_EXPIR_DT AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.PAY_START_TM_STAMP AS PAY_START_TM_STAMP -- 缴费开始时间戳
    ,P1.BIZ_UNIT_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.BIZ_UNIT_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.PROD_NO AS PROD_NO -- 产品编号
    ,P1.PROD_NAME AS PROD_NAME -- 产品名称
    ,P1.MDL_BIZ_CATE_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.MDL_BIZ_CATE_NAME AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,P1.MDL_BIZ_MDL_CATOGR_NO AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,P1.MDL_BIZ_MDL_CATOGR_NAME AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,P1.MDL_BIZ_SUB_CLS_CD AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,P1.LIFE_PAY_BIZ_CATEGORY_CD AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,P1.PAY_PROJ_NO AS PAY_PROJ_NO -- 缴费项目编号
    ,P1.PAY_PROJ_NAME AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.THIRD_PTY_USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.THIRD_PTY_USER_DOCTYP_CD AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,P1.THIRD_PTY_USER_DOC_NO AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,P1.THIRD_PTY_USER_CONT_ADDR AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,P1.THIRD_PTY_USER_CONT_NO_NO AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.CONT_NO_NO AS CONT_NO_NO -- 联系电话号码
    ,P1.CONT_ADDR AS CONT_ADDR -- 联系地址
    ,P1.POST_CD AS POST_CD -- 邮政编码
    ,P1.SIGN_AGENT_NAME AS SIGN_AGENT_NAME -- 签约代理人名称
    ,P1.SIGN_AGENT_DOCTYP_CD AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,P1.SIGN_AGENT_DOC_NO AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,P1.SIGN_AGENT_CONT_NO_NO AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_PUB_PRIV_TYPE_CD AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_DISCNT_IDNT_CD AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,P1.LIFE_PAY_MED_TYPE_CD AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,P1.TXN_PWD AS TXN_PWD -- 交易密码
    ,P1.SIGN_ACCT_OPEN_ACCT_ORG_NO AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P1.SIGN_ACCT_OPBANK_CNAPS_CODE AS SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,P1.SINGLE_LMT AS SINGLE_LMT -- 单笔限额
    ,P1.DAILY_ACCUM_LMT AS DAILY_ACCUM_LMT -- 日累计限额
    ,P1.MONTHLY_ACCUM_LMT AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,P1.YEAR_CUM_LMT AS YEAR_CUM_LMT -- 年累计限额
    ,P1.SIGN_TYPE_CD AS SIGN_TYPE_CD -- 签约类型代码
    ,P1.SIGN_CHNL_CD AS SIGN_CHNL_CD -- 签约渠道代码
    ,P1.SIGN_SER_NO AS SIGN_SER_NO -- 签约序号
    ,P1.SIGN_CONTR_DT AS SIGN_CONTR_DT -- 签约日期
    ,P1.SIGN_TM_STAMP AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_ORG_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELR_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_UPDATE_TM_STAMP AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.RECNT_MODIF_ORG_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.LIFE_PAY_AGT_STATUS_CD AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,P1.CONT_CENTER_AGT_STATUS_CD AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.LIFE_PAY_SIGN_SYS_CD AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,P1.REM AS REM -- 备注
    ,P1.SIGN_RESLT_DESC AS SIGN_RESLT_DESC -- 签约结果描述
    ,P1.REC_LOCK_FLAG AS REC_LOCK_FLAG -- 记录锁定标志
    ,P1.VER_NO AS VER_NO -- 版本编号
    ,P1.PLAT_DT AS PLAT_DT -- 平台日期
    ,P1.MGMT_ORG_NO AS MGMT_ORG_NO -- 管理机构编号
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,P1.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,P1.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_01_TF AS P1 -- 生活缴费签约协议信息聚合01

WHERE P1.PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第3组）==============
-- 生活缴费签约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM(
     SIGN_ISNO -- 签约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,PLAT_DT -- 平台日期
    ,MGMT_ORG_NO -- 管理机构编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.SIGN_ISNO AS SIGN_ISNO -- 签约自增序号
    ,P1.AGT_NO AS AGT_NO -- 协议编号
    ,P1.THIRD_PTY_AGT_NO AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,P1.CONT_CENTER_AGT_NO AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,P1.AGT_EFFECT_DT AS AGT_EFFECT_DT -- 协议生效日期
    ,P1.AGT_EXPIR_DT AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.PAY_START_TM_STAMP AS PAY_START_TM_STAMP -- 缴费开始时间戳
    ,P1.BIZ_UNIT_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.BIZ_UNIT_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.PROD_NO AS PROD_NO -- 产品编号
    ,P1.PROD_NAME AS PROD_NAME -- 产品名称
    ,P1.MDL_BIZ_CATE_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.MDL_BIZ_CATE_NAME AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,P1.MDL_BIZ_MDL_CATOGR_NO AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,P1.MDL_BIZ_MDL_CATOGR_NAME AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,P1.MDL_BIZ_SUB_CLS_CD AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,P1.LIFE_PAY_BIZ_CATEGORY_CD AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,P1.PAY_PROJ_NO AS PAY_PROJ_NO -- 缴费项目编号
    ,P1.PAY_PROJ_NAME AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.THIRD_PTY_USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.THIRD_PTY_USER_DOCTYP_CD AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,P1.THIRD_PTY_USER_DOC_NO AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,P1.THIRD_PTY_USER_CONT_ADDR AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,P1.THIRD_PTY_USER_CONT_NO_NO AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.CONT_NO_NO AS CONT_NO_NO -- 联系电话号码
    ,P1.CONT_ADDR AS CONT_ADDR -- 联系地址
    ,P1.POST_CD AS POST_CD -- 邮政编码
    ,P1.SIGN_AGENT_NAME AS SIGN_AGENT_NAME -- 签约代理人名称
    ,P1.SIGN_AGENT_DOCTYP_CD AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,P1.SIGN_AGENT_DOC_NO AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,P1.SIGN_AGENT_CONT_NO_NO AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_PUB_PRIV_TYPE_CD AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_DISCNT_IDNT_CD AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,P1.LIFE_PAY_MED_TYPE_CD AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,P1.TXN_PWD AS TXN_PWD -- 交易密码
    ,P1.SIGN_ACCT_OPEN_ACCT_ORG_NO AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P1.SIGN_ACCT_OPBANK_CNAPS_CODE AS SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,P1.SINGLE_LMT AS SINGLE_LMT -- 单笔限额
    ,P1.DAILY_ACCUM_LMT AS DAILY_ACCUM_LMT -- 日累计限额
    ,P1.MONTHLY_ACCUM_LMT AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,P1.YEAR_CUM_LMT AS YEAR_CUM_LMT -- 年累计限额
    ,P1.SIGN_TYPE_CD AS SIGN_TYPE_CD -- 签约类型代码
    ,P1.SIGN_CHNL_CD AS SIGN_CHNL_CD -- 签约渠道代码
    ,P1.SIGN_SER_NO AS SIGN_SER_NO -- 签约序号
    ,P1.SIGN_CONTR_DT AS SIGN_CONTR_DT -- 签约日期
    ,P1.SIGN_TM_STAMP AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_ORG_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELR_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_UPDATE_TM_STAMP AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.RECNT_MODIF_ORG_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.LIFE_PAY_AGT_STATUS_CD AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,P1.CONT_CENTER_AGT_STATUS_CD AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.LIFE_PAY_SIGN_SYS_CD AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,P1.REM AS REM -- 备注
    ,P1.SIGN_RESLT_DESC AS SIGN_RESLT_DESC -- 签约结果描述
    ,P1.REC_LOCK_FLAG AS REC_LOCK_FLAG -- 记录锁定标志
    ,P1.VER_NO AS VER_NO -- 版本编号
    ,P1.PLAT_DT AS PLAT_DT -- 平台日期
    ,P1.MGMT_ORG_NO AS MGMT_ORG_NO -- 管理机构编号
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,P1.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,P1.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_02_TF AS P1 -- 生活缴费签约协议信息聚合02

WHERE P1.PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第4-10组）==============
-- 生活缴费签约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM(
     SIGN_ISNO -- 签约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,PLAT_DT -- 平台日期
    ,MGMT_ORG_NO -- 管理机构编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.SIGN_ISNO AS SIGN_ISNO -- 签约自增序号
    ,P1.AGT_NO AS AGT_NO -- 协议编号
    ,P1.THIRD_PTY_AGT_NO AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,P1.CONT_CENTER_AGT_NO AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,P1.AGT_EFFECT_DT AS AGT_EFFECT_DT -- 协议生效日期
    ,P1.AGT_EXPIR_DT AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.PAY_START_TM_STAMP AS PAY_START_TM_STAMP -- 缴费开始时间戳
    ,P1.BIZ_UNIT_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.BIZ_UNIT_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.PROD_NO AS PROD_NO -- 产品编号
    ,P1.PROD_NAME AS PROD_NAME -- 产品名称
    ,P1.MDL_BIZ_CATE_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.MDL_BIZ_CATE_NAME AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,P1.MDL_BIZ_MDL_CATOGR_NO AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,P1.MDL_BIZ_MDL_CATOGR_NAME AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,P1.MDL_BIZ_SUB_CLS_CD AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,P1.LIFE_PAY_BIZ_CATEGORY_CD AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,P1.PAY_PROJ_NO AS PAY_PROJ_NO -- 缴费项目编号
    ,P1.PAY_PROJ_NAME AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.THIRD_PTY_USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.THIRD_PTY_USER_DOCTYP_CD AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,P1.THIRD_PTY_USER_DOC_NO AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,P1.THIRD_PTY_USER_CONT_ADDR AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,P1.THIRD_PTY_USER_CONT_NO_NO AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.CONT_NO_NO AS CONT_NO_NO -- 联系电话号码
    ,P1.CONT_ADDR AS CONT_ADDR -- 联系地址
    ,P1.POST_CD AS POST_CD -- 邮政编码
    ,P1.SIGN_AGENT_NAME AS SIGN_AGENT_NAME -- 签约代理人名称
    ,P1.SIGN_AGENT_DOCTYP_CD AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,P1.SIGN_AGENT_DOC_NO AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,P1.SIGN_AGENT_CONT_NO_NO AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_PUB_PRIV_TYPE_CD AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_DISCNT_IDNT_CD AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,P1.LIFE_PAY_MED_TYPE_CD AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,P1.TXN_PWD AS TXN_PWD -- 交易密码
    ,P1.SIGN_ACCT_OPEN_ACCT_ORG_NO AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P1.SIGN_ACCT_OPBANK_CNAPS_CODE AS SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,P1.SINGLE_LMT AS SINGLE_LMT -- 单笔限额
    ,P1.DAILY_ACCUM_LMT AS DAILY_ACCUM_LMT -- 日累计限额
    ,P1.MONTHLY_ACCUM_LMT AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,P1.YEAR_CUM_LMT AS YEAR_CUM_LMT -- 年累计限额
    ,P1.SIGN_TYPE_CD AS SIGN_TYPE_CD -- 签约类型代码
    ,P1.SIGN_CHNL_CD AS SIGN_CHNL_CD -- 签约渠道代码
    ,P1.SIGN_SER_NO AS SIGN_SER_NO -- 签约序号
    ,P1.SIGN_CONTR_DT AS SIGN_CONTR_DT -- 签约日期
    ,P1.SIGN_TM_STAMP AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_ORG_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELR_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_UPDATE_TM_STAMP AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.RECNT_MODIF_ORG_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.LIFE_PAY_AGT_STATUS_CD AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,P1.CONT_CENTER_AGT_STATUS_CD AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.LIFE_PAY_SIGN_SYS_CD AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,P1.REM AS REM -- 备注
    ,P1.SIGN_RESLT_DESC AS SIGN_RESLT_DESC -- 签约结果描述
    ,P1.REC_LOCK_FLAG AS REC_LOCK_FLAG -- 记录锁定标志
    ,P1.VER_NO AS VER_NO -- 版本编号
    ,P1.PLAT_DT AS PLAT_DT -- 平台日期
    ,P1.MGMT_ORG_NO AS MGMT_ORG_NO -- 管理机构编号
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,P1.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,P1.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF AS P1 -- 生活缴费签约协议信息聚合03

WHERE P1.PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第11-17组）==============
-- 生活缴费签约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM(
     SIGN_ISNO -- 签约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,PLAT_DT -- 平台日期
    ,MGMT_ORG_NO -- 管理机构编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.SIGN_ISNO AS SIGN_ISNO -- 签约自增序号
    ,P1.AGT_NO AS AGT_NO -- 协议编号
    ,P1.THIRD_PTY_AGT_NO AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,P1.CONT_CENTER_AGT_NO AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,P1.AGT_EFFECT_DT AS AGT_EFFECT_DT -- 协议生效日期
    ,P1.AGT_EXPIR_DT AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.PAY_START_TM_STAMP AS PAY_START_TM_STAMP -- 缴费开始时间戳
    ,P1.BIZ_UNIT_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.BIZ_UNIT_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.PROD_NO AS PROD_NO -- 产品编号
    ,P1.PROD_NAME AS PROD_NAME -- 产品名称
    ,P1.MDL_BIZ_CATE_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.MDL_BIZ_CATE_NAME AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,P1.MDL_BIZ_MDL_CATOGR_NO AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,P1.MDL_BIZ_MDL_CATOGR_NAME AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,P1.MDL_BIZ_SUB_CLS_CD AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,P1.LIFE_PAY_BIZ_CATEGORY_CD AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,P1.PAY_PROJ_NO AS PAY_PROJ_NO -- 缴费项目编号
    ,P1.PAY_PROJ_NAME AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.THIRD_PTY_USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.THIRD_PTY_USER_DOCTYP_CD AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,P1.THIRD_PTY_USER_DOC_NO AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,P1.THIRD_PTY_USER_CONT_ADDR AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,P1.THIRD_PTY_USER_CONT_NO_NO AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.CUST_IN_CD AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.DOCTYP_CD AS DOCTYP_CD -- 证件类型代码
    ,P1.DOC_NO AS DOC_NO -- 证件号码
    ,P1.CONT_NO_NO AS CONT_NO_NO -- 联系电话号码
    ,P1.CONT_ADDR AS CONT_ADDR -- 联系地址
    ,P1.POST_CD AS POST_CD -- 邮政编码
    ,P1.SIGN_AGENT_NAME AS SIGN_AGENT_NAME -- 签约代理人名称
    ,P1.SIGN_AGENT_DOCTYP_CD AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,P1.SIGN_AGENT_DOC_NO AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,P1.SIGN_AGENT_CONT_NO_NO AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_PUB_PRIV_TYPE_CD AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_DISCNT_IDNT_CD AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,P1.CASH_RMT_CD AS CASH_RMT_CD -- 钞汇代码
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,P1.LIFE_PAY_MED_TYPE_CD AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,P1.DRAW_MODE_CD AS DRAW_MODE_CD -- 支取方式代码
    ,P1.TXN_PWD AS TXN_PWD -- 交易密码
    ,P1.SIGN_ACCT_OPEN_ACCT_ORG_NO AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P1.SIGN_ACCT_OPBANK_CNAPS_CODE AS SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,P1.SINGLE_LMT AS SINGLE_LMT -- 单笔限额
    ,P1.DAILY_ACCUM_LMT AS DAILY_ACCUM_LMT -- 日累计限额
    ,P1.MONTHLY_ACCUM_LMT AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,P1.YEAR_CUM_LMT AS YEAR_CUM_LMT -- 年累计限额
    ,P1.SIGN_TYPE_CD AS SIGN_TYPE_CD -- 签约类型代码
    ,P1.SIGN_CHNL_CD AS SIGN_CHNL_CD -- 签约渠道代码
    ,P1.SIGN_SER_NO AS SIGN_SER_NO -- 签约序号
    ,P1.SIGN_CONTR_DT AS SIGN_CONTR_DT -- 签约日期
    ,P1.SIGN_TM_STAMP AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_ORG_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELR_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,P1.FINAL_MODIF_DT AS FINAL_MODIF_DT -- 最后修改日期
    ,P1.FINAL_UPDATE_TM_STAMP AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.RECNT_MODIF_ORG_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.FINAL_MODIF_TELR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.LIFE_PAY_AGT_STATUS_CD AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,P1.CONT_CENTER_AGT_STATUS_CD AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.LIFE_PAY_SIGN_SYS_CD AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,P1.REM AS REM -- 备注
    ,P1.SIGN_RESLT_DESC AS SIGN_RESLT_DESC -- 签约结果描述
    ,P1.REC_LOCK_FLAG AS REC_LOCK_FLAG -- 记录锁定标志
    ,P1.VER_NO AS VER_NO -- 版本编号
    ,P1.PLAT_DT AS PLAT_DT -- 平台日期
    ,P1.MGMT_ORG_NO AS MGMT_ORG_NO -- 管理机构编号
    ,P1.SUMMARY_CD AS SUMMARY_CD -- 摘要代码
    ,P1.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,P1.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,P1.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_04_TF AS P1 -- 生活缴费签约协议信息聚合04

WHERE P1.PT_DT = '${process_date}'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ISNO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ISNO, BF.SIGN_ISNO) END AS SIGN_ISNO -- 签约自增序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.AGT_NO, BF.AGT_NO) END AS AGT_NO -- 协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_AGT_NO, BF.THIRD_PTY_AGT_NO) END AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_CENTER_AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_CENTER_AGT_NO, BF.CONT_CENTER_AGT_NO) END AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_EFFECT_DT IS NULL THEN NULL ELSE COALESCE(TM.AGT_EFFECT_DT, BF.AGT_EFFECT_DT) END AS AGT_EFFECT_DT -- 协议生效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_EXPIR_DT IS NULL THEN NULL ELSE COALESCE(TM.AGT_EXPIR_DT, BF.AGT_EXPIR_DT) END AS AGT_EXPIR_DT -- 协议失效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PLAT_DT IS NULL THEN NULL ELSE COALESCE(TM.PLAT_DT, BF.PLAT_DT) END AS PLAT_DT -- 平台日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_START_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.PAY_START_TM_STAMP, BF.PAY_START_TM_STAMP) END AS PAY_START_TM_STAMP -- 缴费开始时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NO IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NO, BF.BIZ_UNIT_NO) END AS BIZ_UNIT_NO -- 业务单元编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NAME IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NAME, BF.BIZ_UNIT_NAME) END AS BIZ_UNIT_NAME -- 业务单元名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PROD_NO IS NULL THEN NULL ELSE COALESCE(TM.PROD_NO, BF.PROD_NO) END AS PROD_NO -- 产品编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.PROD_NAME, BF.PROD_NAME) END AS PROD_NAME -- 产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_CATE_NO IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_CATE_NO, BF.MDL_BIZ_CATE_NO) END AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_CATE_NAME IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_CATE_NAME, BF.MDL_BIZ_CATE_NAME) END AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_MDL_CATOGR_NO IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO, BF.MDL_BIZ_MDL_CATOGR_NO) END AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_MDL_CATOGR_NAME IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME, BF.MDL_BIZ_MDL_CATOGR_NAME) END AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_SUB_CLS_CD IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_SUB_CLS_CD, BF.MDL_BIZ_SUB_CLS_CD) END AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_BIZ_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD, BF.LIFE_PAY_BIZ_CATEGORY_CD) END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NO, BF.PAY_PROJ_NO) END AS PAY_PROJ_NO -- 缴费项目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NAME, BF.PAY_PROJ_NAME) END AS PAY_PROJ_NAME -- 缴费项目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_NO, BF.THIRD_PTY_USER_NO) END AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD, BF.THIRD_PTY_USER_DOCTYP_CD) END AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_DOC_NO, BF.THIRD_PTY_USER_DOC_NO) END AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_CONT_ADDR IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_CONT_ADDR, BF.THIRD_PTY_USER_CONT_ADDR) END AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO, BF.THIRD_PTY_USER_CONT_NO_NO) END AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DOCTYP_CD, BF.DOCTYP_CD) END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.DOC_NO, BF.DOC_NO) END AS DOC_NO -- 证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_NO_NO, BF.CONT_NO_NO) END AS CONT_NO_NO -- 联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_ADDR IS NULL THEN NULL ELSE COALESCE(TM.CONT_ADDR, BF.CONT_ADDR) END AS CONT_ADDR -- 联系地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POST_CD IS NULL THEN NULL ELSE COALESCE(TM.POST_CD, BF.POST_CD) END AS POST_CD -- 邮政编码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_NAME IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_NAME, BF.SIGN_AGENT_NAME) END AS SIGN_AGENT_NAME -- 签约代理人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_DOCTYP_CD, BF.SIGN_AGENT_DOCTYP_CD) END AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_DOC_NO, BF.SIGN_AGENT_DOC_NO) END AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_CONT_NO_NO, BF.SIGN_AGENT_CONT_NO_NO) END AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_PUB_PRIV_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD, BF.ACCT_PUB_PRIV_TYPE_CD) END AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_DISCNT_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_DISCNT_IDNT_CD, BF.CARD_DISCNT_IDNT_CD) END AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.CASH_RMT_CD, BF.CASH_RMT_CD) END AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_NO, BF.CARD_NO) END AS CARD_NO -- 卡片编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_MED_TYPE_CD, BF.LIFE_PAY_MED_TYPE_CD) END AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.DRAW_MODE_CD, BF.DRAW_MODE_CD) END AS DRAW_MODE_CD -- 支取方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_PWD IS NULL THEN NULL ELSE COALESCE(TM.TXN_PWD, BF.TXN_PWD) END AS TXN_PWD -- 交易密码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ACCT_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO, BF.SIGN_ACCT_OPEN_ACCT_ORG_NO) END AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ACCT_OPBANK_CNAPS_CODE IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ACCT_OPBANK_CNAPS_CODE, BF.SIGN_ACCT_OPBANK_CNAPS_CODE) END AS SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SINGLE_LMT IS NULL THEN NULL ELSE COALESCE(TM.SINGLE_LMT, BF.SINGLE_LMT) END AS SINGLE_LMT -- 单笔限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DAILY_ACCUM_LMT IS NULL THEN NULL ELSE COALESCE(TM.DAILY_ACCUM_LMT, BF.DAILY_ACCUM_LMT) END AS DAILY_ACCUM_LMT -- 日累计限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MONTHLY_ACCUM_LMT IS NULL THEN NULL ELSE COALESCE(TM.MONTHLY_ACCUM_LMT, BF.MONTHLY_ACCUM_LMT) END AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YEAR_CUM_LMT IS NULL THEN NULL ELSE COALESCE(TM.YEAR_CUM_LMT, BF.YEAR_CUM_LMT) END AS YEAR_CUM_LMT -- 年累计限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SIGN_TYPE_CD, BF.SIGN_TYPE_CD) END AS SIGN_TYPE_CD -- 签约类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.SIGN_CHNL_CD, BF.SIGN_CHNL_CD) END AS SIGN_CHNL_CD -- 签约渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_SER_NO, BF.SIGN_SER_NO) END AS SIGN_SER_NO -- 签约序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_CONTR_DT IS NULL THEN NULL ELSE COALESCE(TM.SIGN_CONTR_DT, BF.SIGN_CONTR_DT) END AS SIGN_CONTR_DT -- 签约日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SIGN_TM_STAMP, BF.SIGN_TM_STAMP) END AS SIGN_TM_STAMP -- 签约时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ORG_NO, BF.SIGN_ORG_NO) END AS SIGN_ORG_NO -- 签约机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_TELR_NO, BF.SIGN_TELR_NO) END AS SIGN_TELR_NO -- 签约柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MGMT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.MGMT_ORG_NO, BF.MGMT_ORG_NO) END AS MGMT_ORG_NO -- 管理机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_TM_STAMP, BF.FINAL_UPDATE_TM_STAMP) END AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_MODIF_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RECNT_MODIF_ORG_NO, BF.RECNT_MODIF_ORG_NO) END AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_AGT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_AGT_STATUS_CD, BF.LIFE_PAY_AGT_STATUS_CD) END AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_CENTER_AGT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.CONT_CENTER_AGT_STATUS_CD, BF.CONT_CENTER_AGT_STATUS_CD) END AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_SIGN_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_SIGN_SYS_CD, BF.LIFE_PAY_SIGN_SYS_CD) END AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REM IS NULL THEN NULL ELSE COALESCE(TM.REM, BF.REM) END AS REM -- 备注
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_CD IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_CD, BF.SUMMARY_CD) END AS SUMMARY_CD -- 摘要代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_RESLT_DESC IS NULL THEN NULL ELSE COALESCE(TM.SIGN_RESLT_DESC, BF.SIGN_RESLT_DESC) END AS SIGN_RESLT_DESC -- 签约结果描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_LOCK_FLAG IS NULL THEN NULL ELSE COALESCE(TM.REC_LOCK_FLAG, BF.REC_LOCK_FLAG) END AS REC_LOCK_FLAG -- 记录锁定标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VER_NO IS NULL THEN NULL ELSE COALESCE(TM.VER_NO, BF.VER_NO) END AS VER_NO -- 版本编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.THIRD_PTY_AGT_NO,'') = COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_NO,'') = COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段相等
         AND COALESCE(TM.AGT_EFFECT_DT,'') = COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段相等
         AND COALESCE(TM.AGT_EXPIR_DT,'') = COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段相等
         AND COALESCE(TM.PLAT_DT,'') = COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段相等
         AND COALESCE(TM.PAY_START_TM_STAMP,'') = COALESCE(BF.PAY_START_TM_STAMP,'') -- 缴费开始时间戳 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NAME,'') = COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段相等
         AND COALESCE(TM.PROD_NO,'') = COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段相等
         AND COALESCE(TM.PROD_NAME,'') = COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NO,'') = COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NAME,'') = COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') = COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') = COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NAME,'') = COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') = COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') = COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') = COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') = COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.CONT_NO_NO,'') = COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段相等
         AND COALESCE(TM.CONT_ADDR,'') = COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段相等
         AND COALESCE(TM.POST_CD,'') = COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_NAME,'') = COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') = COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOC_NO,'') = COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') = COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段相等
         AND COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') = COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段相等
         AND COALESCE(TM.CARD_DISCNT_IDNT_CD,'') = COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CARD_NO,'') = COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') = COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.TXN_PWD,'') = COALESCE(BF.TXN_PWD,'') -- 交易密码 非主键字段相等
         AND COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段相等
         AND COALESCE(TM.SIGN_ACCT_OPBANK_CNAPS_CODE,'') = COALESCE(BF.SIGN_ACCT_OPBANK_CNAPS_CODE,'') -- 签约账户开户行人行支付行号 非主键字段相等
         AND COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段相等
         AND COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段相等
         AND COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段相等
         AND COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段相等
         AND COALESCE(TM.SIGN_TYPE_CD,'') = COALESCE(BF.SIGN_TYPE_CD,'') -- 签约类型代码 非主键字段相等
         AND COALESCE(TM.SIGN_CHNL_CD,'') = COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段相等
         AND COALESCE(TM.SIGN_SER_NO,'') = COALESCE(BF.SIGN_SER_NO,'') -- 签约序号 非主键字段相等
         AND COALESCE(TM.SIGN_CONTR_DT,'') = COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段相等
         AND COALESCE(TM.SIGN_TM_STAMP,'') = COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段相等
         AND COALESCE(TM.SIGN_ORG_NO,'') = COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段相等
         AND COALESCE(TM.SIGN_TELR_NO,'') = COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段相等
         AND COALESCE(TM.MGMT_ORG_NO,'') = COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') = COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') = COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') = COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         AND COALESCE(TM.SIGN_RESLT_DESC,'') = COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段相等
         AND COALESCE(TM.REC_LOCK_FLAG,'') = COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段相等
         AND COALESCE(TM.VER_NO,'') = COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.THIRD_PTY_AGT_NO,'') <> COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_NO,'') <> COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段不相等
         OR COALESCE(TM.AGT_EFFECT_DT,'') <> COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段不相等
         OR COALESCE(TM.AGT_EXPIR_DT,'') <> COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段不相等
         OR COALESCE(TM.PLAT_DT,'') <> COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段不相等
         OR COALESCE(TM.PAY_START_TM_STAMP,'') <> COALESCE(BF.PAY_START_TM_STAMP,'') -- 缴费开始时间戳 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NAME,'') <> COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段不相等
         OR COALESCE(TM.PROD_NO,'') <> COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段不相等
         OR COALESCE(TM.PROD_NAME,'') <> COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NO,'') <> COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NAME,'') <> COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') <> COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') <> COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NAME,'') <> COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') <> COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') <> COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.CONT_NO_NO,'') <> COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段不相等
         OR COALESCE(TM.CONT_ADDR,'') <> COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段不相等
         OR COALESCE(TM.POST_CD,'') <> COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_NAME,'') <> COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') <> COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOC_NO,'') <> COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') <> COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段不相等
         OR COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') <> COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_DISCNT_IDNT_CD,'') <> COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.CASH_RMT_CD,'') <> COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CARD_NO,'') <> COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') <> COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.TXN_PWD,'') <> COALESCE(BF.TXN_PWD,'') -- 交易密码 非主键字段不相等
         OR COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.SIGN_ACCT_OPBANK_CNAPS_CODE,'') <> COALESCE(BF.SIGN_ACCT_OPBANK_CNAPS_CODE,'') -- 签约账户开户行人行支付行号 非主键字段不相等
         OR COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段不相等
         OR COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段不相等
         OR COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段不相等
         OR COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段不相等
         OR COALESCE(TM.SIGN_TYPE_CD,'') <> COALESCE(BF.SIGN_TYPE_CD,'') -- 签约类型代码 非主键字段不相等
         OR COALESCE(TM.SIGN_CHNL_CD,'') <> COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段不相等
         OR COALESCE(TM.SIGN_SER_NO,'') <> COALESCE(BF.SIGN_SER_NO,'') -- 签约序号 非主键字段不相等
         OR COALESCE(TM.SIGN_CONTR_DT,'') <> COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段不相等
         OR COALESCE(TM.SIGN_TM_STAMP,'') <> COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段不相等
         OR COALESCE(TM.SIGN_ORG_NO,'') <> COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段不相等
         OR COALESCE(TM.SIGN_TELR_NO,'') <> COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段不相等
         OR COALESCE(TM.MGMT_ORG_NO,'') <> COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') <> COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') <> COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') <> COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         OR COALESCE(TM.SIGN_RESLT_DESC,'') <> COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段不相等
         OR COALESCE(TM.REC_LOCK_FLAG,'') <> COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段不相等
         OR COALESCE(TM.VER_NO,'') <> COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.THIRD_PTY_AGT_NO,'') = COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_NO,'') = COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段相等
         AND COALESCE(TM.AGT_EFFECT_DT,'') = COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段相等
         AND COALESCE(TM.AGT_EXPIR_DT,'') = COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段相等
         AND COALESCE(TM.PLAT_DT,'') = COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段相等
         AND COALESCE(TM.PAY_START_TM_STAMP,'') = COALESCE(BF.PAY_START_TM_STAMP,'') -- 缴费开始时间戳 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NAME,'') = COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段相等
         AND COALESCE(TM.PROD_NO,'') = COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段相等
         AND COALESCE(TM.PROD_NAME,'') = COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NO,'') = COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NAME,'') = COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') = COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') = COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NAME,'') = COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') = COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') = COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') = COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') = COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.CONT_NO_NO,'') = COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段相等
         AND COALESCE(TM.CONT_ADDR,'') = COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段相等
         AND COALESCE(TM.POST_CD,'') = COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_NAME,'') = COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') = COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOC_NO,'') = COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') = COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段相等
         AND COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') = COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段相等
         AND COALESCE(TM.CARD_DISCNT_IDNT_CD,'') = COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CARD_NO,'') = COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') = COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.TXN_PWD,'') = COALESCE(BF.TXN_PWD,'') -- 交易密码 非主键字段相等
         AND COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段相等
         AND COALESCE(TM.SIGN_ACCT_OPBANK_CNAPS_CODE,'') = COALESCE(BF.SIGN_ACCT_OPBANK_CNAPS_CODE,'') -- 签约账户开户行人行支付行号 非主键字段相等
         AND COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段相等
         AND COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段相等
         AND COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段相等
         AND COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段相等
         AND COALESCE(TM.SIGN_TYPE_CD,'') = COALESCE(BF.SIGN_TYPE_CD,'') -- 签约类型代码 非主键字段相等
         AND COALESCE(TM.SIGN_CHNL_CD,'') = COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段相等
         AND COALESCE(TM.SIGN_SER_NO,'') = COALESCE(BF.SIGN_SER_NO,'') -- 签约序号 非主键字段相等
         AND COALESCE(TM.SIGN_CONTR_DT,'') = COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段相等
         AND COALESCE(TM.SIGN_TM_STAMP,'') = COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段相等
         AND COALESCE(TM.SIGN_ORG_NO,'') = COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段相等
         AND COALESCE(TM.SIGN_TELR_NO,'') = COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段相等
         AND COALESCE(TM.MGMT_ORG_NO,'') = COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') = COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') = COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') = COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         AND COALESCE(TM.SIGN_RESLT_DESC,'') = COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段相等
         AND COALESCE(TM.REC_LOCK_FLAG,'') = COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段相等
         AND COALESCE(TM.VER_NO,'') = COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.THIRD_PTY_AGT_NO,'') <> COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_NO,'') <> COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段不相等
         OR COALESCE(TM.AGT_EFFECT_DT,'') <> COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段不相等
         OR COALESCE(TM.AGT_EXPIR_DT,'') <> COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段不相等
         OR COALESCE(TM.PLAT_DT,'') <> COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段不相等
         OR COALESCE(TM.PAY_START_TM_STAMP,'') <> COALESCE(BF.PAY_START_TM_STAMP,'') -- 缴费开始时间戳 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NAME,'') <> COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段不相等
         OR COALESCE(TM.PROD_NO,'') <> COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段不相等
         OR COALESCE(TM.PROD_NAME,'') <> COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NO,'') <> COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NAME,'') <> COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') <> COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') <> COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NAME,'') <> COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') <> COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') <> COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.CONT_NO_NO,'') <> COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段不相等
         OR COALESCE(TM.CONT_ADDR,'') <> COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段不相等
         OR COALESCE(TM.POST_CD,'') <> COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_NAME,'') <> COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') <> COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOC_NO,'') <> COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') <> COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段不相等
         OR COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') <> COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_DISCNT_IDNT_CD,'') <> COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.CASH_RMT_CD,'') <> COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CARD_NO,'') <> COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') <> COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.TXN_PWD,'') <> COALESCE(BF.TXN_PWD,'') -- 交易密码 非主键字段不相等
         OR COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.SIGN_ACCT_OPBANK_CNAPS_CODE,'') <> COALESCE(BF.SIGN_ACCT_OPBANK_CNAPS_CODE,'') -- 签约账户开户行人行支付行号 非主键字段不相等
         OR COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段不相等
         OR COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段不相等
         OR COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段不相等
         OR COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段不相等
         OR COALESCE(TM.SIGN_TYPE_CD,'') <> COALESCE(BF.SIGN_TYPE_CD,'') -- 签约类型代码 非主键字段不相等
         OR COALESCE(TM.SIGN_CHNL_CD,'') <> COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段不相等
         OR COALESCE(TM.SIGN_SER_NO,'') <> COALESCE(BF.SIGN_SER_NO,'') -- 签约序号 非主键字段不相等
         OR COALESCE(TM.SIGN_CONTR_DT,'') <> COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段不相等
         OR COALESCE(TM.SIGN_TM_STAMP,'') <> COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段不相等
         OR COALESCE(TM.SIGN_ORG_NO,'') <> COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段不相等
         OR COALESCE(TM.SIGN_TELR_NO,'') <> COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段不相等
         OR COALESCE(TM.MGMT_ORG_NO,'') <> COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') <> COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') <> COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') <> COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         OR COALESCE(TM.SIGN_RESLT_DESC,'') <> COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段不相等
         OR COALESCE(TM.REC_LOCK_FLAG,'') <> COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段不相等
         OR COALESCE(TM.VER_NO,'') <> COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.SIGN_ISNO,'') = COALESCE(BF.SIGN_ISNO,'') -- 签约自增序号 主键字段关联
    AND COALESCE(TM.AGT_NO,'') = COALESCE(BF.AGT_NO,'') -- 协议编号 主键字段关联
    AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 主键字段关联
    AND COALESCE(TM.THIRD_PTY_USER_NO,'') = COALESCE(BF.THIRD_PTY_USER_NO,'') -- 第三方用户编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_LIFE_PAY_SIGN_AGT_INFO_TF_TM;
