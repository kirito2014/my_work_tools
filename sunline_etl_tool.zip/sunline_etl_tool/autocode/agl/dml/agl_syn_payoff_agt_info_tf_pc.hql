-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-综合代发协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SYN_PAYOFF_AGT_INFO_TF
--     表中文名：综合代发协议信息聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：SYN_PAYOFF_AGT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建
--         2024-11-01 00:00:00 魏丹丹 新增字段：客户归属机构编号  变更字段中英文名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM
USING ORC
COMMENT '综合代发协议信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CONT_NO -- 合约编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,SIGN_PROD_NAME -- 签约产品名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,ACCT_NO -- 账户编号
    ,CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,ACCT_NAME -- 账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,OPEN_ACCT_TM -- 开户时间
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,SIGN_CONTR_DT -- 签约日期
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_TELR_NO -- 交易柜员编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,SIGN_ORG_NO -- 签约机构编号
    ,CONT_EFFECT_DT -- 合约生效日期
    ,CONT_EXPIR_DT -- 合约失效日期
    ,SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,DBO_ORG_NO -- 运营机构编号
    ,MOBILE_NO -- 手机号码
    ,CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CANCEL_CONT_DT -- 解约日期
    ,CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CREATE_TM -- 创建时间
    ,FINAL_UPDATE_TM -- 最后修改时间
    ,CREATOR_NO -- 创建人编号
    ,MODIFIER_NO -- 修改人编号
    ,LP_ORG_NO -- 法人机构编号
    ,LP_NAME -- 法人名称
    ,CORP_DOCTYP_CD -- 企业证件类型代码
    ,CORP_DOC_NO -- 企业证件号码
    ,CORP_USER_ID -- 企业用户ID
    ,LP_CONT_NO_NO -- 法人联系电话号码
    ,LP_DOCTYP_CD -- 法人证件类型代码
    ,LP_DOC_NO -- 法人证件号码
    ,AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CORP_CUST_STATUS -- 企业客户状态
    ,SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,GRP_CUST_FLAG -- 集团客户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 综合代发协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM(
     SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CONT_NO -- 合约编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,SIGN_PROD_NAME -- 签约产品名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,OPEN_ACCT_TM -- 开户时间戳
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,SIGN_CONTR_DT -- 签约日期
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_TELR_NO -- 交易柜员编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,SIGN_ORG_NO -- 签约机构编号
    ,CONT_EFFECT_DT -- 合约生效日期
    ,CONT_EXPIR_DT -- 合约失效日期
    ,SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,DBO_ORG_NO -- 运营机构编号
    ,MOBILE_NO -- 手机号码
    ,CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CANCEL_CONT_DT -- 解约日期
    ,CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CREATE_TM -- 创建时间戳
    ,FINAL_UPDATE_TM -- 最后修改时间戳
    ,CREATOR_NO -- 创建人编号
    ,MODIFIER_NO -- 修改人编号
    ,LP_ORG_NO -- 法人机构编号
    ,LP_NAME -- 法人名称
    ,CORP_DOCTYP_CD -- 企业证件类型代码
    ,CORP_DOC_NO -- 企业证件号码
    ,CORP_USER_ID -- 企业用户ID
    ,LP_CONT_NO_NO -- 法人联系电话号码
    ,LP_DOCTYP_CD -- 法人证件类型代码
    ,LP_DOC_NO -- 法人证件号码
    ,AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CORP_CUST_STATUS -- 企业客户状态
    ,SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,GRP_CUST_FLAG -- 集团客户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT('COPTC',REPLACE('${process_date}','-',''),LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTR_ID ASC, P1.CORP_ID ASC),10,'0')) AS SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,P1.CONTR_ID AS CONT_NO -- 合约编号
    ,P1.CORP_ID AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.CONTR_PROD_CD AS SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,P1.CONTR_PROD_NM AS SIGN_PROD_NAME -- 签约产品名称
    ,P1.CORP_CORE_ID AS CUST_IN_CD -- 客户内码
    ,P2.CORP_NAME AS CUST_NAME -- 客户名称
    ,P2.ORG_NO AS CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,P3.ACCT_NO AS ACCT_NO -- 账户编号
    ,P3.ACCT_NM AS ACCT_NAME -- 账户名称
    ,P3.OPEN_ACCT_ORG AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,unifiedTime(P4.AA43DATE)||' 00:00:00.000000' AS OPEN_ACCT_TM -- 开户时间戳
    ,P1.TRD_PTY_AGMT_ID AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,unifiedTime(P1.CONTR_DT) AS SIGN_CONTR_DT -- 签约日期
    ,P1.CONTR_TX_CHNL AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.CONTR_TX_TELLR AS TXN_TELR_NO -- 交易柜员编号
    ,P1.TX_CORP_USR_ID AS OPER_TELR_NO -- 操作柜员编号
    ,P1.CONTRT_BUS_TP AS SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,P1.BIZ_SEQ_NUM AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,P1.CONTR_ORG AS SIGN_ORG_NO -- 签约机构编号
    ,unifiedTime(P1.CONTR_EFFT_DT) AS CONT_EFFECT_DT -- 合约生效日期
    ,unifiedTime(P1.CONTR_EXPI_DT) AS CONT_EXPIR_DT -- 合约失效日期
    ,CASE WHEN P1.CONTR_ST IS NULL OR TRIM(P1.CONTR_ST)='' 
     THEN '' 
ELSE COALESCE(TRIM(M1.TARGET_CD_VAL), '@'||TRIM(P1.CONTR_ST),'') END AS SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,P1.OPERA_ORG AS DBO_ORG_NO -- 运营机构编号
    ,P1.MOBL_NO AS MOBILE_NO -- 手机号码
    ,P1.TRMN_TX_ORG AS CANCEL_CONT_ORG_NO -- 解约机构编号
    ,P1.TRMN_TX_TELLR AS CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,P1.TRMN_TX_CHNL AS CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,unifiedTime(P1.TRMN_DT) AS CANCEL_CONT_DT -- 解约日期
    ,P1.TRMN_RSN AS CANCEL_CONT_RSN_ILUS -- 解约原因
    ,unifiedTime1(P1.GMT_CREATE) AS CREATE_TM -- 创建时间戳
    ,unifiedTime1(P1.GMT_MODIFIED) AS FINAL_UPDATE_TM -- 最后修改时间戳
    ,P1.CRET_ID AS CREATOR_NO -- 创建人编号
    ,P1.MODI_ID AS MODIFIER_NO -- 修改人编号
    ,P1.LPR_ORG AS LP_ORG_NO -- 法人机构编号
    ,P2.LEGAL_NM AS LP_NAME -- 法人名称
    ,P1.CORP_CERT_TP AS CORP_DOCTYP_CD -- 企业证件类型代码
    ,P1.CORP_CERT_NO AS CORP_DOC_NO -- 企业证件号码
    ,P1.CORP_USR_ID AS CORP_USER_ID -- 企业用户ID
    ,P2.LPR_MOBILE_NO AS LP_CONT_NO_NO -- 法人联系电话号码
    ,P2.LPR_CERT_TP AS LP_DOCTYP_CD -- 法人证件类型代码
    ,P2.LPR_CERT_NO AS LP_DOC_NO -- 法人证件号码
    ,P2.RGST_TP_CD AS AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,P2.MGMT_MTH_CD AS CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,P2.CORP_CUST_ST AS CORP_CUST_STATUS -- 企业客户状态
    ,P2.CORP_CUST_LVL AS SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,P2.GRP_CUST_FLG AS GRP_CUST_FLAG -- 集团客户标志
    ,'COPTC' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_COPTC_T_CTC_CORP_CONTR_INF_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_COPTC${version_num}.ODS_COPTC_T_CTC_CORP_CONTR_INF_TF AS P1 -- 企业合约信息表

LEFT JOIN ODS_ENTUC${version_num}.ODS_ENTUC_T_EUC_CUST_BASE_INF_TF AS P2 -- 企业客户基础信息表
       ON P1.CORP_ID=P2.CORP_ID
      AND P2.DEL_F = '0'
      AND P2.PT_DT = '${process_date}' 
LEFT JOIN ODS_COPTC${version_num}.ODS_COPTC_T_CTC_ACCT_CONTR_INF_TF AS P3 -- 账户类合约辅表
       ON P1.CONTR_ID=P3.CONTR_ID
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款帐户主档
       ON P3.ACCT_NO=P4.AA01AC15
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS M1 -- 码值表
       ON P1.CONTR_ST=M1.SRC_CD_VAL  
AND M1.SRC_TAB_LIB_NAME ='COPTC'  --源系统 简称或中文名 待定
AND M1.SRC_TAB_EN_NAME='T_CTC_CORP_CONTR_INF' --来源表英文名 大写
AND M1.SRC_FIELD_EN_NAME='CONTR_ST' --来源字段英文名 大写
AND M1.TARGET_TAB_EN_NAME='AGL_SYN_PAYOFF_AGT_INFO_TF' --目标表名 大写
AND M1.TARGET_FIELD_EN_NAME='SYN_PAYOFF_SIGN_STATUS_CD' --目标字段 大写 
WHERE P1.CONTR_PROD_CD IN ('PRD0000000024','PRD0000000001','PRD0000000002')  AND P1.DEL_F = '0' AND P1.PT_DT = '${process_date}'
;
-- ==============聚合层字段映射（第2组）==============
-- 综合代发协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM(
     SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CONT_NO -- 合约编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,SIGN_PROD_NAME -- 签约产品名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,OPEN_ACCT_TM -- 开户时间戳
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,SIGN_CONTR_DT -- 签约日期
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_TELR_NO -- 交易柜员编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,SIGN_ORG_NO -- 签约机构编号
    ,CONT_EFFECT_DT -- 合约生效日期
    ,CONT_EXPIR_DT -- 合约失效日期
    ,SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,DBO_ORG_NO -- 运营机构编号
    ,MOBILE_NO -- 手机号码
    ,CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CANCEL_CONT_DT -- 解约日期
    ,CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CREATE_TM -- 创建时间
    ,FINAL_UPDATE_TM -- 最后修改时间
    ,CREATOR_NO -- 创建人编号
    ,MODIFIER_NO -- 修改人编号
    ,LP_ORG_NO -- 法人机构编号
    ,LP_NAME -- 法人名称
    ,CORP_DOCTYP_CD -- 企业证件类型代码
    ,CORP_DOC_NO -- 企业证件号码
    ,CORP_USER_ID -- 企业用户ID
    ,LP_CONT_NO_NO -- 法人联系电话号码
    ,LP_DOCTYP_CD -- 法人证件类型代码
    ,LP_DOC_NO -- 法人证件号码
    ,AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CORP_CUST_STATUS -- 企业客户状态
    ,SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,GRP_CUST_FLAG -- 集团客户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT('IMBS',REPLACE('${process_date}','-',''),LPAD(ROW_NUMBER()OVER(ORDER BY P1.ENTR_NO ASC, P2.CUST_CODE ASC),10,'0')) AS SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,'' AS CONT_NO -- 合约编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,'' AS SIGN_PROD_NAME -- 签约产品名称
    ,P2.CUST_CODE AS CUST_IN_CD -- 客户内码
    ,P1.ENTR_NAME AS CUST_NAME -- 客户名称
    ,'' AS CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,P1.SET_ACCT_NO AS ACCT_NO -- 账户编号
    ,'' AS ACCT_NAME -- 账户名称
    ,P1.BRCH_NO AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,NULL AS OPEN_ACCT_TM -- 开户时间戳
    ,'' AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS OPER_TELR_NO -- 操作柜员编号
    ,'' AS SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,'' AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,'' AS SIGN_ORG_NO -- 签约机构编号
    ,NULL AS CONT_EFFECT_DT -- 合约生效日期
    ,NULL AS CONT_EXPIR_DT -- 合约失效日期
    ,'' AS SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,'' AS DBO_ORG_NO -- 运营机构编号
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS CANCEL_CONT_ORG_NO -- 解约机构编号
    ,'' AS CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,'' AS CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,NULL AS CANCEL_CONT_DT -- 解约日期
    ,'' AS CANCEL_CONT_RSN_ILUS -- 解约原因
    ,NULL AS CREATE_TM -- 创建时间
    ,NULL AS FINAL_UPDATE_TM -- 最后修改时间
    ,'' AS CREATOR_NO -- 创建人编号
    ,'' AS MODIFIER_NO -- 修改人编号
    ,'' AS LP_ORG_NO -- 法人机构编号
    ,'' AS LP_NAME -- 法人名称
    ,P2.ID_TYPE AS CORP_DOCTYP_CD -- 企业证件类型代码
    ,P2.ID_NO AS CORP_DOC_NO -- 企业证件号码
    ,'' AS CORP_USER_ID -- 企业用户ID
    ,'' AS LP_CONT_NO_NO -- 法人联系电话号码
    ,'' AS LP_DOCTYP_CD -- 法人证件类型代码
    ,'' AS LP_DOC_NO -- 法人证件号码
    ,'' AS AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,'' AS CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,'' AS CORP_CUST_STATUS -- 企业客户状态
    ,'' AS SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,'' AS GRP_CUST_FLAG -- 集团客户标志
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_ENTR_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OSCIP${version_num}.ODS_OSCIP_T_ENTR_TF AS P1 -- 代理单位管理表

INNER JOIN ODS_OSCIP${version_num}.ODS_OSCIP_T_ENTR_INNER_CODE_TF AS P2 -- 代理单位核心内码登记信息表
       ON P1.ENTR_NO=P2.ENTR_NO    AND P2.CUST_CODE !='0'   AND P2.DEL_F = '0' AND P2.PT_DT = '${process_date}' 
WHERE P1.PT_DT = '${process_date}'  AND P1.BUSI_NO = 'OLA' AND P1.ACCT_TYPE = '2' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- 综合代发协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM(
     SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CONT_NO -- 合约编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,SIGN_PROD_NAME -- 签约产品名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,OPEN_ACCT_TM -- 开户时间戳
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,SIGN_CONTR_DT -- 签约日期
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_TELR_NO -- 交易柜员编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,SIGN_ORG_NO -- 签约机构编号
    ,CONT_EFFECT_DT -- 合约生效日期
    ,CONT_EXPIR_DT -- 合约失效日期
    ,SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,DBO_ORG_NO -- 运营机构编号
    ,MOBILE_NO -- 手机号码
    ,CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CANCEL_CONT_DT -- 解约日期
    ,CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CREATE_TM -- 创建时间
    ,FINAL_UPDATE_TM -- 最后修改时间
    ,CREATOR_NO -- 创建人编号
    ,MODIFIER_NO -- 修改人编号
    ,LP_ORG_NO -- 法人机构编号
    ,LP_NAME -- 法人名称
    ,CORP_DOCTYP_CD -- 企业证件类型代码
    ,CORP_DOC_NO -- 企业证件号码
    ,CORP_USER_ID -- 企业用户ID
    ,LP_CONT_NO_NO -- 法人联系电话号码
    ,LP_DOCTYP_CD -- 法人证件类型代码
    ,LP_DOC_NO -- 法人证件号码
    ,AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CORP_CUST_STATUS -- 企业客户状态
    ,SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,GRP_CUST_FLAG -- 集团客户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT('NMGZ',REPLACE('${process_date}','-',''),LPAD(ROW_NUMBER()OVER(ORDER BY P1.ENTR_NO ASC, P1.CONTRACT ASC),10,'0')) AS SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,P1.CONTRACT AS CONT_NO -- 合约编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,'' AS SIGN_PROD_NAME -- 签约产品名称
    ,P2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P1.QYMC AS CUST_NAME -- 客户名称
    ,'' AS CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,unifiedTime(P1.OPEN_TIME) AS OPEN_ACCT_TM -- 开户时间戳
    ,'' AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,unifiedTime(P1.SIGN_DATE) AS SIGN_CONTR_DT -- 签约日期
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.SIGN_TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS OPER_TELR_NO -- 操作柜员编号
    ,'' AS SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,'' AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,NULL AS CONT_EFFECT_DT -- 合约生效日期
    ,NULL AS CONT_EXPIR_DT -- 合约失效日期
    ,'' AS SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,'' AS DBO_ORG_NO -- 运营机构编号
    ,P1.TELEPHONE AS MOBILE_NO -- 手机号码
    ,'' AS CANCEL_CONT_ORG_NO -- 解约机构编号
    ,'' AS CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,'' AS CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,NULL AS CANCEL_CONT_DT -- 解约日期
    ,'' AS CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CASE WHEN LENGTH(CONCAT(P1.SIGN_DATE,' ',P1.SIGN_TIME))=9 THEN unifiedTime(P1.SIGN_DATE)||' 00:00:00.000000' ELSE unifiedTime1(CONCAT(P1.SIGN_DATE,' ',P1.SIGN_TIME)) END AS CREATE_TM -- 创建时间
    ,CASE WHEN LENGTH(CONCAT(P1.UPT_DATE,' ',P1.UPT_TIME))=9 THEN unifiedTime(P1.UPT_DATE)||' 00:00:00.000000' ELSE unifiedTime1(CONCAT(P1.UPT_DATE,' ',P1.UPT_TIME)) END AS FINAL_UPDATE_TM -- 最后修改时间
    ,'' AS CREATOR_NO -- 创建人编号
    ,'' AS MODIFIER_NO -- 修改人编号
    ,CONCAT(SUBSTR(P1.OPEN_BRCH,1,3),'000') AS LP_ORG_NO -- 法人机构编号
    ,P1.FRXM AS LP_NAME -- 法人名称
    ,'202' AS CORP_DOCTYP_CD -- 企业证件类型代码
    ,P1.SHTYXTDM AS CORP_DOC_NO -- 企业证件号码
    ,'' AS CORP_USER_ID -- 企业用户ID
    ,'' AS LP_CONT_NO_NO -- 法人联系电话号码
    ,'101' AS LP_DOCTYP_CD -- 法人证件类型代码
    ,P1.FRSFZ AS LP_DOC_NO -- 法人证件号码
    ,'' AS AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,'' AS CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,'' AS CORP_CUST_STATUS -- 企业客户状态
    ,'' AS SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,'' AS GRP_CUST_FLAG -- 集团客户标志
    ,'OFSBP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFSBP_T_SIGN_NMGZDF_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFSBP${version_num}.ODS_OFSBP_T_SIGN_NMGZDF_TF AS P1 -- 省企业签约信息表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款账户主档
       ON P1.ACCT_NO = P2.AA01AC15  AND P2.DEL_F = '0'   AND P2.PT_DT = '${process_date}' 
WHERE P1.PT_DT = '${process_date}'   AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- 综合代发协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM(
     SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CONT_NO -- 合约编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,SIGN_PROD_NAME -- 签约产品名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,OPEN_ACCT_TM -- 开户时间戳
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,SIGN_CONTR_DT -- 签约日期
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_TELR_NO -- 交易柜员编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,SIGN_ORG_NO -- 签约机构编号
    ,CONT_EFFECT_DT -- 合约生效日期
    ,CONT_EXPIR_DT -- 合约失效日期
    ,SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,DBO_ORG_NO -- 运营机构编号
    ,MOBILE_NO -- 手机号码
    ,CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CANCEL_CONT_DT -- 解约日期
    ,CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CREATE_TM -- 创建时间
    ,FINAL_UPDATE_TM -- 最后修改时间
    ,CREATOR_NO -- 创建人编号
    ,MODIFIER_NO -- 修改人编号
    ,LP_ORG_NO -- 法人机构编号
    ,LP_NAME -- 法人名称
    ,CORP_DOCTYP_CD -- 企业证件类型代码
    ,CORP_DOC_NO -- 企业证件号码
    ,CORP_USER_ID -- 企业用户ID
    ,LP_CONT_NO_NO -- 法人联系电话号码
    ,LP_DOCTYP_CD -- 法人证件类型代码
    ,LP_DOC_NO -- 法人证件号码
    ,AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CORP_CUST_STATUS -- 企业客户状态
    ,SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,GRP_CUST_FLAG -- 集团客户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT('JNMGZ',REPLACE('${process_date}','-',''),LPAD(ROW_NUMBER()OVER(ORDER BY P1.ENTR_NO ASC, P1.CONTRACT ASC),10,'0')) AS SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,P1.CONTRACT AS CONT_NO -- 合约编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,'' AS SIGN_PROD_NAME -- 签约产品名称
    ,P2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P1.QYMC AS CUST_NAME -- 客户名称
    ,'' AS CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,unifiedTime(P1.OPEN_TIME) AS OPEN_ACCT_TM -- 开户时间戳
    ,'' AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,unifiedTime(P1.SIGN_DATE) AS SIGN_CONTR_DT -- 签约日期
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.SIGN_TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS OPER_TELR_NO -- 操作柜员编号
    ,'' AS SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,'' AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,NULL AS CONT_EFFECT_DT -- 合约生效日期
    ,NULL AS CONT_EXPIR_DT -- 合约失效日期
    ,'' AS SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,'' AS DBO_ORG_NO -- 运营机构编号
    ,P1.TELEPHONE AS MOBILE_NO -- 手机号码
    ,'' AS CANCEL_CONT_ORG_NO -- 解约机构编号
    ,'' AS CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,'' AS CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,NULL AS CANCEL_CONT_DT -- 解约日期
    ,'' AS CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CASE WHEN LENGTH(CONCAT(P1.SIGN_DATE,' ',P1.SIGN_TIME))=9 THEN unifiedTime(P1.SIGN_DATE)||' 00:00:00.000000' ELSE unifiedTime1(CONCAT(P1.SIGN_DATE,' ',P1.SIGN_TIME)) END AS CREATE_TM -- 创建时间
    ,CASE WHEN LENGTH(CONCAT(P1.UPT_DATE,' ',P1.UPT_TIME))=9 THEN unifiedTime(P1.UPT_DATE)||' 00:00:00.000000' ELSE unifiedTime1(CONCAT(P1.UPT_DATE,' ',P1.UPT_TIME)) END AS FINAL_UPDATE_TM -- 最后修改时间
    ,'' AS CREATOR_NO -- 创建人编号
    ,'' AS MODIFIER_NO -- 修改人编号
    ,CONCAT(SUBSTR(P1.OPEN_BRCH,1,3),'000') AS LP_ORG_NO -- 法人机构编号
    ,P1.FRXM AS LP_NAME -- 法人名称
    ,'202' AS CORP_DOCTYP_CD -- 企业证件类型代码
    ,P1.SHTYXTDM AS CORP_DOC_NO -- 企业证件号码
    ,'' AS CORP_USER_ID -- 企业用户ID
    ,'' AS LP_CONT_NO_NO -- 法人联系电话号码
    ,'101' AS LP_DOCTYP_CD -- 法人证件类型代码
    ,P1.FRSFZ AS LP_DOC_NO -- 法人证件号码
    ,'' AS AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,'' AS CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,'' AS CORP_CUST_STATUS -- 企业客户状态
    ,'' AS SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,'' AS GRP_CUST_FLAG -- 集团客户标志
    ,'OFSBP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFSBP_T_SIGN_NMGZDF2_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFSBP${version_num}.ODS_OFSBP_T_SIGN_NMGZDF2_TF AS P1 -- 单位编号

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P2 -- 客户内码
       ON P1.ACCT_NO = P2.AA01AC15  AND P2.DEL_F = '0' AND P2.PT_DT = '${process_date}' 
WHERE P1.PT_DT = '${process_date}'   AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第5组）==============
-- 综合代发协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM(
     SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CONT_NO -- 合约编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,SIGN_PROD_NAME -- 签约产品名称
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,OPEN_ACCT_TM -- 开户时间戳
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,SIGN_CONTR_DT -- 签约日期
    ,TXN_CHNL_CD -- 交易渠道代码
    ,TXN_TELR_NO -- 交易柜员编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,SIGN_ORG_NO -- 签约机构编号
    ,CONT_EFFECT_DT -- 合约生效日期
    ,CONT_EXPIR_DT -- 合约失效日期
    ,SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,DBO_ORG_NO -- 运营机构编号
    ,MOBILE_NO -- 手机号码
    ,CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CANCEL_CONT_DT -- 解约日期
    ,CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CREATE_TM -- 创建时间
    ,FINAL_UPDATE_TM -- 最后修改时间
    ,CREATOR_NO -- 创建人编号
    ,MODIFIER_NO -- 修改人编号
    ,LP_ORG_NO -- 法人机构编号
    ,LP_NAME -- 法人名称
    ,CORP_DOCTYP_CD -- 企业证件类型代码
    ,CORP_DOC_NO -- 企业证件号码
    ,CORP_USER_ID -- 企业用户ID
    ,LP_CONT_NO_NO -- 法人联系电话号码
    ,LP_DOCTYP_CD -- 法人证件类型代码
    ,LP_DOC_NO -- 法人证件号码
    ,AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CORP_CUST_STATUS -- 企业客户状态
    ,SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,GRP_CUST_FLAG -- 集团客户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT('ZHZJ',REPLACE('${process_date}','-',''),LPAD(ROW_NUMBER()OVER(ORDER BY P1.ENTR_NO ASC, P1.CONTRACT ASC),10,'0')) AS SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,P1.CONTRACT AS CONT_NO -- 合约编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,'' AS SIGN_PROD_NAME -- 签约产品名称
    ,P2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P1.QYMC AS CUST_NAME -- 客户名称
    ,'' AS CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,SUBSTR(P1.ACCT_NO,1,15) AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,unifiedTime(P1.OPEN_TIME) AS OPEN_ACCT_TM -- 开户时间戳
    ,'' AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,unifiedTime(P1.SIGN_DATE) AS SIGN_CONTR_DT -- 签约日期
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.SIGN_TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS OPER_TELR_NO -- 操作柜员编号
    ,'' AS SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,'' AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,NULL AS CONT_EFFECT_DT -- 合约生效日期
    ,NULL AS CONT_EXPIR_DT -- 合约失效日期
    ,'' AS SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,'' AS DBO_ORG_NO -- 运营机构编号
    ,P1.TELEPHONE AS MOBILE_NO -- 手机号码
    ,'' AS CANCEL_CONT_ORG_NO -- 解约机构编号
    ,'' AS CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,'' AS CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,NULL AS CANCEL_CONT_DT -- 解约日期
    ,'' AS CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CASE WHEN LENGTH(CONCAT(P1.SIGN_DATE,' ',P1.SIGN_TIME))=9 THEN unifiedTime(P1.SIGN_DATE)||' 00:00:00.000000' ELSE unifiedTime1(CONCAT(P1.SIGN_DATE,' ',P1.SIGN_TIME)) END AS CREATE_TM -- 创建时间
    ,CASE WHEN LENGTH(CONCAT(P1.UPT_DATE,' ',P1.UPT_TIME))=9 THEN unifiedTime(P1.UPT_DATE)||' 00:00:00.000000' ELSE unifiedTime1(CONCAT(P1.UPT_DATE,' ',P1.UPT_TIME)) END AS FINAL_UPDATE_TM -- 最后修改时间
    ,'' AS CREATOR_NO -- 创建人编号
    ,'' AS MODIFIER_NO -- 修改人编号
    ,CONCAT(SUBSTR(P1.OPEN_BRCH,1,3),'000') AS LP_ORG_NO -- 法人机构编号
    ,P1.FRXM AS LP_NAME -- 法人名称
    ,'202' AS CORP_DOCTYP_CD -- 企业证件类型代码
    ,P1.SHTYXYDM AS CORP_DOC_NO -- 企业证件号码
    ,'' AS CORP_USER_ID -- 企业用户ID
    ,'' AS LP_CONT_NO_NO -- 法人联系电话号码
    ,'101' AS LP_DOCTYP_CD -- 法人证件类型代码
    ,P1.FRSFZ AS LP_DOC_NO -- 法人证件号码
    ,'' AS AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,'' AS CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,'' AS CORP_CUST_STATUS -- 企业客户状态
    ,'' AS SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,'' AS GRP_CUST_FLAG -- 集团客户标志
    ,'OFSBP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFSBP_T_SIGN_LCZHZJ_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFSBP${version_num}.ODS_OFSBP_T_SIGN_LCZHZJ_TF AS P1 -- 温州智慧住建签约表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款账户主档
       ON P1.ACCT_NO = P2.AA01AC15  AND P2.DEL_F = '0'  AND P2.PT_DT = '${process_date}' 
WHERE P1.PT_DT = '${process_date}'   AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SYN_PAYOFF_AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.SYN_PAYOFF_AGT_NO, BF.SYN_PAYOFF_AGT_NO) END AS SYN_PAYOFF_AGT_NO -- 综合代发协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_NO, BF.CONT_NO) END AS CONT_NO -- 合约编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NO IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NO, BF.BIZ_UNIT_NO) END AS BIZ_UNIT_NO -- 业务单元编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SYN_PAYOFF_SIGN_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.SYN_PAYOFF_SIGN_PROD_CD, BF.SYN_PAYOFF_SIGN_PROD_CD) END AS SYN_PAYOFF_SIGN_PROD_CD -- 综合代发签约产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.SIGN_PROD_NAME, BF.SIGN_PROD_NAME) END AS SIGN_PROD_NAME -- 签约产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_BELONG_ORG_NO, BF.CUST_BELONG_ORG_NO) END AS CUST_BELONG_ORG_NO -- 客户归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_ORG_NO, BF.OPEN_ACCT_ORG_NO) END AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_TM IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_TM, BF.OPEN_ACCT_TM) END AS OPEN_ACCT_TM -- 开户时间
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_AGT_NO, BF.THIRD_PTY_AGT_NO) END AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_CONTR_DT IS NULL THEN NULL ELSE COALESCE(TM.SIGN_CONTR_DT, BF.SIGN_CONTR_DT) END AS SIGN_CONTR_DT -- 签约日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CHNL_CD, BF.TXN_CHNL_CD) END AS TXN_CHNL_CD -- 交易渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.TXN_TELR_NO, BF.TXN_TELR_NO) END AS TXN_TELR_NO -- 交易柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPER_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.OPER_TELR_NO, BF.OPER_TELR_NO) END AS OPER_TELR_NO -- 操作柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SYN_PAYOFF_SIGN_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SYN_PAYOFF_SIGN_TYPE_CD, BF.SYN_PAYOFF_SIGN_TYPE_CD) END AS SYN_PAYOFF_SIGN_TYPE_CD -- 综合代发签约类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.IMAGE_PLAT_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.IMAGE_PLAT_SER_NO, BF.IMAGE_PLAT_SER_NO) END AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ORG_NO, BF.SIGN_ORG_NO) END AS SIGN_ORG_NO -- 签约机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_EFFECT_DT IS NULL THEN NULL ELSE COALESCE(TM.CONT_EFFECT_DT, BF.CONT_EFFECT_DT) END AS CONT_EFFECT_DT -- 合约生效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_EXPIR_DT IS NULL THEN NULL ELSE COALESCE(TM.CONT_EXPIR_DT, BF.CONT_EXPIR_DT) END AS CONT_EXPIR_DT -- 合约失效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SYN_PAYOFF_SIGN_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.SYN_PAYOFF_SIGN_STATUS_CD, BF.SYN_PAYOFF_SIGN_STATUS_CD) END AS SYN_PAYOFF_SIGN_STATUS_CD -- 综合代发签约状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DBO_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.DBO_ORG_NO, BF.DBO_ORG_NO) END AS DBO_ORG_NO -- 运营机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MOBILE_NO IS NULL THEN NULL ELSE COALESCE(TM.MOBILE_NO, BF.MOBILE_NO) END AS MOBILE_NO -- 手机号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANCEL_CONT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CANCEL_CONT_ORG_NO, BF.CANCEL_CONT_ORG_NO) END AS CANCEL_CONT_ORG_NO -- 解约机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANCEL_CONT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.CANCEL_CONT_TELR_NO, BF.CANCEL_CONT_TELR_NO) END AS CANCEL_CONT_TELR_NO -- 解约交易柜员
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANCEL_CONT_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.CANCEL_CONT_CHNL_CD, BF.CANCEL_CONT_CHNL_CD) END AS CANCEL_CONT_CHNL_CD -- 解约渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANCEL_CONT_DT IS NULL THEN NULL ELSE COALESCE(TM.CANCEL_CONT_DT, BF.CANCEL_CONT_DT) END AS CANCEL_CONT_DT -- 解约日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANCEL_CONT_RSN_ILUS IS NULL THEN NULL ELSE COALESCE(TM.CANCEL_CONT_RSN_ILUS, BF.CANCEL_CONT_RSN_ILUS) END AS CANCEL_CONT_RSN_ILUS -- 解约原因
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CREATE_TM IS NULL THEN NULL ELSE COALESCE(TM.CREATE_TM, BF.CREATE_TM) END AS CREATE_TM -- 创建时间
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_TM IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_TM, BF.FINAL_UPDATE_TM) END AS FINAL_UPDATE_TM -- 最后修改时间
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CREATOR_NO IS NULL THEN NULL ELSE COALESCE(TM.CREATOR_NO, BF.CREATOR_NO) END AS CREATOR_NO -- 创建人编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MODIFIER_NO IS NULL THEN NULL ELSE COALESCE(TM.MODIFIER_NO, BF.MODIFIER_NO) END AS MODIFIER_NO -- 修改人编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_NAME IS NULL THEN NULL ELSE COALESCE(TM.LP_NAME, BF.LP_NAME) END AS LP_NAME -- 法人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CORP_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.CORP_DOCTYP_CD, BF.CORP_DOCTYP_CD) END AS CORP_DOCTYP_CD -- 企业证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CORP_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.CORP_DOC_NO, BF.CORP_DOC_NO) END AS CORP_DOC_NO -- 企业证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CORP_USER_ID IS NULL THEN NULL ELSE COALESCE(TM.CORP_USER_ID, BF.CORP_USER_ID) END AS CORP_USER_ID -- 企业用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_CONT_NO_NO, BF.LP_CONT_NO_NO) END AS LP_CONT_NO_NO -- 法人联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.LP_DOCTYP_CD, BF.LP_DOCTYP_CD) END AS LP_DOCTYP_CD -- 法人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_DOC_NO, BF.LP_DOC_NO) END AS LP_DOC_NO -- 法人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUTON_CNTER_REG_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.AUTON_CNTER_REG_IDNT_CD, BF.AUTON_CNTER_REG_IDNT_CD) END AS AUTON_CNTER_REG_IDNT_CD -- 自主柜面注册标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CORP_BANK_MGMT_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.CORP_BANK_MGMT_IDNT_CD, BF.CORP_BANK_MGMT_IDNT_CD) END AS CORP_BANK_MGMT_IDNT_CD -- 企业银行管理标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CORP_CUST_STATUS IS NULL THEN NULL ELSE COALESCE(TM.CORP_CUST_STATUS, BF.CORP_CUST_STATUS) END AS CORP_CUST_STATUS -- 企业客户状态
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SYN_CD_CUST_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SYN_CD_CUST_TYPE_CD, BF.SYN_CD_CUST_TYPE_CD) END AS SYN_CD_CUST_TYPE_CD -- 客户等级代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_CUST_FLAG IS NULL THEN NULL ELSE COALESCE(TM.GRP_CUST_FLAG, BF.GRP_CUST_FLAG) END AS GRP_CUST_FLAG -- 集团客户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CONT_NO,'') = COALESCE(BF.CONT_NO,'') -- 合约编号 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段相等
         AND COALESCE(TM.SYN_PAYOFF_SIGN_PROD_CD,'') = COALESCE(BF.SYN_PAYOFF_SIGN_PROD_CD,'') -- 综合代发签约产品代码 非主键字段相等
         AND COALESCE(TM.SIGN_PROD_NAME,'') = COALESCE(BF.SIGN_PROD_NAME,'') -- 签约产品名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.CUST_BELONG_ORG_NO,'') = COALESCE(BF.CUST_BELONG_ORG_NO,'') -- 客户归属机构编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_ORG_NO,'') = COALESCE(BF.OPEN_ACCT_ORG_NO,'') -- 开户机构编号 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM,'') = COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_AGT_NO,'') = COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段相等
         AND COALESCE(TM.SIGN_CONTR_DT,'') = COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.TXN_TELR_NO,'') = COALESCE(BF.TXN_TELR_NO,'') -- 交易柜员编号 非主键字段相等
         AND COALESCE(TM.OPER_TELR_NO,'') = COALESCE(BF.OPER_TELR_NO,'') -- 操作柜员编号 非主键字段相等
         AND COALESCE(TM.SYN_PAYOFF_SIGN_TYPE_CD,'') = COALESCE(BF.SYN_PAYOFF_SIGN_TYPE_CD,'') -- 综合代发签约类型代码 非主键字段相等
         AND COALESCE(TM.IMAGE_PLAT_SER_NO,'') = COALESCE(BF.IMAGE_PLAT_SER_NO,'') -- 影像平台流水号 非主键字段相等
         AND COALESCE(TM.SIGN_ORG_NO,'') = COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段相等
         AND COALESCE(TM.CONT_EFFECT_DT,'') = COALESCE(BF.CONT_EFFECT_DT,'') -- 合约生效日期 非主键字段相等
         AND COALESCE(TM.CONT_EXPIR_DT,'') = COALESCE(BF.CONT_EXPIR_DT,'') -- 合约失效日期 非主键字段相等
         AND COALESCE(TM.SYN_PAYOFF_SIGN_STATUS_CD,'') = COALESCE(BF.SYN_PAYOFF_SIGN_STATUS_CD,'') -- 综合代发签约状态代码 非主键字段相等
         AND COALESCE(TM.DBO_ORG_NO,'') = COALESCE(BF.DBO_ORG_NO,'') -- 运营机构编号 非主键字段相等
         AND COALESCE(TM.MOBILE_NO,'') = COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_ORG_NO,'') = COALESCE(BF.CANCEL_CONT_ORG_NO,'') -- 解约机构编号 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_TELR_NO,'') = COALESCE(BF.CANCEL_CONT_TELR_NO,'') -- 解约交易柜员 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_CHNL_CD,'') = COALESCE(BF.CANCEL_CONT_CHNL_CD,'') -- 解约渠道代码 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_DT,'') = COALESCE(BF.CANCEL_CONT_DT,'') -- 解约日期 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_RSN_ILUS,'') = COALESCE(BF.CANCEL_CONT_RSN_ILUS,'') -- 解约原因 非主键字段相等
         AND COALESCE(TM.CREATE_TM,'') = COALESCE(BF.CREATE_TM,'') -- 创建时间 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM,'') = COALESCE(BF.FINAL_UPDATE_TM,'') -- 最后修改时间 非主键字段相等
         AND COALESCE(TM.CREATOR_NO,'') = COALESCE(BF.CREATOR_NO,'') -- 创建人编号 非主键字段相等
         AND COALESCE(TM.MODIFIER_NO,'') = COALESCE(BF.MODIFIER_NO,'') -- 修改人编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.LP_NAME,'') = COALESCE(BF.LP_NAME,'') -- 法人名称 非主键字段相等
         AND COALESCE(TM.CORP_DOCTYP_CD,'') = COALESCE(BF.CORP_DOCTYP_CD,'') -- 企业证件类型代码 非主键字段相等
         AND COALESCE(TM.CORP_DOC_NO,'') = COALESCE(BF.CORP_DOC_NO,'') -- 企业证件号码 非主键字段相等
         AND COALESCE(TM.CORP_USER_ID,'') = COALESCE(BF.CORP_USER_ID,'') -- 企业用户ID 非主键字段相等
         AND COALESCE(TM.LP_CONT_NO_NO,'') = COALESCE(BF.LP_CONT_NO_NO,'') -- 法人联系电话号码 非主键字段相等
         AND COALESCE(TM.LP_DOCTYP_CD,'') = COALESCE(BF.LP_DOCTYP_CD,'') -- 法人证件类型代码 非主键字段相等
         AND COALESCE(TM.LP_DOC_NO,'') = COALESCE(BF.LP_DOC_NO,'') -- 法人证件号码 非主键字段相等
         AND COALESCE(TM.AUTON_CNTER_REG_IDNT_CD,'') = COALESCE(BF.AUTON_CNTER_REG_IDNT_CD,'') -- 自主柜面注册标识代码 非主键字段相等
         AND COALESCE(TM.CORP_BANK_MGMT_IDNT_CD,'') = COALESCE(BF.CORP_BANK_MGMT_IDNT_CD,'') -- 企业银行管理标识代码 非主键字段相等
         AND COALESCE(TM.CORP_CUST_STATUS,'') = COALESCE(BF.CORP_CUST_STATUS,'') -- 企业客户状态 非主键字段相等
         AND COALESCE(TM.SYN_CD_CUST_TYPE_CD,'') = COALESCE(BF.SYN_CD_CUST_TYPE_CD,'') -- 客户等级代码 非主键字段相等
         AND COALESCE(TM.GRP_CUST_FLAG,'') = COALESCE(BF.GRP_CUST_FLAG,'') -- 集团客户标志 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CONT_NO,'') <> COALESCE(BF.CONT_NO,'') -- 合约编号 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NO,'') <> COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段不相等
         OR COALESCE(TM.SYN_PAYOFF_SIGN_PROD_CD,'') <> COALESCE(BF.SYN_PAYOFF_SIGN_PROD_CD,'') -- 综合代发签约产品代码 非主键字段不相等
         OR COALESCE(TM.SIGN_PROD_NAME,'') <> COALESCE(BF.SIGN_PROD_NAME,'') -- 签约产品名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.CUST_BELONG_ORG_NO,'') <> COALESCE(BF.CUST_BELONG_ORG_NO,'') -- 客户归属机构编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.OPEN_ACCT_ORG_NO,'') -- 开户机构编号 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM,'') <> COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_AGT_NO,'') <> COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段不相等
         OR COALESCE(TM.SIGN_CONTR_DT,'') <> COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段不相等
         OR COALESCE(TM.TXN_CHNL_CD,'') <> COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段不相等
         OR COALESCE(TM.TXN_TELR_NO,'') <> COALESCE(BF.TXN_TELR_NO,'') -- 交易柜员编号 非主键字段不相等
         OR COALESCE(TM.OPER_TELR_NO,'') <> COALESCE(BF.OPER_TELR_NO,'') -- 操作柜员编号 非主键字段不相等
         OR COALESCE(TM.SYN_PAYOFF_SIGN_TYPE_CD,'') <> COALESCE(BF.SYN_PAYOFF_SIGN_TYPE_CD,'') -- 综合代发签约类型代码 非主键字段不相等
         OR COALESCE(TM.IMAGE_PLAT_SER_NO,'') <> COALESCE(BF.IMAGE_PLAT_SER_NO,'') -- 影像平台流水号 非主键字段不相等
         OR COALESCE(TM.SIGN_ORG_NO,'') <> COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段不相等
         OR COALESCE(TM.CONT_EFFECT_DT,'') <> COALESCE(BF.CONT_EFFECT_DT,'') -- 合约生效日期 非主键字段不相等
         OR COALESCE(TM.CONT_EXPIR_DT,'') <> COALESCE(BF.CONT_EXPIR_DT,'') -- 合约失效日期 非主键字段不相等
         OR COALESCE(TM.SYN_PAYOFF_SIGN_STATUS_CD,'') <> COALESCE(BF.SYN_PAYOFF_SIGN_STATUS_CD,'') -- 综合代发签约状态代码 非主键字段不相等
         OR COALESCE(TM.DBO_ORG_NO,'') <> COALESCE(BF.DBO_ORG_NO,'') -- 运营机构编号 非主键字段不相等
         OR COALESCE(TM.MOBILE_NO,'') <> COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_ORG_NO,'') <> COALESCE(BF.CANCEL_CONT_ORG_NO,'') -- 解约机构编号 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_TELR_NO,'') <> COALESCE(BF.CANCEL_CONT_TELR_NO,'') -- 解约交易柜员 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_CHNL_CD,'') <> COALESCE(BF.CANCEL_CONT_CHNL_CD,'') -- 解约渠道代码 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_DT,'') <> COALESCE(BF.CANCEL_CONT_DT,'') -- 解约日期 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_RSN_ILUS,'') <> COALESCE(BF.CANCEL_CONT_RSN_ILUS,'') -- 解约原因 非主键字段不相等
         OR COALESCE(TM.CREATE_TM,'') <> COALESCE(BF.CREATE_TM,'') -- 创建时间 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM,'') <> COALESCE(BF.FINAL_UPDATE_TM,'') -- 最后修改时间 非主键字段不相等
         OR COALESCE(TM.CREATOR_NO,'') <> COALESCE(BF.CREATOR_NO,'') -- 创建人编号 非主键字段不相等
         OR COALESCE(TM.MODIFIER_NO,'') <> COALESCE(BF.MODIFIER_NO,'') -- 修改人编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.LP_NAME,'') <> COALESCE(BF.LP_NAME,'') -- 法人名称 非主键字段不相等
         OR COALESCE(TM.CORP_DOCTYP_CD,'') <> COALESCE(BF.CORP_DOCTYP_CD,'') -- 企业证件类型代码 非主键字段不相等
         OR COALESCE(TM.CORP_DOC_NO,'') <> COALESCE(BF.CORP_DOC_NO,'') -- 企业证件号码 非主键字段不相等
         OR COALESCE(TM.CORP_USER_ID,'') <> COALESCE(BF.CORP_USER_ID,'') -- 企业用户ID 非主键字段不相等
         OR COALESCE(TM.LP_CONT_NO_NO,'') <> COALESCE(BF.LP_CONT_NO_NO,'') -- 法人联系电话号码 非主键字段不相等
         OR COALESCE(TM.LP_DOCTYP_CD,'') <> COALESCE(BF.LP_DOCTYP_CD,'') -- 法人证件类型代码 非主键字段不相等
         OR COALESCE(TM.LP_DOC_NO,'') <> COALESCE(BF.LP_DOC_NO,'') -- 法人证件号码 非主键字段不相等
         OR COALESCE(TM.AUTON_CNTER_REG_IDNT_CD,'') <> COALESCE(BF.AUTON_CNTER_REG_IDNT_CD,'') -- 自主柜面注册标识代码 非主键字段不相等
         OR COALESCE(TM.CORP_BANK_MGMT_IDNT_CD,'') <> COALESCE(BF.CORP_BANK_MGMT_IDNT_CD,'') -- 企业银行管理标识代码 非主键字段不相等
         OR COALESCE(TM.CORP_CUST_STATUS,'') <> COALESCE(BF.CORP_CUST_STATUS,'') -- 企业客户状态 非主键字段不相等
         OR COALESCE(TM.SYN_CD_CUST_TYPE_CD,'') <> COALESCE(BF.SYN_CD_CUST_TYPE_CD,'') -- 客户等级代码 非主键字段不相等
         OR COALESCE(TM.GRP_CUST_FLAG,'') <> COALESCE(BF.GRP_CUST_FLAG,'') -- 集团客户标志 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CONT_NO,'') = COALESCE(BF.CONT_NO,'') -- 合约编号 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段相等
         AND COALESCE(TM.SYN_PAYOFF_SIGN_PROD_CD,'') = COALESCE(BF.SYN_PAYOFF_SIGN_PROD_CD,'') -- 综合代发签约产品代码 非主键字段相等
         AND COALESCE(TM.SIGN_PROD_NAME,'') = COALESCE(BF.SIGN_PROD_NAME,'') -- 签约产品名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.CUST_BELONG_ORG_NO,'') = COALESCE(BF.CUST_BELONG_ORG_NO,'') -- 客户归属机构编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_ORG_NO,'') = COALESCE(BF.OPEN_ACCT_ORG_NO,'') -- 开户机构编号 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_TM,'') = COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_AGT_NO,'') = COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段相等
         AND COALESCE(TM.SIGN_CONTR_DT,'') = COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.TXN_TELR_NO,'') = COALESCE(BF.TXN_TELR_NO,'') -- 交易柜员编号 非主键字段相等
         AND COALESCE(TM.OPER_TELR_NO,'') = COALESCE(BF.OPER_TELR_NO,'') -- 操作柜员编号 非主键字段相等
         AND COALESCE(TM.SYN_PAYOFF_SIGN_TYPE_CD,'') = COALESCE(BF.SYN_PAYOFF_SIGN_TYPE_CD,'') -- 综合代发签约类型代码 非主键字段相等
         AND COALESCE(TM.IMAGE_PLAT_SER_NO,'') = COALESCE(BF.IMAGE_PLAT_SER_NO,'') -- 影像平台流水号 非主键字段相等
         AND COALESCE(TM.SIGN_ORG_NO,'') = COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段相等
         AND COALESCE(TM.CONT_EFFECT_DT,'') = COALESCE(BF.CONT_EFFECT_DT,'') -- 合约生效日期 非主键字段相等
         AND COALESCE(TM.CONT_EXPIR_DT,'') = COALESCE(BF.CONT_EXPIR_DT,'') -- 合约失效日期 非主键字段相等
         AND COALESCE(TM.SYN_PAYOFF_SIGN_STATUS_CD,'') = COALESCE(BF.SYN_PAYOFF_SIGN_STATUS_CD,'') -- 综合代发签约状态代码 非主键字段相等
         AND COALESCE(TM.DBO_ORG_NO,'') = COALESCE(BF.DBO_ORG_NO,'') -- 运营机构编号 非主键字段相等
         AND COALESCE(TM.MOBILE_NO,'') = COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_ORG_NO,'') = COALESCE(BF.CANCEL_CONT_ORG_NO,'') -- 解约机构编号 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_TELR_NO,'') = COALESCE(BF.CANCEL_CONT_TELR_NO,'') -- 解约交易柜员 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_CHNL_CD,'') = COALESCE(BF.CANCEL_CONT_CHNL_CD,'') -- 解约渠道代码 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_DT,'') = COALESCE(BF.CANCEL_CONT_DT,'') -- 解约日期 非主键字段相等
         AND COALESCE(TM.CANCEL_CONT_RSN_ILUS,'') = COALESCE(BF.CANCEL_CONT_RSN_ILUS,'') -- 解约原因 非主键字段相等
         AND COALESCE(TM.CREATE_TM,'') = COALESCE(BF.CREATE_TM,'') -- 创建时间 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM,'') = COALESCE(BF.FINAL_UPDATE_TM,'') -- 最后修改时间 非主键字段相等
         AND COALESCE(TM.CREATOR_NO,'') = COALESCE(BF.CREATOR_NO,'') -- 创建人编号 非主键字段相等
         AND COALESCE(TM.MODIFIER_NO,'') = COALESCE(BF.MODIFIER_NO,'') -- 修改人编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.LP_NAME,'') = COALESCE(BF.LP_NAME,'') -- 法人名称 非主键字段相等
         AND COALESCE(TM.CORP_DOCTYP_CD,'') = COALESCE(BF.CORP_DOCTYP_CD,'') -- 企业证件类型代码 非主键字段相等
         AND COALESCE(TM.CORP_DOC_NO,'') = COALESCE(BF.CORP_DOC_NO,'') -- 企业证件号码 非主键字段相等
         AND COALESCE(TM.CORP_USER_ID,'') = COALESCE(BF.CORP_USER_ID,'') -- 企业用户ID 非主键字段相等
         AND COALESCE(TM.LP_CONT_NO_NO,'') = COALESCE(BF.LP_CONT_NO_NO,'') -- 法人联系电话号码 非主键字段相等
         AND COALESCE(TM.LP_DOCTYP_CD,'') = COALESCE(BF.LP_DOCTYP_CD,'') -- 法人证件类型代码 非主键字段相等
         AND COALESCE(TM.LP_DOC_NO,'') = COALESCE(BF.LP_DOC_NO,'') -- 法人证件号码 非主键字段相等
         AND COALESCE(TM.AUTON_CNTER_REG_IDNT_CD,'') = COALESCE(BF.AUTON_CNTER_REG_IDNT_CD,'') -- 自主柜面注册标识代码 非主键字段相等
         AND COALESCE(TM.CORP_BANK_MGMT_IDNT_CD,'') = COALESCE(BF.CORP_BANK_MGMT_IDNT_CD,'') -- 企业银行管理标识代码 非主键字段相等
         AND COALESCE(TM.CORP_CUST_STATUS,'') = COALESCE(BF.CORP_CUST_STATUS,'') -- 企业客户状态 非主键字段相等
         AND COALESCE(TM.SYN_CD_CUST_TYPE_CD,'') = COALESCE(BF.SYN_CD_CUST_TYPE_CD,'') -- 客户等级代码 非主键字段相等
         AND COALESCE(TM.GRP_CUST_FLAG,'') = COALESCE(BF.GRP_CUST_FLAG,'') -- 集团客户标志 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CONT_NO,'') <> COALESCE(BF.CONT_NO,'') -- 合约编号 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NO,'') <> COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段不相等
         OR COALESCE(TM.SYN_PAYOFF_SIGN_PROD_CD,'') <> COALESCE(BF.SYN_PAYOFF_SIGN_PROD_CD,'') -- 综合代发签约产品代码 非主键字段不相等
         OR COALESCE(TM.SIGN_PROD_NAME,'') <> COALESCE(BF.SIGN_PROD_NAME,'') -- 签约产品名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.CUST_BELONG_ORG_NO,'') <> COALESCE(BF.CUST_BELONG_ORG_NO,'') -- 客户归属机构编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.OPEN_ACCT_ORG_NO,'') -- 开户机构编号 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_TM,'') <> COALESCE(BF.OPEN_ACCT_TM,'') -- 开户时间 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_AGT_NO,'') <> COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段不相等
         OR COALESCE(TM.SIGN_CONTR_DT,'') <> COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段不相等
         OR COALESCE(TM.TXN_CHNL_CD,'') <> COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段不相等
         OR COALESCE(TM.TXN_TELR_NO,'') <> COALESCE(BF.TXN_TELR_NO,'') -- 交易柜员编号 非主键字段不相等
         OR COALESCE(TM.OPER_TELR_NO,'') <> COALESCE(BF.OPER_TELR_NO,'') -- 操作柜员编号 非主键字段不相等
         OR COALESCE(TM.SYN_PAYOFF_SIGN_TYPE_CD,'') <> COALESCE(BF.SYN_PAYOFF_SIGN_TYPE_CD,'') -- 综合代发签约类型代码 非主键字段不相等
         OR COALESCE(TM.IMAGE_PLAT_SER_NO,'') <> COALESCE(BF.IMAGE_PLAT_SER_NO,'') -- 影像平台流水号 非主键字段不相等
         OR COALESCE(TM.SIGN_ORG_NO,'') <> COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段不相等
         OR COALESCE(TM.CONT_EFFECT_DT,'') <> COALESCE(BF.CONT_EFFECT_DT,'') -- 合约生效日期 非主键字段不相等
         OR COALESCE(TM.CONT_EXPIR_DT,'') <> COALESCE(BF.CONT_EXPIR_DT,'') -- 合约失效日期 非主键字段不相等
         OR COALESCE(TM.SYN_PAYOFF_SIGN_STATUS_CD,'') <> COALESCE(BF.SYN_PAYOFF_SIGN_STATUS_CD,'') -- 综合代发签约状态代码 非主键字段不相等
         OR COALESCE(TM.DBO_ORG_NO,'') <> COALESCE(BF.DBO_ORG_NO,'') -- 运营机构编号 非主键字段不相等
         OR COALESCE(TM.MOBILE_NO,'') <> COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_ORG_NO,'') <> COALESCE(BF.CANCEL_CONT_ORG_NO,'') -- 解约机构编号 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_TELR_NO,'') <> COALESCE(BF.CANCEL_CONT_TELR_NO,'') -- 解约交易柜员 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_CHNL_CD,'') <> COALESCE(BF.CANCEL_CONT_CHNL_CD,'') -- 解约渠道代码 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_DT,'') <> COALESCE(BF.CANCEL_CONT_DT,'') -- 解约日期 非主键字段不相等
         OR COALESCE(TM.CANCEL_CONT_RSN_ILUS,'') <> COALESCE(BF.CANCEL_CONT_RSN_ILUS,'') -- 解约原因 非主键字段不相等
         OR COALESCE(TM.CREATE_TM,'') <> COALESCE(BF.CREATE_TM,'') -- 创建时间 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM,'') <> COALESCE(BF.FINAL_UPDATE_TM,'') -- 最后修改时间 非主键字段不相等
         OR COALESCE(TM.CREATOR_NO,'') <> COALESCE(BF.CREATOR_NO,'') -- 创建人编号 非主键字段不相等
         OR COALESCE(TM.MODIFIER_NO,'') <> COALESCE(BF.MODIFIER_NO,'') -- 修改人编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.LP_NAME,'') <> COALESCE(BF.LP_NAME,'') -- 法人名称 非主键字段不相等
         OR COALESCE(TM.CORP_DOCTYP_CD,'') <> COALESCE(BF.CORP_DOCTYP_CD,'') -- 企业证件类型代码 非主键字段不相等
         OR COALESCE(TM.CORP_DOC_NO,'') <> COALESCE(BF.CORP_DOC_NO,'') -- 企业证件号码 非主键字段不相等
         OR COALESCE(TM.CORP_USER_ID,'') <> COALESCE(BF.CORP_USER_ID,'') -- 企业用户ID 非主键字段不相等
         OR COALESCE(TM.LP_CONT_NO_NO,'') <> COALESCE(BF.LP_CONT_NO_NO,'') -- 法人联系电话号码 非主键字段不相等
         OR COALESCE(TM.LP_DOCTYP_CD,'') <> COALESCE(BF.LP_DOCTYP_CD,'') -- 法人证件类型代码 非主键字段不相等
         OR COALESCE(TM.LP_DOC_NO,'') <> COALESCE(BF.LP_DOC_NO,'') -- 法人证件号码 非主键字段不相等
         OR COALESCE(TM.AUTON_CNTER_REG_IDNT_CD,'') <> COALESCE(BF.AUTON_CNTER_REG_IDNT_CD,'') -- 自主柜面注册标识代码 非主键字段不相等
         OR COALESCE(TM.CORP_BANK_MGMT_IDNT_CD,'') <> COALESCE(BF.CORP_BANK_MGMT_IDNT_CD,'') -- 企业银行管理标识代码 非主键字段不相等
         OR COALESCE(TM.CORP_CUST_STATUS,'') <> COALESCE(BF.CORP_CUST_STATUS,'') -- 企业客户状态 非主键字段不相等
         OR COALESCE(TM.SYN_CD_CUST_TYPE_CD,'') <> COALESCE(BF.SYN_CD_CUST_TYPE_CD,'') -- 客户等级代码 非主键字段不相等
         OR COALESCE(TM.GRP_CUST_FLAG,'') <> COALESCE(BF.GRP_CUST_FLAG,'') -- 集团客户标志 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.SYN_PAYOFF_AGT_NO,'') = COALESCE(BF.SYN_PAYOFF_AGT_NO,'') -- 综合代发协议编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_SYN_PAYOFF_AGT_INFO_TF_TM;
