-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-移动展业交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_YDZY_TXN_DTL_TA
--     表中文名：移动展业交易明细聚合
--     创建日期：2024-06-11 00:00:00
--     主键字段：TXN_SER_NO, EVENT_ID
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：选取移动展业系统交易流水表的全部信息
--     更新记录：
--         2024-06-11 00:00:00 王穆军 new
--         2024-09-03 00:00:00 王穆军 修改字段
--         2024-10-08 00:00:00 王穆军 新增主键字段



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_YDZY_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_YDZY_TXN_DTL_TA_TM
USING ORC
COMMENT '移动展业交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,EVENT_ID -- 事件ID
    ,TXN_DT -- 交易日期
    ,TXN_TM -- 交易时间
    ,PAD_EQUIP_NO -- PAD设备编号
    ,PAD_EQUIP_MODEL -- PAD设备型号
    ,MAC_ADDR -- MAC地址
    ,BJ_NO -- 背夹编号
    ,IP_ADDR -- IP地址
    ,GEOG_PSTN_LGTD -- 地理位置经度
    ,GEOG_PSTN_LATD -- 地理位置纬度
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,BANK_CARD_NO -- 银行卡号
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,ELEC_VOCH_PERMNT_KEEP_FLAG -- 电子凭证永久保留标志
    ,ORG_NO -- 机构编号
    ,MENU_NO -- 菜单编号
    ,MENU_MODULE_NAME -- 菜单模块名称
    ,TXN_SERV_LINK_DESC -- 交易服务链接描述
    ,TXN_NAME -- 交易名称
    ,TXN_DESC_1 -- 交易描述1
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_TELR_NAME -- 交易柜员名称
    ,HANDLE_TELR_POST_CD -- 经办柜员岗位代码
    ,HANDLE_TELR_POST_NAME -- 经办柜员岗位名称
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_FLAG -- 授权标志
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,TXN_ACCT_CATEGORY_IDNT_CD -- 交易账务类别标识代码
    ,TXN_RESLT_DESC_1 -- 交易结果描述
    ,TXN_RESLT_DESC_2 -- 交易结果描述
    ,FRONT_SER_NO -- 前置流水号
    ,TELR_SER_NO -- 柜员流水号
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,GLOB_SER_NO -- 全局流水号
    ,CORE_SER_NO -- 核心流水号
    ,CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,REM -- 备注
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_YDZY_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_YDZY_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL.AGL_YDZY_TXN_DTL_TA_TM(
     TXN_SER_NO -- 交易流水号
    ,EVENT_ID -- 事件ID
    ,TXN_DT -- 交易日期
    ,TXN_TM -- 交易时间
    ,PAD_EQUIP_NO -- PAD设备编号
    ,PAD_EQUIP_MODEL -- PAD设备型号
    ,MAC_ADDR -- MAC地址
    ,BJ_NO -- 背夹编号
    ,IP_ADDR -- IP地址
    ,GEOG_PSTN_LGTD -- 地理位置经度
    ,GEOG_PSTN_LATD -- 地理位置纬度
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,BANK_CARD_NO -- 银行卡号
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,ELEC_VOCH_PERMNT_KEEP_FLAG -- 电子凭证永久保留标志
    ,ORG_NO -- 机构编号
    ,MENU_NO -- 菜单编号
    ,MENU_MODULE_NAME -- 菜单模块名称
    ,TXN_SERV_LINK_DESC -- 交易服务链接描述
    ,TXN_NAME -- 交易名称
    ,TXN_DESC_1 -- 交易描述1
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_TELR_NAME -- 交易柜员名称
    ,HANDLE_TELR_POST_CD -- 经办柜员岗位代码
    ,HANDLE_TELR_POST_NAME -- 经办柜员岗位名称
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_FLAG -- 授权标志
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,TXN_ACCT_CATEGORY_IDNT_CD -- 交易账务类别标识代码
    ,TXN_RESLT_DESC_1 -- 交易结果描述
    ,TXN_RESLT_DESC_2 -- 交易结果描述
    ,FRONT_SER_NO -- 前置流水号
    ,TELR_SER_NO -- 柜员流水号
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,GLOB_SER_NO -- 全局流水号
    ,CORE_SER_NO -- 核心流水号
    ,CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,REM -- 备注
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.TRD_SEQNO AS TXN_SER_NO -- 交易流水号
    ,T1.ID AS EVENT_ID -- 事件ID
    ,unifiedTime(T1.TRADE_DATE) AS TXN_DT -- 交易日期
    ,T1.TRADE_TIME AS TXN_TM -- 交易时间
    ,T1.DEVICE_ID AS PAD_EQUIP_NO -- PAD设备编号
    ,T1.DEVICE_TYPE AS PAD_EQUIP_MODEL -- PAD设备型号
    ,T1.DEVICE_MAC AS MAC_ADDR -- MAC地址
    ,T1.BACK_SPLINT_ID AS BJ_NO -- 背夹编号
    ,T1.IP_ADDR AS IP_ADDR -- IP地址
    ,T1.POS_X AS GEOG_PSTN_LGTD -- 地理位置经度
    ,T1.POS_Y AS GEOG_PSTN_LATD -- 地理位置纬度
    ,CASE WHEN CERT_TYPE IS NOT NULL AND CERT_NO IS NOT NULL then  T4.CST_IN_CD ELSE '' END  AS CUST_IN_CD -- 客户内码
    ,T1.CUST_NAME AS CUST_NAME -- 客户名称
    ,T1.CARD_NO AS BANK_CARD_NO -- 银行卡号
    ,T1.CERT_TYPE AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,T1.CERT_NO AS CUST_DOC_NO -- 客户证件号码
    ,T1.CELLPHONE_NO AS CUST_MOBILE_NO -- 客户手机号码
    ,CASE WHEN T1.ALTER_FIELD1 = '1' THEN '0'
WHEN T1.ALTER_FIELD1 = '2' THEN '1'  END  AS ELEC_VOCH_PERMNT_KEEP_FLAG -- 电子凭证永久保留标志
    ,T1.ORG_ID AS ORG_NO -- 机构编号
    ,T1.MENU_ID AS MENU_NO -- 菜单编号
    ,T3.MENU_NAME AS MENU_MODULE_NAME -- 菜单模块名称
    ,T1.TRADE_TYPE AS TXN_SERV_LINK_DESC -- 交易服务链接描述
    ,T1.TRAN_NAME AS TXN_NAME -- 交易名称
    ,T1.TRAN_CODE AS TXN_DESC_1 -- 交易描述1
    ,T1.TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,T1.TELLER_NAME AS TXN_TELR_NAME -- 交易柜员名称
    ,T1.TELLER_POST_ID AS HANDLE_TELR_POST_CD -- 经办柜员岗位代码
    ,T2.POST_NAME AS HANDLE_TELR_POST_NAME -- 经办柜员岗位名称
    ,T1.AUTH_TELLER_NO AS AUTH_TELR_NO -- 授权柜员编号
    ,CASE T1.AUTH_FLAG WHEN '1' THEN '1'
WHEN '2' THEN '0'
END  AS AUTH_FLAG -- 授权标志
    ,T1.VIRTUAL_TELLER_NO AS VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,T1.TRADE_CLASS AS TXN_ACCT_CATEGORY_IDNT_CD -- 交易账务类别标识代码
    ,T1.TRADE_REST AS TXN_RESLT_DESC_1 -- 交易结果描述
    ,T1.TRADE_DESC AS TXN_RESLT_DESC_2 -- 交易结果描述
    ,T1.PRE_SEQNO AS FRONT_SER_NO -- 前置流水号
    ,T1.TER_SEQNO AS TELR_SER_NO -- 柜员流水号
    ,T1.IMG_SEQNO AS IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,T1.GLB_SEQNO AS GLOB_SER_NO -- 全局流水号
    ,T1.COR_SEQNO AS CORE_SER_NO -- 核心流水号
    ,T1.SUB_TRD_SEQNO AS CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,T1.BIZ_NO AS REM -- 备注
    ,unifiedTime(T1.GMT_CREATE) AS SETUP_TM_STAMP -- 建立时间戳
    ,unifiedTime(T1.GMT_MODIFIED) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'YDZY' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_YDZY_PUB_TARDE_LOG_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_YDZY.ODS_YDZY_PUB_TARDE_LOG_TA AS T1 -- 交易流水表

LEFT JOIN ODS_YDZY.ODS_YDZY_ICEP_POST_TF AS T2 -- 岗位对应表
       ON T1.TELLER_POST_ID=T2.POST_ID
and t2.pt_dt  = '${process_date}'
and t2.del_f = '0' 
LEFT JOIN ODS_YDZY.ODS_YDZY_ICEP_MENU_TF AS T3 -- 渠道菜单信息表
       ON T1.menu_ID=T3.menu_ID
and t3.pt_dt  = '${process_date}'
and t3.del_f = '0' 
LEFT JOIN (
select
 *,
 row_number () over(partition by crtf_typ ,
 crtf_no
order by
 gmt_create desc)rn
from
 ods_eicc.ODS_EICC_C_CUS_PRIV_CRTF_TF
where
 pt_dt = '${process_date}'
 and del_f = '0'
 ) AS T4 -- 客户证件信息表
       ON T1.cert_type=T4.CRTF_TYP
AND T1.cert_no=T4.CRTF_NO
and t4.rn =1 
WHERE t1.pt_dt  = '${process_date}'
and t1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_YDZY_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_YDZY_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_YDZY_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,EVENT_ID -- 事件ID
    ,TXN_DT -- 交易日期
    ,TXN_TM -- 交易时间
    ,PAD_EQUIP_NO -- PAD设备编号
    ,PAD_EQUIP_MODEL -- PAD设备型号
    ,MAC_ADDR -- MAC地址
    ,BJ_NO -- 背夹编号
    ,IP_ADDR -- IP地址
    ,GEOG_PSTN_LGTD -- 地理位置经度
    ,GEOG_PSTN_LATD -- 地理位置纬度
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,BANK_CARD_NO -- 银行卡号
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,ELEC_VOCH_PERMNT_KEEP_FLAG -- 电子凭证永久保留标志
    ,ORG_NO -- 机构编号
    ,MENU_NO -- 菜单编号
    ,MENU_MODULE_NAME -- 菜单模块名称
    ,TXN_SERV_LINK_DESC -- 交易服务链接描述
    ,TXN_NAME -- 交易名称
    ,TXN_DESC_1 -- 交易描述1
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_TELR_NAME -- 交易柜员名称
    ,HANDLE_TELR_POST_CD -- 经办柜员岗位代码
    ,HANDLE_TELR_POST_NAME -- 经办柜员岗位名称
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_FLAG -- 授权标志
    ,VIRTUAL_TELR_NO -- 虚拟柜员编号
    ,TXN_ACCT_CATEGORY_IDNT_CD -- 交易账务类别标识代码
    ,TXN_RESLT_DESC_1 -- 交易结果描述
    ,TXN_RESLT_DESC_2 -- 交易结果描述
    ,FRONT_SER_NO -- 前置流水号
    ,TELR_SER_NO -- 柜员流水号
    ,IMAGE_PLAT_SER_NO -- 影像平台流水号
    ,GLOB_SER_NO -- 全局流水号
    ,CORE_SER_NO -- 核心流水号
    ,CORE_SUB_TXN_SER_NO -- 核心子交易流水号
    ,REM -- 备注
    ,SETUP_TM_STAMP -- 建立时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_YDZY_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_YDZY_TXN_DTL_TA_TM;
