-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-财政代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF
--     表中文名：财政代发交易明细聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO, TXN_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建
--         2024-09-23 00:00:00 叶禹 第三组表补齐，目标表没上线



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM
USING ORC
COMMENT '财政代发交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 财政代发交易明细聚合

INSERT INTO TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM(
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PLAT_DATE AS TXN_DT -- 交易日期
    ,'' AS PLAT_BATCH_NO -- 平台批次编号
    ,'' AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,'1' AS SRC_SYS_CD1 -- 来源系统代码1
    ,'' AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,'' AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,'' AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,'1' AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,P1.CHN_TYPE AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,P1.ECODE AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.GWK_FLAG AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,P1.CHN_NO AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,'' AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,'' AS PAY_CORP_NO -- 付款单位编号
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,P1.SET_ACT_LHBRCH AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.ACT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.ACT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.ACT_HM AS RECV_BANK_NAME_1 -- 收款行名称1
    ,P1.ACT_LHH AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.ACT_LHHM AS RECV_BANK_NAME_2 -- 收款行名称2
    ,P1.OPEN_BRCH_NO AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,P1.SET_ACT_NO AS ZBA_NO -- 零余额账户编号
    ,P1.SET_ACT_NAME AS ZBA_NAME -- 零余额账户名称
    ,P1.ACT_TIME AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS BUDGET_CORP_NO -- 预算单位编号
    ,P1.ENAME AS BUDGET_CORP_NAME -- 预算单位名称
    ,P1.PURPOSE AS TXN_USAGE_DESC -- 交易用途描述
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS MOBILE_NO -- 手机号码
    ,P1.REMARK AS REM -- 备注
    ,P1.MENO AS SUMMARY_ILUS -- 摘要说明
    ,P1.ADDWORD AS POSTSC_DESC -- 附言描述
    ,'OFISCAL' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFISCAL_T_ZJZF_JS_JRNL_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFISCAL.ODS_OFISCAL_T_ZJZF_JS_JRNL_TF AS P1 -- 国库单位支付清算流水表

WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- 财政代发交易明细聚合

INSERT INTO TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM(
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PLAT_DATE  AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO   AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'1' AS SRC_SYS_CD1 -- 来源系统代码1
    ,'' AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,'' AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,'' AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,'1' AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,'' AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,P1.ACCT_NAME AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,'' AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,'' AS PAY_CORP_NO -- 付款单位编号
    ,P1.SET_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,'' AS FUND_COL_ACCT_NO -- 收款账户编号
    ,'' AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS RECV_BANK_NAME_1 -- 收款行名称1
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS RECV_BANK_NAME_2 -- 收款行名称2
    ,'' AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,'' AS ZBA_NO -- 零余额账户编号
    ,'' AS ZBA_NAME -- 零余额账户名称
    ,'' AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,P1.ECODE AS BUDGET_CORP_NO -- 预算单位编号
    ,'' AS BUDGET_CORP_NAME -- 预算单位名称
    ,'' AS TXN_USAGE_DESC -- 交易用途描述
    ,'' AS CURR_CD -- 币种代码
    ,P1.PHONE AS MOBILE_NO -- 手机号码
    ,'' AS REM -- 备注
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,'' AS POSTSC_DESC -- 附言描述
    ,'OFISCAL' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFISCAL_T_GWK_CRT_BAT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFISCAL.ODS_OFISCAL_T_GWK_CRT_BAT_TF AS P1 -- 个人公务卡贷记卡批量明细表

WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- 财政代发交易明细聚合

INSERT INTO TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM(
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PLAT_DATE AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'1' AS SRC_SYS_CD1 -- 来源系统代码1
    ,'' AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,'' AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,P1.BAT_TYPE AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,'1' AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,'' AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.USER_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.USER_ID_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.USER_ID_NO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,'' AS PAY_CORP_NO -- 付款单位编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS RECV_BANK_NAME_1 -- 收款行名称1
    ,P1.BANK_NO AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.BANK_NAME AS RECV_BANK_NAME_2 -- 收款行名称2
    ,'' AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,'' AS ZBA_NO -- 零余额账户编号
    ,'' AS ZBA_NAME -- 零余额账户名称
    ,'' AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS BUDGET_CORP_NO -- 预算单位编号
    ,'' AS BUDGET_CORP_NAME -- 预算单位名称
    ,'' AS TXN_USAGE_DESC -- 交易用途描述
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS REM -- 备注
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OFISCAL' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFISCAL_T_ZJZF_BATDET_ACC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFISCAL.ODS_OFISCAL_T_ZJZF_BATDET_ACC_TF AS P1 -- 国库集中支付批量代发明细表

WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- 财政代发交易明细聚合

INSERT INTO TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM(
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PLAT_DATE AS TXN_DT -- 交易日期
    ,'' AS PLAT_BATCH_NO -- 平台批次编号
    ,'' AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,P1.SEQ_NO AS TXN_SER_NO -- 交易流水号
    ,'' AS SRC_SYS_CD1 -- 来源系统代码1
    ,'' AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,'' AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,'' AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,'' AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,P1.CHN_TYPE AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,P1.ECODE AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.GWK_FLAG AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,P1.CHN_NO AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,'' AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,'' AS PAY_CORP_NO -- 付款单位编号
    ,'' AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,'' AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,P1.SET_ACT_LHBRCH AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.ACT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.ACT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.ACT_HM AS RECV_BANK_NAME_1 -- 收款行名称1
    ,P1.ACT_LHH AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,P1.ACT_LHHM AS RECV_BANK_NAME_2 -- 收款行名称2
    ,P1.OPEN_BRCH_NO AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,P1.SET_ACT_NO AS ZBA_NO -- 零余额账户编号
    ,P1.SET_ACT_NAME AS ZBA_NAME -- 零余额账户名称
    ,P1.ACT_TIME AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS BUDGET_CORP_NO -- 预算单位编号
    ,P1.ENAME AS BUDGET_CORP_NAME -- 预算单位名称
    ,P1.PURPOSE AS TXN_USAGE_DESC -- 交易用途描述
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS MOBILE_NO -- 手机号码
    ,P1.REMARK AS REM -- 备注
    ,P1.MENO AS SUMMARY_ILUS -- 摘要说明
    ,P1.ADDWORD AS POSTSC_DESC -- 附言描述
    ,'OFISCAL' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFISCAL_T_ZJZF_JS_JRNL_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFISCAL.ODS_OFISCAL_T_ZJZF_JS_JRNL_TF AS P1 -- 省版集中支付结算流水表

WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第5组）==============
-- 财政代发交易明细聚合

INSERT INTO TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM(
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PLAT_DATE AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'3' AS SRC_SYS_CD1 -- 来源系统代码1
    ,P1.CHN_TYPE AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,P1.BANK_FLAG AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,'' AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,'2' AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,'' AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,'' AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,'' AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,'' AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,'' AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,P1.CORP_NAME AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,P1.CORP_NO AS PAY_CORP_NO -- 付款单位编号
    ,P1.PAY_ACCOUNT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCOUNT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,P1.PAY_BANK_NAME AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,P1.PAY_BANKNO AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,P1.OPEN_BRCH AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.RECEIVE_ACCOUNT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.RECEIVE_ACCOUNT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.RECEIVE_BANK_NO AS RECV_BANK_NAME_1 -- 收款行名称1
    ,P1.RECEIVE_BANK_NAME AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS RECV_BANK_NAME_2 -- 收款行名称2
    ,'' AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,'' AS ZBA_NO -- 零余额账户编号
    ,'' AS ZBA_NAME -- 零余额账户名称
    ,P1.HOST_TIME AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS BUDGET_CORP_NO -- 预算单位编号
    ,'' AS BUDGET_CORP_NAME -- 预算单位名称
    ,P1.PURPOSE_DESC AS TXN_USAGE_DESC -- 交易用途描述
    ,'' AS CURR_CD -- 币种代码
    ,'' AS MOBILE_NO -- 手机号码
    ,P1.MEMO AS REM -- 备注
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.POSTSCRIPT AS POSTSC_DESC -- 附言描述
    ,'mid72' AS SRC_SYS_CD -- 来源系统代码
    ,'FISC_FCZZJ_PAY_TASK_MX' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
mid72.FISC_FCZZJ_PAY_TASK_MX AS P1 -- 非财政资金支付批量明细表

WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第6组）==============
-- 财政代发交易明细聚合

INSERT INTO TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM(
     TXN_DT -- 交易日期
    ,PLAT_BATCH_NO -- 平台批次编号
    ,BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,TXN_SER_NO -- 交易流水号
    ,SRC_SYS_CD1 -- 来源系统代码1
    ,AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,BIZ_UNIT_NO -- 业务单元编号
    ,PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CRDT_CARD_CARD_NO -- 信用卡卡号
    ,TXN_AMT -- 交易金额
    ,PAY_MNY_CORP_NAME -- 付款单位名称
    ,PAY_CORP_NO -- 付款单位编号
    ,PAY_FUND_ACCT_NO -- 付款账户编号
    ,PAY_ACCT_NAME -- 付款账户名称
    ,PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,RECV_BANK_NAME_1 -- 收款行名称1
    ,PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,RECV_BANK_NAME_2 -- 收款行名称2
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,ZBA_NO -- 零余额账户编号
    ,ZBA_NAME -- 零余额账户名称
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,BUDGET_CORP_NO -- 预算单位编号
    ,BUDGET_CORP_NAME -- 预算单位名称
    ,TXN_USAGE_DESC -- 交易用途描述
    ,CURR_CD -- 币种代码
    ,MOBILE_NO -- 手机号码
    ,REM -- 备注
    ,SUMMARY_ILUS -- 摘要说明
    ,POSTSC_DESC -- 附言描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PLAT_DATE AS TXN_DT -- 交易日期
    ,P1.BAT_SEQ AS PLAT_BATCH_NO -- 平台批次编号
    ,P1.SERI_NO AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'2' AS SRC_SYS_CD1 -- 来源系统代码1
    ,'' AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,'' AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,P1.BAT_TYPE AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,'1' AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,'' AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.USER_NO AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,P1.USER_TYPE AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,P1.USER_NAME AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,P1.USER_ID_TYPE AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,P1.USER_ID_NO AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,'' AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,P1.TOT_AMT AS TXN_AMT -- 交易金额
    ,'' AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,'' AS PAY_CORP_NO -- 付款单位编号
    ,P1.PAY_ACCT_NO AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,P1.PAY_ACCT_NAME AS PAY_ACCT_NAME -- 付款账户名称
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,'' AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,'' AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,P1.PAYEE_ACCT_NO AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.PAYEE_ACCT_NAME AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,'' AS RECV_BANK_NAME_1 -- 收款行名称1
    ,'' AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,'' AS RECV_BANK_NAME_2 -- 收款行名称2
    ,'' AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,'' AS ZBA_NO -- 零余额账户编号
    ,'' AS ZBA_NAME -- 零余额账户名称
    ,'' AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS BUDGET_CORP_NO -- 预算单位编号
    ,'' AS BUDGET_CORP_NAME -- 预算单位名称
    ,'' AS TXN_USAGE_DESC -- 交易用途描述
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,'' AS MOBILE_NO -- 手机号码
    ,'' AS REM -- 备注
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,P1.DSCRP_MSG AS POSTSC_DESC -- 附言描述
    ,'OFISCAL' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFISCAL_T_ZJCZ_BAT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFISCAL.ODS_OFISCAL_T_ZJCZ_BAT_TF AS P1 -- 财政公共服务平台批量明细表

WHERE P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.TXN_DT, BF.TXN_DT) END AS TXN_DT -- 交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PLAT_BATCH_NO IS NULL THEN NULL ELSE COALESCE(TM.PLAT_BATCH_NO, BF.PLAT_BATCH_NO) END AS PLAT_BATCH_NO -- 平台批次编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BAT_AGEN_PAY_SEQ_NO IS NULL THEN NULL ELSE COALESCE(TM.BAT_AGEN_PAY_SEQ_NO, BF.BAT_AGEN_PAY_SEQ_NO) END AS BAT_AGEN_PAY_SEQ_NO -- 批量代发顺序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.TXN_SER_NO, BF.TXN_SER_NO) END AS TXN_SER_NO -- 交易流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD1 IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD1, BF.SRC_SYS_CD1) END AS SRC_SYS_CD1 -- 来源系统代码1
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGEN_GOV_FUND_COL_ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.AGEN_GOV_FUND_COL_ACCT_TYPE_CD, BF.AGEN_GOV_FUND_COL_ACCT_TYPE_CD) END AS AGEN_GOV_FUND_COL_ACCT_TYPE_CD -- 代理政府收款账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FUND_COL_ACCT_CROSS_BANK_FLAG IS NULL THEN NULL ELSE COALESCE(TM.FUND_COL_ACCT_CROSS_BANK_FLAG, BF.FUND_COL_ACCT_CROSS_BANK_FLAG) END AS FUND_COL_ACCT_CROSS_BANK_FLAG -- 收款账户跨行标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGEN_GOV_PAYOFF_BIZ_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.AGEN_GOV_PAYOFF_BIZ_TYPE_CD, BF.AGEN_GOV_PAYOFF_BIZ_TYPE_CD) END AS AGEN_GOV_PAYOFF_BIZ_TYPE_CD -- 代理政府代发业务类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FISCAL_PAYOFF_FLAG IS NULL THEN NULL ELSE COALESCE(TM.FISCAL_PAYOFF_FLAG, BF.FISCAL_PAYOFF_FLAG) END AS FISCAL_PAYOFF_FLAG -- 财政代发标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GOV_PAYOFF_CLEAR_PATH_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.GOV_PAYOFF_CLEAR_PATH_TYPE_CD, BF.GOV_PAYOFF_CLEAR_PATH_TYPE_CD) END AS GOV_PAYOFF_CLEAR_PATH_TYPE_CD -- 政府代发清算途径类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NO IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NO, BF.BIZ_UNIT_NO) END AS BIZ_UNIT_NO -- 业务单元编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PUB_AFFAIR_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.PUB_AFFAIR_CARD_FLAG, BF.PUB_AFFAIR_CARD_FLAG) END AS PUB_AFFAIR_CARD_FLAG -- 公务卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CHNL_CD, BF.TXN_CHNL_CD) END AS TXN_CHNL_CD -- 交易渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRTCPT_INSURE_OBJ_NO IS NULL THEN NULL ELSE COALESCE(TM.PRTCPT_INSURE_OBJ_NO, BF.PRTCPT_INSURE_OBJ_NO) END AS PRTCPT_INSURE_OBJ_NO -- 参保对象编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRTCPT_INSURE_OBJ_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.PRTCPT_INSURE_OBJ_TYPE_CD, BF.PRTCPT_INSURE_OBJ_TYPE_CD) END AS PRTCPT_INSURE_OBJ_TYPE_CD -- 参保对象类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRTCPT_INSURE_OBJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.PRTCPT_INSURE_OBJ_NAME, BF.PRTCPT_INSURE_OBJ_NAME) END AS PRTCPT_INSURE_OBJ_NAME -- 参保对象名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRTCPT_INSURE_OBJ_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.PRTCPT_INSURE_OBJ_DOCTYP_CD, BF.PRTCPT_INSURE_OBJ_DOCTYP_CD) END AS PRTCPT_INSURE_OBJ_DOCTYP_CD -- 参保对象证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRTCPT_INSURE_OBJ_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.PRTCPT_INSURE_OBJ_DOC_NO, BF.PRTCPT_INSURE_OBJ_DOC_NO) END AS PRTCPT_INSURE_OBJ_DOC_NO -- 参保对象证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CRDT_CARD_CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.CRDT_CARD_CARD_NO, BF.CRDT_CARD_CARD_NO) END AS CRDT_CARD_CARD_NO -- 信用卡卡号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_AMT IS NULL THEN NULL ELSE COALESCE(TM.TXN_AMT, BF.TXN_AMT) END AS TXN_AMT -- 交易金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_MNY_CORP_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_MNY_CORP_NAME, BF.PAY_MNY_CORP_NAME) END AS PAY_MNY_CORP_NAME -- 付款单位名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_CORP_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_CORP_NO, BF.PAY_CORP_NO) END AS PAY_CORP_NO -- 付款单位编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_FUND_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_FUND_ACCT_NO, BF.PAY_FUND_ACCT_NO) END AS PAY_FUND_ACCT_NO -- 付款账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_ACCT_NAME, BF.PAY_ACCT_NAME) END AS PAY_ACCT_NAME -- 付款账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_ACCT_OPEN_ACCT_ORG_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NAME, BF.PAY_ACCT_OPEN_ACCT_ORG_NAME) END AS PAY_ACCT_OPEN_ACCT_ORG_NAME -- 付款账户开户机构名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYER_CNAPS_CODE IS NULL THEN NULL ELSE COALESCE(TM.PAYER_CNAPS_CODE, BF.PAYER_CNAPS_CODE) END AS PAYER_CNAPS_CODE -- 付款方人行支付行号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_ACCT_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NO, BF.PAY_ACCT_OPEN_ACCT_ORG_NO) END AS PAY_ACCT_OPEN_ACCT_ORG_NO -- 付款账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FUND_COL_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.FUND_COL_ACCT_NO, BF.FUND_COL_ACCT_NO) END AS FUND_COL_ACCT_NO -- 收款账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FUND_COL_ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.FUND_COL_ACCT_NAME, BF.FUND_COL_ACCT_NAME) END AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BANK_NAME_1 IS NULL THEN NULL ELSE COALESCE(TM.RECV_BANK_NAME_1, BF.RECV_BANK_NAME_1) END AS RECV_BANK_NAME_1 -- 收款行名称1
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYEE_CNAPS_CODE IS NULL THEN NULL ELSE COALESCE(TM.PAYEE_CNAPS_CODE, BF.PAYEE_CNAPS_CODE) END AS PAYEE_CNAPS_CODE -- 收款方人行支付行号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BANK_NAME_2 IS NULL THEN NULL ELSE COALESCE(TM.RECV_BANK_NAME_2, BF.RECV_BANK_NAME_2) END AS RECV_BANK_NAME_2 -- 收款行名称2
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYEE_ACCT_BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NO, BF.PAYEE_ACCT_BELONG_ORG_NO) END AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ZBA_NO IS NULL THEN NULL ELSE COALESCE(TM.ZBA_NO, BF.ZBA_NO) END AS ZBA_NO -- 零余额账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ZBA_NAME IS NULL THEN NULL ELSE COALESCE(TM.ZBA_NAME, BF.ZBA_NAME) END AS ZBA_NAME -- 零余额账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.HOST_TXN_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.HOST_TXN_TM_STAMP, BF.HOST_TXN_TM_STAMP) END AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BUDGET_CORP_NO IS NULL THEN NULL ELSE COALESCE(TM.BUDGET_CORP_NO, BF.BUDGET_CORP_NO) END AS BUDGET_CORP_NO -- 预算单位编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BUDGET_CORP_NAME IS NULL THEN NULL ELSE COALESCE(TM.BUDGET_CORP_NAME, BF.BUDGET_CORP_NAME) END AS BUDGET_CORP_NAME -- 预算单位名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_USAGE_DESC IS NULL THEN NULL ELSE COALESCE(TM.TXN_USAGE_DESC, BF.TXN_USAGE_DESC) END AS TXN_USAGE_DESC -- 交易用途描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MOBILE_NO IS NULL THEN NULL ELSE COALESCE(TM.MOBILE_NO, BF.MOBILE_NO) END AS MOBILE_NO -- 手机号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REM IS NULL THEN NULL ELSE COALESCE(TM.REM, BF.REM) END AS REM -- 备注
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_ILUS IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_ILUS, BF.SUMMARY_ILUS) END AS SUMMARY_ILUS -- 摘要说明
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POSTSC_DESC IS NULL THEN NULL ELSE COALESCE(TM.POSTSC_DESC, BF.POSTSC_DESC) END AS POSTSC_DESC -- 附言描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SRC_SYS_CD1,'') = COALESCE(BF.SRC_SYS_CD1,'') -- 来源系统代码1 非主键字段相等
         AND COALESCE(TM.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') = COALESCE(BF.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') -- 代理政府收款账户类型代码 非主键字段相等
         AND COALESCE(TM.FUND_COL_ACCT_CROSS_BANK_FLAG,'') = COALESCE(BF.FUND_COL_ACCT_CROSS_BANK_FLAG,'') -- 收款账户跨行标志 非主键字段相等
         AND COALESCE(TM.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') = COALESCE(BF.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') -- 代理政府代发业务类型代码 非主键字段相等
         AND COALESCE(TM.FISCAL_PAYOFF_FLAG,'') = COALESCE(BF.FISCAL_PAYOFF_FLAG,'') -- 财政代发标志 非主键字段相等
         AND COALESCE(TM.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') = COALESCE(BF.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') -- 政府代发清算途径类型代码 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段相等
         AND COALESCE(TM.PUB_AFFAIR_CARD_FLAG,'') = COALESCE(BF.PUB_AFFAIR_CARD_FLAG,'') -- 公务卡标志 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_NO,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_NO,'') -- 参保对象编号 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_TYPE_CD,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_TYPE_CD,'') -- 参保对象类型代码 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_NAME,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_NAME,'') -- 参保对象名称 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') -- 参保对象证件类型代码 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_DOC_NO,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_DOC_NO,'') -- 参保对象证件号码 非主键字段相等
         AND COALESCE(TM.CRDT_CARD_CARD_NO,'') = COALESCE(BF.CRDT_CARD_CARD_NO,'') -- 信用卡卡号 非主键字段相等
         AND COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段相等
         AND COALESCE(TM.PAY_MNY_CORP_NAME,'') = COALESCE(BF.PAY_MNY_CORP_NAME,'') -- 付款单位名称 非主键字段相等
         AND COALESCE(TM.PAY_CORP_NO,'') = COALESCE(BF.PAY_CORP_NO,'') -- 付款单位编号 非主键字段相等
         AND COALESCE(TM.PAY_FUND_ACCT_NO,'') = COALESCE(BF.PAY_FUND_ACCT_NO,'') -- 付款账户编号 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_NAME,'') = COALESCE(BF.PAY_ACCT_NAME,'') -- 付款账户名称 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') -- 付款账户开户机构名称 非主键字段相等
         AND COALESCE(TM.PAYER_CNAPS_CODE,'') = COALESCE(BF.PAYER_CNAPS_CODE,'') -- 付款方人行支付行号 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NO,'') -- 付款账户开户机构编号 非主键字段相等
         AND COALESCE(TM.FUND_COL_ACCT_NO,'') = COALESCE(BF.FUND_COL_ACCT_NO,'') -- 收款账户编号 非主键字段相等
         AND COALESCE(TM.FUND_COL_ACCT_NAME,'') = COALESCE(BF.FUND_COL_ACCT_NAME,'') -- 收款账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BANK_NAME_1,'') = COALESCE(BF.RECV_BANK_NAME_1,'') -- 收款行名称1 非主键字段相等
         AND COALESCE(TM.PAYEE_CNAPS_CODE,'') = COALESCE(BF.PAYEE_CNAPS_CODE,'') -- 收款方人行支付行号 非主键字段相等
         AND COALESCE(TM.RECV_BANK_NAME_2,'') = COALESCE(BF.RECV_BANK_NAME_2,'') -- 收款行名称2 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NO,'') = COALESCE(BF.PAYEE_ACCT_BELONG_ORG_NO,'') -- 收款方账户归属机构编号 非主键字段相等
         AND COALESCE(TM.ZBA_NO,'') = COALESCE(BF.ZBA_NO,'') -- 零余额账户编号 非主键字段相等
         AND COALESCE(TM.ZBA_NAME,'') = COALESCE(BF.ZBA_NAME,'') -- 零余额账户名称 非主键字段相等
         AND COALESCE(TM.HOST_TXN_TM_STAMP,'') = COALESCE(BF.HOST_TXN_TM_STAMP,'') -- 主机交易时间戳 非主键字段相等
         AND COALESCE(TM.BUDGET_CORP_NO,'') = COALESCE(BF.BUDGET_CORP_NO,'') -- 预算单位编号 非主键字段相等
         AND COALESCE(TM.BUDGET_CORP_NAME,'') = COALESCE(BF.BUDGET_CORP_NAME,'') -- 预算单位名称 非主键字段相等
         AND COALESCE(TM.TXN_USAGE_DESC,'') = COALESCE(BF.TXN_USAGE_DESC,'') -- 交易用途描述 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.MOBILE_NO,'') = COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.SUMMARY_ILUS,'') = COALESCE(BF.SUMMARY_ILUS,'') -- 摘要说明 非主键字段相等
         AND COALESCE(TM.POSTSC_DESC,'') = COALESCE(BF.POSTSC_DESC,'') -- 附言描述 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SRC_SYS_CD1,'') <> COALESCE(BF.SRC_SYS_CD1,'') -- 来源系统代码1 非主键字段不相等
         OR COALESCE(TM.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') <> COALESCE(BF.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') -- 代理政府收款账户类型代码 非主键字段不相等
         OR COALESCE(TM.FUND_COL_ACCT_CROSS_BANK_FLAG,'') <> COALESCE(BF.FUND_COL_ACCT_CROSS_BANK_FLAG,'') -- 收款账户跨行标志 非主键字段不相等
         OR COALESCE(TM.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') <> COALESCE(BF.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') -- 代理政府代发业务类型代码 非主键字段不相等
         OR COALESCE(TM.FISCAL_PAYOFF_FLAG,'') <> COALESCE(BF.FISCAL_PAYOFF_FLAG,'') -- 财政代发标志 非主键字段不相等
         OR COALESCE(TM.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') <> COALESCE(BF.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') -- 政府代发清算途径类型代码 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NO,'') <> COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段不相等
         OR COALESCE(TM.PUB_AFFAIR_CARD_FLAG,'') <> COALESCE(BF.PUB_AFFAIR_CARD_FLAG,'') -- 公务卡标志 非主键字段不相等
         OR COALESCE(TM.TXN_CHNL_CD,'') <> COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_NO,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_NO,'') -- 参保对象编号 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_TYPE_CD,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_TYPE_CD,'') -- 参保对象类型代码 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_NAME,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_NAME,'') -- 参保对象名称 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') -- 参保对象证件类型代码 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_DOC_NO,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_DOC_NO,'') -- 参保对象证件号码 非主键字段不相等
         OR COALESCE(TM.CRDT_CARD_CARD_NO,'') <> COALESCE(BF.CRDT_CARD_CARD_NO,'') -- 信用卡卡号 非主键字段不相等
         OR COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段不相等
         OR COALESCE(TM.PAY_MNY_CORP_NAME,'') <> COALESCE(BF.PAY_MNY_CORP_NAME,'') -- 付款单位名称 非主键字段不相等
         OR COALESCE(TM.PAY_CORP_NO,'') <> COALESCE(BF.PAY_CORP_NO,'') -- 付款单位编号 非主键字段不相等
         OR COALESCE(TM.PAY_FUND_ACCT_NO,'') <> COALESCE(BF.PAY_FUND_ACCT_NO,'') -- 付款账户编号 非主键字段不相等
         OR COALESCE(TM.PAY_ACCT_NAME,'') <> COALESCE(BF.PAY_ACCT_NAME,'') -- 付款账户名称 非主键字段不相等
         OR COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') -- 付款账户开户机构名称 非主键字段不相等
         OR COALESCE(TM.PAYER_CNAPS_CODE,'') <> COALESCE(BF.PAYER_CNAPS_CODE,'') -- 付款方人行支付行号 非主键字段不相等
         OR COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NO,'') -- 付款账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.FUND_COL_ACCT_NO,'') <> COALESCE(BF.FUND_COL_ACCT_NO,'') -- 收款账户编号 非主键字段不相等
         OR COALESCE(TM.FUND_COL_ACCT_NAME,'') <> COALESCE(BF.FUND_COL_ACCT_NAME,'') -- 收款账户名称 非主键字段不相等
         OR COALESCE(TM.RECV_BANK_NAME_1,'') <> COALESCE(BF.RECV_BANK_NAME_1,'') -- 收款行名称1 非主键字段不相等
         OR COALESCE(TM.PAYEE_CNAPS_CODE,'') <> COALESCE(BF.PAYEE_CNAPS_CODE,'') -- 收款方人行支付行号 非主键字段不相等
         OR COALESCE(TM.RECV_BANK_NAME_2,'') <> COALESCE(BF.RECV_BANK_NAME_2,'') -- 收款行名称2 非主键字段不相等
         OR COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NO,'') <> COALESCE(BF.PAYEE_ACCT_BELONG_ORG_NO,'') -- 收款方账户归属机构编号 非主键字段不相等
         OR COALESCE(TM.ZBA_NO,'') <> COALESCE(BF.ZBA_NO,'') -- 零余额账户编号 非主键字段不相等
         OR COALESCE(TM.ZBA_NAME,'') <> COALESCE(BF.ZBA_NAME,'') -- 零余额账户名称 非主键字段不相等
         OR COALESCE(TM.HOST_TXN_TM_STAMP,'') <> COALESCE(BF.HOST_TXN_TM_STAMP,'') -- 主机交易时间戳 非主键字段不相等
         OR COALESCE(TM.BUDGET_CORP_NO,'') <> COALESCE(BF.BUDGET_CORP_NO,'') -- 预算单位编号 非主键字段不相等
         OR COALESCE(TM.BUDGET_CORP_NAME,'') <> COALESCE(BF.BUDGET_CORP_NAME,'') -- 预算单位名称 非主键字段不相等
         OR COALESCE(TM.TXN_USAGE_DESC,'') <> COALESCE(BF.TXN_USAGE_DESC,'') -- 交易用途描述 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.MOBILE_NO,'') <> COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.SUMMARY_ILUS,'') <> COALESCE(BF.SUMMARY_ILUS,'') -- 摘要说明 非主键字段不相等
         OR COALESCE(TM.POSTSC_DESC,'') <> COALESCE(BF.POSTSC_DESC,'') -- 附言描述 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SRC_SYS_CD1,'') = COALESCE(BF.SRC_SYS_CD1,'') -- 来源系统代码1 非主键字段相等
         AND COALESCE(TM.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') = COALESCE(BF.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') -- 代理政府收款账户类型代码 非主键字段相等
         AND COALESCE(TM.FUND_COL_ACCT_CROSS_BANK_FLAG,'') = COALESCE(BF.FUND_COL_ACCT_CROSS_BANK_FLAG,'') -- 收款账户跨行标志 非主键字段相等
         AND COALESCE(TM.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') = COALESCE(BF.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') -- 代理政府代发业务类型代码 非主键字段相等
         AND COALESCE(TM.FISCAL_PAYOFF_FLAG,'') = COALESCE(BF.FISCAL_PAYOFF_FLAG,'') -- 财政代发标志 非主键字段相等
         AND COALESCE(TM.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') = COALESCE(BF.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') -- 政府代发清算途径类型代码 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段相等
         AND COALESCE(TM.PUB_AFFAIR_CARD_FLAG,'') = COALESCE(BF.PUB_AFFAIR_CARD_FLAG,'') -- 公务卡标志 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_NO,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_NO,'') -- 参保对象编号 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_TYPE_CD,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_TYPE_CD,'') -- 参保对象类型代码 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_NAME,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_NAME,'') -- 参保对象名称 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') -- 参保对象证件类型代码 非主键字段相等
         AND COALESCE(TM.PRTCPT_INSURE_OBJ_DOC_NO,'') = COALESCE(BF.PRTCPT_INSURE_OBJ_DOC_NO,'') -- 参保对象证件号码 非主键字段相等
         AND COALESCE(TM.CRDT_CARD_CARD_NO,'') = COALESCE(BF.CRDT_CARD_CARD_NO,'') -- 信用卡卡号 非主键字段相等
         AND COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段相等
         AND COALESCE(TM.PAY_MNY_CORP_NAME,'') = COALESCE(BF.PAY_MNY_CORP_NAME,'') -- 付款单位名称 非主键字段相等
         AND COALESCE(TM.PAY_CORP_NO,'') = COALESCE(BF.PAY_CORP_NO,'') -- 付款单位编号 非主键字段相等
         AND COALESCE(TM.PAY_FUND_ACCT_NO,'') = COALESCE(BF.PAY_FUND_ACCT_NO,'') -- 付款账户编号 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_NAME,'') = COALESCE(BF.PAY_ACCT_NAME,'') -- 付款账户名称 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') = COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') -- 付款账户开户机构名称 非主键字段相等
         AND COALESCE(TM.PAYER_CNAPS_CODE,'') = COALESCE(BF.PAYER_CNAPS_CODE,'') -- 付款方人行支付行号 非主键字段相等
         AND COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NO,'') -- 付款账户开户机构编号 非主键字段相等
         AND COALESCE(TM.FUND_COL_ACCT_NO,'') = COALESCE(BF.FUND_COL_ACCT_NO,'') -- 收款账户编号 非主键字段相等
         AND COALESCE(TM.FUND_COL_ACCT_NAME,'') = COALESCE(BF.FUND_COL_ACCT_NAME,'') -- 收款账户名称 非主键字段相等
         AND COALESCE(TM.RECV_BANK_NAME_1,'') = COALESCE(BF.RECV_BANK_NAME_1,'') -- 收款行名称1 非主键字段相等
         AND COALESCE(TM.PAYEE_CNAPS_CODE,'') = COALESCE(BF.PAYEE_CNAPS_CODE,'') -- 收款方人行支付行号 非主键字段相等
         AND COALESCE(TM.RECV_BANK_NAME_2,'') = COALESCE(BF.RECV_BANK_NAME_2,'') -- 收款行名称2 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NO,'') = COALESCE(BF.PAYEE_ACCT_BELONG_ORG_NO,'') -- 收款方账户归属机构编号 非主键字段相等
         AND COALESCE(TM.ZBA_NO,'') = COALESCE(BF.ZBA_NO,'') -- 零余额账户编号 非主键字段相等
         AND COALESCE(TM.ZBA_NAME,'') = COALESCE(BF.ZBA_NAME,'') -- 零余额账户名称 非主键字段相等
         AND COALESCE(TM.HOST_TXN_TM_STAMP,'') = COALESCE(BF.HOST_TXN_TM_STAMP,'') -- 主机交易时间戳 非主键字段相等
         AND COALESCE(TM.BUDGET_CORP_NO,'') = COALESCE(BF.BUDGET_CORP_NO,'') -- 预算单位编号 非主键字段相等
         AND COALESCE(TM.BUDGET_CORP_NAME,'') = COALESCE(BF.BUDGET_CORP_NAME,'') -- 预算单位名称 非主键字段相等
         AND COALESCE(TM.TXN_USAGE_DESC,'') = COALESCE(BF.TXN_USAGE_DESC,'') -- 交易用途描述 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.MOBILE_NO,'') = COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.SUMMARY_ILUS,'') = COALESCE(BF.SUMMARY_ILUS,'') -- 摘要说明 非主键字段相等
         AND COALESCE(TM.POSTSC_DESC,'') = COALESCE(BF.POSTSC_DESC,'') -- 附言描述 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.SRC_SYS_CD1,'') <> COALESCE(BF.SRC_SYS_CD1,'') -- 来源系统代码1 非主键字段不相等
         OR COALESCE(TM.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') <> COALESCE(BF.AGEN_GOV_FUND_COL_ACCT_TYPE_CD,'') -- 代理政府收款账户类型代码 非主键字段不相等
         OR COALESCE(TM.FUND_COL_ACCT_CROSS_BANK_FLAG,'') <> COALESCE(BF.FUND_COL_ACCT_CROSS_BANK_FLAG,'') -- 收款账户跨行标志 非主键字段不相等
         OR COALESCE(TM.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') <> COALESCE(BF.AGEN_GOV_PAYOFF_BIZ_TYPE_CD,'') -- 代理政府代发业务类型代码 非主键字段不相等
         OR COALESCE(TM.FISCAL_PAYOFF_FLAG,'') <> COALESCE(BF.FISCAL_PAYOFF_FLAG,'') -- 财政代发标志 非主键字段不相等
         OR COALESCE(TM.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') <> COALESCE(BF.GOV_PAYOFF_CLEAR_PATH_TYPE_CD,'') -- 政府代发清算途径类型代码 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NO,'') <> COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段不相等
         OR COALESCE(TM.PUB_AFFAIR_CARD_FLAG,'') <> COALESCE(BF.PUB_AFFAIR_CARD_FLAG,'') -- 公务卡标志 非主键字段不相等
         OR COALESCE(TM.TXN_CHNL_CD,'') <> COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_NO,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_NO,'') -- 参保对象编号 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_TYPE_CD,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_TYPE_CD,'') -- 参保对象类型代码 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_NAME,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_NAME,'') -- 参保对象名称 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_DOCTYP_CD,'') -- 参保对象证件类型代码 非主键字段不相等
         OR COALESCE(TM.PRTCPT_INSURE_OBJ_DOC_NO,'') <> COALESCE(BF.PRTCPT_INSURE_OBJ_DOC_NO,'') -- 参保对象证件号码 非主键字段不相等
         OR COALESCE(TM.CRDT_CARD_CARD_NO,'') <> COALESCE(BF.CRDT_CARD_CARD_NO,'') -- 信用卡卡号 非主键字段不相等
         OR COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段不相等
         OR COALESCE(TM.PAY_MNY_CORP_NAME,'') <> COALESCE(BF.PAY_MNY_CORP_NAME,'') -- 付款单位名称 非主键字段不相等
         OR COALESCE(TM.PAY_CORP_NO,'') <> COALESCE(BF.PAY_CORP_NO,'') -- 付款单位编号 非主键字段不相等
         OR COALESCE(TM.PAY_FUND_ACCT_NO,'') <> COALESCE(BF.PAY_FUND_ACCT_NO,'') -- 付款账户编号 非主键字段不相等
         OR COALESCE(TM.PAY_ACCT_NAME,'') <> COALESCE(BF.PAY_ACCT_NAME,'') -- 付款账户名称 非主键字段不相等
         OR COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') <> COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NAME,'') -- 付款账户开户机构名称 非主键字段不相等
         OR COALESCE(TM.PAYER_CNAPS_CODE,'') <> COALESCE(BF.PAYER_CNAPS_CODE,'') -- 付款方人行支付行号 非主键字段不相等
         OR COALESCE(TM.PAY_ACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.PAY_ACCT_OPEN_ACCT_ORG_NO,'') -- 付款账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.FUND_COL_ACCT_NO,'') <> COALESCE(BF.FUND_COL_ACCT_NO,'') -- 收款账户编号 非主键字段不相等
         OR COALESCE(TM.FUND_COL_ACCT_NAME,'') <> COALESCE(BF.FUND_COL_ACCT_NAME,'') -- 收款账户名称 非主键字段不相等
         OR COALESCE(TM.RECV_BANK_NAME_1,'') <> COALESCE(BF.RECV_BANK_NAME_1,'') -- 收款行名称1 非主键字段不相等
         OR COALESCE(TM.PAYEE_CNAPS_CODE,'') <> COALESCE(BF.PAYEE_CNAPS_CODE,'') -- 收款方人行支付行号 非主键字段不相等
         OR COALESCE(TM.RECV_BANK_NAME_2,'') <> COALESCE(BF.RECV_BANK_NAME_2,'') -- 收款行名称2 非主键字段不相等
         OR COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NO,'') <> COALESCE(BF.PAYEE_ACCT_BELONG_ORG_NO,'') -- 收款方账户归属机构编号 非主键字段不相等
         OR COALESCE(TM.ZBA_NO,'') <> COALESCE(BF.ZBA_NO,'') -- 零余额账户编号 非主键字段不相等
         OR COALESCE(TM.ZBA_NAME,'') <> COALESCE(BF.ZBA_NAME,'') -- 零余额账户名称 非主键字段不相等
         OR COALESCE(TM.HOST_TXN_TM_STAMP,'') <> COALESCE(BF.HOST_TXN_TM_STAMP,'') -- 主机交易时间戳 非主键字段不相等
         OR COALESCE(TM.BUDGET_CORP_NO,'') <> COALESCE(BF.BUDGET_CORP_NO,'') -- 预算单位编号 非主键字段不相等
         OR COALESCE(TM.BUDGET_CORP_NAME,'') <> COALESCE(BF.BUDGET_CORP_NAME,'') -- 预算单位名称 非主键字段不相等
         OR COALESCE(TM.TXN_USAGE_DESC,'') <> COALESCE(BF.TXN_USAGE_DESC,'') -- 交易用途描述 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.MOBILE_NO,'') <> COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.SUMMARY_ILUS,'') <> COALESCE(BF.SUMMARY_ILUS,'') -- 摘要说明 非主键字段不相等
         OR COALESCE(TM.POSTSC_DESC,'') <> COALESCE(BF.POSTSC_DESC,'') -- 附言描述 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.TXN_DT,'') = COALESCE(BF.TXN_DT,'') -- 交易日期 主键字段关联
    AND COALESCE(TM.PLAT_BATCH_NO,'') = COALESCE(BF.PLAT_BATCH_NO,'') -- 平台批次编号 主键字段关联
    AND COALESCE(TM.BAT_AGEN_PAY_SEQ_NO,'') = COALESCE(BF.BAT_AGEN_PAY_SEQ_NO,'') -- 批量代发顺序号 主键字段关联
    AND COALESCE(TM.TXN_SER_NO,'') = COALESCE(BF.TXN_SER_NO,'') -- 交易流水号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_FISCAL_AGEN_PAY_TXN_DTL_AGGREGT_TF_TM;
