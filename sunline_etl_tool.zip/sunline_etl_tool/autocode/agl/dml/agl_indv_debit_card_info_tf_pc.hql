-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人借记卡信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DEBIT_CARD_INFO_TF
--     表中文名：个人借记卡信息聚合
--     创建日期：2023-12-13 00:00:00
--     主键字段：DEBIT_CARD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-13 00:00:00 游崔龙 新增
--         2024-01-11 00:00:00 游崔龙 对标
--         2024-02-20 00:00:00 王穆军 修改映射信息
--         2024-04-19 00:00:00 王穆军 修改客户内码去除空值的逻辑
--         2024-07-23 00:00:00 王穆军 修改与设计文档一致
--         2024-08-05 00:00:00 王穆军 新增字段
--         2024-09-06 00:00:00 王穆军 新增5个字段
--         2024-09-12 00:00:00 王穆军 修改第二组 账号逻辑
--         2024-09-24 00:00:00 王穆军 1、账户性质代码 20240915：新增字段2、国密卡标志 20240915：新增字段3、最后存取款日期 20240915：新增字段
--         2024-10-28 00:00:00 王穆军 新增3个字段，修改一个字段的中英文名称，删除最后存取款日期



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM
USING ORC
COMMENT '个人借记卡信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     DEBIT_CARD_NO -- 借记卡编号
    ,ACCT_NO -- 账户编号
    ,MAIN_CURR_CD -- 主币种代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL -- 昨日余额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CUST_NO -- 客户号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,DEBIT_CARD_BIZ_TYPE_CD -- 借记卡业务类别代码
    ,DEBIT_CARD_PROD_CD -- 借记卡产品代码
    ,DEBIT_CARD_PROD_NAME -- 借记卡产品名称
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,TRGT_CUST_CARD_TYPE_CD -- 卡对象类别代码
    ,CARD_BRAND_TYPE_CD -- 卡品牌类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,MODIF_BEF_CARD_STATUS_CD -- 修改前卡片状态代码
    ,CARD_STATUS_CD -- 卡片状态代码
    ,GOOD_HVST_DEBIT_CARD_FLAG -- 丰收借记卡标志
    ,EMPLY_CARD_FLAG -- 员工卡标志
    ,FOLD_CARD_FLAG -- 有折卡标志
    ,FORGED_CARD_FLAG -- 伪冒卡标志
    ,NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,DEBIT_CARD_ANLFEE_TYPE_CD -- 借记卡年费类型代码
    ,SERV_CHARGE_RATE_PREFR_LVL_CD -- 费率优惠等级代码
    ,FREE_CARD_ANLFEE_EFFECT_DT -- 豁免卡年费生效日期
    ,FREE_CARD_ANLFEE_EXPIR_DT -- 豁免卡年费失效日期
    ,LAST_COL_ANLFEE_DT -- 上次收取年费日期
    ,CONSM_POINT_BAL -- 消费积分余额
    ,UN_CROSS_ANLFEE_TOTAL_AMT -- 未交年费总额
    ,ELEC_CASH_ALLOW_OPEN_FLAG -- 电子现金允许开通标志
    ,ELEC_CASH_OPEN_FLAG -- 电子现金开通标志
    ,SOCI_SECU_CARD_FLAG -- 社保卡标志
    ,SOCI_SECU_CARD_ONLINE_ACT_FLAG -- 社保卡在线激活标志
    ,SMS_SERV_PROVI_FLAG -- 短信服务提供标志
    ,TEL_BANK_SERV_PROVI_FLAG -- 电话银行服务提供标志
    ,ATM_SERV_PROVI_FLAG -- ATM服务提供标志
    ,POS_SERV_PROVI_FLAG -- POS服务提供标志
    ,SETUP_COMMS_FLAG -- 建立委托标志
    ,MICRO_FREE_SECRET_VISA_XMP_FLAG -- 小额免密免签标志
    ,ACPTD_ORG_NO -- 受理机构编号
    ,MAKE_CARD_TELR_NO -- 制卡柜员编号
    ,MAKE_CARD_DT -- 制卡日期
    ,ISSUE_DRAW_CARD_ORG_NO -- 发领卡机构编号
    ,OPEN_CARD_CHNL_CD -- 开卡渠道代码
    ,OPEN_CARD_TELR_NO -- 开卡柜员编号
    ,OPEN_CARD_DT -- 开卡日期
    ,ENABLED_TELR_NO -- 启用柜员编号
    ,ENABLED_DT -- 启用日期
    ,SAME_CARD_NO_CHG_CARD_APP_FLAG -- 同卡号换卡申请标志
    ,SAME_CARD_NO_CHG_CARD_FLAG -- 同卡号换卡标志
    ,CHG_CARD_DT -- 换卡日期
    ,PWD_ENABLED_FLAG -- 密码启用标志
    ,REPLOS_FLAG -- 挂失标志
    ,CARD_PWD_REPLOS_TYPE_CD -- 卡密码挂失类型代码
    ,CARD_REPLOS_TYPE_CD -- 卡片挂失类型代码
    ,CARD_MATU_YM -- 卡到期年月
    ,NOT_CARD_TYPE_CD -- 不动卡类型代码
    ,NOT_CARD_DT -- 置不动卡日期
    ,RECV_CARD_RSN_CD -- 销收卡原因代码
    ,CLOSE_CARD_CHNL_CD -- 销卡渠道代码
    ,RECV_CARD_ORG_NO -- 销收卡机构编号
    ,RECV_CARD_TELR_NO -- 销收卡柜员编号
    ,RECV_CARD_DT -- 销收卡日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,REC_STATUS_CD -- 记录状态代码
    ,MICRO_ACCT_BAL -- 小额账户余额
    ,COMPLT_ACCT_BAL -- 补登账户余额
    ,ECASH_ACCT_FLAG -- 电子现金账户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_01;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_01 (
     CDNOAC19 STRING COMMENT '卡号'
    ,CRDNCRDN STRING COMMENT '卡性质'
    ,PTCDPDTP STRING COMMENT '卡产品类¦e代码'
    ,PDCDPRON STRING COMMENT '产品代码'
    ,MECDMECD STRING COMMENT '联名/认同单位号'
    ,CRDMCRDM STRING COMMENT '卡介质'
    ,CT04FLNM STRING COMMENT '卡种类名称'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_01(
     CDNOAC19 -- 卡号
    ,CRDNCRDN -- 卡性质
    ,PTCDPDTP -- 卡产品类¦e代码
    ,PDCDPRON -- 产品代码
    ,MECDMECD -- 联名/认同单位号
    ,CRDMCRDM -- 卡介质
    ,CT04FLNM -- 卡种类名称
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CDNOAC19 AS CDNOAC19 -- 卡号
    ,P1.CRDNCRDN AS CRDNCRDN -- 卡性质
    ,P1.PTCDPDTP AS PTCDPDTP -- 卡产品类¦e代码
    ,P1.PDCDPRON AS PDCDPRON -- 产品代码
    ,P1.MECDMECD AS MECDMECD -- 联名/认同单位号
    ,P1.CRDMCRDM AS CRDMCRDM -- 卡介质
    ,P1.CT04FLNM AS CT04FLNM -- 卡种类名称
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
    SELECT
         P1.cdnoac19 --卡号
        ,P1.crdncrdn --卡性质
        ,P1.ptcdpdtp --卡产品类¦e代码
        ,P1.pdcdpron --产品代码
        ,P1.mecdmecd --联名/认同单位号
        ,p1.crdmcrdm --卡介质
        ,case when p1.crdncrdn is not null and p2.ct04flnm  is not null  then p2.ct04flnm 
        else coalesce(p2.ct04flnm, p3.ct04flnm ,'')
        end as CT04FLNM --卡种类名称
    FROM
        ODS_CORE.ODS_CORE_BWFMDCIM_TF P1
        left join ODS_CORE.ODS_CORE_BWFMCPCT_TF P2
            on P1.crdncrdn = P2.ct03crdt 
            and p1.ptcdpdtp  = p2.ct01pdtp 
            and p1.pdcdpron  = p2.ct02pron 
            and p1.crdmcrdm  = p2.ct08bool 
            and p2.pt_dt  = '${process_date}'
            AND p2.DEL_F = '0' 
        left join ODS_CORE.ODS_CORE_BWFMCPCT_TF P3
            on P1.mecdmecd  = P3.ct03crdt 
            and p1.ptcdpdtp  = p3.ct01pdtp 
            and p1.pdcdpron  = p3.ct02pron 
            and p1.crdmcrdm  = p3.ct08bool 
            and  p3.pt_dt  = '${process_date}'
            AND p3.DEL_F = '0' 
    WHERE
        p1.PT_DT = '${process_date}' AND p1.DEL_F = '0' 
)
 AS P1 -- 卡产品控制表

;
-- ==============聚合层字段映射（第2组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_011;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_011 (
     AB01AC15 STRING COMMENT '账号'
    ,AB14BAL DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,LAST_DAY_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_011(
     AB01AC15 -- 账号
    ,AB14BAL -- 昨日余额折人民币
    ,LAST_DAY_BAL -- 昨日余额
    ,DT_FLG -- 数据存在标志
)
SELECT
     U1.AB01AC15 AS AB01AC15 -- 账号
    ,sum(U1.AB14BAL) AS AB14BAL -- 昨日余额折人民币
    ,sum(u1.LAST_DAY_BAL) AS LAST_DAY_BAL -- 昨日余额
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
  
  select T1.AB01AC15 
   ,CASE WHEN T1.AB02CCYC = 'CNY'
       THEN coalesce(T1.AB14BAL,0)
       ELSE coalesce(T1.AB14BAL*(NVL(T2.YRCAEXRT,0)/NVL(T2.YRCACUNO,1)) ,0)
       end as AB14BAL
   ,T1.AB14BAL as LAST_DAY_BAL
      from 
    ( 
     SELECT 
         D2.AB02CCYC
         ,D2.AB14BAL
         ,D2.AB01AC15 
     FROM ODS_CORE.ODS_CORE_BDFMHQAB_TF D2
     WHERE D2.PT_DT = '${process_date}' 
     AND D2.DEL_F = '0' 
    ) T1
   left join 
    (
     SELECT 
          D5.YRCACCYC
         ,D5.YRCAEXRT
         ,D5.YRCACUNO
         ,D5.YRCADATE
     FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D5 
     WHERE  1=1
      and cast(D5.YRCADATE as string)= REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
         AND D5.YRCARS1B <> '9'
         AND D5.DEL_F = '0'
         and D5.PT_DT = '${process_date}' 

        ) T2
  on T1.AB02CCYC = T2.YRCACCYC

 ) AS U1 -- 活期存款余额主档

GROUP BY U1.AB01AC15
;
-- ==============聚合层字段映射（第2.1组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_012;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_012 (
     DEBIT_CARD_NO STRING COMMENT '借记卡编号'
    ,NR02ZHTP STRING COMMENT '账户性质'
    ,AA13ZHTP STRING COMMENT '账户性质'
    ,AB02CCYC STRING COMMENT '币种代码'
    ,ACCT_PROPTY_CD STRING COMMENT '账户性质代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_012(
     DEBIT_CARD_NO -- 借记卡编号
    ,NR02ZHTP -- 账户性质
    ,AA13ZHTP -- 账户性质
    ,AB02CCYC -- 币种代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CDNOAC19 AS DEBIT_CARD_NO -- 借记卡编号
    ,P3.NR02ZHTP AS NR02ZHTP -- 账户性质
    ,PP.AA13ZHTP AS AA13ZHTP -- 账户性质
    ,PP.AB02CCYC AS AB02CCYC -- 币种代码
    ,CASE WHEN SUBSTR(P1.BEIYNO20,7,1)='2' AND PP.AB02CCYC <>'CNY'
     THEN P3.NR02ZHTP
ELSE PP.AA13ZHTP
END AS ACCT_PROPTY_CD -- 账户性质代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P1 -- 借记卡主档

LEFT JOIN  (
    select
        P2.ab01ac15 ,
        P3.aa13zhtp ,
        P2.ab02ccyc
    from
        ods_core.ods_core_bdfmhqab_tf p2
    inner join ods_core.ods_core_bdfmhqaa_tf p3
    on
        p2.ab01ac15 = p3.aa01ac15
        and p3.del_f = '0'
        and p3.pt_dt = '${process_date}'
        and p3.rcstrs1b <> '9'
    where
        p2.del_f = '0'
        and p2.pt_dt = '${process_date}'
        and p2.rcstrs1b <> '9'
    group by
        P2.ab01ac15 ,
        P3.aa13zhtp ,
        P2.ab02ccyc 
    ) AS PP -- None
       ON PP.ab01ac15 = P1.DFANAC19
    and P1.PCCYCCYC = PP.ab02ccyc 
LEFT JOIN ODS_CORE.ODS_CORE_BDFMHQNR_TF AS P3 -- 活期存款账户主档补充文件
       ON TRIM(P3.NR01AC15) = TRIM(P1.DFANAC19)
AND P3.DEL_F='0' 
   and P3.PT_DT= '${process_date}' 
WHERE P1.PT_DT = '${process_date}' 
AND P1.DEL_F = '0' 
AND TRIM(P1.RCSTRS1B) = ''
;
-- ==============聚合层字段映射（第2.2组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_013;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_013 (
     CDNOAC19 STRING COMMENT '借记卡编号'
    ,NAT_SECRET_CARD_FLAG STRING COMMENT '国密卡标志'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_013(
     CDNOAC19 -- 借记卡编号
    ,NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CDNOAC19 AS CDNOAC19 -- 借记卡编号
    ,count(1) AS NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P1 -- 借记卡主档

INNER JOIN  ODS_ICS.ODS_ICS_TBL_CARD_GM_COUNT_TF AS P2 -- 国密IC借记卡统计表
       ON P2.DEL_F = '0' 
AND P2.PT_DT=  '${process_date}'
AND P2.PT_DT  = P1.PT_DT 
WHERE P1.PT_DT = '${process_date}' 
AND P1.DEL_F = '0' 
AND TRIM(P1.RCSTRS1B) = ''
AND  P1.CDNOAC19 BETWEEN P2.BEGIN_CARD_NO AND P2.END_CARD_NO 
GROUP BY P1.CDNOAC19
;
-- ==============聚合层字段映射（第3组）==============
-- 个人借记卡信息聚合

INSERT INTO TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM(
     DEBIT_CARD_NO -- 借记卡编号
    ,ACCT_NO -- 账户编号
    ,MAIN_CURR_CD -- 主币种代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL -- 昨日余额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CUST_NO -- 客户号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,DEBIT_CARD_BIZ_TYPE_CD -- 借记卡业务类别代码
    ,DEBIT_CARD_PROD_CD -- 借记卡产品代码
    ,DEBIT_CARD_PROD_NAME -- 借记卡产品名称
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,TRGT_CUST_CARD_TYPE_CD -- 卡对象类别代码
    ,CARD_BRAND_TYPE_CD -- 卡品牌类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,MODIF_BEF_CARD_STATUS_CD -- 修改前卡片状态代码
    ,CARD_STATUS_CD -- 卡片状态代码
    ,GOOD_HVST_DEBIT_CARD_FLAG -- 丰收借记卡标志
    ,EMPLY_CARD_FLAG -- 员工卡标志
    ,FOLD_CARD_FLAG -- 有折卡标志
    ,FORGED_CARD_FLAG -- 伪冒卡标志
    ,NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,DEBIT_CARD_ANLFEE_TYPE_CD -- 借记卡年费类型代码
    ,SERV_CHARGE_RATE_PREFR_LVL_CD -- 费率优惠等级代码
    ,FREE_CARD_ANLFEE_EFFECT_DT -- 豁免卡年费生效日期
    ,FREE_CARD_ANLFEE_EXPIR_DT -- 豁免卡年费失效日期
    ,LAST_COL_ANLFEE_DT -- 上次收取年费日期
    ,CONSM_POINT_BAL -- 消费积分余额
    ,UN_CROSS_ANLFEE_TOTAL_AMT -- 未交年费总额
    ,ELEC_CASH_ALLOW_OPEN_FLAG -- 电子现金允许开通标志
    ,ELEC_CASH_OPEN_FLAG -- 电子现金开通标志
    ,SOCI_SECU_CARD_FLAG -- 社保卡标志
    ,SOCI_SECU_CARD_ONLINE_ACT_FLAG -- 社保卡在线激活标志
    ,SMS_SERV_PROVI_FLAG -- 短信服务提供标志
    ,TEL_BANK_SERV_PROVI_FLAG -- 电话银行服务提供标志
    ,ATM_SERV_PROVI_FLAG -- ATM服务提供标志
    ,POS_SERV_PROVI_FLAG -- POS服务提供标志
    ,SETUP_COMMS_FLAG -- 建立委托标志
    ,MICRO_FREE_SECRET_VISA_XMP_FLAG -- 小额免密免签标志
    ,ACPTD_ORG_NO -- 受理机构编号
    ,MAKE_CARD_TELR_NO -- 制卡柜员编号
    ,MAKE_CARD_DT -- 制卡日期
    ,ISSUE_DRAW_CARD_ORG_NO -- 发领卡机构编号
    ,OPEN_CARD_CHNL_CD -- 开卡渠道代码
    ,OPEN_CARD_TELR_NO -- 开卡柜员编号
    ,OPEN_CARD_DT -- 开卡日期
    ,ENABLED_TELR_NO -- 启用柜员编号
    ,ENABLED_DT -- 启用日期
    ,SAME_CARD_NO_CHG_CARD_APP_FLAG -- 同卡号换卡申请标志
    ,SAME_CARD_NO_CHG_CARD_FLAG -- 同卡号换卡标志
    ,CHG_CARD_DT -- 换卡日期
    ,PWD_ENABLED_FLAG -- 密码启用标志
    ,REPLOS_FLAG -- 挂失标志
    ,CARD_PWD_REPLOS_TYPE_CD -- 卡密码挂失类型代码
    ,CARD_REPLOS_TYPE_CD -- 卡片挂失类型代码
    ,CARD_MATU_YM -- 卡到期年月
    ,NOT_CARD_TYPE_CD -- 不动卡类型代码
    ,NOT_CARD_DT -- 置不动卡日期
    ,RECV_CARD_RSN_CD -- 销收卡原因代码
    ,CLOSE_CARD_CHNL_CD -- 销卡渠道代码
    ,RECV_CARD_ORG_NO -- 销收卡机构编号
    ,RECV_CARD_TELR_NO -- 销收卡柜员编号
    ,RECV_CARD_DT -- 销收卡日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,REC_STATUS_CD -- 记录状态代码
    ,MICRO_ACCT_BAL -- 小额账户余额
    ,COMPLT_ACCT_BAL -- 补登账户余额
    ,ECASH_ACCT_FLAG -- 电子现金账户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CDNOAC19 AS DEBIT_CARD_NO -- 借记卡编号
    ,P1.DFANAC19 AS ACCT_NO -- 账户编号
    ,p1.PCCYCCYC AS MAIN_CURR_CD -- 主币种代码
    ,P7.ACCT_PROPTY_CD AS ACCT_PROPTY_CD -- 账户性质代码
    ,coalesce(P2.AB14BAL,0) AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P2.AB14BAL) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + coalesce(P2.AB14BAL,0) END  AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P2.AB14BAL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + coalesce(P2.AB14BAL,0) END  AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P2.AB14BAL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + coalesce(P2.AB14BAL,0) END  AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,COALESCE(P2.LAST_DAY_BAL,0) AS YESTD_BAL -- 昨日余额
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P2.LAST_DAY_BAL) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM,0) + coalesce(P2.LAST_DAY_BAL,0) END  AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P2.LAST_DAY_BAL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM,0) + coalesce(P2.LAST_DAY_BAL,0) END  AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P2.LAST_DAY_BAL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM,0) + coalesce(P2.LAST_DAY_BAL,0) END  AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,P1.CSNOCSID AS CUST_NO -- 客户号
    ,P1.CINOCSNO AS CUST_IN_CD -- 客户内码
    ,P1.CHNMNM40 AS CUST_NAME -- 客户名称
    ,P3.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P3.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P1.BSTPBUST AS DEBIT_CARD_BIZ_TYPE_CD -- 借记卡业务类别代码
    ,CONCAT(P1.PTCDPDTP,P1.PDCDPRON) AS DEBIT_CARD_PROD_CD -- 借记卡产品代码
    ,P4.CT04FLNM AS DEBIT_CARD_PROD_NAME -- 借记卡产品名称
    ,P1.CRDNCRDN AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,P1.CRDCCRDC AS TRGT_CUST_CARD_TYPE_CD -- 卡对象类别代码
    ,P1.CRDLCRDL AS CARD_BRAND_TYPE_CD -- 卡品牌类别代码
    ,P1.CRDMCRDM AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,P1.CDOSCRDS AS MODIF_BEF_CARD_STATUS_CD -- 修改前卡片状态代码
    ,P1.CRDSCRDS AS CARD_STATUS_CD -- 卡片状态代码
    ,CASE WHEN SUBSTR(P1.CDNOAC19,1,6)<>'940036' THEN '1' ELSE '0' END AS GOOD_HVST_DEBIT_CARD_FLAG -- 丰收借记卡标志
    ,P1.STAFBOOL AS EMPLY_CARD_FLAG -- 员工卡标志
    ,P1.YZKBBOOL AS FOLD_CARD_FLAG -- 有折卡标志
    ,SUBSTR(P1.CSWDCSWD,2,1) AS FORGED_CARD_FLAG -- 伪冒卡标志
    ,CASE WHEN P5.NAT_SECRET_CARD_FLAG IS NOT NULL THEN '1' ELSE '0' END AS NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,P1.CFLGCFLG AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,P1.PZZLBLTP AS VOCH_CATE_CD -- 凭证种类代码
    ,P1.MECDMECD AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,P1.ANFFANFF AS DEBIT_CARD_ANLFEE_TYPE_CD -- 借记卡年费类型代码
    ,P1.FRCSFRCS AS SERV_CHARGE_RATE_PREFR_LVL_CD -- 费率优惠等级代码
    ,unifiedTime(P1.WEFDDATE) AS FREE_CARD_ANLFEE_EFFECT_DT -- 豁免卡年费生效日期
    ,unifiedTime(P1.WEXDDATE) AS FREE_CARD_ANLFEE_EXPIR_DT -- 豁免卡年费失效日期
    ,unifiedTime(P1.LAFDDATE) AS LAST_COL_ANLFEE_DT -- 上次收取年费日期
    ,P1.BONSBONS AS CONSM_POINT_BAL -- 消费积分余额
    ,P1.WJNFAMT AS UN_CROSS_ANLFEE_TOTAL_AMT -- 未交年费总额
    ,CASE WHEN SUBSTR(P1.DLDKCTLW,13,1)='0' 
     THEN '1' 
     ELSE '0' 
END AS ELEC_CASH_ALLOW_OPEN_FLAG -- 电子现金允许开通标志
    ,CASE WHEN SUBSTR(P1.BEIYNO20,1,1)='1'
     THEN '1'
     ELSE '0' 
END  AS ELEC_CASH_OPEN_FLAG -- 电子现金开通标志
    ,CASE WHEN SUBSTR(P1.DLDKCTLW,12,1)='0' AND substr(P1.MECDMECD,1,2)='03' 
     THEN '1' 
     ELSE '0' 
END AS SOCI_SECU_CARD_FLAG -- 社保卡标志
    ,CASE WHEN P9.JH03FLAG IS NOT NULL THEN P9.JH03FLAG ELSE '0' END AS SOCI_SECU_CARD_ONLINE_ACT_FLAG -- 社保卡在线激活标志
    ,SUBSTR(P1.DLDKCTLW,1,1) AS SMS_SERV_PROVI_FLAG -- 短信服务提供标志
    ,SUBSTR(P1.DLDKCTLW,2,1) AS TEL_BANK_SERV_PROVI_FLAG -- 电话银行服务提供标志
    ,SUBSTR(P1.DLDKCTLW,5,1) AS ATM_SERV_PROVI_FLAG -- ATM服务提供标志
    ,SUBSTR(P1.DLDKCTLW,6,1) AS POS_SERV_PROVI_FLAG -- POS服务提供标志
    ,SUBSTR(P1.DLDKCTLW,7,1) AS SETUP_COMMS_FLAG -- 建立委托标志
    ,CASE WHEN SUBSTR(P1.DLDKCTLW,8,1)='0' OR SUBSTR(P1.DLDKCTLW,8,1)='' 
     THEN '1' 
     ELSE '0' 
END AS MICRO_FREE_SECRET_VISA_XMP_FLAG -- 小额免密免签标志
    ,P1.HOUNBRNO AS ACPTD_ORG_NO -- 受理机构编号
    ,P1.PRTRSTAF AS MAKE_CARD_TELR_NO -- 制卡柜员编号
    ,unifiedTime(P1.PRDTDATE) AS MAKE_CARD_DT -- 制卡日期
    ,P1.SOUNBRNO AS ISSUE_DRAW_CARD_ORG_NO -- 发领卡机构编号
    ,P1.OPCHCNCD AS OPEN_CARD_CHNL_CD -- 开卡渠道代码
    ,P1.OPTRSTAF AS OPEN_CARD_TELR_NO -- 开卡柜员编号
    ,unifiedTime(P1.OPDTDATE) AS OPEN_CARD_DT -- 开卡日期
    ,P1.ACTRSTAF AS ENABLED_TELR_NO -- 启用柜员编号
    ,unifiedTime(P1.ACTDDATE) AS ENABLED_DT -- 启用日期
    ,SUBSTR(P1.BEIYNO20,5,1) AS SAME_CARD_NO_CHG_CARD_APP_FLAG -- 同卡号换卡申请标志
    ,SUBSTR(P1.DLDKCTLW,11,1) AS SAME_CARD_NO_CHG_CARD_FLAG -- 同卡号换卡标志
    ,unifiedTime(P1.RPDTDATE) AS CHG_CARD_DT -- 换卡日期
    ,P1.PEFGPEFG AS PWD_ENABLED_FLAG -- 密码启用标志
    ,CASE WHEN SUBSTR(P1.CSWDCSWD,4,1)='2' OR SUBSTR(P1.CSWDCSWD,4,1)='3'
     THEN '1'  
     ELSE '0'
END AS REPLOS_FLAG -- 挂失标志
    ,SUBSTR(P1.CSWDCSWD,3,1) AS CARD_PWD_REPLOS_TYPE_CD -- 卡密码挂失类型代码
    ,SUBSTR(P1.CSWDCSWD,4,1) AS CARD_REPLOS_TYPE_CD -- 卡片挂失类型代码
    ,P1.EXYMYYMM AS CARD_MATU_YM -- 卡到期年月
    ,P1.IATPIATP AS NOT_CARD_TYPE_CD -- 不动卡类型代码
    ,unifiedTime(P1.SIADDATE) AS NOT_CARD_DT -- 置不动卡日期
    ,P1.CLSNCLSN AS RECV_CARD_RSN_CD -- 销收卡原因代码
    ,P1.CLCHCNCD AS CLOSE_CARD_CHNL_CD -- 销卡渠道代码
    ,P1.COUNBRNO AS RECV_CARD_ORG_NO -- 销收卡机构编号
    ,P1.CLTRSTAF AS RECV_CARD_TELR_NO -- 销收卡柜员编号
    ,unifiedTime(P1.CLDTDATE) AS RECV_CARD_DT -- 销收卡日期
    ,P1.BUOPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.BUDIDATE) AS SETUP_DT -- 建立日期
    ,P1.BUTSSTAM AS SETUP_TM_STAMP -- 建立时间戳
    ,unifiedTime(P1.CLTDDATE) AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,unifiedTime(P1.UPDTDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPTSSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,UPOPSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.OWONBRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P1.OPONBRNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.HSJGBRNO AS LP_ORG_NO -- 法人机构编号
    ,'CORE' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,P1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,P6.SH12BAL AS MICRO_ACCT_BAL -- 小额账户余额
    ,P6.SH13BAL AS COMPLT_ACCT_BAL -- 补登账户余额
    ,CASE WHEN P6.SH01AC19 IS NULL THEN '0' ELSE '1' END AS ECASH_ACCT_FLAG -- 电子现金账户标志
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BWFMDCIM_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P1 -- 借记卡主档

LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_011 AS P2 -- 活期存款余额主档
       ON P1.DFANAC19 = P2.AB01AC15  
LEFT JOIN (
select 
  T.CST_IN_CD           
 ,T.CRTF_TYP
 ,T.CRTF_NO 
from
(
      SELECT T1.CST_IN_CD
            ,T1.CRTF_TYP
            ,T1.CRTF_NO
            ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
      FROM  ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF T1
      where 1=1
      --and T1.MAJOR_FLG='1'
      AND   T1.PT_DT = '${process_date}' AND DEL_F = '0' 
   )T
   where t.rn =1 
) AS P3 -- 客户证件信息
       ON P1.CINOCSNO = P3.CST_IN_CD  
LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_01 AS P4 -- 卡产品控制表
       ON P1.CDNOAC19 = P4.CDNOAC19 
LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_013 AS P5 -- 国密IC借记卡统计表
       ON P1.CDNOAC19 = P5.CDNOAC19 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMECSH_TF AS P6 -- 电子现金账户表
       ON TRIM(P1.CDNOAC19) = TRIM(P6.SH01AC19)
AND P6.PT_DT= '${process_date}'
AND P6.DEL_F = '0' 
LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_012 AS P7 -- 账户性质代码
       ON P1.CDNOAC19 = P7.DEBIT_CARD_NO 
LEFT JOIN (
select
 JH01AC19,JH03FLAG
from
 ODS_CORE.ODS_CORE_BWFMONJH_TF
where
 TRIM(JH03FLAG)= '1'
 and DEL_F = '0'
 and PT_DT = '${process_date}'
) AS P9 -- 社保卡激活
       ON TRIM(P1.CDNOAC19) = TRIM(P9.JH01AC19) 
LEFT JOIN (
SELECT 
     P1.DEBIT_CARD_NO
    ,P1.YESTD_BAL
    ,P1.YESTD_BAL_MONTH_ACCUM
    ,P1.YESTD_BAL_QUAR_ACCUM
    ,P1.YESTD_BAL_YEAR_ACCUM
    ,P1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
    ,P1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
    ,P1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB

FROM 
AGL.AGL_INDV_DEBIT_CARD_INFO_TF P1
WHERE  P1.PT_DT = cast(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND P1.SRC_SYS_CD ='CORE'
) AS S1 -- 个人借记卡上日积数
       ON  S1.DEBIT_CARD_NO = P1.CDNOAC19 
WHERE P1.PT_DT = '${process_date}' 
AND P1.DEL_F = '0' 
AND TRIM(P1.RCSTRS1B) = ''
;
-- ==============聚合层字段映射（第4组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_02;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_02 (
     CARDNO STRING COMMENT '凭证号码'
    ,LASTBL DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,LAST_DAY_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_02(
     CARDNO -- 凭证号码
    ,LASTBL -- 昨日余额折人民币
    ,LAST_DAY_BAL -- 昨日余额
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CARDNO AS CARDNO -- 凭证号码
    ,SUM(P1.LASTBL) AS LASTBL -- 昨日余额折人民币
    ,SUM(P1.LAST_DAY_BAL) AS LAST_DAY_BAL -- 昨日余额
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
select T1.cardno,p1.crcycd,CASE WHEN p1.CRCYCD = 'CNY'
     THEN coalesce(p1.LASTBL,0)
     ELSE coalesce(p1.LASTBL*(NVL(p2.YRCAEXRT,0)/NVL(p2.YRCACUNO,1)) ,0)    
END as lastbl,
p1.LASTBL as LAST_DAY_BAL

from 
ODS_NAS.ODS_NAS_KCD_CARD_TF T1      --卡信息表  
left join 

 (
    SELECT T2.CARDNO 
          ,T3.CRCYCD
          ,T3.CSEXTG
          ,T3.CUSTNO
          ,T2.CUSTAC 
          ,T3.ACCTNO 
          ,T3.ONLNBL 
          ,t3.lastbl 
    FROM     ODS_NAS.ODS_NAS_KNA_ACDC_TF T2  --卡客户账号对照表
    inner JOIN ODS_NAS.ODS_NAS_KNA_ACCT_TF T3   --负债活期账户信息表
        ON         T2.CUSTAC = T3.CUSTAC  
        AND        T3.ACCTST <> '2'
        AND        T3.PT_DT = '${process_date}' 
        AND T3.DEL_F = '0' 
    WHERE      T2.PT_DT = '${process_date}' 
    AND T2.DEL_F = '0' 

    UNION 

    SELECT T2.CARDNO 
          ,T3.CRCYCD
          ,T3.CSEXTG
          ,T3.CUSTNO
          ,T2.CUSTAC 
          ,T3.ACCTNO 
          ,T3.ONLNBL 
          ,t3.lastbl 
    FROM   ODS_NAS.ODS_NAS_KNA_ACDC_TF T2  --卡客户账号对照表
       
    INNER JOIN ODS_NAS.ODS_NAS_KNA_FXAC_TF T3  --负债定期账户信息表
        ON         T2.CUSTAC = T3.CUSTAC
        AND        T3.ACCTST <> '2'
        AND        T3.PT_DT = '${process_date}' 
        AND T3.DEL_F = '0' 
    INNER JOIN ODS_NAS.ODS_NAS_KNA_SVAC_TF T4  --储蓄账户信息表
        ON         T2.CUSTAC = T4.CUSTAC
        AND        T3.ACCTNO = T4.ACCTNO
        AND        T4.ACCTST = '0'
        AND        T4.PT_DT = '${process_date}' 
        AND T4.DEL_F = '0'  
    WHERE      T2.PT_DT = '${process_date}' 
    AND T2.DEL_F = '0' 
) P1

 ON         T1.CARDNO = P1.CARDNO 
left join 
(
 SELECT 
      D5.YRCACCYC
     ,D5.YRCAEXRT
     ,D5.YRCACUNO
     ,D5.YRCADATE
     --,REPLACE('${process_date}','-','')
     --,row_number()over(partition by D5.YRCACCYC order by D5.YRCADATE desc )RN
 FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D5 
 WHERE  1=1
  and cast(D5.YRCADATE as string)= REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
     AND D5.YRCARS1B <> '9'
     AND D5.DEL_F = '0'
     and D5.PT_DT = '${process_date}' 
     AND D5.DEL_F = '0' 
    ) p2
    on p1.crcycd = p2.YRCACCYC
 
 
where       T1.PT_DT = '${process_date}' 
AND T1.DEL_F = '0' 
)


 AS P1 -- 卡号对应名下的上日余额汇总

GROUP BY P1.CARDNO
;
-- ==============聚合层字段映射（第5组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_03;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_03 (
     CARDNO STRING COMMENT '凭证号码'
    ,CST_IN_CD STRING COMMENT '客户内码'
    ,CRTF_TYP STRING COMMENT '客户证件类型代码'
    ,CRTF_NO STRING COMMENT '客户证件号码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_03(
     CARDNO -- 凭证号码
    ,CST_IN_CD -- 客户内码
    ,CRTF_TYP -- 客户证件类型代码
    ,CRTF_NO -- 客户证件号码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CARDNO AS CARDNO -- 凭证号码
    ,P1.CST_IN_CD AS CST_IN_CD -- 客户内码
    ,P2.CRTF_TYP AS CRTF_TYP -- 客户证件类型代码
    ,P2.CRTF_NO AS CRTF_NO -- 客户证件号码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT
  P.CARDNO
 ,P.CST_IN_CD
FROM
 (
 SELECT
  T1.CARDNO,CASE WHEN T4.CST_IN_CD IS NULL OR T4.CST_IN_CD='' THEN  T5.CST_IN_CD ELSE T4.CST_IN_CD END AS CST_IN_CD
 FROM
  ODS_NAS.ODS_NAS_KNA_ACDC_TF T1
 LEFT JOIN ODS_NAS.ODS_NAS_KNA_CUST_TF T2
        ON T1.CUSTAC = T2.CUSTAC AND T2.PT_DT = '${process_date}'  AND T2.DEL_F = '0' 
 LEFT JOIN (SELECT * FROM(SELECT   CUSTNO,CUSTID,CUSTCD,ROW_NUMBER() OVER(PARTITION BY CUSTNO ORDER BY STATUS ) AS RN
            FROM ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF AS P2 -- 客户信息关联表
            WHERE    P2.PT_DT = '${process_date}'  AND P2.DEL_F = '0'
   ) WHERE RN=1) T3
  ON  T2.CUSTNO = T3.CUSTNO 
 LEFT JOIN ( SELECT D4.USER_ID,D4.CST_IN_CD FROM ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF  D4
             WHERE  D4.DEL_F='0' AND  COALESCE(TRIM(D4.CST_IN_CD),'')<>'' AND  D4.PT_DT='${process_date}') T4
        ON  T3.CUSTID = T4.USER_ID 
 LEFT JOIN (SELECT * FROM(SELECT CRTF_NO,CST_IN_CD,ROW_NUMBER() OVER(PARTITION BY CRTF_NO ORDER BY CST_IN_CD ) AS RN
           FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF WHERE DEL_F='0' AND PT_DT='${process_date}'  GROUP BY CRTF_NO,CST_IN_CD) WHERE RN=1)T5 
        ON  T2.IDTFNO = T5.CRTF_NO
 WHERE T1.PT_DT = '${process_date}'  AND T1.DEL_F = '0' 
 GROUP BY T1.CARDNO,CASE WHEN T4.CST_IN_CD IS NULL OR T4.CST_IN_CD='' THEN  T5.CST_IN_CD ELSE T4.CST_IN_CD END 
)P WHERE COALESCE(TRIM(P.CST_IN_CD),'')<>''
) AS P1 -- 获取客户内码信息

LEFT JOIN (
 SELECT  D2.CST_IN_CD
        ,D2.CRTF_TYP
        ,D2.CRTF_NO
 FROM (
       SELECT T1.CST_IN_CD
             ,T1.CRTF_TYP
             ,T1.CRTF_NO
             ,ROW_NUMBER() OVER(PARTITION BY T1.CST_IN_CD ORDER BY T1.GMT_MODIFIED DESC ) RN 
       FROM  ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF T1  --证件信息表
       WHERE  T1.MAJOR_FLG='1'
       AND    T1.PT_DT = '${process_date}' 
       AND T1.DEL_F = '0' 
      ) D2
 WHERE  D2.RN= 1
) AS P2 -- 获取客户的证件信息
       ON P1.CST_IN_CD = P2.CST_IN_CD 
;
-- ==============聚合层字段映射（第6组）==============
-- 个人借记卡信息聚合
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_04;

CREATE TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_04 (
     CARDNO STRING COMMENT '凭证号码'
    ,CURR_CD STRING COMMENT '币种代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '个人借记卡信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_04(
     CARDNO -- 凭证号码
    ,CURR_CD -- 币种代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CARDNO AS CARDNO -- 凭证号码
    ,P1.CURR_CD AS CURR_CD -- 币种代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
    SELECT T2.CARDNO 
          ,T3.CRCYCD as CURR_CD
    FROM     ODS_NAS.ODS_NAS_KNA_ACDC_TF T2  --卡客户账号对照表
    inner JOIN ODS_NAS.ODS_NAS_KNA_ACCT_TF T3   --负债活期账户信息表
        ON         T2.CUSTAC = T3.CUSTAC  
        AND        T3.ACCTST <> '2'
        AND        T3.PT_DT = '${process_date}' 
        AND T3.DEL_F = '0' 
    WHERE      T2.PT_DT = '${process_date}' 
    AND T2.DEL_F = '0' 

    UNION 

    SELECT T2.CARDNO 
          ,T3.CRCYCD as CURR_CD
    FROM   ODS_NAS.ODS_NAS_KNA_ACDC_TF T2  --卡客户账号对照表 
    INNER JOIN ODS_NAS.ODS_NAS_KNA_FXAC_TF T3  --负债定期账户信息表
        ON         T2.CUSTAC = T3.CUSTAC
        AND        T3.ACCTST <> '2'
        AND        T3.PT_DT = '${process_date}' 
        AND T3.DEL_F = '0' 
    WHERE      T2.PT_DT = '${process_date}' 
    AND T2.DEL_F = '0' 
) AS P1 -- 获取客户内码信息

;
-- ==============聚合层字段映射（第7组）==============
-- 个人借记卡信息聚合

INSERT INTO TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM(
     DEBIT_CARD_NO -- 借记卡编号
    ,ACCT_NO -- 账户编号
    ,MAIN_CURR_CD -- 主币种代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL -- 昨日余额
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CUST_NO -- 客户号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,CUST_DOC_NO -- 客户证件号码
    ,DEBIT_CARD_BIZ_TYPE_CD -- 借记卡业务类别代码
    ,DEBIT_CARD_PROD_CD -- 借记卡产品代码
    ,DEBIT_CARD_PROD_NAME -- 借记卡产品名称
    ,CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,TRGT_CUST_CARD_TYPE_CD -- 卡对象类别代码
    ,CARD_BRAND_TYPE_CD -- 卡品牌类别代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,MODIF_BEF_CARD_STATUS_CD -- 修改前卡片状态代码
    ,CARD_STATUS_CD -- 卡片状态代码
    ,GOOD_HVST_DEBIT_CARD_FLAG -- 丰收借记卡标志
    ,EMPLY_CARD_FLAG -- 员工卡标志
    ,FOLD_CARD_FLAG -- 有折卡标志
    ,FORGED_CARD_FLAG -- 伪冒卡标志
    ,NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,DEBIT_CARD_ANLFEE_TYPE_CD -- 借记卡年费类型代码
    ,SERV_CHARGE_RATE_PREFR_LVL_CD -- 费率优惠等级代码
    ,FREE_CARD_ANLFEE_EFFECT_DT -- 豁免卡年费生效日期
    ,FREE_CARD_ANLFEE_EXPIR_DT -- 豁免卡年费失效日期
    ,LAST_COL_ANLFEE_DT -- 上次收取年费日期
    ,CONSM_POINT_BAL -- 消费积分余额
    ,UN_CROSS_ANLFEE_TOTAL_AMT -- 未交年费总额
    ,ELEC_CASH_ALLOW_OPEN_FLAG -- 电子现金允许开通标志
    ,ELEC_CASH_OPEN_FLAG -- 电子现金开通标志
    ,SOCI_SECU_CARD_FLAG -- 社保卡标志
    ,SOCI_SECU_CARD_ONLINE_ACT_FLAG -- 社保卡在线激活标志
    ,SMS_SERV_PROVI_FLAG -- 短信服务提供标志
    ,TEL_BANK_SERV_PROVI_FLAG -- 电话银行服务提供标志
    ,ATM_SERV_PROVI_FLAG -- ATM服务提供标志
    ,POS_SERV_PROVI_FLAG -- POS服务提供标志
    ,SETUP_COMMS_FLAG -- 建立委托标志
    ,MICRO_FREE_SECRET_VISA_XMP_FLAG -- 小额免密免签标志
    ,ACPTD_ORG_NO -- 受理机构编号
    ,MAKE_CARD_TELR_NO -- 制卡柜员编号
    ,MAKE_CARD_DT -- 制卡日期
    ,ISSUE_DRAW_CARD_ORG_NO -- 发领卡机构编号
    ,OPEN_CARD_CHNL_CD -- 开卡渠道代码
    ,OPEN_CARD_TELR_NO -- 开卡柜员编号
    ,OPEN_CARD_DT -- 开卡日期
    ,ENABLED_TELR_NO -- 启用柜员编号
    ,ENABLED_DT -- 启用日期
    ,SAME_CARD_NO_CHG_CARD_APP_FLAG -- 同卡号换卡申请标志
    ,SAME_CARD_NO_CHG_CARD_FLAG -- 同卡号换卡标志
    ,CHG_CARD_DT -- 换卡日期
    ,PWD_ENABLED_FLAG -- 密码启用标志
    ,REPLOS_FLAG -- 挂失标志
    ,CARD_PWD_REPLOS_TYPE_CD -- 卡密码挂失类型代码
    ,CARD_REPLOS_TYPE_CD -- 卡片挂失类型代码
    ,CARD_MATU_YM -- 卡到期年月
    ,NOT_CARD_TYPE_CD -- 不动卡类型代码
    ,NOT_CARD_DT -- 置不动卡日期
    ,RECV_CARD_RSN_CD -- 销收卡原因代码
    ,CLOSE_CARD_CHNL_CD -- 销卡渠道代码
    ,RECV_CARD_ORG_NO -- 销收卡机构编号
    ,RECV_CARD_TELR_NO -- 销收卡柜员编号
    ,RECV_CARD_DT -- 销收卡日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,REC_STATUS_CD -- 记录状态代码
    ,MICRO_ACCT_BAL -- 小额账户余额
    ,COMPLT_ACCT_BAL -- 补登账户余额
    ,ECASH_ACCT_FLAG -- 电子现金账户标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CARDNO AS DEBIT_CARD_NO -- 借记卡编号
    ,'' AS ACCT_NO -- 账户编号
    ,P4.CURR_CD AS MAIN_CURR_CD -- 主币种代码
    ,'' AS ACCT_PROPTY_CD -- 账户性质代码
    ,coalesce(P2.LASTBL,0) AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P2.LASTBL) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + coalesce(P2.LASTBL,0) END  AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P2.LASTBL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + coalesce(P2.LASTBL,0) END  AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P2.LASTBL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + coalesce(P2.LASTBL,0) END  AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,COALESCE(P2.LAST_DAY_BAL,0) AS YESTD_BAL -- 昨日余额
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P2.LAST_DAY_BAL) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM,0) + coalesce(P2.LAST_DAY_BAL,0) END  AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P2.LAST_DAY_BAL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM,0) + coalesce(P2.LAST_DAY_BAL,0) END  AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P2.LAST_DAY_BAL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM,0) + coalesce(P2.LAST_DAY_BAL,0) END  AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,P5.CUSTNO AS CUST_NO -- 客户号
    ,P3.CST_IN_CD AS CUST_IN_CD -- 客户内码
    ,'' AS CUST_NAME -- 客户名称
    ,P3.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P3.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,'' AS DEBIT_CARD_BIZ_TYPE_CD -- 借记卡业务类别代码
    ,P1.PRODCD AS DEBIT_CARD_PROD_CD -- 借记卡产品代码
    ,'' AS DEBIT_CARD_PROD_NAME -- 借记卡产品名称
    ,'W1' AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,'1' AS TRGT_CUST_CARD_TYPE_CD -- 卡对象类别代码
    ,'' AS CARD_BRAND_TYPE_CD -- 卡品牌类别代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS MODIF_BEF_CARD_STATUS_CD -- 修改前卡片状态代码
    ,CASE WHEN P1.DCMTST='0' THEN '9' WHEN P1.DCMTST='1' THEN '1' WHEN P1.DCMTST='2' THEN 'W2' ELSE '99' END AS CARD_STATUS_CD -- 卡片状态代码
    ,'' AS GOOD_HVST_DEBIT_CARD_FLAG -- 丰收借记卡标志
    ,'' AS EMPLY_CARD_FLAG -- 员工卡标志
    ,'' AS FOLD_CARD_FLAG -- 有折卡标志
    ,'' AS FORGED_CARD_FLAG -- 伪冒卡标志
    ,'' AS NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,'' AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,'' AS VOCH_CATE_CD -- 凭证种类代码
    ,'' AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,'' AS DEBIT_CARD_ANLFEE_TYPE_CD -- 借记卡年费类型代码
    ,'' AS SERV_CHARGE_RATE_PREFR_LVL_CD -- 费率优惠等级代码
    ,'' AS FREE_CARD_ANLFEE_EFFECT_DT -- 豁免卡年费生效日期
    ,'' AS FREE_CARD_ANLFEE_EXPIR_DT -- 豁免卡年费失效日期
    ,'' AS LAST_COL_ANLFEE_DT -- 上次收取年费日期
    ,NULL AS CONSM_POINT_BAL -- 消费积分余额
    ,NULL AS UN_CROSS_ANLFEE_TOTAL_AMT -- 未交年费总额
    ,'' AS ELEC_CASH_ALLOW_OPEN_FLAG -- 电子现金允许开通标志
    ,'' AS ELEC_CASH_OPEN_FLAG -- 电子现金开通标志
    ,'' AS SOCI_SECU_CARD_FLAG -- 社保卡标志
    ,'' AS SOCI_SECU_CARD_ONLINE_ACT_FLAG -- 社保卡在线激活标志
    ,'' AS SMS_SERV_PROVI_FLAG -- 短信服务提供标志
    ,'' AS TEL_BANK_SERV_PROVI_FLAG -- 电话银行服务提供标志
    ,'' AS ATM_SERV_PROVI_FLAG -- ATM服务提供标志
    ,'' AS POS_SERV_PROVI_FLAG -- POS服务提供标志
    ,'' AS SETUP_COMMS_FLAG -- 建立委托标志
    ,'' AS MICRO_FREE_SECRET_VISA_XMP_FLAG -- 小额免密免签标志
    ,'' AS ACPTD_ORG_NO -- 受理机构编号
    ,'' AS MAKE_CARD_TELR_NO -- 制卡柜员编号
    ,'' AS MAKE_CARD_DT -- 制卡日期
    ,'' AS ISSUE_DRAW_CARD_ORG_NO -- 发领卡机构编号
    ,'' AS OPEN_CARD_CHNL_CD -- 开卡渠道代码
    ,'' AS OPEN_CARD_TELR_NO -- 开卡柜员编号
    ,unifiedTime(P1.OPENDT) AS OPEN_CARD_DT -- 开卡日期
    ,'' AS ENABLED_TELR_NO -- 启用柜员编号
    ,'' AS ENABLED_DT -- 启用日期
    ,'' AS SAME_CARD_NO_CHG_CARD_APP_FLAG -- 同卡号换卡申请标志
    ,'' AS SAME_CARD_NO_CHG_CARD_FLAG -- 同卡号换卡标志
    ,'' AS CHG_CARD_DT -- 换卡日期
    ,'' AS PWD_ENABLED_FLAG -- 密码启用标志
    ,CASE WHEN P1.DCMTST='3' OR P1.DCMTST='4' THEN '1' ELSE '0' END AS REPLOS_FLAG -- 挂失标志
    ,'' AS CARD_PWD_REPLOS_TYPE_CD -- 卡密码挂失类型代码
    ,'' AS CARD_REPLOS_TYPE_CD -- 卡片挂失类型代码
    ,SUBSTR(P1.MATUDT,1,6) AS CARD_MATU_YM -- 卡到期年月
    ,'' AS NOT_CARD_TYPE_CD -- 不动卡类型代码
    ,'' AS NOT_CARD_DT -- 置不动卡日期
    ,'' AS RECV_CARD_RSN_CD -- 销收卡原因代码
    ,'' AS CLOSE_CARD_CHNL_CD -- 销卡渠道代码
    ,'' AS RECV_CARD_ORG_NO -- 销收卡机构编号
    ,'' AS RECV_CARD_TELR_NO -- 销收卡柜员编号
    ,unifiedTime(P1.CLOSDT) AS RECV_CARD_DT -- 销收卡日期
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'' AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,SUBSTR(P1.TIMETM,1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.CORPNO AS BELONG_ORG_NO -- 归属机构编号
    ,'' AS STAT_ORG_NO -- 统计机构编号
    ,'' AS LP_ORG_NO -- 法人机构编号
    ,'NAS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'' AS REC_STATUS_CD -- 记录状态代码
    ,NULL AS MICRO_ACCT_BAL -- 小额账户余额
    ,NULL AS COMPLT_ACCT_BAL -- 补登账户余额
    ,'' AS ECASH_ACCT_FLAG -- 电子现金账户标志
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KCD_CARD_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
 SELECT 
     D1.CARDNO
     ,D1.PRODCD
     ,D1.DCMTST
     ,D1.OPENDT
     ,D1.MATUDT
     ,D1.CLOSDT
     ,D1.TIMETM
     ,D1.CORPNO
    ,D1.PT_DT
 FROM  ODS_NAS.ODS_NAS_KCD_CARD_TF D1    --卡信息表 
  WHERE      D1.PT_DT = '${process_date}' 
  AND D1.DEL_F = '0' 
 )
 AS P1 -- 电子借记卡信息

LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_02 AS P2 -- 客户卡对应的所有现金余额
       ON P1.CARDNO = P2.CARDNO 
LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_03 AS P3 -- 用户信息表
       ON P1.CARDNO = P3.CARDNO 
LEFT JOIN AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_04 AS P4 -- 客户卡对应的币种代码
       ON P1.CARDNO = P4.CARDNO 
LEFT JOIN (
    SELECT T2.CARDNO 
          ,T3.CUSTNO
    FROM     ODS_NAS.ODS_NAS_KNA_ACDC_TF T2  --卡客户账号对照表 
    inner JOIN ODS_NAS.ODS_NAS_KNA_ACCT_TF T3   --负债活期账户信息表
        ON         T2.CUSTAC = T3.CUSTAC  
        AND        T3.ACCTST <> '2'
        AND        T3.PT_DT = '${process_date}' 
        AND T3.DEL_F = '0' 
    WHERE      T2.PT_DT = '${process_date}' 
    AND T2.DEL_F = '0' 

    UNION 

    SELECT T2.CARDNO 
          ,T3.CUSTNO
    FROM   ODS_NAS.ODS_NAS_KNA_ACDC_TF T2  --卡客户账号对照表
    INNER JOIN ODS_NAS.ODS_NAS_KNA_FXAC_TF T3  --负债定期账户信息表
        ON         T2.CUSTAC = T3.CUSTAC
        AND        T3.ACCTST <> '2'
        AND        T3.PT_DT = '${process_date}' 
        AND T3.DEL_F = '0' 
    INNER JOIN ODS_NAS.ODS_NAS_KNA_SVAC_TF T4  --储蓄账户信息表
        ON         T2.CUSTAC = T4.CUSTAC
        AND        T3.ACCTNO = T4.ACCTNO
        AND        T4.ACCTST = '0'
        AND        T4.PT_DT = '${process_date}' 
        AND T4.DEL_F = '0'  
    WHERE      T2.PT_DT = '${process_date}' 
    AND T2.DEL_F = '0' 
)
 AS P5 -- 负债活期账户信息表
       ON P1.CARDNO = P5.CARDNO  
LEFT JOIN (
SELECT 
     P1.DEBIT_CARD_NO
    ,P1.YESTD_BAL
    ,P1.YESTD_BAL_MONTH_ACCUM
    ,P1.YESTD_BAL_QUAR_ACCUM
    ,P1.YESTD_BAL_YEAR_ACCUM
    ,P1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
    ,P1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
    ,P1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB

FROM 
AGL.AGL_INDV_DEBIT_CARD_INFO_TF P1
WHERE  P1.PT_DT = cast(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND P1.SRC_SYS_CD ='NAS'
) AS S1 -- 个人借记卡上日积数
       ON  S1.DEBIT_CARD_NO = P1.CARDNO 
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_DEBIT_CARD_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEBIT_CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.DEBIT_CARD_NO, BF.DEBIT_CARD_NO) END AS DEBIT_CARD_NO -- 借记卡编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAIN_CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.MAIN_CURR_CD, BF.MAIN_CURR_CD) END AS MAIN_CURR_CD -- 主币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_PROPTY_CD, BF.ACCT_PROPTY_CD) END AS ACCT_PROPTY_CD -- 账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_CONVT_RMB, BF.YESTD_BAL_CONVT_RMB) END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB, BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL, BF.YESTD_BAL) END AS YESTD_BAL -- 昨日余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM, BF.YESTD_BAL_MONTH_ACCUM) END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM, BF.YESTD_BAL_QUAR_ACCUM) END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM, BF.YESTD_BAL_YEAR_ACCUM) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_NO, BF.CUST_NO) END AS CUST_NO -- 客户号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_DOCTYP_CD, BF.CUST_DOCTYP_CD) END AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_DOC_NO, BF.CUST_DOC_NO) END AS CUST_DOC_NO -- 客户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEBIT_CARD_BIZ_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.DEBIT_CARD_BIZ_TYPE_CD, BF.DEBIT_CARD_BIZ_TYPE_CD) END AS DEBIT_CARD_BIZ_TYPE_CD -- 借记卡业务类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEBIT_CARD_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.DEBIT_CARD_PROD_CD, BF.DEBIT_CARD_PROD_CD) END AS DEBIT_CARD_PROD_CD -- 借记卡产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEBIT_CARD_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.DEBIT_CARD_PROD_NAME, BF.DEBIT_CARD_PROD_NAME) END AS DEBIT_CARD_PROD_NAME -- 借记卡产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_PROPTY_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_PROPTY_TYPE_CD, BF.CARD_PROPTY_TYPE_CD) END AS CARD_PROPTY_TYPE_CD -- 卡性质类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TRGT_CUST_CARD_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.TRGT_CUST_CARD_TYPE_CD, BF.TRGT_CUST_CARD_TYPE_CD) END AS TRGT_CUST_CARD_TYPE_CD -- 卡对象类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_BRAND_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_BRAND_TYPE_CD, BF.CARD_BRAND_TYPE_CD) END AS CARD_BRAND_TYPE_CD -- 卡品牌类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_MED_TYPE_CD, BF.CARD_MED_TYPE_CD) END AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MODIF_BEF_CARD_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.MODIF_BEF_CARD_STATUS_CD, BF.MODIF_BEF_CARD_STATUS_CD) END AS MODIF_BEF_CARD_STATUS_CD -- 修改前卡片状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_STATUS_CD, BF.CARD_STATUS_CD) END AS CARD_STATUS_CD -- 卡片状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GOOD_HVST_DEBIT_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.GOOD_HVST_DEBIT_CARD_FLAG, BF.GOOD_HVST_DEBIT_CARD_FLAG) END AS GOOD_HVST_DEBIT_CARD_FLAG -- 丰收借记卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EMPLY_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.EMPLY_CARD_FLAG, BF.EMPLY_CARD_FLAG) END AS EMPLY_CARD_FLAG -- 员工卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FOLD_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.FOLD_CARD_FLAG, BF.FOLD_CARD_FLAG) END AS FOLD_CARD_FLAG -- 有折卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FORGED_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.FORGED_CARD_FLAG, BF.FORGED_CARD_FLAG) END AS FORGED_CARD_FLAG -- 伪冒卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.NAT_SECRET_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.NAT_SECRET_CARD_FLAG, BF.NAT_SECRET_CARD_FLAG) END AS NAT_SECRET_CARD_FLAG -- 国密卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_AGT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_AGT_TYPE_CD, BF.CARD_AGT_TYPE_CD) END AS CARD_AGT_TYPE_CD -- 卡协议类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VOCH_CATE_CD IS NULL THEN NULL ELSE COALESCE(TM.VOCH_CATE_CD, BF.VOCH_CATE_CD) END AS VOCH_CATE_CD -- 凭证种类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CO_SIGN_IDTFY_CERT_CORP_NO IS NULL THEN NULL ELSE COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO, BF.CO_SIGN_IDTFY_CERT_CORP_NO) END AS CO_SIGN_IDTFY_CERT_CORP_NO -- 联名认同单位编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEBIT_CARD_ANLFEE_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.DEBIT_CARD_ANLFEE_TYPE_CD, BF.DEBIT_CARD_ANLFEE_TYPE_CD) END AS DEBIT_CARD_ANLFEE_TYPE_CD -- 借记卡年费类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_CHARGE_RATE_PREFR_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.SERV_CHARGE_RATE_PREFR_LVL_CD, BF.SERV_CHARGE_RATE_PREFR_LVL_CD) END AS SERV_CHARGE_RATE_PREFR_LVL_CD -- 费率优惠等级代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FREE_CARD_ANLFEE_EFFECT_DT IS NULL THEN NULL ELSE COALESCE(TM.FREE_CARD_ANLFEE_EFFECT_DT, BF.FREE_CARD_ANLFEE_EFFECT_DT) END AS FREE_CARD_ANLFEE_EFFECT_DT -- 豁免卡年费生效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FREE_CARD_ANLFEE_EXPIR_DT IS NULL THEN NULL ELSE COALESCE(TM.FREE_CARD_ANLFEE_EXPIR_DT, BF.FREE_CARD_ANLFEE_EXPIR_DT) END AS FREE_CARD_ANLFEE_EXPIR_DT -- 豁免卡年费失效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LAST_COL_ANLFEE_DT IS NULL THEN NULL ELSE COALESCE(TM.LAST_COL_ANLFEE_DT, BF.LAST_COL_ANLFEE_DT) END AS LAST_COL_ANLFEE_DT -- 上次收取年费日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONSM_POINT_BAL IS NULL THEN NULL ELSE COALESCE(TM.CONSM_POINT_BAL, BF.CONSM_POINT_BAL) END AS CONSM_POINT_BAL -- 消费积分余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UN_CROSS_ANLFEE_TOTAL_AMT IS NULL THEN NULL ELSE COALESCE(TM.UN_CROSS_ANLFEE_TOTAL_AMT, BF.UN_CROSS_ANLFEE_TOTAL_AMT) END AS UN_CROSS_ANLFEE_TOTAL_AMT -- 未交年费总额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_CASH_ALLOW_OPEN_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ELEC_CASH_ALLOW_OPEN_FLAG, BF.ELEC_CASH_ALLOW_OPEN_FLAG) END AS ELEC_CASH_ALLOW_OPEN_FLAG -- 电子现金允许开通标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_CASH_OPEN_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ELEC_CASH_OPEN_FLAG, BF.ELEC_CASH_OPEN_FLAG) END AS ELEC_CASH_OPEN_FLAG -- 电子现金开通标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SOCI_SECU_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SOCI_SECU_CARD_FLAG, BF.SOCI_SECU_CARD_FLAG) END AS SOCI_SECU_CARD_FLAG -- 社保卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SOCI_SECU_CARD_ONLINE_ACT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SOCI_SECU_CARD_ONLINE_ACT_FLAG, BF.SOCI_SECU_CARD_ONLINE_ACT_FLAG) END AS SOCI_SECU_CARD_ONLINE_ACT_FLAG -- 社保卡在线激活标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SMS_SERV_PROVI_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SMS_SERV_PROVI_FLAG, BF.SMS_SERV_PROVI_FLAG) END AS SMS_SERV_PROVI_FLAG -- 短信服务提供标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TEL_BANK_SERV_PROVI_FLAG IS NULL THEN NULL ELSE COALESCE(TM.TEL_BANK_SERV_PROVI_FLAG, BF.TEL_BANK_SERV_PROVI_FLAG) END AS TEL_BANK_SERV_PROVI_FLAG -- 电话银行服务提供标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ATM_SERV_PROVI_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ATM_SERV_PROVI_FLAG, BF.ATM_SERV_PROVI_FLAG) END AS ATM_SERV_PROVI_FLAG -- ATM服务提供标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POS_SERV_PROVI_FLAG IS NULL THEN NULL ELSE COALESCE(TM.POS_SERV_PROVI_FLAG, BF.POS_SERV_PROVI_FLAG) END AS POS_SERV_PROVI_FLAG -- POS服务提供标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_COMMS_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SETUP_COMMS_FLAG, BF.SETUP_COMMS_FLAG) END AS SETUP_COMMS_FLAG -- 建立委托标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MICRO_FREE_SECRET_VISA_XMP_FLAG IS NULL THEN NULL ELSE COALESCE(TM.MICRO_FREE_SECRET_VISA_XMP_FLAG, BF.MICRO_FREE_SECRET_VISA_XMP_FLAG) END AS MICRO_FREE_SECRET_VISA_XMP_FLAG -- 小额免密免签标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACPTD_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.ACPTD_ORG_NO, BF.ACPTD_ORG_NO) END AS ACPTD_ORG_NO -- 受理机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAKE_CARD_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.MAKE_CARD_TELR_NO, BF.MAKE_CARD_TELR_NO) END AS MAKE_CARD_TELR_NO -- 制卡柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MAKE_CARD_DT IS NULL THEN NULL ELSE COALESCE(TM.MAKE_CARD_DT, BF.MAKE_CARD_DT) END AS MAKE_CARD_DT -- 制卡日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ISSUE_DRAW_CARD_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.ISSUE_DRAW_CARD_ORG_NO, BF.ISSUE_DRAW_CARD_ORG_NO) END AS ISSUE_DRAW_CARD_ORG_NO -- 发领卡机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_CARD_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_CARD_CHNL_CD, BF.OPEN_CARD_CHNL_CD) END AS OPEN_CARD_CHNL_CD -- 开卡渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_CARD_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.OPEN_CARD_TELR_NO, BF.OPEN_CARD_TELR_NO) END AS OPEN_CARD_TELR_NO -- 开卡柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_CARD_DT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_CARD_DT, BF.OPEN_CARD_DT) END AS OPEN_CARD_DT -- 开卡日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ENABLED_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.ENABLED_TELR_NO, BF.ENABLED_TELR_NO) END AS ENABLED_TELR_NO -- 启用柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ENABLED_DT IS NULL THEN NULL ELSE COALESCE(TM.ENABLED_DT, BF.ENABLED_DT) END AS ENABLED_DT -- 启用日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SAME_CARD_NO_CHG_CARD_APP_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SAME_CARD_NO_CHG_CARD_APP_FLAG, BF.SAME_CARD_NO_CHG_CARD_APP_FLAG) END AS SAME_CARD_NO_CHG_CARD_APP_FLAG -- 同卡号换卡申请标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SAME_CARD_NO_CHG_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SAME_CARD_NO_CHG_CARD_FLAG, BF.SAME_CARD_NO_CHG_CARD_FLAG) END AS SAME_CARD_NO_CHG_CARD_FLAG -- 同卡号换卡标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CHG_CARD_DT IS NULL THEN NULL ELSE COALESCE(TM.CHG_CARD_DT, BF.CHG_CARD_DT) END AS CHG_CARD_DT -- 换卡日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PWD_ENABLED_FLAG IS NULL THEN NULL ELSE COALESCE(TM.PWD_ENABLED_FLAG, BF.PWD_ENABLED_FLAG) END AS PWD_ENABLED_FLAG -- 密码启用标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REPLOS_FLAG IS NULL THEN NULL ELSE COALESCE(TM.REPLOS_FLAG, BF.REPLOS_FLAG) END AS REPLOS_FLAG -- 挂失标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_PWD_REPLOS_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_PWD_REPLOS_TYPE_CD, BF.CARD_PWD_REPLOS_TYPE_CD) END AS CARD_PWD_REPLOS_TYPE_CD -- 卡密码挂失类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_REPLOS_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_REPLOS_TYPE_CD, BF.CARD_REPLOS_TYPE_CD) END AS CARD_REPLOS_TYPE_CD -- 卡片挂失类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_MATU_YM IS NULL THEN NULL ELSE COALESCE(TM.CARD_MATU_YM, BF.CARD_MATU_YM) END AS CARD_MATU_YM -- 卡到期年月
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.NOT_CARD_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.NOT_CARD_TYPE_CD, BF.NOT_CARD_TYPE_CD) END AS NOT_CARD_TYPE_CD -- 不动卡类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.NOT_CARD_DT IS NULL THEN NULL ELSE COALESCE(TM.NOT_CARD_DT, BF.NOT_CARD_DT) END AS NOT_CARD_DT -- 置不动卡日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_CARD_RSN_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_CARD_RSN_CD, BF.RECV_CARD_RSN_CD) END AS RECV_CARD_RSN_CD -- 销收卡原因代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CLOSE_CARD_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.CLOSE_CARD_CHNL_CD, BF.CLOSE_CARD_CHNL_CD) END AS CLOSE_CARD_CHNL_CD -- 销卡渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_CARD_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_CARD_ORG_NO, BF.RECV_CARD_ORG_NO) END AS RECV_CARD_ORG_NO -- 销收卡机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_CARD_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_CARD_TELR_NO, BF.RECV_CARD_TELR_NO) END AS RECV_CARD_TELR_NO -- 销收卡柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_CARD_DT IS NULL THEN NULL ELSE COALESCE(TM.RECV_CARD_DT, BF.RECV_CARD_DT) END AS RECV_CARD_DT -- 销收卡日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TELR_NO, BF.SETUP_TELR_NO) END AS SETUP_TELR_NO -- 建立柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_DT IS NULL THEN NULL ELSE COALESCE(TM.SETUP_DT, BF.SETUP_DT) END AS SETUP_DT -- 建立日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TM_STAMP, BF.SETUP_TM_STAMP) END AS SETUP_TM_STAMP -- 建立时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_FINAL_TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.CUST_FINAL_TXN_DT, BF.CUST_FINAL_TXN_DT) END AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STAT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.STAT_ORG_NO, BF.STAT_ORG_NO) END AS STAT_ORG_NO -- 统计机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.B_SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.B_SRC_SYS_CD, BF.B_SRC_SYS_CD) END AS B_SRC_SYS_CD -- 业务来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REC_STATUS_CD, BF.REC_STATUS_CD) END AS REC_STATUS_CD -- 记录状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MICRO_ACCT_BAL IS NULL THEN NULL ELSE COALESCE(TM.MICRO_ACCT_BAL, BF.MICRO_ACCT_BAL) END AS MICRO_ACCT_BAL -- 小额账户余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMPLT_ACCT_BAL IS NULL THEN NULL ELSE COALESCE(TM.COMPLT_ACCT_BAL, BF.COMPLT_ACCT_BAL) END AS COMPLT_ACCT_BAL -- 补登账户余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ECASH_ACCT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.ECASH_ACCT_FLAG, BF.ECASH_ACCT_FLAG) END AS ECASH_ACCT_FLAG -- 电子现金账户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.MAIN_CURR_CD,'') = COALESCE(BF.MAIN_CURR_CD,'') -- 主币种代码 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.CUST_NO,'') = COALESCE(BF.CUST_NO,'') -- 客户号 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_BIZ_TYPE_CD,'') = COALESCE(BF.DEBIT_CARD_BIZ_TYPE_CD,'') -- 借记卡业务类别代码 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_PROD_CD,'') = COALESCE(BF.DEBIT_CARD_PROD_CD,'') -- 借记卡产品代码 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_PROD_NAME,'') = COALESCE(BF.DEBIT_CARD_PROD_NAME,'') -- 借记卡产品名称 非主键字段相等
         AND COALESCE(TM.CARD_PROPTY_TYPE_CD,'') = COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段相等
         AND COALESCE(TM.TRGT_CUST_CARD_TYPE_CD,'') = COALESCE(BF.TRGT_CUST_CARD_TYPE_CD,'') -- 卡对象类别代码 非主键字段相等
         AND COALESCE(TM.CARD_BRAND_TYPE_CD,'') = COALESCE(BF.CARD_BRAND_TYPE_CD,'') -- 卡品牌类别代码 非主键字段相等
         AND COALESCE(TM.CARD_MED_TYPE_CD,'') = COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段相等
         AND COALESCE(TM.MODIF_BEF_CARD_STATUS_CD,'') = COALESCE(BF.MODIF_BEF_CARD_STATUS_CD,'') -- 修改前卡片状态代码 非主键字段相等
         AND COALESCE(TM.CARD_STATUS_CD,'') = COALESCE(BF.CARD_STATUS_CD,'') -- 卡片状态代码 非主键字段相等
         AND COALESCE(TM.GOOD_HVST_DEBIT_CARD_FLAG,'') = COALESCE(BF.GOOD_HVST_DEBIT_CARD_FLAG,'') -- 丰收借记卡标志 非主键字段相等
         AND COALESCE(TM.EMPLY_CARD_FLAG,'') = COALESCE(BF.EMPLY_CARD_FLAG,'') -- 员工卡标志 非主键字段相等
         AND COALESCE(TM.FOLD_CARD_FLAG,'') = COALESCE(BF.FOLD_CARD_FLAG,'') -- 有折卡标志 非主键字段相等
         AND COALESCE(TM.FORGED_CARD_FLAG,'') = COALESCE(BF.FORGED_CARD_FLAG,'') -- 伪冒卡标志 非主键字段相等
         AND COALESCE(TM.NAT_SECRET_CARD_FLAG,'') = COALESCE(BF.NAT_SECRET_CARD_FLAG,'') -- 国密卡标志 非主键字段相等
         AND COALESCE(TM.CARD_AGT_TYPE_CD,'') = COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段相等
         AND COALESCE(TM.VOCH_CATE_CD,'') = COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段相等
         AND COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') = COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_ANLFEE_TYPE_CD,'') = COALESCE(BF.DEBIT_CARD_ANLFEE_TYPE_CD,'') -- 借记卡年费类型代码 非主键字段相等
         AND COALESCE(TM.SERV_CHARGE_RATE_PREFR_LVL_CD,'') = COALESCE(BF.SERV_CHARGE_RATE_PREFR_LVL_CD,'') -- 费率优惠等级代码 非主键字段相等
         AND COALESCE(TM.FREE_CARD_ANLFEE_EFFECT_DT,'') = COALESCE(BF.FREE_CARD_ANLFEE_EFFECT_DT,'') -- 豁免卡年费生效日期 非主键字段相等
         AND COALESCE(TM.FREE_CARD_ANLFEE_EXPIR_DT,'') = COALESCE(BF.FREE_CARD_ANLFEE_EXPIR_DT,'') -- 豁免卡年费失效日期 非主键字段相等
         AND COALESCE(TM.LAST_COL_ANLFEE_DT,'') = COALESCE(BF.LAST_COL_ANLFEE_DT,'') -- 上次收取年费日期 非主键字段相等
         AND COALESCE(TM.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) -- 消费积分余额 非主键字段相等
         AND COALESCE(TM.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) -- 未交年费总额 非主键字段相等
         AND COALESCE(TM.ELEC_CASH_ALLOW_OPEN_FLAG,'') = COALESCE(BF.ELEC_CASH_ALLOW_OPEN_FLAG,'') -- 电子现金允许开通标志 非主键字段相等
         AND COALESCE(TM.ELEC_CASH_OPEN_FLAG,'') = COALESCE(BF.ELEC_CASH_OPEN_FLAG,'') -- 电子现金开通标志 非主键字段相等
         AND COALESCE(TM.SOCI_SECU_CARD_FLAG,'') = COALESCE(BF.SOCI_SECU_CARD_FLAG,'') -- 社保卡标志 非主键字段相等
         AND COALESCE(TM.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') = COALESCE(BF.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') -- 社保卡在线激活标志 非主键字段相等
         AND COALESCE(TM.SMS_SERV_PROVI_FLAG,'') = COALESCE(BF.SMS_SERV_PROVI_FLAG,'') -- 短信服务提供标志 非主键字段相等
         AND COALESCE(TM.TEL_BANK_SERV_PROVI_FLAG,'') = COALESCE(BF.TEL_BANK_SERV_PROVI_FLAG,'') -- 电话银行服务提供标志 非主键字段相等
         AND COALESCE(TM.ATM_SERV_PROVI_FLAG,'') = COALESCE(BF.ATM_SERV_PROVI_FLAG,'') -- ATM服务提供标志 非主键字段相等
         AND COALESCE(TM.POS_SERV_PROVI_FLAG,'') = COALESCE(BF.POS_SERV_PROVI_FLAG,'') -- POS服务提供标志 非主键字段相等
         AND COALESCE(TM.SETUP_COMMS_FLAG,'') = COALESCE(BF.SETUP_COMMS_FLAG,'') -- 建立委托标志 非主键字段相等
         AND COALESCE(TM.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') = COALESCE(BF.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') -- 小额免密免签标志 非主键字段相等
         AND COALESCE(TM.ACPTD_ORG_NO,'') = COALESCE(BF.ACPTD_ORG_NO,'') -- 受理机构编号 非主键字段相等
         AND COALESCE(TM.MAKE_CARD_TELR_NO,'') = COALESCE(BF.MAKE_CARD_TELR_NO,'') -- 制卡柜员编号 非主键字段相等
         AND COALESCE(TM.MAKE_CARD_DT,'') = COALESCE(BF.MAKE_CARD_DT,'') -- 制卡日期 非主键字段相等
         AND COALESCE(TM.ISSUE_DRAW_CARD_ORG_NO,'') = COALESCE(BF.ISSUE_DRAW_CARD_ORG_NO,'') -- 发领卡机构编号 非主键字段相等
         AND COALESCE(TM.OPEN_CARD_CHNL_CD,'') = COALESCE(BF.OPEN_CARD_CHNL_CD,'') -- 开卡渠道代码 非主键字段相等
         AND COALESCE(TM.OPEN_CARD_TELR_NO,'') = COALESCE(BF.OPEN_CARD_TELR_NO,'') -- 开卡柜员编号 非主键字段相等
         AND COALESCE(TM.OPEN_CARD_DT,'') = COALESCE(BF.OPEN_CARD_DT,'') -- 开卡日期 非主键字段相等
         AND COALESCE(TM.ENABLED_TELR_NO,'') = COALESCE(BF.ENABLED_TELR_NO,'') -- 启用柜员编号 非主键字段相等
         AND COALESCE(TM.ENABLED_DT,'') = COALESCE(BF.ENABLED_DT,'') -- 启用日期 非主键字段相等
         AND COALESCE(TM.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') = COALESCE(BF.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') -- 同卡号换卡申请标志 非主键字段相等
         AND COALESCE(TM.SAME_CARD_NO_CHG_CARD_FLAG,'') = COALESCE(BF.SAME_CARD_NO_CHG_CARD_FLAG,'') -- 同卡号换卡标志 非主键字段相等
         AND COALESCE(TM.CHG_CARD_DT,'') = COALESCE(BF.CHG_CARD_DT,'') -- 换卡日期 非主键字段相等
         AND COALESCE(TM.PWD_ENABLED_FLAG,'') = COALESCE(BF.PWD_ENABLED_FLAG,'') -- 密码启用标志 非主键字段相等
         AND COALESCE(TM.REPLOS_FLAG,'') = COALESCE(BF.REPLOS_FLAG,'') -- 挂失标志 非主键字段相等
         AND COALESCE(TM.CARD_PWD_REPLOS_TYPE_CD,'') = COALESCE(BF.CARD_PWD_REPLOS_TYPE_CD,'') -- 卡密码挂失类型代码 非主键字段相等
         AND COALESCE(TM.CARD_REPLOS_TYPE_CD,'') = COALESCE(BF.CARD_REPLOS_TYPE_CD,'') -- 卡片挂失类型代码 非主键字段相等
         AND COALESCE(TM.CARD_MATU_YM,'') = COALESCE(BF.CARD_MATU_YM,'') -- 卡到期年月 非主键字段相等
         AND COALESCE(TM.NOT_CARD_TYPE_CD,'') = COALESCE(BF.NOT_CARD_TYPE_CD,'') -- 不动卡类型代码 非主键字段相等
         AND COALESCE(TM.NOT_CARD_DT,'') = COALESCE(BF.NOT_CARD_DT,'') -- 置不动卡日期 非主键字段相等
         AND COALESCE(TM.RECV_CARD_RSN_CD,'') = COALESCE(BF.RECV_CARD_RSN_CD,'') -- 销收卡原因代码 非主键字段相等
         AND COALESCE(TM.CLOSE_CARD_CHNL_CD,'') = COALESCE(BF.CLOSE_CARD_CHNL_CD,'') -- 销卡渠道代码 非主键字段相等
         AND COALESCE(TM.RECV_CARD_ORG_NO,'') = COALESCE(BF.RECV_CARD_ORG_NO,'') -- 销收卡机构编号 非主键字段相等
         AND COALESCE(TM.RECV_CARD_TELR_NO,'') = COALESCE(BF.RECV_CARD_TELR_NO,'') -- 销收卡柜员编号 非主键字段相等
         AND COALESCE(TM.RECV_CARD_DT,'') = COALESCE(BF.RECV_CARD_DT,'') -- 销收卡日期 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.CUST_FINAL_TXN_DT,'') = COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 小额账户余额 非主键字段相等
         AND COALESCE(TM.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 补登账户余额 非主键字段相等
         AND COALESCE(TM.ECASH_ACCT_FLAG,'') = COALESCE(BF.ECASH_ACCT_FLAG,'') -- 电子现金账户标志 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.MAIN_CURR_CD,'') <> COALESCE(BF.MAIN_CURR_CD,'') -- 主币种代码 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.CUST_NO,'') <> COALESCE(BF.CUST_NO,'') -- 客户号 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_DOCTYP_CD,'') <> COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_DOC_NO,'') <> COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_BIZ_TYPE_CD,'') <> COALESCE(BF.DEBIT_CARD_BIZ_TYPE_CD,'') -- 借记卡业务类别代码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_PROD_CD,'') <> COALESCE(BF.DEBIT_CARD_PROD_CD,'') -- 借记卡产品代码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_PROD_NAME,'') <> COALESCE(BF.DEBIT_CARD_PROD_NAME,'') -- 借记卡产品名称 非主键字段不相等
         OR COALESCE(TM.CARD_PROPTY_TYPE_CD,'') <> COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段不相等
         OR COALESCE(TM.TRGT_CUST_CARD_TYPE_CD,'') <> COALESCE(BF.TRGT_CUST_CARD_TYPE_CD,'') -- 卡对象类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_BRAND_TYPE_CD,'') <> COALESCE(BF.CARD_BRAND_TYPE_CD,'') -- 卡品牌类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_MED_TYPE_CD,'') <> COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段不相等
         OR COALESCE(TM.MODIF_BEF_CARD_STATUS_CD,'') <> COALESCE(BF.MODIF_BEF_CARD_STATUS_CD,'') -- 修改前卡片状态代码 非主键字段不相等
         OR COALESCE(TM.CARD_STATUS_CD,'') <> COALESCE(BF.CARD_STATUS_CD,'') -- 卡片状态代码 非主键字段不相等
         OR COALESCE(TM.GOOD_HVST_DEBIT_CARD_FLAG,'') <> COALESCE(BF.GOOD_HVST_DEBIT_CARD_FLAG,'') -- 丰收借记卡标志 非主键字段不相等
         OR COALESCE(TM.EMPLY_CARD_FLAG,'') <> COALESCE(BF.EMPLY_CARD_FLAG,'') -- 员工卡标志 非主键字段不相等
         OR COALESCE(TM.FOLD_CARD_FLAG,'') <> COALESCE(BF.FOLD_CARD_FLAG,'') -- 有折卡标志 非主键字段不相等
         OR COALESCE(TM.FORGED_CARD_FLAG,'') <> COALESCE(BF.FORGED_CARD_FLAG,'') -- 伪冒卡标志 非主键字段不相等
         OR COALESCE(TM.NAT_SECRET_CARD_FLAG,'') <> COALESCE(BF.NAT_SECRET_CARD_FLAG,'') -- 国密卡标志 非主键字段不相等
         OR COALESCE(TM.CARD_AGT_TYPE_CD,'') <> COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段不相等
         OR COALESCE(TM.VOCH_CATE_CD,'') <> COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段不相等
         OR COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') <> COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_ANLFEE_TYPE_CD,'') <> COALESCE(BF.DEBIT_CARD_ANLFEE_TYPE_CD,'') -- 借记卡年费类型代码 非主键字段不相等
         OR COALESCE(TM.SERV_CHARGE_RATE_PREFR_LVL_CD,'') <> COALESCE(BF.SERV_CHARGE_RATE_PREFR_LVL_CD,'') -- 费率优惠等级代码 非主键字段不相等
         OR COALESCE(TM.FREE_CARD_ANLFEE_EFFECT_DT,'') <> COALESCE(BF.FREE_CARD_ANLFEE_EFFECT_DT,'') -- 豁免卡年费生效日期 非主键字段不相等
         OR COALESCE(TM.FREE_CARD_ANLFEE_EXPIR_DT,'') <> COALESCE(BF.FREE_CARD_ANLFEE_EXPIR_DT,'') -- 豁免卡年费失效日期 非主键字段不相等
         OR COALESCE(TM.LAST_COL_ANLFEE_DT,'') <> COALESCE(BF.LAST_COL_ANLFEE_DT,'') -- 上次收取年费日期 非主键字段不相等
         OR COALESCE(TM.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) -- 消费积分余额 非主键字段不相等
         OR COALESCE(TM.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) -- 未交年费总额 非主键字段不相等
         OR COALESCE(TM.ELEC_CASH_ALLOW_OPEN_FLAG,'') <> COALESCE(BF.ELEC_CASH_ALLOW_OPEN_FLAG,'') -- 电子现金允许开通标志 非主键字段不相等
         OR COALESCE(TM.ELEC_CASH_OPEN_FLAG,'') <> COALESCE(BF.ELEC_CASH_OPEN_FLAG,'') -- 电子现金开通标志 非主键字段不相等
         OR COALESCE(TM.SOCI_SECU_CARD_FLAG,'') <> COALESCE(BF.SOCI_SECU_CARD_FLAG,'') -- 社保卡标志 非主键字段不相等
         OR COALESCE(TM.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') <> COALESCE(BF.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') -- 社保卡在线激活标志 非主键字段不相等
         OR COALESCE(TM.SMS_SERV_PROVI_FLAG,'') <> COALESCE(BF.SMS_SERV_PROVI_FLAG,'') -- 短信服务提供标志 非主键字段不相等
         OR COALESCE(TM.TEL_BANK_SERV_PROVI_FLAG,'') <> COALESCE(BF.TEL_BANK_SERV_PROVI_FLAG,'') -- 电话银行服务提供标志 非主键字段不相等
         OR COALESCE(TM.ATM_SERV_PROVI_FLAG,'') <> COALESCE(BF.ATM_SERV_PROVI_FLAG,'') -- ATM服务提供标志 非主键字段不相等
         OR COALESCE(TM.POS_SERV_PROVI_FLAG,'') <> COALESCE(BF.POS_SERV_PROVI_FLAG,'') -- POS服务提供标志 非主键字段不相等
         OR COALESCE(TM.SETUP_COMMS_FLAG,'') <> COALESCE(BF.SETUP_COMMS_FLAG,'') -- 建立委托标志 非主键字段不相等
         OR COALESCE(TM.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') <> COALESCE(BF.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') -- 小额免密免签标志 非主键字段不相等
         OR COALESCE(TM.ACPTD_ORG_NO,'') <> COALESCE(BF.ACPTD_ORG_NO,'') -- 受理机构编号 非主键字段不相等
         OR COALESCE(TM.MAKE_CARD_TELR_NO,'') <> COALESCE(BF.MAKE_CARD_TELR_NO,'') -- 制卡柜员编号 非主键字段不相等
         OR COALESCE(TM.MAKE_CARD_DT,'') <> COALESCE(BF.MAKE_CARD_DT,'') -- 制卡日期 非主键字段不相等
         OR COALESCE(TM.ISSUE_DRAW_CARD_ORG_NO,'') <> COALESCE(BF.ISSUE_DRAW_CARD_ORG_NO,'') -- 发领卡机构编号 非主键字段不相等
         OR COALESCE(TM.OPEN_CARD_CHNL_CD,'') <> COALESCE(BF.OPEN_CARD_CHNL_CD,'') -- 开卡渠道代码 非主键字段不相等
         OR COALESCE(TM.OPEN_CARD_TELR_NO,'') <> COALESCE(BF.OPEN_CARD_TELR_NO,'') -- 开卡柜员编号 非主键字段不相等
         OR COALESCE(TM.OPEN_CARD_DT,'') <> COALESCE(BF.OPEN_CARD_DT,'') -- 开卡日期 非主键字段不相等
         OR COALESCE(TM.ENABLED_TELR_NO,'') <> COALESCE(BF.ENABLED_TELR_NO,'') -- 启用柜员编号 非主键字段不相等
         OR COALESCE(TM.ENABLED_DT,'') <> COALESCE(BF.ENABLED_DT,'') -- 启用日期 非主键字段不相等
         OR COALESCE(TM.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') <> COALESCE(BF.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') -- 同卡号换卡申请标志 非主键字段不相等
         OR COALESCE(TM.SAME_CARD_NO_CHG_CARD_FLAG,'') <> COALESCE(BF.SAME_CARD_NO_CHG_CARD_FLAG,'') -- 同卡号换卡标志 非主键字段不相等
         OR COALESCE(TM.CHG_CARD_DT,'') <> COALESCE(BF.CHG_CARD_DT,'') -- 换卡日期 非主键字段不相等
         OR COALESCE(TM.PWD_ENABLED_FLAG,'') <> COALESCE(BF.PWD_ENABLED_FLAG,'') -- 密码启用标志 非主键字段不相等
         OR COALESCE(TM.REPLOS_FLAG,'') <> COALESCE(BF.REPLOS_FLAG,'') -- 挂失标志 非主键字段不相等
         OR COALESCE(TM.CARD_PWD_REPLOS_TYPE_CD,'') <> COALESCE(BF.CARD_PWD_REPLOS_TYPE_CD,'') -- 卡密码挂失类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_REPLOS_TYPE_CD,'') <> COALESCE(BF.CARD_REPLOS_TYPE_CD,'') -- 卡片挂失类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_MATU_YM,'') <> COALESCE(BF.CARD_MATU_YM,'') -- 卡到期年月 非主键字段不相等
         OR COALESCE(TM.NOT_CARD_TYPE_CD,'') <> COALESCE(BF.NOT_CARD_TYPE_CD,'') -- 不动卡类型代码 非主键字段不相等
         OR COALESCE(TM.NOT_CARD_DT,'') <> COALESCE(BF.NOT_CARD_DT,'') -- 置不动卡日期 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_RSN_CD,'') <> COALESCE(BF.RECV_CARD_RSN_CD,'') -- 销收卡原因代码 非主键字段不相等
         OR COALESCE(TM.CLOSE_CARD_CHNL_CD,'') <> COALESCE(BF.CLOSE_CARD_CHNL_CD,'') -- 销卡渠道代码 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_ORG_NO,'') <> COALESCE(BF.RECV_CARD_ORG_NO,'') -- 销收卡机构编号 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_TELR_NO,'') <> COALESCE(BF.RECV_CARD_TELR_NO,'') -- 销收卡柜员编号 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_DT,'') <> COALESCE(BF.RECV_CARD_DT,'') -- 销收卡日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.CUST_FINAL_TXN_DT,'') <> COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 小额账户余额 非主键字段不相等
         OR COALESCE(TM.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 补登账户余额 非主键字段不相等
         OR COALESCE(TM.ECASH_ACCT_FLAG,'') <> COALESCE(BF.ECASH_ACCT_FLAG,'') -- 电子现金账户标志 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.MAIN_CURR_CD,'') = COALESCE(BF.MAIN_CURR_CD,'') -- 主币种代码 非主键字段相等
         AND COALESCE(TM.ACCT_PROPTY_CD,'') = COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.CUST_NO,'') = COALESCE(BF.CUST_NO,'') -- 客户号 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_BIZ_TYPE_CD,'') = COALESCE(BF.DEBIT_CARD_BIZ_TYPE_CD,'') -- 借记卡业务类别代码 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_PROD_CD,'') = COALESCE(BF.DEBIT_CARD_PROD_CD,'') -- 借记卡产品代码 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_PROD_NAME,'') = COALESCE(BF.DEBIT_CARD_PROD_NAME,'') -- 借记卡产品名称 非主键字段相等
         AND COALESCE(TM.CARD_PROPTY_TYPE_CD,'') = COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段相等
         AND COALESCE(TM.TRGT_CUST_CARD_TYPE_CD,'') = COALESCE(BF.TRGT_CUST_CARD_TYPE_CD,'') -- 卡对象类别代码 非主键字段相等
         AND COALESCE(TM.CARD_BRAND_TYPE_CD,'') = COALESCE(BF.CARD_BRAND_TYPE_CD,'') -- 卡品牌类别代码 非主键字段相等
         AND COALESCE(TM.CARD_MED_TYPE_CD,'') = COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段相等
         AND COALESCE(TM.MODIF_BEF_CARD_STATUS_CD,'') = COALESCE(BF.MODIF_BEF_CARD_STATUS_CD,'') -- 修改前卡片状态代码 非主键字段相等
         AND COALESCE(TM.CARD_STATUS_CD,'') = COALESCE(BF.CARD_STATUS_CD,'') -- 卡片状态代码 非主键字段相等
         AND COALESCE(TM.GOOD_HVST_DEBIT_CARD_FLAG,'') = COALESCE(BF.GOOD_HVST_DEBIT_CARD_FLAG,'') -- 丰收借记卡标志 非主键字段相等
         AND COALESCE(TM.EMPLY_CARD_FLAG,'') = COALESCE(BF.EMPLY_CARD_FLAG,'') -- 员工卡标志 非主键字段相等
         AND COALESCE(TM.FOLD_CARD_FLAG,'') = COALESCE(BF.FOLD_CARD_FLAG,'') -- 有折卡标志 非主键字段相等
         AND COALESCE(TM.FORGED_CARD_FLAG,'') = COALESCE(BF.FORGED_CARD_FLAG,'') -- 伪冒卡标志 非主键字段相等
         AND COALESCE(TM.NAT_SECRET_CARD_FLAG,'') = COALESCE(BF.NAT_SECRET_CARD_FLAG,'') -- 国密卡标志 非主键字段相等
         AND COALESCE(TM.CARD_AGT_TYPE_CD,'') = COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段相等
         AND COALESCE(TM.VOCH_CATE_CD,'') = COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段相等
         AND COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') = COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段相等
         AND COALESCE(TM.DEBIT_CARD_ANLFEE_TYPE_CD,'') = COALESCE(BF.DEBIT_CARD_ANLFEE_TYPE_CD,'') -- 借记卡年费类型代码 非主键字段相等
         AND COALESCE(TM.SERV_CHARGE_RATE_PREFR_LVL_CD,'') = COALESCE(BF.SERV_CHARGE_RATE_PREFR_LVL_CD,'') -- 费率优惠等级代码 非主键字段相等
         AND COALESCE(TM.FREE_CARD_ANLFEE_EFFECT_DT,'') = COALESCE(BF.FREE_CARD_ANLFEE_EFFECT_DT,'') -- 豁免卡年费生效日期 非主键字段相等
         AND COALESCE(TM.FREE_CARD_ANLFEE_EXPIR_DT,'') = COALESCE(BF.FREE_CARD_ANLFEE_EXPIR_DT,'') -- 豁免卡年费失效日期 非主键字段相等
         AND COALESCE(TM.LAST_COL_ANLFEE_DT,'') = COALESCE(BF.LAST_COL_ANLFEE_DT,'') -- 上次收取年费日期 非主键字段相等
         AND COALESCE(TM.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) -- 消费积分余额 非主键字段相等
         AND COALESCE(TM.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) -- 未交年费总额 非主键字段相等
         AND COALESCE(TM.ELEC_CASH_ALLOW_OPEN_FLAG,'') = COALESCE(BF.ELEC_CASH_ALLOW_OPEN_FLAG,'') -- 电子现金允许开通标志 非主键字段相等
         AND COALESCE(TM.ELEC_CASH_OPEN_FLAG,'') = COALESCE(BF.ELEC_CASH_OPEN_FLAG,'') -- 电子现金开通标志 非主键字段相等
         AND COALESCE(TM.SOCI_SECU_CARD_FLAG,'') = COALESCE(BF.SOCI_SECU_CARD_FLAG,'') -- 社保卡标志 非主键字段相等
         AND COALESCE(TM.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') = COALESCE(BF.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') -- 社保卡在线激活标志 非主键字段相等
         AND COALESCE(TM.SMS_SERV_PROVI_FLAG,'') = COALESCE(BF.SMS_SERV_PROVI_FLAG,'') -- 短信服务提供标志 非主键字段相等
         AND COALESCE(TM.TEL_BANK_SERV_PROVI_FLAG,'') = COALESCE(BF.TEL_BANK_SERV_PROVI_FLAG,'') -- 电话银行服务提供标志 非主键字段相等
         AND COALESCE(TM.ATM_SERV_PROVI_FLAG,'') = COALESCE(BF.ATM_SERV_PROVI_FLAG,'') -- ATM服务提供标志 非主键字段相等
         AND COALESCE(TM.POS_SERV_PROVI_FLAG,'') = COALESCE(BF.POS_SERV_PROVI_FLAG,'') -- POS服务提供标志 非主键字段相等
         AND COALESCE(TM.SETUP_COMMS_FLAG,'') = COALESCE(BF.SETUP_COMMS_FLAG,'') -- 建立委托标志 非主键字段相等
         AND COALESCE(TM.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') = COALESCE(BF.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') -- 小额免密免签标志 非主键字段相等
         AND COALESCE(TM.ACPTD_ORG_NO,'') = COALESCE(BF.ACPTD_ORG_NO,'') -- 受理机构编号 非主键字段相等
         AND COALESCE(TM.MAKE_CARD_TELR_NO,'') = COALESCE(BF.MAKE_CARD_TELR_NO,'') -- 制卡柜员编号 非主键字段相等
         AND COALESCE(TM.MAKE_CARD_DT,'') = COALESCE(BF.MAKE_CARD_DT,'') -- 制卡日期 非主键字段相等
         AND COALESCE(TM.ISSUE_DRAW_CARD_ORG_NO,'') = COALESCE(BF.ISSUE_DRAW_CARD_ORG_NO,'') -- 发领卡机构编号 非主键字段相等
         AND COALESCE(TM.OPEN_CARD_CHNL_CD,'') = COALESCE(BF.OPEN_CARD_CHNL_CD,'') -- 开卡渠道代码 非主键字段相等
         AND COALESCE(TM.OPEN_CARD_TELR_NO,'') = COALESCE(BF.OPEN_CARD_TELR_NO,'') -- 开卡柜员编号 非主键字段相等
         AND COALESCE(TM.OPEN_CARD_DT,'') = COALESCE(BF.OPEN_CARD_DT,'') -- 开卡日期 非主键字段相等
         AND COALESCE(TM.ENABLED_TELR_NO,'') = COALESCE(BF.ENABLED_TELR_NO,'') -- 启用柜员编号 非主键字段相等
         AND COALESCE(TM.ENABLED_DT,'') = COALESCE(BF.ENABLED_DT,'') -- 启用日期 非主键字段相等
         AND COALESCE(TM.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') = COALESCE(BF.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') -- 同卡号换卡申请标志 非主键字段相等
         AND COALESCE(TM.SAME_CARD_NO_CHG_CARD_FLAG,'') = COALESCE(BF.SAME_CARD_NO_CHG_CARD_FLAG,'') -- 同卡号换卡标志 非主键字段相等
         AND COALESCE(TM.CHG_CARD_DT,'') = COALESCE(BF.CHG_CARD_DT,'') -- 换卡日期 非主键字段相等
         AND COALESCE(TM.PWD_ENABLED_FLAG,'') = COALESCE(BF.PWD_ENABLED_FLAG,'') -- 密码启用标志 非主键字段相等
         AND COALESCE(TM.REPLOS_FLAG,'') = COALESCE(BF.REPLOS_FLAG,'') -- 挂失标志 非主键字段相等
         AND COALESCE(TM.CARD_PWD_REPLOS_TYPE_CD,'') = COALESCE(BF.CARD_PWD_REPLOS_TYPE_CD,'') -- 卡密码挂失类型代码 非主键字段相等
         AND COALESCE(TM.CARD_REPLOS_TYPE_CD,'') = COALESCE(BF.CARD_REPLOS_TYPE_CD,'') -- 卡片挂失类型代码 非主键字段相等
         AND COALESCE(TM.CARD_MATU_YM,'') = COALESCE(BF.CARD_MATU_YM,'') -- 卡到期年月 非主键字段相等
         AND COALESCE(TM.NOT_CARD_TYPE_CD,'') = COALESCE(BF.NOT_CARD_TYPE_CD,'') -- 不动卡类型代码 非主键字段相等
         AND COALESCE(TM.NOT_CARD_DT,'') = COALESCE(BF.NOT_CARD_DT,'') -- 置不动卡日期 非主键字段相等
         AND COALESCE(TM.RECV_CARD_RSN_CD,'') = COALESCE(BF.RECV_CARD_RSN_CD,'') -- 销收卡原因代码 非主键字段相等
         AND COALESCE(TM.CLOSE_CARD_CHNL_CD,'') = COALESCE(BF.CLOSE_CARD_CHNL_CD,'') -- 销卡渠道代码 非主键字段相等
         AND COALESCE(TM.RECV_CARD_ORG_NO,'') = COALESCE(BF.RECV_CARD_ORG_NO,'') -- 销收卡机构编号 非主键字段相等
         AND COALESCE(TM.RECV_CARD_TELR_NO,'') = COALESCE(BF.RECV_CARD_TELR_NO,'') -- 销收卡柜员编号 非主键字段相等
         AND COALESCE(TM.RECV_CARD_DT,'') = COALESCE(BF.RECV_CARD_DT,'') -- 销收卡日期 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TM_STAMP,'') = COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段相等
         AND COALESCE(TM.CUST_FINAL_TXN_DT,'') = COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 小额账户余额 非主键字段相等
         AND COALESCE(TM.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 补登账户余额 非主键字段相等
         AND COALESCE(TM.ECASH_ACCT_FLAG,'') = COALESCE(BF.ECASH_ACCT_FLAG,'') -- 电子现金账户标志 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.MAIN_CURR_CD,'') <> COALESCE(BF.MAIN_CURR_CD,'') -- 主币种代码 非主键字段不相等
         OR COALESCE(TM.ACCT_PROPTY_CD,'') <> COALESCE(BF.ACCT_PROPTY_CD,'') -- 账户性质代码 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.CUST_NO,'') <> COALESCE(BF.CUST_NO,'') -- 客户号 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_DOCTYP_CD,'') <> COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_DOC_NO,'') <> COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_BIZ_TYPE_CD,'') <> COALESCE(BF.DEBIT_CARD_BIZ_TYPE_CD,'') -- 借记卡业务类别代码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_PROD_CD,'') <> COALESCE(BF.DEBIT_CARD_PROD_CD,'') -- 借记卡产品代码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_PROD_NAME,'') <> COALESCE(BF.DEBIT_CARD_PROD_NAME,'') -- 借记卡产品名称 非主键字段不相等
         OR COALESCE(TM.CARD_PROPTY_TYPE_CD,'') <> COALESCE(BF.CARD_PROPTY_TYPE_CD,'') -- 卡性质类别代码 非主键字段不相等
         OR COALESCE(TM.TRGT_CUST_CARD_TYPE_CD,'') <> COALESCE(BF.TRGT_CUST_CARD_TYPE_CD,'') -- 卡对象类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_BRAND_TYPE_CD,'') <> COALESCE(BF.CARD_BRAND_TYPE_CD,'') -- 卡品牌类别代码 非主键字段不相等
         OR COALESCE(TM.CARD_MED_TYPE_CD,'') <> COALESCE(BF.CARD_MED_TYPE_CD,'') -- 卡介质类别代码 非主键字段不相等
         OR COALESCE(TM.MODIF_BEF_CARD_STATUS_CD,'') <> COALESCE(BF.MODIF_BEF_CARD_STATUS_CD,'') -- 修改前卡片状态代码 非主键字段不相等
         OR COALESCE(TM.CARD_STATUS_CD,'') <> COALESCE(BF.CARD_STATUS_CD,'') -- 卡片状态代码 非主键字段不相等
         OR COALESCE(TM.GOOD_HVST_DEBIT_CARD_FLAG,'') <> COALESCE(BF.GOOD_HVST_DEBIT_CARD_FLAG,'') -- 丰收借记卡标志 非主键字段不相等
         OR COALESCE(TM.EMPLY_CARD_FLAG,'') <> COALESCE(BF.EMPLY_CARD_FLAG,'') -- 员工卡标志 非主键字段不相等
         OR COALESCE(TM.FOLD_CARD_FLAG,'') <> COALESCE(BF.FOLD_CARD_FLAG,'') -- 有折卡标志 非主键字段不相等
         OR COALESCE(TM.FORGED_CARD_FLAG,'') <> COALESCE(BF.FORGED_CARD_FLAG,'') -- 伪冒卡标志 非主键字段不相等
         OR COALESCE(TM.NAT_SECRET_CARD_FLAG,'') <> COALESCE(BF.NAT_SECRET_CARD_FLAG,'') -- 国密卡标志 非主键字段不相等
         OR COALESCE(TM.CARD_AGT_TYPE_CD,'') <> COALESCE(BF.CARD_AGT_TYPE_CD,'') -- 卡协议类别代码 非主键字段不相等
         OR COALESCE(TM.VOCH_CATE_CD,'') <> COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段不相等
         OR COALESCE(TM.CO_SIGN_IDTFY_CERT_CORP_NO,'') <> COALESCE(BF.CO_SIGN_IDTFY_CERT_CORP_NO,'') -- 联名认同单位编号 非主键字段不相等
         OR COALESCE(TM.DEBIT_CARD_ANLFEE_TYPE_CD,'') <> COALESCE(BF.DEBIT_CARD_ANLFEE_TYPE_CD,'') -- 借记卡年费类型代码 非主键字段不相等
         OR COALESCE(TM.SERV_CHARGE_RATE_PREFR_LVL_CD,'') <> COALESCE(BF.SERV_CHARGE_RATE_PREFR_LVL_CD,'') -- 费率优惠等级代码 非主键字段不相等
         OR COALESCE(TM.FREE_CARD_ANLFEE_EFFECT_DT,'') <> COALESCE(BF.FREE_CARD_ANLFEE_EFFECT_DT,'') -- 豁免卡年费生效日期 非主键字段不相等
         OR COALESCE(TM.FREE_CARD_ANLFEE_EXPIR_DT,'') <> COALESCE(BF.FREE_CARD_ANLFEE_EXPIR_DT,'') -- 豁免卡年费失效日期 非主键字段不相等
         OR COALESCE(TM.LAST_COL_ANLFEE_DT,'') <> COALESCE(BF.LAST_COL_ANLFEE_DT,'') -- 上次收取年费日期 非主键字段不相等
         OR COALESCE(TM.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CONSM_POINT_BAL,CAST(0 AS DECIMAL(28,2))) -- 消费积分余额 非主键字段不相等
         OR COALESCE(TM.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.UN_CROSS_ANLFEE_TOTAL_AMT,CAST(0 AS DECIMAL(28,2))) -- 未交年费总额 非主键字段不相等
         OR COALESCE(TM.ELEC_CASH_ALLOW_OPEN_FLAG,'') <> COALESCE(BF.ELEC_CASH_ALLOW_OPEN_FLAG,'') -- 电子现金允许开通标志 非主键字段不相等
         OR COALESCE(TM.ELEC_CASH_OPEN_FLAG,'') <> COALESCE(BF.ELEC_CASH_OPEN_FLAG,'') -- 电子现金开通标志 非主键字段不相等
         OR COALESCE(TM.SOCI_SECU_CARD_FLAG,'') <> COALESCE(BF.SOCI_SECU_CARD_FLAG,'') -- 社保卡标志 非主键字段不相等
         OR COALESCE(TM.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') <> COALESCE(BF.SOCI_SECU_CARD_ONLINE_ACT_FLAG,'') -- 社保卡在线激活标志 非主键字段不相等
         OR COALESCE(TM.SMS_SERV_PROVI_FLAG,'') <> COALESCE(BF.SMS_SERV_PROVI_FLAG,'') -- 短信服务提供标志 非主键字段不相等
         OR COALESCE(TM.TEL_BANK_SERV_PROVI_FLAG,'') <> COALESCE(BF.TEL_BANK_SERV_PROVI_FLAG,'') -- 电话银行服务提供标志 非主键字段不相等
         OR COALESCE(TM.ATM_SERV_PROVI_FLAG,'') <> COALESCE(BF.ATM_SERV_PROVI_FLAG,'') -- ATM服务提供标志 非主键字段不相等
         OR COALESCE(TM.POS_SERV_PROVI_FLAG,'') <> COALESCE(BF.POS_SERV_PROVI_FLAG,'') -- POS服务提供标志 非主键字段不相等
         OR COALESCE(TM.SETUP_COMMS_FLAG,'') <> COALESCE(BF.SETUP_COMMS_FLAG,'') -- 建立委托标志 非主键字段不相等
         OR COALESCE(TM.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') <> COALESCE(BF.MICRO_FREE_SECRET_VISA_XMP_FLAG,'') -- 小额免密免签标志 非主键字段不相等
         OR COALESCE(TM.ACPTD_ORG_NO,'') <> COALESCE(BF.ACPTD_ORG_NO,'') -- 受理机构编号 非主键字段不相等
         OR COALESCE(TM.MAKE_CARD_TELR_NO,'') <> COALESCE(BF.MAKE_CARD_TELR_NO,'') -- 制卡柜员编号 非主键字段不相等
         OR COALESCE(TM.MAKE_CARD_DT,'') <> COALESCE(BF.MAKE_CARD_DT,'') -- 制卡日期 非主键字段不相等
         OR COALESCE(TM.ISSUE_DRAW_CARD_ORG_NO,'') <> COALESCE(BF.ISSUE_DRAW_CARD_ORG_NO,'') -- 发领卡机构编号 非主键字段不相等
         OR COALESCE(TM.OPEN_CARD_CHNL_CD,'') <> COALESCE(BF.OPEN_CARD_CHNL_CD,'') -- 开卡渠道代码 非主键字段不相等
         OR COALESCE(TM.OPEN_CARD_TELR_NO,'') <> COALESCE(BF.OPEN_CARD_TELR_NO,'') -- 开卡柜员编号 非主键字段不相等
         OR COALESCE(TM.OPEN_CARD_DT,'') <> COALESCE(BF.OPEN_CARD_DT,'') -- 开卡日期 非主键字段不相等
         OR COALESCE(TM.ENABLED_TELR_NO,'') <> COALESCE(BF.ENABLED_TELR_NO,'') -- 启用柜员编号 非主键字段不相等
         OR COALESCE(TM.ENABLED_DT,'') <> COALESCE(BF.ENABLED_DT,'') -- 启用日期 非主键字段不相等
         OR COALESCE(TM.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') <> COALESCE(BF.SAME_CARD_NO_CHG_CARD_APP_FLAG,'') -- 同卡号换卡申请标志 非主键字段不相等
         OR COALESCE(TM.SAME_CARD_NO_CHG_CARD_FLAG,'') <> COALESCE(BF.SAME_CARD_NO_CHG_CARD_FLAG,'') -- 同卡号换卡标志 非主键字段不相等
         OR COALESCE(TM.CHG_CARD_DT,'') <> COALESCE(BF.CHG_CARD_DT,'') -- 换卡日期 非主键字段不相等
         OR COALESCE(TM.PWD_ENABLED_FLAG,'') <> COALESCE(BF.PWD_ENABLED_FLAG,'') -- 密码启用标志 非主键字段不相等
         OR COALESCE(TM.REPLOS_FLAG,'') <> COALESCE(BF.REPLOS_FLAG,'') -- 挂失标志 非主键字段不相等
         OR COALESCE(TM.CARD_PWD_REPLOS_TYPE_CD,'') <> COALESCE(BF.CARD_PWD_REPLOS_TYPE_CD,'') -- 卡密码挂失类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_REPLOS_TYPE_CD,'') <> COALESCE(BF.CARD_REPLOS_TYPE_CD,'') -- 卡片挂失类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_MATU_YM,'') <> COALESCE(BF.CARD_MATU_YM,'') -- 卡到期年月 非主键字段不相等
         OR COALESCE(TM.NOT_CARD_TYPE_CD,'') <> COALESCE(BF.NOT_CARD_TYPE_CD,'') -- 不动卡类型代码 非主键字段不相等
         OR COALESCE(TM.NOT_CARD_DT,'') <> COALESCE(BF.NOT_CARD_DT,'') -- 置不动卡日期 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_RSN_CD,'') <> COALESCE(BF.RECV_CARD_RSN_CD,'') -- 销收卡原因代码 非主键字段不相等
         OR COALESCE(TM.CLOSE_CARD_CHNL_CD,'') <> COALESCE(BF.CLOSE_CARD_CHNL_CD,'') -- 销卡渠道代码 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_ORG_NO,'') <> COALESCE(BF.RECV_CARD_ORG_NO,'') -- 销收卡机构编号 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_TELR_NO,'') <> COALESCE(BF.RECV_CARD_TELR_NO,'') -- 销收卡柜员编号 非主键字段不相等
         OR COALESCE(TM.RECV_CARD_DT,'') <> COALESCE(BF.RECV_CARD_DT,'') -- 销收卡日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TM_STAMP,'') <> COALESCE(BF.SETUP_TM_STAMP,'') -- 建立时间戳 非主键字段不相等
         OR COALESCE(TM.CUST_FINAL_TXN_DT,'') <> COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MICRO_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 小额账户余额 非主键字段不相等
         OR COALESCE(TM.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.COMPLT_ACCT_BAL,CAST(0 AS DECIMAL(28,2))) -- 补登账户余额 非主键字段不相等
         OR COALESCE(TM.ECASH_ACCT_FLAG,'') <> COALESCE(BF.ECASH_ACCT_FLAG,'') -- 电子现金账户标志 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.DEBIT_CARD_NO,'') = COALESCE(BF.DEBIT_CARD_NO,'') -- 借记卡编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_DEBIT_CARD_INFO_TF_TM;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_01;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_011;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_012;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_TM_013;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_02;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_03;
DROP TABLE AGL.TMP_AGL_INDV_DEBIT_CARD_INFO_TF_04;
