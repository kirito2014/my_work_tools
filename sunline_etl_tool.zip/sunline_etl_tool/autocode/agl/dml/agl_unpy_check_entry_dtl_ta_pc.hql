-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-银联对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_CHECK_ENTRY_DTL_TA
--     表中文名：银联对账明细聚合
--     创建日期：2024-06-14 00:00:00
--     主键字段：CHECK_ENTRY_DT, UNPY_TXN_TM_STAMP, UNPY_TXN_PROC_CD, MSG_TYPE_CD, AGEN_TXN_UNPY_ORG_NO, SEND_MSG_UNPY_ORG_NO, SYS_TRACK_NO, UNPY_DOC_TYPE_CD
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：清算综合服务平台的银联与账务交易系统对账结果数据
--     更新记录：
--         2024-06-14 00:00:00 wangmujun new
--         2024-08-22 00:00:00 王穆军 修改最新版本
--         2024-09-03 00:00:00 王穆军 修改字段名称
--         2024-09-13 00:00:00 王穆军 修改主键逻辑
--         2024-11-10 00:00:00 魏丹丹 修改代理交易银联机构编号，发送报文银联机构编号,原始交易时间戳,服务点输入方式代码,清算日期取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM
USING ORC
COMMENT '银联对账明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CHECK_ENTRY_DT -- 对账日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,AGEN_ORG_NAME -- 代理机构名称
    ,SEND_ORG_NAME -- 发送机构名称
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RECV_ORG_NAME -- 接收机构名称
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_COMM_FEE -- 分期付款手续费
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,ECI_FLAG -- ECI标志
    ,FRONT_SER_NO -- 前置流水号
    ,CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM(
     CHECK_ENTRY_DT -- 对账日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,AGEN_ORG_NAME -- 代理机构名称
    ,SEND_ORG_NAME -- 发送机构名称
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RECV_ORG_NAME -- 接收机构名称
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_COMM_FEE -- 分期付款手续费
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,ECI_FLAG -- ECI标志
    ,FRONT_SER_NO -- 前置流水号
    ,CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(T1.UNION_SETTLE_DT) AS CHECK_ENTRY_DT -- 对账日期
    ,unifiedTime(T1.UNION_TRANS_DT_TM) AS UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,T1.TRANS_TP_CD AS UNPY_TXN_PROC_CD -- 银联交易处理码
    ,T1.MSG_TP AS MSG_TYPE_CD -- 报文类型代码
    ,SUBSTR(T1.ACQ_INS_ID_CD,4,11) AS AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SUBSTR(T1.FWD_INS_ID_CD,4,11) AS SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,T1.SYS_TRA_NUMBER AS SYS_TRACK_NO -- 系统跟踪号
    ,T1.UNION_FILE_TP AS UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,unifiedTime1(SUBSTR(T1.UNION_SETTLE_DT,1,4)||T1.ORIG_TRANS_DT_TM) AS ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,T1.PRI_ACCOUNT_NUMBER AS TXN_CARD_NO -- 交易卡片编号
    ,T1.TRANS_CARD_NO_BELONG_ORG AS BELONG_ORG_NO -- 归属机构编号
    ,'C'||T1.TRANS_TYPE AS UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,T1.TRANS_CODE AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN T1.SETTLE_CURRENCY='156' THEN 'CNY'
     WHEN T1.SETTLE_CURRENCY='840' THEN 'USD'
     ELSE T1.SETTLE_CURRENCY
END AS TXN_CURR_CD -- 交易币种代码
    ,T1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,T1.ANALYZE_CHANNEL AS TXN_CHNL_CD -- 交易渠道代码
    ,T1.TERM_ID AS EQUIP_NO -- 设备编号
    ,T1.MCHNT_TP AS MERCHT_MCC_CD -- 商户MCC代码
    ,T1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,T1.MCHNT_NAME_ADRESS AS MERCHT_NAME -- 商户名称
    ,T1.ORDER_ID AS ORDER_SER_NO -- 订单流水号
    ,t2.PARA_NM_CN AS AGEN_ORG_NAME -- 代理机构名称
    ,t3.PARA_NM_CN AS SEND_ORG_NAME -- 发送机构名称
    ,T1.RCV_INS_ID_CD AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,T4.TRANS_ORG_NAME AS RECV_ORG_NAME -- 接收机构名称
    ,T1.ISS_INS_ID_CD AS CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,T5.TRANS_ORG_NAME AS CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,T1.ORIG_SYS_TRA_NUMBER AS ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,T1.RETR_REF_NO AS RETRIV_REF_NO -- 检索参考号
    ,T1.POS_COND_CD AS SERV_POINT_COND_CD -- 服务点条件代码
    ,T1.TFR_OUT_ORG_ID AS TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,T1.TFR_OUT_ORG_NO AS TRNOUT_ORG_NO -- 转出机构编号
    ,T1.TFR_OUT_CARD_NUMBER AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,T1.TFR_IN_ORG_ID AS TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,T1.TFR_IN_ORG_NO AS TRNIN_ORG_NO -- 转入机构编号
    ,T1.TFR_IN_CARD_NUMBER AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,T1.AUTH_RESP_CD AS AUTH_ANSWER_CD -- 授权应答码
    ,SUBSTR(T1.SERV_INPUT_WAY,1,2) AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,T1.TERM_TP AS TERMN_TYPE_CD -- 终端类型代码
    ,T1.TRANS_AREA_ID AS TXN_RGN_CD -- 交易地区代码
    ,unifiedTime1(SUBSTR(T1.UNION_SETTLE_DT,1,4)||T1.SETTLE_DT) AS CLEAR_DT -- 清算日期
    ,T1.SETTLE_PERIOD AS CLEAR_PERIOD_DESC -- 清算周期描述
    ,T1.SETTLE_AMOUNT AS CLEAR_AMT -- 清算金额
    ,T1.SETTLE_CURRENCY AS CLEAR_CURR_CD -- 清算币种代码
    ,T1.SETTLE_EXCH_RATE AS CLEAR_EXCH_RATE -- 清算汇率
    ,T1.CARD_HOLDER_TRANS_COMMISSION AS CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,T1.ACQ_REC_COMMISSION AS RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,T1.ACQ_PAY_COMMISSION AS RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,T1.TRANS_SERV_CHARGE_AMOUNT AS TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,T1.MCHNT_COMMISSION AS COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,T1.INNER_COMMISSION AS IN_BANK_COMM_FEE -- 行内手续费
    ,T1.INSTALLMENT_SERVICE_CHARGE AS INSTALMT_COMM_FEE -- 分期付款手续费
    ,T1.FILE_SOURCE AS DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,T1.ACCOUNT_TYPE AS CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,T1.ACCOUNT_RESULT AS UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,T1.ECI AS ECI_FLAG -- ECI标志
    ,T1.PREP_TRA_NUMBER AS FRONT_SER_NO -- 前置流水号
    ,'1' AS CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,T1.ACCEPT_ORG_NO AS CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_UNIONTOAS400_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ods_ccpt${version_num}.ODS_CCPT_SW_ACCOUNT_UNIONTOAS400_UNION_QUERY_TA AS T1 -- 银联核心对账银联方数据流水表（查询表）

LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_UP_UNION_PARAMETER_TF AS t2 -- 银联差错直连-银联参数表
       ON t1.ACQ_INS_ID_CD = t2.PARA_CODE
and t2.pt_dt = '${process_date}'
and t2.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_UP_UNION_PARAMETER_TF AS t3 -- 银联差错直连-银联参数表
       ON t1.FWD_INS_ID_CD= t3.PARA_CODE
and t3.pt_dt = '${process_date}'
and t3.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T4 -- 银联交易机构代码表
       ON T1.RCV_INS_ID_CD = T4.TRANS_ORG_NO
and t4.pt_dt = '${process_date}'
and t4.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T5 -- 银联交易机构代码表
       ON T1.ISS_INS_ID_CD = T5.TRANS_ORG_NO
and t5.pt_dt = '${process_date}'
and t5.del_f = '0' 
WHERE t1.pt_dt = '${process_date}' and t1.del_f = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- None

INSERT INTO TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM(
     CHECK_ENTRY_DT -- 对账日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,AGEN_ORG_NAME -- 代理机构名称
    ,SEND_ORG_NAME -- 发送机构名称
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RECV_ORG_NAME -- 接收机构名称
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_COMM_FEE -- 分期付款手续费
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,ECI_FLAG -- ECI标志
    ,FRONT_SER_NO -- 前置流水号
    ,CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(T1.UNION_SETTLE_DT) AS CHECK_ENTRY_DT -- 对账日期
    ,unifiedTime(T1.UNION_TRANS_DT_TM) AS UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,T1.TRANS_TP_CD AS UNPY_TXN_PROC_CD -- 银联交易处理码
    ,T1.MSG_TP AS MSG_TYPE_CD -- 报文类型代码
    ,SUBSTR(T1.ACQ_INS_ID_CD,4,11) AS AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SUBSTR(T1.FWD_INS_ID_CD,4,11) AS SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,T1.SYS_TRA_NUMBER AS SYS_TRACK_NO -- 系统跟踪号
    ,T1.UNION_FILE_TP AS UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,unifiedTime1(SUBSTR(T1.UNION_SETTLE_DT,1,4)||T1.ORIG_TRANS_DT_TM) AS ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,T1.PRI_ACCOUNT_NUMBER AS TXN_CARD_NO -- 交易卡片编号
    ,T1.TRANS_CARD_NO_BELONG_ORG AS BELONG_ORG_NO -- 归属机构编号
    ,'C'||T1.TRANS_TYPE AS UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,T1.TRANS_CODE AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN T1.TRANS_CURRENCY='156' THEN 'CNY'
     WHEN T1.TRANS_CURRENCY='840' THEN 'USD'
     ELSE T1.TRANS_CURRENCY
END AS TXN_CURR_CD -- 交易币种代码
    ,T1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,T1.ANALYZE_CHANNEL AS TXN_CHNL_CD -- 交易渠道代码
    ,T1.TERM_ID AS EQUIP_NO -- 设备编号
    ,T1.MCHNT_TP AS MERCHT_MCC_CD -- 商户MCC代码
    ,T1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,T1.MCHNT_NAME_ADRESS AS MERCHT_NAME -- 商户名称
    ,T1.ORDER_ID AS ORDER_SER_NO -- 订单流水号
    ,T2.PARA_NM_CN AS AGEN_ORG_NAME -- 代理机构名称
    ,T3.PARA_NM_CN AS SEND_ORG_NAME -- 发送机构名称
    ,T1.RCV_INS_ID_CD AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,T4.TRANS_ORG_NAME AS RECV_ORG_NAME -- 接收机构名称
    ,T1.ISS_INS_ID_CD AS CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,T5.TRANS_ORG_NAME AS CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,T1.ORIG_SYS_TRA_NUMBER AS ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,T1.RETR_REF_NO AS RETRIV_REF_NO -- 检索参考号
    ,T1.POS_COND_CD AS SERV_POINT_COND_CD -- 服务点条件代码
    ,T1.TFR_OUT_ORG_ID AS TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,T1.TFR_OUT_ORG_NO AS TRNOUT_ORG_NO -- 转出机构编号
    ,T1.TFR_OUT_CARD_NUMBER AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,T1.TFR_IN_ORG_ID AS TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,T1.TFR_IN_ORG_NO AS TRNIN_ORG_NO -- 转入机构编号
    ,T1.TFR_IN_CARD_NUMBER AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,T1.AUTH_RESP_CD AS AUTH_ANSWER_CD -- 授权应答码
    ,SUBSTR(T1.SERV_INPUT_WAY,1,2) AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,T1.TERM_TP AS TERMN_TYPE_CD -- 终端类型代码
    ,T1.TRANS_AREA_ID AS TXN_RGN_CD -- 交易地区代码
    ,unifiedTime1(SUBSTR(T1.UNION_SETTLE_DT,1,4)||T1.SETTLE_DT) AS CLEAR_DT -- 清算日期
    ,T1.SETTLE_PERIOD AS CLEAR_PERIOD_DESC -- 清算周期描述
    ,T1.SETTLE_AMOUNT AS CLEAR_AMT -- 清算金额
    ,T1.SETTLE_CURRENCY AS CLEAR_CURR_CD -- 清算币种代码
    ,T1.SETTLE_EXCH_RATE AS CLEAR_EXCH_RATE -- 清算汇率
    ,T1.CARD_HOLDER_TRANS_COMMISSION AS CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,T1.ACQ_REC_COMMISSION AS RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,T1.ACQ_PAY_COMMISSION AS RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,T1.TRANS_SERV_CHARGE_AMOUNT AS TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,T1.MCHNT_COMMISSION AS COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,T1.INNER_COMMISSION AS IN_BANK_COMM_FEE -- 行内手续费
    ,T1.INSTALLMENT_SERVICE_CHARGE AS INSTALMT_COMM_FEE -- 分期付款手续费
    ,T1.FILE_SOURCE AS DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,T1.ACCOUNT_TYPE AS CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,T1.ACCOUNT_RESULT AS UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,T1.ECI AS ECI_FLAG -- ECI标志
    ,T1.PREP_TRA_NUMBER AS FRONT_SER_NO -- 前置流水号
    ,'2' AS CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,T1.ACCEPT_ORG_NO AS CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_UNIONNETWORK_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT${version_num}.ODS_CCPT_SW_ACCOUNT_UNIONNETWORK_UNION_QUERY_TA AS T1 -- 银联网络核心对账银联方数据查询表

LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_UP_UNION_PARAMETER_TF AS t2 -- 银联差错直连-银联参数表
       ON t1.ACQ_INS_ID_CD = t2.PARA_CODE
and t2.pt_dt = '${process_date}'
and t2.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_UP_UNION_PARAMETER_TF AS t3 -- 银联差错直连-银联参数表
       ON t1.FWD_INS_ID_CD= t3.PARA_CODE
and t3.pt_dt = '${process_date}'
and t3.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T4 -- 银联交易机构代码表
       ON T1.RCV_INS_ID_CD = T4.TRANS_ORG_NO
and t4.pt_dt = '${process_date}'
and t4.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T5 -- 银联交易机构代码表
       ON T1.ISS_INS_ID_CD = T5.TRANS_ORG_NO
and t5.pt_dt = '${process_date}'
and t5.del_f = '0' 
WHERE t1.pt_dt = '${process_date}' and t1.del_f = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- None

INSERT INTO TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM(
     CHECK_ENTRY_DT -- 对账日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,AGEN_ORG_NAME -- 代理机构名称
    ,SEND_ORG_NAME -- 发送机构名称
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RECV_ORG_NAME -- 接收机构名称
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_COMM_FEE -- 分期付款手续费
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,ECI_FLAG -- ECI标志
    ,FRONT_SER_NO -- 前置流水号
    ,CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(T1.UNION_SETTLE_DT) AS CHECK_ENTRY_DT -- 对账日期
    ,unifiedTime(T1.UNION_TRANS_DT_TM) AS UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,T1.TRANS_TP_CD AS UNPY_TXN_PROC_CD -- 银联交易处理码
    ,T1.MSG_TP AS MSG_TYPE_CD -- 报文类型代码
    ,T1.ACQ_INS_ID_CD AS AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,T1.FWD_INS_ID_CD AS SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,T1.SYS_TRA_NUMBER AS SYS_TRACK_NO -- 系统跟踪号
    ,T1.UNION_FILE_TP AS UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,unifiedTime1(SUBSTR(T1.UNION_SETTLE_DT,1,4)||T1.ORIG_TRANS_DT_TM) AS ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,T1.PRI_ACCOUNT_NUMBER AS TXN_CARD_NO -- 交易卡片编号
    ,'' AS BELONG_ORG_NO -- 归属机构编号
    ,'' AS UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,T1.TRANS_CODE AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN T1.TRANS_CURRENCY='156' THEN 'CNY'
     WHEN T1.TRANS_CURRENCY='840' THEN 'USD'
     ELSE T1.TRANS_CURRENCY
END AS TXN_CURR_CD -- 交易币种代码
    ,T1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,T1.TERM_ID AS EQUIP_NO -- 设备编号
    ,T1.MCHNT_TP AS MERCHT_MCC_CD -- 商户MCC代码
    ,T1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,T2.PARA_NM_CN AS AGEN_ORG_NAME -- 代理机构名称
    ,T3.PARA_NM_CN AS SEND_ORG_NAME -- 发送机构名称
    ,T1.RCV_INS_ID_CD AS RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,T4.TRANS_ORG_NAME AS RECV_ORG_NAME -- 接收机构名称
    ,T1.ISS_INS_ID_CD AS CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,T5.TRANS_ORG_NAME AS CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,T1.ORIG_SYS_TRA_NUMBER AS ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,T1.RETR_REF_NO AS RETRIV_REF_NO -- 检索参考号
    ,T1.POS_COND_CD AS SERV_POINT_COND_CD -- 服务点条件代码
    ,T1.TFR_OUT_ORG_ID AS TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,'' AS TRNOUT_ORG_NO -- 转出机构编号
    ,T1.TFR_OUT_CARD_NUMBER AS TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,T1.TFR_IN_ORG_ID AS TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,'' AS TRNIN_ORG_NO -- 转入机构编号
    ,T1.TFR_IN_CARD_NUMBER AS TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,T1.AUTH_RESP_CD AS AUTH_ANSWER_CD -- 授权应答码
    ,SUBSTR(T1.SERV_INPUT_WAY,1,2) AS SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,T1.TERM_TP AS TERMN_TYPE_CD -- 终端类型代码
    ,T1.TRANS_AREA_ID AS TXN_RGN_CD -- 交易地区代码
    ,NULL AS CLEAR_DT -- 清算日期
    ,'' AS CLEAR_PERIOD_DESC -- 清算周期描述
    ,NULL AS CLEAR_AMT -- 清算金额
    ,T1.TRANS_CURRENCY AS CLEAR_CURR_CD -- 清算币种代码
    ,NULL AS CLEAR_EXCH_RATE -- 清算汇率
    ,T1.CARD_HOLDER_TRANS_COMMISSION AS CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,T1.ACQ_REC_COMMISSION AS RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,T1.ACQ_PAY_COMMISSION AS RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,T1.TRANS_SERV_CHARGE_AMOUNT AS TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,NULL AS COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,NULL AS IN_BANK_COMM_FEE -- 行内手续费
    ,T1.INSTALLMENT_SERVICE_CHARGE AS INSTALMT_COMM_FEE -- 分期付款手续费
    ,T1.FILE_SOURCE AS DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,'' AS CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,'' AS UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,T1.ECI AS ECI_FLAG -- ECI标志
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,'3' AS CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,'' AS CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_UNIONCREDIT_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT${version_num}.ODS_CCPT_SW_ACCOUNT_UNIONCREDIT_UNION_QUERY_TA AS t1 -- 银联贷记卡对账银联方数据查询表

LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_UP_UNION_PARAMETER_TF AS t2 -- 银联差错直连-银联参数表
       ON t1.ACQ_INS_ID_CD = t2.PARA_CODE
and t2.pt_dt = '${process_date}'
and t2.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_UP_UNION_PARAMETER_TF AS t3 -- 银联差错直连-银联参数表
       ON t1.FWD_INS_ID_CD= t3.PARA_CODE
and t3.pt_dt = '${process_date}'
and t3.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T4 -- 银联交易机构代码表
       ON T1.RCV_INS_ID_CD = T4.TRANS_ORG_NO
and t4.pt_dt = '${process_date}'
and t4.del_f = '0' 
LEFT JOIN ODS_CCPT${version_num}.ODS_CCPT_JC_TRANS_ORG_STATUS_TF AS T5 -- 银联交易机构代码表
       ON T1.ISS_INS_ID_CD = T5.TRANS_ORG_NO
and t5.pt_dt = '${process_date}'
and t5.del_f = '0' 
WHERE t1.pt_dt = '${process_date}'  and t1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     CHECK_ENTRY_DT -- 对账日期
    ,UNPY_TXN_TM_STAMP -- 银联交易时间戳
    ,UNPY_TXN_PROC_CD -- 银联交易处理码
    ,MSG_TYPE_CD -- 报文类型代码
    ,AGEN_TXN_UNPY_ORG_NO -- 代理交易银联机构编号
    ,SEND_MSG_UNPY_ORG_NO -- 发送报文银联机构编号
    ,SYS_TRACK_NO -- 系统跟踪号
    ,UNPY_DOC_TYPE_CD -- 银联文件类型代码
    ,ORIG_TXN_TM_STAMP -- 原始交易时间戳
    ,TXN_CARD_NO -- 交易卡片编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,UNPY_CENT_TXN_TYPE_CD -- 银联对账交易类型代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_CHNL_CD -- 交易渠道代码
    ,EQUIP_NO -- 设备编号
    ,MERCHT_MCC_CD -- 商户MCC代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,ORDER_SER_NO -- 订单流水号
    ,AGEN_ORG_NAME -- 代理机构名称
    ,SEND_ORG_NAME -- 发送机构名称
    ,RECV_TXN_UNPY_ORG_NO -- 接收交易银联机构编号
    ,RECV_ORG_NAME -- 接收机构名称
    ,CARD_ISSUE_UNPY_ORG_NO -- 发卡银联机构编号
    ,CARD_ISSUE_ORG_NAME -- 发卡机构名称
    ,ORIG_TXSYS_TRACK_NO -- 原始交易系统跟踪号
    ,RETRIV_REF_NO -- 检索参考号
    ,SERV_POINT_COND_CD -- 服务点条件代码
    ,TRNOUT_UNPY_ORG_NO -- 转出银联机构编号
    ,TRNOUT_ORG_NO -- 转出机构编号
    ,TRNOUT_CARD_CARD_NO -- 转出卡卡号
    ,TRNIN_UNPY_ORG_NO -- 转入银联机构编号
    ,TRNIN_ORG_NO -- 转入机构编号
    ,TRNIN_CARD_CARD_NO -- 转入卡卡号
    ,AUTH_ANSWER_CD -- 授权应答码
    ,SERV_POINT_INPUT_MODE_CD -- 服务点输入方式代码
    ,TERMN_TYPE_CD -- 终端类型代码
    ,TXN_RGN_CD -- 交易地区代码
    ,CLEAR_DT -- 清算日期
    ,CLEAR_PERIOD_DESC -- 清算周期描述
    ,CLEAR_AMT -- 清算金额
    ,CLEAR_CURR_CD -- 清算币种代码
    ,CLEAR_EXCH_RATE -- 清算汇率
    ,CARD_HOLDER_TXN_COMM_FEE -- 持卡人交易手续费
    ,RECV_PTY_RECVBL_COMM_FEE -- 受理方应收手续费
    ,RECV_PTY_PAYBL_COMM_FEE -- 受理方应付手续费
    ,TRAN_SERV_FEE_AMT -- 转接服务费金额
    ,COL_MERCHT_FIX_COMM_FEE -- 收取商户固定手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,INSTALMT_COMM_FEE -- 分期付款手续费
    ,DOC_SRC_PATH_DESC -- 文件来源路径描述
    ,CHECK_ENTRY_OBJ_DESC -- 对账对象描述
    ,UNPY_CHECK_ENTRY_RESLT_CD -- 银联对账结果代码
    ,ECI_FLAG -- ECI标志
    ,FRONT_SER_NO -- 前置流水号
    ,CHECK_ENTRY_ACCT_TYPE_CD -- 对账账户类型代码
    ,CORE_ACPTD_ORG_NO -- 核心受理机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_UNPY_CHECK_ENTRY_DTL_TA_TM;
