-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-校园云用户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CAMPUS_CLD_USER_INFO_TF
--     表中文名：校园云用户信息聚合
--     创建日期：None
--     主键字段：CUST_NO, USER_ID
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：None
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-10-16 00:00:00 WDD 数据重复修复
--         2024-10-29 00:00:00 WDD 修改主表，增加主键



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF_TM
USING ORC
COMMENT '校园云用户信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CUST_NO -- 客户号
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_TYPE_CD -- 客户类型代码
    ,CUST_LVL_CD -- 客户级别代码
    ,DOCTYP_CD -- 证件类型代码
    ,SCH_NO -- 学校编号
    ,SCH_NAME -- 学校名称
    ,CAMPUS_TYPE_CD -- 校园类型代码
    ,CAMPUS_BELONG_ORG_NO -- 校园归属机构编号
    ,ORG_BELONG_RGN_CD -- 机构归属地区代码
    ,GENDER_CD -- 性别代码
    ,BIRTH_DT -- 出生日期
    ,MOBILE_NO -- 手机号码
    ,LANDLINE_NO -- 座机号码
    ,RESIDENTIAL_ADDR -- 住宅地址
    ,COMMUNIC_ADDR -- 通讯地址
    ,POST_CD -- 邮政编码
    ,EMAIL_ADDR -- 电子邮箱地址
    ,CUST_INFO_CREATE_TM_STAMP -- 客户信息创建时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 校园云用户信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF_TM(
     CUST_NO -- 客户号
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_TYPE_CD -- 客户类型代码
    ,CUST_LVL_CD -- 客户级别代码
    ,DOCTYP_CD -- 证件类型代码
    ,SCH_NO -- 学校编号
    ,SCH_NAME -- 学校名称
    ,CAMPUS_TYPE_CD -- 校园类型代码
    ,CAMPUS_BELONG_ORG_NO -- 校园归属机构编号
    ,ORG_BELONG_RGN_CD -- 机构归属地区代码
    ,GENDER_CD -- 性别代码
    ,BIRTH_DT -- 出生日期
    ,MOBILE_NO -- 手机号码
    ,LANDLINE_NO -- 座机号码
    ,RESIDENTIAL_ADDR -- 住宅地址
    ,COMMUNIC_ADDR -- 通讯地址
    ,POST_CD -- 邮政编码
    ,EMAIL_ADDR -- 电子邮箱地址
    ,CUST_INFO_CREATE_TM_STAMP -- 客户信息创建时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户号
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P2.CUST_NAME AS CUST_NAME -- 客户名称
    ,P2.CUST_TYPE AS CUST_TYPE_CD -- 客户类型代码
    ,P2.CUST_LEVEL AS CUST_LVL_CD -- 客户级别代码
    ,P2.CDS_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P2.SITE_ID AS SCH_NO -- 学校编号
    ,P4.SITE_NAME AS SCH_NAME -- 学校名称
    ,P4.SITE_TYPE AS CAMPUS_TYPE_CD -- 校园类型代码
    ,P4.SITE_INST AS CAMPUS_BELONG_ORG_NO -- 校园归属机构编号
    ,P4.SITE_AREA AS ORG_BELONG_RGN_CD -- 机构归属地区代码
    ,P2.CUST_SEX AS GENDER_CD -- 性别代码
    ,unifiedTime(P2.BIRTH_DATE) AS BIRTH_DT -- 出生日期
    ,P2.MLE_TEL_NO AS MOBILE_NO -- 手机号码
    ,P2.TELE_NO AS LANDLINE_NO -- 座机号码
    ,P2.HOME_ADDR AS RESIDENTIAL_ADDR -- 住宅地址
    ,P2.POST_ADDR AS COMMUNIC_ADDR -- 通讯地址
    ,P2.ZIP_CODE AS POST_CD -- 邮政编码
    ,P2.EML_ADDR AS EMAIL_ADDR -- 电子邮箱地址
    ,unifiedTime(P2.CREATE_TIME) AS CUST_INFO_CREATE_TM_STAMP -- 客户信息创建时间戳
    ,unifiedTime(P2.LST_UPD_TIME) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'YYKT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_YYKT_TBL_CUST_BASE_INFO_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT
     USER_ID
    ,CUST_NO
  FROM ODS_YYKT${version_num}.ODS_YYKT_TBL_MOBILE_USER_MAP_TF
  WHERE PT_DT='${process_date}' AND DEL_F='0'
) AS P1 -- 手机用户表

LEFT JOIN ODS_YYKT${version_num}.ODS_YYKT_TBL_CUST_BASE_INFO_TF AS P2 -- 客户信息表
       ON P1.CUST_NO=P2.CUST_NO AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_YYKT${version_num}.ODS_YYKT_TBL_SITE_INFO_TF AS P4 -- 站点明细表
       ON P2.SITE_ID=P4.SITE_ID AND P4.PT_DT='${process_date}' AND P4.DEL_F='0' 
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_NO, BF.CUST_NO) END AS CUST_NO -- 客户号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_TYPE_CD, BF.CUST_TYPE_CD) END AS CUST_TYPE_CD -- 客户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_LVL_CD, BF.CUST_LVL_CD) END AS CUST_LVL_CD -- 客户级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DOCTYP_CD, BF.DOCTYP_CD) END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SCH_NO IS NULL THEN NULL ELSE COALESCE(TM.SCH_NO, BF.SCH_NO) END AS SCH_NO -- 学校编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SCH_NAME IS NULL THEN NULL ELSE COALESCE(TM.SCH_NAME, BF.SCH_NAME) END AS SCH_NAME -- 学校名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CAMPUS_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CAMPUS_TYPE_CD, BF.CAMPUS_TYPE_CD) END AS CAMPUS_TYPE_CD -- 校园类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CAMPUS_BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CAMPUS_BELONG_ORG_NO, BF.CAMPUS_BELONG_ORG_NO) END AS CAMPUS_BELONG_ORG_NO -- 校园归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORG_BELONG_RGN_CD IS NULL THEN NULL ELSE COALESCE(TM.ORG_BELONG_RGN_CD, BF.ORG_BELONG_RGN_CD) END AS ORG_BELONG_RGN_CD -- 机构归属地区代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GENDER_CD IS NULL THEN NULL ELSE COALESCE(TM.GENDER_CD, BF.GENDER_CD) END AS GENDER_CD -- 性别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIRTH_DT IS NULL THEN NULL ELSE COALESCE(TM.BIRTH_DT, BF.BIRTH_DT) END AS BIRTH_DT -- 出生日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MOBILE_NO IS NULL THEN NULL ELSE COALESCE(TM.MOBILE_NO, BF.MOBILE_NO) END AS MOBILE_NO -- 手机号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LANDLINE_NO IS NULL THEN NULL ELSE COALESCE(TM.LANDLINE_NO, BF.LANDLINE_NO) END AS LANDLINE_NO -- 座机号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RESIDENTIAL_ADDR IS NULL THEN NULL ELSE COALESCE(TM.RESIDENTIAL_ADDR, BF.RESIDENTIAL_ADDR) END AS RESIDENTIAL_ADDR -- 住宅地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMMUNIC_ADDR IS NULL THEN NULL ELSE COALESCE(TM.COMMUNIC_ADDR, BF.COMMUNIC_ADDR) END AS COMMUNIC_ADDR -- 通讯地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POST_CD IS NULL THEN NULL ELSE COALESCE(TM.POST_CD, BF.POST_CD) END AS POST_CD -- 邮政编码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EMAIL_ADDR IS NULL THEN NULL ELSE COALESCE(TM.EMAIL_ADDR, BF.EMAIL_ADDR) END AS EMAIL_ADDR -- 电子邮箱地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_INFO_CREATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.CUST_INFO_CREATE_TM_STAMP, BF.CUST_INFO_CREATE_TM_STAMP) END AS CUST_INFO_CREATE_TM_STAMP -- 客户信息创建时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.CUST_LVL_CD,'') = COALESCE(BF.CUST_LVL_CD,'') -- 客户级别代码 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.SCH_NO,'') = COALESCE(BF.SCH_NO,'') -- 学校编号 非主键字段相等
         AND COALESCE(TM.SCH_NAME,'') = COALESCE(BF.SCH_NAME,'') -- 学校名称 非主键字段相等
         AND COALESCE(TM.CAMPUS_TYPE_CD,'') = COALESCE(BF.CAMPUS_TYPE_CD,'') -- 校园类型代码 非主键字段相等
         AND COALESCE(TM.CAMPUS_BELONG_ORG_NO,'') = COALESCE(BF.CAMPUS_BELONG_ORG_NO,'') -- 校园归属机构编号 非主键字段相等
         AND COALESCE(TM.ORG_BELONG_RGN_CD,'') = COALESCE(BF.ORG_BELONG_RGN_CD,'') -- 机构归属地区代码 非主键字段相等
         AND COALESCE(TM.GENDER_CD,'') = COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段相等
         AND COALESCE(TM.BIRTH_DT,'') = COALESCE(BF.BIRTH_DT,'') -- 出生日期 非主键字段相等
         AND COALESCE(TM.MOBILE_NO,'') = COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段相等
         AND COALESCE(TM.LANDLINE_NO,'') = COALESCE(BF.LANDLINE_NO,'') -- 座机号码 非主键字段相等
         AND COALESCE(TM.RESIDENTIAL_ADDR,'') = COALESCE(BF.RESIDENTIAL_ADDR,'') -- 住宅地址 非主键字段相等
         AND COALESCE(TM.COMMUNIC_ADDR,'') = COALESCE(BF.COMMUNIC_ADDR,'') -- 通讯地址 非主键字段相等
         AND COALESCE(TM.POST_CD,'') = COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段相等
         AND COALESCE(TM.EMAIL_ADDR,'') = COALESCE(BF.EMAIL_ADDR,'') -- 电子邮箱地址 非主键字段相等
         AND COALESCE(TM.CUST_INFO_CREATE_TM_STAMP,'') = COALESCE(BF.CUST_INFO_CREATE_TM_STAMP,'') -- 客户信息创建时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_LVL_CD,'') <> COALESCE(BF.CUST_LVL_CD,'') -- 客户级别代码 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.SCH_NO,'') <> COALESCE(BF.SCH_NO,'') -- 学校编号 非主键字段不相等
         OR COALESCE(TM.SCH_NAME,'') <> COALESCE(BF.SCH_NAME,'') -- 学校名称 非主键字段不相等
         OR COALESCE(TM.CAMPUS_TYPE_CD,'') <> COALESCE(BF.CAMPUS_TYPE_CD,'') -- 校园类型代码 非主键字段不相等
         OR COALESCE(TM.CAMPUS_BELONG_ORG_NO,'') <> COALESCE(BF.CAMPUS_BELONG_ORG_NO,'') -- 校园归属机构编号 非主键字段不相等
         OR COALESCE(TM.ORG_BELONG_RGN_CD,'') <> COALESCE(BF.ORG_BELONG_RGN_CD,'') -- 机构归属地区代码 非主键字段不相等
         OR COALESCE(TM.GENDER_CD,'') <> COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段不相等
         OR COALESCE(TM.BIRTH_DT,'') <> COALESCE(BF.BIRTH_DT,'') -- 出生日期 非主键字段不相等
         OR COALESCE(TM.MOBILE_NO,'') <> COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段不相等
         OR COALESCE(TM.LANDLINE_NO,'') <> COALESCE(BF.LANDLINE_NO,'') -- 座机号码 非主键字段不相等
         OR COALESCE(TM.RESIDENTIAL_ADDR,'') <> COALESCE(BF.RESIDENTIAL_ADDR,'') -- 住宅地址 非主键字段不相等
         OR COALESCE(TM.COMMUNIC_ADDR,'') <> COALESCE(BF.COMMUNIC_ADDR,'') -- 通讯地址 非主键字段不相等
         OR COALESCE(TM.POST_CD,'') <> COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段不相等
         OR COALESCE(TM.EMAIL_ADDR,'') <> COALESCE(BF.EMAIL_ADDR,'') -- 电子邮箱地址 非主键字段不相等
         OR COALESCE(TM.CUST_INFO_CREATE_TM_STAMP,'') <> COALESCE(BF.CUST_INFO_CREATE_TM_STAMP,'') -- 客户信息创建时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.CUST_LVL_CD,'') = COALESCE(BF.CUST_LVL_CD,'') -- 客户级别代码 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.SCH_NO,'') = COALESCE(BF.SCH_NO,'') -- 学校编号 非主键字段相等
         AND COALESCE(TM.SCH_NAME,'') = COALESCE(BF.SCH_NAME,'') -- 学校名称 非主键字段相等
         AND COALESCE(TM.CAMPUS_TYPE_CD,'') = COALESCE(BF.CAMPUS_TYPE_CD,'') -- 校园类型代码 非主键字段相等
         AND COALESCE(TM.CAMPUS_BELONG_ORG_NO,'') = COALESCE(BF.CAMPUS_BELONG_ORG_NO,'') -- 校园归属机构编号 非主键字段相等
         AND COALESCE(TM.ORG_BELONG_RGN_CD,'') = COALESCE(BF.ORG_BELONG_RGN_CD,'') -- 机构归属地区代码 非主键字段相等
         AND COALESCE(TM.GENDER_CD,'') = COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段相等
         AND COALESCE(TM.BIRTH_DT,'') = COALESCE(BF.BIRTH_DT,'') -- 出生日期 非主键字段相等
         AND COALESCE(TM.MOBILE_NO,'') = COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段相等
         AND COALESCE(TM.LANDLINE_NO,'') = COALESCE(BF.LANDLINE_NO,'') -- 座机号码 非主键字段相等
         AND COALESCE(TM.RESIDENTIAL_ADDR,'') = COALESCE(BF.RESIDENTIAL_ADDR,'') -- 住宅地址 非主键字段相等
         AND COALESCE(TM.COMMUNIC_ADDR,'') = COALESCE(BF.COMMUNIC_ADDR,'') -- 通讯地址 非主键字段相等
         AND COALESCE(TM.POST_CD,'') = COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段相等
         AND COALESCE(TM.EMAIL_ADDR,'') = COALESCE(BF.EMAIL_ADDR,'') -- 电子邮箱地址 非主键字段相等
         AND COALESCE(TM.CUST_INFO_CREATE_TM_STAMP,'') = COALESCE(BF.CUST_INFO_CREATE_TM_STAMP,'') -- 客户信息创建时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_LVL_CD,'') <> COALESCE(BF.CUST_LVL_CD,'') -- 客户级别代码 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.SCH_NO,'') <> COALESCE(BF.SCH_NO,'') -- 学校编号 非主键字段不相等
         OR COALESCE(TM.SCH_NAME,'') <> COALESCE(BF.SCH_NAME,'') -- 学校名称 非主键字段不相等
         OR COALESCE(TM.CAMPUS_TYPE_CD,'') <> COALESCE(BF.CAMPUS_TYPE_CD,'') -- 校园类型代码 非主键字段不相等
         OR COALESCE(TM.CAMPUS_BELONG_ORG_NO,'') <> COALESCE(BF.CAMPUS_BELONG_ORG_NO,'') -- 校园归属机构编号 非主键字段不相等
         OR COALESCE(TM.ORG_BELONG_RGN_CD,'') <> COALESCE(BF.ORG_BELONG_RGN_CD,'') -- 机构归属地区代码 非主键字段不相等
         OR COALESCE(TM.GENDER_CD,'') <> COALESCE(BF.GENDER_CD,'') -- 性别代码 非主键字段不相等
         OR COALESCE(TM.BIRTH_DT,'') <> COALESCE(BF.BIRTH_DT,'') -- 出生日期 非主键字段不相等
         OR COALESCE(TM.MOBILE_NO,'') <> COALESCE(BF.MOBILE_NO,'') -- 手机号码 非主键字段不相等
         OR COALESCE(TM.LANDLINE_NO,'') <> COALESCE(BF.LANDLINE_NO,'') -- 座机号码 非主键字段不相等
         OR COALESCE(TM.RESIDENTIAL_ADDR,'') <> COALESCE(BF.RESIDENTIAL_ADDR,'') -- 住宅地址 非主键字段不相等
         OR COALESCE(TM.COMMUNIC_ADDR,'') <> COALESCE(BF.COMMUNIC_ADDR,'') -- 通讯地址 非主键字段不相等
         OR COALESCE(TM.POST_CD,'') <> COALESCE(BF.POST_CD,'') -- 邮政编码 非主键字段不相等
         OR COALESCE(TM.EMAIL_ADDR,'') <> COALESCE(BF.EMAIL_ADDR,'') -- 电子邮箱地址 非主键字段不相等
         OR COALESCE(TM.CUST_INFO_CREATE_TM_STAMP,'') <> COALESCE(BF.CUST_INFO_CREATE_TM_STAMP,'') -- 客户信息创建时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.CUST_NO,'') = COALESCE(BF.CUST_NO,'') -- 客户号 主键字段关联
    AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_CAMPUS_CLD_USER_INFO_TF_TM;
