-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-农信银对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA
--     表中文名：农信银对账明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：PLAT_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：原海娜
--     时间粒度：日
--     保留周期：None
--     描述信息：农信银平台与农信银中心和核心进行三方对账
--     更新记录：
--         2024-07-01 00:00:00 原海娜 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA_TM
USING ORC
COMMENT '农信银对账明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_SER_NO -- 平台流水号
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,MSG_IDE_NO -- 报文标识号
    ,REQE_SER_NO -- 请求流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,NXY_BIZ_SCLS_CD -- 农信银业务小类代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_TM_STAMP -- 交易时间戳
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,NXY_TXN_CHECK_ENTRY_STATUS_CD -- 农信银交易对账状态代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,CORE_DAILY_CUT_DT -- 核心日切日期
    ,PASS_CLEAR_DT -- 通道清算日期
    ,LP_ORG_NO -- 法人机构编号
    ,NXY_ERR_DEAL_MODE_CD -- 农信银差错处理方式代码
    ,TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 农信银对账明细聚合

INSERT INTO TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA_TM(
     PLAT_SER_NO -- 平台流水号
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,MSG_IDE_NO -- 报文标识号
    ,REQE_SER_NO -- 请求流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,NXY_BIZ_SCLS_CD -- 农信银业务小类代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_TM_STAMP -- 交易时间戳
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,NXY_TXN_CHECK_ENTRY_STATUS_CD -- 农信银交易对账状态代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,CORE_DAILY_CUT_DT -- 核心日切日期
    ,PASS_CLEAR_DT -- 通道清算日期
    ,LP_ORG_NO -- 法人机构编号
    ,NXY_ERR_DEAL_MODE_CD -- 农信银差错处理方式代码
    ,TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.MSG_ID AS PLAT_SER_NO -- 平台流水号
    ,T1.TUNNEL_ID AS NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,T1.CORE_ID AS NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,T1.RECON_TP AS NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,''--T1.TXN_ID AS MSG_IDE_NO -- 报文标识号
    ,T1.REQ_ID AS REQE_SER_NO -- 请求流水号
    ,T1.ORDER_ID AS TXN_ORDER_NO -- 交易订单编号
    ,''--T1.END_TO_END_NO AS END_TO_END_IDE_NO -- 端到端标识号
    ,T1.RECON_CLASSIFY_ID AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,T1.BATCH_ID AS TXN_BATCH_NO -- 交易批次编号
    ,T1.AMOUNT AS TXN_AMT -- 交易金额
    ,T1.CCY AS TXN_CURR_CD -- 交易币种代码
    ,T1.FEE_AMT AS COMM_FEE_AMT -- 手续费金额
    ,T1.BIZ_TYPE AS NXY_BIZ_SCLS_CD -- 农信银业务小类代码
    ,T1.MSG_TYPE AS RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,T1.MSG_DIRC AS ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,T1.LOAN_TYPE AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,T1.TXN_STATUS AS TXN_STATUS_CD -- 交易状态代码
    ,unifiedTime(T1.TXN_TIME) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.CHANNL_RECON_STATUS AS PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,T1.RECON_STATUS AS NXY_TXN_CHECK_ENTRY_STATUS_CD -- 农信银交易对账状态代码
    ,unifiedTime(T1.PLA_STTL_DATE) AS PLAT_CLEAR_DT -- 平台清算日期
    ,unifiedTime(T1.CORE_STTL_DATE) AS CORE_CLEAR_DT -- 核心清算日期
    ,unifiedTime(T1.CORE_CUT_DATE) AS CORE_DAILY_CUT_DT -- 核心日切日期
    ,unifiedTime(T1.TUNNEL_STTL_DATE) AS PASS_CLEAR_DT -- 通道清算日期
    ,T1.TNT_INST_ID AS LP_ORG_NO -- 法人机构编号
    ,T1.DEAL_METHOD AS NXY_ERR_DEAL_MODE_CD -- 农信银差错处理方式代码
    ,''--unifiedTime(T1.CREATE_TIME) AS TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SPS_SP_BATCH_PLA_RECON_RESULT_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_UCPS.ODS_UCPS_SP_BATCH_PLA_RECON_RESULT_TA AS T1 -- 平台对账结果明细表

WHERE T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_SER_NO -- 平台流水号
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,NXY_CHECK_ENTRY_TYPE_CD -- 农信银对账类型代码
    ,MSG_IDE_NO -- 报文标识号
    ,REQE_SER_NO -- 请求流水号
    ,TXN_ORDER_NO -- 交易订单编号
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,TXN_BATCH_NO -- 交易批次编号
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,COMM_FEE_AMT -- 手续费金额
    ,NXY_BIZ_SCLS_CD -- 农信银业务小类代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_TM_STAMP -- 交易时间戳
    ,PASS_CORE_CHECK_ENTRY_STATUS_CD -- 通道核心对账状态代码
    ,NXY_TXN_CHECK_ENTRY_STATUS_CD -- 农信银交易对账状态代码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,CORE_DAILY_CUT_DT -- 核心日切日期
    ,PASS_CLEAR_DT -- 通道清算日期
    ,LP_ORG_NO -- 法人机构编号
    ,NXY_ERR_DEAL_MODE_CD -- 农信银差错处理方式代码
    ,TXN_CREATE_TM_STAMP -- 交易创建时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_RURAL_CRDT_CHECK_ENTRY_DTL_TA_TM;
