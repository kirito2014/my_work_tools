-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-生活缴费解约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF
--     表中文名：生活缴费解约协议信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：CANCEL_CONT_ISNO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-16 00:00:00 陈艺丹 创建
--         2024-09-03 00:00:00 陈艺丹 新增字段：平台日期、管理机构编号、摘要代码；删除来源表字段和来源系统字段；
--         2024-09-20 00:00:00 陈艺丹 新增字段：生活缴费业务类别代码,字段中间业务种类编号增加字段来源,字段客户内码取数逻辑更改,字段签约账户开户机构编号来源修改，关联条件修改,UNION3主表筛选条件更改
--         2024-10-28 00:00:00 魏丹丹 调整逻辑，优化脚本



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM
USING ORC
COMMENT '生活缴费解约协议信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 生活缴费解约协议信息聚合
DROP TABLE IF EXISTS AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01;

CREATE TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 (
     CUST_ISN STRING COMMENT '客户内码'
    ,ACCT_NO STRING COMMENT '账户编号'
    ,BEL_ORG STRING COMMENT '机构编号'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '生活缴费解约协议信息聚合'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01(
     CUST_ISN -- 客户内码
    ,ACCT_NO -- 账户编号
    ,BEL_ORG -- 机构编号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.CUST_ISN AS CUST_ISN -- 客户内码
    ,P1.ACCT_NO AS ACCT_NO -- 账户编号
    ,P1.BEL_ORG AS BEL_ORG -- 机构编号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
SELECT MAX(CUST_ISN) CUST_ISN,ACCT_NO,MAX(BEL_ORG) BEL_ORG
FROM(
    SELECT  TRIM(AA03CSNO) CUST_ISN, TRIM(AA01AC15) ACCT_NO,TRIM(AA47BRNO) BEL_ORG
    FROM ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF --活期存款主档
    WHERE TRIM(AA15ZHZT) = '1' AND TRIM(RCSTRS1B) <> '9' AND PT_DT = '${process_date}' AND DEL_F='0'
      UNION
    SELECT TRIM(CINOCSNO) CUST_ISN,TRIM(CDNOAC19) ACCT_NO,TRIM(OWONBRNO) BEL_ORG 
    FROM ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF  --借记卡信息主档文件
    WHERE TRIM(CRDSCRDS) IN ('1','5') AND TRIM(RCSTRS1B) <> '9' AND PT_DT = '${process_date}' AND DEL_F='0'
      UNION
    SELECT TRIM(CUSTR_REF) CUST_ISN,TRIM(CARD_NBR) ACCT_NO,TRIM(PRMAG_CODE) BEL_ORG 
    FROM ODS_CCRD${version_num}.ODS_CCRD_CARD_TF --卡片资料表
    WHERE PT_DT = '${process_date}' AND DEL_F='0'
  )WHERE CUST_ISN IS NOT NULL
GROUP BY ACCT_NO
) AS P1 -- None

;
-- ==============聚合层字段映射（第1-1组）==============
-- 生活缴费解约协议信息聚合


-- ==============聚合层字段映射（第3组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'TELE'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT_NO),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT_NO AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,'TELE' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'15' AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,'' AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.TELEACCT_NAME AS CUST_NAME -- 客户名称
    ,NVL(P4.CUST_ISN,P5.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,'' AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P2.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P3.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P4.BEL_ORG,P5.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,'' AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,'' AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'IMBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_TELE_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_SIGN_TELE_HIST_TF AS P1 -- 电信

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P2 -- 借记卡主档
       ON P1.CARD_NO=P2.CDNOAC19 AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P3 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P3.BD01AC22 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P4 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P4.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P5.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'IMBS'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN P2.BUSI_NO = 'SMK' THEN '01'
     WHEN P2.BUSI_NO = 'ELE' THEN '02'
  WHEN P2.BUSI_NO LIKE '%SF%' OR P2.BUSI_NO LIKE '%WT%' OR P2.BUSI_NO LIKE '%YJLH%' THEN '03'
  WHEN P2.BUSI_NO LIKE '%RQ%' OR P2.BUSI_NO LIKE '%MQF%' OR P2.BUSI_NO LIKE '%LWXO%' THEN '04'
  WHEN P2.BUSI_NO LIKE '%TEL%' OR P2.BUSI_NO LIKE '%MOB%' OR P2.BUSI_NO LIKE '%ZJUT%' THEN '05'
  WHEN P2.BUSI_NO LIKE '%HS%' OR P2.BUSI_NO LIKE '%UPAY%' OR P2.BUSI_NO LIKE '%GD%' OR P2.BUSI_NO LIKE '%TV%' THEN '06'
  WHEN P2.BUSI_NO LIKE '%OLA%' THEN '08'
  WHEN P2.BUSI_NO LIKE '%YXT' OR P2.BUSI_NO IN('QZJFT','SCZX','YQDS','LSXXT') THEN '09'
  WHEN P2.BUSI_NO IN('YHLZF','JNZJDS') THEN '10'
     WHEN P2.BUSI_NO = 'ROAD' THEN '11'
  WHEN P2.BUSI_NO IN('ZHTC','CXTC') THEN '12'
  WHEN P2.BUSI_NO IN('YYYKT','TZXYK','LCXYQC','NBFWK','LAQC') THEN '13'
ELSE '14' END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'IMBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OSCIP${version_num}.ODS_OSCIP_T_SIGN_HIST_TF AS P1 -- 公共签约历史表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND (P2.BUSI_NO LIKE '%SF%' 
OR P2.BUSI_NO LIKE '%WT%' 
OR P2.BUSI_NO LIKE 'YJLH' 
OR P2.BUSI_NO LIKE '%RQ%' 
OR P2.BUSI_NO LIKE '%MQF%' 
OR P2.BUSI_NO LIKE 'LWXO' 
OR P2.BUSI_NO LIKE '%TEL%' 
OR P2.BUSI_NO LIKE '%HS' 
OR P2.BUSI_NO LIKE 'UPAY' 
OR P2.BUSI_NO LIKE '%GD%' 
OR P2.BUSI_NO LIKE '%TV%' 
OR P2.BUSI_NO LIKE '%SMK%' 
OR P2.BUSI_NO LIKE 'OLA' 
OR P2.BUSI_NO LIKE '%MOB%' 
OR P2.BUSI_NO LIKE '%UT%' 
OR P2.BUSI_NO IN('LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX')
)AND P2.BUSI_NO NOT IN ('JXDSF','HGHS','LCESFCG','LCESF')
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第5组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'IMBSETC'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN P2.BUSI_NO = 'SMK' THEN '01'
     WHEN P2.BUSI_NO = 'ELE' THEN '02'
  WHEN P2.BUSI_NO LIKE '%SF%' OR P2.BUSI_NO LIKE '%WT%' OR P2.BUSI_NO LIKE '%YJLH%' THEN '03'
  WHEN P2.BUSI_NO LIKE '%RQ%' OR P2.BUSI_NO LIKE '%MQF%' OR P2.BUSI_NO LIKE '%LWXO%' THEN '04'
  WHEN P2.BUSI_NO LIKE '%TEL%' OR P2.BUSI_NO LIKE '%MOB%' OR P2.BUSI_NO LIKE '%ZJUT%' THEN '05'
  WHEN P2.BUSI_NO LIKE '%HS%' OR P2.BUSI_NO LIKE '%UPAY%' OR P2.BUSI_NO LIKE '%GD%' OR P2.BUSI_NO LIKE '%TV%' THEN '06'
  WHEN P2.BUSI_NO LIKE '%OLA%' THEN '08'
  WHEN P2.BUSI_NO LIKE '%YXT' OR P2.BUSI_NO IN('QZJFT','SCZX','YQDS','LSXXT') THEN '09'
  WHEN P2.BUSI_NO IN('YHLZF','JNZJDS') THEN '10'
     WHEN P2.BUSI_NO = 'ROAD' THEN '11'
  WHEN P2.BUSI_NO IN('ZHTC','CXTC') THEN '12'
  WHEN P2.BUSI_NO IN('YYYKT','TZXYK','LCXYQC','NBFWK','LAQC') THEN '13'
ELSE '14' END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'IMBSETC' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_IMBSETC_T_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_IMBSETC${version_num}.ODS_IMBSETC_T_SIGN_HIST_TF AS P1 -- 公共签约历史表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND (P2.BUSI_NO LIKE '%SF%' 
OR P2.BUSI_NO LIKE '%WT%' 
OR P2.BUSI_NO LIKE 'YJLH' 
OR P2.BUSI_NO LIKE '%RQ%' 
OR P2.BUSI_NO LIKE '%MQF%' 
OR P2.BUSI_NO LIKE 'LWXO' 
OR P2.BUSI_NO LIKE '%TEL%' 
OR P2.BUSI_NO LIKE '%HS' 
OR P2.BUSI_NO LIKE 'UPAY' 
OR P2.BUSI_NO LIKE '%GD%' 
OR P2.BUSI_NO LIKE '%TV%' 
OR P2.BUSI_NO LIKE '%SMK%' 
OR P2.BUSI_NO LIKE 'OLA' 
OR P2.BUSI_NO LIKE '%MOB%' 
OR P2.BUSI_NO LIKE '%UT%' 
OR P2.BUSI_NO IN('LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX')
)AND P2.BUSI_NO NOT IN ('JXDSF','HGHS','LCESFCG','LCESF')
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第6组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'MID71'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN P2.BUSI_NO = 'SMK' THEN '01'
     WHEN P2.BUSI_NO = 'ELE' THEN '02'
  WHEN P2.BUSI_NO LIKE '%SF%' OR P2.BUSI_NO LIKE '%WT%' OR P2.BUSI_NO LIKE '%YJLH%' THEN '03'
  WHEN P2.BUSI_NO LIKE '%RQ%' OR P2.BUSI_NO LIKE '%MQF%' OR P2.BUSI_NO LIKE '%LWXO%' THEN '04'
  WHEN P2.BUSI_NO LIKE '%TEL%' OR P2.BUSI_NO LIKE '%MOB%' OR P2.BUSI_NO LIKE '%ZJUT%' THEN '05'
  WHEN P2.BUSI_NO LIKE '%HS%' OR P2.BUSI_NO LIKE '%UPAY%' OR P2.BUSI_NO LIKE '%GD%' OR P2.BUSI_NO LIKE '%TV%' THEN '06'
  WHEN P2.BUSI_NO LIKE '%OLA%' THEN '08'
  WHEN P2.BUSI_NO LIKE '%YXT' OR P2.BUSI_NO IN('QZJFT','SCZX','YQDS','LSXXT') THEN '09'
  WHEN P2.BUSI_NO IN('YHLZF','JNZJDS') THEN '10'
     WHEN P2.BUSI_NO = 'ROAD' THEN '11'
  WHEN P2.BUSI_NO IN('ZHTC','CXTC') THEN '12'
  WHEN P2.BUSI_NO IN('YYYKT','TZXYK','LCXYQC','NBFWK','LAQC') THEN '13'
ELSE '14' END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'MID71' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MID71_T_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MID71${version_num}.ODS_MID71_T_SIGN_HIST_TF AS P1 -- 公共签约历史表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND (P2.BUSI_NO LIKE '%SF%' 
OR P2.BUSI_NO LIKE '%WT%' 
OR P2.BUSI_NO LIKE 'YJLH' 
OR P2.BUSI_NO LIKE '%RQ%' 
OR P2.BUSI_NO LIKE '%MQF%' 
OR P2.BUSI_NO LIKE 'LWXO' 
OR P2.BUSI_NO LIKE '%TEL%' 
OR P2.BUSI_NO LIKE '%HS' 
OR P2.BUSI_NO LIKE 'UPAY' 
OR P2.BUSI_NO LIKE '%GD%' 
OR P2.BUSI_NO LIKE '%TV%' 
OR P2.BUSI_NO LIKE '%SMK%' 
OR P2.BUSI_NO LIKE 'OLA' 
OR P2.BUSI_NO LIKE '%MOB%' 
OR P2.BUSI_NO LIKE '%UT%' 
OR P2.BUSI_NO IN('LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX')
)AND P2.BUSI_NO NOT IN ('JXDSF','HGHS','LCESFCG','LCESF')
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第7组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'OFSBP'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN P2.BUSI_NO = 'SMK' THEN '01'
     WHEN P2.BUSI_NO = 'ELE' THEN '02'
  WHEN P2.BUSI_NO LIKE '%SF%' OR P2.BUSI_NO LIKE '%WT%' OR P2.BUSI_NO LIKE '%YJLH%' THEN '03'
  WHEN P2.BUSI_NO LIKE '%RQ%' OR P2.BUSI_NO LIKE '%MQF%' OR P2.BUSI_NO LIKE '%LWXO%' THEN '04'
  WHEN P2.BUSI_NO LIKE '%TEL%' OR P2.BUSI_NO LIKE '%MOB%' OR P2.BUSI_NO LIKE '%ZJUT%' THEN '05'
  WHEN P2.BUSI_NO LIKE '%HS%' OR P2.BUSI_NO LIKE '%UPAY%' OR P2.BUSI_NO LIKE '%GD%' OR P2.BUSI_NO LIKE '%TV%' THEN '06'
  WHEN P2.BUSI_NO LIKE '%OLA%' THEN '08'
  WHEN P2.BUSI_NO LIKE '%YXT' OR P2.BUSI_NO IN('QZJFT','SCZX','YQDS','LSXXT') THEN '09'
  WHEN P2.BUSI_NO IN('YHLZF','JNZJDS') THEN '10'
     WHEN P2.BUSI_NO = 'ROAD' THEN '11'
  WHEN P2.BUSI_NO IN('ZHTC','CXTC') THEN '12'
  WHEN P2.BUSI_NO IN('YYYKT','TZXYK','LCXYQC','NBFWK','LAQC') THEN '13'
ELSE '14' END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'OFSBP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OFSBP_T_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,7 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OFSBP${version_num}.ODS_OFSBP_T_SIGN_HIST_TF AS P1 -- 公共签约历史表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND (P2.BUSI_NO LIKE '%SF%' 
OR P2.BUSI_NO LIKE '%WT%' 
OR P2.BUSI_NO LIKE 'YJLH' 
OR P2.BUSI_NO LIKE '%RQ%' 
OR P2.BUSI_NO LIKE '%MQF%' 
OR P2.BUSI_NO LIKE 'LWXO' 
OR P2.BUSI_NO LIKE '%TEL%' 
OR P2.BUSI_NO LIKE '%HS' 
OR P2.BUSI_NO LIKE 'UPAY' 
OR P2.BUSI_NO LIKE '%GD%' 
OR P2.BUSI_NO LIKE '%TV%' 
OR P2.BUSI_NO LIKE '%SMK%' 
OR P2.BUSI_NO LIKE 'OLA' 
OR P2.BUSI_NO LIKE '%MOB%' 
OR P2.BUSI_NO LIKE '%UT%' 
OR P2.BUSI_NO IN('LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX')
)AND P2.BUSI_NO NOT IN ('JXDSF','HGHS','LCESFCG','LCESF')
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第8组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'ZJJS'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.ENTR_NO),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,'' AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'14' AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,'' AS CONT_NO_NO -- 联系电话号码
    ,'' AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_ZJJS_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,8 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OSSAS${version_num}.ODS_OSSAS_T_ZJJS_SIGN_HIST_TF AS P1 -- 签约历史表 诊间结算

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND P2.BUSI_NO ='ZJJS'
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第9组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'CXTC'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'12' AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_CXTC_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,9 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_CXTC_SIGN_HIST_TF AS P1 -- 长兴停车场系统签约历史表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND P2.BUSI_NO ='CXTC'
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第10组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'CRRQ'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'04' AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_CRRQ_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,10 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_SIGN_CRRQ_HIST_TF AS P1 -- 城燃燃气解约客户信息表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND P2.BUSI_NO ='CRRQ'
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第11组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'YHLNZC'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'13' AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_YHLNZC_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,11 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_SIGN_YHLNZC_HIST_TF AS P1 -- 公共签约信息历史表 余杭老年助餐

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO AND P2.BUSI_NO ='YHLNZC'
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第12组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'ZHTC'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,'' AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,NULL AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'12' AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,NVL(P5.CUST_ISN,P6.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACCT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,P1.CARD_TYPE AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P3.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P4.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P5.BEL_ORG,P6.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,'' AS SINGLE_LMT -- 单笔限额
    ,'' AS DAILY_ACCUM_LMT -- 日累计限额
    ,'' AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,'' AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,NULL AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,'MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_ZHTC_SIGN_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,12 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_ZHTC_SIGN_HIST_TF AS P1 -- 智慧停车场系统签约历史表

LEFT JOIN ODS_IMBSETC${version_num}.ODS_IMBSETC_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO  AND P2.BUSI_NO ='ZHTC'
AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡主档
       ON P1.CARD_NO=P3.CDNOAC19 AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P4 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P4.BD01AC22 AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P5 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P5.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P6 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P6.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第13组）==============
-- 生活缴费解约协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM(
     CANCEL_CONT_ISNO -- 解约自增序号
    ,AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,PLAT_DT -- 平台日期
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'NIMBS'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.OTH_CONTRACT),12,'0') AS CANCEL_CONT_ISNO -- 解约自增序号
    ,P1.SIGN_CONTRACT AS AGT_NO -- 协议编号
    ,P1.OTH_CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,P1.CENTER_CONTRACT AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,NULL AS PLAT_DT -- 平台日期
    ,unifiedTime(P1.PROT_EFFT_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,unifiedTime(P1.PROT_END_DATE) AS AGT_EXPIR_DT -- 协议失效日期
    ,P1.BUSI_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.BUSI_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P2.PROD_NO AS PROD_NO -- 产品编号
    ,P3.PROD_NAME AS PROD_NAME -- 产品名称
    ,P3.BUSI_KIND_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P4.BUSI_KIND_NAME AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,P4.PARENT_NO AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,P4.MID_NAME AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN P4.BUSI_KIND_NO = 'YWZL0022' THEN '01'
     WHEN P4.BUSI_KIND_NO = 'YWZL0001' THEN '02'
     WHEN P4.BUSI_KIND_NO = 'YWZL0002' THEN '03'
     WHEN P4.BUSI_KIND_NO = 'YWZL0003' THEN '04'
     WHEN P4.BUSI_KIND_NO IN ('YWZL0004','YWZL0005','YWZL0007','YWZL0034','YWZL0036') THEN '05'
     WHEN P4.BUSI_KIND_NO IN ('YWZL0006','YWZL0035') THEN '06'
     WHEN P4.BUSI_KIND_NO IN ('YWZL0017','YWZL0018') THEN '07'
     WHEN P4.BUSI_KIND_NO IN ('YWZL0027','YWZL0041','YWZL0048','YWZL0053')  THEN '09'
     WHEN P4.BUSI_KIND_NO IN ('YWZL0010','YWZL0011') THEN '10'
     WHEN P4.BUSI_KIND_NO = 'YWZL0008'  THEN '12'
     WHEN P4.BUSI_KIND_NO IN ('YWZL0029','YWZL0054') THEN '13'
ELSE '14' END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,P1.BUSI_SUB_TYPE AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,P1.ENTR_IDEN_NO AS PAY_PROJ_NO -- 缴费项目编号
    ,P1.ENTR_IDEN_NAME AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.CUST_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P5.USER_CERT_TP AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,P5.USER_CERT_ID AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,P5.USER_ADD AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,P5.USER_TLP_NO AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,NVL(P8.CUST_ISN,P9.CUST_ISN) AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS USER_ID -- 用户ID
    ,P1.CUST_CERT_TP AS DOCTYP_CD -- 证件类型代码
    ,P1.CUST_CERT_NO AS DOC_NO -- 证件号码
    ,P5.CUST_TLP_NO AS CONT_NO_NO -- 联系电话号码
    ,'' AS CONT_ADDR -- 联系地址
    ,P5.CUST_EMAIL AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,P5.AGENT_NAME AS SIGN_AGENT_NAME -- 签约代理人名称
    ,P5.AGENT_CERT_TP AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,P5.AGENT_CERT_ID AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,P5.AGENT_TLP_NO AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,P1.ACT_TYPE AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,'' AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN  P1.ACCT_NO<>'' AND TRIM(P1.ACCT_NO)IS NOT NULL THEN P1.ACCT_NO
     WHEN  P1.CARD_NO<>'' AND TRIM(P1.CARD_NO)IS NOT NULL THEN P6.DFANAC19
     WHEN  P1.OLD_ACCT_NO<>'' AND TRIM(P1.OLD_ACCT_NO)IS NOT NULL THEN P7.BD02AC15
ELSE '' END AS ACCT_NO -- 账户编号
    ,P1.ACCT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,P1.CARD_TP AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,NVL(P8.BEL_ORG,P9.BEL_ORG) AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,P1.OWNER_BRCH AS MGMT_ORG_NO -- 管理机构编号
    ,P1.LIMIT_AMT AS SINGLE_LMT -- 单笔限额
    ,P1.DAY_LIMIT_AMT AS DAILY_ACCUM_LMT -- 日累计限额
    ,P1.MOTH_LIMIT_AMT AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,P1.YEAR_LIMIT_AMT AS YEAR_CUM_LMT -- 年累计限额
    ,P1.CHNL_NO AS SIGN_CHNL_CD -- 签约渠道代码
    ,SUBSTR(unifiedTime(P1.GMT_CREATE),1,10) AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.GMT_CREATE) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TLR_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,SUBSTR(unifiedTime(P1.GMT_MODIFIED),1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.GMT_MODIFIED) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TLR_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.SIGN_STAT AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,P1.CENTER_STAT AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,'' AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,P1.DISP_MSG AS SIGN_RESLT_DESC -- 签约结果描述
    ,P1.LOCK_STAT AS REC_LOCK_FLAG -- 记录锁定标志
    ,P1.UPDATE_VERSION AS VER_NO -- 版本编号
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'NIMBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NIMBS_SCIP_SIGN_INFO_HIST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,13 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NIMBS${version_num}.ODS_NIMBS_SCIP_SIGN_INFO_HIST_TF AS P1 -- 签约信息表

LEFT JOIN ODS_NIMBS${version_num}.ODS_NIMBS_SPIDER_PLAT_BUSI_TF AS P2 -- 业务单元表
       ON P1.BUSI_NO=P2.BUSI_NO 
AND P2.IF_RECORD_VALID='1' 
AND P2.IF_VALID='1' 
AND P2.PT_DT='${process_date}' 
AND P2.DEL_F = '0' 
LEFT JOIN ODS_NIMBS${version_num}.ODS_NIMBS_SCIP_PRODUCT_BUSI_TF AS P3 -- 业务产品信息表
       ON P2.PROD_NO=P3.PROD_NO 
AND P3.IF_RECORD_VALID='1' 
AND P3.IF_VALID='1' 
AND P3.PT_DT='${process_date}' 
AND P3.DEL_F = '0' 
LEFT JOIN ODS_NIMBS${version_num}.ODS_NIMBS_SCIP_PRODUCT_BUSI_KIND_TF AS P4 -- 业务种类表
       ON P3.BUSI_KIND_NO=P4.BUSI_KIND_NO 
AND P4.IF_RECORD_VALID='1'  
AND P4.PARENT_NO IN ('01','03','05','07') 
AND P4.BUSI_KIND_NO<>'YWZL0023' 
AND P4.IF_VALID='1' 
AND P4.PT_DT='${process_date}' 
AND P4.DEL_F = '0' 
LEFT JOIN (SELECT * FROM(
   SELECT
      USER_CERT_TP
     ,USER_CERT_ID
     ,USER_ADD
     ,USER_TLP_NO
     ,CUST_TLP_NO
     ,CUST_EMAIL
     ,AGENT_NAME
     ,AGENT_CERT_TP
     ,AGENT_CERT_ID
     ,AGENT_TLP_NO
     ,SIGN_CONTRACT
     ,ROW_NUMBER() OVER(PARTITION BY SIGN_CONTRACT ORDER BY ID DESC)RN
   FROM ODS_NIMBS${version_num}.ODS_NIMBS_SCIP_SIGN_CUSTOMER_HIST_TF
   WHERE IF_DELETE='0' AND PT_DT='${process_date}' AND DEL_F = '0'
)T WHERE RN=1) AS P5 -- 签约客户信息表
       ON P1.SIGN_CONTRACT=P5.SIGN_CONTRACT 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P6 -- 借记卡主档
       ON P1.CARD_NO=P6.CDNOAC19 
AND P6.PT_DT='${process_date}' 
AND P6.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQBD_TF AS P7 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P7.BD01AC22 
AND P7.PT_DT='${process_date}' 
AND P7.DEL_F = '0' 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P8 -- None
       ON TRIM(P1.ACCT_NO) = TRIM(P8.ACCT_NO) 
LEFT JOIN AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01 AS P9 -- None
       ON TRIM(P1.CARD_NO) = TRIM(P9.ACCT_NO) 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0' AND P1.IF_DELETE='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANCEL_CONT_ISNO IS NULL THEN NULL ELSE COALESCE(TM.CANCEL_CONT_ISNO, BF.CANCEL_CONT_ISNO) END AS CANCEL_CONT_ISNO -- 解约自增序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.AGT_NO, BF.AGT_NO) END AS AGT_NO -- 协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_AGT_NO, BF.THIRD_PTY_AGT_NO) END AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_CENTER_AGT_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_CENTER_AGT_NO, BF.CONT_CENTER_AGT_NO) END AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PLAT_DT IS NULL THEN NULL ELSE COALESCE(TM.PLAT_DT, BF.PLAT_DT) END AS PLAT_DT -- 平台日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_EFFECT_DT IS NULL THEN NULL ELSE COALESCE(TM.AGT_EFFECT_DT, BF.AGT_EFFECT_DT) END AS AGT_EFFECT_DT -- 协议生效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AGT_EXPIR_DT IS NULL THEN NULL ELSE COALESCE(TM.AGT_EXPIR_DT, BF.AGT_EXPIR_DT) END AS AGT_EXPIR_DT -- 协议失效日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NO IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NO, BF.BIZ_UNIT_NO) END AS BIZ_UNIT_NO -- 业务单元编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIZ_UNIT_NAME IS NULL THEN NULL ELSE COALESCE(TM.BIZ_UNIT_NAME, BF.BIZ_UNIT_NAME) END AS BIZ_UNIT_NAME -- 业务单元名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PROD_NO IS NULL THEN NULL ELSE COALESCE(TM.PROD_NO, BF.PROD_NO) END AS PROD_NO -- 产品编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.PROD_NAME, BF.PROD_NAME) END AS PROD_NAME -- 产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_CATE_NO IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_CATE_NO, BF.MDL_BIZ_CATE_NO) END AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_CATE_NAME IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_CATE_NAME, BF.MDL_BIZ_CATE_NAME) END AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_MDL_CATOGR_NO IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO, BF.MDL_BIZ_MDL_CATOGR_NO) END AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_MDL_CATOGR_NAME IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME, BF.MDL_BIZ_MDL_CATOGR_NAME) END AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_BIZ_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD, BF.LIFE_PAY_BIZ_CATEGORY_CD) END AS LIFE_PAY_BIZ_CATEGORY_CD -- 生活缴费业务类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MDL_BIZ_SUB_CLS_CD IS NULL THEN NULL ELSE COALESCE(TM.MDL_BIZ_SUB_CLS_CD, BF.MDL_BIZ_SUB_CLS_CD) END AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NO, BF.PAY_PROJ_NO) END AS PAY_PROJ_NO -- 缴费项目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NAME, BF.PAY_PROJ_NAME) END AS PAY_PROJ_NAME -- 缴费项目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_NO, BF.THIRD_PTY_USER_NO) END AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD, BF.THIRD_PTY_USER_DOCTYP_CD) END AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_DOC_NO, BF.THIRD_PTY_USER_DOC_NO) END AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_CONT_ADDR IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_CONT_ADDR, BF.THIRD_PTY_USER_CONT_ADDR) END AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.THIRD_PTY_USER_CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO, BF.THIRD_PTY_USER_CONT_NO_NO) END AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.DOCTYP_CD, BF.DOCTYP_CD) END AS DOCTYP_CD -- 证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.DOC_NO, BF.DOC_NO) END AS DOC_NO -- 证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.CONT_NO_NO, BF.CONT_NO_NO) END AS CONT_NO_NO -- 联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_ADDR IS NULL THEN NULL ELSE COALESCE(TM.CONT_ADDR, BF.CONT_ADDR) END AS CONT_ADDR -- 联系地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_EMAIL_ADDR IS NULL THEN NULL ELSE COALESCE(TM.CUST_EMAIL_ADDR, BF.CUST_EMAIL_ADDR) END AS CUST_EMAIL_ADDR -- 客户电子邮箱地址
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_NAME IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_NAME, BF.SIGN_AGENT_NAME) END AS SIGN_AGENT_NAME -- 签约代理人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_DOCTYP_CD, BF.SIGN_AGENT_DOCTYP_CD) END AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_DOC_NO, BF.SIGN_AGENT_DOC_NO) END AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_AGENT_CONT_NO_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_AGENT_CONT_NO_NO, BF.SIGN_AGENT_CONT_NO_NO) END AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_PUB_PRIV_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD, BF.ACCT_PUB_PRIV_TYPE_CD) END AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_DISCNT_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.CARD_DISCNT_IDNT_CD, BF.CARD_DISCNT_IDNT_CD) END AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.CASH_RMT_CD, BF.CASH_RMT_CD) END AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CARD_NO IS NULL THEN NULL ELSE COALESCE(TM.CARD_NO, BF.CARD_NO) END AS CARD_NO -- 卡片编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_MED_TYPE_CD, BF.LIFE_PAY_MED_TYPE_CD) END AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DRAW_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.DRAW_MODE_CD, BF.DRAW_MODE_CD) END AS DRAW_MODE_CD -- 支取方式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ACCT_OPEN_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO, BF.SIGN_ACCT_OPEN_ACCT_ORG_NO) END AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MGMT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.MGMT_ORG_NO, BF.MGMT_ORG_NO) END AS MGMT_ORG_NO -- 管理机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SINGLE_LMT IS NULL THEN NULL ELSE COALESCE(TM.SINGLE_LMT, BF.SINGLE_LMT) END AS SINGLE_LMT -- 单笔限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DAILY_ACCUM_LMT IS NULL THEN NULL ELSE COALESCE(TM.DAILY_ACCUM_LMT, BF.DAILY_ACCUM_LMT) END AS DAILY_ACCUM_LMT -- 日累计限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MONTHLY_ACCUM_LMT IS NULL THEN NULL ELSE COALESCE(TM.MONTHLY_ACCUM_LMT, BF.MONTHLY_ACCUM_LMT) END AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YEAR_CUM_LMT IS NULL THEN NULL ELSE COALESCE(TM.YEAR_CUM_LMT, BF.YEAR_CUM_LMT) END AS YEAR_CUM_LMT -- 年累计限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.SIGN_CHNL_CD, BF.SIGN_CHNL_CD) END AS SIGN_CHNL_CD -- 签约渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_CONTR_DT IS NULL THEN NULL ELSE COALESCE(TM.SIGN_CONTR_DT, BF.SIGN_CONTR_DT) END AS SIGN_CONTR_DT -- 签约日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.SIGN_TM_STAMP, BF.SIGN_TM_STAMP) END AS SIGN_TM_STAMP -- 签约时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_ORG_NO, BF.SIGN_ORG_NO) END AS SIGN_ORG_NO -- 签约机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SIGN_TELR_NO, BF.SIGN_TELR_NO) END AS SIGN_TELR_NO -- 签约柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_TM_STAMP, BF.FINAL_UPDATE_TM_STAMP) END AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_MODIF_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RECNT_MODIF_ORG_NO, BF.RECNT_MODIF_ORG_NO) END AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_AGT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_AGT_STATUS_CD, BF.LIFE_PAY_AGT_STATUS_CD) END AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CONT_CENTER_AGT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.CONT_CENTER_AGT_STATUS_CD, BF.CONT_CENTER_AGT_STATUS_CD) END AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFE_PAY_SIGN_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFE_PAY_SIGN_SYS_CD, BF.LIFE_PAY_SIGN_SYS_CD) END AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SIGN_RESLT_DESC IS NULL THEN NULL ELSE COALESCE(TM.SIGN_RESLT_DESC, BF.SIGN_RESLT_DESC) END AS SIGN_RESLT_DESC -- 签约结果描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_LOCK_FLAG IS NULL THEN NULL ELSE COALESCE(TM.REC_LOCK_FLAG, BF.REC_LOCK_FLAG) END AS REC_LOCK_FLAG -- 记录锁定标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VER_NO IS NULL THEN NULL ELSE COALESCE(TM.VER_NO, BF.VER_NO) END AS VER_NO -- 版本编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_CD IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_CD, BF.SUMMARY_CD) END AS SUMMARY_CD -- 摘要代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.AGT_NO,'') = COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_AGT_NO,'') = COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_NO,'') = COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段相等
         AND COALESCE(TM.PLAT_DT,'') = COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段相等
         AND COALESCE(TM.AGT_EFFECT_DT,'') = COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段相等
         AND COALESCE(TM.AGT_EXPIR_DT,'') = COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NAME,'') = COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段相等
         AND COALESCE(TM.PROD_NO,'') = COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段相等
         AND COALESCE(TM.PROD_NAME,'') = COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NO,'') = COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NAME,'') = COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') = COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') = COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NAME,'') = COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_NO,'') = COALESCE(BF.THIRD_PTY_USER_NO,'') -- 第三方用户编号 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') = COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') = COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') = COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') = COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.CONT_NO_NO,'') = COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段相等
         AND COALESCE(TM.CONT_ADDR,'') = COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段相等
         AND COALESCE(TM.CUST_EMAIL_ADDR,'') = COALESCE(BF.CUST_EMAIL_ADDR,'') -- 客户电子邮箱地址 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_NAME,'') = COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') = COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOC_NO,'') = COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') = COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段相等
         AND COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') = COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段相等
         AND COALESCE(TM.CARD_DISCNT_IDNT_CD,'') = COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CARD_NO,'') = COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') = COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段相等
         AND COALESCE(TM.MGMT_ORG_NO,'') = COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段相等
         AND COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段相等
         AND COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段相等
         AND COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段相等
         AND COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段相等
         AND COALESCE(TM.SIGN_CHNL_CD,'') = COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段相等
         AND COALESCE(TM.SIGN_CONTR_DT,'') = COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段相等
         AND COALESCE(TM.SIGN_TM_STAMP,'') = COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段相等
         AND COALESCE(TM.SIGN_ORG_NO,'') = COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段相等
         AND COALESCE(TM.SIGN_TELR_NO,'') = COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') = COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') = COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') = COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段相等
         AND COALESCE(TM.SIGN_RESLT_DESC,'') = COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段相等
         AND COALESCE(TM.REC_LOCK_FLAG,'') = COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段相等
         AND COALESCE(TM.VER_NO,'') = COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.AGT_NO,'') <> COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_AGT_NO,'') <> COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_NO,'') <> COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段不相等
         OR COALESCE(TM.PLAT_DT,'') <> COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段不相等
         OR COALESCE(TM.AGT_EFFECT_DT,'') <> COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段不相等
         OR COALESCE(TM.AGT_EXPIR_DT,'') <> COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NO,'') <> COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NAME,'') <> COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段不相等
         OR COALESCE(TM.PROD_NO,'') <> COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段不相等
         OR COALESCE(TM.PROD_NAME,'') <> COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NO,'') <> COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NAME,'') <> COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') <> COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') <> COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NAME,'') <> COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_NO,'') <> COALESCE(BF.THIRD_PTY_USER_NO,'') -- 第三方用户编号 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') <> COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') <> COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.CONT_NO_NO,'') <> COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段不相等
         OR COALESCE(TM.CONT_ADDR,'') <> COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段不相等
         OR COALESCE(TM.CUST_EMAIL_ADDR,'') <> COALESCE(BF.CUST_EMAIL_ADDR,'') -- 客户电子邮箱地址 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_NAME,'') <> COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') <> COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOC_NO,'') <> COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') <> COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段不相等
         OR COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') <> COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_DISCNT_IDNT_CD,'') <> COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.CASH_RMT_CD,'') <> COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CARD_NO,'') <> COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') <> COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.MGMT_ORG_NO,'') <> COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段不相等
         OR COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段不相等
         OR COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段不相等
         OR COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段不相等
         OR COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段不相等
         OR COALESCE(TM.SIGN_CHNL_CD,'') <> COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段不相等
         OR COALESCE(TM.SIGN_CONTR_DT,'') <> COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段不相等
         OR COALESCE(TM.SIGN_TM_STAMP,'') <> COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段不相等
         OR COALESCE(TM.SIGN_ORG_NO,'') <> COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段不相等
         OR COALESCE(TM.SIGN_TELR_NO,'') <> COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') <> COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') <> COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') <> COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段不相等
         OR COALESCE(TM.SIGN_RESLT_DESC,'') <> COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段不相等
         OR COALESCE(TM.REC_LOCK_FLAG,'') <> COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段不相等
         OR COALESCE(TM.VER_NO,'') <> COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.AGT_NO,'') = COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_AGT_NO,'') = COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_NO,'') = COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段相等
         AND COALESCE(TM.PLAT_DT,'') = COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段相等
         AND COALESCE(TM.AGT_EFFECT_DT,'') = COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段相等
         AND COALESCE(TM.AGT_EXPIR_DT,'') = COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NO,'') = COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段相等
         AND COALESCE(TM.BIZ_UNIT_NAME,'') = COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段相等
         AND COALESCE(TM.PROD_NO,'') = COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段相等
         AND COALESCE(TM.PROD_NAME,'') = COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NO,'') = COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_CATE_NAME,'') = COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') = COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') = COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段相等
         AND COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') = COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NAME,'') = COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_NO,'') = COALESCE(BF.THIRD_PTY_USER_NO,'') -- 第三方用户编号 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') = COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') = COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') = COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') = COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.DOCTYP_CD,'') = COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段相等
         AND COALESCE(TM.DOC_NO,'') = COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段相等
         AND COALESCE(TM.CONT_NO_NO,'') = COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段相等
         AND COALESCE(TM.CONT_ADDR,'') = COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段相等
         AND COALESCE(TM.CUST_EMAIL_ADDR,'') = COALESCE(BF.CUST_EMAIL_ADDR,'') -- 客户电子邮箱地址 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_NAME,'') = COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') = COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_DOC_NO,'') = COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段相等
         AND COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') = COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段相等
         AND COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') = COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段相等
         AND COALESCE(TM.CARD_DISCNT_IDNT_CD,'') = COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段相等
         AND COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CARD_NO,'') = COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') = COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段相等
         AND COALESCE(TM.DRAW_MODE_CD,'') = COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段相等
         AND COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') = COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段相等
         AND COALESCE(TM.MGMT_ORG_NO,'') = COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段相等
         AND COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段相等
         AND COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段相等
         AND COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段相等
         AND COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段相等
         AND COALESCE(TM.SIGN_CHNL_CD,'') = COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段相等
         AND COALESCE(TM.SIGN_CONTR_DT,'') = COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段相等
         AND COALESCE(TM.SIGN_TM_STAMP,'') = COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段相等
         AND COALESCE(TM.SIGN_ORG_NO,'') = COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段相等
         AND COALESCE(TM.SIGN_TELR_NO,'') = COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') = COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段相等
         AND COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') = COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段相等
         AND COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') = COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段相等
         AND COALESCE(TM.SIGN_RESLT_DESC,'') = COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段相等
         AND COALESCE(TM.REC_LOCK_FLAG,'') = COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段相等
         AND COALESCE(TM.VER_NO,'') = COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.AGT_NO,'') <> COALESCE(BF.AGT_NO,'') -- 协议编号 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_AGT_NO,'') <> COALESCE(BF.THIRD_PTY_AGT_NO,'') -- 第三方协议编号 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_NO,'') <> COALESCE(BF.CONT_CENTER_AGT_NO,'') -- 合约中心协议编号 非主键字段不相等
         OR COALESCE(TM.PLAT_DT,'') <> COALESCE(BF.PLAT_DT,'') -- 平台日期 非主键字段不相等
         OR COALESCE(TM.AGT_EFFECT_DT,'') <> COALESCE(BF.AGT_EFFECT_DT,'') -- 协议生效日期 非主键字段不相等
         OR COALESCE(TM.AGT_EXPIR_DT,'') <> COALESCE(BF.AGT_EXPIR_DT,'') -- 协议失效日期 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NO,'') <> COALESCE(BF.BIZ_UNIT_NO,'') -- 业务单元编号 非主键字段不相等
         OR COALESCE(TM.BIZ_UNIT_NAME,'') <> COALESCE(BF.BIZ_UNIT_NAME,'') -- 业务单元名称 非主键字段不相等
         OR COALESCE(TM.PROD_NO,'') <> COALESCE(BF.PROD_NO,'') -- 产品编号 非主键字段不相等
         OR COALESCE(TM.PROD_NAME,'') <> COALESCE(BF.PROD_NAME,'') -- 产品名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NO,'') <> COALESCE(BF.MDL_BIZ_CATE_NO,'') -- 中间业务种类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_CATE_NAME,'') <> COALESCE(BF.MDL_BIZ_CATE_NAME,'') -- 中间业务种类名称 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NO,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NO,'') -- 中间业务中类编号 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_MDL_CATOGR_NAME,'') <> COALESCE(BF.MDL_BIZ_MDL_CATOGR_NAME,'') -- 中间业务中类名称 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_BIZ_CATEGORY_CD,'') <> COALESCE(BF.LIFE_PAY_BIZ_CATEGORY_CD,'') -- 生活缴费业务类别代码 非主键字段不相等
         OR COALESCE(TM.MDL_BIZ_SUB_CLS_CD,'') <> COALESCE(BF.MDL_BIZ_SUB_CLS_CD,'') -- 中间业务子类代码 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NAME,'') <> COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_NO,'') <> COALESCE(BF.THIRD_PTY_USER_NO,'') -- 第三方用户编号 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOCTYP_CD,'') <> COALESCE(BF.THIRD_PTY_USER_DOCTYP_CD,'') -- 第三方用户证件类型代码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_DOC_NO,'') <> COALESCE(BF.THIRD_PTY_USER_DOC_NO,'') -- 第三方用户证件号码 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_ADDR,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_ADDR,'') -- 第三方用户联系地址 非主键字段不相等
         OR COALESCE(TM.THIRD_PTY_USER_CONT_NO_NO,'') <> COALESCE(BF.THIRD_PTY_USER_CONT_NO_NO,'') -- 第三方用户联系电话号码 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.DOCTYP_CD,'') <> COALESCE(BF.DOCTYP_CD,'') -- 证件类型代码 非主键字段不相等
         OR COALESCE(TM.DOC_NO,'') <> COALESCE(BF.DOC_NO,'') -- 证件号码 非主键字段不相等
         OR COALESCE(TM.CONT_NO_NO,'') <> COALESCE(BF.CONT_NO_NO,'') -- 联系电话号码 非主键字段不相等
         OR COALESCE(TM.CONT_ADDR,'') <> COALESCE(BF.CONT_ADDR,'') -- 联系地址 非主键字段不相等
         OR COALESCE(TM.CUST_EMAIL_ADDR,'') <> COALESCE(BF.CUST_EMAIL_ADDR,'') -- 客户电子邮箱地址 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_NAME,'') <> COALESCE(BF.SIGN_AGENT_NAME,'') -- 签约代理人名称 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOCTYP_CD,'') <> COALESCE(BF.SIGN_AGENT_DOCTYP_CD,'') -- 签约代理人证件类型代码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_DOC_NO,'') <> COALESCE(BF.SIGN_AGENT_DOC_NO,'') -- 签约代理人证件号码 非主键字段不相等
         OR COALESCE(TM.SIGN_AGENT_CONT_NO_NO,'') <> COALESCE(BF.SIGN_AGENT_CONT_NO_NO,'') -- 签约代理人联系电话号码 非主键字段不相等
         OR COALESCE(TM.ACCT_PUB_PRIV_TYPE_CD,'') <> COALESCE(BF.ACCT_PUB_PRIV_TYPE_CD,'') -- 账户公私类型代码 非主键字段不相等
         OR COALESCE(TM.CARD_DISCNT_IDNT_CD,'') <> COALESCE(BF.CARD_DISCNT_IDNT_CD,'') -- 卡折标识代码 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.CASH_RMT_CD,'') <> COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段不相等
         OR COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CARD_NO,'') <> COALESCE(BF.CARD_NO,'') -- 卡片编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_MED_TYPE_CD,'') <> COALESCE(BF.LIFE_PAY_MED_TYPE_CD,'') -- 生活缴费介质类型代码 非主键字段不相等
         OR COALESCE(TM.DRAW_MODE_CD,'') <> COALESCE(BF.DRAW_MODE_CD,'') -- 支取方式代码 非主键字段不相等
         OR COALESCE(TM.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') <> COALESCE(BF.SIGN_ACCT_OPEN_ACCT_ORG_NO,'') -- 签约账户开户机构编号 非主键字段不相等
         OR COALESCE(TM.MGMT_ORG_NO,'') <> COALESCE(BF.MGMT_ORG_NO,'') -- 管理机构编号 非主键字段不相等
         OR COALESCE(TM.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.SINGLE_LMT,CAST(0 AS DECIMAL(28,2))) -- 单笔限额 非主键字段不相等
         OR COALESCE(TM.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.DAILY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 日累计限额 非主键字段不相等
         OR COALESCE(TM.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.MONTHLY_ACCUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 月累计限额 非主键字段不相等
         OR COALESCE(TM.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YEAR_CUM_LMT,CAST(0 AS DECIMAL(28,2))) -- 年累计限额 非主键字段不相等
         OR COALESCE(TM.SIGN_CHNL_CD,'') <> COALESCE(BF.SIGN_CHNL_CD,'') -- 签约渠道代码 非主键字段不相等
         OR COALESCE(TM.SIGN_CONTR_DT,'') <> COALESCE(BF.SIGN_CONTR_DT,'') -- 签约日期 非主键字段不相等
         OR COALESCE(TM.SIGN_TM_STAMP,'') <> COALESCE(BF.SIGN_TM_STAMP,'') -- 签约时间戳 非主键字段不相等
         OR COALESCE(TM.SIGN_ORG_NO,'') <> COALESCE(BF.SIGN_ORG_NO,'') -- 签约机构编号 非主键字段不相等
         OR COALESCE(TM.SIGN_TELR_NO,'') <> COALESCE(BF.SIGN_TELR_NO,'') -- 签约柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_AGT_STATUS_CD,'') <> COALESCE(BF.LIFE_PAY_AGT_STATUS_CD,'') -- 生活缴费协议状态代码 非主键字段不相等
         OR COALESCE(TM.CONT_CENTER_AGT_STATUS_CD,'') <> COALESCE(BF.CONT_CENTER_AGT_STATUS_CD,'') -- 合约中心协议状态代码 非主键字段不相等
         OR COALESCE(TM.LIFE_PAY_SIGN_SYS_CD,'') <> COALESCE(BF.LIFE_PAY_SIGN_SYS_CD,'') -- 生活缴费签约系统代码 非主键字段不相等
         OR COALESCE(TM.SIGN_RESLT_DESC,'') <> COALESCE(BF.SIGN_RESLT_DESC,'') -- 签约结果描述 非主键字段不相等
         OR COALESCE(TM.REC_LOCK_FLAG,'') <> COALESCE(BF.REC_LOCK_FLAG,'') -- 记录锁定标志 非主键字段不相等
         OR COALESCE(TM.VER_NO,'') <> COALESCE(BF.VER_NO,'') -- 版本编号 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.CANCEL_CONT_ISNO,'') = COALESCE(BF.CANCEL_CONT_ISNO,'') -- 解约自增序号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM;
DROP TABLE AGL${version_num}.AGL_LIFE_PAY_CANCEL_CONT_AGT_INFO_TF_TM_01;
