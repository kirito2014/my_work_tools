-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人保证金交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_MRG_TXN_DTL_TA
--     表中文名：个人保证金交易明细聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO.TXN_DT, TXN_ACCT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-06-25 00:00:00 原海娜 新增
--         2024-11-10 00:00:00 魏丹丹 修改主表的筛选条件



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM
USING ORC
COMMENT '个人保证金交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_ACCT_NAME -- 交易账户名称
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,VAL_DT -- 起息日期
    ,INT_AMT -- 利息金额
    ,TRAN_CD -- 交易码
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人保证金交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_ACCT_NAME -- 交易账户名称
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,VAL_DT -- 起息日期
    ,INT_AMT -- 利息金额
    ,TRAN_CD -- 交易码
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.AO03TXSN AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.AO04TSSN AS SUB_TXN_SER_NO -- 子交易流水号
    ,unifiedTime(T1.AO02DATE) AS TXN_DT -- 交易日期
    ,T1.AO01AC15 AS TXN_ACCT_NO -- 交易账户编号
    ,CAST(T2.TEL_JNO AS STRING) AS TELR_SER_NO -- 柜员流水号
    ,T2.SRV_JNO AS FRONT_SER_NO -- 前置流水号
    ,T3.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,T4.CUST_NM AS CUST_NAME -- 客户名称
    ,T5.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,T5.CRTF_NO AS DOC_NO -- 证件号码
    ,unifiedTime(T1.AO17STAM) AS TXN_TM_STAMP -- 交易时间戳
    ,T3.AA04FLNM AS TXN_ACCT_NAME -- 交易账户名称
    ,T6.AB06ACFG AS ACCT_TYPE_CD -- 账户类型代码
    ,'2104' AS ACCT_PROPTY_CD -- 账户性质代码
    ,T1.AO10JZFS AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,T1.AO07CCYC AS TXN_CURR_CD -- 交易币种代码
    ,T1.AO08CHSX AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,CASE WHEN  T1.AO13CDFG='2' then 'C'
     WHEN T1.AO13CDFG='1' then 'D'
END  AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,T1.AO26JYLX AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN T2.CSTR_IND='0' THEN '2' 
     WHEN  T2.CSTR_IND='1' then '1'
END AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,T1.AO11AMT AS TXN_AMT -- 交易金额
    ,T1.AO12BAL AS ACCT_BAL -- 账户余额
    ,unifiedTime('') AS VAL_DT -- 起息日期
    ,T1.AO09IAMT AS INT_AMT -- 利息金额
    ,T2.SYS_TXID AS TRAN_CD -- 交易码
    ,T1.AO22NTCD AS SUMMARY_CD -- 摘要代码
    ,T2.ABS_DSC AS SUMMARY_DESC -- 摘要描述
    ,T7.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,T7.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,T6.AB10PDTP||T6.AB11PRON AS DPSIT_PROD_CD -- 存款产品代码
    ,T8.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,T1.AO16AC22 AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,'' AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,'' AS CNTPTY_BANK_NO -- 对方行号
    ,'' AS CNTPTY_BANK_NAME -- 对方行名
    ,T1.AO20BRNO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,T2.TX_DIS AS TXN_RGN_NO -- 交易地区编号
    ,T1.AO19STAF AS TXN_TELR_NO -- 交易柜员编号
    ,T1.AO18CNCD AS TXN_CHNL_CD -- 交易渠道代码
    ,T2.ATX_ID AS SUB_TRAN_CD -- 子交易码
    ,'' AS TXN_EQUIP_IP -- 交易设备IP
    ,'' AS TXN_EQUIP_MAC -- 交易设备MAC
    ,CASE WHEN T1.AO14OPTP IS NULL OR TRIM(T1.AO14OPTP) = '' 
THEN  ''
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@' || TRIM(T1.AO14OPTP),'') END AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,T1.AO15BLNO AS TXN_VOCH_NO -- 交易凭证号码
    ,T3.AA40BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,T3.AA42BRNO AS STAT_ORG_NO -- 统计机构编号
    ,T3.AA43BRNO AS LP_ORG_NO -- 法人机构编号
    ,T2.JRN_MARK AS REM -- 备注
    ,unifiedTime(T2.CRT_DTE) AS SETUP_DT -- 建立日期
    ,unifiedTime(T2.CRE_TS) AS SETUP_TM_STAMP -- 建立时间戳
    ,T2.CRE_UID AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(T2.UPD_DTE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(T2.UPD_TS) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,T2.UPD_UID AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAO_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE${version_num}.ODS_CORE_BDFMHQAO_TA AS T1 -- 保证金交易明细表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BYFTJRN_TA AS T2 -- 会计流水文件
       ON unifiedTime(T1.AO02DATE) = T2.TX_DATE  
AND T1.AO03TXSN =T2.BTX_JNO 
AND T1.AO04TSSN =T2.ATX_JNO
AND T1.AO01AC15 =T2.ACC_NO 
AND T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAA_TF AS T3 -- 定期存款账户控制文件
       ON T1.AO01AC15 =T3.AA01AC15 
AND T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF AS T4 -- 客户基础信息表
       ON T3.AA03CSNO =T4.CST_IN_CD AND T4.PT_DT = '${process_date}' AND T4.DEL_F = '0' 
LEFT JOIN (
SELECT CRTF_TYP,CST_IN_CD,CRTF_NO,ROW_NUMBER() OVER (PARTITION BY CST_IN_CD ORDER BY CRTF_NO DESC ) AS NUM1 FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF WHERE MAJOR_FLG='1' AND DELETED = '0' AND  PT_DT = '${process_date}' AND DEL_F = '0'
) AS T5 -- 客户证件信息表
       ON T5.CST_IN_CD =T3.AA03CSNO AND T5.NUM1=1 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BFFMDQAB_TF AS T6 -- 定期模块账户分户余额信息
       ON T6.AB01AC15 = T1.AO01AC15  AND T6.AB03CCYC=T1.AO07CCYC  AND T6.AB05CHSX=T1.AO08CHSX 
AND T6.PT_DT = '${process_date}' AND T6.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS T7 -- 新会计科目核算码对照表
       ON T7.KHDBACID = T2.GLAC_NO AND T7.PT_DT = '${process_date}' AND T7.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQCW_TF AS T8 -- 产品代码名称表
       ON T8.CW03PRON = T6.AB11PRON AND T8.CW02PDTP = T6.AB10PDTP AND T8.PT_DT = '${process_date}' AND T8.DEL_F = '0' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 代码转换
       ON T1.AO14OPTP=S1.SRC_CD_VAL   --源表.源字段=字段映射表。SRC_CD_VAL
AND S1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='BDFMHQAO' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='AO14OPTP' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_INDV_MRG_TXN_DTL_TA'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='TXN_VOCH_CATE_CD' --目标字段 
WHERE SUBSTR(T1.AO01AC15,1,3) = '183' AND T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- 个人保证金交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_ACCT_NAME -- 交易账户名称
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,VAL_DT -- 起息日期
    ,INT_AMT -- 利息金额
    ,TRAN_CD -- 交易码
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.AC03TXSN AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.AC04TSSN AS SUB_TXN_SER_NO -- 子交易流水号
    ,unifiedTime(T1.AC02DATE) AS TXN_DT -- 交易日期
    ,T1.AC01AC15 AS TXN_ACCT_NO -- 交易账户编号
    ,CAST(T1.AC24SN04 AS STRING) AS TELR_SER_NO -- 柜员流水号
    ,T1.AC25NO12 AS FRONT_SER_NO -- 前置流水号
    ,T2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,T3.CUST_NM AS CUST_NAME -- 客户名称
    ,T4.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,T4.CRTF_NO AS DOC_NO -- 证件号码
    ,unifiedTime(T1.AC16STAM) AS TXN_TM_STAMP -- 交易时间戳
    ,T2.AA04FLNM AS TXN_ACCT_NAME -- 交易账户名称
    ,CASE WHEN T2.AA11ACFG='4' then 'H4'
     WHEN T2.AA11ACFG='6' then 'H6'
END AS ACCT_TYPE_CD -- 账户类型代码
    ,T2.AA13ZHTP AS ACCT_PROPTY_CD -- 账户性质代码
    ,'' AS MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,T1.AC07CCYC AS TXN_CURR_CD -- 交易币种代码
    ,T1.AC08CHSX AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,CASE WHEN T1.AC12CDFG='1' THEN 'D'
     WHEN T1.AC12CDFG='2' THEN 'C'
END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,T1.AC24JYLX AS TXN_TYPE_CD -- 交易类型代码
    ,T1.AC09JZFS AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,T1.AC10AMT AS TXN_AMT -- 交易金额
    ,T1.AC11AMT AS ACCT_BAL -- 账户余额
    ,unifiedTime(T1.AC06DATE) AS VAL_DT -- 起息日期
    ,NULL AS INT_AMT -- 利息金额
    ,T1.BTXMTXCD AS TRAN_CD -- 交易码
    ,T1.AC20NTCD AS SUMMARY_CD -- 摘要代码
    ,T1.ZYXXNM40 AS SUMMARY_DESC -- 摘要描述
    ,T11.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,T11.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,T2.AA07PDTP||T2.AA08PRON AS DPSIT_PROD_CD -- 存款产品代码
    ,T5.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,T1.AC15AC22 AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,T6.ET06FLNM AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,T6.ET07BK20 AS CNTPTY_BANK_NO -- 对方行号
    ,CASE WHEN LENGTH(TRIM(T6.ET07BK20))=6  THEN T8.ORCAFLNM       
     WHEN LENGTH(TRIM(T6.ET07BK20))=12 THEN  T9.BANK_NAME
     END AS CNTPTY_BANK_NAME -- 对方行名
    ,T1.AC19BRNO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,T10.TX_DIS AS TXN_RGN_NO -- 交易地区编号
    ,T1.AC18STAF AS TXN_TELR_NO -- 交易柜员编号
    ,T1.AC17CNCD AS TXN_CHNL_CD -- 交易渠道代码
    ,T10.ATX_ID AS SUB_TRAN_CD -- 子交易码
    ,T7.KF06IPAD AS TXN_EQUIP_IP -- 交易设备IP
    ,T7.KF07MAC AS TXN_EQUIP_MAC -- 交易设备MAC
    ,CASE WHEN  T1.AC13BLTP IS NULL OR TRIM(T1.AC13BLTP) ='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@'||trim(T1.AC13BLTP),'') END  AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,T1.AC14BLNO AS TXN_VOCH_NO -- 交易凭证号码
    ,T1.AC25BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,T2.AA45BRNO AS STAT_ORG_NO -- 统计机构编号
    ,T2.AA48BRNO AS LP_ORG_NO -- 法人机构编号
    ,T10.JRN_MARK AS REM -- 备注
    ,unifiedTime(T10.CRT_DTE) AS SETUP_DT -- 建立日期
    ,unifiedTime(T10.CRE_TS) AS SETUP_TM_STAMP -- 建立时间戳
    ,T10.CRE_UID AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(T10.UPD_DTE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(T10.UPD_TS) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,T10.UPD_UID AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAC_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE${version_num}.ODS_CORE_BDFMHQAC_TA AS T1 -- 活期存款账户交易明细表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS T2 -- 活期存款账户主档
       ON T1.AC01AC15 = T2.AA01AC15 AND T2.PT_DT = '${process_date}' AND T2.DEL_F = '0' 
LEFT JOIN ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_BAS_TF AS T3 -- 客户基础信息表
       ON T2.AA03CSNO =T3.CST_IN_CD AND T3.PT_DT = '${process_date}' AND T3.DEL_F = '0' 
LEFT JOIN (
SELECT C1.CRTF_TYP
       ,C1.CRTF_NO
       ,C1.CST_IN_CD
       ,C1.CRTF_NO
       ,ROW_NUMBER() OVER (PARTITION BY C1.CST_IN_CD ORDER BY C1.CRTF_NO DESC ) AS NUM1 
FROM ODS_EICC${version_num}.ODS_EICC_C_CUS_PRIV_CRTF_TF C1 
WHERE C1.MAJOR_FLG='1' AND C1.DELETED = '0' AND  C1.PT_DT = '${process_date}' AND C1.DEL_F = '0'
) AS T4 -- 客户证件信息表
       ON T4.CST_IN_CD =T2.AA03CSNO and T4.NUM1=1  
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQCW_TF AS T5 -- 产品代码名称表
       ON T5.CW03PRON = T2.AA08PRON AND T5.CW02PDTP = T2.AA07PDTP AND T5.PT_DT = '${process_date}' AND T5.DEL_F = '0' 


 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQET_TA AS T6 -- 活期存款当日账户交易明细补充信息表
       ON T6.ET01AC15 = T1.AC01AC15
AND T6.ET02DATE = T1.AC02DATE
AND T6.ET03TXSN = T1.AC03TXSN
AND T6.ET04TSSN = T1.AC04TSSN
AND T6.PT_DT = '${process_date}' AND T6.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQKF_TA AS T7 -- 活期存款互联网交易登记簿（当日）
       ON T7.KF01AC15 = T1.AC01AC15
AND T7.KF02DATE = T1.AC02DATE
AND T7.KF03TXSN = T1.AC03TXSN
AND T7.KF04TSSN = T1.AC04TSSN
AND T7.PT_DT = '${process_date}' AND T7.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BBFMORGA_TF AS T8 -- 机构信息表
       ON TRIM(T6.ET07BK20)=TRIM(T8.ORCABRNO) 
AND T8.PT_DT = '${process_date}' AND T8.DEL_F = '0' 
LEFT JOIN ODS_PYMT${version_num}.ODS_PYMT_T_SET_BANK_TF AS T9 -- 支付系统统一行名行号表
       ON TRIM(T6.ET07BK20)=TRIM(T9.BANK_NO)
AND T9.PT_DT = '${process_date}' AND T9.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BYFTJRN_TA AS T10 -- 会计流水文件
       ON unifiedTime(T1.AC02DATE) = T10.TX_DATE  AND T1.AC03TXSN =T10.BTX_JNO
 AND T1.AC04TSSN =T10.ATX_JNO  AND T1.AC01AC15 =T10.ACC_NO
AND T10.PT_DT = '${process_date}' AND T10.DEL_F = '0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS T11 -- 新会计科目核算码对照表
       ON T11.KHDBACID = T10.GLAC_NO
AND T11.PT_DT = '${process_date}' AND T11.DEL_F = '0' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- 代码转换
       ON T1.AC13BLTP=S1.SRC_CD_VAL   --源表.源字段=字段映射表。SRC_CD_VAL
AND S1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='BDFMHQAC' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='AC13BLTP' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_INDV_MRG_TXN_DTL_TA'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='TXN_VOCH_CATE_CD' --目标字段 
WHERE SUBSTR(T1.AC01AC15,1,3) = '181'  AND T1.PT_DT = '${process_date}' AND T1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_DT -- 交易日期
    ,TXN_ACCT_NO -- 交易账户编号
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_ACCT_NAME -- 交易账户名称
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,MRG_REC_TYPE_CD -- 保证金记录类型代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,ACCT_BAL -- 账户余额
    ,VAL_DT -- 起息日期
    ,INT_AMT -- 利息金额
    ,TRAN_CD -- 交易码
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_INDV_MRG_TXN_DTL_TA_TM;
