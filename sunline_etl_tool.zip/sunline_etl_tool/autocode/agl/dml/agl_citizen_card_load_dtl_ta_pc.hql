-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-市民卡圈存明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CITIZEN_CARD_LOAD_DTL_TA
--     表中文名：市民卡圈存明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM
USING ORC
COMMENT '市民卡圈存明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,TRPRT_TXN_SER_NO -- 三方交易流水号
    ,CTZ_CARD_SER_NO -- 市民卡流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,CORE_SER_NO -- 核心流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,TXN_RGN_NO -- 交易地区号
    ,CHNL_CD -- 渠道代码
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CTZ_CARD_NO -- 市民卡编号
    ,DOC_NO -- 证件号码
    ,USER_NO -- 用户编号
    ,CUST_NO -- 客户号
    ,CUST_NAME -- 客户名称
    ,TXN_UCC_FLAG -- 交易成功标志
    ,BANK_CARD_ACCT_NO -- 银行卡账号
    ,MASTER_CARD_NO -- 主卡卡号
    ,NOW_CHARGE_FLAG -- 现在收费标志
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TAX_FLAG -- 非居民税收标志
    ,CHARGE_TYPE_CD -- 收费类型代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,CUST_ACCT_NO -- 客户账户编号
    ,CUST_ACCT_NAME -- 客户账户名称
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,TXN_AMT -- 交易金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,LATE_FEE -- 滞纳金
    ,RECORD_ORG_NO -- 入账机构编号
    ,LOGIN_TELR_NO -- 登录柜员编号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,HECKER_NO -- 复核人柜员编号
    ,PRE_AUTH_NO -- 预授权编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,LATST_EMPLYER_TEL -- 最新工作单位电话
    ,CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,TXN_ORDER_NO -- 交易订单编号
    ,CLEAR_DT -- 清算日期
    ,THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,SEND_SUCC_FLAG -- 发送成功标志
    ,HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_ILUS -- 摘要说明
    ,THIRD_PTY_RSPS_CD -- 第三方响应码
    ,THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,FINAL_TXN_DT -- 最后交易日期
    ,TXN_HAPP_TM_CD -- 交易发生时间代码
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_DT -- 交易日期
    ,PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,OPER_DT -- 操作日期
    ,TXN_TERM_MODE_CD -- 交易期限方式代码
    ,REM -- 备注
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 市民卡圈存明细聚合

INSERT INTO TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,TRPRT_TXN_SER_NO -- 三方交易流水号
    ,CTZ_CARD_SER_NO -- 市民卡流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,CORE_SER_NO -- 核心流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,TXN_RGN_NO -- 交易地区号
    ,CHNL_CD -- 渠道代码
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CTZ_CARD_NO -- 市民卡编号
    ,DOC_NO -- 证件号码
    ,USER_NO -- 用户编号
    ,CUST_NO -- 客户号
    ,CUST_NAME -- 客户名称
    ,TXN_UCC_FLAG -- 交易成功标志
    ,BANK_CARD_ACCT_NO -- 银行卡账号
    ,MASTER_CARD_NO -- 主卡卡号
    ,NOW_CHARGE_FLAG -- 现在收费标志
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TAX_FLAG -- 非居民税收标志
    ,CHARGE_TYPE_CD -- 收费类型代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,CUST_ACCT_NO -- 客户账户编号
    ,CUST_ACCT_NAME -- 客户账户名称
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,TXN_AMT -- 交易金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,LATE_FEE -- 滞纳金
    ,RECORD_ORG_NO -- 入账机构编号
    ,LOGIN_TELR_NO -- 登录柜员编号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,HECKER_NO -- 复核人柜员编号
    ,PRE_AUTH_NO -- 预授权编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,LATST_EMPLYER_TEL -- 最新工作单位电话
    ,CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,TXN_ORDER_NO -- 交易订单编号
    ,CLEAR_DT -- 清算日期
    ,THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,SEND_SUCC_FLAG -- 发送成功标志
    ,HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_ILUS -- 摘要说明
    ,THIRD_PTY_RSPS_CD -- 第三方响应码
    ,THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,FINAL_TXN_DT -- 最后交易日期
    ,TXN_HAPP_TM_CD -- 交易发生时间代码
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_DT -- 交易日期
    ,PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,OPER_DT -- 操作日期
    ,TXN_TERM_MODE_CD -- 交易期限方式代码
    ,REM -- 备注
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,P1.OTH_SEQ AS TRPRT_TXN_SER_NO -- 三方交易流水号
    ,'' AS CTZ_CARD_SER_NO -- 市民卡流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,'' AS CORE_SER_NO -- 核心流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,'' AS TXN_RGN_NO -- 交易地区号
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.TX_CODE AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CTZ_CARD_NO -- 市民卡编号
    ,'' AS DOC_NO -- 证件号码
    ,'' --P1.USER_ID AS USER_NO -- 用户编号
    ,P1.CUST_NO AS CUST_NO -- 客户号
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,P1.BZ AS TXN_UCC_FLAG -- 交易成功标志
    ,P1.CUST_ACCT AS BANK_CARD_ACCT_NO -- 银行卡账号
    ,P1.CARD_NO AS MASTER_CARD_NO -- 主卡卡号
    ,P1.SFBZ AS NOW_CHARGE_FLAG -- 现在收费标志
    ,P1.XZBZ AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.TAX_FLAG AS TAX_FLAG -- 非居民税收标志
    ,P1.SFLX AS CHARGE_TYPE_CD -- 收费类型代码
    ,'' AS VOCH_CATE_CD -- 凭证种类代码
    ,'' AS VOCH_NO -- 凭证号码
    ,'' AS CUST_ACCT_NO -- 客户账户编号
    ,'' AS CUST_ACCT_NAME -- 客户账户名称
    ,'' AS FUND_COL_ACCT_NO -- 收款账户编号
    ,'' AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,'' AS YESTD_BAL -- 昨日余额
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,'' AS COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,'' AS LATE_FEE -- 滞纳金
    ,'' AS RECORD_ORG_NO -- 入账机构编号
    ,'' AS LOGIN_TELR_NO -- 登录柜员编号
    ,P1.CHK_ACT_NO AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,'' AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,'' AS SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,'' AS HECKER_NO -- 复核人柜员编号
    ,'' AS PRE_AUTH_NO -- 预授权编号
    ,'' AS OPER_TELR_NO -- 操作柜员编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,'' AS IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,'' AS LATST_EMPLYER_TEL -- 最新工作单位电话
    ,'' AS CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,'' AS TXN_ORDER_NO -- 交易订单编号
    ,'1899-12-31' AS CLEAR_DT -- 清算日期
    ,'1899-12-31' AS THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,'' AS SEND_SUCC_FLAG -- 发送成功标志
    ,P1.HOST_CHK_STAT AS HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,P1.ENTR_CHK_STAT AS TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,P1.HOST_ACC_STAT AS HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,'' AS THIRD_PTY_RSPS_CD -- 第三方响应码
    ,'' AS THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,'1899-12-31' AS FINAL_TXN_DT -- 最后交易日期
    ,'' AS TXN_HAPP_TM_CD -- 交易发生时间代码
    ,'1899-12-31' AS HOST_TXN_DT -- 主机交易日期
    ,'1899-12-31 00:00:00.000000' AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,'' AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'1899-12-31' AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,'1899-12-31 00:00:00.000000' AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,'' AS BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,'1899-12-31 00:00:00.000000' AS APP_TM_STAMP -- 申请时间戳
    ,'1899-12-31 00:00:00.000000' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,unifiedTime(P1.TX_DATE) AS TXN_DT -- 交易日期
    ,unifiedTime(P1.TX_TIME) AS PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,'1899-12-31' AS OPER_DT -- 操作日期
    ,'' AS TXN_TERM_MODE_CD -- 交易期限方式代码
    ,'' AS REM -- 备注
    ,P1.BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_YWSMK_JRNL_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS.ODS_OSSAS_T_YWSMK_JRNL_TF AS P1 -- 义乌市民卡流水表

WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- 市民卡圈存明细聚合

INSERT INTO TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,TRPRT_TXN_SER_NO -- 三方交易流水号
    ,CTZ_CARD_SER_NO -- 市民卡流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,CORE_SER_NO -- 核心流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,TXN_RGN_NO -- 交易地区号
    ,CHNL_CD -- 渠道代码
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CTZ_CARD_NO -- 市民卡编号
    ,DOC_NO -- 证件号码
    ,USER_NO -- 用户编号
    ,CUST_NO -- 客户号
    ,CUST_NAME -- 客户名称
    ,TXN_UCC_FLAG -- 交易成功标志
    ,BANK_CARD_ACCT_NO -- 银行卡账号
    ,MASTER_CARD_NO -- 主卡卡号
    ,NOW_CHARGE_FLAG -- 现在收费标志
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TAX_FLAG -- 非居民税收标志
    ,CHARGE_TYPE_CD -- 收费类型代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,CUST_ACCT_NO -- 客户账户编号
    ,CUST_ACCT_NAME -- 客户账户名称
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,TXN_AMT -- 交易金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,LATE_FEE -- 滞纳金
    ,RECORD_ORG_NO -- 入账机构编号
    ,LOGIN_TELR_NO -- 登录柜员编号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,HECKER_NO -- 复核人柜员编号
    ,PRE_AUTH_NO -- 预授权编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,LATST_EMPLYER_TEL -- 最新工作单位电话
    ,CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,TXN_ORDER_NO -- 交易订单编号
    ,CLEAR_DT -- 清算日期
    ,THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,SEND_SUCC_FLAG -- 发送成功标志
    ,HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_ILUS -- 摘要说明
    ,THIRD_PTY_RSPS_CD -- 第三方响应码
    ,THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,FINAL_TXN_DT -- 最后交易日期
    ,TXN_HAPP_TM_CD -- 交易发生时间代码
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_DT -- 交易日期
    ,PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,OPER_DT -- 操作日期
    ,TXN_TERM_MODE_CD -- 交易期限方式代码
    ,REM -- 备注
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,'' AS TRPRT_TXN_SER_NO -- 三方交易流水号
    ,P1.SMK_SEQ AS CTZ_CARD_SER_NO -- 市民卡流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,'' --P1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,'' --P1.OLD_SEQ AS UNDO_SER_NO -- 撤销流水号
    ,'' AS TXN_RGN_NO -- 交易地区号
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' --P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.SVCNAME AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,P1.SMK_NO AS CTZ_CARD_NO -- 市民卡编号
    ,'' AS DOC_NO -- 证件号码
    ,'' AS USER_NO -- 用户编号
    ,'' AS CUST_NO -- 客户号
    ,'' AS CUST_NAME -- 客户名称
    ,'' AS TXN_UCC_FLAG -- 交易成功标志
    ,P1.ACCT_NO AS BANK_CARD_ACCT_NO -- 银行卡账号
    ,'' AS MASTER_CARD_NO -- 主卡卡号
    ,'' AS NOW_CHARGE_FLAG -- 现在收费标志
    ,'' AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,'' AS TAX_FLAG -- 非居民税收标志
    ,'' AS CHARGE_TYPE_CD -- 收费类型代码
    ,'' AS VOCH_CATE_CD -- 凭证种类代码
    ,'' AS VOCH_NO -- 凭证号码
    ,'' AS CUST_ACCT_NO -- 客户账户编号
    ,'' AS CUST_ACCT_NAME -- 客户账户名称
    ,'' AS FUND_COL_ACCT_NO -- 收款账户编号
    ,'' AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.SMK_JYJE AS TXN_AMT -- 交易金额
    ,P1.SMK_YE AS YESTD_BAL -- 昨日余额
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,'' AS COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,'' AS LATE_FEE -- 滞纳金
    ,P1.SMK_BRCH AS RECORD_ORG_NO -- 入账机构编号
    ,P1.SMK_TELLER AS LOGIN_TELR_NO -- 登录柜员编号
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,'' AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,'' AS SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,'' AS HECKER_NO -- 复核人柜员编号
    ,'' AS PRE_AUTH_NO -- 预授权编号
    ,'' AS OPER_TELR_NO -- 操作柜员编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,'' AS IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,'' AS LATST_EMPLYER_TEL -- 最新工作单位电话
    ,'' AS CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,'' AS TXN_ORDER_NO -- 交易订单编号
    ,'1899-12-31' AS CLEAR_DT -- 清算日期
    ,'1899-12-31' AS THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,'' AS SEND_SUCC_FLAG -- 发送成功标志
    ,P1.HOST_CHK_STAT AS HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,P1.ENTR_CHK_STAT AS TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,P1.HOST_ACC_STAT AS HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_ILUS -- 摘要说明
    ,'' AS THIRD_PTY_RSPS_CD -- 第三方响应码
    ,'' AS THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,'1899-12-31' AS FINAL_TXN_DT -- 最后交易日期
    ,'' AS TXN_HAPP_TM_CD -- 交易发生时间代码
    ,'1899-12-31' AS HOST_TXN_DT -- 主机交易日期
    ,'1899-12-31 00:00:00.000000' AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,'' AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'1899-12-31' AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,'1899-12-31 00:00:00.000000' AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,'' AS BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,'1899-12-31 00:00:00.000000' AS APP_TM_STAMP -- 申请时间戳
    ,'1899-12-31 00:00:00.000000' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'1899-12-31' AS TXN_DT -- 交易日期
    ,unifiedTime(P1.SMK_TIME) AS PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,unifiedTime(P1.SMK_DATE) AS OPER_DT -- 操作日期
    ,P1.RMRK3 AS TXN_TERM_MODE_CD -- 交易期限方式代码
    ,P1.RMRK1 AS REM -- 备注
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'OSSAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSSAS_T_ZJSMK_JRNL_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_OSSAS.ODS_OSSAS_T_ZJSMK_JRNL_TF AS P1 -- 浙江市民卡流水表

WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- 市民卡圈存明细聚合

INSERT INTO TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,TRPRT_TXN_SER_NO -- 三方交易流水号
    ,CTZ_CARD_SER_NO -- 市民卡流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,CORE_SER_NO -- 核心流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,TXN_RGN_NO -- 交易地区号
    ,CHNL_CD -- 渠道代码
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CTZ_CARD_NO -- 市民卡编号
    ,DOC_NO -- 证件号码
    ,USER_NO -- 用户编号
    ,CUST_NO -- 客户号
    ,CUST_NAME -- 客户名称
    ,TXN_UCC_FLAG -- 交易成功标志
    ,BANK_CARD_ACCT_NO -- 银行卡账号
    ,MASTER_CARD_NO -- 主卡卡号
    ,NOW_CHARGE_FLAG -- 现在收费标志
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TAX_FLAG -- 非居民税收标志
    ,CHARGE_TYPE_CD -- 收费类型代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,CUST_ACCT_NO -- 客户账户编号
    ,CUST_ACCT_NAME -- 客户账户名称
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,TXN_AMT -- 交易金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,LATE_FEE -- 滞纳金
    ,RECORD_ORG_NO -- 入账机构编号
    ,LOGIN_TELR_NO -- 登录柜员编号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,HECKER_NO -- 复核人柜员编号
    ,PRE_AUTH_NO -- 预授权编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,LATST_EMPLYER_TEL -- 最新工作单位电话
    ,CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,TXN_ORDER_NO -- 交易订单编号
    ,CLEAR_DT -- 清算日期
    ,THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,SEND_SUCC_FLAG -- 发送成功标志
    ,HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_ILUS -- 摘要说明
    ,THIRD_PTY_RSPS_CD -- 第三方响应码
    ,THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,FINAL_TXN_DT -- 最后交易日期
    ,TXN_HAPP_TM_CD -- 交易发生时间代码
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_DT -- 交易日期
    ,PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,OPER_DT -- 操作日期
    ,TXN_TERM_MODE_CD -- 交易期限方式代码
    ,REM -- 备注
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,P1.OTH_SEQ AS TRPRT_TXN_SER_NO -- 三方交易流水号
    ,'' AS CTZ_CARD_SER_NO -- 市民卡流水号
    ,P1.TX_SEQ AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,P1.OLD_SEQ AS UNDO_SER_NO -- 撤销流水号
    ,P1.PLAT_NO AS TXN_RGN_NO -- 交易地区号
    ,P1.CHN_NO AS CHNL_CD -- 渠道代码
    ,P1.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.TX_CODE AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CTZ_CARD_NO -- 市民卡编号
    ,P1.USER_ID AS DOC_NO -- 证件号码
    ,P1.USER_NO AS USER_NO -- 用户编号
    ,P1.CUST_NO AS CUST_NO -- 客户号
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,'' AS TXN_UCC_FLAG -- 交易成功标志
    ,'' AS BANK_CARD_ACCT_NO -- 银行卡账号
    ,'' AS MASTER_CARD_NO -- 主卡卡号
    ,'' AS NOW_CHARGE_FLAG -- 现在收费标志
    ,'' AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,'' AS TAX_FLAG -- 非居民税收标志
    ,'' AS CHARGE_TYPE_CD -- 收费类型代码
    ,P1.VCH_TYPE AS VOCH_CATE_CD -- 凭证种类代码
    ,P1.VCH_NO AS VOCH_NO -- 凭证号码
    ,P1.ACT_NO1 AS CUST_ACCT_NO -- 客户账户编号
    ,P1.ACT_NAME1 AS CUST_ACCT_NAME -- 客户账户名称
    ,P1.ACT_NO2 AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.ACT_NAME2 AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,'' AS YESTD_BAL -- 昨日余额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,P1.TX_FEE AS COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,P1.TX_LATE AS LATE_FEE -- 滞纳金
    ,'' AS RECORD_ORG_NO -- 入账机构编号
    ,'' AS LOGIN_TELR_NO -- 登录柜员编号
    ,P1.CHK_ACT_NO AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,P1.MNG_BRCH AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,P1.DC_FLAG AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.HOST_ACT_NO1 AS SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,P1.RCKR_NO AS HECKER_NO -- 复核人柜员编号
    ,P1.AUTH_NO AS PRE_AUTH_NO -- 预授权编号
    ,P1.TELLER_NO AS OPER_TELR_NO -- 操作柜员编号
    ,P1.TX_FLAG AS TXN_STATUS_CD -- 交易状态代码
    ,P1.RS_TYPE AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,P1.ZQ_TYPE AS DRAW_MODE_CD -- 支取方式代码
    ,P1.USER_TYPE AS IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,P1.USER_TEL AS LATST_EMPLYER_TEL -- 最新工作单位电话
    ,P1.APP_TYPE AS CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,P1.ORDER_NO AS TXN_ORDER_NO -- 交易订单编号
    ,unifiedTime(P1.BANK_CLR_DATE) AS CLEAR_DT -- 清算日期
    ,unifiedTime(P1.CLR_DATE) AS THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,P1.SEND_FLAG AS SEND_SUCC_FLAG -- 发送成功标志
    ,P1.HOST_CHK_STAT AS HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,P1.ENTR_CHK_STAT AS TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,P1.HOST_ACC_STAT AS HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,P1.SUM_CODE AS SUMMARY_CD -- 摘要代码
    ,P1.SUM_MSG AS SUMMARY_ILUS -- 摘要说明
    ,P1.RET_CODE AS THIRD_PTY_RSPS_CD -- 第三方响应码
    ,P1.RET_MSG AS THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,unifiedTime(P1.TX_DATE) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(P1.TX_TIME) AS TXN_HAPP_TM_CD -- 交易发生时间代码
    ,unifiedTime(P1.ACT_DATE) AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime(P1.ACT_TIME) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,unifiedTime(P1.OTH_DATE) AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime(P1.OTH_TIME) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.OTH_CODE AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,P1.OTH_MSG AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,P1.OTH_DEAL_STAT AS TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,P1.DEAL AS BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,unifiedTime(P1.INIT_TIME) AS APP_TM_STAMP -- 申请时间戳
    ,unifiedTime(P1.UPDATE_TIME) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'1899-12-31' AS TXN_DT -- 交易日期
    ,'1899-12-31 00:00:00.000000' AS PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,'1899-12-31' AS OPER_DT -- 操作日期
    ,'' AS TXN_TERM_MODE_CD -- 交易期限方式代码
    ,P1.REMARK AS REM -- 备注
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'IMBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_IMBS_T_HUZSMK_JRNL_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_IMBS.ODS_IMBS_T_HUZSMK_JRNL_TF AS P1 -- 湖州市民卡流水表

WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- 市民卡圈存明细聚合

INSERT INTO TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,TRPRT_TXN_SER_NO -- 三方交易流水号
    ,CTZ_CARD_SER_NO -- 市民卡流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,CORE_SER_NO -- 核心流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,TXN_RGN_NO -- 交易地区号
    ,CHNL_CD -- 渠道代码
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CTZ_CARD_NO -- 市民卡编号
    ,DOC_NO -- 证件号码
    ,USER_NO -- 用户编号
    ,CUST_NO -- 客户号
    ,CUST_NAME -- 客户名称
    ,TXN_UCC_FLAG -- 交易成功标志
    ,BANK_CARD_ACCT_NO -- 银行卡账号
    ,MASTER_CARD_NO -- 主卡卡号
    ,NOW_CHARGE_FLAG -- 现在收费标志
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TAX_FLAG -- 非居民税收标志
    ,CHARGE_TYPE_CD -- 收费类型代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,CUST_ACCT_NO -- 客户账户编号
    ,CUST_ACCT_NAME -- 客户账户名称
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,TXN_AMT -- 交易金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,LATE_FEE -- 滞纳金
    ,RECORD_ORG_NO -- 入账机构编号
    ,LOGIN_TELR_NO -- 登录柜员编号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,HECKER_NO -- 复核人柜员编号
    ,PRE_AUTH_NO -- 预授权编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,LATST_EMPLYER_TEL -- 最新工作单位电话
    ,CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,TXN_ORDER_NO -- 交易订单编号
    ,CLEAR_DT -- 清算日期
    ,THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,SEND_SUCC_FLAG -- 发送成功标志
    ,HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_ILUS -- 摘要说明
    ,THIRD_PTY_RSPS_CD -- 第三方响应码
    ,THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,FINAL_TXN_DT -- 最后交易日期
    ,TXN_HAPP_TM_CD -- 交易发生时间代码
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_DT -- 交易日期
    ,PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,OPER_DT -- 操作日期
    ,TXN_TERM_MODE_CD -- 交易期限方式代码
    ,REM -- 备注
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,P1.OTH_SEQ AS TRPRT_TXN_SER_NO -- 三方交易流水号
    ,'' AS CTZ_CARD_SER_NO -- 市民卡流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,P1.OLD_SEQ AS UNDO_SER_NO -- 撤销流水号
    ,P1.PLAT_NO AS TXN_RGN_NO -- 交易地区号
    ,P1.CHN_NO AS CHNL_CD -- 渠道代码
    ,P1.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,P1.TX_CODE AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CTZ_CARD_NO -- 市民卡编号
    ,'' AS DOC_NO -- 证件号码
    ,P1.USER_ID AS USER_NO -- 用户编号
    ,P1.CUST_NO AS CUST_NO -- 客户号
    ,P1.CUST_NAME AS CUST_NAME -- 客户名称
    ,'' AS TXN_UCC_FLAG -- 交易成功标志
    ,'' AS BANK_CARD_ACCT_NO -- 银行卡账号
    ,'' AS MASTER_CARD_NO -- 主卡卡号
    ,'' AS NOW_CHARGE_FLAG -- 现在收费标志
    ,'' AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,'' AS TAX_FLAG -- 非居民税收标志
    ,'' AS CHARGE_TYPE_CD -- 收费类型代码
    ,P1.VCH_TYPE AS VOCH_CATE_CD -- 凭证种类代码
    ,P1.VCH_NO AS VOCH_NO -- 凭证号码
    ,P1.ACT_NO1 AS CUST_ACCT_NO -- 客户账户编号
    ,P1.ACT_NAME1 AS CUST_ACCT_NAME -- 客户账户名称
    ,P1.ACT_NO2 AS FUND_COL_ACCT_NO -- 收款账户编号
    ,P1.ACT_NAME2 AS FUND_COL_ACCT_NAME -- 收款账户名称
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,'' AS YESTD_BAL -- 昨日余额
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,P1.TX_FEE AS COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,P1.TX_LATE AS LATE_FEE -- 滞纳金
    ,'' AS RECORD_ORG_NO -- 入账机构编号
    ,'' AS LOGIN_TELR_NO -- 登录柜员编号
    ,P1.CHK_ACT_NO AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,P1.MNG_BRCH AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,P1.DC_FLAG AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.HOST_ACT_NO1 AS SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,P1.RCKR_NO AS HECKER_NO -- 复核人柜员编号
    ,P1.AUTH_NO AS PRE_AUTH_NO -- 预授权编号
    ,P1.TELLER_NO AS OPER_TELR_NO -- 操作柜员编号
    ,P1.TX_FLAG AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS CARD_MED_TYPE_CD -- 卡介质类别代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,'' AS IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,'' AS LATST_EMPLYER_TEL -- 最新工作单位电话
    ,'' AS CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,'' AS TXN_ORDER_NO -- 交易订单编号
    ,'1899-12-31' AS CLEAR_DT -- 清算日期
    ,'1899-12-31' AS THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,'' AS SEND_SUCC_FLAG -- 发送成功标志
    ,P1.HOST_CHK_STAT AS HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,P1.ENTR_CHK_STAT AS TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,P1.HOST_ACC_STAT AS HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,P1.SUM_CODE AS SUMMARY_CD -- 摘要代码
    ,P1.SUM_MSG AS SUMMARY_ILUS -- 摘要说明
    ,P1.RET_CODE AS THIRD_PTY_RSPS_CD -- 第三方响应码
    ,P1.RET_MSG AS THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,unifiedTime(P1.TX_DATE) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(P1.TX_TIME) AS TXN_HAPP_TM_CD -- 交易发生时间代码
    ,unifiedTime(P1.ACT_DATE) AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime(P1.ACT_TIME) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,unifiedTime(P1.OTH_DATE) AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime(P1.OTH_TIME) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.OTH_CODE AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,P1.OTH_MSG AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,'' AS BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,'1899-12-31 00:00:00.000000' AS APP_TM_STAMP -- 申请时间戳
    ,'1899-12-31 00:00:00.000000' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'1899-12-31' AS TXN_DT -- 交易日期
    ,'1899-12-31 00:00:00.000000' AS PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,'1899-12-31' AS OPER_DT -- 操作日期
    ,'' AS TXN_TERM_MODE_CD -- 交易期限方式代码
    ,'' AS REM -- 备注
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'IMBS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_IMBS_T_JRNL_JHSMK_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_IMBS.ODS_IMBS_T_JRNL_JHSMK_TF AS P1 -- 金华市民卡流水表

WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,TRPRT_TXN_SER_NO -- 三方交易流水号
    ,CTZ_CARD_SER_NO -- 市民卡流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,CORE_SER_NO -- 核心流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,TXN_RGN_NO -- 交易地区号
    ,CHNL_CD -- 渠道代码
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CTZ_CARD_NO -- 市民卡编号
    ,DOC_NO -- 证件号码
    ,USER_NO -- 用户编号
    ,CUST_NO -- 客户号
    ,CUST_NAME -- 客户名称
    ,TXN_UCC_FLAG -- 交易成功标志
    ,BANK_CARD_ACCT_NO -- 银行卡账号
    ,MASTER_CARD_NO -- 主卡卡号
    ,NOW_CHARGE_FLAG -- 现在收费标志
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TAX_FLAG -- 非居民税收标志
    ,CHARGE_TYPE_CD -- 收费类型代码
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,CUST_ACCT_NO -- 客户账户编号
    ,CUST_ACCT_NAME -- 客户账户名称
    ,FUND_COL_ACCT_NO -- 收款账户编号
    ,FUND_COL_ACCT_NAME -- 收款账户名称
    ,TXN_AMT -- 交易金额
    ,YESTD_BAL -- 昨日余额
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,COMM_FEE_TOTAL_AMT -- 手续费总金额
    ,LATE_FEE -- 滞纳金
    ,RECORD_ORG_NO -- 入账机构编号
    ,LOGIN_TELR_NO -- 登录柜员编号
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,SEND_HOST_ACCT_NO -- 上送主机账户编号
    ,HECKER_NO -- 复核人柜员编号
    ,PRE_AUTH_NO -- 预授权编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,CARD_MED_TYPE_CD -- 卡介质类别代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,IDENTITY_CARD_REG_FLAG -- 身份证注册标志
    ,LATST_EMPLYER_TEL -- 最新工作单位电话
    ,CTZ_CARD_PAY_BIZ_TYPE_CD -- 市民卡缴费业务类型代码
    ,TXN_ORDER_NO -- 交易订单编号
    ,CLEAR_DT -- 清算日期
    ,THIRD_PTY_CLEAR_DT -- 第三方清算日期
    ,SEND_SUCC_FLAG -- 发送成功标志
    ,HOST_CHECK_ENTRY_STATUS_CD -- 主机对账状态代码
    ,TRPRT_CHECK_ENTRY_STATUS_CD -- 三方对账状态代码
    ,HOST_ACCTN_STAUS_CD -- 主机记账状态代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位记账结果
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_ILUS -- 摘要说明
    ,THIRD_PTY_RSPS_CD -- 第三方响应码
    ,THIRD_PTY_RESP_INFO_DESC -- 第三方响应信息描述
    ,FINAL_TXN_DT -- 最后交易日期
    ,TXN_HAPP_TM_CD -- 交易发生时间代码
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,TRPRT_DEAL_STATUS_CD -- 三方处理状态代码
    ,BAT_DEAL_STATUS_CD -- 批量处理状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TXN_DT -- 交易日期
    ,PAY_TXN_TM_STAMP -- 支付交易时间戳
    ,OPER_DT -- 操作日期
    ,TXN_TERM_MODE_CD -- 交易期限方式代码
    ,REM -- 备注
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA_TM;
