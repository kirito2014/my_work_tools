-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-大额支付对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA
--     表中文名：大额支付对账明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：TXN_DT, TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建
--         2024-09-18 00:00:00 陈艺丹 修改表名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA_TM
USING ORC
COMMENT '大额支付对账明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,CHECK_ENTRY_DT -- 对账日期
    ,TXN_AMT -- 交易金额
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,ORIG_TXN_DT -- 原交易日期
    ,ORIG_TXN_SER_NUM -- 原交易序号
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,ORIG_START_BANK_NAME -- 原发起行名称
    ,ORIG_MSG_NO -- 原报文编号
    ,LARGE_AMT_PAY_ENTRY_RESLT_CD -- 大额支付对账结果代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 大额支付对账明细聚合

INSERT INTO TABLE AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,CHECK_ENTRY_DT -- 对账日期
    ,TXN_AMT -- 交易金额
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,ORIG_TXN_DT -- 原交易日期
    ,ORIG_TXN_SER_NUM -- 原交易序号
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,ORIG_START_BANK_NAME -- 原发起行名称
    ,ORIG_MSG_NO -- 原报文编号
    ,LARGE_AMT_PAY_ENTRY_RESLT_CD -- 大额支付对账结果代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.PLAT_DATE AS TXN_DT -- 交易日期
    ,P1.PLAT_SEQ AS TXN_SER_NO -- 交易流水号
    ,P1.BUSI_CLRDATE AS CHECK_ENTRY_DT -- 对账日期
    ,P1.TX_AMT AS TXN_AMT -- 交易金额
    ,P1.SR_FLAG AS ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,P1.SND_BANK AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,P2.BRCH_NAME AS START_BANK_NAME -- 发起行名称
    ,P1.RCV_BANK AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,P3.BRCH_NAME AS RECV_BANK_NAME -- 接收行名称
    ,P1.DC_FLAG AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.PAY_ACTNO AS PAYER_ACCT_NO  -- 付款人账户编号
    ,P1.PYE_ACTNO AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,P1.TX_SEQ AS TXN_SEQ_NO -- 交易序号
    ,P1.MSG_CODE AS MSG_NO -- 报文编号
    ,P1.ORG_AGTDATE AS ORIG_TXN_DT -- 原交易日期
    ,P1.ORG_TXSEQ AS ORIG_TXN_SER_NUM -- 原交易序号
    ,P1.ORG_SNDBANK AS ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,P4.BRCH_NAME AS ORIG_START_BANK_NAME -- 原发起行名称
    ,P1.ORG_MSGCD AS ORIG_MSG_NO -- 原报文编号
    ,P1.CHK_RSLT AS LARGE_AMT_PAY_ENTRY_RESLT_CD -- 大额支付对账结果代码
    ,'ODS_PYMT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_PYMT_T_HVPS_CHKHOST_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_PYMT.ODS_PYMT_T_HVPS_CHKHOST_TF AS P1 -- 大额核心对账平台明细表

LEFT JOIN ODS_PYMT.ODS_PYMT_T_SET_SENDBRCH_TF AS P2 -- 往账机构行号关系表
       ON P1.SND_BANK = P2.BANK_NO AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
LEFT JOIN ODS_PYMT.ODS_PYMT_T_SET_SENDBRCH_TF AS P3 -- 往账机构行号关系表
       ON P1.RCV_BANK = P3.BANK_NO AND P3.PT_DT='${process_date}' AND P3.DEL_F = '0' 
LEFT JOIN ODS_PYMT.ODS_PYMT_T_SET_SENDBRCH_TF AS P4 -- 往账机构行号关系表
       ON P1.ORG_SNDBANK = P4.BANK_NO AND P4.PT_DT='${process_date}' AND P4.DEL_F = '0' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_DT -- 交易日期
    ,TXN_SER_NO -- 交易流水号
    ,CHECK_ENTRY_DT -- 对账日期
    ,TXN_AMT -- 交易金额
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,START_BANK_NAME -- 发起行名称
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_BANK_NAME -- 接收行名称
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,ORIG_TXN_DT -- 原交易日期
    ,ORIG_TXN_SER_NUM -- 原交易序号
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,ORIG_START_BANK_NAME -- 原发起行名称
    ,ORIG_MSG_NO -- 原报文编号
    ,LARGE_AMT_PAY_ENTRY_RESLT_CD -- 大额支付对账结果代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA_TM;
