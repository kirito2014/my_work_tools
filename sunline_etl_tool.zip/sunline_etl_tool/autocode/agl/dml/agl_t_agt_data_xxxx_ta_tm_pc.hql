-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-批量聚合表
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_T_AGT_DATA_XXXX_TA_TM
--     表中文名：批量聚合表
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
DROP TABLE IF EXISTS AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00;
CREATE TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00
USING ORC
COMMENT 'T_AGT_DATA_XXXX类临时表'
OPTIONS (compression 'zstd')
AS
SELECT
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp 
from AGL.AGL_T_AGT_DATA_XXXX_TA_TM where 0=1;
/*truncate temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00;

--1

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
 entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oehcp.ods_oehcp_t_agt_data_981_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL 
select * from ods_oscip.ods_oscip_t_agt_data_601_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL 
select * from ods_oscip.ods_oscip_t_agt_data_608_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL 
select * from ods_oscip.ods_oscip_t_agt_data_611_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL
select * from ods_oscip.ods_oscip_t_agt_data_618_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL
select * from ods_oscip.ods_oscip_t_agt_data_626_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL
select * from ods_oscip.ods_oscip_t_agt_data_631_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL
select * from ods_oscip.ods_oscip_t_agt_data_635_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL
select * from ods_oscip.ods_oscip_t_agt_data_636_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL
select * from ods_oscip.ods_oscip_t_agt_data_637_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;


--2

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_638_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_639_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_640_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_651_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_656_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_661_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_662_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_663_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_664_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_665_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--3

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_666_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_667_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_668_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_669_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_671_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_672_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_675_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_676_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_677_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_678_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--4

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_681_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_682_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_801_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_802_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_803_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_805_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_806_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_807_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_808_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_809_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--5

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_822_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_823_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_825_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_826_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_827_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_828_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_829_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_831_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_851_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_852_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--6

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_853_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_855_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_856_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_857_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_858_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_859_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_861_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_862_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_863_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_865_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--7

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_871_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_872_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_873_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_875_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_876_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_877_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_881_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_882_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_883_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_885_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--8

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_886_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_891_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_892_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_893_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_895_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_896_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_897_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_901_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_902_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_903_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--9

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_905_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_906_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_907_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_908_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_909_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_921_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_922_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_923_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_925_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_926_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--10

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_927_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_931_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_932_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_933_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_935_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_936_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_937_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_938_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_939_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_951_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;

--11

INSERT INTO TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00(
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp           

)
select 
A.entr_no           --代理单位编号                                                   
,A.data_date         --数据装入日期                     
,A.user_no           --用户号                   
,A.sub_seq           --子序号                   
,A.end_date          --缴费截止日期                     
,A.plat_date         --批量提交日期                     
,A.bat_seq           --批号                  
,A.seri_no           --批内顺序号                        
,A.entr_bat_seq      --第三方批号(批次号)                       
,A.file_seq          --文件序号                 
,A.det_stat          --交易状态                 
,A.cust_acct_no1     --客户帐号一               
,A.set_acct_no1     --结算帐号一               
,A.cust_acct_no2     --客户帐号二               
,A.set_acct_no2      --结算帐号二               
,A.rp_flag           --入帐规则判定标志字段                                 
,A.tran_amt          --本金              
,A.late_amt          --滞纳金                
,A.tot_amt           --总金额                    
,A.real_amt          --实际发生额                    
,A.user_name         --用户名               
,A.vou_type          --凭证种类                 
,A.vou_no            --凭证号码                     
,A.acct_name         --帐户名称                 
,A.open_brch         --开户机构                 
,A.acct_bal          --帐户余额                  
,A.entr_date         --计费日期                 
,A.brch_no           --交易机构编码                         
,A.oper_no           --交易柜员                     
,A.tran_date         --交易日期                 
,A.tran_time         --交易时间                 
,A.seq_no            --前置流水号                        
,A.host_seq_no       --主机流水号                   
,A.host_code         --主机返回代码                     
,A.host_msg          --主机返回信息                     
,A.prt_stat          --打印标志                 
,A.prt_oper          --打印柜员                 
,A.prt_date          --打印日期                 
,A.prt_time          --打印时间                 
,A.prt_seq_no        --打印时的前置流水号                            
,A.prt_data          --打印字段                 
,A.last_etl_acg_dt   --last_etl_acg_dt                     
,A.del_f             --del_f                  
,A.etl_timestamp     --etl_timestamp 
FROM (     
SELECT * from ods_oscip.ods_oscip_t_agt_data_961_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_962_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_963_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_965_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_966_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_967_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_968_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_969_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_971_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_982_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_983_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
UNION ALL                                                                                               
select * from ods_oscip.ods_oscip_t_agt_data_985_ta where PT_DT = '${process_date}' AND DEL_F = '0'  
)A ;


/*put data into target table */
INSERT INTO AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM PARTITION(PT_DT = '${process_date}')
SELECT
entr_no           --代理单位编号                                                   
,data_date         --数据装入日期                     
,user_no           --用户号                   
,sub_seq           --子序号                   
,end_date          --缴费截止日期                     
,plat_date         --批量提交日期                     
,bat_seq           --批号                  
,seri_no           --批内顺序号                        
,entr_bat_seq      --第三方批号(批次号)                       
,file_seq          --文件序号                 
,det_stat          --交易状态                 
,cust_acct_no1     --客户帐号一               
,set_acct_no1     --结算帐号一               
,cust_acct_no2     --客户帐号二               
,set_acct_no2      --结算帐号二               
,rp_flag           --入帐规则判定标志字段                                 
,tran_amt          --本金              
,late_amt          --滞纳金                
,tot_amt           --总金额                    
,real_amt          --实际发生额                    
,user_name         --用户名               
,vou_type          --凭证种类                 
,vou_no            --凭证号码                     
,acct_name         --帐户名称                 
,open_brch         --开户机构                 
,acct_bal          --帐户余额                  
,entr_date         --计费日期                 
,brch_no           --交易机构编码                         
,oper_no           --交易柜员                     
,tran_date         --交易日期                 
,tran_time         --交易时间                 
,seq_no            --前置流水号                        
,host_seq_no       --主机流水号                   
,host_code         --主机返回代码                     
,host_msg          --主机返回信息                     
,prt_stat          --打印标志                 
,prt_oper          --打印柜员                 
,prt_date          --打印日期                 
,prt_time          --打印时间                 
,prt_seq_no        --打印时的前置流水号                            
,prt_data          --打印字段                 
,last_etl_acg_dt   --last_etl_acg_dt                     
,del_f             --del_f                  
,etl_timestamp     --etl_timestamp 
FROM AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00
;
/*drop temp table */
DROP TABLE AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM_00;