-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-内部账户交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INTER_ACCT_TXN_DTL_TA
--     表中文名：内部账户交易明细聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：TXN_ACCT_NO, BELONG_GL_ACCT_ORG_NO, TXN_ACCTN_DT, ORIG_TXN_SER_NO, VOUCH_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-02-29 00:00:00 魏丹丹 新增
--         2024-09-07 00:00:00 魏丹丹 修改取数逻辑
--         2024-09-10 00:00:00 魏丹丹 修改会计科目编号取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '内部账户交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_ACCT_NO -- 交易账户编号
    ,BELONG_GL_ACCT_ORG_NO -- 归属总账账务机构编号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,VOUCH_SER_NO -- 传票流水号
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_DT -- 销户日期
    ,ACCT_NAME -- 账户名称
    ,PRIN_OFBS_IN_FLAG_CD -- 本金内外标识代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,RBMRK_CD -- 红蓝字代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,INTER_ACCT_TXN_STATUS_CD -- 内部账户交易状态代码
    ,REAL_TM_ACCT_CATEGORY_CD -- 实时账务类别代码
    ,TXN_DIR_CD -- 交易方向代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,CURR_BAL_DIR_CD -- 当前余额方向代码
    ,TXN_BAL -- 交易余额
    ,VAL_DT -- 起息日期
    ,TXN_DT -- 交易日期
    ,NO -- 套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,TELR_SER_NO -- 柜员流水号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,ORIG_DEBIT_CRDT_TXN_TYPE_CD -- 原借贷交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,RGN_NO -- 地区编号
    ,AGENT_BANK_NO -- 代理行编号
    ,DLGT_BANK_BNKOUTLS_ORG_NO -- 委托行网点机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,TXN_AUTH_TELR_NO_1 -- 交易授权柜员编号1
    ,AUTH_SER_NO -- 授权流水号
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_CLEAR_ORG_NO -- 对方清算机构编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ACCT_REC_TYPE_CD -- 账务记录类型代码
    ,GL_CHECK_ENTRY_FLAG -- 总账对账标志
    ,ORIG_TRAN_CD -- 原交易码
    ,SUMMARY_DESC -- 摘要描述
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 内部账户交易明细聚合

INSERT INTO TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM(
     TXN_ACCT_NO -- 交易账户编号
    ,BELONG_GL_ACCT_ORG_NO -- 归属总账账务机构编号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,VOUCH_SER_NO -- 传票流水号
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_DT -- 销户日期
    ,ACCT_NAME -- 账户名称
    ,PRIN_OFBS_IN_FLAG_CD -- 本金表内外标识代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,RBMRK_CD -- 红蓝字代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,INTER_ACCT_TXN_STATUS_CD -- 内部账户交易状态代码
    ,REAL_TM_ACCT_CATEGORY_CD -- 实时账务类别代码
    ,TXN_DIR_CD -- 交易方向代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,CURR_BAL_DIR_CD -- 当前余额方向代码
    ,TXN_BAL -- 交易余额
    ,VAL_DT -- 起息日期
    ,TXN_DT -- 交易日期
    ,NO -- 套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,TELR_SER_NO -- 柜员流水号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,ORIG_DEBIT_CRDT_TXN_TYPE_CD -- 原借贷交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,RGN_NO -- 地区编号
    ,AGENT_BANK_NO -- 代理行编号
    ,DLGT_BANK_BNKOUTLS_ORG_NO -- 委托行网点机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,TXN_AUTH_TELR_NO_1 -- 交易授权柜员编号1
    ,AUTH_SER_NO -- 授权流水号
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_CLEAR_ORG_NO -- 对方清算机构编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ACCT_REC_TYPE_CD -- 账务记录类型代码
    ,GL_CHECK_ENTRY_FLAG -- 总账对账标志
    ,ORIG_TRAN_CD -- 原交易码
    ,SUMMARY_DESC -- 摘要描述
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.FDCAAC20 AS TXN_ACCT_NO -- 交易账户编号
    ,COALESCE(P2.FGCCBRNO,P3.OBCCBRNO) AS BELONG_GL_ACCT_ORG_NO -- 归属总账账务机构编号
    ,unifiedTime(P1.FDCADATE) AS TXN_ACCTN_DT -- 交易记账日期
    ,P1.FDCATXSN AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.FDCBTXSN AS SUB_TXN_SER_NO -- 子交易流水号
    ,'GM'||REPLACE('${process_date}','-','')||LPAD(ROW_NUMBER()OVER(ORDER BY P1.FDCAAC20 ASC, P1.FDCATXSN ASC),10,'0')
 AS VOUCH_SER_NO -- 传票流水号
    ,unifiedTime(COALESCE(P2.FGCFDATE,P3.OBCBDATE)) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(COALESCE(P2.FGCCDATE,P3.OBCCDATE)) AS CANC_ACCT_DT -- 销户日期
    ,COALESCE(P2.FGCAFLNM,P3.OBCAFLNM) AS ACCT_NAME -- 账户名称
    ,CASE WHEN P1.FDCAAC20 IS NOT NULL AND P1.FDCAAC20<>''  THEN 'I' ELSE 'O' END AS PRIN_OFBS_IN_FLAG_CD -- 本金表内外标识代码
    ,'9' AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.FDCARDBL AS RBMRK_CD -- 红蓝字代码
    ,COALESCE(P4.KHDAACID,T4.KHDAACID) AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.FDCARS1B AS INTER_ACCT_TXN_STATUS_CD -- 内部账户交易状态代码
    ,'1' AS REAL_TM_ACCT_CATEGORY_CD -- 实时账务类别代码
    ,CASE WHEN P1.FDCACDFG IS NULL OR TRIM(P1.FDCACDFG)=''
     THEN ''
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.FDCACDFG)),'')
END AS TXN_DIR_CD -- 交易方向代码
    ,P1.FDCACCYC AS CURR_CD -- 币种代码
    ,P1.FDCAAMT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.FDCBCDFG IS NULL OR TRIM(P1.FDCBCDFG)=''
     THEN ''
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.FDCBCDFG)),'')
END AS CURR_BAL_DIR_CD -- 当前余额方向代码
    ,P1.FDCABAL AS TXN_BAL -- 交易余额
    ,unifiedTime(P1.FDCBDATE) AS VAL_DT -- 起息日期
    ,unifiedTime(P1.FDCCDATE) AS TXN_DT -- 交易日期
    ,P1.FDCASN10 AS NO -- 套号
    ,P1.FDCASN02 AS DWELL_SPC_SER_NO -- 套内序号
    ,P1.FDCANO11 AS TELR_SER_NO -- 柜员流水号
    ,P1.FDCABLTP AS VOCH_CATE_CD -- 凭证种类代码
    ,P1.FDCABLNO AS VOCH_NO -- 凭证号码
    ,P1.FDCAINVT AS ORIG_DEBIT_CRDT_TXN_TYPE_CD -- 原借贷交易类型代码
    ,P1.FDCABRNO AS TXN_ORG_NO -- 交易机构编号
    ,P5.ORCAATDR AS RGN_NO -- 地区编号
    ,P1.FDCBBRNO AS AGENT_BANK_NO -- 代理行编号
    ,P1.FDCCBRNO AS DLGT_BANK_BNKOUTLS_ORG_NO -- 委托行网点机构编号
    ,P1.FDCASTAF AS OPER_TELR_NO -- 操作柜员编号
    ,P1.FDCBSTAF AS CHECKER_NO -- 复核人柜员编号
    ,P1.FDCCSTAF AS TXN_AUTH_TELR_NO_1 -- 交易授权柜员编号1
    ,'' AS AUTH_SER_NO -- 授权流水号
    ,P1.FDCBAC20 AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,'' AS CNTPTY_CLEAR_ORG_NO -- 对方清算机构编号
    ,'' AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,P1.FDCARETY AS ACCT_REC_TYPE_CD -- 账务记录类型代码
    ,'' AS GL_CHECK_ENTRY_FLAG -- 总账对账标志
    ,P1.FDCATXCD AS ORIG_TRAN_CD -- 原交易码
    ,P1.FDCARMRK AS SUMMARY_DESC -- 摘要描述
    ,P1.FDCBRMRK AS REM -- 备注
    ,unifiedTime(P1.FDCDDATE) AS SETUP_DT -- 建立日期
    ,unifiedTime1(P1.FDCASTAM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.FDCDSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P1.FDCEDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime1(P1.FDCBSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.FDCESTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BGFMFDTL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_CORE.ODS_CORE_BGFMFDTL_TA AS P1 -- 内部账明细文件

LEFT JOIN ODS_CORE.ODS_CORE_BGFMFBAL_TA AS P2 -- 表内分户账文件
       ON  P1.FDCAAC20=P2.FGCAAC20 AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BGFMOBAL_TA AS P3 -- 表外分户文件
       ON  P1.FDCAAC20=P3.OBCAAC20 AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BGFDKHDZ_TF AS P4 -- 新会计科目核算码对照表
       ON P4.KHDBACID = SUBSTR(P1.FDCAAC20,9,6) AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BGFDKHDZ_TF AS T4 -- 新会计科目核算码对照表
       ON T4.KHDBACID = SUBSTR(P1.FDCAAC20,10,5) AND T4.PT_DT = '${process_date}' AND T4.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BBFMORGA_TF AS P5 -- 机构信息表
       ON P5.ORCABRNO = P1.FDCABRNO AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON P1.FDCACDFG=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND S1.SRC_TAB_EN_NAME='BGFMFDTL' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='FDCACDFG' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_INTER_ACCT_TXN_DTL_TA'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='TXN_DIR_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 代码转换
       ON P1.FDCBCDFG=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='CORE'  --源系统
AND S2.SRC_TAB_EN_NAME='BGFMFDTL' --来源表英文名  
AND S2.SRC_FIELD_EN_NAME='FDCBCDFG' --来源字段英文名 
AND S2.TARGET_TAB_EN_NAME='AGL_INTER_ACCT_TXN_DTL_TA'  --目标表名   
AND S2.TARGET_FIELD_EN_NAME='CURR_BAL_DIR_CD' --目标字段 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 内部账户交易明细聚合

INSERT INTO TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM(
     TXN_ACCT_NO -- 交易账户编号
    ,BELONG_GL_ACCT_ORG_NO -- 归属总账账务机构编号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,VOUCH_SER_NO -- 传票流水号
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_DT -- 销户日期
    ,ACCT_NAME -- 账户名称
    ,PRIN_OFBS_IN_FLAG_CD -- 本金表内外标识代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,RBMRK_CD -- 红蓝字代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,INTER_ACCT_TXN_STATUS_CD -- 内部账户交易状态代码
    ,REAL_TM_ACCT_CATEGORY_CD -- 实时账务类别代码
    ,TXN_DIR_CD -- 交易方向代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,CURR_BAL_DIR_CD -- 当前余额方向代码
    ,TXN_BAL -- 交易余额
    ,VAL_DT -- 起息日期
    ,TXN_DT -- 交易日期
    ,NO -- 套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,TELR_SER_NO -- 柜员流水号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,ORIG_DEBIT_CRDT_TXN_TYPE_CD -- 原借贷交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,RGN_NO -- 地区编号
    ,AGENT_BANK_NO -- 代理行编号
    ,DLGT_BANK_BNKOUTLS_ORG_NO -- 委托行网点机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,TXN_AUTH_TELR_NO_1 -- 交易授权柜员编号1
    ,AUTH_SER_NO -- 授权流水号
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_CLEAR_ORG_NO -- 对方清算机构编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ACCT_REC_TYPE_CD -- 账务记录类型代码
    ,GL_CHECK_ENTRY_FLAG -- 总账对账标志
    ,ORIG_TRAN_CD -- 原交易码
    ,SUMMARY_DESC -- 摘要描述
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ACCTNO AS TXN_ACCT_NO -- 交易账户编号
    ,P1.BRCHNO AS BELONG_GL_ACCT_ORG_NO -- 归属总账账务机构编号
    ,unifiedTime(P1.TRANDT) AS TXN_ACCTN_DT -- 交易记账日期
    ,P1.TRANSQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,'0' AS SUB_TXN_SER_NO -- 子交易流水号
    ,'WL'||REPLACE('${process_date}','-','')||P1.GLVCSQ AS VOUCH_SER_NO -- 传票流水号
    ,unifiedTime(P2.OPENDT) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P2.CLOSDT) AS CANC_ACCT_DT -- 销户日期
    ,P2.ACCTNA AS ACCT_NAME -- 账户名称
    ,P1.IOFLAG AS PRIN_OFBS_IN_FLAG_CD -- 本金表内外标识代码
    ,CASE WHEN P1.TRANTP='' THEN '9' ELSE P1.TRANTP END AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.ACUTTP AS RBMRK_CD -- 红蓝字代码
    ,P3.SUBJECT_DR AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P1.STATUS AS INTER_ACCT_TXN_STATUS_CD -- 内部账户交易状态代码
    ,P1.CKVCFG AS REAL_TM_ACCT_CATEGORY_CD -- 实时账务类别代码
    ,P1.AMNTCD AS TXN_DIR_CD -- 交易方向代码
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.TRANAM AS TXN_AMT -- 交易金额
    ,P1.BLNCDN AS CURR_BAL_DIR_CD -- 当前余额方向代码
    ,P1.TRANBL AS TXN_BAL -- 交易余额
    ,unifiedTime(P1.TRANDT) AS VAL_DT -- 起息日期
    ,unifiedTime(P1.TRANDT) AS TXN_DT -- 交易日期
    ,P1.STACNO AS NO -- 套号
    ,P1.STACSQ AS DWELL_SPC_SER_NO -- 套内序号
    ,P1.USSQNO AS TELR_SER_NO -- 柜员流水号
    ,P1.CHEQTP AS VOCH_CATE_CD -- 凭证种类代码
    ,P1.CHEQNO AS VOCH_NO -- 凭证号码
    ,'' AS ORIG_DEBIT_CRDT_TXN_TYPE_CD -- 原借贷交易类型代码
    ,P1.ACCTBR AS TXN_ORG_NO -- 交易机构编号
    ,P4.ORCAATDR AS RGN_NO -- 地区编号
    ,'' AS AGENT_BANK_NO -- 代理行编号
    ,'' AS DLGT_BANK_BNKOUTLS_ORG_NO -- 委托行网点机构编号
    ,P1.TRANUS AS OPER_TELR_NO -- 操作柜员编号
    ,P1.CKBSUS AS CHECKER_NO -- 复核人柜员编号
    ,P1.AUTTEL AS TXN_AUTH_TELR_NO_1 -- 交易授权柜员编号1
    ,P1.AUTHSEQ AS AUTH_SER_NO -- 授权流水号
    ,P1.TOACCT AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P1.EXDPAC AS CNTPTY_CLEAR_ORG_NO -- 对方清算机构编号
    ,P1.TOACNA AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,'2' AS ACCT_REC_TYPE_CD -- 账务记录类型代码
    ,P1.BKFNST AS GL_CHECK_ENTRY_FLAG -- 总账对账标志
    ,P1.PRCSCD AS ORIG_TRAN_CD -- 原交易码
    ,P1.SMRYTX AS SUMMARY_DESC -- 摘要描述
    ,'' AS REM -- 备注
    ,unifiedTime(P1.USSRDT) AS SETUP_DT -- 建立日期
    ,unifiedTime1(P1.TIMETM) AS SETUP_TM_STAMP -- 建立时间戳
    ,P1.TRANUS AS SETUP_TELR_NO -- 建立柜员编号
    ,NULL AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime1(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.TRANUS AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_GL_KNS_GLVC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_NAS.ODS_NAS_GL_KNS_GLVC_TF AS P1 -- 传票流水表(表内外)

LEFT JOIN ODS_NAS.ODS_NAS_GL_KNA_ACCT_TF AS P2 -- 内部户账户表
       ON P1.CORPNO=P2.CORPNO AND P1.ACCTNO=P2.ACCTNO AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_GAS.ODS_GAS_CUX_EA_RULES_TF AS P3 -- 总账
       ON P1.BUSINO = P3.PRODUCT  AND P3.SUBJECT_DR<>'' AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BBFMORGA_TF AS P4 -- 机构信息表
       ON P4.ORCABRNO = P1.ACCTBR AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INTER_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_ACCT_NO -- 交易账户编号
    ,BELONG_GL_ACCT_ORG_NO -- 归属总账账务机构编号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,VOUCH_SER_NO -- 传票流水号
    ,OPEN_ACCT_DT -- 开户日期
    ,CANC_ACCT_DT -- 销户日期
    ,ACCT_NAME -- 账户名称
    ,PRIN_OFBS_IN_FLAG_CD -- 本金内外标识代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,RBMRK_CD -- 红蓝字代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,INTER_ACCT_TXN_STATUS_CD -- 内部账户交易状态代码
    ,REAL_TM_ACCT_CATEGORY_CD -- 实时账务类别代码
    ,TXN_DIR_CD -- 交易方向代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,CURR_BAL_DIR_CD -- 当前余额方向代码
    ,TXN_BAL -- 交易余额
    ,VAL_DT -- 起息日期
    ,TXN_DT -- 交易日期
    ,NO -- 套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,TELR_SER_NO -- 柜员流水号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,ORIG_DEBIT_CRDT_TXN_TYPE_CD -- 原借贷交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,RGN_NO -- 地区编号
    ,AGENT_BANK_NO -- 代理行编号
    ,DLGT_BANK_BNKOUTLS_ORG_NO -- 委托行网点机构编号
    ,OPER_TELR_NO -- 操作柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,TXN_AUTH_TELR_NO_1 -- 交易授权柜员编号1
    ,AUTH_SER_NO -- 授权流水号
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_CLEAR_ORG_NO -- 对方清算机构编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ACCT_REC_TYPE_CD -- 账务记录类型代码
    ,GL_CHECK_ENTRY_FLAG -- 总账对账标志
    ,ORIG_TRAN_CD -- 原交易码
    ,SUMMARY_DESC -- 摘要描述
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INTER_ACCT_TXN_DTL_TA_TM;
