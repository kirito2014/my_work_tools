-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-综合前端交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SYN_FORE_END_TXN_DTL_TA
--     表中文名：综合前端交易明细聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：TXN_DT, LOG_ID, BIZ_SER_NO, TELR_TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：保留柜面核心，网络核心的个人定期存款账户的交易明细数据。
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 修改20240722 版本,修改字段名称



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM
USING ORC
COMMENT '综合前端交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_DT -- 交易日期
    ,LOG_ID -- 日志编号
    ,BIZ_SER_NO -- 业务流水号
    ,TELR_TXN_SER_NO -- 柜员交易流水号
    ,CORE_SER_NO -- 核心流水号
    ,LP_ORG_NO -- 法人机构编号
    ,GLOB_SER_NO -- 全局流水号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TRAN_CD -- 交易码
    ,TXN_NAME -- 交易名称
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,SUB_TRADE_CODE -- 子交易代码
    ,SUB_TRADE_NAME -- 子交易名称
    ,NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,MVACCT_FLAG -- 动账标志
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_PROPTY_CD -- 交易性质代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_DEAL_RTN_CD -- 交易处理返回码
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,AUTH_SER_NO -- 授权流水号
    ,AUTH_ORG_NO -- 授权机构编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_TM_STAMP -- 授权时间戳
    ,ACCT_NAME -- 账户名称
    ,ACCT_NO -- 账户编号
    ,OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,VERIFY_SEAL_SER_NO -- 验印流水号
    ,VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,RETURN_INFO_DESC -- 返回信息描述
    ,RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ACCTNG_DT -- 会计日期
    ,IMAGE_SER_NO -- 影像流水号
    ,IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,REQE_CHNL_CD -- 请求渠道代码
    ,REQE_CHNL_SER_NO -- 请求渠道流水号
    ,SERVER_DT -- 服务器日期
    ,SERVER_TM_STAMP -- 服务器时间戳
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO1 -- 经办柜员编号
    ,PRINT_FLAG -- 补打标志
    ,LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_SYN_FORE_END_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,LOG_ID -- 日志编号
    ,BIZ_SER_NO -- 业务流水号
    ,TELR_TXN_SER_NO -- 柜员交易流水号
    ,CORE_SER_NO -- 核心流水号
    ,LP_ORG_NO -- 法人机构编号
    ,GLOB_SER_NO -- 全局流水号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TRAN_CD -- 交易码
    ,TXN_NAME -- 交易名称
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,SUB_TRADE_CODE -- 子交易代码
    ,SUB_TRADE_NAME -- 子交易名称
    ,NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,MVACCT_FLAG -- 动账标志
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_PROPTY_CD -- 交易性质代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_DEAL_RTN_CD -- 交易处理返回码
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,AUTH_SER_NO -- 授权流水号
    ,AUTH_ORG_NO -- 授权机构编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_TM_STAMP -- 授权时间戳
    ,ACCT_NAME -- 账户名称
    ,ACCT_NO -- 账户编号
    ,OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,VERIFY_SEAL_SER_NO -- 验印流水号
    ,VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,RETURN_INFO_DESC -- 返回信息描述
    ,RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ACCTNG_DT -- 会计日期
    ,IMAGE_SER_NO -- 影像流水号
    ,IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,REQE_CHNL_CD -- 请求渠道代码
    ,REQE_CHNL_SER_NO -- 请求渠道流水号
    ,SERVER_DT -- 服务器日期
    ,SERVER_TM_STAMP -- 服务器时间戳
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO1 -- 经办柜员编号
    ,PRINT_FLAG -- 补打标志
    ,LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(T1.WORKDATE) AS TXN_DT -- 交易日期
    ,'' AS LOG_ID -- 日志编号
    ,T1.CSERIALNO AS BIZ_SER_NO -- 业务流水号
    ,T1.FSERIALNO AS TELR_TXN_SER_NO -- 柜员交易流水号
    ,T1.HSERIALNO AS CORE_SER_NO -- 核心流水号
    ,T1.BANKNO AS LP_ORG_NO -- 法人机构编号
    ,'' AS GLOB_SER_NO -- 全局流水号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,T1.ORGID AS TXN_ORG_NO -- 交易机构编号
    ,T1.MENUCODE AS TRAN_CD -- 交易码
    ,T1.MENUCODENAME AS TXN_NAME -- 交易名称
    ,unifiedTime(T1.SERVERTIME) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.AMT AS TXN_AMT -- 交易金额
    ,'' AS SUB_TRADE_CODE -- 子交易代码
    ,'' AS SUB_TRADE_NAME -- 子交易名称
    ,'' AS NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,'' AS SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,'' AS NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,CASE WHEN T1.AMT = '0'
THEN  '1'
else  '0' END AS MVACCT_FLAG -- 动账标志
    ,T1.CCY AS TXN_CURR_CD -- 交易币种代码
    ,T1.TRANTYPE AS TXN_TYPE_CD -- 交易类型代码
    ,T1.TRANCLASS AS TXN_PROPTY_CD -- 交易性质代码
    ,T1.TRANSTATE AS TXN_STATUS_CD -- 交易状态代码
    ,T1.RETCODE AS TXN_DEAL_RTN_CD -- 交易处理返回码
    ,T1.TRANSTELLER AS HANDLE_TELR_NO -- 经办柜员编号
    ,T1.REVIEWTELLER AS CHKR_TELR_NAME -- 复核人柜员名称
    ,'' AS AUTH_SER_NO -- 授权流水号
    ,'' AS AUTH_ORG_NO -- 授权机构编号
    ,T1.AUTHTELLER AS AUTH_TELR_NO -- 授权柜员编号
    ,'' AS AUTH_TM_STAMP -- 授权时间戳
    ,T1.NAME AS ACCT_NAME -- 账户名称
    ,T1.DACCOUNT AS ACCT_NO -- 账户编号
    ,T1.ACCBANKNO AS OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,T1.CACCOUNT AS CNTPTY_ACCT_NO -- 对方账户编号
    ,T1.OPPACCBANKNO AS CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,T1.VOUCHERTYPE AS VOCH_CATE_CD -- 凭证种类代码
    ,T1.VOUCHERNO AS VOCH_NO -- 凭证号码
    ,T1.VERIFYSEQ AS VERIFY_SEAL_SER_NO -- 验印流水号
    ,T1.VERIFYSTATE AS VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,T1.IDCHECKSTATE AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,T1.RETMSG AS RETURN_INFO_DESC -- 返回信息描述
    ,T1.CASHFLAG AS RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,T1.TRANFLAG AS POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,'' AS ACCTNG_DT -- 会计日期
    ,'' AS IMAGE_SER_NO -- 影像流水号
    ,'' AS IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,'' AS REQE_CHNL_CD -- 请求渠道代码
    ,'' AS REQE_CHNL_SER_NO -- 请求渠道流水号
    ,'' AS SERVER_DT -- 服务器日期
    ,'' AS SERVER_TM_STAMP -- 服务器时间戳
    ,'' AS HANDLE_ORG_NO -- 经办机构编号
    ,'' AS HANDLE_TELR_NO1 -- 经办柜员编号
    ,'' AS PRINT_FLAG -- 补打标志
    ,'' AS LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,T1.REMARK AS REM -- 备注
    ,'BTOP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_BTOP_BTOP_TASK_TRADELOG_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_BTOP.ODS_BTOP_BTOP_TASK_TRADELOG_TA AS T1 -- 综合前端流水表

WHERE  t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- None

INSERT INTO TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,LOG_ID -- 日志编号
    ,BIZ_SER_NO -- 业务流水号
    ,TELR_TXN_SER_NO -- 柜员交易流水号
    ,CORE_SER_NO -- 核心流水号
    ,LP_ORG_NO -- 法人机构编号
    ,GLOB_SER_NO -- 全局流水号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TRAN_CD -- 交易码
    ,TXN_NAME -- 交易名称
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,SUB_TRADE_CODE -- 子交易代码
    ,SUB_TRADE_NAME -- 子交易名称
    ,NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,MVACCT_FLAG -- 动账标志
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_PROPTY_CD -- 交易性质代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_DEAL_RTN_CD -- 交易处理返回码
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,AUTH_SER_NO -- 授权流水号
    ,AUTH_ORG_NO -- 授权机构编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_TM_STAMP -- 授权时间戳
    ,ACCT_NAME -- 账户名称
    ,ACCT_NO -- 账户编号
    ,OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,VERIFY_SEAL_SER_NO -- 验印流水号
    ,VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,RETURN_INFO_DESC -- 返回信息描述
    ,RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ACCTNG_DT -- 会计日期
    ,IMAGE_SER_NO -- 影像流水号
    ,IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,REQE_CHNL_CD -- 请求渠道代码
    ,REQE_CHNL_SER_NO -- 请求渠道流水号
    ,SERVER_DT -- 服务器日期
    ,SERVER_TM_STAMP -- 服务器时间戳
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO1 -- 经办柜员编号
    ,PRINT_FLAG -- 补打标志
    ,LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS TXN_DT -- 交易日期
    ,T1.LOG_ID AS LOG_ID -- 日志编号
    ,'' AS BIZ_SER_NO -- 业务流水号
    ,'' AS TELR_TXN_SER_NO -- 柜员交易流水号
    ,T1.CUST_SEQ AS CORE_SER_NO -- 核心流水号
    ,'' AS LP_ORG_NO -- 法人机构编号
    ,T1.GLOBAL_SEQ AS GLOB_SER_NO -- 全局流水号
    ,T1.TRADE_SEQ AS TXN_SER_NO -- 交易流水号
    ,'' AS TXN_ORG_NO -- 交易机构编号
    ,T1.TRADE_CODE AS TRAN_CD -- 交易码
    ,T1.TRADE_NAME AS TXN_NAME -- 交易名称
    ,'' AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_AMT -- 交易金额
    ,T1.SUB_TRADE_CODE AS SUB_TRADE_CODE -- 子交易代码
    ,T1.SUB_TRADE_NAME AS SUB_TRADE_NAME -- 子交易名称
    ,T1.TRADE_TYPE AS NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,T1.TRADE_CLS AS SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,T1.TRADE_MODE AS NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,CASE WHEN T1.AMT = '0'
THEN  '1'
else  '0' END AS MVACCT_FLAG -- 动账标志
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,'' AS TXN_TYPE_CD -- 交易类型代码
    ,'' AS TXN_PROPTY_CD -- 交易性质代码
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS TXN_DEAL_RTN_CD -- 交易处理返回码
    ,'' AS HANDLE_TELR_NO -- 经办柜员编号
    ,'' AS CHKR_TELR_NAME -- 复核人柜员名称
    ,T1.AUTH_SEQ AS AUTH_SER_NO -- 授权流水号
    ,T1.AUTH_ORG_ID AS AUTH_ORG_NO -- 授权机构编号
    ,T1.AUTH_USER_ID AS AUTH_TELR_NO -- 授权柜员编号
    ,unifiedTime(T1.AUTH_TIME) AS AUTH_TM_STAMP -- 授权时间戳
    ,'' AS ACCT_NAME -- 账户名称
    ,'' AS ACCT_NO -- 账户编号
    ,'' AS OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,'' AS CNTPTY_ACCT_NO -- 对方账户编号
    ,'' AS CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,'' AS VOCH_CATE_CD -- 凭证种类代码
    ,'' AS VOCH_NO -- 凭证号码
    ,'' AS VERIFY_SEAL_SER_NO -- 验印流水号
    ,'' AS VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,'' AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,'' AS RETURN_INFO_DESC -- 返回信息描述
    ,'' AS RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,'' AS POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,T1.WORK_DATE AS ACCTNG_DT -- 会计日期
    ,T1.IMAGE_SEQ AS IMAGE_SER_NO -- 影像流水号
    ,T1.IMAGE_DIRS AS IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,T1.REQ_CHANNEL AS REQE_CHNL_CD -- 请求渠道代码
    ,T1.REQ_CHANNEL_SEQ AS REQE_CHNL_SER_NO -- 请求渠道流水号
    ,T1.SERVER_DATE AS SERVER_DT -- 服务器日期
    ,unifiedTime(T1.SERVER_TIME) AS SERVER_TM_STAMP -- 服务器时间戳
    ,T1.TRANS_ORG_ID AS HANDLE_ORG_NO -- 经办机构编号
    ,T1.TRANS_USER_ID AS HANDLE_TELR_NO1 -- 经办柜员编号
    ,T1.IS_REPRINT AS PRINT_FLAG -- 补打标志
    ,unifiedTime(T1.GMT_CREATE) AS LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,unifiedTime(T1.GMT_MODIFIED) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,T1.REMARK AS REM -- 备注
    ,'COP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_COP_LOG_TRADE_BUSS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_COP.ODS_COP_LOG_TRADE_BUSS_TA AS T1 -- 交易公共日志表

WHERE  t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- None

INSERT INTO TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM(
     TXN_DT -- 交易日期
    ,LOG_ID -- 日志编号
    ,BIZ_SER_NO -- 业务流水号
    ,TELR_TXN_SER_NO -- 柜员交易流水号
    ,CORE_SER_NO -- 核心流水号
    ,LP_ORG_NO -- 法人机构编号
    ,GLOB_SER_NO -- 全局流水号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TRAN_CD -- 交易码
    ,TXN_NAME -- 交易名称
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,SUB_TRADE_CODE -- 子交易代码
    ,SUB_TRADE_NAME -- 子交易名称
    ,NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,MVACCT_FLAG -- 动账标志
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_PROPTY_CD -- 交易性质代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_DEAL_RTN_CD -- 交易处理返回码
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,AUTH_SER_NO -- 授权流水号
    ,AUTH_ORG_NO -- 授权机构编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_TM_STAMP -- 授权时间戳
    ,ACCT_NAME -- 账户名称
    ,ACCT_NO -- 账户编号
    ,OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,VERIFY_SEAL_SER_NO -- 验印流水号
    ,VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,RETURN_INFO_DESC -- 返回信息描述
    ,RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ACCTNG_DT -- 会计日期
    ,IMAGE_SER_NO -- 影像流水号
    ,IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,REQE_CHNL_CD -- 请求渠道代码
    ,REQE_CHNL_SER_NO -- 请求渠道流水号
    ,SERVER_DT -- 服务器日期
    ,SERVER_TM_STAMP -- 服务器时间戳
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO1 -- 经办柜员编号
    ,PRINT_FLAG -- 补打标志
    ,LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     unifiedTime(T1.WORKDATE) AS TXN_DT -- 交易日期
    ,'' AS LOG_ID -- 日志编号
    ,T1.CSERIALNO AS BIZ_SER_NO -- 业务流水号
    ,T1.FSERIALNO AS TELR_TXN_SER_NO -- 柜员交易流水号
    ,T1.HSERIALNO AS CORE_SER_NO -- 核心流水号
    ,T1.BANKNO AS LP_ORG_NO -- 法人机构编号
    ,'' AS GLOB_SER_NO -- 全局流水号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,T1.ORGID AS TXN_ORG_NO -- 交易机构编号
    ,T1.MENUCODE AS TRAN_CD -- 交易码
    ,T1.MENUCODENAME AS TXN_NAME -- 交易名称
    ,unifiedTime(T1.SERVERTIME) AS TXN_TM_STAMP -- 交易时间戳
    ,T1.AMT AS TXN_AMT -- 交易金额
    ,'' AS SUB_TRADE_CODE -- 子交易代码
    ,'' AS SUB_TRADE_NAME -- 子交易名称
    ,'' AS NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,'' AS SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,'' AS NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,CASE WHEN T1.AMT = '0'
THEN  '1'
else  '0' END AS MVACCT_FLAG -- 动账标志
    ,T1.CCY AS TXN_CURR_CD -- 交易币种代码
    ,T1.TRANTYPE AS TXN_TYPE_CD -- 交易类型代码
    ,T1.TRANCLASS AS TXN_PROPTY_CD -- 交易性质代码
    ,T1.TRANSTATE AS TXN_STATUS_CD -- 交易状态代码
    ,T1.RETCODE AS TXN_DEAL_RTN_CD -- 交易处理返回码
    ,T1.TRANSTELLER AS HANDLE_TELR_NO -- 经办柜员编号
    ,T1.REVIEWTELLER AS CHKR_TELR_NAME -- 复核人柜员名称
    ,'' AS AUTH_SER_NO -- 授权流水号
    ,'' AS AUTH_ORG_NO -- 授权机构编号
    ,T1.AUTHTELLER AS AUTH_TELR_NO -- 授权柜员编号
    ,'' AS AUTH_TM_STAMP -- 授权时间戳
    ,T1.NAME AS ACCT_NAME -- 账户名称
    ,T1.DACCOUNT AS ACCT_NO -- 账户编号
    ,T1.ACCBANKNO AS OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,T1.CACCOUNT AS CNTPTY_ACCT_NO -- 对方账户编号
    ,T1.OPPACCBANKNO AS CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,T1.VOUCHERTYPE AS VOCH_CATE_CD -- 凭证种类代码
    ,T1.VOUCHERNO AS VOCH_NO -- 凭证号码
    ,T1.VERIFYSEQ AS VERIFY_SEAL_SER_NO -- 验印流水号
    ,T1.VERIFYSTATE AS VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,T1.IDCHECKSTATE AS STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,T1.RETMSG AS RETURN_INFO_DESC -- 返回信息描述
    ,T1.CASHFLAG AS RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,T1.TRANFLAG AS POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,'' AS ACCTNG_DT -- 会计日期
    ,'' AS IMAGE_SER_NO -- 影像流水号
    ,'' AS IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,'' AS REQE_CHNL_CD -- 请求渠道代码
    ,'' AS REQE_CHNL_SER_NO -- 请求渠道流水号
    ,'' AS SERVER_DT -- 服务器日期
    ,'' AS SERVER_TM_STAMP -- 服务器时间戳
    ,'' AS HANDLE_ORG_NO -- 经办机构编号
    ,'' AS HANDLE_TELR_NO1 -- 经办柜员编号
    ,'' AS PRINT_FLAG -- 补打标志
    ,'' AS LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,T1.REMARK AS REM -- 备注
    ,'BMS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_BMS_BTOP_TASK_TRADELOG_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_BMS.ODS_BMS_BTOP_TASK_TRADELOG_TA AS T1 -- 综合前端流水表

WHERE  t1.pt_dt = '${process_date}'
and t1.del_f = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_SYN_FORE_END_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_DT -- 交易日期
    ,LOG_ID -- 日志编号
    ,BIZ_SER_NO -- 业务流水号
    ,TELR_TXN_SER_NO -- 柜员交易流水号
    ,CORE_SER_NO -- 核心流水号
    ,LP_ORG_NO -- 法人机构编号
    ,GLOB_SER_NO -- 全局流水号
    ,TXN_SER_NO -- 交易流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TRAN_CD -- 交易码
    ,TXN_NAME -- 交易名称
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,SUB_TRADE_CODE -- 子交易代码
    ,SUB_TRADE_NAME -- 子交易名称
    ,NEW_CNTER_TXN_TYPE_CD -- 账务交易类型代码
    ,SINGLE_COMB_TXN_IDNT_CD -- 单笔组合交易标识代码
    ,NO_PAPER_TXN_FLAG -- 无纸化交易标志
    ,MVACCT_FLAG -- 动账标志
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,TXN_PROPTY_CD -- 交易性质代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_DEAL_RTN_CD -- 交易处理返回码
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,AUTH_SER_NO -- 授权流水号
    ,AUTH_ORG_NO -- 授权机构编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,AUTH_TM_STAMP -- 授权时间戳
    ,ACCT_NAME -- 账户名称
    ,ACCT_NO -- 账户编号
    ,OBANK_UPP_BANK_NO -- 我行统一支付平台行号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTRA_PAY_BANK_NO -- 对手方支付行号
    ,VOCH_CATE_CD -- 凭证种类代码
    ,VOCH_NO -- 凭证号码
    ,VERIFY_SEAL_SER_NO -- 验印流水号
    ,VERIFY_SEAL_STATUS_DESC -- 验印状态描述
    ,STATUS_VERI_STATUS_CD -- 身份核查状态代码
    ,RETURN_INFO_DESC -- 返回信息描述
    ,RECORD_ALCT_BNKNT_STATUS_CD -- 入账配钞状态代码
    ,POSITIVE_REV_TRAN_CATE_CD -- 正反交易种类代码
    ,ACCTNG_DT -- 会计日期
    ,IMAGE_SER_NO -- 影像流水号
    ,IMAGE_DIRC_TREE_DESC -- 影像目录树
    ,REQE_CHNL_CD -- 请求渠道代码
    ,REQE_CHNL_SER_NO -- 请求渠道流水号
    ,SERVER_DT -- 服务器日期
    ,SERVER_TM_STAMP -- 服务器时间戳
    ,HANDLE_ORG_NO -- 经办机构编号
    ,HANDLE_TELR_NO1 -- 经办柜员编号
    ,PRINT_FLAG -- 补打标志
    ,LOG_CREATE_TM_STAMP -- 日志生成时间戳
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,REM -- 备注
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_SYN_FORE_END_TXN_DTL_TA_TM;
