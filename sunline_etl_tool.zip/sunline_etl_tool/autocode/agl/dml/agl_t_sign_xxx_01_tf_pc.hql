-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-联社公共签约表01
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_T_SIGN_XXX_01_TF
--     表中文名：联社公共签约表01
--     创建日期：2024-04-15 00:00:00
--     主键字段：
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改中间业务库名，增加95组
--         2024-09-10 00:00:00 魏丹丹 新增字段：摘要代码，修改客户内码/签约账户开户机构编号 的取数逻辑，增加1组
--         2024-10-17 00:00:00 魏丹丹 拆分生活缴费签约协议信息聚合 中T_SIGN_XXX，已8开始801-863



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_T_SIGN_XXX_01_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM
USING ORC
COMMENT '联社公共签约表01-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_T_SIGN_XXX_01_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_801_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_801_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_2组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_802_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_802_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_3组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_803_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_803_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_4组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_805_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_805_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_5组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_806_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_806_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_6组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_807_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_807_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_7组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_808_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_808_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_8组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_809_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_809_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_9组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_822_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_822_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_10组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_823_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_823_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_11组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_825_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_825_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_12组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_826_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_826_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_13组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_827_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_827_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_14组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_828_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_828_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_15组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_829_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_829_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_16组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_831_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_831_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_17组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_851_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_851_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_18组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_852_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_852_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_19组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_853_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_853_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_20组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_855_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_855_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_21组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_856_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_856_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_22组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_857_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_857_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_23组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_858_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_858_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_24组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_859_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_859_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_25组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_861_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_861_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_26组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_862_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_862_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_27组）==============
-- 联社公共签约表01

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_863_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_863_TF AS P1 -- 联社公共签约表01

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_T_SIGN_XXX_01_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_T_SIGN_XXX_01_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_T_SIGN_XXX_01_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_T_SIGN_XXX_01_TF_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_T_SIGN_XXX_01_TF_TM;
