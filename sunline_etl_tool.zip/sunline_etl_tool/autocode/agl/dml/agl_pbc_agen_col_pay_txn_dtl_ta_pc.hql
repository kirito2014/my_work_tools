-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-人行代理收付交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA
--     表中文名：人行代理收付交易明细聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：PLAT_SER_NO, PLAT_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：包括经人行转发的缴费交易信息、批量代收付交易信息和实时代收付交易信息
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 20240724 版本同步
--         2024-10-08 00:00:00 王穆军 修改赋值错误



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM
USING ORC
COMMENT '人行代理收付交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_SER_NO -- 平台流水号
    ,PLAT_DT -- 平台日期
    ,LOC_BATCH_NO -- 本地批次编号
    ,PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,TXN_PROD_COST -- 交易工本费
    ,PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,AGT_NO -- 协议编号
    ,PAY_CATEGORY_CD -- 缴费类别代码
    ,PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,PAY_DT -- 缴款日期
    ,PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_TXN_DT -- 渠道交易日期
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CORE_SER_NO -- 核心流水号
    ,CORE_INPUT_SER_NO -- 核心录入流水号
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,HOST_ON_ACCT_DT -- 主机挂账日期
    ,HOST_WRTOFF_SER_NO -- 主机销账序号
    ,THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,PAYER_OPBANK_NAME -- 付款人开户行名称
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,PAYER_DOC_NO -- 付款人证件号码
    ,PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,DEDUCT_NOTICE_NO -- 扣款通知编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,RCD_NOTICE_NO -- 入账通知编号
    ,PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,MSG_VER_CD -- 报文版本代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,PKG_SER_NO -- 包序号
    ,DTL_SER_NO -- 明细序号
    ,PKG_MSG_NO -- 包报文编号
    ,DTL_MSG_NO -- 明细报文编号
    ,DTL_BIZ_REF_NO -- 明细业务参考号
    ,PKG_COMMS_DT -- 包委托日期
    ,DTL_COMMS_DT -- 明细委托日期
    ,AL_CHECK_FLAG -- 已核验标志
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_PKG_MSG_NO -- 原包报文编号
    ,ORIG_DTL_MSG_NO -- 原明细报文编号
    ,ORIG_COMMS_DT -- 原委托日期
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,REFUS_CD -- 拒绝码
    ,REFUS_INFO_DESC -- 拒绝信息描述
    ,NPC_PROC_CD -- NPC处理码
    ,NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,NPC_DEAL_DT -- NPC处理日期
    ,NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,INPUT_TELR_NO -- 录入柜员编号
    ,UPDATE_DT -- 更新日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- None

INSERT INTO TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM(
     PLAT_SER_NO -- 平台流水号
    ,PLAT_DT -- 平台日期
    ,LOC_BATCH_NO -- 本地批次编号
    ,PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,TXN_PROD_COST -- 交易工本费
    ,PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,AGT_NO -- 协议编号
    ,PAY_CATEGORY_CD -- 缴费类别代码
    ,PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,PAY_DT -- 缴款日期
    ,PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_TXN_DT -- 渠道交易日期
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CORE_SER_NO -- 核心流水号
    ,CORE_INPUT_SER_NO -- 核心录入流水号
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,HOST_ON_ACCT_DT -- 主机挂账日期
    ,HOST_WRTOFF_SER_NO -- 主机销账序号
    ,THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,PAYER_OPBANK_NAME -- 付款人开户行名称
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,PAYER_DOC_NO -- 付款人证件号码
    ,PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,DEDUCT_NOTICE_NO -- 扣款通知编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,RCD_NOTICE_NO -- 入账通知编号
    ,PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,MSG_VER_CD -- 报文版本代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,PKG_SER_NO -- 包序号
    ,DTL_SER_NO -- 明细序号
    ,PKG_MSG_NO -- 包报文编号
    ,DTL_MSG_NO -- 明细报文编号
    ,DTL_BIZ_REF_NO -- 明细业务参考号
    ,PKG_COMMS_DT -- 包委托日期
    ,DTL_COMMS_DT -- 明细委托日期
    ,AL_CHECK_FLAG -- 已核验标志
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_PKG_MSG_NO -- 原包报文编号
    ,ORIG_DTL_MSG_NO -- 原明细报文编号
    ,ORIG_COMMS_DT -- 原委托日期
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,REFUS_CD -- 拒绝码
    ,REFUS_INFO_DESC -- 拒绝信息描述
    ,NPC_PROC_CD -- NPC处理码
    ,NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,NPC_DEAL_DT -- NPC处理日期
    ,NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,INPUT_TELR_NO -- 录入柜员编号
    ,UPDATE_DT -- 更新日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.PLAT_SEQ AS PLAT_SER_NO -- 平台流水号
    ,unifiedTime(T1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,'' AS LOC_BATCH_NO -- 本地批次编号
    ,T1.UNI_CODE AS PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,CASE
         WHEN T1.DC_FLAG IS NULL OR TRIM(T1.DC_FLAG) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S2.TARGET_CD_VAL),
                   '@' || TRIM(T1.DC_FLAG),
                   '')
       END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,T1.REG_ID AS ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,T1.CUR_NO AS CURR_CD -- 币种代码
    ,T1.TX_AMT AS TXN_AMT -- 交易金额
    ,T1.TX_FEE AS TXN_COMM_FEE -- 交易手续费
    ,null AS TXN_PROD_COST -- 交易工本费
    ,CASE
         WHEN T1.TRAN_STAT IS NULL OR TRIM(T1.TRAN_STAT) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S3.TARGET_CD_VAL),
                   '@' || TRIM(T1.TRAN_STAT),
                   '')
       END AS PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,'' AS AGT_NO -- 协议编号
    ,T1.PAY_TYPE AS PAY_CATEGORY_CD -- 缴费类别代码
    ,T1.PAY_CNT AS PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,unifiedTime(T1.PAY_DATE) AS PAY_DT -- 缴款日期
    ,T1.PAY_CHN AS PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,T1.BUSI_TYPE AS PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,T1.BUSI_KIND AS PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,'' AS ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,'' AS ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,T1.FEE_CODE AS PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,T1.CHN_NO AS PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,T1.CHN_SEQ AS CHNL_SER_NO -- 渠道流水号
    ,substr(unifiedTime(T1.CHN_DATE),1,10) AS CHNL_TXN_DT -- 渠道交易日期
    ,unifiedTime(T1.CHN_DATE||' '||T1.CHN_TIME) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,T1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,T1.HOST_REGSEQ AS CORE_INPUT_SER_NO -- 核心录入流水号
    ,substr(unifiedTime(T1.HOST_DATE),1,10) AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(T1.HOST_DATE||T1.HOST_TIME) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,T1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,T1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,T1.HOST_RVSSEQ AS HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,T1.HNAC_SEQ AS HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,unifiedTime(T1.HNAC_DATE) AS HOST_ON_ACCT_DT -- 主机挂账日期
    ,T1.CNAC_SEQ AS HOST_WRTOFF_SER_NO -- 主机销账序号
    ,T1.CSP_CSID AS THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,T1.CUS_TYPE AS THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,T1.PAY_ACTNO AS PAYER_ACCT_NO  -- 付款人账户编号
    ,T1.PAY_NAME AS PAYER_ACCT_NAME -- 付款方账户名称
    ,'' AS PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,'' AS PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,T1.PAY_OPNBANK AS PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,'' AS PAYER_OPBANK_NAME -- 付款人开户行名称
    ,T1.PAY_CLRBANK AS PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,T1.PAY_BANK AS PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,T1.PAY_CERTP AS PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,T1.PAY_CERNO AS PAYER_DOC_NO -- 付款人证件号码
    ,T1.ACT_CHGFLAG AS PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,T1.INFO_NO AS DEDUCT_NOTICE_NO -- 扣款通知编号
    ,T1.PYE_ACTNO AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,T1.PYE_NAME AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,'' AS PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,'' AS PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,'' AS PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,T1.PYE_OPNBANK AS PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,'' AS PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,T1.PYE_CLRBANK AS FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,T1.PYE_BANK AS RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,T1.ACT_CHGFLAG AS PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,T1.INFO_NO AS RCD_NOTICE_NO -- 入账通知编号
    ,T1.AGENT_NO AS PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,T1.TX_SEQ AS TXN_SEQ_NO -- 交易序号
    ,T1.MSG_CODE AS MSG_NO -- 报文编号
    ,T1.MSG_KIND AS MSG_VER_CD -- 报文版本代码
    ,CASE WHEN T1.SR_FLAG IS NULL OR TRIM(T1.SR_FLAG) = ''
     THEN  ''
 ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), '@' || TRIM(T1.SR_FLAG), '') END AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,T1.PKG_SEQ AS PKG_SER_NO -- 包序号
    ,'' AS DTL_SER_NO -- 明细序号
    ,T1.MSG_PKGID AS PKG_MSG_NO -- 包报文编号
    ,T1.MSG_TXID AS DTL_MSG_NO -- 明细报文编号
    ,T1.MSG_REFID AS DTL_BIZ_REF_NO -- 明细业务参考号
    ,unifiedTime(T1.PKG_DATE) AS PKG_COMMS_DT -- 包委托日期
    ,unifiedTime(T1.AGT_DATE) AS DTL_COMMS_DT -- 明细委托日期
    ,'' AS AL_CHECK_FLAG -- 已核验标志
    ,T1.SND_BANK AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T1.SND_CLRBANK AS INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,T1.RCV_BANK AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T1.RCV_BANK AS RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,T1.RSP_STAT AS PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,'' AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.ORG_MSGCD AS ORIG_MSG_NO -- 原报文编号
    ,T1.ORG_MSGID AS ORIG_PKG_MSG_NO -- 原包报文编号
    ,'' AS ORIG_DTL_MSG_NO -- 原明细报文编号
    ,NULL AS ORIG_COMMS_DT -- 原委托日期
    ,T1.ORG_SNDBANK AS ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,T1.BUSI_RFSBANK AS REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,T1.BUSI_RFSCODE AS REFUS_CD -- 拒绝码
    ,T1.BUSI_RFSMSG AS REFUS_INFO_DESC -- 拒绝信息描述
    ,T1.BUSI_RETCODE AS NPC_PROC_CD -- NPC处理码
    ,T1.BUSI_RETMSG AS NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,unifiedTime(T1.BUSI_PRCDATE) AS NPC_DEAL_DT -- NPC处理日期
    ,unifiedTime(T1.BUSI_CLRDATE) AS NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,T1.BUSI_STAT AS PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,T1.BRCH_NO AS MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,T1.REG_BRCH AS INPUT_ORG_NO -- 录入机构编号
    ,T1.REG_TELLER AS INPUT_TELR_NO -- 录入柜员编号
    ,substr(unifiedTime(T1.UPD_LSTDATE),1,10) AS UPDATE_DT -- 更新日期
    ,unifiedTime(T1.UPD_LSTDATE||' '||T1.UPD_LSTTIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'01' AS PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,'PYMT' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_PYMT_T_BEPS_PAYBOOK_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'PYMT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_PYMT_T_BEPS_PAYBOOK_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_PYMT.ODS_PYMT_T_BEPS_PAYBOOK_TA AS T1 -- 缴款记录表

LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 币种代码转换
       ON T1.SR_FLAG = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'PYMT'
AND S1.SRC_FIELD_EN_NAME ='SR_FLAG'
AND S1.SRC_TAB_EN_NAME = 'T_BEPS_PAYBOOK'
AND S1.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'MSG_CONT_DIR_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 币种代码转换
       ON T1.DC_FLAG = S2.SRC_CD_VAL 
AND S2.SRC_TAB_LIB_NAME = 'PYMT'
AND S2.SRC_FIELD_EN_NAME ='DC_FLAG'
AND S2.SRC_TAB_EN_NAME = 'T_BEPS_PAYBOOK'
AND S2.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S2.TARGET_FIELD_EN_NAME = 'DEBIT_CRDT_DIR_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S3 -- 币种代码转换
       ON T1.TRAN_STAT = S3.SRC_CD_VAL 
AND S3.SRC_TAB_LIB_NAME = 'PYMT'
AND S3.SRC_FIELD_EN_NAME ='TRAN_STAT'
AND S3.SRC_TAB_EN_NAME = 'T_BEPS_PAYBOOK'
AND S3.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S3.TARGET_FIELD_EN_NAME = 'PBC_AGEN_COL_PAY_TXN_STATUS_CD' 
WHERE T1.PT_DT = '${process_date}'
AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- None

INSERT INTO TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM(
     PLAT_SER_NO -- 平台流水号
    ,PLAT_DT -- 平台日期
    ,LOC_BATCH_NO -- 本地批次编号
    ,PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,TXN_PROD_COST -- 交易工本费
    ,PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,AGT_NO -- 协议编号
    ,PAY_CATEGORY_CD -- 缴费类别代码
    ,PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,PAY_DT -- 缴款日期
    ,PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_TXN_DT -- 渠道交易日期
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CORE_SER_NO -- 核心流水号
    ,CORE_INPUT_SER_NO -- 核心录入流水号
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,HOST_ON_ACCT_DT -- 主机挂账日期
    ,HOST_WRTOFF_SER_NO -- 主机销账序号
    ,THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,PAYER_OPBANK_NAME -- 付款人开户行名称
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,PAYER_DOC_NO -- 付款人证件号码
    ,PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,DEDUCT_NOTICE_NO -- 扣款通知编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,RCD_NOTICE_NO -- 入账通知编号
    ,PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,MSG_VER_CD -- 报文版本代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,PKG_SER_NO -- 包序号
    ,DTL_SER_NO -- 明细序号
    ,PKG_MSG_NO -- 包报文编号
    ,DTL_MSG_NO -- 明细报文编号
    ,DTL_BIZ_REF_NO -- 明细业务参考号
    ,PKG_COMMS_DT -- 包委托日期
    ,DTL_COMMS_DT -- 明细委托日期
    ,AL_CHECK_FLAG -- 已核验标志
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_PKG_MSG_NO -- 原包报文编号
    ,ORIG_DTL_MSG_NO -- 原明细报文编号
    ,ORIG_COMMS_DT -- 原委托日期
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,REFUS_CD -- 拒绝码
    ,REFUS_INFO_DESC -- 拒绝信息描述
    ,NPC_PROC_CD -- NPC处理码
    ,NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,NPC_DEAL_DT -- NPC处理日期
    ,NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,INPUT_TELR_NO -- 录入柜员编号
    ,UPDATE_DT -- 更新日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.PLAT_SEQ AS PLAT_SER_NO -- 平台流水号
    ,unifiedTime(T1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,T1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,T1.UNI_CODE AS PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,CASE
         WHEN T1.DC_FLAG IS NULL OR TRIM(T1.DC_FLAG) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S2.TARGET_CD_VAL),
                   '@' || TRIM(T1.DC_FLAG),
                   '')
       END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,T1.REG_ID AS ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,T1.CUR_NO AS CURR_CD -- 币种代码
    ,T1.TX_AMT AS TXN_AMT -- 交易金额
    ,T1.TX_FEE AS TXN_COMM_FEE -- 交易手续费
    ,T1.TX_PNS AS TXN_PROD_COST -- 交易工本费
    ,T1.TRAN_STAT AS PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,T1.CNTR_NO AS AGT_NO -- 协议编号
    ,'' AS PAY_CATEGORY_CD -- 缴费类别代码
    ,NULL AS PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,NULL AS PAY_DT -- 缴款日期
    ,'' AS PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,T1.BUSI_TYPE AS PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,T1.BUSI_KIND AS PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,T1.ORG_BUSITP AS ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,T1.ORG_BUSIKD AS ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,'' AS PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,T1.CHN_NO AS PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,T1.CHN_SEQ AS CHNL_SER_NO -- 渠道流水号
    ,substr(unifiedTime(T1.CHN_DATE),1,10) AS CHNL_TXN_DT -- 渠道交易日期
    ,unifiedTime(T1.CHN_DATE||' '||T1.CHN_TIME) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,T1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,'' AS CORE_INPUT_SER_NO -- 核心录入流水号
    ,substr(unifiedTime(T1.HOST_DATE),1,10) AS HOST_TXN_DT -- 主机交易日期
    ,NULL AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,T1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,T1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,T1.HOST_RVSSEQ AS HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,T1.HNAC_SEQ AS HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,unifiedTime(T1.HNAC_DATE) AS HOST_ON_ACCT_DT -- 主机挂账日期
    ,'' AS HOST_WRTOFF_SER_NO -- 主机销账序号
    ,T1.PAY_CUSCODE AS THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,'' AS THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,T1.PAY_ACTNO AS PAYER_ACCT_NO  -- 付款人账户编号
    ,T1.PAY_NAME AS PAYER_ACCT_NAME -- 付款方账户名称
    ,T1.PAY_TRNACTNO AS PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,T1.PAY_TRNAME AS PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,T1.PAY_OPNBANK AS PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,T1.PAY_BANKNM AS PAYER_OPBANK_NAME -- 付款人开户行名称
    ,T1.PAY_CLRBANK AS PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,T1.PAY_BANK AS PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,T1.PAY_CERNO AS PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,T1.PAY_CERTP AS PAYER_DOC_NO -- 付款人证件号码
    ,T1.PAY_CHGFLAG AS PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,T1.PAY_CHGSEQ AS DEDUCT_NOTICE_NO -- 扣款通知编号
    ,T1.PYE_ACTNO AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,T1.PYE_NAME AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,T1.PYE_TRNACTNO AS PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,T1.PYE_TRNAME AS PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,T1.PYE_ACTCODE AS PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,T1.PYE_OPNBANK AS PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,T1.PYE_BANKNM AS PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,T1.PYE_CLRBANK AS FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,T1.PYE_BANK AS RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,T1.PYE_CHGFLAG AS PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,T1.PYE_CHGSEQ AS RCD_NOTICE_NO -- 入账通知编号
    ,'' AS PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,T1.TX_SEQ AS TXN_SEQ_NO -- 交易序号
    ,T1.MSG_CODE AS MSG_NO -- 报文编号
    ,T1.MSG_KIND AS MSG_VER_CD -- 报文版本代码
    ,CASE WHEN T1.SR_FLAG IS NULL OR TRIM(T1.SR_FLAG) = ''
 THEN  ''
ELSE  COALESCE(TRIM(S1.TARGET_CD_VAL), '@' || TRIM(T1.SR_FLAG), '') END AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,T1.PKG_SEQ AS PKG_SER_NO -- 包序号
    ,T1.LST_SEQ AS DTL_SER_NO -- 明细序号
    ,T1.MSG_PKGID AS PKG_MSG_NO -- 包报文编号
    ,T1.MSG_TXID AS DTL_MSG_NO -- 明细报文编号
    ,T1.MSG_REFID AS DTL_BIZ_REF_NO -- 明细业务参考号
    ,unifiedTime(T1.PKG_DATE) AS PKG_COMMS_DT -- 包委托日期
    ,unifiedTime(T1.AGT_DATE) AS DTL_COMMS_DT -- 明细委托日期
    ,T1.AGC_FLAG AS AL_CHECK_FLAG -- 已核验标志
    ,T1.SND_BANK AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T1.SND_CLRBANK AS INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,T1.RCV_BANK AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T1.RCV_BANK AS RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,T1.RSP_STAT AS PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,T1.ORG_TXSEQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.ORG_MSGCD AS ORIG_MSG_NO -- 原报文编号
    ,T1.ORG_MSGID AS ORIG_PKG_MSG_NO -- 原包报文编号
    ,T1.ORG_TXID AS ORIG_DTL_MSG_NO -- 原明细报文编号
    ,unifiedTime(T1.ORG_AGTDATE) AS ORIG_COMMS_DT -- 原委托日期
    ,T1.ORG_SNDBANK AS ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,T1.BUSI_RFSBANK AS REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,T1.BUSI_RFSCODE AS REFUS_CD -- 拒绝码
    ,T1.BUSI_RFSMSG AS REFUS_INFO_DESC -- 拒绝信息描述
    ,T1.BUSI_RETCODE AS NPC_PROC_CD -- NPC处理码
    ,T1.BUSI_RETMSG AS NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,unifiedTime(T1.BUSI_PRCDATE) AS NPC_DEAL_DT -- NPC处理日期
    ,unifiedTime(T1.BUSI_CLRDATE) AS NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,T1.BUSI_STAT AS PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,T1.BRCH_NO AS MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,T1.REG_BRCH AS INPUT_ORG_NO -- 录入机构编号
    ,T1.REG_TELLER AS INPUT_TELR_NO -- 录入柜员编号
    ,substr(unifiedTime(T1.UPD_LSTDATE),1,10) AS UPDATE_DT -- 更新日期
    ,unifiedTime(T1.UPD_LSTDATE||' '||T1.UPD_LSTTIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'02' AS PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,'PYMT' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_PYMT_T_BEPS_DSFBOOK_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'PYMT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_PYMT_T_BEPS_DSFBOOK_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_PYMT.ODS_PYMT_T_BEPS_DSFBOOK_TA AS T1 -- 代收付明细表

LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 币种代码转换
       ON T1.SR_FLAG = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'PYMT'
AND S1.SRC_FIELD_EN_NAME ='SR_FLAG'
AND S1.SRC_TAB_EN_NAME = 'T_BEPS_DSFBOOK'
AND S1.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'MSG_CONT_DIR_CD' 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 币种代码转换
       ON T1.DC_FLAG = S2.SRC_CD_VAL 
AND S2.SRC_TAB_LIB_NAME = 'PYMT'
AND S2.SRC_FIELD_EN_NAME ='DC_FLAG'
AND S2.SRC_TAB_EN_NAME = 'T_BEPS_DSFBOOK'
AND S2.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S2.TARGET_FIELD_EN_NAME = 'DEBIT_CRDT_DIR_CD' 
WHERE T1.PT_DT = '${process_date}'
AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- None

INSERT INTO TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM(
     PLAT_SER_NO -- 平台流水号
    ,PLAT_DT -- 平台日期
    ,LOC_BATCH_NO -- 本地批次编号
    ,PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,TXN_PROD_COST -- 交易工本费
    ,PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,AGT_NO -- 协议编号
    ,PAY_CATEGORY_CD -- 缴费类别代码
    ,PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,PAY_DT -- 缴款日期
    ,PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_TXN_DT -- 渠道交易日期
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CORE_SER_NO -- 核心流水号
    ,CORE_INPUT_SER_NO -- 核心录入流水号
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,HOST_ON_ACCT_DT -- 主机挂账日期
    ,HOST_WRTOFF_SER_NO -- 主机销账序号
    ,THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,PAYER_OPBANK_NAME -- 付款人开户行名称
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,PAYER_DOC_NO -- 付款人证件号码
    ,PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,DEDUCT_NOTICE_NO -- 扣款通知编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,RCD_NOTICE_NO -- 入账通知编号
    ,PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,MSG_VER_CD -- 报文版本代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,PKG_SER_NO -- 包序号
    ,DTL_SER_NO -- 明细序号
    ,PKG_MSG_NO -- 包报文编号
    ,DTL_MSG_NO -- 明细报文编号
    ,DTL_BIZ_REF_NO -- 明细业务参考号
    ,PKG_COMMS_DT -- 包委托日期
    ,DTL_COMMS_DT -- 明细委托日期
    ,AL_CHECK_FLAG -- 已核验标志
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_PKG_MSG_NO -- 原包报文编号
    ,ORIG_DTL_MSG_NO -- 原明细报文编号
    ,ORIG_COMMS_DT -- 原委托日期
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,REFUS_CD -- 拒绝码
    ,REFUS_INFO_DESC -- 拒绝信息描述
    ,NPC_PROC_CD -- NPC处理码
    ,NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,NPC_DEAL_DT -- NPC处理日期
    ,NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,INPUT_TELR_NO -- 录入柜员编号
    ,UPDATE_DT -- 更新日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.PLAT_SEQ AS PLAT_SER_NO -- 平台流水号
    ,unifiedTime(T1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,T1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,T1.UNI_CODE AS PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,CASE
         WHEN T1.DC_FLAG IS NULL OR TRIM(T1.DC_FLAG) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S2.TARGET_CD_VAL),
                   '@' || TRIM(T1.DC_FLAG),
                   '')
       END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,T1.REG_ID AS ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,T1.CUR_NO AS CURR_CD -- 币种代码
    ,T1.TX_AMT AS TXN_AMT -- 交易金额
    ,T1.TX_FEE AS TXN_COMM_FEE -- 交易手续费
    ,T1.TX_PNS AS TXN_PROD_COST -- 交易工本费
    ,T1.TRAN_STAT AS PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,T1.CNTR_NO AS AGT_NO -- 协议编号
    ,'' AS PAY_CATEGORY_CD -- 缴费类别代码
    ,NULL AS PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,NULL AS PAY_DT -- 缴款日期
    ,'' AS PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,T1.BUSI_TYPE AS PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,T1.BUSI_KIND AS PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,T1.ORG_BUSITP AS ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,T1.ORG_BUSIKD AS ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,'' AS PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,T1.CHN_NO AS PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,T1.CHN_SEQ AS CHNL_SER_NO -- 渠道流水号
    ,substr(unifiedTime(T1.CHN_DATE),1,10) AS CHNL_TXN_DT -- 渠道交易日期
    ,unifiedTime(T1.CHN_DATE||' '||T1.CHN_TIME) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,T1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,'' AS CORE_INPUT_SER_NO -- 核心录入流水号
    ,substr(unifiedTime(T1.HOST_DATE),1,10) AS HOST_TXN_DT -- 主机交易日期
    ,NULL AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,T1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,T1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,T1.HOST_RVSSEQ AS HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,T1.HNAC_SEQ AS HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,unifiedTime(T1.HNAC_DATE) AS HOST_ON_ACCT_DT -- 主机挂账日期
    ,'' AS HOST_WRTOFF_SER_NO -- 主机销账序号
    ,T1.PAY_CUSCODE AS THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,'' AS THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,T1.PAY_ACTNO AS PAYER_ACCT_NO  -- 付款人账户编号
    ,T1.PAY_NAME AS PAYER_ACCT_NAME -- 付款方账户名称
    ,T1.PAY_TRNACTNO AS PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,T1.PAY_TRNAME AS PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,T1.PAY_OPNBANK AS PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,T1.PAY_BANKNM AS PAYER_OPBANK_NAME -- 付款人开户行名称
    ,T1.PAY_CLRBANK AS PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,T1.PAY_BANK AS PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,T1.PAY_CERNO AS PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,T1.PAY_CERTP AS PAYER_DOC_NO -- 付款人证件号码
    ,T1.PAY_CHGFLAG AS PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,T1.PAY_CHGSEQ AS DEDUCT_NOTICE_NO -- 扣款通知编号
    ,T1.PYE_ACTNO AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,T1.PYE_NAME AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,T1.PYE_TRNACTNO AS PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,T1.PYE_TRNAME AS PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,T1.PYE_ACTCODE AS PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,T1.PYE_OPNBANK AS PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,T1.PYE_BANKNM AS PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,T1.PYE_CLRBANK AS FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,T1.PYE_BANK AS RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,T1.PYE_CHGFLAG AS PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,T1.PYE_CHGSEQ AS RCD_NOTICE_NO -- 入账通知编号
    ,'' AS PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,T1.TX_SEQ AS TXN_SEQ_NO -- 交易序号
    ,T1.MSG_CODE AS MSG_NO -- 报文编号
    ,T1.MSG_KIND AS MSG_VER_CD -- 报文版本代码
    ,CASE
         WHEN T1.SR_FLAG IS NULL OR TRIM(T1.SR_FLAG) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.SR_FLAG),
                   '')
       END AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,T1.PKG_SEQ AS PKG_SER_NO -- 包序号
    ,T1.LST_SEQ AS DTL_SER_NO -- 明细序号
    ,T1.MSG_PKGID AS PKG_MSG_NO -- 包报文编号
    ,T1.MSG_TXID AS DTL_MSG_NO -- 明细报文编号
    ,T1.MSG_REFID AS DTL_BIZ_REF_NO -- 明细业务参考号
    ,unifiedTime(T1.PKG_DATE) AS PKG_COMMS_DT -- 包委托日期
    ,unifiedTime(T1.AGT_DATE) AS DTL_COMMS_DT -- 明细委托日期
    ,T1.AGC_FLAG AS AL_CHECK_FLAG -- 已核验标志
    ,T1.SND_BANK AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T1.SND_CLRBANK AS INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,T1.RCV_BANK AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T1.RCV_BANK AS RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,T1.RSP_STAT AS PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,T1.ORG_TXSEQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.ORG_MSGCD AS ORIG_MSG_NO -- 原报文编号
    ,T1.ORG_MSGID AS ORIG_PKG_MSG_NO -- 原包报文编号
    ,T1.ORG_TXID AS ORIG_DTL_MSG_NO -- 原明细报文编号
    ,unifiedTime(T1.ORG_AGTDATE) AS ORIG_COMMS_DT -- 原委托日期
    ,T1.ORG_SNDBANK AS ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,T1.BUSI_RFSBANK AS REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,T1.BUSI_RFSCODE AS REFUS_CD -- 拒绝码
    ,T1.BUSI_RFSMSG AS REFUS_INFO_DESC -- 拒绝信息描述
    ,T1.BUSI_RETCODE AS NPC_PROC_CD -- NPC处理码
    ,T1.BUSI_RETMSG AS NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,unifiedTime(T1.BUSI_PRCDATE) AS NPC_DEAL_DT -- NPC处理日期
    ,unifiedTime(T1.BUSI_CLRDATE) AS NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,T1.BUSI_STAT AS PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,T1.BRCH_NO AS MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,T1.REG_BRCH AS INPUT_ORG_NO -- 录入机构编号
    ,T1.REG_TELLER AS INPUT_TELR_NO -- 录入柜员编号
    ,substr(unifiedTime(T1.UPD_LSTDATE),1,10) AS UPDATE_DT -- 更新日期
    ,unifiedTime(T1.UPD_LSTDATE||' '||T1.UPD_LSTTIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'03' AS PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,'PYMT' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_PYMT_T_BEPS_PLDSBOOK_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'PYMT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_PYMT_T_BEPS_PLDSBOOK_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_PYMT.ODS_PYMT_T_BEPS_PLDSBOOK_TA AS T1 -- 批量代收明细表

LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 币种代码转换
       ON T1.SR_FLAG = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'PYMT'
AND S1.SRC_FIELD_EN_NAME ='SR_FLAG'
AND S1.SRC_TAB_EN_NAME = 'T_BEPS_PLDSBOOK'
AND S1.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'MSG_CONT_DIR_CD'
 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 币种代码转换
       ON T1.DC_FLAG = S2.SRC_CD_VAL 
AND S2.SRC_TAB_LIB_NAME = 'PYMT'
AND S2.SRC_FIELD_EN_NAME ='DC_FLAG'
AND S2.SRC_TAB_EN_NAME = 'T_BEPS_PLDSBOOK'
AND S2.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S2.TARGET_FIELD_EN_NAME = 'DEBIT_CRDT_DIR_CD' 
WHERE T1.PT_DT = '${process_date}'
AND T1.DEL_F = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- None

INSERT INTO TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM(
     PLAT_SER_NO -- 平台流水号
    ,PLAT_DT -- 平台日期
    ,LOC_BATCH_NO -- 本地批次编号
    ,PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,TXN_PROD_COST -- 交易工本费
    ,PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,AGT_NO -- 协议编号
    ,PAY_CATEGORY_CD -- 缴费类别代码
    ,PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,PAY_DT -- 缴款日期
    ,PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_TXN_DT -- 渠道交易日期
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CORE_SER_NO -- 核心流水号
    ,CORE_INPUT_SER_NO -- 核心录入流水号
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,HOST_ON_ACCT_DT -- 主机挂账日期
    ,HOST_WRTOFF_SER_NO -- 主机销账序号
    ,THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,PAYER_OPBANK_NAME -- 付款人开户行名称
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,PAYER_DOC_NO -- 付款人证件号码
    ,PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,DEDUCT_NOTICE_NO -- 扣款通知编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,RCD_NOTICE_NO -- 入账通知编号
    ,PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,MSG_VER_CD -- 报文版本代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,PKG_SER_NO -- 包序号
    ,DTL_SER_NO -- 明细序号
    ,PKG_MSG_NO -- 包报文编号
    ,DTL_MSG_NO -- 明细报文编号
    ,DTL_BIZ_REF_NO -- 明细业务参考号
    ,PKG_COMMS_DT -- 包委托日期
    ,DTL_COMMS_DT -- 明细委托日期
    ,AL_CHECK_FLAG -- 已核验标志
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_PKG_MSG_NO -- 原包报文编号
    ,ORIG_DTL_MSG_NO -- 原明细报文编号
    ,ORIG_COMMS_DT -- 原委托日期
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,REFUS_CD -- 拒绝码
    ,REFUS_INFO_DESC -- 拒绝信息描述
    ,NPC_PROC_CD -- NPC处理码
    ,NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,NPC_DEAL_DT -- NPC处理日期
    ,NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,INPUT_TELR_NO -- 录入柜员编号
    ,UPDATE_DT -- 更新日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     T1.PLAT_SEQ AS PLAT_SER_NO -- 平台流水号
    ,unifiedTime(T1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,T1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,T1.UNI_CODE AS PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,CASE
         WHEN T1.DC_FLAG IS NULL OR TRIM(T1.DC_FLAG) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S2.TARGET_CD_VAL),
                   '@' || TRIM(T1.DC_FLAG),
                   '')
       END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,T1.REG_ID AS ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,T1.CUR_NO AS CURR_CD -- 币种代码
    ,T1.TX_AMT AS TXN_AMT -- 交易金额
    ,T1.TX_FEE AS TXN_COMM_FEE -- 交易手续费
    ,T1.TX_PNS AS TXN_PROD_COST -- 交易工本费
    ,T1.TRAN_STAT AS PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,T1.CNTR_NO AS AGT_NO -- 协议编号
    ,'' AS PAY_CATEGORY_CD -- 缴费类别代码
    ,NULL AS PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,NULL AS PAY_DT -- 缴款日期
    ,'' AS PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,T1.BUSI_TYPE AS PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,T1.BUSI_KIND AS PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,T1.ORG_BUSITP AS ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,T1.ORG_BUSIKD AS ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,'' AS PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,T1.CHN_NO AS PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,T1.CHN_SEQ AS CHNL_SER_NO -- 渠道流水号
    ,substr(unifiedTime(T1.CHN_DATE),1,10) AS CHNL_TXN_DT -- 渠道交易日期
    ,unifiedTime(T1.CHN_DATE||' '||T1.CHN_TIME) AS CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,T1.HOST_SEQ AS CORE_SER_NO -- 核心流水号
    ,'' AS CORE_INPUT_SER_NO -- 核心录入流水号
    ,substr(unifiedTime(T1.HOST_DATE),1,10) AS HOST_TXN_DT -- 主机交易日期
    ,NULL AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,T1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,T1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,T1.HOST_RVSSEQ AS HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,T1.HNAC_SEQ AS HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,unifiedTime(T1.HNAC_DATE) AS HOST_ON_ACCT_DT -- 主机挂账日期
    ,'' AS HOST_WRTOFF_SER_NO -- 主机销账序号
    ,T1.PAY_CUSCODE AS THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,'' AS THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,T1.PAY_ACTNO AS PAYER_ACCT_NO  -- 付款人账户编号
    ,T1.PAY_NAME AS PAYER_ACCT_NAME -- 付款方账户名称
    ,T1.PAY_TRNACTNO AS PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,T1.PAY_TRNAME AS PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,T1.PAY_OPNBANK AS PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,T1.PAY_BANKNM AS PAYER_OPBANK_NAME -- 付款人开户行名称
    ,T1.PAY_CLRBANK AS PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,T1.PAY_BANK AS PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,T1.PAY_CERNO AS PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,T1.PAY_CERTP AS PAYER_DOC_NO -- 付款人证件号码
    ,T1.PAY_CHGFLAG AS PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,T1.PAY_CHGSEQ AS DEDUCT_NOTICE_NO -- 扣款通知编号
    ,T1.PYE_ACTNO AS PAYEE_ACCT_NO  -- 收款人账户编号
    ,T1.PYE_NAME AS PAYEE_ACCT_NAME -- 收款方账户名称
    ,T1.PYE_TRNACTNO AS PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,T1.PYE_TRNAME AS PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,T1.PYE_ACTCODE AS PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,T1.PYE_OPNBANK AS PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,T1.PYE_BANKNM AS PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,T1.PYE_CLRBANK AS FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,T1.PYE_BANK AS RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,T1.PYE_CHGFLAG AS PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,T1.PYE_CHGSEQ AS RCD_NOTICE_NO -- 入账通知编号
    ,'' AS PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,T1.TX_SEQ AS TXN_SEQ_NO -- 交易序号
    ,T1.MSG_CODE AS MSG_NO -- 报文编号
    ,T1.MSG_KIND AS MSG_VER_CD -- 报文版本代码
    ,CASE
         WHEN T1.SR_FLAG IS NULL OR TRIM(T1.SR_FLAG) = '' THEN
          ''
         ELSE
          COALESCE(TRIM(S1.TARGET_CD_VAL),
                   '@' || TRIM(T1.SR_FLAG),
                   '')
       END AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,T1.PKG_SEQ AS PKG_SER_NO -- 包序号
    ,T1.LST_SEQ AS DTL_SER_NO -- 明细序号
    ,T1.MSG_PKGID AS PKG_MSG_NO -- 包报文编号
    ,T1.MSG_TXID AS DTL_MSG_NO -- 明细报文编号
    ,T1.MSG_REFID AS DTL_BIZ_REF_NO -- 明细业务参考号
    ,unifiedTime(T1.PKG_DATE) AS PKG_COMMS_DT -- 包委托日期
    ,unifiedTime(T1.AGT_DATE) AS DTL_COMMS_DT -- 明细委托日期
    ,T1.AGC_FLAG AS AL_CHECK_FLAG -- 已核验标志
    ,T1.SND_BANK AS START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,T1.SND_CLRBANK AS INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,T1.RCV_BANK AS RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,T1.RCV_BANK AS RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,T1.RSP_STAT AS PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,T1.ORG_TXSEQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,T1.ORG_MSGCD AS ORIG_MSG_NO -- 原报文编号
    ,T1.ORG_MSGID AS ORIG_PKG_MSG_NO -- 原包报文编号
    ,T1.ORG_TXID AS ORIG_DTL_MSG_NO -- 原明细报文编号
    ,unifiedTime(T1.ORG_AGTDATE) AS ORIG_COMMS_DT -- 原委托日期
    ,T1.ORG_SNDBANK AS ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,T1.BUSI_RFSBANK AS REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,T1.BUSI_RFSCODE AS REFUS_CD -- 拒绝码
    ,T1.BUSI_RFSMSG AS REFUS_INFO_DESC -- 拒绝信息描述
    ,T1.BUSI_RETCODE AS NPC_PROC_CD -- NPC处理码
    ,T1.BUSI_RETMSG AS NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,unifiedTime(T1.BUSI_PRCDATE) AS NPC_DEAL_DT -- NPC处理日期
    ,unifiedTime(T1.BUSI_CLRDATE) AS NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,T1.BUSI_STAT AS PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,T1.BRCH_NO AS MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,T1.REG_BRCH AS INPUT_ORG_NO -- 录入机构编号
    ,T1.REG_TELLER AS INPUT_TELR_NO -- 录入柜员编号
    ,substr(unifiedTime(T1.UPD_LSTDATE),1,10) AS UPDATE_DT -- 更新日期
    ,unifiedTime(T1.UPD_LSTDATE||' '||T1.UPD_LSTTIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'04' AS PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,'PYMT' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'ODS_PYMT_T_BEPS_PLDFBOOK_TA' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'PYMT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_PYMT_T_BEPS_PLDFBOOK_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_PYMT.ODS_PYMT_T_BEPS_PLDFBOOK_TA AS T1 -- 批量代付明细表

LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 币种代码转换
       ON T1.SR_FLAG = S1.SRC_CD_VAL 
AND S1.SRC_TAB_LIB_NAME = 'PYMT'
AND S1.SRC_FIELD_EN_NAME ='SR_FLAG'
AND S1.SRC_TAB_EN_NAME = 'T_BEPS_PLDFBOOK'
AND S1.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S1.TARGET_FIELD_EN_NAME = 'MSG_CONT_DIR_CD'
 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 币种代码转换
       ON T1.DC_FLAG = S2.SRC_CD_VAL 
AND S2.SRC_TAB_LIB_NAME = 'PYMT'
AND S2.SRC_FIELD_EN_NAME ='DC_FLAG'
AND S2.SRC_TAB_EN_NAME = 'T_BEPS_PLDFBOOK'
AND S2.TARGET_TAB_EN_NAME='AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA'
AND S2.TARGET_FIELD_EN_NAME = 'DEBIT_CRDT_DIR_CD' 
WHERE T1.PT_DT = '${process_date}'
AND T1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_SER_NO -- 平台流水号
    ,PLAT_DT -- 平台日期
    ,LOC_BATCH_NO -- 本地批次编号
    ,PBC_NET_IN_ORG_NO -- 人行入网机构编号
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCESS_POINT_DIST_CD -- 接入点行政区划代码
    ,CURR_CD -- 币种代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,TXN_PROD_COST -- 交易工本费
    ,PBC_AGEN_COL_PAY_TXN_STATUS_CD -- 人行代理收付交易状态代码
    ,AGT_NO -- 协议编号
    ,PAY_CATEGORY_CD -- 缴费类别代码
    ,PAY_INFO_CNT_VAL -- 缴费信息数目值
    ,PAY_DT -- 缴款日期
    ,PBC_PAY_CHNL_CD -- 人行缴款渠道代码
    ,PBC_BIZ_MCLS_CD -- 人行业务大类代码
    ,PBC_BIZ_SCLS_CD -- 人行业务小类代码
    ,ORIG_PBC_BIZ_MCLS_CD -- 原人行业务大类代码
    ,ORIG_PBC_BIZ_SCLS_CD -- 原人行业务小类代码
    ,PBC_AGEN_COL_PAY_PAY_TYPE_CD -- 人行代理收付缴费类型代码
    ,PBC_AGEN_COL_PAY_CHNL_CD -- 人行代理收付渠道代码
    ,CHNL_SER_NO -- 渠道流水号
    ,CHNL_TXN_DT -- 渠道交易日期
    ,CHNL_TXN_TM_STAMP -- 渠道交易时间戳
    ,CORE_SER_NO -- 核心流水号
    ,CORE_INPUT_SER_NO -- 核心录入流水号
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,HOST_STRK_BAL_SER_NO -- 主机冲抹账流水号
    ,HOST_ON_ACCT_SER_NO -- 主机挂账序号
    ,HOST_ON_ACCT_DT -- 主机挂账日期
    ,HOST_WRTOFF_SER_NO -- 主机销账序号
    ,THIRD_PTY_PAY_CUST_NO -- 第三方付款客户编号
    ,THIRD_PTY_PAY_CUST_NO_TYPE_CD -- 第三方付款客户编号类型代码
    ,PAYER_ACCT_NO  -- 付款人账户编号
    ,PAYER_ACCT_NAME -- 付款方账户名称
    ,PAYER_INTER_STL_ACCT_NO -- 付款方内部结算账户编号
    ,PAYER_INTER_STL_ACCT_NAME -- 付款方内部结算账户名称
    ,PAYER_OPBANK_ACCT_CNAPS_CODE -- 付款人开户行人行支付行号
    ,PAYER_OPBANK_NAME -- 付款人开户行名称
    ,PAY_LIQD_BANK_CNAPS_CODE -- 付款清算行人行支付行号
    ,PAY_BANK_CNAPS_CODE -- 付款行人行支付行号
    ,PAYER_DOCTYP_CD -- 付款人证件类型代码
    ,PAYER_DOC_NO -- 付款人证件号码
    ,PAYER_MVACCT_IDNT_CD -- 付款方动账标识代码
    ,DEDUCT_NOTICE_NO -- 扣款通知编号
    ,PAYEE_ACCT_NO  -- 收款人账户编号
    ,PAYEE_ACCT_NAME -- 收款方账户名称
    ,PAYEE_INTER_STL_ACCT_NO -- 收款人内部结算账户编号
    ,PAYEE_INTER_STL_ACCT_NAME -- 收款人内部结算账户名称
    ,PAYEE_FIN_ACCT_FLAG -- 收款方金融账户标志
    ,PAYEE_OPBANK_ACCT_CNAPS_CODE -- 收款人开户行人行支付行号
    ,PAYEE_OPBANK_NAME -- 收款人开户行名称
    ,FUND_COL_LIQD_BANK_CNAPS_CODE -- 收款清算行人行支付行号
    ,RECV_AMT_BANK_CNAPS_CODE -- 收款行人行支付行号
    ,PAYEE_MVACCT_MODE_CD -- 收款方动账方式代码
    ,RCD_NOTICE_NO -- 入账通知编号
    ,PBC_AGEN_RCPT_PAY_CENTER_NO -- 人行代收付中心编号
    ,TXN_SEQ_NO -- 交易序号
    ,MSG_NO -- 报文编号
    ,MSG_VER_CD -- 报文版本代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,PKG_SER_NO -- 包序号
    ,DTL_SER_NO -- 明细序号
    ,PKG_MSG_NO -- 包报文编号
    ,DTL_MSG_NO -- 明细报文编号
    ,DTL_BIZ_REF_NO -- 明细业务参考号
    ,PKG_COMMS_DT -- 包委托日期
    ,DTL_COMMS_DT -- 明细委托日期
    ,AL_CHECK_FLAG -- 已核验标志
    ,START_BANK_CNAPS_CODE -- 发起行人行支付行号
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,RECV_BANK_CNAPS_CODE -- 接收行人行支付行号
    ,RECV_LIQD_BANK_CNAPS_CODE -- 接收清算行人行支付行号
    ,PACP_BIZ_RCPT_STAT_CD -- 人行代理收付业务回执状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,ORIG_MSG_NO -- 原报文编号
    ,ORIG_PKG_MSG_NO -- 原包报文编号
    ,ORIG_DTL_MSG_NO -- 原明细报文编号
    ,ORIG_COMMS_DT -- 原委托日期
    ,ORIG_START_BANK_CNAPS_CODE -- 原发起行人行支付行号
    ,REFUS_ORG_CNAPS_CODE -- 拒绝机构人行支付行号
    ,REFUS_CD -- 拒绝码
    ,REFUS_INFO_DESC -- 拒绝信息描述
    ,NPC_PROC_CD -- NPC处理码
    ,NPC_REFUS_INFO_DESC -- NPC拒绝信息描述
    ,NPC_DEAL_DT -- NPC处理日期
    ,NPC_BIZ_CLEAR_DT -- NPC业务清算日期
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,MGMT_ORG_CLEAR_CENTER_NO -- 管理机构清算中心编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,INPUT_TELR_NO -- 录入柜员编号
    ,UPDATE_DT -- 更新日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,PBC_AGEN_BIZ_TYPE_CD -- 人行代理业务类型代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA_TM;
