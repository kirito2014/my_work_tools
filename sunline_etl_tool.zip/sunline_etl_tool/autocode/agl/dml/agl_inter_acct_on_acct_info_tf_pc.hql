-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-内部账户挂账信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INTER_ACCT_ON_ACCT_INFO_TF
--     表中文名：内部账户挂账信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：ON_ACCT_SER_NO, ON_ACCT_DT, REC_STATUS_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-09-06 00:00:00 魏丹丹 修改取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM
USING ORC
COMMENT '内部账户挂账信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ON_ACCT_SER_NO -- 挂账序号
    ,ON_ACCT_DT -- 挂账日期
    ,INTER_ACCT_ON_ACCT_STATUS_CD -- 内部账户挂账状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TELR_SER_NO -- 柜员流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,VOCH_CATE_CD -- 凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,VICE_VOCH_CATE_CD -- 副凭证种类代码
    ,TXN_VICE_VOCH_NO -- 交易副凭证号码
    ,VOUCH_NO -- 传票套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ON_ACCT_AMT -- 挂账金额
    ,AL_WRTOFF_AMT -- 已销账金额
    ,UN_WRTOFF_AMT -- 未销账金额
    ,AL_WRTOFF_CNT -- 已销账笔数
    ,FINAL_WRTOFF_DT -- 最后销账日期
    ,AL_WRTOFF_MAX_SER_NO -- 已销账最大序号
    ,ON_ACCT_ORG_NO -- 挂账机构编号
    ,ON_ACCT_CRDT_STAT_SEQ_NO -- 挂账信用站顺序号
    ,ON_ACCT_TELR_NO -- 挂账柜员编号
    ,ON_ACCT_AUTH_TELR_NO -- 挂账授权柜员编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 内部账户挂账信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ON_ACCT_SER_NO -- 挂账序号
    ,ON_ACCT_DT -- 挂账日期
    ,INTER_ACCT_ON_ACCT_STATUS_CD -- 内部账户挂账状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TELR_SER_NO -- 柜员流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,VOCH_CATE_CD -- 凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,VICE_VOCH_CATE_CD -- 副凭证种类代码
    ,TXN_VICE_VOCH_NO -- 交易副凭证号码
    ,VOUCH_NO -- 传票套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ON_ACCT_AMT -- 挂账金额
    ,AL_WRTOFF_AMT -- 已销账金额
    ,UN_WRTOFF_AMT -- 未销账金额
    ,AL_WRTOFF_CNT -- 已销账笔数
    ,FINAL_WRTOFF_DT -- 最后销账日期
    ,AL_WRTOFF_MAX_SER_NO -- 已销账最大序号
    ,ON_ACCT_ORG_NO -- 挂账机构编号
    ,ON_ACCT_CRDT_STAT_SEQ_NO -- 挂账信用站顺序号
    ,ON_ACCT_TELR_NO -- 挂账柜员编号
    ,ON_ACCT_AUTH_TELR_NO -- 挂账授权柜员编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.DBCAAC20 AS ACCT_NO -- 账户编号
    ,P2.FGCAFLNM AS ACCT_NAME -- 账户名称
    ,P1.DBCASQNO AS ON_ACCT_SER_NO -- 挂账序号
    ,unifiedTime(P1.DBCADATE) AS ON_ACCT_DT -- 挂账日期
    ,P1.DBCAWRST AS INTER_ACCT_ON_ACCT_STATUS_CD -- 内部账户挂账状态代码
    ,P1.DBCATXSN AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.DBCBTXSN AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.DBCASN11 AS TELR_SER_NO -- 柜员流水号
    ,P1.DBCBBRNO AS TXN_ORG_NO -- 交易机构编号
    ,P1.DBCACCYC AS TXN_CURR_CD -- 交易币种代码
    ,P1.DBCACHSX AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,CASE WHEN P1.DBCACDFG ='1' THEN 'D' WHEN  P1.DBCACDFG='2' THEN 'C' ELSE  P1.DBCACDFG  END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,COALESCE(P4.KHDCACID,P5.KHDCACID) AS ACCTN_SUBJ_NO -- 会计科目编号
    ,COALESCE(P4.KHDAFLNM,P5.KHDAFLNM) AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.DBCANTCD AS SUMMARY_CD -- 摘要代码
    ,P1.DBCARMRK AS SUMMARY_DESC -- 摘要描述
    ,P1.DBCABLTP AS VOCH_CATE_CD -- 凭证种类代码
    ,P1.DBCABLNO AS TXN_VOCH_NO -- 交易凭证号码
    ,P1.DBCBBLTP AS VICE_VOCH_CATE_CD -- 副凭证种类代码
    ,P1.DBCBBLNO AS TXN_VICE_VOCH_NO -- 交易副凭证号码
    ,P1.DBCASN10 AS VOUCH_NO -- 传票套号
    ,P1.DBCASN02 AS DWELL_SPC_SER_NO -- 套内序号
    ,P1.DBCAAC32 AS CNTPTY_ACCT_NO -- 对方账户编号
    ,P1.DBCBFLNM AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,P1.DBCAAMT AS ON_ACCT_AMT -- 挂账金额
    ,P1.DBCBAMT AS AL_WRTOFF_AMT -- 已销账金额
    ,P1.DBCCAMT AS UN_WRTOFF_AMT -- 未销账金额
    ,P1.DBCBSN03 AS AL_WRTOFF_CNT -- 已销账笔数
    ,unifiedTime(P1.DBCCDATE) AS FINAL_WRTOFF_DT -- 最后销账日期
    ,P1.DBCASN08 AS AL_WRTOFF_MAX_SER_NO -- 已销账最大序号
    ,P1.DBCABRNO AS ON_ACCT_ORG_NO -- 挂账机构编号
    ,P1.DBCAPTSN AS ON_ACCT_CRDT_STAT_SEQ_NO -- 挂账信用站顺序号
    ,P1.DBCASTAF AS ON_ACCT_TELR_NO -- 挂账柜员编号
    ,P1.DBCBSTAF AS ON_ACCT_AUTH_TELR_NO -- 挂账授权柜员编号
    ,P2.FGCABRNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.FGCBBRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.FGCCBRNO AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN P1.DBCARS1B='' OR P1.DBCARS1B IS NULL THEN '0' WHEN P1.DBCARS1B='9' THEN '9' END AS REC_STATUS_CD -- 记录状态代码
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BGFMDBAL_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE${version_num}.ODS_CORE_BGFMDBAL_TF AS P1 -- 内部户挂账登记薄

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFMFBAL_TF AS P2 -- 表内分户账文件
       ON P1.DBCAAC20 = P2.FGCAAC20  AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS P4 -- 新会计科目核算码对照表
       ON P4.KHDBACID = SUBSTR(P1.DBCAAC20,9,6)  AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BGFDKHDZ_TF AS P5 -- 新会计科目核算码对照表
       ON P5.KHDBACID = SUBSTR(P1.DBCAAC20,10,5)  AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 内部账户挂账信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,ON_ACCT_SER_NO -- 挂账序号
    ,ON_ACCT_DT -- 挂账日期
    ,INTER_ACCT_ON_ACCT_STATUS_CD -- 内部账户挂账状态代码
    ,ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TELR_SER_NO -- 柜员流水号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,VOCH_CATE_CD -- 凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,VICE_VOCH_CATE_CD -- 副凭证种类代码
    ,TXN_VICE_VOCH_NO -- 交易副凭证号码
    ,VOUCH_NO -- 传票套号
    ,DWELL_SPC_SER_NO -- 套内序号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,CNTPTY_ACCT_NAME -- 对方账户名称
    ,ON_ACCT_AMT -- 挂账金额
    ,AL_WRTOFF_AMT -- 已销账金额
    ,UN_WRTOFF_AMT -- 未销账金额
    ,AL_WRTOFF_CNT -- 已销账笔数
    ,FINAL_WRTOFF_DT -- 最后销账日期
    ,AL_WRTOFF_MAX_SER_NO -- 已销账最大序号
    ,ON_ACCT_ORG_NO -- 挂账机构编号
    ,ON_ACCT_CRDT_STAT_SEQ_NO -- 挂账信用站顺序号
    ,ON_ACCT_TELR_NO -- 挂账柜员编号
    ,ON_ACCT_AUTH_TELR_NO -- 挂账授权柜员编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REC_STATUS_CD -- 记录状态代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PAYAAC AS ACCT_NO -- 账户编号
    ,P2.ACCTNA AS ACCT_NAME -- 账户名称
    ,P1.PAYASQ AS ON_ACCT_SER_NO -- 挂账序号
    ,unifiedTime(P1.TRANDT) AS ON_ACCT_DT -- 挂账日期
    ,CASE WHEN P1.PAYAST= '0' THEN '2'
     WHEN P1.PAYAST= '2' THEN '3'
     WHEN P1.PAYAST= '3' THEN '4'
     WHEN P1.PAYAST= '4' THEN 'W4'
     WHEN P1.PAYAST= '5' THEN 'W5'
 ELSE P1.PAYAST  END AS INTER_ACCT_ON_ACCT_STATUS_CD -- 内部账户挂账状态代码
    ,P1.TRANSQ AS ORIG_TXN_SER_NO -- 原交易流水号
    ,'' AS SUB_TXN_SER_NO -- 子交易流水号
    ,'' AS TELR_SER_NO -- 柜员流水号
    ,P3.acctbr AS TXN_ORG_NO -- 交易机构编号
    ,P1.CRCYCD AS TXN_CURR_CD -- 交易币种代码
    ,'' AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P3.AMNTCD AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,coalesce(P4.SUBJECT_DR,P4.SUBJECT_CR) AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P5.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P3.smrytx AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,P3.cheqtp AS VOCH_CATE_CD -- 凭证种类代码
    ,P3.cheqno AS TXN_VOCH_NO -- 交易凭证号码
    ,'' AS VICE_VOCH_CATE_CD -- 副凭证种类代码
    ,'' AS TXN_VICE_VOCH_NO -- 交易副凭证号码
    ,P1.ACSTNO AS VOUCH_NO -- 传票套号
    ,P1.PAYSEQ AS DWELL_SPC_SER_NO -- 套内序号
    ,P1.TOACCT AS CNTPTY_ACCT_NO -- 对方账户编号
    ,P1.TOACNA AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,P1.PAYAMN AS ON_ACCT_AMT -- 挂账金额
    ,P1.PAYAMN-P1.RSDLMN AS AL_WRTOFF_AMT -- 已销账金额
    ,P1.RSDLMN AS UN_WRTOFF_AMT -- 未销账金额
    ,P1.PAYDNM AS AL_WRTOFF_CNT -- 已销账笔数
    ,'' AS FINAL_WRTOFF_DT -- 最后销账日期
    ,'' AS AL_WRTOFF_MAX_SER_NO -- 已销账最大序号
    ,P1.PAYABR AS ON_ACCT_ORG_NO -- 挂账机构编号
    ,'' AS ON_ACCT_CRDT_STAT_SEQ_NO -- 挂账信用站顺序号
    ,P1.TRANUS AS ON_ACCT_TELR_NO -- 挂账柜员编号
    ,'' AS ON_ACCT_AUTH_TELR_NO -- 挂账授权柜员编号
    ,P2.BRCHNO AS STAT_ORG_NO -- 统计机构编号
    ,P2.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,P2.KPACBR AS LP_ORG_NO -- 法人机构编号
    ,'' AS REC_STATUS_CD -- 记录状态代码
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNS_PAYA_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS${version_num}.ODS_NAS_KNS_PAYA_TF AS P1 -- 挂账登记薄

LEFT JOIN ODS_NAS${version_num}.ODS_NAS_GL_KNA_ACCT_TF AS P2 -- 内部户账户表
       ON P1.PAYAAC = P2.ACCTNO  AND P2.PT_DT = '${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_NAS${version_num}.ODS_NAS_GL_KNS_GLVC_TF AS P3 -- 传票流水表(表内外)
       ON P3.transq = P1.transq  AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_EA_RULES_TF AS P4 -- COA段值视图
       ON P3.BUSINO = P4.PRODUCT  AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_GAS${version_num}.ODS_GAS_CUX_FLEX_VALUES_V_TF AS P5 -- 会计核算规则定义
       ON coalesce(P4.SUBJECT_DR,P4.SUBJECT_CR) = P5.flex_value  AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
WHERE  P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_SER_NO, BF.ON_ACCT_SER_NO) END AS ON_ACCT_SER_NO -- 挂账序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_DT, BF.ON_ACCT_DT) END AS ON_ACCT_DT -- 挂账日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INTER_ACCT_ON_ACCT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.INTER_ACCT_ON_ACCT_STATUS_CD, BF.INTER_ACCT_ON_ACCT_STATUS_CD) END AS INTER_ACCT_ON_ACCT_STATUS_CD -- 内部账户挂账状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORIG_TXN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.ORIG_TXN_SER_NO, BF.ORIG_TXN_SER_NO) END AS ORIG_TXN_SER_NO -- 原交易流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUB_TXN_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.SUB_TXN_SER_NO, BF.SUB_TXN_SER_NO) END AS SUB_TXN_SER_NO -- 子交易流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TELR_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.TELR_SER_NO, BF.TELR_SER_NO) END AS TELR_SER_NO -- 柜员流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.TXN_ORG_NO, BF.TXN_ORG_NO) END AS TXN_ORG_NO -- 交易机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CURR_CD, BF.TXN_CURR_CD) END AS TXN_CURR_CD -- 交易币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CASH_RMT_CD, BF.TXN_CASH_RMT_CD) END AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DEBIT_CRDT_DIR_CD IS NULL THEN NULL ELSE COALESCE(TM.DEBIT_CRDT_DIR_CD, BF.DEBIT_CRDT_DIR_CD) END AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NO, BF.ACCTN_SUBJ_NO) END AS ACCTN_SUBJ_NO -- 会计科目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NAME, BF.ACCTN_SUBJ_NAME) END AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_CD IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_CD, BF.SUMMARY_CD) END AS SUMMARY_CD -- 摘要代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUMMARY_DESC IS NULL THEN NULL ELSE COALESCE(TM.SUMMARY_DESC, BF.SUMMARY_DESC) END AS SUMMARY_DESC -- 摘要描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VOCH_CATE_CD IS NULL THEN NULL ELSE COALESCE(TM.VOCH_CATE_CD, BF.VOCH_CATE_CD) END AS VOCH_CATE_CD -- 凭证种类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_VOCH_NO IS NULL THEN NULL ELSE COALESCE(TM.TXN_VOCH_NO, BF.TXN_VOCH_NO) END AS TXN_VOCH_NO -- 交易凭证号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VICE_VOCH_CATE_CD IS NULL THEN NULL ELSE COALESCE(TM.VICE_VOCH_CATE_CD, BF.VICE_VOCH_CATE_CD) END AS VICE_VOCH_CATE_CD -- 副凭证种类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_VICE_VOCH_NO IS NULL THEN NULL ELSE COALESCE(TM.TXN_VICE_VOCH_NO, BF.TXN_VICE_VOCH_NO) END AS TXN_VICE_VOCH_NO -- 交易副凭证号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VOUCH_NO IS NULL THEN NULL ELSE COALESCE(TM.VOUCH_NO, BF.VOUCH_NO) END AS VOUCH_NO -- 传票套号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DWELL_SPC_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.DWELL_SPC_SER_NO, BF.DWELL_SPC_SER_NO) END AS DWELL_SPC_SER_NO -- 套内序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CNTPTY_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.CNTPTY_ACCT_NO, BF.CNTPTY_ACCT_NO) END AS CNTPTY_ACCT_NO -- 对方账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CNTPTY_ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.CNTPTY_ACCT_NAME, BF.CNTPTY_ACCT_NAME) END AS CNTPTY_ACCT_NAME -- 对方账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_AMT IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_AMT, BF.ON_ACCT_AMT) END AS ON_ACCT_AMT -- 挂账金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AL_WRTOFF_AMT IS NULL THEN NULL ELSE COALESCE(TM.AL_WRTOFF_AMT, BF.AL_WRTOFF_AMT) END AS AL_WRTOFF_AMT -- 已销账金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UN_WRTOFF_AMT IS NULL THEN NULL ELSE COALESCE(TM.UN_WRTOFF_AMT, BF.UN_WRTOFF_AMT) END AS UN_WRTOFF_AMT -- 未销账金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AL_WRTOFF_CNT IS NULL THEN NULL ELSE COALESCE(TM.AL_WRTOFF_CNT, BF.AL_WRTOFF_CNT) END AS AL_WRTOFF_CNT -- 已销账笔数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_WRTOFF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_WRTOFF_DT, BF.FINAL_WRTOFF_DT) END AS FINAL_WRTOFF_DT -- 最后销账日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AL_WRTOFF_MAX_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.AL_WRTOFF_MAX_SER_NO, BF.AL_WRTOFF_MAX_SER_NO) END AS AL_WRTOFF_MAX_SER_NO -- 已销账最大序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_ORG_NO, BF.ON_ACCT_ORG_NO) END AS ON_ACCT_ORG_NO -- 挂账机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_CRDT_STAT_SEQ_NO IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_CRDT_STAT_SEQ_NO, BF.ON_ACCT_CRDT_STAT_SEQ_NO) END AS ON_ACCT_CRDT_STAT_SEQ_NO -- 挂账信用站顺序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_TELR_NO, BF.ON_ACCT_TELR_NO) END AS ON_ACCT_TELR_NO -- 挂账柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ON_ACCT_AUTH_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.ON_ACCT_AUTH_TELR_NO, BF.ON_ACCT_AUTH_TELR_NO) END AS ON_ACCT_AUTH_TELR_NO -- 挂账授权柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STAT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.STAT_ORG_NO, BF.STAT_ORG_NO) END AS STAT_ORG_NO -- 统计机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REC_STATUS_CD, BF.REC_STATUS_CD) END AS REC_STATUS_CD -- 记录状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.INTER_ACCT_ON_ACCT_STATUS_CD,'') = COALESCE(BF.INTER_ACCT_ON_ACCT_STATUS_CD,'') -- 内部账户挂账状态代码 非主键字段相等
         AND COALESCE(TM.ORIG_TXN_SER_NO,'') = COALESCE(BF.ORIG_TXN_SER_NO,'') -- 原交易流水号 非主键字段相等
         AND COALESCE(TM.SUB_TXN_SER_NO,'') = COALESCE(BF.SUB_TXN_SER_NO,'') -- 子交易流水号 非主键字段相等
         AND COALESCE(TM.TELR_SER_NO,'') = COALESCE(BF.TELR_SER_NO,'') -- 柜员流水号 非主键字段相等
         AND COALESCE(TM.TXN_ORG_NO,'') = COALESCE(BF.TXN_ORG_NO,'') -- 交易机构编号 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.TXN_CASH_RMT_CD,'') = COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段相等
         AND COALESCE(TM.DEBIT_CRDT_DIR_CD,'') = COALESCE(BF.DEBIT_CRDT_DIR_CD,'') -- 借贷方向代码 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         AND COALESCE(TM.SUMMARY_DESC,'') = COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段相等
         AND COALESCE(TM.VOCH_CATE_CD,'') = COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段相等
         AND COALESCE(TM.TXN_VOCH_NO,'') = COALESCE(BF.TXN_VOCH_NO,'') -- 交易凭证号码 非主键字段相等
         AND COALESCE(TM.VICE_VOCH_CATE_CD,'') = COALESCE(BF.VICE_VOCH_CATE_CD,'') -- 副凭证种类代码 非主键字段相等
         AND COALESCE(TM.TXN_VICE_VOCH_NO,'') = COALESCE(BF.TXN_VICE_VOCH_NO,'') -- 交易副凭证号码 非主键字段相等
         AND COALESCE(TM.VOUCH_NO,'') = COALESCE(BF.VOUCH_NO,'') -- 传票套号 非主键字段相等
         AND COALESCE(TM.DWELL_SPC_SER_NO,'') = COALESCE(BF.DWELL_SPC_SER_NO,'') -- 套内序号 非主键字段相等
         AND COALESCE(TM.CNTPTY_ACCT_NO,'') = COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段相等
         AND COALESCE(TM.CNTPTY_ACCT_NAME,'') = COALESCE(BF.CNTPTY_ACCT_NAME,'') -- 对方账户名称 非主键字段相等
         AND COALESCE(TM.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 挂账金额 非主键字段相等
         AND COALESCE(TM.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 已销账金额 非主键字段相等
         AND COALESCE(TM.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 未销账金额 非主键字段相等
         AND COALESCE(TM.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) = COALESCE(BF.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) -- 已销账笔数 非主键字段相等
         AND COALESCE(TM.FINAL_WRTOFF_DT,'') = COALESCE(BF.FINAL_WRTOFF_DT,'') -- 最后销账日期 非主键字段相等
         AND COALESCE(TM.AL_WRTOFF_MAX_SER_NO,'') = COALESCE(BF.AL_WRTOFF_MAX_SER_NO,'') -- 已销账最大序号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_ORG_NO,'') = COALESCE(BF.ON_ACCT_ORG_NO,'') -- 挂账机构编号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_CRDT_STAT_SEQ_NO,'') = COALESCE(BF.ON_ACCT_CRDT_STAT_SEQ_NO,'') -- 挂账信用站顺序号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_TELR_NO,'') = COALESCE(BF.ON_ACCT_TELR_NO,'') -- 挂账柜员编号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_AUTH_TELR_NO,'') = COALESCE(BF.ON_ACCT_AUTH_TELR_NO,'') -- 挂账授权柜员编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.INTER_ACCT_ON_ACCT_STATUS_CD,'') <> COALESCE(BF.INTER_ACCT_ON_ACCT_STATUS_CD,'') -- 内部账户挂账状态代码 非主键字段不相等
         OR COALESCE(TM.ORIG_TXN_SER_NO,'') <> COALESCE(BF.ORIG_TXN_SER_NO,'') -- 原交易流水号 非主键字段不相等
         OR COALESCE(TM.SUB_TXN_SER_NO,'') <> COALESCE(BF.SUB_TXN_SER_NO,'') -- 子交易流水号 非主键字段不相等
         OR COALESCE(TM.TELR_SER_NO,'') <> COALESCE(BF.TELR_SER_NO,'') -- 柜员流水号 非主键字段不相等
         OR COALESCE(TM.TXN_ORG_NO,'') <> COALESCE(BF.TXN_ORG_NO,'') -- 交易机构编号 非主键字段不相等
         OR COALESCE(TM.TXN_CURR_CD,'') <> COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段不相等
         OR COALESCE(TM.TXN_CASH_RMT_CD,'') <> COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CRDT_DIR_CD,'') <> COALESCE(BF.DEBIT_CRDT_DIR_CD,'') -- 借贷方向代码 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         OR COALESCE(TM.SUMMARY_DESC,'') <> COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段不相等
         OR COALESCE(TM.VOCH_CATE_CD,'') <> COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段不相等
         OR COALESCE(TM.TXN_VOCH_NO,'') <> COALESCE(BF.TXN_VOCH_NO,'') -- 交易凭证号码 非主键字段不相等
         OR COALESCE(TM.VICE_VOCH_CATE_CD,'') <> COALESCE(BF.VICE_VOCH_CATE_CD,'') -- 副凭证种类代码 非主键字段不相等
         OR COALESCE(TM.TXN_VICE_VOCH_NO,'') <> COALESCE(BF.TXN_VICE_VOCH_NO,'') -- 交易副凭证号码 非主键字段不相等
         OR COALESCE(TM.VOUCH_NO,'') <> COALESCE(BF.VOUCH_NO,'') -- 传票套号 非主键字段不相等
         OR COALESCE(TM.DWELL_SPC_SER_NO,'') <> COALESCE(BF.DWELL_SPC_SER_NO,'') -- 套内序号 非主键字段不相等
         OR COALESCE(TM.CNTPTY_ACCT_NO,'') <> COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段不相等
         OR COALESCE(TM.CNTPTY_ACCT_NAME,'') <> COALESCE(BF.CNTPTY_ACCT_NAME,'') -- 对方账户名称 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 挂账金额 非主键字段不相等
         OR COALESCE(TM.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 已销账金额 非主键字段不相等
         OR COALESCE(TM.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 未销账金额 非主键字段不相等
         OR COALESCE(TM.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) <> COALESCE(BF.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) -- 已销账笔数 非主键字段不相等
         OR COALESCE(TM.FINAL_WRTOFF_DT,'') <> COALESCE(BF.FINAL_WRTOFF_DT,'') -- 最后销账日期 非主键字段不相等
         OR COALESCE(TM.AL_WRTOFF_MAX_SER_NO,'') <> COALESCE(BF.AL_WRTOFF_MAX_SER_NO,'') -- 已销账最大序号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_ORG_NO,'') <> COALESCE(BF.ON_ACCT_ORG_NO,'') -- 挂账机构编号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_CRDT_STAT_SEQ_NO,'') <> COALESCE(BF.ON_ACCT_CRDT_STAT_SEQ_NO,'') -- 挂账信用站顺序号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_TELR_NO,'') <> COALESCE(BF.ON_ACCT_TELR_NO,'') -- 挂账柜员编号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_AUTH_TELR_NO,'') <> COALESCE(BF.ON_ACCT_AUTH_TELR_NO,'') -- 挂账授权柜员编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.INTER_ACCT_ON_ACCT_STATUS_CD,'') = COALESCE(BF.INTER_ACCT_ON_ACCT_STATUS_CD,'') -- 内部账户挂账状态代码 非主键字段相等
         AND COALESCE(TM.ORIG_TXN_SER_NO,'') = COALESCE(BF.ORIG_TXN_SER_NO,'') -- 原交易流水号 非主键字段相等
         AND COALESCE(TM.SUB_TXN_SER_NO,'') = COALESCE(BF.SUB_TXN_SER_NO,'') -- 子交易流水号 非主键字段相等
         AND COALESCE(TM.TELR_SER_NO,'') = COALESCE(BF.TELR_SER_NO,'') -- 柜员流水号 非主键字段相等
         AND COALESCE(TM.TXN_ORG_NO,'') = COALESCE(BF.TXN_ORG_NO,'') -- 交易机构编号 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.TXN_CASH_RMT_CD,'') = COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段相等
         AND COALESCE(TM.DEBIT_CRDT_DIR_CD,'') = COALESCE(BF.DEBIT_CRDT_DIR_CD,'') -- 借贷方向代码 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.SUMMARY_CD,'') = COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段相等
         AND COALESCE(TM.SUMMARY_DESC,'') = COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段相等
         AND COALESCE(TM.VOCH_CATE_CD,'') = COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段相等
         AND COALESCE(TM.TXN_VOCH_NO,'') = COALESCE(BF.TXN_VOCH_NO,'') -- 交易凭证号码 非主键字段相等
         AND COALESCE(TM.VICE_VOCH_CATE_CD,'') = COALESCE(BF.VICE_VOCH_CATE_CD,'') -- 副凭证种类代码 非主键字段相等
         AND COALESCE(TM.TXN_VICE_VOCH_NO,'') = COALESCE(BF.TXN_VICE_VOCH_NO,'') -- 交易副凭证号码 非主键字段相等
         AND COALESCE(TM.VOUCH_NO,'') = COALESCE(BF.VOUCH_NO,'') -- 传票套号 非主键字段相等
         AND COALESCE(TM.DWELL_SPC_SER_NO,'') = COALESCE(BF.DWELL_SPC_SER_NO,'') -- 套内序号 非主键字段相等
         AND COALESCE(TM.CNTPTY_ACCT_NO,'') = COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段相等
         AND COALESCE(TM.CNTPTY_ACCT_NAME,'') = COALESCE(BF.CNTPTY_ACCT_NAME,'') -- 对方账户名称 非主键字段相等
         AND COALESCE(TM.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 挂账金额 非主键字段相等
         AND COALESCE(TM.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 已销账金额 非主键字段相等
         AND COALESCE(TM.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 未销账金额 非主键字段相等
         AND COALESCE(TM.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) = COALESCE(BF.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) -- 已销账笔数 非主键字段相等
         AND COALESCE(TM.FINAL_WRTOFF_DT,'') = COALESCE(BF.FINAL_WRTOFF_DT,'') -- 最后销账日期 非主键字段相等
         AND COALESCE(TM.AL_WRTOFF_MAX_SER_NO,'') = COALESCE(BF.AL_WRTOFF_MAX_SER_NO,'') -- 已销账最大序号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_ORG_NO,'') = COALESCE(BF.ON_ACCT_ORG_NO,'') -- 挂账机构编号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_CRDT_STAT_SEQ_NO,'') = COALESCE(BF.ON_ACCT_CRDT_STAT_SEQ_NO,'') -- 挂账信用站顺序号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_TELR_NO,'') = COALESCE(BF.ON_ACCT_TELR_NO,'') -- 挂账柜员编号 非主键字段相等
         AND COALESCE(TM.ON_ACCT_AUTH_TELR_NO,'') = COALESCE(BF.ON_ACCT_AUTH_TELR_NO,'') -- 挂账授权柜员编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.INTER_ACCT_ON_ACCT_STATUS_CD,'') <> COALESCE(BF.INTER_ACCT_ON_ACCT_STATUS_CD,'') -- 内部账户挂账状态代码 非主键字段不相等
         OR COALESCE(TM.ORIG_TXN_SER_NO,'') <> COALESCE(BF.ORIG_TXN_SER_NO,'') -- 原交易流水号 非主键字段不相等
         OR COALESCE(TM.SUB_TXN_SER_NO,'') <> COALESCE(BF.SUB_TXN_SER_NO,'') -- 子交易流水号 非主键字段不相等
         OR COALESCE(TM.TELR_SER_NO,'') <> COALESCE(BF.TELR_SER_NO,'') -- 柜员流水号 非主键字段不相等
         OR COALESCE(TM.TXN_ORG_NO,'') <> COALESCE(BF.TXN_ORG_NO,'') -- 交易机构编号 非主键字段不相等
         OR COALESCE(TM.TXN_CURR_CD,'') <> COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段不相等
         OR COALESCE(TM.TXN_CASH_RMT_CD,'') <> COALESCE(BF.TXN_CASH_RMT_CD,'') -- 交易钞汇代码 非主键字段不相等
         OR COALESCE(TM.DEBIT_CRDT_DIR_CD,'') <> COALESCE(BF.DEBIT_CRDT_DIR_CD,'') -- 借贷方向代码 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.SUMMARY_CD,'') <> COALESCE(BF.SUMMARY_CD,'') -- 摘要代码 非主键字段不相等
         OR COALESCE(TM.SUMMARY_DESC,'') <> COALESCE(BF.SUMMARY_DESC,'') -- 摘要描述 非主键字段不相等
         OR COALESCE(TM.VOCH_CATE_CD,'') <> COALESCE(BF.VOCH_CATE_CD,'') -- 凭证种类代码 非主键字段不相等
         OR COALESCE(TM.TXN_VOCH_NO,'') <> COALESCE(BF.TXN_VOCH_NO,'') -- 交易凭证号码 非主键字段不相等
         OR COALESCE(TM.VICE_VOCH_CATE_CD,'') <> COALESCE(BF.VICE_VOCH_CATE_CD,'') -- 副凭证种类代码 非主键字段不相等
         OR COALESCE(TM.TXN_VICE_VOCH_NO,'') <> COALESCE(BF.TXN_VICE_VOCH_NO,'') -- 交易副凭证号码 非主键字段不相等
         OR COALESCE(TM.VOUCH_NO,'') <> COALESCE(BF.VOUCH_NO,'') -- 传票套号 非主键字段不相等
         OR COALESCE(TM.DWELL_SPC_SER_NO,'') <> COALESCE(BF.DWELL_SPC_SER_NO,'') -- 套内序号 非主键字段不相等
         OR COALESCE(TM.CNTPTY_ACCT_NO,'') <> COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段不相等
         OR COALESCE(TM.CNTPTY_ACCT_NAME,'') <> COALESCE(BF.CNTPTY_ACCT_NAME,'') -- 对方账户名称 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ON_ACCT_AMT,CAST(0 AS DECIMAL(28,2))) -- 挂账金额 非主键字段不相等
         OR COALESCE(TM.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.AL_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 已销账金额 非主键字段不相等
         OR COALESCE(TM.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.UN_WRTOFF_AMT,CAST(0 AS DECIMAL(28,2))) -- 未销账金额 非主键字段不相等
         OR COALESCE(TM.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) <> COALESCE(BF.AL_WRTOFF_CNT,CAST(0 AS BIGINT)) -- 已销账笔数 非主键字段不相等
         OR COALESCE(TM.FINAL_WRTOFF_DT,'') <> COALESCE(BF.FINAL_WRTOFF_DT,'') -- 最后销账日期 非主键字段不相等
         OR COALESCE(TM.AL_WRTOFF_MAX_SER_NO,'') <> COALESCE(BF.AL_WRTOFF_MAX_SER_NO,'') -- 已销账最大序号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_ORG_NO,'') <> COALESCE(BF.ON_ACCT_ORG_NO,'') -- 挂账机构编号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_CRDT_STAT_SEQ_NO,'') <> COALESCE(BF.ON_ACCT_CRDT_STAT_SEQ_NO,'') -- 挂账信用站顺序号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_TELR_NO,'') <> COALESCE(BF.ON_ACCT_TELR_NO,'') -- 挂账柜员编号 非主键字段不相等
         OR COALESCE(TM.ON_ACCT_AUTH_TELR_NO,'') <> COALESCE(BF.ON_ACCT_AUTH_TELR_NO,'') -- 挂账授权柜员编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.ON_ACCT_SER_NO,'') = COALESCE(BF.ON_ACCT_SER_NO,'') -- 挂账序号 主键字段关联
    AND COALESCE(TM.ON_ACCT_DT,'') = COALESCE(BF.ON_ACCT_DT,'') -- 挂账日期 主键字段关联
    AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_INTER_ACCT_ON_ACCT_INFO_TF_TM;
