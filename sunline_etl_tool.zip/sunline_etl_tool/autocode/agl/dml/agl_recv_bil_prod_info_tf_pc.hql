-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单产品信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_PROD_INFO_TF
--     表中文名：收单产品信息聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：RECV_BIL_PROD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-27 00:00:00 吉云龙 创建
--         2024-08-13 00:00:00 陈艺丹 修改字段适用商户类型代码的取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_RECV_BIL_PROD_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM
USING ORC
COMMENT '收单产品信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,SAM_APPID_MATN_FLAG -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_RECV_BIL_PROD_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 收单产品信息聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM(
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.PDCODE AS RECV_BIL_PROD_NO -- 收单产品编号
    ,P1.PDNAME AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,P1.ISNDEV AS NEED_DVLP_FLAG -- 需开发标志
    ,P1.PDTYPE AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,CASE WHEN P1.PDCODE IN ('P99920231010200002','P99920221010200001') 
     THEN 'POSCLOUD'
  WHEN P1.PDCODE = 'P99920211010100001' OR (SUBSTR(P1.PDCODE,10,2)='01' AND P1.PDCODE NOT IN ('P99920231010200002','P99920221010200001'))
  THEN 'YMTCLOUD'
  WHEN SUBSTR(P1.PDCODE,10,2) IN ('02','03')
  THEN 'OPEN3CLOUD'
END AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,CASE WHEN P1.PDCODE IN ('P99920231010200002','P99920221010200001') 
     THEN 'POS'
  WHEN P1.PDCODE = 'P99920211010100001' OR (SUBSTR(P1.PDCODE,10,2)='01' AND P1.PDCODE NOT IN ('P99920231010200002','P99920221010200001'))
  THEN 'YMT'
  WHEN SUBSTR(P1.PDCODE,10,2) IN ('02','03')
  THEN 'OPEN'
END AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,SUBSTR(P1.PDCODE,10,2) AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,P1.PDCODE AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,P1.REMARK AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,P1.BILLMD AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,P1.PAYTYP AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,P1.BIGWAL AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,P1.SMAWAL AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,P1.APBRCH AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,P1.APMCAT AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,CASE WHEN P1.APMCTY IS NULL OR TRIM(P1.APMCTY)='' THEN '' 
ELSE COALESCE(TRIM(M1.TARGET_CD_VAL), '@'||TRIM(P1.APMCTY),'') END AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,P1.APLMCC AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,P1.APLOBJ AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,P1.SMCAPP AS FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,P1.SPRAPP AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,P1.APTLTY AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,P1.SFAUTO AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,P1.PTSTAT AS PUT_ON_FLAG -- 上架标志
    ,unifiedTime(P1.PTDATE) AS PUT_ON_TM_STAMP -- 上架时间戳
    ,unifiedTime(P1.CREADT) AS CREATE_TM_STAMP -- 创建时间戳
    ,P1.TRANUS AS INPUT_TELR_NO -- 录入柜员编号
    ,P1.BRCHNO AS INPUT_ORG_NO -- 录入机构编号
    ,unifiedTime(P1.UPDTDT) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPDUSR AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.UPBRCHNO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_PAY_INFO_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP.ODS_MCSP_PRDU_PAY_INFO_TF AS P1 -- 收单产品聚合层基本信息表

LEFT JOIN AGL.PUB_CD_MAP AS M1 -- 码值表
       ON P1.APMCTY=M1.SRC_CD_VAL  
AND M1.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND M1.SRC_TAB_EN_NAME='PRDU_PAY_INFO' --来源表英文名 大写
AND M1.SRC_FIELD_EN_NAME='APMCTY' --来源字段英文名 大写
AND M1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_PROD_INFO_TF'--目标表名 大写
AND M1.TARGET_FIELD_EN_NAME='FIT_MERCHT_TYPE_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 收单产品信息聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM(
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'ZF2.0' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS NEED_DVLP_FLAG -- 需开发标志
    ,'' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'OPEN1' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'OPEN' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'03' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,'ZF2.0' AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,'' AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,'' AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,'' AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,'' AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,'' AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,'' AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,'' AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,'' AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,'' AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,'' AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,'' AS FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,'' AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,'' AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,'' AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,'1' AS PUT_ON_FLAG -- 上架标志
    ,'9999/12/31' AS PUT_ON_TM_STAMP -- 上架时间戳
    ,'9999/12/31' AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_PAY_INFO_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP.ODS_MCSP_PRDU_PAY_INFO_TF AS P1 -- 收单产品聚合层基本信息表

WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.ID=2
;
-- ==============聚合层字段映射（第3组）==============
-- 收单产品信息聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM(
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'ZNZF' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS NEED_DVLP_FLAG -- 需开发标志
    ,'' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'OPEN3' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'OPEN' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'03' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,'ZNZF' AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,'' AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,'' AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,'' AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,'' AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,'' AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,'' AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,'' AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,'' AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,'' AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,'' AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,'' AS FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,'' AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,'' AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,'' AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,'1' AS PUT_ON_FLAG -- 上架标志
    ,'9999/12/31' AS PUT_ON_TM_STAMP -- 上架时间戳
    ,'9999/12/31' AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_PAY_INFO_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP.ODS_MCSP_PRDU_PAY_INFO_TF AS P1 -- 收单产品基本信息表

WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.ID=2
;
-- ==============聚合层字段映射（第4组）==============
-- 收单产品信息聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM(
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'YMT' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS NEED_DVLP_FLAG -- 需开发标志
    ,'' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'YMT' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'YMT' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'01' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,'YMT' AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,'' AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,'' AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,'' AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,'' AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,'' AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,'' AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,'' AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,'' AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,'' AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,'' AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,'' AS FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,'' AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,'' AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,'' AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,'1' AS PUT_ON_FLAG -- 上架标志
    ,'9999/12/31' AS PUT_ON_TM_STAMP -- 上架时间戳
    ,'9999/12/31' AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_PAY_INFO_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP.ODS_MCSP_PRDU_PAY_INFO_TF AS P1 -- 收单产品基本信息表

WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.ID=2
;
-- ==============聚合层字段映射（第5组）==============
-- 收单产品信息聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM(
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'POS' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS NEED_DVLP_FLAG -- 需开发标志
    ,'' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'POS' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'POS' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'01' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,'POS' AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,'' AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,'' AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,'' AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,'' AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,'' AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,'' AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,'' AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,'' AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,'' AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,'' AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,'' AS FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,'' AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,'' AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,'' AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,'1' AS PUT_ON_FLAG -- 上架标志
    ,'9999/12/31' AS PUT_ON_TM_STAMP -- 上架时间戳
    ,'9999/12/31' AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_PAY_INFO_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP.ODS_MCSP_PRDU_PAY_INFO_TF AS P1 -- 收单产品基本信息表

WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.ID=2
;
-- ==============聚合层字段映射（第6组）==============
-- 收单产品信息聚合

INSERT INTO TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM(
     RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,NEED_DVLP_FLAG -- 需开发标志
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,RECV_BIL_PROD_DESC -- 收单产品描述
    ,CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,PUT_ON_FLAG -- 上架标志
    ,PUT_ON_TM_STAMP -- 上架时间戳
    ,CREATE_TM_STAMP -- 创建时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     'OPENPOSP' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS NEED_DVLP_FLAG -- 需开发标志
    ,'' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'OPEN2' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'OPEN' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'03' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,'OPENPOSP' AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,'' AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,'' AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,'' AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,'' AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,'' AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,'' AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,'' AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,'' AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,'' AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,'' AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,'' AS FIT_TERMN_TYPE_SEQ -- 特约商户appid维护标志
    ,'' AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,'' AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,'' AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,'1' AS PUT_ON_FLAG -- 上架标志
    ,'9999/12/31' AS PUT_ON_TM_STAMP -- 上架时间戳
    ,'9999/12/31' AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,'' AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_PAY_INFO_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP.ODS_MCSP_PRDU_PAY_INFO_TF AS P1 -- 收单产品基本信息表

WHERE P1.PT_DT='${process_date}' 
AND P1.DEL_F='0'
AND P1.ID=2
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_RECV_BIL_PROD_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_NO, BF.RECV_BIL_PROD_NO) END AS RECV_BIL_PROD_NO -- 收单产品编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_NAME, BF.RECV_BIL_PROD_NAME) END AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.NEED_DVLP_FLAG IS NULL THEN NULL ELSE COALESCE(TM.NEED_DVLP_FLAG, BF.NEED_DVLP_FLAG) END AS NEED_DVLP_FLAG -- 需开发标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_TYPE_CD, BF.RECV_BIL_PROD_TYPE_CD) END AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SRC_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SRC_CD, BF.RECV_BIL_PROD_SRC_CD) END AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_MCLS_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_MCLS_CD, BF.RECV_BIL_PROD_MCLS_CD) END AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_MDL_CATOGR_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD, BF.RECV_BIL_PROD_MDL_CATOGR_CD) END AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SCLS_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SCLS_CD, BF.RECV_BIL_PROD_SCLS_CD) END AS RECV_BIL_PROD_SCLS_CD -- 收单产品小类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_DESC IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_DESC, BF.RECV_BIL_PROD_DESC) END AS RECV_BIL_PROD_DESC -- 收单产品描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CAN_CHOOSE_FEE_MODE_SEQ IS NULL THEN NULL ELSE COALESCE(TM.CAN_CHOOSE_FEE_MODE_SEQ, BF.CAN_CHOOSE_FEE_MODE_SEQ) END AS CAN_CHOOSE_FEE_MODE_SEQ -- 可选计费模式序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CAN_CHOOSE_PAY_MODE_SEQ IS NULL THEN NULL ELSE COALESCE(TM.CAN_CHOOSE_PAY_MODE_SEQ, BF.CAN_CHOOSE_PAY_MODE_SEQ) END AS CAN_CHOOSE_PAY_MODE_SEQ -- 可选支付方式序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BIG_WALLET_FIT_ORG_NO_SEQ IS NULL THEN NULL ELSE COALESCE(TM.BIG_WALLET_FIT_ORG_NO_SEQ, BF.BIG_WALLET_FIT_ORG_NO_SEQ) END AS BIG_WALLET_FIT_ORG_NO_SEQ -- 大钱包适用机构编号序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SMALL_WALLET_FIT_ORG_NO_SEQ IS NULL THEN NULL ELSE COALESCE(TM.SMALL_WALLET_FIT_ORG_NO_SEQ, BF.SMALL_WALLET_FIT_ORG_NO_SEQ) END AS SMALL_WALLET_FIT_ORG_NO_SEQ -- 小钱包适用机构编号序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PROD_FIT_ORG_NO_SEQ IS NULL THEN NULL ELSE COALESCE(TM.PROD_FIT_ORG_NO_SEQ, BF.PROD_FIT_ORG_NO_SEQ) END AS PROD_FIT_ORG_NO_SEQ -- 产品适用机构编号序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FIT_MERCHT_ATTR_CD IS NULL THEN NULL ELSE COALESCE(TM.FIT_MERCHT_ATTR_CD, BF.FIT_MERCHT_ATTR_CD) END AS FIT_MERCHT_ATTR_CD -- 适用商户属性代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FIT_MERCHT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.FIT_MERCHT_TYPE_CD, BF.FIT_MERCHT_TYPE_CD) END AS FIT_MERCHT_TYPE_CD -- 适用商户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FIT_MERCHT_MCC_CD_SEQ IS NULL THEN NULL ELSE COALESCE(TM.FIT_MERCHT_MCC_CD_SEQ, BF.FIT_MERCHT_MCC_CD_SEQ) END AS FIT_MERCHT_MCC_CD_SEQ -- 适用商户MCC代码序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FIT_APP_OBJ_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.FIT_APP_OBJ_TYPE_CD, BF.FIT_APP_OBJ_TYPE_CD) END AS FIT_APP_OBJ_TYPE_CD -- 适用申请对象类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SAM_APPID_MATN_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SAM_APPID_MATN_FLAG, BF.SAM_APPID_MATN_FLAG) END AS SAM_APPID_MATN_FLAG -- 特约商户appid维护标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_APPID_MATN_FLAG IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_APPID_MATN_FLAG, BF.SERV_PROVDER_APPID_MATN_FLAG) END AS SERV_PROVDER_APPID_MATN_FLAG -- 服务商appid维护标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FIT_TERMN_TYPE_SEQ IS NULL THEN NULL ELSE COALESCE(TM.FIT_TERMN_TYPE_SEQ, BF.FIT_TERMN_TYPE_SEQ) END AS FIT_TERMN_TYPE_SEQ -- 适用终端类型序列
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUTO_TUNE_PAY_CTRL_FLAG IS NULL THEN NULL ELSE COALESCE(TM.AUTO_TUNE_PAY_CTRL_FLAG, BF.AUTO_TUNE_PAY_CTRL_FLAG) END AS AUTO_TUNE_PAY_CTRL_FLAG -- 自动调起支付控件标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PUT_ON_FLAG IS NULL THEN NULL ELSE COALESCE(TM.PUT_ON_FLAG, BF.PUT_ON_FLAG) END AS PUT_ON_FLAG -- 上架标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PUT_ON_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.PUT_ON_TM_STAMP, BF.PUT_ON_TM_STAMP) END AS PUT_ON_TM_STAMP -- 上架时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CREATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.CREATE_TM_STAMP, BF.CREATE_TM_STAMP) END AS CREATE_TM_STAMP -- 创建时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_TELR_NO, BF.INPUT_TELR_NO) END AS INPUT_TELR_NO -- 录入柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_ORG_NO, BF.INPUT_ORG_NO) END AS INPUT_ORG_NO -- 录入机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_TM_STAMP, BF.FINAL_UPDATE_TM_STAMP) END AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_MODIF_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RECNT_MODIF_ORG_NO, BF.RECNT_MODIF_ORG_NO) END AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_NAME,'') = COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段相等
         AND COALESCE(TM.NEED_DVLP_FLAG,'') = COALESCE(BF.NEED_DVLP_FLAG,'') -- 需开发标志 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') = COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') = COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') = COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') = COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SCLS_CD,'') = COALESCE(BF.RECV_BIL_PROD_SCLS_CD,'') -- 收单产品小类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_DESC,'') = COALESCE(BF.RECV_BIL_PROD_DESC,'') -- 收单产品描述 非主键字段相等
         AND COALESCE(TM.CAN_CHOOSE_FEE_MODE_SEQ,'') = COALESCE(BF.CAN_CHOOSE_FEE_MODE_SEQ,'') -- 可选计费模式序列 非主键字段相等
         AND COALESCE(TM.CAN_CHOOSE_PAY_MODE_SEQ,'') = COALESCE(BF.CAN_CHOOSE_PAY_MODE_SEQ,'') -- 可选支付方式序列 非主键字段相等
         AND COALESCE(TM.BIG_WALLET_FIT_ORG_NO_SEQ,'') = COALESCE(BF.BIG_WALLET_FIT_ORG_NO_SEQ,'') -- 大钱包适用机构编号序列 非主键字段相等
         AND COALESCE(TM.SMALL_WALLET_FIT_ORG_NO_SEQ,'') = COALESCE(BF.SMALL_WALLET_FIT_ORG_NO_SEQ,'') -- 小钱包适用机构编号序列 非主键字段相等
         AND COALESCE(TM.PROD_FIT_ORG_NO_SEQ,'') = COALESCE(BF.PROD_FIT_ORG_NO_SEQ,'') -- 产品适用机构编号序列 非主键字段相等
         AND COALESCE(TM.FIT_MERCHT_ATTR_CD,'') = COALESCE(BF.FIT_MERCHT_ATTR_CD,'') -- 适用商户属性代码 非主键字段相等
         AND COALESCE(TM.FIT_MERCHT_TYPE_CD,'') = COALESCE(BF.FIT_MERCHT_TYPE_CD,'') -- 适用商户类型代码 非主键字段相等
         AND COALESCE(TM.FIT_MERCHT_MCC_CD_SEQ,'') = COALESCE(BF.FIT_MERCHT_MCC_CD_SEQ,'') -- 适用商户MCC代码序列 非主键字段相等
         AND COALESCE(TM.FIT_APP_OBJ_TYPE_CD,'') = COALESCE(BF.FIT_APP_OBJ_TYPE_CD,'') -- 适用申请对象类型代码 非主键字段相等
         AND COALESCE(TM.SAM_APPID_MATN_FLAG,'') = COALESCE(BF.SAM_APPID_MATN_FLAG,'') -- 特约商户appid维护标志 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_APPID_MATN_FLAG,'') = COALESCE(BF.SERV_PROVDER_APPID_MATN_FLAG,'') -- 服务商appid维护标志 非主键字段相等
         AND COALESCE(TM.FIT_TERMN_TYPE_SEQ,'') = COALESCE(BF.FIT_TERMN_TYPE_SEQ,'') -- 适用终端类型序列 非主键字段相等
         AND COALESCE(TM.AUTO_TUNE_PAY_CTRL_FLAG,'') = COALESCE(BF.AUTO_TUNE_PAY_CTRL_FLAG,'') -- 自动调起支付控件标志 非主键字段相等
         AND COALESCE(TM.PUT_ON_FLAG,'') = COALESCE(BF.PUT_ON_FLAG,'') -- 上架标志 非主键字段相等
         AND COALESCE(TM.PUT_ON_TM_STAMP,'') = COALESCE(BF.PUT_ON_TM_STAMP,'') -- 上架时间戳 非主键字段相等
         AND COALESCE(TM.CREATE_TM_STAMP,'') = COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段相等
         AND COALESCE(TM.INPUT_TELR_NO,'') = COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段相等
         AND COALESCE(TM.INPUT_ORG_NO,'') = COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_NAME,'') <> COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段不相等
         OR COALESCE(TM.NEED_DVLP_FLAG,'') <> COALESCE(BF.NEED_DVLP_FLAG,'') -- 需开发标志 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') <> COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SCLS_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SCLS_CD,'') -- 收单产品小类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_DESC,'') <> COALESCE(BF.RECV_BIL_PROD_DESC,'') -- 收单产品描述 非主键字段不相等
         OR COALESCE(TM.CAN_CHOOSE_FEE_MODE_SEQ,'') <> COALESCE(BF.CAN_CHOOSE_FEE_MODE_SEQ,'') -- 可选计费模式序列 非主键字段不相等
         OR COALESCE(TM.CAN_CHOOSE_PAY_MODE_SEQ,'') <> COALESCE(BF.CAN_CHOOSE_PAY_MODE_SEQ,'') -- 可选支付方式序列 非主键字段不相等
         OR COALESCE(TM.BIG_WALLET_FIT_ORG_NO_SEQ,'') <> COALESCE(BF.BIG_WALLET_FIT_ORG_NO_SEQ,'') -- 大钱包适用机构编号序列 非主键字段不相等
         OR COALESCE(TM.SMALL_WALLET_FIT_ORG_NO_SEQ,'') <> COALESCE(BF.SMALL_WALLET_FIT_ORG_NO_SEQ,'') -- 小钱包适用机构编号序列 非主键字段不相等
         OR COALESCE(TM.PROD_FIT_ORG_NO_SEQ,'') <> COALESCE(BF.PROD_FIT_ORG_NO_SEQ,'') -- 产品适用机构编号序列 非主键字段不相等
         OR COALESCE(TM.FIT_MERCHT_ATTR_CD,'') <> COALESCE(BF.FIT_MERCHT_ATTR_CD,'') -- 适用商户属性代码 非主键字段不相等
         OR COALESCE(TM.FIT_MERCHT_TYPE_CD,'') <> COALESCE(BF.FIT_MERCHT_TYPE_CD,'') -- 适用商户类型代码 非主键字段不相等
         OR COALESCE(TM.FIT_MERCHT_MCC_CD_SEQ,'') <> COALESCE(BF.FIT_MERCHT_MCC_CD_SEQ,'') -- 适用商户MCC代码序列 非主键字段不相等
         OR COALESCE(TM.FIT_APP_OBJ_TYPE_CD,'') <> COALESCE(BF.FIT_APP_OBJ_TYPE_CD,'') -- 适用申请对象类型代码 非主键字段不相等
         OR COALESCE(TM.SAM_APPID_MATN_FLAG,'') <> COALESCE(BF.SAM_APPID_MATN_FLAG,'') -- 特约商户appid维护标志 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_APPID_MATN_FLAG,'') <> COALESCE(BF.SERV_PROVDER_APPID_MATN_FLAG,'') -- 服务商appid维护标志 非主键字段不相等
         OR COALESCE(TM.FIT_TERMN_TYPE_SEQ,'') <> COALESCE(BF.FIT_TERMN_TYPE_SEQ,'') -- 适用终端类型序列 非主键字段不相等
         OR COALESCE(TM.AUTO_TUNE_PAY_CTRL_FLAG,'') <> COALESCE(BF.AUTO_TUNE_PAY_CTRL_FLAG,'') -- 自动调起支付控件标志 非主键字段不相等
         OR COALESCE(TM.PUT_ON_FLAG,'') <> COALESCE(BF.PUT_ON_FLAG,'') -- 上架标志 非主键字段不相等
         OR COALESCE(TM.PUT_ON_TM_STAMP,'') <> COALESCE(BF.PUT_ON_TM_STAMP,'') -- 上架时间戳 非主键字段不相等
         OR COALESCE(TM.CREATE_TM_STAMP,'') <> COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段不相等
         OR COALESCE(TM.INPUT_TELR_NO,'') <> COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段不相等
         OR COALESCE(TM.INPUT_ORG_NO,'') <> COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_NAME,'') = COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段相等
         AND COALESCE(TM.NEED_DVLP_FLAG,'') = COALESCE(BF.NEED_DVLP_FLAG,'') -- 需开发标志 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') = COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') = COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') = COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') = COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SCLS_CD,'') = COALESCE(BF.RECV_BIL_PROD_SCLS_CD,'') -- 收单产品小类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_DESC,'') = COALESCE(BF.RECV_BIL_PROD_DESC,'') -- 收单产品描述 非主键字段相等
         AND COALESCE(TM.CAN_CHOOSE_FEE_MODE_SEQ,'') = COALESCE(BF.CAN_CHOOSE_FEE_MODE_SEQ,'') -- 可选计费模式序列 非主键字段相等
         AND COALESCE(TM.CAN_CHOOSE_PAY_MODE_SEQ,'') = COALESCE(BF.CAN_CHOOSE_PAY_MODE_SEQ,'') -- 可选支付方式序列 非主键字段相等
         AND COALESCE(TM.BIG_WALLET_FIT_ORG_NO_SEQ,'') = COALESCE(BF.BIG_WALLET_FIT_ORG_NO_SEQ,'') -- 大钱包适用机构编号序列 非主键字段相等
         AND COALESCE(TM.SMALL_WALLET_FIT_ORG_NO_SEQ,'') = COALESCE(BF.SMALL_WALLET_FIT_ORG_NO_SEQ,'') -- 小钱包适用机构编号序列 非主键字段相等
         AND COALESCE(TM.PROD_FIT_ORG_NO_SEQ,'') = COALESCE(BF.PROD_FIT_ORG_NO_SEQ,'') -- 产品适用机构编号序列 非主键字段相等
         AND COALESCE(TM.FIT_MERCHT_ATTR_CD,'') = COALESCE(BF.FIT_MERCHT_ATTR_CD,'') -- 适用商户属性代码 非主键字段相等
         AND COALESCE(TM.FIT_MERCHT_TYPE_CD,'') = COALESCE(BF.FIT_MERCHT_TYPE_CD,'') -- 适用商户类型代码 非主键字段相等
         AND COALESCE(TM.FIT_MERCHT_MCC_CD_SEQ,'') = COALESCE(BF.FIT_MERCHT_MCC_CD_SEQ,'') -- 适用商户MCC代码序列 非主键字段相等
         AND COALESCE(TM.FIT_APP_OBJ_TYPE_CD,'') = COALESCE(BF.FIT_APP_OBJ_TYPE_CD,'') -- 适用申请对象类型代码 非主键字段相等
         AND COALESCE(TM.SAM_APPID_MATN_FLAG,'') = COALESCE(BF.SAM_APPID_MATN_FLAG,'') -- 特约商户appid维护标志 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_APPID_MATN_FLAG,'') = COALESCE(BF.SERV_PROVDER_APPID_MATN_FLAG,'') -- 服务商appid维护标志 非主键字段相等
         AND COALESCE(TM.FIT_TERMN_TYPE_SEQ,'') = COALESCE(BF.FIT_TERMN_TYPE_SEQ,'') -- 适用终端类型序列 非主键字段相等
         AND COALESCE(TM.AUTO_TUNE_PAY_CTRL_FLAG,'') = COALESCE(BF.AUTO_TUNE_PAY_CTRL_FLAG,'') -- 自动调起支付控件标志 非主键字段相等
         AND COALESCE(TM.PUT_ON_FLAG,'') = COALESCE(BF.PUT_ON_FLAG,'') -- 上架标志 非主键字段相等
         AND COALESCE(TM.PUT_ON_TM_STAMP,'') = COALESCE(BF.PUT_ON_TM_STAMP,'') -- 上架时间戳 非主键字段相等
         AND COALESCE(TM.CREATE_TM_STAMP,'') = COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段相等
         AND COALESCE(TM.INPUT_TELR_NO,'') = COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段相等
         AND COALESCE(TM.INPUT_ORG_NO,'') = COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_NAME,'') <> COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段不相等
         OR COALESCE(TM.NEED_DVLP_FLAG,'') <> COALESCE(BF.NEED_DVLP_FLAG,'') -- 需开发标志 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') <> COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SCLS_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SCLS_CD,'') -- 收单产品小类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_DESC,'') <> COALESCE(BF.RECV_BIL_PROD_DESC,'') -- 收单产品描述 非主键字段不相等
         OR COALESCE(TM.CAN_CHOOSE_FEE_MODE_SEQ,'') <> COALESCE(BF.CAN_CHOOSE_FEE_MODE_SEQ,'') -- 可选计费模式序列 非主键字段不相等
         OR COALESCE(TM.CAN_CHOOSE_PAY_MODE_SEQ,'') <> COALESCE(BF.CAN_CHOOSE_PAY_MODE_SEQ,'') -- 可选支付方式序列 非主键字段不相等
         OR COALESCE(TM.BIG_WALLET_FIT_ORG_NO_SEQ,'') <> COALESCE(BF.BIG_WALLET_FIT_ORG_NO_SEQ,'') -- 大钱包适用机构编号序列 非主键字段不相等
         OR COALESCE(TM.SMALL_WALLET_FIT_ORG_NO_SEQ,'') <> COALESCE(BF.SMALL_WALLET_FIT_ORG_NO_SEQ,'') -- 小钱包适用机构编号序列 非主键字段不相等
         OR COALESCE(TM.PROD_FIT_ORG_NO_SEQ,'') <> COALESCE(BF.PROD_FIT_ORG_NO_SEQ,'') -- 产品适用机构编号序列 非主键字段不相等
         OR COALESCE(TM.FIT_MERCHT_ATTR_CD,'') <> COALESCE(BF.FIT_MERCHT_ATTR_CD,'') -- 适用商户属性代码 非主键字段不相等
         OR COALESCE(TM.FIT_MERCHT_TYPE_CD,'') <> COALESCE(BF.FIT_MERCHT_TYPE_CD,'') -- 适用商户类型代码 非主键字段不相等
         OR COALESCE(TM.FIT_MERCHT_MCC_CD_SEQ,'') <> COALESCE(BF.FIT_MERCHT_MCC_CD_SEQ,'') -- 适用商户MCC代码序列 非主键字段不相等
         OR COALESCE(TM.FIT_APP_OBJ_TYPE_CD,'') <> COALESCE(BF.FIT_APP_OBJ_TYPE_CD,'') -- 适用申请对象类型代码 非主键字段不相等
         OR COALESCE(TM.SAM_APPID_MATN_FLAG,'') <> COALESCE(BF.SAM_APPID_MATN_FLAG,'') -- 特约商户appid维护标志 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_APPID_MATN_FLAG,'') <> COALESCE(BF.SERV_PROVDER_APPID_MATN_FLAG,'') -- 服务商appid维护标志 非主键字段不相等
         OR COALESCE(TM.FIT_TERMN_TYPE_SEQ,'') <> COALESCE(BF.FIT_TERMN_TYPE_SEQ,'') -- 适用终端类型序列 非主键字段不相等
         OR COALESCE(TM.AUTO_TUNE_PAY_CTRL_FLAG,'') <> COALESCE(BF.AUTO_TUNE_PAY_CTRL_FLAG,'') -- 自动调起支付控件标志 非主键字段不相等
         OR COALESCE(TM.PUT_ON_FLAG,'') <> COALESCE(BF.PUT_ON_FLAG,'') -- 上架标志 非主键字段不相等
         OR COALESCE(TM.PUT_ON_TM_STAMP,'') <> COALESCE(BF.PUT_ON_TM_STAMP,'') -- 上架时间戳 非主键字段不相等
         OR COALESCE(TM.CREATE_TM_STAMP,'') <> COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段不相等
         OR COALESCE(TM.INPUT_TELR_NO,'') <> COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段不相等
         OR COALESCE(TM.INPUT_ORG_NO,'') <> COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_RECV_BIL_PROD_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_RECV_BIL_PROD_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.RECV_BIL_PROD_NO,'') = COALESCE(BF.RECV_BIL_PROD_NO,'') -- 收单产品编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_RECV_BIL_PROD_INFO_TF_TM;
