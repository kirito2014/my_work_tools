-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-网联对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_NET_CHECK_ENTRY_DTL_TA
--     表中文名：网联对账明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：UPP_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：原海娜
--     时间粒度：日
--     保留周期：None
--     描述信息：保留三方对账相关的交易信息和流水信息
--     更新记录：
--         2024-07-01 00:00:00 原海娜 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_NET_CHECK_ENTRY_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA_TM
USING ORC
COMMENT '网联对账明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     UPP_SER_NO -- 统一支付平台流水号
    ,MSG_NO -- 报文编号
    ,REQE_SER_NO -- 请求流水号
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,NXY_BIZ_MCLS_CD -- 农信银业务大类代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_CMPLT_TM -- 交易完成时间
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,PASS_BATCH_NO -- 通道批次编号
    ,PLAT_BATCH_NO -- 平台批次编号 
    ,NUCC_PASS_CHECK_ENTRY_STATUS_CD -- 网联通道对账状态代码
    ,NUCC_CORE_CHECK_ENTRY_STATUS_CD -- 网联核心对账状态代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,ACCTN_DT -- 记账日期
    ,NUCC_CHECK_ENTRY_STATUS_CD -- 网联对账状态代码
    ,CHECK_ENTRY_STATUS_INFO_DESC -- 对账状态描述信息
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,LP_ORG_NO -- 法人机构编号
    ,业务术语待申请 -- 统一报文epmId
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,PASS_CLEAR_DT -- 通道清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_NET_CHECK_ENTRY_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 网联对账明细聚合

INSERT INTO TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA_TM(
     UPP_SER_NO -- 统一支付平台流水号
    ,MSG_NO -- 报文编号
    ,REQE_SER_NO -- 请求流水号
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,NXY_BIZ_MCLS_CD -- 农信银业务大类代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_CMPLT_TM -- 交易完成时间
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,PASS_BATCH_NO -- 通道批次编号
    ,PLAT_BATCH_NO -- 平台批次编号 
    ,NUCC_PASS_CHECK_ENTRY_STATUS_CD -- 网联通道对账状态代码
    ,NUCC_CORE_CHECK_ENTRY_STATUS_CD -- 网联核心对账状态代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,ACCTN_DT -- 记账日期
    ,NUCC_CHECK_ENTRY_STATUS_CD -- 网联对账状态代码
    ,CHECK_ENTRY_STATUS_INFO_DESC -- 对账状态描述信息
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,LP_ORG_NO -- 法人机构编号
    ,业务术语待申请 -- 统一报文epmId
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,PASS_CLEAR_DT -- 通道清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TXN_ID AS UPP_SER_NO -- 统一支付平台流水号
    ,P1.MSG_ID AS MSG_NO -- 报文编号
    ,P1.REQ_ID AS REQE_SER_NO -- 请求流水号
    ,P1.CCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,P1.BIZ_TYPE AS NXY_BIZ_MCLS_CD -- 农信银业务大类代码
    ,P1.MSG_TYPE AS RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,P1.MSG_DIRC AS ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,P1.LOAN_TYPE AS DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,P1.TXN_STATUS AS TXN_STATUS_CD -- 交易状态代码
    ,P1.TXN_TIME AS TXN_CMPLT_TM -- 交易完成时间
    ,P1.EX_TXN_ID AS THIRD_PTY_SER_NO -- 第三方流水号
    ,P1.TUL_TRANCE_BATCH_NO AS PASS_BATCH_NO -- 通道批次编号
    ,P1.PLA_TRANCE_BATCH_NO AS PLAT_BATCH_NO -- 平台批次编号 
    ,P1.RECON_TUNNEL_STATUS AS NUCC_PASS_CHECK_ENTRY_STATUS_CD -- 网联通道对账状态代码
    ,P1.RECON_CORE_STATUS AS NUCC_CORE_CHECK_ENTRY_STATUS_CD -- 网联核心对账状态代码
    ,P1.RECON_CLASSIFY_ID AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,unifiedTime(P1.RECON_DATE) AS ACCTN_DT -- 记账日期
    ,P1.RECON_STATUS AS NUCC_CHECK_ENTRY_STATUS_CD -- 网联对账状态代码
    ,P1.RECON_MSG AS CHECK_ENTRY_STATUS_INFO_DESC -- 对账状态描述信息
    ,P1.TUNNEL_ID AS NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,P1.CORE_ID AS NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,P1.TNT_INST_ID AS LP_ORG_NO -- 法人机构编号
    ,P1.EPM_ID AS 业务术语待申请 -- 统一报文epmId
    ,unifiedTime(P1.STTL_DATE) AS PLAT_CLEAR_DT -- 平台清算日期
    ,unifiedTime(P1.CHNL_STTL_DATE) AS PASS_CLEAR_DT -- 通道清算日期
    ,unifiedTime(P1.EX_STTL_DATE) AS CORE_CLEAR_DT -- 核心清算日期
    ,'UPP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_UPP_SP_BATCH_RECON_RESULT_RECORD_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_UPP.ODS_UPP_SP_BATCH_RECON_RESULT_RECORD_TA AS P1 -- 对账结果明细表

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_NET_CHECK_ENTRY_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     UPP_SER_NO -- 统一支付平台流水号
    ,MSG_NO -- 报文编号
    ,REQE_SER_NO -- 请求流水号
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_AMT -- 交易金额
    ,NXY_BIZ_MCLS_CD -- 农信银业务大类代码
    ,RURAL_BANK_CRDT_MSG_TYPE_NO -- 农信银报文类型编号
    ,ACCT_CONT_IDNT_CD -- 账务往来标识代码
    ,DEBIT_CRDT_DIR_CD -- 借贷方向代码
    ,TXN_STATUS_CD -- 交易状态代码
    ,TXN_CMPLT_TM -- 交易完成时间
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,PASS_BATCH_NO -- 通道批次编号
    ,PLAT_BATCH_NO -- 平台批次编号 
    ,NUCC_PASS_CHECK_ENTRY_STATUS_CD -- 网联通道对账状态代码
    ,NUCC_CORE_CHECK_ENTRY_STATUS_CD -- 网联核心对账状态代码
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,ACCTN_DT -- 记账日期
    ,NUCC_CHECK_ENTRY_STATUS_CD -- 网联对账状态代码
    ,CHECK_ENTRY_STATUS_INFO_DESC -- 对账状态描述信息
    ,NXY_CHECK_ENTRY_PASS_CD -- 农信银对账通道代码
    ,NXY_CORE_TYPE_CD -- 农信银核心类型代码
    ,LP_ORG_NO -- 法人机构编号
    ,业务术语待申请 -- 统一报文epmId
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,PASS_CLEAR_DT -- 通道清算日期
    ,CORE_CLEAR_DT -- 核心清算日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_NET_CHECK_ENTRY_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_NET_CHECK_ENTRY_DTL_TA_TM;
