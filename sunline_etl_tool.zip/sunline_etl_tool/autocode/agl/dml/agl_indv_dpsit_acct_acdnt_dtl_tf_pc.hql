-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人存款账户事故明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF
--     表中文名：个人存款账户事故明细聚合
--     创建日期：2024-05-18 00:00:00
--     主键字段：NO, MED_NO, OPER_DT
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：翟向阳
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-17 00:00:00 翟向阳 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM
USING ORC
COMMENT '个人存款账户事故明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     NO -- 编号
    ,ACCT_NO -- 账号
    ,OPER_DT -- 操作日期
    ,MED_NO -- 介质编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,ACCT_NAME -- 账户名称
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,RIGHTS_ORG_NAME -- 有权机构名称
    ,TYPE_CD -- 类型代码
    ,APP_NOTICE_NO -- 申请通知书编号
    ,ORG_NO -- 机构号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,APPRV_TELR_NAME -- 审批柜员名称
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,RELA_NO -- 关联编号
    ,MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ACDNT_AMT -- 事故金额
    ,ACDNT_RSN -- 事故原因
    ,MEASURE_CD -- 措施代码
    ,LIFTED_NOTICE_NO -- 解除通知书编号
    ,LIFTED_ORG_NO -- 解除机构编号
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_OPERR_NAME -- 解除经办人名称
    ,LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,LIFTED_DT -- 解除日期
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACDNT_STATUS_CD -- 事故状态代码
    ,RV_FLAG -- 冲正标志
    ,ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,INPUT_SER_NO -- 录入流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SITU_DESC -- 情况描述
    ,REM -- 备注
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_UPDATE_DT -- 最后修改日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 个人存款账户事故明细聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM(
     NO -- 编号
    ,ACCT_NO -- 账号
    ,OPER_DT -- 操作日期
    ,MED_NO -- 介质编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,ACCT_NAME -- 账户名称
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,RIGHTS_ORG_NAME -- 有权机构名称
    ,TYPE_CD -- 类型代码
    ,APP_NOTICE_NO -- 申请通知书编号
    ,ORG_NO -- 机构号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,APPRV_TELR_NAME -- 审批柜员名称
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,RELA_NO -- 关联编号
    ,MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ACDNT_AMT -- 事故金额
    ,ACDNT_RSN -- 事故原因
    ,MEASURE_CD -- 措施代码
    ,LIFTED_NOTICE_NO -- 解除通知书编号
    ,LIFTED_ORG_NO -- 解除机构编号
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_OPERR_NAME -- 解除经办人名称
    ,LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,LIFTED_DT -- 解除日期
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACDNT_STATUS_CD -- 事故状态代码
    ,RV_FLAG -- 冲正标志
    ,ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,INPUT_SER_NO -- 录入流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SITU_DESC -- 情况描述
    ,REM -- 备注
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_UPDATE_DT -- 最后修改日期
    ,SRC_SYS_CD       -- 来源系统代码
    ,SRC_TAB_EN_NAME  -- 来源表英文名称
    ,GRP_SER_NO       -- 组序号         
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AQ01NO16 AS NO -- 编号
    ,P1.AQ02AC15 AS ACCT_NO -- 账号
    ,unifiedTime(P1.AQ15DATE) AS OPER_DT -- 操作日期
    ,P1.AQ02AC19 AS MED_NO -- 介质编号
    ,'' AS CNTPTY_ACCT_NO -- 对方账户编号
    ,P1.AQ28FLNM AS ACCT_NAME -- 账户名称
    ,'odsdb' AS DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,'' AS RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,P1.AQ16FLNM AS RIGHTS_ORG_NAME -- 有权机构名称
    ,P1.AQ07DZFS AS TYPE_CD -- 类型代码
    ,P1.AQ08NO20 AS APP_NOTICE_NO -- 申请通知书编号
    ,P1.AQ14BRNO AS ORG_NO -- 机构号
    ,P1.AQ13STAF AS HANDLE_TELR_NO -- 经办柜员编号
    ,'' AS AUTH_TELR_NO -- 授权柜员编号
    ,'' AS APPRV_TELR_NAME -- 审批柜员名称
    ,'' AS CHKR_TELR_NAME -- 复核人柜员名称
    ,P1.AQ17FLNM AS OPERR_NAME -- 经办人名称
    ,P1.AQ18CFTP AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,P1.AQ19CFNO AS OPERR_DOC_NO -- 经办人证件号码
    ,P1.AQ27NO16 AS RELA_NO -- 关联编号
    ,P1.AQ29DVKD AS MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,P1.AQ28SN03 AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,P1.AQ11AMT AS ACDNT_AMT -- 事故金额
    ,P1.AQ10YYDM AS ACDNT_RSN -- 事故原因
    ,'' AS MEASURE_CD -- 措施代码
    ,P1.AQ23NO20 AS LIFTED_NOTICE_NO -- 解除通知书编号
    ,P1.AQ21BRNO AS LIFTED_ORG_NO -- 解除机构编号
    ,P1.AQ20STAF AS LIFTED_TELR_NO -- 解除柜员编号
    ,P1.AQ41STAF AS LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,P1.AQ24FLNM AS LIFTED_OPERR_NAME -- 解除经办人名称
    ,P1.AQ25CFTP AS LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,P1.AQ26CFNO AS LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,unifiedTime(P1.AQ22DATE) AS LIFTED_DT -- 解除日期
    ,P1.AQ03CCYC AS CURR_CD -- 币种代码
    ,P1.AQ04CHSX AS CASH_RMT_CD -- 钞汇代码
    ,'' AS ACDNT_STATUS_CD -- 事故状态代码
    ,'' AS RV_FLAG -- 冲正标志
    ,'' AS ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,'' AS INPUT_SER_NO -- 录入流水号
    ,'' AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.AQ12RMRK AS SITU_DESC -- 情况描述
    ,'' AS REM -- 备注
    ,unifiedTime(P1.UPDTSTAM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,unifiedTime(P1.UPOPDATE) AS FINAL_UPDATE_DT -- 最后修改日期
    ,'ODS_CORE' AS SRC_SYS_CD       -- 来源系统代码
    ,'ODS_CORE_BDFMHQAQ_TF' AS SRC_TAB_EN_NAME  -- 来源表英文名称
    ,1 AS GRP_SER_NO       -- 组序号         
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ods_core.ODS_CORE_BDFMHQAQ_TF AS P1 -- 事故登记簿

WHERE P1.PT_DT='${process_date}'  AND P1.DEL_F = '0'  AND P1.AQ07DZFS NOT IN ('6','8','A') 
;
-- ==============聚合层字段映射（第2组）==============
-- 个人存款账户事故明细聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM(
     NO -- 编号
    ,ACCT_NO -- 账号
    ,OPER_DT -- 操作日期
    ,MED_NO -- 介质编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,ACCT_NAME -- 账户名称
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,RIGHTS_ORG_NAME -- 有权机构名称
    ,TYPE_CD -- 类型代码
    ,APP_NOTICE_NO -- 申请通知书编号
    ,ORG_NO -- 机构号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,APPRV_TELR_NAME -- 审批柜员名称
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,RELA_NO -- 关联编号
    ,MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ACDNT_AMT -- 事故金额
    ,ACDNT_RSN -- 事故原因
    ,MEASURE_CD -- 措施代码
    ,LIFTED_NOTICE_NO -- 解除通知书编号
    ,LIFTED_ORG_NO -- 解除机构编号
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_OPERR_NAME -- 解除经办人名称
    ,LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,LIFTED_DT -- 解除日期
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACDNT_STATUS_CD -- 事故状态代码
    ,RV_FLAG -- 冲正标志
    ,ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,INPUT_SER_NO -- 录入流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SITU_DESC -- 情况描述
    ,REM -- 备注
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_UPDATE_DT -- 最后修改日期
    ,SRC_SYS_CD       -- 来源系统代码
    ,SRC_TAB_EN_NAME  -- 来源表英文名称
    ,GRP_SER_NO       -- 组序号         
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.DEDUNO AS NO -- 编号
    ,P1.CUSTAC AS ACCT_NO -- 账号
    ,unifiedTime(P1.TRANDT) AS OPER_DT -- 操作日期
    ,'' AS MED_NO -- 介质编号
    ,P1.OTHEAC AS CNTPTY_ACCT_NO -- 对方账户编号
    ,P1.CUSTNA AS ACCT_NAME -- 账户名称
    ,'nfcp' AS DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,P1.DEOGTP AS RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,P1.DEOGNA AS RIGHTS_ORG_NAME -- 有权机构名称
    ,CASE WHEN P1.DEDUTP IN ('1','2') THEN '7' ELSE '' END  AS TYPE_CD -- 类型代码
    ,P1.DECTNO AS APP_NOTICE_NO -- 申请通知书编号
    ,P1.TRANBR AS ORG_NO -- 机构号
    ,P1.TRANUS AS HANDLE_TELR_NO -- 经办柜员编号
    ,'' AS AUTH_TELR_NO -- 授权柜员编号
    ,P1.PRUSER AS APPRV_TELR_NAME -- 审批柜员名称
    ,P1.CKUSER AS CHKR_TELR_NAME -- 复核人柜员名称
    ,P1.OPNA01 AS OPERR_NAME -- 经办人名称
    ,P1.OPTP01 AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,P1.OPNO01 AS OPERR_DOC_NO -- 经办人证件号码
    ,'' AS RELA_NO -- 关联编号
    ,'' AS MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,'' AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,P1.DEDUAM AS ACDNT_AMT -- 事故金额
    ,P1.REASON AS ACDNT_RSN -- 事故原因
    ,'' AS MEASURE_CD -- 措施代码
    ,'' AS LIFTED_NOTICE_NO -- 解除通知书编号
    ,'' AS LIFTED_ORG_NO -- 解除机构编号
    ,'' AS LIFTED_TELR_NO -- 解除柜员编号
    ,'' AS LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,'' AS LIFTED_OPERR_NAME -- 解除经办人名称
    ,'' AS LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,'' AS LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,NULL AS LIFTED_DT -- 解除日期
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,P1.DEDUST AS ACDNT_STATUS_CD -- 事故状态代码
    ,P1.ISFLAG AS RV_FLAG -- 冲正标志
    ,P1.MONYTO AS ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,P1.TYINSQ AS INPUT_SER_NO -- 录入流水号
    ,P1.SERVTP AS TXN_CHNL_CD -- 交易渠道代码
    ,P1.REMARK AS SITU_DESC -- 情况描述
    ,P1.SIGUNM AS REM -- 备注
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_UPDATE_DT -- 最后修改日期
    ,'ODS_NAS' AS SRC_SYS_CD       -- 来源系统代码
    ,'ODS_NAS_KNB_DEDU_TF' AS SRC_TAB_EN_NAME  -- 来源表英文名称
    ,2 AS GRP_SER_NO       -- 组序号         
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS.ODS_NAS_KNB_DEDU_TF AS P1 -- 扣划登记簿

WHERE P1.PT_DT='${process_date}'  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- 个人存款账户事故明细聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM(
     NO -- 编号
    ,ACCT_NO -- 账号
    ,OPER_DT -- 操作日期
    ,MED_NO -- 介质编号
    ,CNTPTY_ACCT_NO -- 对方账户编号
    ,ACCT_NAME -- 账户名称
    ,DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,RIGHTS_ORG_NAME -- 有权机构名称
    ,TYPE_CD -- 类型代码
    ,APP_NOTICE_NO -- 申请通知书编号
    ,ORG_NO -- 机构号
    ,HANDLE_TELR_NO -- 经办柜员编号
    ,AUTH_TELR_NO -- 授权柜员编号
    ,APPRV_TELR_NAME -- 审批柜员名称
    ,CHKR_TELR_NAME -- 复核人柜员名称
    ,OPERR_NAME -- 经办人名称
    ,OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,OPERR_DOC_NO -- 经办人证件号码
    ,RELA_NO -- 关联编号
    ,MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,ACDNT_AMT -- 事故金额
    ,ACDNT_RSN -- 事故原因
    ,MEASURE_CD -- 措施代码
    ,LIFTED_NOTICE_NO -- 解除通知书编号
    ,LIFTED_ORG_NO -- 解除机构编号
    ,LIFTED_TELR_NO -- 解除柜员编号
    ,LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,LIFTED_OPERR_NAME -- 解除经办人名称
    ,LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,LIFTED_DT -- 解除日期
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACDNT_STATUS_CD -- 事故状态代码
    ,RV_FLAG -- 冲正标志
    ,ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,INPUT_SER_NO -- 录入流水号
    ,TXN_CHNL_CD -- 交易渠道代码
    ,SITU_DESC -- 情况描述
    ,REM -- 备注
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_UPDATE_DT -- 最后修改日期
    ,SRC_SYS_CD       -- 来源系统代码
    ,SRC_TAB_EN_NAME  -- 来源表英文名称
    ,GRP_SER_NO       -- 组序号         
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.FROZNO AS NO -- 编号
    ,P1.CUSTAC AS ACCT_NO -- 账号
    ,unifiedTime(P1.FRBGDT) AS OPER_DT -- 操作日期
    ,'' AS MED_NO -- 介质编号
    ,'' AS CNTPTY_ACCT_NO -- 对方账户编号
    ,'' AS ACCT_NAME -- 账户名称
    ,'nfcp' AS DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,P1.FREXOG AS RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,P1.FROGNA AS RIGHTS_ORG_NAME -- 有权机构名称
    ,'' AS TYPE_CD -- 类型代码
    ,P1.FRCTNO AS APP_NOTICE_NO -- 申请通知书编号
    ,P1.TRANBR AS ORG_NO -- 机构号
    ,P1.TRANUS AS HANDLE_TELR_NO -- 经办柜员编号
    ,'' AS AUTH_TELR_NO -- 授权柜员编号
    ,P1.PRUSER AS APPRV_TELR_NAME -- 审批柜员名称
    ,P1.CKUSER AS CHKR_TELR_NAME -- 复核人柜员名称
    ,P1.FRNA01 AS OPERR_NAME -- 经办人名称
    ,P1.IDTP01 AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,P1.IDNO01 AS OPERR_DOC_NO -- 经办人证件号码
    ,'' AS RELA_NO -- 关联编号
    ,'' AS MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,'' AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,NULL AS ACDNT_AMT -- 事故金额
    ,P1.FRREAS AS ACDNT_RSN -- 事故原因
    ,P1.STOPMS AS MEASURE_CD -- 措施代码
    ,'' AS LIFTED_NOTICE_NO -- 解除通知书编号
    ,'' AS LIFTED_ORG_NO -- 解除机构编号
    ,'' AS LIFTED_TELR_NO -- 解除柜员编号
    ,'' AS LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,'' AS LIFTED_OPERR_NAME -- 解除经办人名称
    ,'' AS LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,'' AS LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,unifiedTime(P1.FREDDT) AS LIFTED_DT -- 解除日期
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,P1.FROZST AS ACDNT_STATUS_CD -- 事故状态代码
    ,'' AS RV_FLAG -- 冲正标志
    ,'' AS ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,'' AS INPUT_SER_NO -- 录入流水号
    ,P1.SERVTP AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS SITU_DESC -- 情况描述
    ,P1.REMARK AS REM -- 备注
    ,unifiedTime(P1.TIMETM) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_UPDATE_DT -- 最后修改日期
    ,'ODS_NAS' AS SRC_SYS_CD       -- 来源系统代码
    ,'ODS_NAS_KNB_FROZ_TF' AS SRC_TAB_EN_NAME  -- 来源表英文名称
    ,3 AS GRP_SER_NO       -- 组序号         
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS.ODS_NAS_KNB_FROZ_TF AS P1 -- 冻结登记簿

WHERE P1.PT_DT='${process_date}'  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.NO IS NULL THEN NULL ELSE COALESCE(TM.NO, BF.NO) END AS NO -- 编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPER_DT IS NULL THEN NULL ELSE COALESCE(TM.OPER_DT, BF.OPER_DT) END AS OPER_DT -- 操作日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MED_NO IS NULL THEN NULL ELSE COALESCE(TM.MED_NO, BF.MED_NO) END AS MED_NO -- 介质编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CNTPTY_ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.CNTPTY_ACCT_NO, BF.CNTPTY_ACCT_NO) END AS CNTPTY_ACCT_NO -- 对方账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DATA_SRC_MODULE_CD IS NULL THEN NULL ELSE COALESCE(TM.DATA_SRC_MODULE_CD, BF.DATA_SRC_MODULE_CD) END AS DATA_SRC_MODULE_CD -- 数据来源模块代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RIGHTS_ORG_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.RIGHTS_ORG_TYPE_CD, BF.RIGHTS_ORG_TYPE_CD) END AS RIGHTS_ORG_TYPE_CD -- 有权机构类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RIGHTS_ORG_NAME IS NULL THEN NULL ELSE COALESCE(TM.RIGHTS_ORG_NAME, BF.RIGHTS_ORG_NAME) END AS RIGHTS_ORG_NAME -- 有权机构名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.TYPE_CD, BF.TYPE_CD) END AS TYPE_CD -- 类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.APP_NOTICE_NO IS NULL THEN NULL ELSE COALESCE(TM.APP_NOTICE_NO, BF.APP_NOTICE_NO) END AS APP_NOTICE_NO -- 申请通知书编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.ORG_NO, BF.ORG_NO) END AS ORG_NO -- 机构号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.HANDLE_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.HANDLE_TELR_NO, BF.HANDLE_TELR_NO) END AS HANDLE_TELR_NO -- 经办柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUTH_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.AUTH_TELR_NO, BF.AUTH_TELR_NO) END AS AUTH_TELR_NO -- 授权柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.APPRV_TELR_NAME IS NULL THEN NULL ELSE COALESCE(TM.APPRV_TELR_NAME, BF.APPRV_TELR_NAME) END AS APPRV_TELR_NAME -- 审批柜员名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CHKR_TELR_NAME IS NULL THEN NULL ELSE COALESCE(TM.CHKR_TELR_NAME, BF.CHKR_TELR_NAME) END AS CHKR_TELR_NAME -- 复核人柜员名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPERR_NAME IS NULL THEN NULL ELSE COALESCE(TM.OPERR_NAME, BF.OPERR_NAME) END AS OPERR_NAME -- 经办人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPERR_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.OPERR_DOCTYP_CD, BF.OPERR_DOCTYP_CD) END AS OPERR_DOCTYP_CD -- 经办人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPERR_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.OPERR_DOC_NO, BF.OPERR_DOC_NO) END AS OPERR_DOC_NO -- 经办人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RELA_NO IS NULL THEN NULL ELSE COALESCE(TM.RELA_NO, BF.RELA_NO) END AS RELA_NO -- 关联编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MNY_PAID_STK_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.MNY_PAID_STK_PROPTY_CD, BF.MNY_PAID_STK_PROPTY_CD) END AS MNY_PAID_STK_PROPTY_CD -- 股金性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ALL_IN_ONE_PSBOOK_NO IS NULL THEN NULL ELSE COALESCE(TM.ALL_IN_ONE_PSBOOK_NO, BF.ALL_IN_ONE_PSBOOK_NO) END AS ALL_IN_ONE_PSBOOK_NO -- 一本通册号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACDNT_AMT IS NULL THEN NULL ELSE COALESCE(TM.ACDNT_AMT, BF.ACDNT_AMT) END AS ACDNT_AMT -- 事故金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACDNT_RSN IS NULL THEN NULL ELSE COALESCE(TM.ACDNT_RSN, BF.ACDNT_RSN) END AS ACDNT_RSN -- 事故原因
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MEASURE_CD IS NULL THEN NULL ELSE COALESCE(TM.MEASURE_CD, BF.MEASURE_CD) END AS MEASURE_CD -- 措施代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_NOTICE_NO IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_NOTICE_NO, BF.LIFTED_NOTICE_NO) END AS LIFTED_NOTICE_NO -- 解除通知书编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_ORG_NO, BF.LIFTED_ORG_NO) END AS LIFTED_ORG_NO -- 解除机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_TELR_NO, BF.LIFTED_TELR_NO) END AS LIFTED_TELR_NO -- 解除柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_AUTH_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_AUTH_TELR_NO, BF.LIFTED_AUTH_TELR_NO) END AS LIFTED_AUTH_TELR_NO -- 解除授权柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_OPERR_NAME IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_OPERR_NAME, BF.LIFTED_OPERR_NAME) END AS LIFTED_OPERR_NAME -- 解除经办人名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_OPERR_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_OPERR_DOCTYP_CD, BF.LIFTED_OPERR_DOCTYP_CD) END AS LIFTED_OPERR_DOCTYP_CD -- 解除经办人证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_OPERR_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_OPERR_DOC_NO, BF.LIFTED_OPERR_DOC_NO) END AS LIFTED_OPERR_DOC_NO -- 解除经办人证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LIFTED_DT IS NULL THEN NULL ELSE COALESCE(TM.LIFTED_DT, BF.LIFTED_DT) END AS LIFTED_DT -- 解除日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.CASH_RMT_CD, BF.CASH_RMT_CD) END AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACDNT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.ACDNT_STATUS_CD, BF.ACDNT_STATUS_CD) END AS ACDNT_STATUS_CD -- 事故状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RV_FLAG IS NULL THEN NULL ELSE COALESCE(TM.RV_FLAG, BF.RV_FLAG) END AS RV_FLAG -- 冲正标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACDNT_CAP_DIR_CD IS NULL THEN NULL ELSE COALESCE(TM.ACDNT_CAP_DIR_CD, BF.ACDNT_CAP_DIR_CD) END AS ACDNT_CAP_DIR_CD -- 事故资金去向代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_SER_NO, BF.INPUT_SER_NO) END AS INPUT_SER_NO -- 录入流水号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TXN_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.TXN_CHNL_CD, BF.TXN_CHNL_CD) END AS TXN_CHNL_CD -- 交易渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SITU_DESC IS NULL THEN NULL ELSE COALESCE(TM.SITU_DESC, BF.SITU_DESC) END AS SITU_DESC -- 情况描述
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REM IS NULL THEN NULL ELSE COALESCE(TM.REM, BF.REM) END AS REM -- 备注
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TM_STAMP, BF.FINAL_MODIF_TM_STAMP) END AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_DT, BF.FINAL_UPDATE_DT) END AS FINAL_UPDATE_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账号 非主键字段相等
         AND COALESCE(TM.CNTPTY_ACCT_NO,'') = COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.DATA_SRC_MODULE_CD,'') = COALESCE(BF.DATA_SRC_MODULE_CD,'') -- 数据来源模块代码 非主键字段相等
         AND COALESCE(TM.RIGHTS_ORG_TYPE_CD,'') = COALESCE(BF.RIGHTS_ORG_TYPE_CD,'') -- 有权机构类型代码 非主键字段相等
         AND COALESCE(TM.RIGHTS_ORG_NAME,'') = COALESCE(BF.RIGHTS_ORG_NAME,'') -- 有权机构名称 非主键字段相等
         AND COALESCE(TM.TYPE_CD,'') = COALESCE(BF.TYPE_CD,'') -- 类型代码 非主键字段相等
         AND COALESCE(TM.APP_NOTICE_NO,'') = COALESCE(BF.APP_NOTICE_NO,'') -- 申请通知书编号 非主键字段相等
         AND COALESCE(TM.ORG_NO,'') = COALESCE(BF.ORG_NO,'') -- 机构号 非主键字段相等
         AND COALESCE(TM.HANDLE_TELR_NO,'') = COALESCE(BF.HANDLE_TELR_NO,'') -- 经办柜员编号 非主键字段相等
         AND COALESCE(TM.AUTH_TELR_NO,'') = COALESCE(BF.AUTH_TELR_NO,'') -- 授权柜员编号 非主键字段相等
         AND COALESCE(TM.APPRV_TELR_NAME,'') = COALESCE(BF.APPRV_TELR_NAME,'') -- 审批柜员名称 非主键字段相等
         AND COALESCE(TM.CHKR_TELR_NAME,'') = COALESCE(BF.CHKR_TELR_NAME,'') -- 复核人柜员名称 非主键字段相等
         AND COALESCE(TM.OPERR_NAME,'') = COALESCE(BF.OPERR_NAME,'') -- 经办人名称 非主键字段相等
         AND COALESCE(TM.OPERR_DOCTYP_CD,'') = COALESCE(BF.OPERR_DOCTYP_CD,'') -- 经办人证件类型代码 非主键字段相等
         AND COALESCE(TM.OPERR_DOC_NO,'') = COALESCE(BF.OPERR_DOC_NO,'') -- 经办人证件号码 非主键字段相等
         AND COALESCE(TM.RELA_NO,'') = COALESCE(BF.RELA_NO,'') -- 关联编号 非主键字段相等
         AND COALESCE(TM.MNY_PAID_STK_PROPTY_CD,'') = COALESCE(BF.MNY_PAID_STK_PROPTY_CD,'') -- 股金性质代码 非主键字段相等
         AND COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') = COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段相等
         AND COALESCE(TM.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) -- 事故金额 非主键字段相等
         AND COALESCE(TM.ACDNT_RSN,'') = COALESCE(BF.ACDNT_RSN,'') -- 事故原因 非主键字段相等
         AND COALESCE(TM.MEASURE_CD,'') = COALESCE(BF.MEASURE_CD,'') -- 措施代码 非主键字段相等
         AND COALESCE(TM.LIFTED_NOTICE_NO,'') = COALESCE(BF.LIFTED_NOTICE_NO,'') -- 解除通知书编号 非主键字段相等
         AND COALESCE(TM.LIFTED_ORG_NO,'') = COALESCE(BF.LIFTED_ORG_NO,'') -- 解除机构编号 非主键字段相等
         AND COALESCE(TM.LIFTED_TELR_NO,'') = COALESCE(BF.LIFTED_TELR_NO,'') -- 解除柜员编号 非主键字段相等
         AND COALESCE(TM.LIFTED_AUTH_TELR_NO,'') = COALESCE(BF.LIFTED_AUTH_TELR_NO,'') -- 解除授权柜员编号 非主键字段相等
         AND COALESCE(TM.LIFTED_OPERR_NAME,'') = COALESCE(BF.LIFTED_OPERR_NAME,'') -- 解除经办人名称 非主键字段相等
         AND COALESCE(TM.LIFTED_OPERR_DOCTYP_CD,'') = COALESCE(BF.LIFTED_OPERR_DOCTYP_CD,'') -- 解除经办人证件类型代码 非主键字段相等
         AND COALESCE(TM.LIFTED_OPERR_DOC_NO,'') = COALESCE(BF.LIFTED_OPERR_DOC_NO,'') -- 解除经办人证件号码 非主键字段相等
         AND COALESCE(TM.LIFTED_DT,'') = COALESCE(BF.LIFTED_DT,'') -- 解除日期 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段相等
         AND COALESCE(TM.ACDNT_STATUS_CD,'') = COALESCE(BF.ACDNT_STATUS_CD,'') -- 事故状态代码 非主键字段相等
         AND COALESCE(TM.RV_FLAG,'') = COALESCE(BF.RV_FLAG,'') -- 冲正标志 非主键字段相等
         AND COALESCE(TM.ACDNT_CAP_DIR_CD,'') = COALESCE(BF.ACDNT_CAP_DIR_CD,'') -- 事故资金去向代码 非主键字段相等
         AND COALESCE(TM.INPUT_SER_NO,'') = COALESCE(BF.INPUT_SER_NO,'') -- 录入流水号 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.SITU_DESC,'') = COALESCE(BF.SITU_DESC,'') -- 情况描述 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_DT,'') = COALESCE(BF.FINAL_UPDATE_DT,'') -- 最后修改日期 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账号 非主键字段不相等
         OR COALESCE(TM.CNTPTY_ACCT_NO,'') <> COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.DATA_SRC_MODULE_CD,'') <> COALESCE(BF.DATA_SRC_MODULE_CD,'') -- 数据来源模块代码 非主键字段不相等
         OR COALESCE(TM.RIGHTS_ORG_TYPE_CD,'') <> COALESCE(BF.RIGHTS_ORG_TYPE_CD,'') -- 有权机构类型代码 非主键字段不相等
         OR COALESCE(TM.RIGHTS_ORG_NAME,'') <> COALESCE(BF.RIGHTS_ORG_NAME,'') -- 有权机构名称 非主键字段不相等
         OR COALESCE(TM.TYPE_CD,'') <> COALESCE(BF.TYPE_CD,'') -- 类型代码 非主键字段不相等
         OR COALESCE(TM.APP_NOTICE_NO,'') <> COALESCE(BF.APP_NOTICE_NO,'') -- 申请通知书编号 非主键字段不相等
         OR COALESCE(TM.ORG_NO,'') <> COALESCE(BF.ORG_NO,'') -- 机构号 非主键字段不相等
         OR COALESCE(TM.HANDLE_TELR_NO,'') <> COALESCE(BF.HANDLE_TELR_NO,'') -- 经办柜员编号 非主键字段不相等
         OR COALESCE(TM.AUTH_TELR_NO,'') <> COALESCE(BF.AUTH_TELR_NO,'') -- 授权柜员编号 非主键字段不相等
         OR COALESCE(TM.APPRV_TELR_NAME,'') <> COALESCE(BF.APPRV_TELR_NAME,'') -- 审批柜员名称 非主键字段不相等
         OR COALESCE(TM.CHKR_TELR_NAME,'') <> COALESCE(BF.CHKR_TELR_NAME,'') -- 复核人柜员名称 非主键字段不相等
         OR COALESCE(TM.OPERR_NAME,'') <> COALESCE(BF.OPERR_NAME,'') -- 经办人名称 非主键字段不相等
         OR COALESCE(TM.OPERR_DOCTYP_CD,'') <> COALESCE(BF.OPERR_DOCTYP_CD,'') -- 经办人证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPERR_DOC_NO,'') <> COALESCE(BF.OPERR_DOC_NO,'') -- 经办人证件号码 非主键字段不相等
         OR COALESCE(TM.RELA_NO,'') <> COALESCE(BF.RELA_NO,'') -- 关联编号 非主键字段不相等
         OR COALESCE(TM.MNY_PAID_STK_PROPTY_CD,'') <> COALESCE(BF.MNY_PAID_STK_PROPTY_CD,'') -- 股金性质代码 非主键字段不相等
         OR COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') <> COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段不相等
         OR COALESCE(TM.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) -- 事故金额 非主键字段不相等
         OR COALESCE(TM.ACDNT_RSN,'') <> COALESCE(BF.ACDNT_RSN,'') -- 事故原因 非主键字段不相等
         OR COALESCE(TM.MEASURE_CD,'') <> COALESCE(BF.MEASURE_CD,'') -- 措施代码 非主键字段不相等
         OR COALESCE(TM.LIFTED_NOTICE_NO,'') <> COALESCE(BF.LIFTED_NOTICE_NO,'') -- 解除通知书编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_ORG_NO,'') <> COALESCE(BF.LIFTED_ORG_NO,'') -- 解除机构编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_TELR_NO,'') <> COALESCE(BF.LIFTED_TELR_NO,'') -- 解除柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_AUTH_TELR_NO,'') <> COALESCE(BF.LIFTED_AUTH_TELR_NO,'') -- 解除授权柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_OPERR_NAME,'') <> COALESCE(BF.LIFTED_OPERR_NAME,'') -- 解除经办人名称 非主键字段不相等
         OR COALESCE(TM.LIFTED_OPERR_DOCTYP_CD,'') <> COALESCE(BF.LIFTED_OPERR_DOCTYP_CD,'') -- 解除经办人证件类型代码 非主键字段不相等
         OR COALESCE(TM.LIFTED_OPERR_DOC_NO,'') <> COALESCE(BF.LIFTED_OPERR_DOC_NO,'') -- 解除经办人证件号码 非主键字段不相等
         OR COALESCE(TM.LIFTED_DT,'') <> COALESCE(BF.LIFTED_DT,'') -- 解除日期 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.CASH_RMT_CD,'') <> COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段不相等
         OR COALESCE(TM.ACDNT_STATUS_CD,'') <> COALESCE(BF.ACDNT_STATUS_CD,'') -- 事故状态代码 非主键字段不相等
         OR COALESCE(TM.RV_FLAG,'') <> COALESCE(BF.RV_FLAG,'') -- 冲正标志 非主键字段不相等
         OR COALESCE(TM.ACDNT_CAP_DIR_CD,'') <> COALESCE(BF.ACDNT_CAP_DIR_CD,'') -- 事故资金去向代码 非主键字段不相等
         OR COALESCE(TM.INPUT_SER_NO,'') <> COALESCE(BF.INPUT_SER_NO,'') -- 录入流水号 非主键字段不相等
         OR COALESCE(TM.TXN_CHNL_CD,'') <> COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段不相等
         OR COALESCE(TM.SITU_DESC,'') <> COALESCE(BF.SITU_DESC,'') -- 情况描述 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_DT,'') <> COALESCE(BF.FINAL_UPDATE_DT,'') -- 最后修改日期 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账号 非主键字段相等
         AND COALESCE(TM.CNTPTY_ACCT_NO,'') = COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段相等
         AND COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.DATA_SRC_MODULE_CD,'') = COALESCE(BF.DATA_SRC_MODULE_CD,'') -- 数据来源模块代码 非主键字段相等
         AND COALESCE(TM.RIGHTS_ORG_TYPE_CD,'') = COALESCE(BF.RIGHTS_ORG_TYPE_CD,'') -- 有权机构类型代码 非主键字段相等
         AND COALESCE(TM.RIGHTS_ORG_NAME,'') = COALESCE(BF.RIGHTS_ORG_NAME,'') -- 有权机构名称 非主键字段相等
         AND COALESCE(TM.TYPE_CD,'') = COALESCE(BF.TYPE_CD,'') -- 类型代码 非主键字段相等
         AND COALESCE(TM.APP_NOTICE_NO,'') = COALESCE(BF.APP_NOTICE_NO,'') -- 申请通知书编号 非主键字段相等
         AND COALESCE(TM.ORG_NO,'') = COALESCE(BF.ORG_NO,'') -- 机构号 非主键字段相等
         AND COALESCE(TM.HANDLE_TELR_NO,'') = COALESCE(BF.HANDLE_TELR_NO,'') -- 经办柜员编号 非主键字段相等
         AND COALESCE(TM.AUTH_TELR_NO,'') = COALESCE(BF.AUTH_TELR_NO,'') -- 授权柜员编号 非主键字段相等
         AND COALESCE(TM.APPRV_TELR_NAME,'') = COALESCE(BF.APPRV_TELR_NAME,'') -- 审批柜员名称 非主键字段相等
         AND COALESCE(TM.CHKR_TELR_NAME,'') = COALESCE(BF.CHKR_TELR_NAME,'') -- 复核人柜员名称 非主键字段相等
         AND COALESCE(TM.OPERR_NAME,'') = COALESCE(BF.OPERR_NAME,'') -- 经办人名称 非主键字段相等
         AND COALESCE(TM.OPERR_DOCTYP_CD,'') = COALESCE(BF.OPERR_DOCTYP_CD,'') -- 经办人证件类型代码 非主键字段相等
         AND COALESCE(TM.OPERR_DOC_NO,'') = COALESCE(BF.OPERR_DOC_NO,'') -- 经办人证件号码 非主键字段相等
         AND COALESCE(TM.RELA_NO,'') = COALESCE(BF.RELA_NO,'') -- 关联编号 非主键字段相等
         AND COALESCE(TM.MNY_PAID_STK_PROPTY_CD,'') = COALESCE(BF.MNY_PAID_STK_PROPTY_CD,'') -- 股金性质代码 非主键字段相等
         AND COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') = COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段相等
         AND COALESCE(TM.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) -- 事故金额 非主键字段相等
         AND COALESCE(TM.ACDNT_RSN,'') = COALESCE(BF.ACDNT_RSN,'') -- 事故原因 非主键字段相等
         AND COALESCE(TM.MEASURE_CD,'') = COALESCE(BF.MEASURE_CD,'') -- 措施代码 非主键字段相等
         AND COALESCE(TM.LIFTED_NOTICE_NO,'') = COALESCE(BF.LIFTED_NOTICE_NO,'') -- 解除通知书编号 非主键字段相等
         AND COALESCE(TM.LIFTED_ORG_NO,'') = COALESCE(BF.LIFTED_ORG_NO,'') -- 解除机构编号 非主键字段相等
         AND COALESCE(TM.LIFTED_TELR_NO,'') = COALESCE(BF.LIFTED_TELR_NO,'') -- 解除柜员编号 非主键字段相等
         AND COALESCE(TM.LIFTED_AUTH_TELR_NO,'') = COALESCE(BF.LIFTED_AUTH_TELR_NO,'') -- 解除授权柜员编号 非主键字段相等
         AND COALESCE(TM.LIFTED_OPERR_NAME,'') = COALESCE(BF.LIFTED_OPERR_NAME,'') -- 解除经办人名称 非主键字段相等
         AND COALESCE(TM.LIFTED_OPERR_DOCTYP_CD,'') = COALESCE(BF.LIFTED_OPERR_DOCTYP_CD,'') -- 解除经办人证件类型代码 非主键字段相等
         AND COALESCE(TM.LIFTED_OPERR_DOC_NO,'') = COALESCE(BF.LIFTED_OPERR_DOC_NO,'') -- 解除经办人证件号码 非主键字段相等
         AND COALESCE(TM.LIFTED_DT,'') = COALESCE(BF.LIFTED_DT,'') -- 解除日期 非主键字段相等
         AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段相等
         AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段相等
         AND COALESCE(TM.ACDNT_STATUS_CD,'') = COALESCE(BF.ACDNT_STATUS_CD,'') -- 事故状态代码 非主键字段相等
         AND COALESCE(TM.RV_FLAG,'') = COALESCE(BF.RV_FLAG,'') -- 冲正标志 非主键字段相等
         AND COALESCE(TM.ACDNT_CAP_DIR_CD,'') = COALESCE(BF.ACDNT_CAP_DIR_CD,'') -- 事故资金去向代码 非主键字段相等
         AND COALESCE(TM.INPUT_SER_NO,'') = COALESCE(BF.INPUT_SER_NO,'') -- 录入流水号 非主键字段相等
         AND COALESCE(TM.TXN_CHNL_CD,'') = COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段相等
         AND COALESCE(TM.SITU_DESC,'') = COALESCE(BF.SITU_DESC,'') -- 情况描述 非主键字段相等
         AND COALESCE(TM.REM,'') = COALESCE(BF.REM,'') -- 备注 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_DT,'') = COALESCE(BF.FINAL_UPDATE_DT,'') -- 最后修改日期 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NO,'') <> COALESCE(BF.ACCT_NO,'') -- 账号 非主键字段不相等
         OR COALESCE(TM.CNTPTY_ACCT_NO,'') <> COALESCE(BF.CNTPTY_ACCT_NO,'') -- 对方账户编号 非主键字段不相等
         OR COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.DATA_SRC_MODULE_CD,'') <> COALESCE(BF.DATA_SRC_MODULE_CD,'') -- 数据来源模块代码 非主键字段不相等
         OR COALESCE(TM.RIGHTS_ORG_TYPE_CD,'') <> COALESCE(BF.RIGHTS_ORG_TYPE_CD,'') -- 有权机构类型代码 非主键字段不相等
         OR COALESCE(TM.RIGHTS_ORG_NAME,'') <> COALESCE(BF.RIGHTS_ORG_NAME,'') -- 有权机构名称 非主键字段不相等
         OR COALESCE(TM.TYPE_CD,'') <> COALESCE(BF.TYPE_CD,'') -- 类型代码 非主键字段不相等
         OR COALESCE(TM.APP_NOTICE_NO,'') <> COALESCE(BF.APP_NOTICE_NO,'') -- 申请通知书编号 非主键字段不相等
         OR COALESCE(TM.ORG_NO,'') <> COALESCE(BF.ORG_NO,'') -- 机构号 非主键字段不相等
         OR COALESCE(TM.HANDLE_TELR_NO,'') <> COALESCE(BF.HANDLE_TELR_NO,'') -- 经办柜员编号 非主键字段不相等
         OR COALESCE(TM.AUTH_TELR_NO,'') <> COALESCE(BF.AUTH_TELR_NO,'') -- 授权柜员编号 非主键字段不相等
         OR COALESCE(TM.APPRV_TELR_NAME,'') <> COALESCE(BF.APPRV_TELR_NAME,'') -- 审批柜员名称 非主键字段不相等
         OR COALESCE(TM.CHKR_TELR_NAME,'') <> COALESCE(BF.CHKR_TELR_NAME,'') -- 复核人柜员名称 非主键字段不相等
         OR COALESCE(TM.OPERR_NAME,'') <> COALESCE(BF.OPERR_NAME,'') -- 经办人名称 非主键字段不相等
         OR COALESCE(TM.OPERR_DOCTYP_CD,'') <> COALESCE(BF.OPERR_DOCTYP_CD,'') -- 经办人证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPERR_DOC_NO,'') <> COALESCE(BF.OPERR_DOC_NO,'') -- 经办人证件号码 非主键字段不相等
         OR COALESCE(TM.RELA_NO,'') <> COALESCE(BF.RELA_NO,'') -- 关联编号 非主键字段不相等
         OR COALESCE(TM.MNY_PAID_STK_PROPTY_CD,'') <> COALESCE(BF.MNY_PAID_STK_PROPTY_CD,'') -- 股金性质代码 非主键字段不相等
         OR COALESCE(TM.ALL_IN_ONE_PSBOOK_NO,'') <> COALESCE(BF.ALL_IN_ONE_PSBOOK_NO,'') -- 一本通册号 非主键字段不相等
         OR COALESCE(TM.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACDNT_AMT,CAST(0 AS DECIMAL(28,2))) -- 事故金额 非主键字段不相等
         OR COALESCE(TM.ACDNT_RSN,'') <> COALESCE(BF.ACDNT_RSN,'') -- 事故原因 非主键字段不相等
         OR COALESCE(TM.MEASURE_CD,'') <> COALESCE(BF.MEASURE_CD,'') -- 措施代码 非主键字段不相等
         OR COALESCE(TM.LIFTED_NOTICE_NO,'') <> COALESCE(BF.LIFTED_NOTICE_NO,'') -- 解除通知书编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_ORG_NO,'') <> COALESCE(BF.LIFTED_ORG_NO,'') -- 解除机构编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_TELR_NO,'') <> COALESCE(BF.LIFTED_TELR_NO,'') -- 解除柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_AUTH_TELR_NO,'') <> COALESCE(BF.LIFTED_AUTH_TELR_NO,'') -- 解除授权柜员编号 非主键字段不相等
         OR COALESCE(TM.LIFTED_OPERR_NAME,'') <> COALESCE(BF.LIFTED_OPERR_NAME,'') -- 解除经办人名称 非主键字段不相等
         OR COALESCE(TM.LIFTED_OPERR_DOCTYP_CD,'') <> COALESCE(BF.LIFTED_OPERR_DOCTYP_CD,'') -- 解除经办人证件类型代码 非主键字段不相等
         OR COALESCE(TM.LIFTED_OPERR_DOC_NO,'') <> COALESCE(BF.LIFTED_OPERR_DOC_NO,'') -- 解除经办人证件号码 非主键字段不相等
         OR COALESCE(TM.LIFTED_DT,'') <> COALESCE(BF.LIFTED_DT,'') -- 解除日期 非主键字段不相等
         OR COALESCE(TM.CURR_CD,'') <> COALESCE(BF.CURR_CD,'') -- 币种代码 非主键字段不相等
         OR COALESCE(TM.CASH_RMT_CD,'') <> COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 非主键字段不相等
         OR COALESCE(TM.ACDNT_STATUS_CD,'') <> COALESCE(BF.ACDNT_STATUS_CD,'') -- 事故状态代码 非主键字段不相等
         OR COALESCE(TM.RV_FLAG,'') <> COALESCE(BF.RV_FLAG,'') -- 冲正标志 非主键字段不相等
         OR COALESCE(TM.ACDNT_CAP_DIR_CD,'') <> COALESCE(BF.ACDNT_CAP_DIR_CD,'') -- 事故资金去向代码 非主键字段不相等
         OR COALESCE(TM.INPUT_SER_NO,'') <> COALESCE(BF.INPUT_SER_NO,'') -- 录入流水号 非主键字段不相等
         OR COALESCE(TM.TXN_CHNL_CD,'') <> COALESCE(BF.TXN_CHNL_CD,'') -- 交易渠道代码 非主键字段不相等
         OR COALESCE(TM.SITU_DESC,'') <> COALESCE(BF.SITU_DESC,'') -- 情况描述 非主键字段不相等
         OR COALESCE(TM.REM,'') <> COALESCE(BF.REM,'') -- 备注 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TM_STAMP,'') <> COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_DT,'') <> COALESCE(BF.FINAL_UPDATE_DT,'') -- 最后修改日期 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.NO,'') = COALESCE(BF.NO,'') -- 编号 主键字段关联
    AND COALESCE(TM.OPER_DT,'') = COALESCE(BF.OPER_DT,'') -- 操作日期 主键字段关联
    AND COALESCE(TM.MED_NO,'') = COALESCE(BF.MED_NO,'') -- 介质编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF_TM;
