-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-自助机具非动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA
--     表中文名：自助机具非动账交易明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：BIZ_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建
--         2024-09-12 00:00:00 陈艺丹 修改union1-3主表筛选条件，增加主键；



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM
USING ORC
COMMENT '自助机具非动账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,SERVER_IP -- 服务器IP
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 自助机具非动账交易明细聚合

INSERT INTO TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,SERVER_IP -- 服务器IP
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSEQ AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,'' --unifiedTime(P1.CREATETIME) AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,P1.SRVCD AS FUNC_ID -- 功能ID
    ,P1.SRVDESC AS FUNC_DESC -- 功能描述
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO1 AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO1 AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,P1.IDPASS1 AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,P1.NAME1 AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.RESERVE1 AS VOCH_NO -- 凭证号码
    ,'' AS P_END_RSPS_CD -- P端响应码
    ,'' AS OPBANK_NO -- 开户行行号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS UNIONPAY_SER_NO -- 银联流水号
    ,'' AS BIZ_TYPE_NO -- 业务类型编号
    ,'' AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.NODENO AS EQUIP_NO -- 设备编号
    ,P2.DEV_CATALOG AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P2.VIRTUAL_TELLER_NO AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,CASE WHEN P1.SUCCFLAG='3' THEN '1-是' ELSE '0-否' END AS SUCC_FLAG -- 成功标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,P1.TRANOPER AS TXN_TELR_NO -- 交易柜员编号
    ,P1.CHECKOPER AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN P1.DEL_F='0' THEN '1-是' ELSE '0-否' END AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_STMP_TRANS_TABLE_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ.ODS_ZZQZ_STMP_TRANS_TABLE_TF AS P1 -- 智柜交易流水表

LEFT JOIN ODS_ZZQZ.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.NODENO=P2.NO AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
WHERE (P1.AMOUNT = '0.0' OR COALESCE(TRIM(P1.AMOUNT),'')='') AND P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第2组）==============
-- 自助机具非动账交易明细聚合

INSERT INTO TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,SERVER_IP -- 服务器IP
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSEQ AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,'' --unifiedTime(P1.CREATETIME) AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,P1.SRVCD AS FUNC_ID -- 功能ID
    ,P1.SRVDESC AS FUNC_DESC -- 功能描述
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO1 AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO1 AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,P1.IDPASS1 AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,P1.NAME1 AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.RESERVE1 AS VOCH_NO -- 凭证号码
    ,'' AS P_END_RSPS_CD -- P端响应码
    ,'' AS OPBANK_NO -- 开户行行号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS UNIONPAY_SER_NO -- 银联流水号
    ,'' AS BIZ_TYPE_NO -- 业务类型编号
    ,'' AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.NODENO AS EQUIP_NO -- 设备编号
    ,P2.DEV_CATALOG AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P2.VIRTUAL_TELLER_NO AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,CASE WHEN P1.SUCCFLAG='3' THEN '1-是' ELSE '0-否' END AS SUCC_FLAG -- 成功标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,P1.TRANOPER AS TXN_TELR_NO -- 交易柜员编号
    ,P1.CHECKOPER AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN P1.DEL_F='0' THEN '1-是' ELSE '0-否' END AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_STMP_BSR_TRANS_TABLE_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ.ODS_ZZQZ_STMP_BSR_TRANS_TABLE_TF AS P1 -- 新版助农终端交易流水表

LEFT JOIN ODS_ZZQZ.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.NODENO=P2.NO AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
WHERE (P1.AMOUNT = '0.0' OR COALESCE(TRIM(P1.AMOUNT),'')='') AND P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- 自助机具非动账交易明细聚合

INSERT INTO TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,SERVER_IP -- 服务器IP
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.AT_TERMID,P1.TRANDATE,P1.AT_TRACE) AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,unifiedTime(P1.TRANTIME) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.INITSIDE AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,'' AS FUNC_ID -- 功能ID
    ,'' AS FUNC_DESC -- 功能描述
    ,P1.FRONTTRACE AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,'' AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,'' AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,'' AS VOCH_NO -- 凭证号码
    ,P1.RETCODE AS P_END_RSPS_CD -- P端响应码
    ,P1.ACCTBANK AS OPBANK_NO -- 开户行行号
    ,P1.HOST_TRACE AS HOST_SER_NO -- 主机流水号
    ,P1.GD_TRACE AS UNIONPAY_SER_NO -- 银联流水号
    ,P1.BUSITYPE AS BIZ_TYPE_NO -- 业务类型编号
    ,P1.AT_TRACE AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.AT_TERMID AS EQUIP_NO -- 设备编号
    ,P1.AT_TERMTYPE AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P1.AT_TELLERID AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,P1.SUCCFLAG AS SUCC_FLAG -- 成功标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN P1.DEL_F='0' THEN '1-是' ELSE '0-否' END AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_TRANS_HISTORY_TABLE_TF'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ.ODS_ZZQZ_TRANS_HISTORY_TABLE_TF AS P1 -- 自助交易流水表

LEFT JOIN ODS_ZZQZ.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.AT_TERMID=P2.NO AND P2.PT_DT='${process_date}' AND P2.DEL_F = '0' 
WHERE (P1.AMOUNT = '0.0' OR COALESCE(TRIM(P1.AMOUNT),'')='') AND P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA PARTITION(PT_DT = '${process_date}')
SELECT
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,SERVER_IP -- 服务器IP
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_SELF_SERV_MACH_UN_MVACCT_TXN_DTL_AGGREGT_TA_TM;
