-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人存款账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DPSIT_ACCT_INFO_TF
--     表中文名：个人存款账户信息聚合
--     创建日期：2023-12-29 00:00:00
--     主键字段：ACCT_NO, CASH_RMT_CD, CURR_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军/魏丹丹
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-29 00:00:00 游崔龙 新增
--         2024-01-11 00:00:00 游崔龙 对标
--         2024-02-05 00:00:00 王穆军/魏丹丹 单元测试 代码映射
--         2024-07-23 00:00:00 王穆军/魏丹丹 修改同步设计文档
--         2024-08-18 00:00:00 王穆军/魏丹丹 修改上日取数逻辑
--         2024-09-06 00:00:00 王穆军/魏丹丹 新增字段，逻辑变更
--         2024-10-08 00:00:00 王穆军/魏丹丹 新增字段，删除汇集账户字段
--         2024-10-31 00:00:00 魏丹丹 修改积数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM
USING ORC
COMMENT '个人存款账户信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CUST_TYPE_CD -- 客户类型代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,MED_TYPE_CD -- 介质类型代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,VOCH_NO -- 凭证号码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,CTRL_AMT -- 控制金额
    ,STOP_PAY_AMT -- 止付金额
    ,PRE_AUTH_AMT -- 预授权金额
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,DATA_DT -- 数据日期
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 用户基本信息关联表
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_01;

CREATE TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_01 (
     AA01AC15 STRING COMMENT '账号'
    ,AA04FLNM STRING COMMENT '账户名称'
    ,AA03CSNO STRING COMMENT '客户内码'
    ,AA10CSTP STRING COMMENT '客户类型代码'
    ,AA13ZHTP STRING COMMENT '存款账户性质代码'
    ,AA11ACFG STRING COMMENT '存款账户类型代码'
    ,CB15BDHS STRING COMMENT '存款账户状态代码'
    ,AA12ACT2 STRING COMMENT '介质类型代码'
    ,AA16PZZT STRING COMMENT '挂失状态代码'
    ,AA24SSLV STRING COMMENT '通兑级别代码'
    ,AA25SWLV STRING COMMENT '通存级别代码'
    ,AA14BLNO STRING COMMENT '凭证号码'
    ,AA06BUST STRING COMMENT '存款业务类别代码'
    ,DPSIT_PROD_CD STRING COMMENT '存款产品代码'
    ,AA61CFTP STRING COMMENT '开户证件类型代码'
    ,AA62CFNO STRING COMMENT '开户证件号码'
    ,AA44DATE STRING COMMENT '销户日期'
    ,USER_ID STRING COMMENT '用户ID'
    ,CRTF_TYP STRING COMMENT '客户主证件类型代码'
    ,CRTF_NO STRING COMMENT '客户主证件号码'
    ,CW05FLNM STRING COMMENT '存款产品名称'
    ,AA64SDTP STRING COMMENT '保证金业务种类'
    ,AA48BRNO STRING COMMENT '核算主体行'
    ,AA47BRNO STRING COMMENT '归属网点'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '用户基本信息关联表'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_01(
     AA01AC15 -- 账号
    ,AA04FLNM -- 账户名称
    ,AA03CSNO -- 客户内码
    ,AA10CSTP -- 客户类型代码
    ,AA13ZHTP -- 存款账户性质代码
    ,AA11ACFG -- 存款账户类型代码
    ,CB15BDHS -- 存款账户状态代码
    ,AA12ACT2 -- 介质类型代码
    ,AA16PZZT -- 挂失状态代码
    ,AA24SSLV -- 通兑级别代码
    ,AA25SWLV -- 通存级别代码
    ,AA14BLNO -- 凭证号码
    ,AA06BUST -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,AA61CFTP -- 开户证件类型代码
    ,AA62CFNO -- 开户证件号码
    ,AA44DATE -- 销户日期
    ,USER_ID -- 用户ID
    ,CRTF_TYP -- 客户主证件类型代码
    ,CRTF_NO -- 客户主证件号码
    ,CW05FLNM -- 存款产品名称
    ,AA64SDTP -- 保证金业务种类
    ,AA48BRNO -- 核算主体行
    ,AA47BRNO -- 归属网点
    ,DT_FLG -- 数据存在标志
)
SELECT
     P2.AA01AC15 AS AA01AC15 -- 账号
    ,p2.AA04FLNM AS AA04FLNM -- 账户名称
    ,p2.AA03CSNO AS AA03CSNO -- 客户内码
    ,p2.AA10CSTP AS AA10CSTP -- 客户类型代码
    ,P2.AA13ZHTP AS AA13ZHTP -- 存款账户性质代码
    ,P2.AA11ACFG AS AA11ACFG -- 存款账户类型代码
    ,P5.CB15BDHS AS CB15BDHS -- 存款账户状态代码
    ,P2.AA12ACT2 AS AA12ACT2 -- 介质类型代码
    ,P2.AA16PZZT AS AA16PZZT -- 挂失状态代码
    ,P2.AA24SSLV AS AA24SSLV -- 通兑级别代码
    ,P2.AA25SWLV AS AA25SWLV -- 通存级别代码
    ,p2.AA14BLNO AS AA14BLNO -- 凭证号码
    ,P2.AA06BUST AS AA06BUST -- 存款业务类别代码
    ,CONCAT(P2.AA07PDTP,P2.AA08PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,P2.AA61CFTP AS AA61CFTP -- 开户证件类型代码
    ,p2.AA62CFNO AS AA62CFNO -- 开户证件号码
    ,p2.AA44DATE AS AA44DATE -- 销户日期
    ,p3.USER_ID AS USER_ID -- 用户ID
    ,p4.CRTF_TYP AS CRTF_TYP -- 客户主证件类型代码
    ,p4.CRTF_NO AS CRTF_NO -- 客户主证件号码
    ,P6.CW05FLNM AS CW05FLNM -- 存款产品名称
    ,P2.AA64SDTP AS AA64SDTP -- 保证金业务种类
    ,P2.AA48BRNO AS AA48BRNO -- 核算主体行
    ,P2.AA47BRNO AS AA47BRNO -- 归属网点
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE.ODS_CORE_BDFMHQAA_TF AS P2 -- 活期存款帐户主档

LEFT JOIN (
  select
   U3.CST_IN_CD ,
   U3.USER_ID
  from
    (
    select
     d3.USER_ID
     ,d3.CST_IN_CD 
     , row_number() over(partition by d3.CST_IN_CD
    order by
     d3.USER_ID desc ) rn
    from
     ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF D3
    where
     D3.PT_DT = '${process_date}' AND DEL_F = '0' 
     and deleted = '0'
    )U3
  where
   U3.rn = 1 
) AS P3 -- 用户信息表
       ON p2.AA03CSNO = p3.CST_IN_CD 
LEFT JOIN (
   select 
    U4.CST_IN_CD
    ,U4.CRTF_TYP
    ,U4.CRTF_NO
    from 
    (
        SELECT 
             d4.CRTF_TYP
            ,d4.CRTF_NO
            ,d4.CST_IN_CD
            ,row_number()over(partition by d4.CST_IN_CD order by d4.CRTF_NO desc ) rn
        FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF D4
        WHERE  D4.PT_DT = '${process_date}' 
        and d4.deleted  ='0' 
        AND DEL_F = '0' 
        and major_flg  = '1'
    ) U4
   where U4.RN = 1
) AS P4 -- 客户证件信息表
       ON p2.AA03CSNO = p4.CST_IN_CD 
LEFT JOIN (
 select 
  CB01AC22,
  CB15BDHS
 from ODS_core.Ods_core_BDFMHQCB_tf D5
 where D5.pt_dt ='${process_date}'
 and DEL_F = '0'
) AS P5 -- 不动户活期存款账户主档
       ON P5.CB01AC22 = P2.AA01AC15 
LEFT JOIN (
    SELECT 
        D6.CW03PRON
        ,D6.CW05FLNM 
        ,D6.CW02PDTP  
        ,D6.CW04BRNO
    FROM ODS_CORE.ODS_CORE_BDFMHQCW_TF D6
    WHERE  D6.PT_DT = '${process_date}' AND DEL_F = '0' 
    ) AS P6 -- 产品代码名称表
       ON P2.AA08PRON = P6.CW03PRON
AND P2.AA07PDTP = P6.CW02PDTP 
WHERE p2.PT_DT = '${process_date}' AND p2.DEL_F = '0'
;
-- ==============聚合层字段映射（第1-2组）==============
-- 上日余额积数计算
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_02;

CREATE TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_02 (
     ACCT_NO STRING COMMENT '账户编号'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,ACTL_INT_AMT_YEAR_CUM DECIMAL(28,2) COMMENT '实际利息发生额年累计'
    ,CURR_BAL DECIMAL(28,2) COMMENT '当前余额'
    ,CURR_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '当前余额折人民币'
    ,YESTD_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,YESTD_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,YESTD_BAL_MONTH_ACCUM DECIMAL(28,2) COMMENT '昨日余额月积数'
    ,YESTD_BAL_QUAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额季积数'
    ,YESTD_BAL_YEAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额年积数'
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额月积数折人民币'
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额季积数折人民币'
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额年积数折人民币'
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额总积数折人民币'
    ,YESTD_BAL_WEEK_ACCUM DECIMAL(28,2) COMMENT '昨日余额周积数'
    ,YESTD_BAL_TOTAL_ACCUM DECIMAL(28,2) COMMENT '昨日余额总积数'
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额周积数折人民币'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '上日余额积数计算'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_02(
     ACCT_NO -- 账户编号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,CURR_BAL -- 当前余额
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,DT_FLG -- 数据存在标志
)
SELECT
     p1.AB01AC15 AS ACCT_NO -- 账户编号
    ,P1.AB02CCYC AS CURR_CD -- 币种代码
    ,P1.AB03CHSX AS CASH_RMT_CD -- 钞汇代码
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(p8.ACTL_INT_AMT_YEAR_CUM,0)  --当为年初时，取当日余额
ELSE COALESCE(S1.ACTL_INT_AMT_YEAR_CUM,0)+ coalesce(p8.ACTL_INT_AMT_YEAR_CUM,0)  END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,P1.AB16BAL AS CURR_BAL -- 当前余额
    ,CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,P1.AB14BAL AS YESTD_BAL -- 昨日余额
    ,CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB14BAL
     ELSE P1.AB14BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P1.AB14BAL,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM,0) + coalesce(P1.AB14BAL,0) END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P1.AB14BAL,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM,0) + coalesce(P1.AB14BAL,0) END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P1.AB14BAL,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM,0) + coalesce(P1.AB14BAL,0) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + coalesce(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + coalesce(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + coalesce(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,COALESCE(S1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,0) + coalesce(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(P1.AB14BAL,0) --当为周初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_WEEK_ACCUM,0) + coalesce(P1.AB14BAL,0) END AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,COALESCE(S1.YESTD_BAL_TOTAL_ACCUM,0) + coalesce(P1.AB14BAL,0) AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,0) + coalesce(CASE WHEN P1.AB02CCYC = 'CNY'
     THEN P1.AB16BAL
     ELSE P1.AB16BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END,0) END AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
    SELECT 
         d1.AB01AC15
        ,d1.AB08ACST 
        ,d1.AB09NO16
        ,d1.AB11NO02
        ,d1.AB02CCYC
        ,d1.AB03CHSX
        ,d1.AB16BAL
        ,d1.AB14BAL
        ,d1.AB20AMT
        ,d1.AB18AMT
        ,d1.AB19AMT
        ,d1.AB21AMT
        ,d1.AB27DATE
        ,d1.AB28DATE
        ,d1.AB13DATE
        ,d1.AB31BRNO
        ,d1.AB29BRNO
        ,d1.AB30BRNO
        ,d1.BUOPDATE
        ,d1.BUTSSTAF
        ,d1.UPOPDATE
        ,d1.UPTSSTAF
        ,d1.AB33DATE
        ,d1.RCSTRS1B
        ,D1.AB06ACID
        ,D1.PT_DT
    FROM ODS_CORE.ODS_CORE_BDFMHQAB_TF D1
    WHERE SUBSTR(D1.AB01AC15,1,1) = '1' 
        AND D1.PT_DT = '${process_date}' AND DEL_F = '0' 
    ) AS P1 -- 活期存款余额主档

LEFT JOIN (
    SELECT 
         D7.YRCAEXRT
        ,D7.YRCACUNO
        ,D7.YRCACCYC 

    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D7
    WHERE  D7.PT_DT = '${process_date}' AND DEL_F = '0' 
        AND cast(D7.YRCADATE as string) = REPLACE('${process_date}','-','')  --跑批日 
        AND D7.YRCARS1B <> '9'
) AS P7 -- 年度报表汇率文件
       ON p1.AB02CCYC=p7.YRCACCYC 
LEFT JOIN (
     select  T1.MG__AC22,
   sum( T1.MGYSAMT) as ACTL_INT_AMT_YEAR_CUM
     from   ODS_CORE.ODS_CORE_BIFMLXDJ_TF T1 --帐户利息登记簿
     where    to_date(cast(T1.MG__DATE as STRING) ,'yyyymmdd') = to_date(REPLACE('${process_date}','-',''),'yyyymmdd')     --跑批日期参数
       AND    T1.RCSTRS1B NOT IN ('1','9')
       AND    T1.PT_DT = '${process_date}' 
       AND    T1.DEL_F = '0' 
  group by T1.MG__AC22
) AS P8 -- None
       ON p1.AB01AC15 = p8.MG__AC22 
LEFT JOIN (
    select
        P1.ACCT_NO
        ,P1.CASH_RMT_CD
        ,P1.CURR_CD 
        ,P1.YESTD_BAL_MONTH_ACCUM
        ,P1.YESTD_BAL_QUAR_ACCUM
        ,P1.YESTD_BAL_YEAR_ACCUM
        ,P1.ACTL_INT_AMT_YEAR_CUM
        ,P1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_WEEK_ACCUM
        ,P1.YESTD_BAL_TOTAL_ACCUM
        ,P1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB
    FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF P1
    WHERE P1.PT_DT = cast(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND P1.SRC_TAB_EN_NAME ='ODS_CORE_BDFMHQAB_TF'
AND DEL_F = '0'
) AS S1 -- 个人存款账户信息聚合上日积数
       ON S1.ACCT_NO = P1.AB01AC15
AND S1.CURR_CD = P1.AB02CCYC
AND S1.CASH_RMT_CD = P1.AB03CHSX 
;
-- ==============聚合层字段映射（第1-3组）==============
-- None
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_021;

CREATE TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_021 (
     BQ05AC15 STRING COMMENT '账户编号'
    ,BQ04CHSX STRING COMMENT '钞汇属性'
    ,BQ03CCYC STRING COMMENT '币种代码'
    ,BQ06DATE STRING COMMENT '交易日期'
    ,BQ07BRNO STRING COMMENT '销户机构编号'
    ,BQ08STAF STRING COMMENT '销户柜员编号'
    ,BQ09CNCD STRING COMMENT '销户渠道代码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT 'None'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_021(
     BQ05AC15 -- 账户编号
    ,BQ04CHSX -- 钞汇属性
    ,BQ03CCYC -- 币种代码
    ,BQ06DATE -- 交易日期
    ,BQ07BRNO -- 销户机构编号
    ,BQ08STAF -- 销户柜员编号
    ,BQ09CNCD -- 销户渠道代码
    ,DT_FLG -- 数据存在标志
)
SELECT
     T1.BQ05AC15 AS BQ05AC15 -- 账户编号
    ,T1.BQ04CHSX AS BQ04CHSX -- 钞汇属性
    ,T1.BQ03CCYC AS BQ03CCYC -- 币种代码
    ,T1.BQ06DATE AS BQ06DATE -- 交易日期
    ,T1.BQ07BRNO AS BQ07BRNO -- 销户机构编号
    ,T1.BQ08STAF AS BQ08STAF -- 销户柜员编号
    ,T1.BQ09CNCD AS BQ09CNCD -- 销户渠道代码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
select 
  d12.BQ01AC22  
 ,d12.BQ03CCYC
 ,d12.BQ04CHSX
 ,d12.BQ06DATE  
 ,d12.BQ07BRNO
 ,d12.BQ08STAF
 ,d12.BQ09CNCD
 ,d12.BQ10CLSN
 ,d12.BQ11AMT
 ,d12.BQ12AMT
 ,D12.BQ13AMT
,D12.BQ05AC15
 ,D12.PT_DT
,ROW_NUMBER()OVER(partition by  D12.BQ05AC15  order by d12.BQ01AC22,d12.BQ03CCYC,D12.BQ09CNCD desc ) RN 
from ODS_CORE.ODS_CORE_BDFMHQBQ_TF D12
where D12.DEL_F='0' 
AND  D12.PT_DT='${process_date}'
) AS T1 -- None

WHERE T1.RN =1
;
-- ==============聚合层字段映射（第1-4组）==============
-- None
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_022;

CREATE TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_022 (
     BC35CNCD STRING COMMENT 'BC35CNCD'
    ,BC01AC22 STRING COMMENT 'BC01AC22'
    ,BC03CCYC STRING COMMENT 'BC03CCYC'
    ,BC04CHSX STRING COMMENT 'BC04CHSX'
    ,BC08ZHTP STRING COMMENT 'BC08ZHTP'
    ,BC09ACT2 STRING COMMENT 'BC09ACT2'
    ,BC31DATE STRING COMMENT 'BC31DATE'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT 'None'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_022(
     BC35CNCD -- BC35CNCD
    ,BC01AC22 -- BC01AC22
    ,BC03CCYC -- BC03CCYC
    ,BC04CHSX -- BC04CHSX
    ,BC08ZHTP -- BC08ZHTP
    ,BC09ACT2 -- BC09ACT2
    ,BC31DATE -- BC31DATE
    ,DT_FLG -- 数据存在标志
)
SELECT
     T1.BC35CNCD AS BC35CNCD -- BC35CNCD
    ,T1.BC01AC22 AS BC01AC22 -- BC01AC22
    ,T1.BC03CCYC AS BC03CCYC -- BC03CCYC
    ,T1.BC04CHSX AS BC04CHSX -- BC04CHSX
    ,T1.BC08ZHTP AS BC08ZHTP -- BC08ZHTP
    ,T1.BC09ACT2 AS BC09ACT2 -- BC09ACT2
    ,T1.BC31DATE AS BC31DATE -- BC31DATE
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT * FROM(
select 
  D12.BC01AC22  
 ,D12.BC03CCYC
 ,D12.BC04CHSX
 ,D12.BC31DATE  
 ,D12.BC35CNCD
 ,d12.BC09ACT2
 ,D12.BC08ZHTP
,ROW_NUMBER()OVER(partition by  D12.BC01AC22 ,D12.BC03CCYC,D12.BC04CHSX,D12.BC31DATE order by D12.BC31DATE desc ) RN 
from ODS_CORE.ODS_CORE_BDFMHQBC_TF D12
where D12.DEL_F='0' 
AND  D12.PT_DT='${process_date}'
)WHERE RN=1) AS T1 -- None

;
-- ==============聚合层字段映射（第1-0组）==============
-- 个人存款账户信息聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CUST_TYPE_CD -- 客户类型代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,MED_TYPE_CD -- 介质类型代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,VOCH_NO -- 凭证号码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,CTRL_AMT -- 控制金额
    ,STOP_PAY_AMT -- 止付金额
    ,PRE_AUTH_AMT -- 预授权金额
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,DATA_DT -- 数据日期
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     p1.AB01AC15 AS ACCT_NO -- 账户编号
    ,p2.AA04FLNM AS ACCT_NAME -- 账户名称
    ,p2.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,p2.USER_ID AS USER_ID -- 用户ID
    ,p2.AA04FLNM AS CUST_NAME -- 客户名称
    ,p2.CRTF_TYP AS CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,p2.CRTF_NO AS CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CASE WHEN P2.AA03CSNO like '81%' THEN '1' when P2.AA03CSNO like '82%' THEN '2' ELSE '3' END AS CUST_TYPE_CD -- 客户类型代码
    ,p2.AA10CSTP AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN coalesce(TRIM(P2.AA13ZHTP),'') = '' OR P2.AA13ZHTP IS NULL THEN '9999' ELSE P2.AA13ZHTP END AS DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,P2.AA11ACFG AS DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,CASE WHEN  P1.AB08ACST='2' AND  SUBSTR(P1.AB09NO16,7,1)='1' AND   P2.CB15BDHS<>'3' --销户  
THEN '5'--不动户
ELSE P1.AB08ACST END AS DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,P2.AA12ACT2 AS MED_TYPE_CD -- 介质类型代码
    ,CASE WHEN SUBSTR(P1.AB09NO16,3,1)='1' 
     THEN '1' 
     WHEN SUBSTR(P1.AB11NO02,2,1)='1' 
     THEN '2' 
     ELSE '0'
END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,P2.AA16PZZT AS REPLOS_STATUS_CD -- 挂失状态代码
    ,CASE WHEN SUBSTR(AB09NO16,2,1)='1' 
     THEN '1' 
     WHEN SUBSTR(AB09NO16,1,1)='1' 
     THEN '3' 
     WHEN SUBSTR(AB11NO02,1,1)='1' 
     THEN '2' 
     ELSE '0' 
END AS FRZ_STATUS_CD -- 冻结状态代码
    ,P2.AA24SSLV AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,P2.AA25SWLV AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,p2.AA14BLNO AS VOCH_NO -- 凭证号码
    ,P5.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P5.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,'' AS EACCT_NO -- 电子账户编号
    ,'' AS EACCT_STATUS_CD -- 电子账户状态代码
    ,'' AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,'' AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,'' AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,P2.AA06BUST AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P2.DPSIT_PROD_CD AS DPSIT_PROD_CD -- 存款产品代码
    ,P2.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,P2.AA61CFTP AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,p2.AA62CFNO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.AB02CCYC AS CURR_CD -- 币种代码
    ,P1.AB03CHSX AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TRIM(P2.AA64SDTP) = '' THEN '0' ELSE '1' END AS MRGACCT_FLAG -- 保证金账户标志
    ,'1' AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,S1.CURR_BAL_CONVT_RMB AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,p1.AB16BAL AS CURR_BAL -- 当前余额
    ,S1.YESTD_BAL_CONVT_RMB AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,p1.AB14BAL AS YESTD_BAL -- 昨日余额
    ,p1.AB20AMT AS KEEP_AMT -- 保留金额
    ,p1.AB18AMT AS FRZ_AMT -- 冻结金额
    ,null AS CTRL_AMT -- 控制金额
    ,p1.AB19AMT AS STOP_PAY_AMT -- 止付金额
    ,p1.AB21AMT AS PRE_AUTH_AMT -- 预授权金额
    ,S1.YESTD_BAL_WEEK_ACCUM AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,S1.YESTD_BAL_MONTH_ACCUM AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,S1.YESTD_BAL_QUAR_ACCUM AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,S1.YESTD_BAL_YEAR_ACCUM AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,S1.YESTD_BAL_TOTAL_ACCUM AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,S1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,S1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,S1.ACTL_INT_AMT_YEAR_CUM AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,unifiedTime(p1.AB27DATE) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(p1.AB28DATE) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(p2.AA44DATE) AS CANC_ACCT_DT -- 销户日期
    ,unifiedTime(p1.AB13DATE) AS VAL_DT -- 起息日期
    ,'' AS MATU_DT -- 到期日期
    ,p2.AA48BRNO AS LP_ORG_NO -- 法人机构编号
    ,p1.AB29BRNO AS STAT_ORG_NO -- 统计机构编号
    ,p2.AA47BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,p9.BQ07BRNO AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,p9.BQ08STAF AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CASE WHEN p10.BC35CNCD = 'CC' THEN 'IC' ELSE p10.BC35CNCD END AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN p9.BQ09CNCD = 'CC' THEN 'IC' ELSE  p9.BQ09CNCD
  END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,'CORE' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,unifiedTime(p1.BUOPDATE) AS SETUP_DT -- 建立日期
    ,p1.BUTSSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(p1.UPOPDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,p1.UPTSSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(p1.AB33DATE) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(p1.AB32DATE) AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,p1.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,'${process_date}' AS DATA_DT -- 数据日期
    ,'ODS_CORE_BDFMHQAB_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAB_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(
    SELECT 
         d1.AB01AC15
        ,d1.AB08ACST 
        ,d1.AB09NO16
        ,d1.AB11NO02
        ,d1.AB02CCYC
        ,d1.AB03CHSX
        ,d1.AB16BAL
        ,d1.AB14BAL
        ,d1.AB20AMT
        ,d1.AB18AMT
        ,d1.AB19AMT
        ,d1.AB21AMT
        ,d1.AB27DATE
        ,d1.AB28DATE
        ,d1.AB13DATE
        ,d1.AB31BRNO
        ,d1.AB29BRNO
        ,d1.AB30BRNO
        ,d1.BUOPDATE
        ,d1.BUTSSTAF
        ,d1.UPOPDATE
        ,d1.UPTSSTAF
        ,d1.AB32DATE
        ,d1.AB33DATE
        ,d1.RCSTRS1B
        ,D1.AB06ACID
        ,D1.PT_DT
    FROM ODS_CORE.ODS_CORE_BDFMHQAB_TF D1
    WHERE SUBSTR(D1.AB01AC15,1,1) = '1' 
        AND D1.PT_DT = '${process_date}' AND DEL_F = '0' 
    ) AS P1 -- 活期存款余额主档

LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_01 AS P2 -- 活期存款帐户主档
       ON p1.AB01AC15 = p2.AA01AC15 
LEFT JOIN (
    SELECT 
        D5.KHDAACID
       ,D5.KHDAFLNM
       ,D5.KHDBACID 
    FROM ODS_CORE.ODS_CORE_BGFDKHDZ_TF D5
    WHERE  D5.PT_DT = '${process_date}' AND DEL_F = '0' 
    ) AS P5 -- 新会计科目核算码对照表
       ON p1.AB06ACID = p5.KHDBACID 
LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_021 AS P9 -- 销户登记簿
       ON TRIM(P1.AB01AC15) = TRIM(P9.BQ05AC15 )
 AND TRIM(P9.BQ04CHSX) = TRIM(P1.AB03CHSX)   
AND TRIM(P9.BQ03CCYC)  =TRIM(P1.AB02CCYC) 
AND TRIM(P9.BQ06DATE)  =TRIM(P2.AA44DATE) 
LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_022 AS P10 -- 开户登记簿
       ON TRIM(P1.AB01AC15) = TRIM(P10.BC01AC22 ) 
    and TRIM(p1.AB02CCYC) = TRIM(p10.bc03ccyc)
    and TRIM(p1.AB03CHSX) =TRIM(p10.bc04chsx)
    AND TRIM(p1.AB27DATE) = TRIM(P10.BC31DATE) 
LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_02 AS S1 -- 个人存款账户信息聚合上日积数
       ON S1.ACCT_NO = P1.AB01AC15
AND S1.CURR_CD = P1.AB02CCYC
AND S1.CASH_RMT_CD = P1.AB03CHSX 
;
-- ==============聚合层字段映射（第2-1组）==============
-- 计算互联网用户内码信息
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_031;

CREATE TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_031 (
     CUSTNO STRING COMMENT '客户编号'
    ,CUSTCD STRING COMMENT '客户内码'
    ,CUSTID STRING COMMENT '用户ID'
    ,CST_IN_CD STRING COMMENT '客户内码'
    ,CRTF_TYP STRING COMMENT '客户主证件类型代码'
    ,CRTF_NO STRING COMMENT '客户主证件号码'
    ,CUST_NM STRING COMMENT '客户名称'
    ,OPEN_ACCT_DOCTYP_CD STRING COMMENT '开户证件类型代码'
    ,OPEN_ACCT_DOC_NO STRING COMMENT '开户证件号码'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '计算互联网用户内码信息'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_031(
     CUSTNO -- 客户编号
    ,CUSTCD -- 客户内码
    ,CUSTID -- 用户ID
    ,CST_IN_CD -- 客户内码
    ,CRTF_TYP -- 客户主证件类型代码
    ,CRTF_NO -- 客户主证件号码
    ,CUST_NM -- 客户名称
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,DT_FLG -- 数据存在标志
)
SELECT
     A1.CUSTNO AS CUSTNO -- 客户编号
    ,A1.CUSTCD AS CUSTCD -- 客户内码
    ,A1.CUSTID AS CUSTID -- 用户ID
    ,A4.CST_IN_CD AS CST_IN_CD -- 客户内码
    ,A4.CRTF_TYP AS CRTF_TYP -- 客户主证件类型代码
    ,A4.CRTF_NO AS CRTF_NO -- 客户主证件号码
    ,A3.CUST_NM AS CUST_NM -- 客户名称
    ,A2.CRTF_TYP AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,A2.CRTF_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT * FROM (
   SELECT
      CUSTCD
     ,CUSTNO
     ,CUSTID
     ,ROW_NUMBER() OVER (PARTITION BY CUSTNO ORDER BY STATUS) AS RN 
   FROM ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF 
   WHERE DEL_F='0' AND  PT_DT='${process_date}'
)T WHERE RN=1) AS A1 -- 客户信息关联表

LEFT JOIN (
    select
    u4.CST_IN_CD 
   ,U4.USER_ID
   ,u4.CRTF_TYP
   ,u4.CRTF_NO
     , row_number() over(partition by u4.CST_IN_CD
    order by
     u4.USER_ID desc ) rn
    from
     ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF u4
    where
     u4.PT_DT = '${process_date}' 
     AND DEL_F = '0' 
     and u4.deleted = '0'
    and u4.del_f = '0'
    and coalesce(trim(u4.CST_IN_CD),'') <> ''
    ) AS A2 -- 用户基本信息表
       ON A1.CUSTCD =A2.CST_IN_CD
and a2.rn =1 
LEFT JOIN (
    SELECT 
        D3.CUST_NM
       ,D3.CST_IN_CD
    FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_BAS_TF d3
    WHERE  d3.PT_DT = '${process_date}' 
    AND DEL_F = '0' 
) AS A3 -- 客户基本信息表
       ON A1.CUSTCD =A3.CST_IN_CD 
LEFT JOIN (
   select D6.CST_IN_CD
     ,D6.CRTF_TYP
     ,D6.CRTF_NO
    from 
    (
        SELECT 
             U13.CRTF_TYP
            ,U13.CRTF_NO
            ,U13.CST_IN_CD
            ,row_number()over(partition by U13.CST_IN_CD order by U13.CRTF_NO desc ) rn
        FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF U13
        WHERE  U13.PT_DT = '${process_date}' AND DEL_F = '0' 
AND DELETED = '0'
AND MAJOR_FLG='1'
    ) D6
   where D6.RN = 1
) AS A4 -- 客户证件信息表
       ON A1.CUSTCD = A4.CST_IN_CD 
;
-- ==============聚合层字段映射（第2-0组）==============
-- 个人存款账户信息聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CUST_TYPE_CD -- 客户类型代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,MED_TYPE_CD -- 介质类型代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,VOCH_NO -- 凭证号码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,CTRL_AMT -- 控制金额
    ,STOP_PAY_AMT -- 止付金额
    ,PRE_AUTH_AMT -- 预授权金额
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,DATA_DT -- 数据日期
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     p1.ACCTNO AS ACCT_NO -- 账户编号
    ,p1.ACCTNA AS ACCT_NAME -- 账户名称
    ,P2.CUSTCD AS CUST_IN_CD -- 客户内码
    ,P2.CUSTID AS USER_ID -- 用户ID
    ,p1.ACCTNA AS CUST_NAME -- 客户名称
    ,p2.CRTF_TYP AS CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,p2.CRTF_NO AS CUST_MAIN_DOC_NO -- 客户主证件号码
    ,'1' AS CUST_TYPE_CD -- 客户类型代码
    ,'1' AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN P4.ACCATP = '1'  AND P1.ACSETP= '01'  THEN '0011'
WHEN  P4.ACCATP = '2'  AND P1.ACSETP= '01' THEN '0013'
WHEN P4.ACCATP = '3' AND P1.ACSETP= '03' THEN 'W003'
WHEN  P4.ACCATP = '3' AND P1.ACSETP= '02' THEN '0014'
WHEN P1.ACSETP IN ('04','08') THEN '0012'
WHEN P1.ACSETP = '01' AND P4.ACCATP IS NULL THEN '0011'
WHEN P1.ACSETP = '02' AND P4.ACCATP IS NULL THEN '0014'
ELSE 'W9999' END AS DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,p1.ACSETP AS DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,CASE WHEN P1.ACCTST IS NULL OR TRIM(P1.ACCTST)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACCTST)),'') END AS DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,'W1' AS MED_TYPE_CD -- 介质类型代码
    ,p3.FROZST AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,'' AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P5.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,'1' AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,'1' AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,p14.CARDNO AS VOCH_NO -- 凭证号码
    ,P6.SUBJECT AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P6.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.CUSTAC AS EACCT_NO -- 电子账户编号
    ,P3.ACCTST AS EACCT_STATUS_CD -- 电子账户状态代码
    ,P1.SPECTP AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,P4.ACCATP AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,P1.ACSETP AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,CASE WHEN P1.DEBTTP IS NULL OR TRIM(P1.DEBTTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DEBTTP)),'') END AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,p1.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,p8.PRODTX AS DPSIT_PROD_NAME -- 存款产品名称
    ,p2.OPEN_ACCT_DOCTYP_CD AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,p2.OPEN_ACCT_DOC_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,'' AS MRGACCT_FLAG -- 保证金账户标志
    ,'1' AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CASE WHEN P1.CRCYCD = 'CNY'
     THEN p1.ONLNBL
     ELSE p1.ONLNBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,p1.ONLNBL AS CURR_BAL -- 当前余额
    ,CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,p1.LASTBL AS YESTD_BAL -- 昨日余额
    ,p1.HDMIMY AS KEEP_AMT -- 保留金额
    ,P5.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,null AS CTRL_AMT -- 控制金额
    ,P5.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,null AS PRE_AUTH_AMT -- 预授权金额
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为月初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_WEEK_ACCUM,0) +COALESCE(P1.LASTBL ,0)  END  AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为月初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_MONTH_ACCUM,0) +COALESCE(P1.LASTBL ,0)  END  AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为季初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_QUAR_ACCUM,0) + COALESCE(P1.LASTBL ,0)  END  AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为年初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_YEAR_ACCUM,0) +COALESCE(P1.LASTBL ,0)  END  AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,COALESCE(S2.YESTD_BAL_TOTAL_ACCUM,0) +COALESCE(P1.LASTBL ,0) AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0) --当为月初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,0) +COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0)  END  AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0) --当为月初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) +COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0)  END  AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0) --当为季初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0)  END  AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0) --当为年初时，取当日余额
ELSE COALESCE(S2.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) +COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0)  END  AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,COALESCE(S2.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,0) +COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P9.YRCAEXRT,0)/NVL(P9.YRCACUNO,1))    
END ,0) AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(p12.ACTL_INT_AMT_YEAR_CUM ,0) --当为年初时，取当日余额
ELSE COALESCE(S2.ACTL_INT_AMT_YEAR_CUM,0)+ COALESCE(p12.ACTL_INT_AMT_YEAR_CUM ,0)  END  AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,unifiedTime(p1.OPENDT) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(p1.CLOSDT) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(p1.CLOSDT) AS CANC_ACCT_DT -- 销户日期
    ,unifiedTime(p1.BGINDT) AS VAL_DT -- 起息日期
    ,unifiedTime(p1.MATUDT) AS MATU_DT -- 到期日期
    ,p1.BRCHNO AS LP_ORG_NO -- 法人机构编号
    ,p1.BRCHNO AS STAT_ORG_NO -- 统计机构编号
    ,p1.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,P13.CLOSBR AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,P13.CLOSUS AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CASE WHEN P1.ACSETP IN ('01' ,'02','03','04') THEN 'NM' ELSE 'TE' END  AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN P1.ACCTST = '2' THEN 'NM' ELSE '' END  AS CANC_ACCT_CHNL -- 销户渠道代码
    ,'NAS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,unifiedTime(p1.OPENDT) AS SETUP_DT -- 建立日期
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,substr(unifiedTime(P1.TIMETM),1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(p1.LSTRDT) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(p1.LSTRDT) AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,'0' AS REC_STATUS_CD -- 记录状态代码
    ,'${process_date}' AS DATA_DT -- 数据日期
    ,'ODS_NAS_KNA_ACCT_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNA_ACCT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS.ods_nas_KNA_ACCT_TF AS P1 -- 负债活期账户信息表

LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_031 AS P2 -- 用户信息表
       ON P1.CUSTNO  = P2.CUSTNO 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_CUST_TF AS P3 -- 电子账户表
       ON P1.CUSTAC = P3.CUSTAC 
AND P3.DEL_F = '0' 
AND P3.PT_DT = '${process_date}' 
LEFT JOIN (  
 select 
      d7.ACCATP
     ,d7.acctno 
     ,d7.corpno
  
 from 
 ods_nas.ODS_NAS_KNA_ACCT_ADDT_TF d7 
 where  d7.PT_DT = '${process_date}' AND DEL_F = '0' 
  and d7.del_f = '0'
) AS P4 -- 负债账户附加信息表
       ON P1.ACCTNO = P4.ACCTNO 
LEFT JOIN (SELECT
T1.CUSTAC
,CASE WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='1' THEN '2'
           WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='2' THEN '3'
WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='3' THEN '1'
WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='4' THEN '4' 
ELSE '0' END AS  FRZ_STATUS_CD --冻结状态代码
,CASE WHEN T1.FROZTP IN ('3' ,'4','5','6') AND T1.FRLMTP='1' THEN '2'
           WHEN T1.FROZTP IN ('3' ,'4','5','6') AND T1.FRLMTP='3' THEN '1'
WHEN T1.FROZTP IN  ('3' ,'4','5','6') AND T1.FRLMTP IN ( '2','4') THEN '3'
ELSE '0' END AS  STOP_PAY_STATUS_CD --止付状态代码
,SUM(CASE WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP IN ('3','4','1','2') THEN T2.FROZAM ELSE 0 END ) AS STOP_PAY_AMT--止付金额
,SUM(CASE WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP IN ('1','2','3','4') THEN T2.FROZAM ELSE 0 END) AS FRZ_AMT -- 冻结金额
FROM ODS_NAS.ODS_NAS_KNB_FROZ_TF T1
LEFT JOIN ODS_NAS.ODS_NAS_KNB_FROZ_DETL_TF T2
ON T1.FROZNO = T2.FROZNO 
AND T1.FROZSQ =T2.FROZSQ  
AND T2.FROZST='0' 
AND T2.DEL_F = '0' 
and T2.pt_dt  = '${process_date}'
WHERE T1.FREDDT='20990101' 
AND T1.FROZST = '0' 
AND T1.DEL_F='0'
and T1.pt_dt  = '${process_date}'
GROUP BY T1.CUSTAC,T1.FROZTP,T1.FRLMTP) AS P5 -- 冻结登记簿
       ON P1.CUSTAC = P5.CUSTAC 
LEFT JOIN (
SELECT  T1.PRODUCT
       ,T1.SUBJECT
       ,T2.DESCRIPTION
FROM 
    (
     SELECT  EVENT_TYPE
            ,PRODUCT
            ,CASE WHEN SUBJECT_DR<>'' AND SUBJECT_DR <> '30410310' 
                  THEN SUBJECT_DR 
                  ELSE SUBJECT_CR
             END       SUBJECT
      FROM  ODS_GAS.ODS_GAS_CUX_EA_RULES_TF 
      WHERE SUBSTR(EVENT_TYPE,1,1) = '1' 
      AND   PT_DT = '${process_date}' AND DEL_F = '0'  
  ) T1
LEFT JOIN ODS_GAS.ODS_GAS_CUX_FLEX_VALUES_V_TF T2
ON        T2.FLEX_VALUE = T1.SUBJECT
AND       T2.PT_DT = '${process_date}' AND DEL_F = '0' 
GROUP BY  T1.PRODUCT
         ,T1.SUBJECT
         ,T2.DESCRIPTION
) AS P6 -- None
       ON P1.ACCTCD = P6.PRODUCT 
LEFT JOIN (
    SELECT 
        d8.PRODTX
        ,d8.PRODCD 
    FROM ODS_NAS.ODS_NAS_KUP_DPPB_TF D8
    WHERE  D8.PT_DT = '${process_date}' AND DEL_F = '0' 
    ) AS P8 -- 产品基础属性表
       ON P1.PRODCD = P8.PRODCD 
LEFT JOIN (
    SELECT 
        D9.YRCAEXRT
        ,D9.YRCACUNO
        ,D9.YRCACCYC 
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D9
    WHERE  D9.PT_DT = '${process_date}' AND DEL_F = '0' 
        AND CAST(D9.YRCADATE AS STRING)= REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D9.YRCARS1B <> '9' 
    ) AS P9 -- 年度报表汇率文件
       ON p1.CRCYCD=p9.YRCACCYC 
LEFT JOIN (
    select  T1.ACCTNO
           ,sum(T1.RLINTR ) as ACTL_INT_AMT_YEAR_CUM
    from   ODS_NAS.ODS_NAS_KNB_PIDL_TF T1 --负债账户付息明细
    where    T1.PT_DT = '${process_date}'  --跑批日期参数
        AND    T1.DEL_F = '0'
 group by  T1.ACCTNO
) AS P12 -- None
       ON P1.ACCTNO = P12.ACCTNO 
LEFT JOIN (
 select        
     P.CLOSBR
       ,P.CLOSUS
       ,P.ACCTNO
    from 
  (
     SELECT 
         d13.CLOSBR
        ,d13.CLOSUS
        ,d13.ACCTNO
        ,row_number ()OVER(partition by d13.ACCTNO order by D13.CLOSSQ desc  )RN 
 
     FROM ODS_NAS.ODS_NAS_KNB_CLAC_TF d13
     WHERE  d13.PT_DT = '${process_date}' 
     and D13.del_f ='0'
 
     )P
     where P.RN =1
    ) AS P13 -- 电子账户销户登记簿
       ON P1.ACCTNO = P13.ACCTNO 
LEFT JOIN (
    SELECT 
        d14.CARDNO
        ,d14.CUSTAC 
    FROM ODS_NAS.ODS_NAS_KNA_ACDC_TF d14
    WHERE  d14.PT_DT = '${process_date}' AND DEL_F = '0' 
    and d14.del_f  = '0'

    ) AS P14 -- 卡客户账号对照表
       ON P1.CUSTAC = P14.CUSTAC 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     where  p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNA_ACCT' 
     AND p1.SRC_FIELD_EN_NAME='ACCTST' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  
     AND p1.TARGET_FIELD_EN_NAME='DPSIT_ACCT_STATUS_CD' 
) AS S1 -- 开户证件类型代码转换
       ON P1.ACCTST=S1.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     where  p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNA_ACCT' 
     AND p1.SRC_FIELD_EN_NAME='DEBTTP' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  
     AND p1.TARGET_FIELD_EN_NAME='DPSIT_BIZ_CATEGORY_CD' 
) AS S3 -- 存款业务类别代码转换
       ON P1.DEBTTP=S3.SRC_CD_VAL 
LEFT JOIN (
    select
         P1.ACCT_NO
        ,P1.CASH_RMT_CD
        ,P1.CURR_CD 
        ,P1.YESTD_BAL_MONTH_ACCUM
        ,P1.YESTD_BAL_QUAR_ACCUM
        ,P1.YESTD_BAL_YEAR_ACCUM
        ,P1.ACTL_INT_AMT_YEAR_CUM
        ,P1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_WEEK_ACCUM
        ,P1.YESTD_BAL_TOTAL_ACCUM
        ,P1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB
    FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF P1
    WHERE P1.PT_DT = cast(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND P1.SRC_TAB_EN_NAME ='ODS_NAS_KNA_ACCT_TF'
AND DEL_F = '0'
) AS S2 -- 个人存款账户信息聚合上日积数
       ON S2.ACCT_NO =P1.ACCTNO 
WHERE P1.SPECTP IN ('0011','0012')  AND P1.PT_DT = '${process_date}' AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第3组）==============
-- 上日余额积数计算
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_04;

CREATE TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_04 (
     ACCT_NO STRING COMMENT '账户编号'
    ,CURR_CD STRING COMMENT '币种代码'
    ,CASH_RMT_CD STRING COMMENT '钞汇代码'
    ,CURR_BAL DECIMAL(28,2) COMMENT '当前余额'
    ,CURR_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '当前余额折人民币'
    ,YESTD_BAL DECIMAL(28,2) COMMENT '昨日余额'
    ,YESTD_BAL_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额折人民币'
    ,YESTD_BAL_MONTH_ACCUM DECIMAL(28,2) COMMENT '昨日余额月积数'
    ,YESTD_BAL_QUAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额季积数'
    ,YESTD_BAL_YEAR_ACCUM DECIMAL(28,2) COMMENT '昨日余额年积数'
    ,ACTL_INT_AMT_YEAR_CUM DECIMAL(28,2) COMMENT '实际利息发生额年累计'
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额月积数折人民币'
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额季积数折人民币'
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额年积数折人民币'
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额总积数折人民币'
    ,YESTD_BAL_WEEK_ACCUM DECIMAL(28,2) COMMENT '昨日余额周积数'
    ,YESTD_BAL_TOTAL_ACCUM DECIMAL(28,2) COMMENT '昨日余额总积数'
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB DECIMAL(28,2) COMMENT '昨日余额周积数折人民币'
    ,DT_FLG STRING COMMENT '数据存在标志'
)
USING ORC
COMMENT '上日余额积数计算'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_04(
     ACCT_NO -- 账户编号
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,CURR_BAL -- 当前余额
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AA01AC15 AS ACCT_NO -- 账户编号
    ,P6.AB03CCYC AS CURR_CD -- 币种代码
    ,P6.AB05CHSX AS CASH_RMT_CD -- 钞汇代码
    ,P6.AB22BAL AS CURR_BAL -- 当前余额
    ,CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB22BAL
     ELSE P6.AB22BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,P6.AB20BAL AS YESTD_BAL -- 昨日余额
    ,CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P6.AB20BAL ,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM,0) + COALESCE(P6.AB20BAL ,0)  END  AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P6.AB20BAL ,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM,0) + COALESCE(P6.AB20BAL ,0)  END  AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P6.AB20BAL ,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM,0) + COALESCE(P6.AB20BAL ,0)  END  AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(p8.ACTL_INT_AMT_YEAR_CUM ,0) --当为年初时，取当日余额
ELSE COALESCE(S1.ACTL_INT_AMT_YEAR_CUM,0)+COALESCE(p8.ACTL_INT_AMT_YEAR_CUM,0)    END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0)  END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0) --当为季初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0)  END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0) --当为年初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0)  END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,COALESCE(S1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0) AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(P6.AB20BAL ,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_WEEK_ACCUM,0) + COALESCE(P6.AB20BAL ,0)  END AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,COALESCE(S1.YESTD_BAL_TOTAL_ACCUM,0) + COALESCE(P6.AB20BAL ,0) AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0) --当为月初时，取当日余额
ELSE COALESCE(S1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P6.AB03CCYC = 'CNY'
     THEN P6.AB20BAL
     ELSE P6.AB20BAL*(NVL(P7.YRCAEXRT,0)/NVL(P7.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END ,0)  END AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE.ODS_CORE_BFFMDQAA_TF AS P1 -- 定期存款帐户控制文件

LEFT JOIN (
     SELECT 
         d6.AB01AC15 
   ,D6.AB06ACFG
   ,D6.AB14NO16
   ,D6.AB09BUST
   ,D6.AB10PDTP
   ,D6.AB11PRON
   ,D6.AB03CCYC
   ,D6.AB05CHSX
   ,D6.AB22BAL
   ,D6.AB20BAL
   ,D6.AB45AMT
   ,D6.AB23AMT
   ,D6.AB46AMT
   ,D6.AB34DATE
   ,D6.AB17DATE
   ,D6.AB18DATE
   ,D6.BUDIDATE
   ,D6.BUTPSTAF
   ,D6.UPTSSTAM
   ,D6.UPOPSTAF
   ,D6.AB30DATE
   ,D6.RCSTRS1B
   ,D6.AB12ACID
 
     FROM ODS_CORE.ODS_CORE_BFFMDQAB_TF D6
     WHERE  D6.PT_DT = '${process_date}' AND DEL_F = '0' 
) AS P6 -- 定期模块账户分户余额信息
       ON p1.AA01AC15 = p6.AB01AC15 
LEFT JOIN (
    SELECT 
        D10.YRCAEXRT
        ,D10.YRCACUNO
        ,D10.YRCACCYC 
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D10
    WHERE  D10.PT_DT = '${process_date}' AND DEL_F = '0' 
        AND  CAST(D10.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D10.YRCARS1B <> '9'
) AS P7 -- 年度报表汇率文件
       ON p6.AB03CCYC=p7.YRCACCYC 
LEFT JOIN (
     select  T1.MG__AC22,
   sum( T1.MGYSAMT) as ACTL_INT_AMT_YEAR_CUM
     from   ODS_CORE.ODS_CORE_BIFMLXDJ_TF T1 --帐户利息登记簿
     where    to_date(cast(T1.MG__DATE as STRING) ,'yyyymmdd') = to_date(REPLACE('${process_date}','-',''),'yyyymmdd')     --跑批日期参数
       AND    T1.RCSTRS1B NOT IN ('1','9')
       AND    T1.PT_DT = '${process_date}' 
       AND    T1.DEL_F = '0' 
  group by T1.MG__AC22
) AS P8 -- 账户利息登记簿
       ON p1.AA01AC15 = p8.MG__AC22 
LEFT JOIN (
    select
        P1.ACCT_NO
        ,P1.CASH_RMT_CD
        ,P1.CURR_CD 
        ,P1.YESTD_BAL_MONTH_ACCUM
        ,P1.YESTD_BAL_QUAR_ACCUM
        ,P1.YESTD_BAL_YEAR_ACCUM
        ,P1.ACTL_INT_AMT_YEAR_CUM
        ,P1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_WEEK_ACCUM
        ,P1.YESTD_BAL_TOTAL_ACCUM
        ,P1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB
    FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF P1
    WHERE P1.PT_DT = cast(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND P1.SRC_TAB_EN_NAME ='ODS_CORE_BFFMDQAA_TF'
AND DEL_F = '0'
) AS S1 -- 个人存款账户信息聚合上日积数
       ON S1.ACCT_NO = P1.AA01AC15
AND S1.CURR_CD = P6.AB03CCYC
AND S1.CASH_RMT_CD = P6.AB05CHSX 
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F = '0'  AND SUBSTR(P1.AA01AC15,1,1) = '1'
;
-- ==============聚合层字段映射（第3-0组）==============
-- 个人存款账户信息聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CUST_TYPE_CD -- 客户类型代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,MED_TYPE_CD -- 介质类型代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,VOCH_NO -- 凭证号码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,CTRL_AMT -- 控制金额
    ,STOP_PAY_AMT -- 止付金额
    ,PRE_AUTH_AMT -- 预授权金额
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,DATA_DT -- 数据日期
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.AA01AC15 AS ACCT_NO -- 账户编号
    ,P1.AA04FLNM AS ACCT_NAME -- 账户名称
    ,P1.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P2.USER_ID AS USER_ID -- 用户ID
    ,P3.CUST_NM AS CUST_NAME -- 客户名称
    ,P4.CRTF_TYP AS CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,P4.CRTF_NO AS CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CASE WHEN P1.AA03CSNO  like '81%' THEN '1' WHEN P1.AA03CSNO like '82%' THEN '2' ELSE '3' END AS CUST_TYPE_CD -- 客户类型代码
    ,P1.AA07CSTP AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN P5.BC08ZHTP IS NULL OR TRIM(P5.BC08ZHTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P5.BC08ZHTP)),'') END AS DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,P6.AB06ACFG AS DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,CASE WHEN  P6.AB13ACST='2' AND  SUBSTR(P6.AB14NO16,7,1)='1' AND   P11.CB15BDHS<>'3' --销户  
THEN '5'--不动户
ELSE P6.AB13ACST END AS DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,AA09ACT2 AS MED_TYPE_CD -- 介质类型代码
    ,CASE WHEN SUBSTR(P6.AB14NO16,3,1)='1' THEN '1' ELSE '0' END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,AA11PZZT AS REPLOS_STATUS_CD -- 挂失状态代码
    ,CASE WHEN SUBSTR(P6.AB14NO16,1,1)='1' THEN '1'  WHEN SUBSTR(P6.AB14NO16,2,1)='1' THEN '2' ELSE '0' END
 AS FRZ_STATUS_CD -- 冻结状态代码
    ,AA31SSLV AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,AA32SWLV AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,P1.AA23BLNO AS VOCH_NO -- 凭证号码
    ,P7.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P7.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,'' AS EACCT_NO -- 电子账户编号
    ,'' AS EACCT_STATUS_CD -- 电子账户状态代码
    ,'' AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,'' AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,'' AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,P6.AB09BUST AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,CONCAT(P6.AB10PDTP,P6.AB11PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,P8.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,CASE WHEN P1.AA49CFTP IS NULL OR TRIM(P1.AA49CFTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AA49CFTP)),'') END AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,P1.AA50CFNO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P6.AB03CCYC AS CURR_CD -- 币种代码
    ,P6.AB05CHSX AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TRIM(P1.AA53SDTP)='' THEN '0' ELSE '1' END AS MRGACCT_FLAG -- 保证金账户标志
    ,'2' AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,S1.CURR_BAL_CONVT_RMB AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,P6.AB22BAL AS CURR_BAL -- 当前余额
    ,S1.YESTD_BAL_CONVT_RMB AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,P6.AB20BAL AS YESTD_BAL -- 昨日余额
    ,null AS KEEP_AMT -- 保留金额
    ,P6.AB45AMT AS FRZ_AMT -- 冻结金额
    ,P6.AB23AMT AS CTRL_AMT -- 控制金额
    ,P6.AB46AMT AS STOP_PAY_AMT -- 止付金额
    ,null AS PRE_AUTH_AMT -- 预授权金额
    ,S1.YESTD_BAL_WEEK_ACCUM AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,S1.YESTD_BAL_MONTH_ACCUM AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,S1.YESTD_BAL_QUAR_ACCUM AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,S1.YESTD_BAL_YEAR_ACCUM AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,S1.YESTD_BAL_TOTAL_ACCUM AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,S1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,S1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,S1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,S1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,S1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,S1.ACTL_INT_AMT_YEAR_CUM AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,unifiedTime(P6.AB32DATE) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P6.AB34DATE) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(P1.AA39DATE) AS CANC_ACCT_DT -- 销户日期
    ,unifiedTime(P6.AB17DATE) AS VAL_DT -- 起息日期
    ,unifiedTime(P6.AB18DATE) AS MATU_DT -- 到期日期
    ,P6.AB36BRNO AS LP_ORG_NO -- 法人机构编号
    ,P6.AB33BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P6.AB35BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P9.BQ07BRNO AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,P9.BQ08STAF AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,P5.BC35CNCD AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN TRIM(P9.BQ09CNCD) = 'CC' THEN 'IC' ELSE P9.BQ09CNCD END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,'CORE' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,unifiedTime(P6.BUDIDATE) AS SETUP_DT -- 建立日期
    ,P6.BUTPSTAF AS SETUP_TELR_NO -- 建立柜员编号
    ,unifiedTime(P6.UPDTDATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,P6.UPOPSTAF AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(P6.AB30DATE) AS FINAL_TXN_DT -- 最后交易日期
    ,'' AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,P6.RCSTRS1B AS REC_STATUS_CD -- 记录状态代码
    ,'${process_date}' AS DATA_DT -- 数据日期
    ,'ODS_CORE_BFFMDQAA_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BFFMDQAA_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_CORE.ODS_CORE_BFFMDQAA_TF AS P1 -- 定期存款帐户控制文件

LEFT JOIN (
  select
   U3.CST_IN_CD ,
   U3.USER_ID
  from
    (
    select
     d3.USER_ID
     ,d3.CST_IN_CD 
     , row_number() over(partition by d3.CST_IN_CD
    order by
     d3.USER_ID desc ) rn
    from
     ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF D3
    where
     D3.PT_DT = '${process_date}' AND DEL_F = '0' 
     and deleted = '0'
     --and cst_in_cd = '81112145570'
    )U3
  where
   U3.rn = 1 
) AS P2 -- 用户信息表
       ON p1.AA03CSNO = p2.CST_IN_CD 
LEFT JOIN (
    SELECT 
        D3.CUST_NM
       ,D3.CST_IN_CD
    FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_BAS_TF d3
    WHERE  d3.PT_DT = '${process_date}' AND DEL_F = '0' 
) AS P3 -- 客户基础信息表
       ON p1.AA03CSNO = p3.CST_IN_CD 
LEFT JOIN (
   select U4.CST_IN_CD
     ,U4.CRTF_TYP
     ,U4.CRTF_NO
    from 
    (
        SELECT 
             d4.CRTF_TYP
            ,d4.CRTF_NO
            ,d4.CST_IN_CD
            ,row_number()over(partition by d4.CST_IN_CD order by d4.CRTF_NO desc ) rn
        FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF D4
        WHERE  D4.PT_DT = '${process_date}' AND DEL_F = '0'
AND DELETED = '0'
AND MAJOR_FLG = '1' 
    ) U4
   where U4.RN = 1
) AS P4 -- 客户证件信息表
       ON p1.AA03CSNO = p4.CST_IN_CD 
LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_022 AS P5 -- 开户登记簿
       ON p1.AA01AC15 = p5.BC01AC22 
LEFT JOIN ODS_CORE.ODS_CORE_BFFMDQAB_TF AS P6 -- 定期模块账户分户余额信息
       ON p1.AA01AC15 = p6.AB01AC15 
AND P6.PT_DT = '${process_date}' 
AND P6.DEL_F = '0' 
LEFT JOIN (
    SELECT 
        D7.KHDAACID
        ,D7.KHDAFLNM
        ,D7.KHDBACID

    FROM ODS_CORE.ODS_CORE_BGFDKHDZ_TF D7
    WHERE  D7.PT_DT = '${process_date}' AND DEL_F = '0' 
) AS P7 -- 新会计科目核算码对照表
       ON P6.AB12ACID = P7.KHDBACID 
LEFT JOIN (
 select 
  CB01AC22,
  CB15BDHS
 from ODS_core.Ods_core_BDFMHQCB_tf D5
 where D5.pt_dt ='${process_date}'
 and DEL_F = '0'
) AS P11 -- 不动户活期存款账户主档
       ON P11.CB01AC22 = P1.AA01AC15 
LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_021 AS P9 -- 销户登记薄
       ON trim(p1.AA01AC15) = trim(p9.BQ05AC15) 
LEFT JOIN (
    SELECT 
        D10.YRCAEXRT
        ,D10.YRCACUNO
        ,D10.YRCACCYC 
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D10
    WHERE  D10.PT_DT = '${process_date}' AND DEL_F = '0' 
        AND  CAST(D10.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D10.YRCARS1B <> '9'

) AS P10 -- 年度报表汇率文件
       ON p6.AB03CCYC=p10.YRCACCYC 
LEFT JOIN (
    SELECT 
        D6.CW03PRON
        ,D6.CW05FLNM 
        ,D6.CW02PDTP  
        ,D6.CW04BRNO
    FROM ODS_CORE.ODS_CORE_BDFMHQCW_TF D6
    WHERE  D6.PT_DT = '${process_date}' AND DEL_F = '0' 
    ) AS P8 -- 产品代码名称表
       ON P6.AB11PRON = P8.CW03PRON
AND P6.AB10PDTP = P8.CW02PDTP 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE P1.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P1.SRC_TAB_EN_NAME='BFFMDQAA' --来源表英文名  
     AND P1.SRC_FIELD_EN_NAME='AA49CFTP' --来源字段英文名 
     AND P1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  --目标表名   
     AND P1.TARGET_FIELD_EN_NAME='OPEN_ACCT_DOCTYP_CD' --目标字段 
) AS S3 -- 开户证件类型代码转换
       ON P1.AA49CFTP=S3.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P2
     WHERE P2.SRC_TAB_LIB_NAME ='CORE'  --源系统 简称或中文名 待定
     AND P2.SRC_TAB_EN_NAME='BDFMHQBC' --来源表英文名  
     AND P2.SRC_FIELD_EN_NAME='BC08ZHTP' --来源字段英文名 
     AND P2.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  --目标表名   
     AND P2.TARGET_FIELD_EN_NAME='DPSIT_ACCT_PROPTY_CD' --目标字段 
) AS S2 -- 账户性质代码
       ON P5.BC08ZHTP=S2.SRC_CD_VAL 
LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_04 AS S1 -- 个人存款账户信息聚合上日积数
       ON S1.ACCT_NO = P1.AA01AC15
AND S1.CURR_CD = P6.AB03CCYC
AND S1.CASH_RMT_CD = P6.AB05CHSX 
WHERE P1.PT_DT = '${process_date}' 
AND P1.DEL_F = '0' 
        AND SUBSTR(P1.AA01AC15,1,1) = '1'
;
-- ==============聚合层字段映射（第4组）==============
-- 个人存款账户信息聚合

INSERT INTO TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM(
     ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,CUST_NAME -- 客户名称
    ,CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CUST_TYPE_CD -- 客户类型代码
    ,INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,MED_TYPE_CD -- 介质类型代码
    ,STOP_PAY_STATUS_CD -- 止付状态代码
    ,REPLOS_STATUS_CD -- 挂失状态代码
    ,FRZ_STATUS_CD -- 冻结状态代码
    ,UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,VOCH_NO -- 凭证号码
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,EACCT_NO -- 电子账户编号
    ,EACCT_STATUS_CD -- 电子账户状态代码
    ,ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,MRGACCT_FLAG -- 保证金账户标志
    ,TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,CURR_BAL -- 当前余额
    ,YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,YESTD_BAL -- 昨日余额
    ,KEEP_AMT -- 保留金额
    ,FRZ_AMT -- 冻结金额
    ,CTRL_AMT -- 控制金额
    ,STOP_PAY_AMT -- 止付金额
    ,PRE_AUTH_AMT -- 预授权金额
    ,YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,OPEN_ACCT_DT -- 开户日期
    ,PAYOFF_DT -- 结清日期
    ,CANC_ACCT_DT -- 销户日期
    ,VAL_DT -- 起息日期
    ,MATU_DT -- 到期日期
    ,LP_ORG_NO -- 法人机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,CANC_ACCT_ORG_NO -- 销户机构编号
    ,CANC_ACCT_TELR_NO -- 销户柜员编号
    ,OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CANC_ACCT_CHNL -- 销户渠道代码
    ,B_SRC_SYS_CD -- 业务来源系统代码
    ,SETUP_DT -- 建立日期
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,FINAL_TXN_DT -- 最后交易日期
    ,CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,REC_STATUS_CD -- 记录状态代码
    ,DATA_DT -- 数据日期
    ,B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.ACCTNO AS ACCT_NO -- 账户编号
    ,P1.ACCTNA AS ACCT_NAME -- 账户名称
    ,P2.CUSTCD AS CUST_IN_CD -- 客户内码
    ,P2.CUSTID AS USER_ID -- 用户ID
    ,P2.CUST_NM AS CUST_NAME -- 客户名称
    ,P2.CRTF_TYP AS CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,P2.CRTF_NO AS CUST_MAIN_DOC_NO -- 客户主证件号码
    ,'1' AS CUST_TYPE_CD -- 客户类型代码
    ,'1' AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN P1.SPECTP IS NULL OR TRIM(P1.SPECTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.SPECTP)),'') END  AS DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,CASE WHEN P1.ACSETP IS NULL OR TRIM(P1.ACSETP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACSETP)),'') END  AS DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,CASE WHEN P1.ACCTST IS NULL OR TRIM(P1.ACCTST)='' 
     THEN '' 
ELSE COALESCE(TRIM(S5.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACCTST)),'') END  AS DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,'' AS MED_TYPE_CD -- 介质类型代码
    ,P5.STOP_PAY_STATUS_CD AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,CASE WHEN P4.RPLSTP = '1' 
     THEN '6' 
     WHEN P4.RPLSTP='2' 
     THEN 'W2' 
     ELSE '1' 
END AS REPLOS_STATUS_CD -- 挂失状态代码
    ,P5.FRZ_STATUS_CD AS FRZ_STATUS_CD -- 冻结状态代码
    ,'1' AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,'1' AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,COALESCE(P6.DCMTNO,CASE WHEN P7.ACCTST = '1' THEN P7.CARDNO WHEN P7.ACCTST = '0' AND P8.CARDNO LIKE '623540%'THEN P8.CARDNO ELSE '' END) AS VOCH_NO -- 凭证号码
    ,P9.SUBJECT AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P9.DESCRIPTION AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P1.CUSTAC AS EACCT_NO -- 电子账户编号
    ,'' AS EACCT_STATUS_CD -- 电子账户状态代码
    ,'' AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,'' AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,'' AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,CASE WHEN P1.DEBTTP IS NULL OR TRIM(P1.DEBTTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.DEBTTP)),'') END 
 AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,P1.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,'' AS DPSIT_PROD_NAME -- 存款产品名称
    ,P2.OPEN_ACCT_DOCTYP_CD AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,p2.OPEN_ACCT_DOC_NO AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,P1.CRCYCD AS CURR_CD -- 币种代码
    ,P1.CSEXTG AS CASH_RMT_CD -- 钞汇代码
    ,'' AS MRGACCT_FLAG -- 保证金账户标志
    ,'2' AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.ONLNBL
     ELSE P1.ONLNBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,P1.ONLNBL AS CURR_BAL -- 当前余额
    ,CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))    --AFFMYRPT.YRCACUNO这个应该是类似于 100元对应的汇率值
END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,P1.LASTBL AS YESTD_BAL -- 昨日余额
    ,null AS KEEP_AMT -- 保留金额
    ,P5.FRZ_AMT AS FRZ_AMT -- 冻结金额
    ,null AS CTRL_AMT -- 控制金额
    ,P5.STOP_PAY_AMT AS STOP_PAY_AMT -- 止付金额
    ,null AS PRE_AUTH_AMT -- 预授权金额
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为月初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_WEEK_ACCUM,0) + COALESCE(P1.LASTBL ,0) END AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为月初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_MONTH_ACCUM,0) + COALESCE(P1.LASTBL ,0) END  AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为季初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_QUAR_ACCUM,0) + COALESCE(P1.LASTBL ,0)  END  AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(P1.LASTBL ,0) --当为年初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_YEAR_ACCUM,0) + COALESCE(P1.LASTBL ,0)  END  AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,COALESCE(S4.YESTD_BAL_TOTAL_ACCUM,0) + COALESCE(P1.LASTBL ,0) AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,case when P1.PT_DT = cast(trunc('${process_date}','week') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) --当为月初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) END AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','MM') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) --当为月初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) END  AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','quarter') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) --当为季初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0)  END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) --当为年初时，取当日余额
ELSE COALESCE(S4.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0)  END  AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,COALESCE(S4.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,0) + COALESCE(CASE WHEN P1.CRCYCD = 'CNY'
     THEN P1.LASTBL
     ELSE P1.LASTBL*(NVL(P11.YRCAEXRT,0)/NVL(P11.YRCACUNO,1))     
END ,0) AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,case when P1.PT_DT = cast(trunc('${process_date}','YY') as STRING )  THEN  COALESCE(p13.ACTL_INT_AMT_YEAR_CUM ,0) --当为年初时，取当日余额
ELSE COALESCE(S4.ACTL_INT_AMT_YEAR_CUM,0)+ COALESCE(p13.ACTL_INT_AMT_YEAR_CUM ,0)  END  AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,unifiedTime(P1.OPENDT) AS OPEN_ACCT_DT -- 开户日期
    ,unifiedTime(P1.MATUDT) AS PAYOFF_DT -- 结清日期
    ,unifiedTime(P1.CLOSDT) AS CANC_ACCT_DT -- 销户日期
    ,unifiedTime(P1.BGINDT) AS VAL_DT -- 起息日期
    ,unifiedTime(P1.MATUDT) AS MATU_DT -- 到期日期
    ,P1.BRCHNO AS LP_ORG_NO -- 法人机构编号
    ,P1.BRCHNO AS STAT_ORG_NO -- 统计机构编号
    ,P1.BRCHNO AS BELONG_ORG_NO -- 归属机构编号
    ,'' AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,'' AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CASE WHEN P1.ACSETP IN ('01' ,'02','03','04') THEN 'NM' ELSE 'TE' END  AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN P1.ACCTST = '2' THEN 'NM' ELSE '' END  AS CANC_ACCT_CHNL -- 销户渠道代码
    ,'NAS' AS B_SRC_SYS_CD -- 业务来源系统代码
    ,'' AS SETUP_DT -- 建立日期
    ,'999S000' AS SETUP_TELR_NO -- 建立柜员编号
    ,substr(unifiedTime(P1.TIMETM),1,10) AS FINAL_MODIF_DT -- 最后修改日期
    ,'999S000' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,unifiedTime(P1.LSTRDT) AS FINAL_TXN_DT -- 最后交易日期
    ,unifiedTime(P1.LSTRDT) AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,'0' AS REC_STATUS_CD -- 记录状态代码
    ,'${process_date}' AS DATA_DT -- 数据日期
    ,'ODS_NAS_KNA_FXAC_TF' AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNA_FXAC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_NAS.ODS_NAS_KNA_FXAC_TF AS P1 -- 负债定期账户信息表

LEFT JOIN AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_031 AS P2 -- 用户信息表
       ON P1.CUSTNO  = P2.CUSTNO 
LEFT JOIN (
select 
      b4.RPLSTP
     ,b4.ACCTNO 
     ,b4.corpno
from 
(
 SELECT 
      D4.RPLSTP
     ,D4.ACCTNO 
     ,d4.corpno 
     ,row_number ()over(partition by D4.ACCTNO,d4.corpno order by d4.timetm desc) rn
 FROM  ODS_nas.ODS_Nas_KNB_RPVO_TF d4
     WHERE  d4.PT_DT = '${process_date}' AND DEL_F = '0' 
     and trim(coalesce(d4.corpno,'')) <> ''
)b4
where b4.rn =1
) AS P4 -- 挂失登记簿
       ON P1.ACCTNO = P4.ACCTNO
and p1.corpno = p4.corpno 
LEFT JOIN (SELECT
T1.CUSTAC
,CASE WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='1' THEN '2'
           WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='2' THEN '3'
WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='3' THEN '1'
WHEN T1.FROZTP IN ('1' ,'2','7') AND T1.FRLMTP='4' THEN '4' 
ELSE '0' END AS  FRZ_STATUS_CD --冻结状态代码
,CASE WHEN T1.FROZTP IN ('3' ,'4','5','6') AND T1.FRLMTP='1' THEN '2'
           WHEN T1.FROZTP IN ('3' ,'4','5','6') AND T1.FRLMTP='3' THEN '1'
WHEN T1.FROZTP IN  ('3' ,'4','5','6') AND T1.FRLMTP IN ( '2','4') THEN '3'
ELSE '0' END AS  STOP_PAY_STATUS_CD --止付状态代码
,SUM(CASE WHEN T1.FROZTP IN ('3','4','5','6') AND T1.FRLMTP IN ('3','4','1','2') THEN T2.FROZAM ELSE 0 END ) AS STOP_PAY_AMT--止付金额
,SUM(CASE WHEN T1.FROZTP IN ('1','2','7') AND T1.FRLMTP IN ('1','2','3','4') THEN T2.FROZAM ELSE 0 END) AS FRZ_AMT -- 冻结金额
FROM ODS_NAS.ODS_NAS_KNB_FROZ_TF T1
LEFT JOIN ODS_NAS.ODS_NAS_KNB_FROZ_DETL_TF T2
ON T1.FROZNO = T2.FROZNO 
AND T1.FROZSQ =T2.FROZSQ  
AND T2.FROZST='0' 
AND T2.DEL_F = '0' 
and T2.pt_dt  = '${process_date}'
WHERE T1.FREDDT='20990101' 
AND T1.FROZST = '0' 
AND T1.DEL_F='0'
and T1.pt_dt  = '${process_date}'
GROUP BY T1.CUSTAC,T1.FROZTP,T1.FRLMTP) AS P5 -- 冻结登记簿
       ON P1.CUSTAC = P5.CUSTAC 
LEFT JOIN (
    SELECT 
        d6.DCMTNO
        ,d6.ACCTNO 
         ,d6.corpno

    FROM ODS_nas.ODS_Nas_KNB_DCMT_TF d6
    WHERE  d6.PT_DT = '${process_date}' AND DEL_F = '0' 
) AS P6 -- 凭证登记簿
       ON P1.ACCTNO = P6.ACCTNO
AND P1.CORPNO = P6.CORPNO 
LEFT JOIN (
SELECT   T1.CUSTAC
        ,T1.ACCTST
        ,T1.CARDNO
        ,T1.CORPNO
        ,T1.acctno 
  FROM  ODS_NAS.ODS_NAS_KNA_SVAC_TF T1   --储蓄账户表
 WHERE  PT_DT = '${process_date}' AND DEL_F = '0' 

) AS P7 -- None
       ON P1.acctno = P7.acctno
AND P1.CORPNO = P7.CORPNO 
LEFT JOIN (
 select 
         p.CARDNO
         ,p.CUSTAC 
   ,p.CORPNO
   from 
 (
     SELECT 
         D8.CARDNO
         ,D8.CUSTAC 
   ,D8.CORPNO
   ,row_number ()over(partition by D8.CUSTAC order by timetm DESC) RN
     FROM ODS_nas.ODS_Nas_KNA_CACD_TF d8
     WHERE  d8.PT_DT = '${process_date}' AND DEL_F = '0' 
     and status  = '1'
     
 )p
 where p.rn =1
) AS P8 -- 外部卡与客户账号对照表
       ON P1.CUSTAC = P8.CUSTAC 
LEFT JOIN (
SELECT  T1.PRODUCT
       ,T1.SUBJECT
       ,T2.DESCRIPTION
FROM 
    (
     SELECT  EVENT_TYPE
            ,PRODUCT
            ,CASE WHEN SUBJECT_DR<>'' AND SUBJECT_DR <> '30410310' 
                  THEN SUBJECT_DR 
                  ELSE SUBJECT_CR
             END       SUBJECT
      FROM  ODS_GAS.ODS_GAS_CUX_EA_RULES_TF 
      WHERE SUBSTR(EVENT_TYPE,1,1) = '1' 
      AND   PT_DT = '${process_date}' AND DEL_F = '0'  
  ) T1
LEFT JOIN ODS_GAS.ODS_GAS_CUX_FLEX_VALUES_V_TF T2
ON        T2.FLEX_VALUE = T1.SUBJECT
AND       T2.PT_DT = '${process_date}' AND DEL_F = '0' 
GROUP BY  T1.PRODUCT
         ,T1.SUBJECT
         ,T2.DESCRIPTION
) AS P9 -- None
       ON P1.ACCTCD= P9.PRODUCT
AND P9.SUBJECT <> '' 
LEFT JOIN (
    SELECT 
        D11.YRCAEXRT
        ,D11.YRCACUNO
        ,D11.YRCACCYC 
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D11
    WHERE  D11.PT_DT = '${process_date}' AND DEL_F = '0' 
        AND  CAST(D11.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D11.YRCARS1B <> '9'

) AS P11 -- 年度报表汇率文件
       ON P1.CRCYCD=p11.YRCACCYC 
LEFT JOIN (
    select  T1.ACCTNO
           ,sum(T1.RLINTR) as ACTL_INT_AMT_YEAR_CUM
    from   ODS_NAS.ODS_NAS_KNB_PIDL_TF T1 --负债账户付息明细
    where    T1.PT_DT = '${process_date}'  --跑批日期参数
        AND    T1.DEL_F = '0'
 group by  T1.ACCTNO
) AS P13 -- None
       ON P1.ACCTNO = P13.ACCTNO 
LEFT JOIN (
    select T1.ACCTNO,
           T1.LASTBL
    from ODS_NAS.ODS_NAS_KNA_FXAC_TF t1
    where T1.PT_DT = '${process_date}'
        AND T1.PDDPFG IN ('0205','0204')
        AND T1.DEL_F = '0'
) AS P15 -- None
       ON P1.ACCTNO = P15.ACCTNO 
LEFT JOIN (
SELECT 
     P1.TARGET_CD_VAL
    ,P1.SRC_CD_VAL  
FROM AGL.PUB_CD_MAP P1
    WHERE p1.SRC_TAB_LIB_NAME ='NAS' 
    AND p1.SRC_TAB_EN_NAME='KNA_FXAC' 
    AND p1.SRC_FIELD_EN_NAME='SPECTP' 
    AND p1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  
    AND p1.TARGET_FIELD_EN_NAME='DPSIT_ACCT_PROPTY_CD' 
 ) AS S1 -- 开户证件类型代码转换
       ON P1.SPECTP=S1.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNA_FXAC' 
     AND p1.SRC_FIELD_EN_NAME='ACSETP' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  
     AND p1.TARGET_FIELD_EN_NAME='DPSIT_ACCT_TYPE_CD' 
) AS S2 -- 开户证件类型代码转换
       ON P1.ACSETP=S2.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNA_FXAC' 
     AND p1.SRC_FIELD_EN_NAME='DEBTTP' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  
     AND p1.TARGET_FIELD_EN_NAME='DPSIT_BIZ_CATEGORY_CD' 
) AS S3 -- 存款业务类别代码
       ON P1.DEBTTP=S3.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP P1
     WHERE p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNA_FXAC' 
     AND p1.SRC_FIELD_EN_NAME='ACCTST' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_DPSIT_ACCT_INFO_TF'  
     AND p1.TARGET_FIELD_EN_NAME='DPSIT_ACCT_STATUS_CD' 
) AS S5 -- 存款账户状态代码
       ON P1.ACCTST=S5.SRC_CD_VAL 
LEFT JOIN (
    select
        P1.ACCT_NO
        ,P1.CASH_RMT_CD
        ,P1.CURR_CD 
        ,P1.YESTD_BAL_MONTH_ACCUM
        ,P1.YESTD_BAL_QUAR_ACCUM
        ,P1.YESTD_BAL_YEAR_ACCUM
        ,P1.ACTL_INT_AMT_YEAR_CUM
        ,P1.YESTD_BAL_MONTH_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_WEEK_ACCUM
        ,P1.YESTD_BAL_TOTAL_ACCUM
        ,P1.YESTD_BAL_WEEK_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_QUAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_YEAR_ACCUM_CONVT_RMB
        ,P1.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB
    FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF P1
    WHERE P1.PT_DT = cast(DATE_SUB(TO_DATE('${process_date}'),1) as STRING)
AND P1.SRC_TAB_EN_NAME ='ODS_NAS_KNA_FXAC_TF'
AND DEL_F = '0'
) AS S4 -- 个人存款账户信息聚合上日积数
       ON S4.ACCT_NO =P1.ACCTNO 
WHERE P1.PDDPFG IN ('0205','0204') 
    AND P1.PT_DT = '${process_date}' 
AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_DPSIT_ACCT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NO, BF.ACCT_NO) END AS ACCT_NO -- 账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCT_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCT_NAME, BF.ACCT_NAME) END AS ACCT_NAME -- 账户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_IN_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_IN_CD, BF.CUST_IN_CD) END AS CUST_IN_CD -- 客户内码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.USER_ID IS NULL THEN NULL ELSE COALESCE(TM.USER_ID, BF.USER_ID) END AS USER_ID -- 用户ID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_NAME IS NULL THEN NULL ELSE COALESCE(TM.CUST_NAME, BF.CUST_NAME) END AS CUST_NAME -- 客户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_MAIN_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_MAIN_DOCTYP_CD, BF.CUST_MAIN_DOCTYP_CD) END AS CUST_MAIN_DOCTYP_CD -- 客户主证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_MAIN_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.CUST_MAIN_DOC_NO, BF.CUST_MAIN_DOC_NO) END AS CUST_MAIN_DOC_NO -- 客户主证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.CUST_TYPE_CD, BF.CUST_TYPE_CD) END AS CUST_TYPE_CD -- 客户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INDV_CORP_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.INDV_CORP_IDNT_CD, BF.INDV_CORP_IDNT_CD) END AS INDV_CORP_IDNT_CD -- 个人企业标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_ACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_ACCT_PROPTY_CD, BF.DPSIT_ACCT_PROPTY_CD) END AS DPSIT_ACCT_PROPTY_CD -- 存款账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_ACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_ACCT_TYPE_CD, BF.DPSIT_ACCT_TYPE_CD) END AS DPSIT_ACCT_TYPE_CD -- 存款账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_ACCT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_ACCT_STATUS_CD, BF.DPSIT_ACCT_STATUS_CD) END AS DPSIT_ACCT_STATUS_CD -- 存款账户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MED_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.MED_TYPE_CD, BF.MED_TYPE_CD) END AS MED_TYPE_CD -- 介质类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_PAY_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.STOP_PAY_STATUS_CD, BF.STOP_PAY_STATUS_CD) END AS STOP_PAY_STATUS_CD -- 止付状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REPLOS_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REPLOS_STATUS_CD, BF.REPLOS_STATUS_CD) END AS REPLOS_STATUS_CD -- 挂失状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.FRZ_STATUS_CD, BF.FRZ_STATUS_CD) END AS FRZ_STATUS_CD -- 冻结状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIVERSAL_WITHDR_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD, BF.UNIVERSAL_WITHDR_LVL_CD) END AS UNIVERSAL_WITHDR_LVL_CD -- 通兑级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.UNIVERSAL_SAVING_LVL_CD IS NULL THEN NULL ELSE COALESCE(TM.UNIVERSAL_SAVING_LVL_CD, BF.UNIVERSAL_SAVING_LVL_CD) END AS UNIVERSAL_SAVING_LVL_CD -- 通存级别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VOCH_NO IS NULL THEN NULL ELSE COALESCE(TM.VOCH_NO, BF.VOCH_NO) END AS VOCH_NO -- 凭证号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NO IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NO, BF.ACCTN_SUBJ_NO) END AS ACCTN_SUBJ_NO -- 会计科目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACCTN_SUBJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.ACCTN_SUBJ_NAME, BF.ACCTN_SUBJ_NAME) END AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EACCT_NO IS NULL THEN NULL ELSE COALESCE(TM.EACCT_NO, BF.EACCT_NO) END AS EACCT_NO -- 电子账户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.EACCT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.EACCT_STATUS_CD, BF.EACCT_STATUS_CD) END AS EACCT_STATUS_CD -- 电子账户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_PROPTY_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_PROPTY_CD, BF.ELEC_LIACCT_PROPTY_CD) END AS ELEC_LIACCT_PROPTY_CD -- 电子负债账户性质代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_CLS_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_CLS_CD, BF.ELEC_LIACCT_CLS_CD) END AS ELEC_LIACCT_CLS_CD -- 电子负债账户分类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ELEC_LIACCT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.ELEC_LIACCT_TYPE_CD, BF.ELEC_LIACCT_TYPE_CD) END AS ELEC_LIACCT_TYPE_CD -- 电子负债账户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_BIZ_CATEGORY_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_BIZ_CATEGORY_CD, BF.DPSIT_BIZ_CATEGORY_CD) END AS DPSIT_BIZ_CATEGORY_CD -- 存款业务类别代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PROD_CD IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PROD_CD, BF.DPSIT_PROD_CD) END AS DPSIT_PROD_CD -- 存款产品代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DPSIT_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.DPSIT_PROD_NAME, BF.DPSIT_PROD_NAME) END AS DPSIT_PROD_NAME -- 存款产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DOCTYP_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DOCTYP_CD, BF.OPEN_ACCT_DOCTYP_CD) END AS OPEN_ACCT_DOCTYP_CD -- 开户证件类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DOC_NO IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DOC_NO, BF.OPEN_ACCT_DOC_NO) END AS OPEN_ACCT_DOC_NO -- 开户证件号码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_CD IS NULL THEN NULL ELSE COALESCE(TM.CURR_CD, BF.CURR_CD) END AS CURR_CD -- 币种代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CASH_RMT_CD IS NULL THEN NULL ELSE COALESCE(TM.CASH_RMT_CD, BF.CASH_RMT_CD) END AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MRGACCT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.MRGACCT_FLAG, BF.MRGACCT_FLAG) END AS MRGACCT_FLAG -- 保证金账户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.TM_DEMAND_IDNT_CD IS NULL THEN NULL ELSE COALESCE(TM.TM_DEMAND_IDNT_CD, BF.TM_DEMAND_IDNT_CD) END AS TM_DEMAND_IDNT_CD -- 定活标识代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_BAL_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.CURR_BAL_CONVT_RMB, BF.CURR_BAL_CONVT_RMB) END AS CURR_BAL_CONVT_RMB -- 当前余额折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CURR_BAL IS NULL THEN NULL ELSE COALESCE(TM.CURR_BAL, BF.CURR_BAL) END AS CURR_BAL -- 当前余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_CONVT_RMB, BF.YESTD_BAL_CONVT_RMB) END AS YESTD_BAL_CONVT_RMB -- 昨日余额折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL, BF.YESTD_BAL) END AS YESTD_BAL -- 昨日余额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.KEEP_AMT IS NULL THEN NULL ELSE COALESCE(TM.KEEP_AMT, BF.KEEP_AMT) END AS KEEP_AMT -- 保留金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_AMT IS NULL THEN NULL ELSE COALESCE(TM.FRZ_AMT, BF.FRZ_AMT) END AS FRZ_AMT -- 冻结金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CTRL_AMT IS NULL THEN NULL ELSE COALESCE(TM.CTRL_AMT, BF.CTRL_AMT) END AS CTRL_AMT -- 控制金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STOP_PAY_AMT IS NULL THEN NULL ELSE COALESCE(TM.STOP_PAY_AMT, BF.STOP_PAY_AMT) END AS STOP_PAY_AMT -- 止付金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PRE_AUTH_AMT IS NULL THEN NULL ELSE COALESCE(TM.PRE_AUTH_AMT, BF.PRE_AUTH_AMT) END AS PRE_AUTH_AMT -- 预授权金额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_WEEK_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_WEEK_ACCUM, BF.YESTD_BAL_WEEK_ACCUM) END AS YESTD_BAL_WEEK_ACCUM -- 昨日余额周积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM, BF.YESTD_BAL_MONTH_ACCUM) END AS YESTD_BAL_MONTH_ACCUM -- 昨日余额月积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM, BF.YESTD_BAL_QUAR_ACCUM) END AS YESTD_BAL_QUAR_ACCUM -- 昨日余额季积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM, BF.YESTD_BAL_YEAR_ACCUM) END AS YESTD_BAL_YEAR_ACCUM -- 昨日余额年积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_TOTAL_ACCUM IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_TOTAL_ACCUM, BF.YESTD_BAL_TOTAL_ACCUM) END AS YESTD_BAL_TOTAL_ACCUM -- 昨日余额总积数
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_WEEK_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_WEEK_ACCUM_CONVT_RMB, BF.YESTD_BAL_WEEK_ACCUM_CONVT_RMB) END AS YESTD_BAL_WEEK_ACCUM_CONVT_RMB -- 昨日余额周积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB, BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB) END AS YESTD_BAL_MONTH_ACCUM_CONVT_RMB -- 昨日余额月积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_QUAR_ACCUM_CONVT_RMB -- 昨日余额季积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB, BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB) END AS YESTD_BAL_YEAR_ACCUM_CONVT_RMB -- 昨日余额年积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB IS NULL THEN NULL ELSE COALESCE(TM.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB, BF.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB) END AS YESTD_BAL_TOTAL_ACCUM_CONVT_RMB -- 昨日余额总积数折人民币
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.ACTL_INT_AMT_YEAR_CUM IS NULL THEN NULL ELSE COALESCE(TM.ACTL_INT_AMT_YEAR_CUM, BF.ACTL_INT_AMT_YEAR_CUM) END AS ACTL_INT_AMT_YEAR_CUM -- 实际利息发生额年累计
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_DT, BF.OPEN_ACCT_DT) END AS OPEN_ACCT_DT -- 开户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAYOFF_DT IS NULL THEN NULL ELSE COALESCE(TM.PAYOFF_DT, BF.PAYOFF_DT) END AS PAYOFF_DT -- 结清日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_DT IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_DT, BF.CANC_ACCT_DT) END AS CANC_ACCT_DT -- 销户日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.VAL_DT IS NULL THEN NULL ELSE COALESCE(TM.VAL_DT, BF.VAL_DT) END AS VAL_DT -- 起息日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MATU_DT IS NULL THEN NULL ELSE COALESCE(TM.MATU_DT, BF.MATU_DT) END AS MATU_DT -- 到期日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.STAT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.STAT_ORG_NO, BF.STAT_ORG_NO) END AS STAT_ORG_NO -- 统计机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_ORG_NO, BF.CANC_ACCT_ORG_NO) END AS CANC_ACCT_ORG_NO -- 销户机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_TELR_NO, BF.CANC_ACCT_TELR_NO) END AS CANC_ACCT_TELR_NO -- 销户柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_ACCT_CHNL_CD IS NULL THEN NULL ELSE COALESCE(TM.OPEN_ACCT_CHNL_CD, BF.OPEN_ACCT_CHNL_CD) END AS OPEN_ACCT_CHNL_CD -- 开户渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CANC_ACCT_CHNL IS NULL THEN NULL ELSE COALESCE(TM.CANC_ACCT_CHNL, BF.CANC_ACCT_CHNL) END AS CANC_ACCT_CHNL -- 销户渠道代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.B_SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.B_SRC_SYS_CD, BF.B_SRC_SYS_CD) END AS B_SRC_SYS_CD -- 业务来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_DT IS NULL THEN NULL ELSE COALESCE(TM.SETUP_DT, BF.SETUP_DT) END AS SETUP_DT -- 建立日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SETUP_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.SETUP_TELR_NO, BF.SETUP_TELR_NO) END AS SETUP_TELR_NO -- 建立柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_DT, BF.FINAL_MODIF_DT) END AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.FINAL_TXN_DT, BF.FINAL_TXN_DT) END AS FINAL_TXN_DT -- 最后交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CUST_FINAL_TXN_DT IS NULL THEN NULL ELSE COALESCE(TM.CUST_FINAL_TXN_DT, BF.CUST_FINAL_TXN_DT) END AS CUST_FINAL_TXN_DT -- 客户最后交易日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REC_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.REC_STATUS_CD, BF.REC_STATUS_CD) END AS REC_STATUS_CD -- 记录状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DATA_DT IS NULL THEN NULL ELSE COALESCE(TM.DATA_DT, BF.DATA_DT) END AS DATA_DT -- 数据日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.B_SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.B_SRC_TAB_EN_NAME, BF.B_SRC_TAB_EN_NAME) END AS B_SRC_TAB_EN_NAME -- 业务来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_MAIN_DOCTYP_CD,'') = COALESCE(BF.CUST_MAIN_DOCTYP_CD,'') -- 客户主证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_MAIN_DOC_NO,'') = COALESCE(BF.CUST_MAIN_DOC_NO,'') -- 客户主证件号码 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.INDV_CORP_IDNT_CD,'') = COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段相等
         AND COALESCE(TM.DPSIT_ACCT_PROPTY_CD,'') = COALESCE(BF.DPSIT_ACCT_PROPTY_CD,'') -- 存款账户性质代码 非主键字段相等
         AND COALESCE(TM.DPSIT_ACCT_TYPE_CD,'') = COALESCE(BF.DPSIT_ACCT_TYPE_CD,'') -- 存款账户类型代码 非主键字段相等
         AND COALESCE(TM.DPSIT_ACCT_STATUS_CD,'') = COALESCE(BF.DPSIT_ACCT_STATUS_CD,'') -- 存款账户状态代码 非主键字段相等
         AND COALESCE(TM.MED_TYPE_CD,'') = COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段相等
         AND COALESCE(TM.STOP_PAY_STATUS_CD,'') = COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段相等
         AND COALESCE(TM.REPLOS_STATUS_CD,'') = COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段相等
         AND COALESCE(TM.FRZ_STATUS_CD,'') = COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') = COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') = COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段相等
         AND COALESCE(TM.VOCH_NO,'') = COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.EACCT_NO,'') = COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段相等
         AND COALESCE(TM.EACCT_STATUS_CD,'') = COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') = COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_CLS_CD,'') = COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') = COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段相等
         AND COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') = COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_CD,'') = COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_NAME,'') = COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') = COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOC_NO,'') = COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段相等
         AND COALESCE(TM.MRGACCT_FLAG,'') = COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段相等
         AND COALESCE(TM.TM_DEMAND_IDNT_CD,'') = COALESCE(BF.TM_DEMAND_IDNT_CD,'') -- 定活标识代码 非主键字段相等
         AND COALESCE(TM.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 当前余额折人民币 非主键字段相等
         AND COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段相等
         AND COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段相等
         AND COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段相等
         AND COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段相等
         AND COALESCE(TM.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 预授权金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数折人民币 非主键字段相等
         AND COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.PAYOFF_DT,'') = COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.VAL_DT,'') = COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段相等
         AND COALESCE(TM.MATU_DT,'') = COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_ORG_NO,'') = COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TELR_NO,'') = COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_CHNL_CD,'') = COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_CHNL,'') = COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_TXN_DT,'') = COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段相等
         AND COALESCE(TM.CUST_FINAL_TXN_DT,'') = COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.DATA_DT,'') = COALESCE(BF.DATA_DT,'') -- 数据日期 非主键字段相等
         AND COALESCE(TM.B_SRC_TAB_EN_NAME,'') = COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_MAIN_DOCTYP_CD,'') <> COALESCE(BF.CUST_MAIN_DOCTYP_CD,'') -- 客户主证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_MAIN_DOC_NO,'') <> COALESCE(BF.CUST_MAIN_DOC_NO,'') -- 客户主证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.INDV_CORP_IDNT_CD,'') <> COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_ACCT_PROPTY_CD,'') <> COALESCE(BF.DPSIT_ACCT_PROPTY_CD,'') -- 存款账户性质代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_ACCT_TYPE_CD,'') <> COALESCE(BF.DPSIT_ACCT_TYPE_CD,'') -- 存款账户类型代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_ACCT_STATUS_CD,'') <> COALESCE(BF.DPSIT_ACCT_STATUS_CD,'') -- 存款账户状态代码 非主键字段不相等
         OR COALESCE(TM.MED_TYPE_CD,'') <> COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_STATUS_CD,'') <> COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段不相等
         OR COALESCE(TM.REPLOS_STATUS_CD,'') <> COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段不相等
         OR COALESCE(TM.FRZ_STATUS_CD,'') <> COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段不相等
         OR COALESCE(TM.VOCH_NO,'') <> COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.EACCT_NO,'') <> COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段不相等
         OR COALESCE(TM.EACCT_STATUS_CD,'') <> COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') <> COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_CLS_CD,'') <> COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') <> COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') <> COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_CD,'') <> COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_NAME,'') <> COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') <> COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOC_NO,'') <> COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段不相等
         OR COALESCE(TM.MRGACCT_FLAG,'') <> COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段不相等
         OR COALESCE(TM.TM_DEMAND_IDNT_CD,'') <> COALESCE(BF.TM_DEMAND_IDNT_CD,'') -- 定活标识代码 非主键字段不相等
         OR COALESCE(TM.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 当前余额折人民币 非主键字段不相等
         OR COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段不相等
         OR COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段不相等
         OR COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段不相等
         OR COALESCE(TM.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 预授权金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数折人民币 非主键字段不相等
         OR COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.PAYOFF_DT,'') <> COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.VAL_DT,'') <> COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段不相等
         OR COALESCE(TM.MATU_DT,'') <> COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_ORG_NO,'') <> COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TELR_NO,'') <> COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_CHNL_CD,'') <> COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_CHNL,'') <> COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_TXN_DT,'') <> COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段不相等
         OR COALESCE(TM.CUST_FINAL_TXN_DT,'') <> COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.DATA_DT,'') <> COALESCE(BF.DATA_DT,'') -- 数据日期 非主键字段不相等
         OR COALESCE(TM.B_SRC_TAB_EN_NAME,'') <> COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') = COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.USER_ID,'') = COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段相等
         AND COALESCE(TM.CUST_NAME,'') = COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段相等
         AND COALESCE(TM.CUST_MAIN_DOCTYP_CD,'') = COALESCE(BF.CUST_MAIN_DOCTYP_CD,'') -- 客户主证件类型代码 非主键字段相等
         AND COALESCE(TM.CUST_MAIN_DOC_NO,'') = COALESCE(BF.CUST_MAIN_DOC_NO,'') -- 客户主证件号码 非主键字段相等
         AND COALESCE(TM.CUST_TYPE_CD,'') = COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段相等
         AND COALESCE(TM.INDV_CORP_IDNT_CD,'') = COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段相等
         AND COALESCE(TM.DPSIT_ACCT_PROPTY_CD,'') = COALESCE(BF.DPSIT_ACCT_PROPTY_CD,'') -- 存款账户性质代码 非主键字段相等
         AND COALESCE(TM.DPSIT_ACCT_TYPE_CD,'') = COALESCE(BF.DPSIT_ACCT_TYPE_CD,'') -- 存款账户类型代码 非主键字段相等
         AND COALESCE(TM.DPSIT_ACCT_STATUS_CD,'') = COALESCE(BF.DPSIT_ACCT_STATUS_CD,'') -- 存款账户状态代码 非主键字段相等
         AND COALESCE(TM.MED_TYPE_CD,'') = COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段相等
         AND COALESCE(TM.STOP_PAY_STATUS_CD,'') = COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段相等
         AND COALESCE(TM.REPLOS_STATUS_CD,'') = COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段相等
         AND COALESCE(TM.FRZ_STATUS_CD,'') = COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') = COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段相等
         AND COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') = COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段相等
         AND COALESCE(TM.VOCH_NO,'') = COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NO,'') = COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段相等
         AND COALESCE(TM.ACCTN_SUBJ_NAME,'') = COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段相等
         AND COALESCE(TM.EACCT_NO,'') = COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段相等
         AND COALESCE(TM.EACCT_STATUS_CD,'') = COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') = COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_CLS_CD,'') = COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段相等
         AND COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') = COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段相等
         AND COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') = COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_CD,'') = COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段相等
         AND COALESCE(TM.DPSIT_PROD_NAME,'') = COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') = COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DOC_NO,'') = COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段相等
         AND COALESCE(TM.MRGACCT_FLAG,'') = COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段相等
         AND COALESCE(TM.TM_DEMAND_IDNT_CD,'') = COALESCE(BF.TM_DEMAND_IDNT_CD,'') -- 定活标识代码 非主键字段相等
         AND COALESCE(TM.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 当前余额折人民币 非主键字段相等
         AND COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段相等
         AND COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段相等
         AND COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段相等
         AND COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段相等
         AND COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段相等
         AND COALESCE(TM.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 预授权金额 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段相等
         AND COALESCE(TM.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数折人民币 非主键字段相等
         AND COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_DT,'') = COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段相等
         AND COALESCE(TM.PAYOFF_DT,'') = COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_DT,'') = COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段相等
         AND COALESCE(TM.VAL_DT,'') = COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段相等
         AND COALESCE(TM.MATU_DT,'') = COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.STAT_ORG_NO,'') = COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_ORG_NO,'') = COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_TELR_NO,'') = COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段相等
         AND COALESCE(TM.OPEN_ACCT_CHNL_CD,'') = COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段相等
         AND COALESCE(TM.CANC_ACCT_CHNL,'') = COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段相等
         AND COALESCE(TM.B_SRC_SYS_CD,'') = COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段相等
         AND COALESCE(TM.SETUP_DT,'') = COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段相等
         AND COALESCE(TM.SETUP_TELR_NO,'') = COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_DT,'') = COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.FINAL_TXN_DT,'') = COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段相等
         AND COALESCE(TM.CUST_FINAL_TXN_DT,'') = COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段相等
         AND COALESCE(TM.REC_STATUS_CD,'') = COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段相等
         AND COALESCE(TM.DATA_DT,'') = COALESCE(BF.DATA_DT,'') -- 数据日期 非主键字段相等
         AND COALESCE(TM.B_SRC_TAB_EN_NAME,'') = COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.ACCT_NAME,'') <> COALESCE(BF.ACCT_NAME,'') -- 账户名称 非主键字段不相等
         OR COALESCE(TM.CUST_IN_CD,'') <> COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段不相等
         OR COALESCE(TM.USER_ID,'') <> COALESCE(BF.USER_ID,'') -- 用户ID 非主键字段不相等
         OR COALESCE(TM.CUST_NAME,'') <> COALESCE(BF.CUST_NAME,'') -- 客户名称 非主键字段不相等
         OR COALESCE(TM.CUST_MAIN_DOCTYP_CD,'') <> COALESCE(BF.CUST_MAIN_DOCTYP_CD,'') -- 客户主证件类型代码 非主键字段不相等
         OR COALESCE(TM.CUST_MAIN_DOC_NO,'') <> COALESCE(BF.CUST_MAIN_DOC_NO,'') -- 客户主证件号码 非主键字段不相等
         OR COALESCE(TM.CUST_TYPE_CD,'') <> COALESCE(BF.CUST_TYPE_CD,'') -- 客户类型代码 非主键字段不相等
         OR COALESCE(TM.INDV_CORP_IDNT_CD,'') <> COALESCE(BF.INDV_CORP_IDNT_CD,'') -- 个人企业标识代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_ACCT_PROPTY_CD,'') <> COALESCE(BF.DPSIT_ACCT_PROPTY_CD,'') -- 存款账户性质代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_ACCT_TYPE_CD,'') <> COALESCE(BF.DPSIT_ACCT_TYPE_CD,'') -- 存款账户类型代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_ACCT_STATUS_CD,'') <> COALESCE(BF.DPSIT_ACCT_STATUS_CD,'') -- 存款账户状态代码 非主键字段不相等
         OR COALESCE(TM.MED_TYPE_CD,'') <> COALESCE(BF.MED_TYPE_CD,'') -- 介质类型代码 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_STATUS_CD,'') <> COALESCE(BF.STOP_PAY_STATUS_CD,'') -- 止付状态代码 非主键字段不相等
         OR COALESCE(TM.REPLOS_STATUS_CD,'') <> COALESCE(BF.REPLOS_STATUS_CD,'') -- 挂失状态代码 非主键字段不相等
         OR COALESCE(TM.FRZ_STATUS_CD,'') <> COALESCE(BF.FRZ_STATUS_CD,'') -- 冻结状态代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_WITHDR_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_WITHDR_LVL_CD,'') -- 通兑级别代码 非主键字段不相等
         OR COALESCE(TM.UNIVERSAL_SAVING_LVL_CD,'') <> COALESCE(BF.UNIVERSAL_SAVING_LVL_CD,'') -- 通存级别代码 非主键字段不相等
         OR COALESCE(TM.VOCH_NO,'') <> COALESCE(BF.VOCH_NO,'') -- 凭证号码 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NO,'') <> COALESCE(BF.ACCTN_SUBJ_NO,'') -- 会计科目编号 非主键字段不相等
         OR COALESCE(TM.ACCTN_SUBJ_NAME,'') <> COALESCE(BF.ACCTN_SUBJ_NAME,'') -- 会计科目名称 非主键字段不相等
         OR COALESCE(TM.EACCT_NO,'') <> COALESCE(BF.EACCT_NO,'') -- 电子账户编号 非主键字段不相等
         OR COALESCE(TM.EACCT_STATUS_CD,'') <> COALESCE(BF.EACCT_STATUS_CD,'') -- 电子账户状态代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_PROPTY_CD,'') <> COALESCE(BF.ELEC_LIACCT_PROPTY_CD,'') -- 电子负债账户性质代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_CLS_CD,'') <> COALESCE(BF.ELEC_LIACCT_CLS_CD,'') -- 电子负债账户分类代码 非主键字段不相等
         OR COALESCE(TM.ELEC_LIACCT_TYPE_CD,'') <> COALESCE(BF.ELEC_LIACCT_TYPE_CD,'') -- 电子负债账户类型代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_BIZ_CATEGORY_CD,'') <> COALESCE(BF.DPSIT_BIZ_CATEGORY_CD,'') -- 存款业务类别代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_CD,'') <> COALESCE(BF.DPSIT_PROD_CD,'') -- 存款产品代码 非主键字段不相等
         OR COALESCE(TM.DPSIT_PROD_NAME,'') <> COALESCE(BF.DPSIT_PROD_NAME,'') -- 存款产品名称 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOCTYP_CD,'') <> COALESCE(BF.OPEN_ACCT_DOCTYP_CD,'') -- 开户证件类型代码 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DOC_NO,'') <> COALESCE(BF.OPEN_ACCT_DOC_NO,'') -- 开户证件号码 非主键字段不相等
         OR COALESCE(TM.MRGACCT_FLAG,'') <> COALESCE(BF.MRGACCT_FLAG,'') -- 保证金账户标志 非主键字段不相等
         OR COALESCE(TM.TM_DEMAND_IDNT_CD,'') <> COALESCE(BF.TM_DEMAND_IDNT_CD,'') -- 定活标识代码 非主键字段不相等
         OR COALESCE(TM.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 当前余额折人民币 非主键字段不相等
         OR COALESCE(TM.CURR_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CURR_BAL,CAST(0 AS DECIMAL(28,2))) -- 当前余额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL,CAST(0 AS DECIMAL(28,2))) -- 昨日余额 非主键字段不相等
         OR COALESCE(TM.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.KEEP_AMT,CAST(0 AS DECIMAL(28,2))) -- 保留金额 非主键字段不相等
         OR COALESCE(TM.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.FRZ_AMT,CAST(0 AS DECIMAL(28,2))) -- 冻结金额 非主键字段不相等
         OR COALESCE(TM.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.CTRL_AMT,CAST(0 AS DECIMAL(28,2))) -- 控制金额 非主键字段不相等
         OR COALESCE(TM.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.STOP_PAY_AMT,CAST(0 AS DECIMAL(28,2))) -- 止付金额 非主键字段不相等
         OR COALESCE(TM.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.PRE_AUTH_AMT,CAST(0 AS DECIMAL(28,2))) -- 预授权金额 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_WEEK_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_TOTAL_ACCUM,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_WEEK_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额周积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_MONTH_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额月积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_QUAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额季积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_YEAR_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额年积数折人民币 非主键字段不相等
         OR COALESCE(TM.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.YESTD_BAL_TOTAL_ACCUM_CONVT_RMB,CAST(0 AS DECIMAL(28,2))) -- 昨日余额总积数折人民币 非主键字段不相等
         OR COALESCE(TM.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.ACTL_INT_AMT_YEAR_CUM,CAST(0 AS DECIMAL(28,2))) -- 实际利息发生额年累计 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_DT,'') <> COALESCE(BF.OPEN_ACCT_DT,'') -- 开户日期 非主键字段不相等
         OR COALESCE(TM.PAYOFF_DT,'') <> COALESCE(BF.PAYOFF_DT,'') -- 结清日期 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_DT,'') <> COALESCE(BF.CANC_ACCT_DT,'') -- 销户日期 非主键字段不相等
         OR COALESCE(TM.VAL_DT,'') <> COALESCE(BF.VAL_DT,'') -- 起息日期 非主键字段不相等
         OR COALESCE(TM.MATU_DT,'') <> COALESCE(BF.MATU_DT,'') -- 到期日期 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.STAT_ORG_NO,'') <> COALESCE(BF.STAT_ORG_NO,'') -- 统计机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_ORG_NO,'') <> COALESCE(BF.CANC_ACCT_ORG_NO,'') -- 销户机构编号 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_TELR_NO,'') <> COALESCE(BF.CANC_ACCT_TELR_NO,'') -- 销户柜员编号 非主键字段不相等
         OR COALESCE(TM.OPEN_ACCT_CHNL_CD,'') <> COALESCE(BF.OPEN_ACCT_CHNL_CD,'') -- 开户渠道代码 非主键字段不相等
         OR COALESCE(TM.CANC_ACCT_CHNL,'') <> COALESCE(BF.CANC_ACCT_CHNL,'') -- 销户渠道代码 非主键字段不相等
         OR COALESCE(TM.B_SRC_SYS_CD,'') <> COALESCE(BF.B_SRC_SYS_CD,'') -- 业务来源系统代码 非主键字段不相等
         OR COALESCE(TM.SETUP_DT,'') <> COALESCE(BF.SETUP_DT,'') -- 建立日期 非主键字段不相等
         OR COALESCE(TM.SETUP_TELR_NO,'') <> COALESCE(BF.SETUP_TELR_NO,'') -- 建立柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_DT,'') <> COALESCE(BF.FINAL_MODIF_DT,'') -- 最后修改日期 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.FINAL_TXN_DT,'') <> COALESCE(BF.FINAL_TXN_DT,'') -- 最后交易日期 非主键字段不相等
         OR COALESCE(TM.CUST_FINAL_TXN_DT,'') <> COALESCE(BF.CUST_FINAL_TXN_DT,'') -- 客户最后交易日期 非主键字段不相等
         OR COALESCE(TM.REC_STATUS_CD,'') <> COALESCE(BF.REC_STATUS_CD,'') -- 记录状态代码 非主键字段不相等
         OR COALESCE(TM.DATA_DT,'') <> COALESCE(BF.DATA_DT,'') -- 数据日期 非主键字段不相等
         OR COALESCE(TM.B_SRC_TAB_EN_NAME,'') <> COALESCE(BF.B_SRC_TAB_EN_NAME,'') -- 业务来源表英文名称 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL.AGL_INDV_DPSIT_ACCT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.ACCT_NO,'') = COALESCE(BF.ACCT_NO,'') -- 账户编号 主键字段关联
    AND COALESCE(TM.CURR_CD,'') = COALESCE(BF.CURR_CD,'') -- 币种代码 主键字段关联
    AND COALESCE(TM.CASH_RMT_CD,'') = COALESCE(BF.CASH_RMT_CD,'') -- 钞汇代码 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_DPSIT_ACCT_INFO_TF_TM;
DROP TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_01;
DROP TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_02;
DROP TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_021;
DROP TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_022;
DROP TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_031;
DROP TABLE AGL.TMP_AGL_INDV_DPSIT_ACCT_INFO_TF_04;
