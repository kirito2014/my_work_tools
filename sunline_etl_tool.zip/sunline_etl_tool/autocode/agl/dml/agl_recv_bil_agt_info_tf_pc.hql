-- 模板名称: 聚合层-主档表-全量快照脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 14:45:10
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_AGT_INFO_TF
--     表中文名：收单协议信息聚合
--     创建日期：2023-12-19 00:00:00
--     主键字段：MERCHT_IDTFY_NO, RECV_BIL_PROD_NO, SPC_ARGMT_MERCHT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军/魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-19 00:00:00 沈健 新增
--         2024-08-01 00:00:00 王穆军/魏丹丹 修改同步设计文档，修改筛选条件，码值映射
--         2024-08-28 00:00:00 王穆军/魏丹丹 新增字段，修改逻辑
--         2024-09-05 00:00:00 王穆军/魏丹丹 新增字段，修改码值
--         2024-09-25 00:00:00 王穆军/魏丹丹 修改0902 第6组主表变更



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM
USING ORC
COMMENT '收单协议信息聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS DT_FLG -- 数据存在标志
FROM AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 收单协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM(
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     P1.MCHSEQ AS MERCHT_IDTFY_NO -- 商户识别编号
    ,P1.AGREID AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,P1.SMVESQ AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,P1.BUSITY AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,P1.MIDDLE_MCHSEQ AS PAY_PROJ_NO -- 缴费项目编号
    ,P1.MIDDLE_PRNAME AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.PACHID AS LP_ORG_NO -- 法人机构编号
    ,P1.FOURBH AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,P1.FIVEBH AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,T1.BEBRCH AS BELONG_ORG_NO -- 归属机构编号
    ,P1.PDCODE AS RECV_BIL_PROD_NO -- 收单产品编号
    ,P1.PDNAME AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,P2.PDTYPE AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,CASE WHEN  trim(P1.pdcode) in ('P99920231010200002', 'P99920221010200001')
    THEN 'POSCLOUD'
WHEN substr(P1.PDCODE, 10,2) in ('02', '03')
    THEN 'OPEN3CLOUD'
WHEN trim(P1.pdcode) ='P99920211010100001' or(trim(P1.pdcode) not in ('P99920231010200002', 'P99920221010200001') and substr(P1.PDCODE, 10,2) ='01')
    THEN'YMTCLOUD'
END AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,CASE WHEN  trim(P1.pdcode) in ('P99920231010200002', 'P99920221010200001')
    THEN 'POS'
WHEN substr(P1.PDCODE, 10,2) in ('02', '03')
    THEN 'OPEN'
WHEN trim(P1.pdcode) ='P99920211010100001' or(trim(P1.pdcode) not in ('P99920231010200002', 'P99920221010200001') and substr(P1.PDCODE, 10,2) ='01')
    THEN 'YMT'
END AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,substr(p1.PDCODE,10,2) AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,P1.SMCHNO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.SMCHNA AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.SAPPID AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,T1.MCHTYP AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,P3.PAPBID AS MERCHT_NO -- 商户编号
    ,P3.PBNAME AS MERCHT_NAME -- 商户名称
    ,'0' AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,'' AS MERCHT_PLAT_NO -- 商户平台编号
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,P1.SEPRNM AS SERV_PROVDER_NO -- 服务商编号
    ,P1.SEPRNA AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.SEAPID AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,P1.WALTYE AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,P1.WALLID AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,P1.CASTYE AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,P1.CABUYE AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,P1.SCENCD AS APP_SCENE_CD -- 应用场景代码
    ,CASE WHEN P1.MRCHID IS NULL OR TRIM(P1.MRCHID)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.MRCHID)),'') END AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,P1.MRCHNA AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,P1.ISHELP AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,CASE WHEN P5.LIMTTP='21' THEN P5.SIGLAM END AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,CASE WHEN P5.LIMTTP='21' THEN P5.DYTLAM END AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,CASE WHEN P5.LIMTTP='21' THEN P5.MHTLAM END AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,CASE WHEN P5.LIMTTP='22' THEN P5.SIGLAM END AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,CASE WHEN P5.LIMTTP='22' THEN P5.DYTLAM END AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,CASE WHEN P5.LIMTTP='22' THEN P5.MHTLAM END AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,P1.ISINTE AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,P1.INTEMD AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,P1.INTEVL AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,P1.ISCOUP AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,P1.ISRAND AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,P6.BILLMD AS FEE_MODE_CD -- 计费模式代码
    ,P7.MONWAY AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,P7.MONCYC AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,P7.REFWAY AS REFUND_MODE_CD -- 退款模式代码
    ,P7.FEECYC AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,P1.APPLST AS APP_STATUS_CD -- 申请状态代码
    ,unifiedTime(P1.VEFYDT) AS APP_TM_STAMP -- 申请时间戳
    ,CASE WHEN P1.VEFYST IS NULL OR TRIM(P1.VEFYST)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.VEFYST)),'') END AS AUDIT_STATUS_CD -- 审核状态代码
    ,unifiedTime(P1.VEFYST_TIME) AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,NULL AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,P1.AGREST AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,T1.MCSTAT AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,P1.FRTYPE AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,P1.FRREMA AS FRZ_RSN_REM -- 冻结原因备注
    ,unifiedTime(P1.FRTIME) AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,unifiedTime(P1.URTIME) AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,P1.TRANUS AS INPUT_TELR_NO -- 录入柜员编号
    ,P1.BRCHNO AS INPUT_ORG_NO -- 录入机构编号
    ,unifiedTime(P1.GMT_CREATE) AS CREATE_TM_STAMP -- 创建时间戳
    ,P1.UPDUSR AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,P1.UPBRCHNO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPTYPE AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,unifiedTime(P1.GMT_MODIFIED) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'MCSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MCSP_PRDU_AGREEMENT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_MCSP${version_num}.ODS_MCSP_PRDU_AGREEMENT_TF AS P1 -- 产品签约表

LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_SMERCHANT_INFO_TF AS T1 -- 特约商户表
       ON P1.SMCHNO = T1.SMCHNO AND  T1.DEL_F='0'  AND  T1.PT_DT='${process_date}' 
LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_PRDU_PAY_INFO_TF AS P2 -- 收单产品基本信息表
       ON P1.PDCODE = P2.PDCODE  AND P2.DEL_F='0' AND P2.PT_DT='${process_date}' 
LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_SMERCHANT_INFO_DETAIL_TF AS P3 -- 特约商户基本信息表
       ON P1.SMCHNO = P3.SMCHNO AND  P3.DEL_F='0'  AND  P3.PT_DT='${process_date}' 
LEFT JOIN (SELECT 
MERTNO
,SIGLAM
,MHTLAM
,DYTLAM
,LIMTTP 
,PRODTP
FROM ODS_LCS${version_num}.ODS_LCS_KMT_MERT_LIMT_TF
WHERE  ACCTTP='%' AND SERVTP='%'  AND  DEL_F='0' AND  PT_DT='${process_date}'
) AS P5 -- 商户额度信息表
       ON P3.PAPBID =P5.MERTNO   AND P1.pdcode = P5.PRODTP 
LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_BILL_AGREEMENT_TF AS P6 -- 手续费签约表
       ON P1.MCHSEQ = P6.MCHSEQ AND P6.IS_DELETE = '0' AND P6.DEL_F='0' AND   P6.PT_DT='${process_date}' 
LEFT JOIN ODS_MCSP${version_num}.ODS_MCSP_SMERCHANT_SETM_TF AS P7 -- 特约商户结算信息表
       ON P1.SMCHNO = P7.BUSSNO   AND  P7.DEL_F='0' AND   P7.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S1 -- None
       ON P1.MRCHID=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S1.SRC_TAB_EN_NAME='PRDU_AGREEMENT' --来源表英文名 大写
AND S1.SRC_FIELD_EN_NAME='MRCHID' --来源字段英文名 大写
AND S1.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND S1.TARGET_FIELD_EN_NAME='IN_BANK_SCENE_PLAT_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- None
       ON P1.VEFYST=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='MCSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='PRDU_AGREEMENT' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='VEFYST' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='AUDIT_STATUS_CD'  
WHERE P1.PT_DT='${process_date}' AND P1.ISTEST='0' AND P1.IS_DELETE='0' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 收单协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM(
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT(P1.MERCHANT_NO,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,'' AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,'' AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.ORG_CODE AS LP_ORG_NO -- 法人机构编号
    ,'' AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,'' AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,P1.ORG_CODE AS BELONG_ORG_NO -- 归属机构编号
    ,'OPENPOSP' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'03' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'OPEN2' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'OPEN' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'03' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,P1.MERCHANT_NO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCHANT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CASE WHEN P1.MERCHANT_SPECIES IS NULL OR TRIM(P1.MERCHANT_SPECIES)='' 
     THEN '' 
ELSE COALESCE(TRIM(P6.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_SPECIES),'') END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'0' AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,'' AS MERCHT_PLAT_NO -- 商户平台编号
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS SERV_PROVDER_NO -- 服务商编号
    ,P1.OUT_SERVICE_INST_NAME AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.DEVELOPER_ID AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,'' AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,'' AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,'' AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,'' AS APP_SCENE_CD -- 应用场景代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,P1.IS_HELP_FARMER AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,NULL AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,NULL AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,NULL AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,NULL AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,NULL AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,NULL AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,'' AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,'' AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,NULL AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,'' AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,'' AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,'' AS FEE_MODE_CD -- 计费模式代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN P1.SETTLEMENT_PERIOD IS NULL OR TRIM(P1.SETTLEMENT_PERIOD)='' 
     THEN '' 
ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEMENT_PERIOD),'') END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,CASE WHEN P1.MERCHANT_STATUS   IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') END AS APP_STATUS_CD -- 申请状态代码
    ,NULL AS APP_TM_STAMP -- 申请时间戳
    ,CASE WHEN P1.PROCESS_STATUS IS NULL OR TRIM(P1.PROCESS_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.PROCESS_STATUS),'') END AS AUDIT_STATUS_CD -- 审核状态代码
    ,unifiedTime(P1.REVIEW_TIME) AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,NULL AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,'' AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,CASE WHEN P1.MERCHANT_STATUS   IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(T3.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') END AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,NULL AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,NULL AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,unifiedTime(P1.CREATE_TIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,unifiedTime(P1.UPDATE_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_ACPS_MGM_OPEN_MERCHANT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_OPEN_MERCHANT_TF AS P1 -- 开放收单商户信息表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值表
       ON CAST(P1.SETTLEMENT_PERIOD as STRING)=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P2.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P2.SRC_FIELD_EN_NAME='SETTLEMENT_PERIOD' --来源字段英文名 大写
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS T3 -- 码值表
       ON CAST(P1.MERCHANT_STATUS AS STRING)=T3.SRC_CD_VAL  
AND T3.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND T3.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND T3.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND T3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND T3.TARGET_FIELD_EN_NAME='RECV_BIL_MERCHT_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值表
       ON CAST(P1.MERCHANT_STATUS AS STRING)=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P4.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P4.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P4.TARGET_FIELD_EN_NAME='APP_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值表
       ON CAST(P1.PROCESS_STATUS AS STRING)=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P5.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P5.SRC_FIELD_EN_NAME='PROCESS_STATUS' --来源字段英文名 大写
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P5.TARGET_FIELD_EN_NAME='AUDIT_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P6 -- 码值表
       ON CAST(P1.MERCHANT_SPECIES AS STRING)=P6.SRC_CD_VAL  
AND P6.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P6.SRC_TAB_EN_NAME='ACPS_MGM_OPEN_MERCHANT' --来源表英文名 大写
AND P6.SRC_FIELD_EN_NAME='MERCHANT_SPECIES' --来源字段英文名 大写
AND P6.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P6.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_TYPE_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F ='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 收单协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM(
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT(P1.MERCHANT_NO,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,'' AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,'' AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,CONCAT(SUBSTR(P1.BUSINESS_VILLAGE_CODE,1,3),'000') AS LP_ORG_NO -- 法人机构编号
    ,CONCAT(SUBSTR(P1.BUSINESS_VILLAGE_CODE,1,5),'0') AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,P2.CODE AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,P2.CODE AS BELONG_ORG_NO -- 归属机构编号
    ,'POS' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'01' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'POS' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'POS' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'01' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,P1.MERCHANT_NO AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCHANT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CASE WHEN P1.MERCHANT_SPECIES    IS NULL OR TRIM(P1.MERCHANT_SPECIES)='' 
     THEN '' 
ELSE COALESCE(TRIM(T3.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_SPECIES),'') END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'0' AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,'' AS MERCHT_PLAT_NO -- 商户平台编号
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS SERV_PROVDER_NO -- 服务商编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,'' AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,'' AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,'' AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,'' AS APP_SCENE_CD -- 应用场景代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,P1.IS_HELP_FARMER AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,NULL AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,NULL AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,NULL AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,P1.TRANSFER_A_LIMITE AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,P1.TRANSFER_DAY_LIMITE AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,P1.TRANSFER_MONTH_LIMITE AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,'' AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,'' AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,NULL AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,'' AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,'' AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,'' AS FEE_MODE_CD -- 计费模式代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN P1.SETTLEMENT_PERIOD    IS NULL OR TRIM(P1.SETTLEMENT_PERIOD)='' 
     THEN '' 
ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEMENT_PERIOD),'') END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,CASE WHEN P1.MERCHANT_STATUS     IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') END AS APP_STATUS_CD -- 申请状态代码
    ,unifiedTime(P1.APPLY_TIME) AS APP_TM_STAMP -- 申请时间戳
    ,CASE WHEN P1.PROCESS_STATUS      IS NULL OR TRIM(P1.PROCESS_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(P6.TARGET_CD_VAL), '@'||TRIM(P1.PROCESS_STATUS),'') END AS AUDIT_STATUS_CD -- 审核状态代码
    ,NULL AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,NULL AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,'' AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,CASE WHEN P1.MERCHANT_STATUS     IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(T4.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') END AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,unifiedTime(P1.FREEZE_TIME) AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,unifiedTime(P1.UNFREEZE_TIME) AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,unifiedTime(P1.UPDATE_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_ACPS_MGM_MERCHANT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_MERCHANT_TF AS P1 -- POS商户信息表

LEFT JOIN ODS_POSP${version_num}.ODS_POSP_CPAY_INSTITUTION_TF AS P2 -- 机构表
       ON P1.INST_ID = P2.ID AND P2.DEL_F= '0' AND P2.PT_DT='${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值表
       ON CAST(P1.SETTLEMENT_PERIOD as STRING)=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P3.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND P3.SRC_FIELD_EN_NAME='SETTLEMENT_PERIOD' --来源字段英文名 大写
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS T3 -- 码值表
       ON CAST(P1.MERCHANT_SPECIES as STRING)=T3.SRC_CD_VAL  
AND T3.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND T3.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND T3.SRC_FIELD_EN_NAME='MERCHANT_SPECIES' --来源字段英文名 大写
AND T3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND T3.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_TYPE_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS T4 -- 码值表
       ON CAST(P1.MERCHANT_STATUS AS STRING)=T4.SRC_CD_VAL  
AND T4.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND T4.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND T4.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND T4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND T4.TARGET_FIELD_EN_NAME='RECV_BIL_MERCHT_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值表
       ON CAST(P1.MERCHANT_STATUS AS STRING)=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P5.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND P5.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P5.TARGET_FIELD_EN_NAME='APP_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P6 -- 码值表
       ON CAST(P1.PROCESS_STATUS AS STRING)=P6.SRC_CD_VAL  
AND P6.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND P6.SRC_TAB_EN_NAME='ACPS_MGM_MERCHANT' --来源表英文名 大写
AND P6.SRC_FIELD_EN_NAME='PROCESS_STATUS' --来源字段英文名 大写
AND P6.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P6.TARGET_FIELD_EN_NAME='AUDIT_STATUS_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}'
AND P1.del_f = '0'
;
-- ==============聚合层字段映射（第4组）==============
-- 收单协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM(
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT(P1.MERNBR,'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,'' AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,'' AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.MERDEVELOPDEPTNBR AS LP_ORG_NO -- 法人机构编号
    ,'' AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,'' AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,CASE WHEN SUBSTR(P1.MERDEVELOPDEPTNBR,1,3)=SUBSTR(NVL(T3.OWONBRNO,T2.AA47BRNO),1,3) 
     THEN NVL(TRIM(T3.OWONBRNO),TRIM(T2.AA47BRNO)) 
     ELSE P1.MERDEVELOPDEPTNBR
END AS BELONG_ORG_NO -- 归属机构编号
    ,'ZF2.0' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'03' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'OPEN1' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'OPEN' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'03' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,P2.MERNBR AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P2.MERNAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CASE WHEN P2.MERTYPE IS NULL OR TRIM(P2.MERTYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(T6.TARGET_CD_VAL), '@'||TRIM(P2.MERTYPE),'')
END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,P1.ISPARENTMER AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,P1.MERPLATFORMNBR AS MERCHT_PLAT_NO -- 商户平台编号
    ,P1.SUPERMERNBR AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS SERV_PROVDER_NO -- 服务商编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,'' AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,'' AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,'' AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,'' AS APP_SCENE_CD -- 应用场景代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,'' AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,NULL AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,NULL AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,NULL AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,NULL AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,NULL AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,NULL AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,'' AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,'' AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,NULL AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,'' AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,'' AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,'' AS FEE_MODE_CD -- 计费模式代码
    , CASE WHEN P1.SETTMODE     IS NULL OR TRIM(P1.SETTMODE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.SETTMODE),'')
     END AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN P1.PAYMODECD='3' THEN  '10' 
ELSE  CASE WHEN P1.SETTPERIOD   IS NULL OR TRIM(P1.SETTPERIOD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.SETTPERIOD),'')
     END
END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,P1.FEESETTPERIOD AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS APP_STATUS_CD -- 申请状态代码
    ,NULL AS APP_TM_STAMP -- 申请时间戳
    ,'' AS AUDIT_STATUS_CD -- 审核状态代码
    ,unifiedTime(P1.MEROPENDATE) AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,NULL AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,'' AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,CASE WHEN P1.MERSTATUS IS NULL OR TRIM(P1.MERSTATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(T5.TARGET_CD_VAL), '@'||TRIM(P1.MERSTATUS),'')
END AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,NULL AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,NULL AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,unifiedTime(P1.MERMODIFYDATE) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'EPAY' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_EPAY_MERACCTINFO_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_EPAY${version_num}.ODS_EPAY_MERACCTINFO_TF AS P1 -- 商户账务信息

LEFT JOIN ODS_EPAY${version_num}.ODS_EPAY_MERBASEINFO_TF AS P2 -- 商户基本信息
       ON P1.MERNBR = P2.MERNBR 
AND P2.DEL_F= '0' 
AND P2.PT_DT='${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS T2 -- 活期存款账户主档
       ON TRIM(P1.SETTLEACCTNBR)=TRIM(T2.AA01AC15) AND T2.PT_DT='${process_date}' AND T2.DEL_F='0' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS T3 -- 借记卡信息
       ON TRIM(P1.SETTLEACCTNBR)=TRIM(T3.CDNOAC19) AND T3.PT_DT='${process_date}' AND T3.DEL_F='0' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值表
       ON P1.SETTPERIOD=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P3.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P3.SRC_FIELD_EN_NAME='SETTPERIOD' --来源字段英文名 大写
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值表
       ON P1.SETTMODE=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND P4.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND P4.SRC_FIELD_EN_NAME='SETTMODE' --来源字段英文名 大写
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_MODE_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS T5 -- 码值表
       ON P1.MERSTATUS=T5.SRC_CD_VAL  
AND T5.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND T5.SRC_TAB_EN_NAME='MERACCTINFO' --来源表英文名 大写
AND T5.SRC_FIELD_EN_NAME='MERSTATUS' --来源字段英文名 大写
AND T5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND T5.TARGET_FIELD_EN_NAME='RECV_BIL_MERCHT_STATUS_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS T6 -- 码值表
       ON P2.MERTYPE=T6.SRC_CD_VAL  
AND T6.SRC_TAB_LIB_NAME ='EPAY'  --源系统 简称或中文名 待定
AND T6.SRC_TAB_EN_NAME='MERBASEINFO' --来源表英文名 大写
AND T6.SRC_FIELD_EN_NAME='MERTYPE' --来源字段英文名 大写
AND T6.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND T6.TARGET_FIELD_EN_NAME='SPC_ARGMT_MERCHT_TYPE_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0' AND P1.isparentmer='0'
;
-- ==============聚合层字段映射（第5组）==============
-- 收单协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM(
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT(TRIM(P1.MERCHANT_ID),'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,'' AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,'' AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.COMPANY_ID AS LP_ORG_NO -- 法人机构编号
    ,'' AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,'' AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,P1.COMPANY_ID AS BELONG_ORG_NO -- 归属机构编号
    ,'ZNZF' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'OPEN3' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'OPEN' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'03' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,P1.MERCHANT_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MERCHANT_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,'5' AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'0' AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,'' AS MERCHT_PLAT_NO -- 商户平台编号
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS SERV_PROVDER_NO -- 服务商编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,'' AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,'' AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,'' AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,'' AS APP_SCENE_CD -- 应用场景代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,'' AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,NULL AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,NULL AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,NULL AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,NULL AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,NULL AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,NULL AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,'' AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,'' AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,NULL AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,'' AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,'' AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,'' AS FEE_MODE_CD -- 计费模式代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN P1.SETTLEMENT_PATTERN     IS NULL OR TRIM(P1.SETTLEMENT_PATTERN)='' 
     THEN '' 
ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLEMENT_PATTERN),'') END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS APP_STATUS_CD -- 申请状态代码
    ,NULL AS APP_TM_STAMP -- 申请时间戳
    ,'' AS AUDIT_STATUS_CD -- 审核状态代码
    ,NULL AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,NULL AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,'' AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,CASE WHEN P1.MERCHANT_STATUS IS NULL OR TRIM(P1.MERCHANT_STATUS)='' 
     THEN '' 
ELSE COALESCE(TRIM(T3.TARGET_CD_VAL), '@'||TRIM(P1.MERCHANT_STATUS),'') END AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,'' AS FRZ_RSN_REM -- 冻结原因备注
    ,NULL AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,NULL AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,'' AS INPUT_ORG_NO -- 录入机构编号
    ,unifiedTime(P1.CREATE_DATETIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,unifiedTime(P1.MODIFY_DATETIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SPS_SP_SHARED_MERCHANT_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
(SELECT * FROM(
SELECT
   COMPANY_ID
  ,MERCHANT_ID
  ,MERCHANT_NAME
  ,SETTLEMENT_PATTERN
  ,MERCHANT_STATUS
  ,CREATE_DATETIME
  ,MODIFY_DATETIME
  ,ROW_NUMBER() OVER(PARTITION BY MERCHANT_ID,MERCHANT_ID ORDER BY CREATE_DATETIME DESC) RN
FROM ODS_SPS${version_num}.ODS_SPS_SP_SHARED_MERCHANT_TF
WHERE PT_DT='${process_date}'  AND DEL_F='0'         
)WHERE RN=1) AS P1 -- 商户信息表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值表
       ON P1.SETTLEMENT_PATTERN=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='SPS'  --源系统 简称或中文名 待定
AND P2.SRC_TAB_EN_NAME='SP_SHARED_MERCHANT' --来源表英文名 大写
AND P2.SRC_FIELD_EN_NAME='SETTLEMENT_PATTERN' --来源字段英文名 大写
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS T3 -- 码值表
       ON P1.MERCHANT_STATUS =T3.SRC_CD_VAL  
AND T3.SRC_TAB_LIB_NAME ='SPS'  --源系统 简称或中文名 待定
AND T3.SRC_TAB_EN_NAME='SP_SHARED_MERCHANT' --来源表英文名 大写
AND T3.SRC_FIELD_EN_NAME='MERCHANT_STATUS' --来源字段英文名 大写
AND T3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND T3.TARGET_FIELD_EN_NAME='RECV_BIL_MERCHT_STATUS_CD' --目标字段 大写 
;
-- ==============聚合层字段映射（第6组）==============
-- 收单协议信息聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM(
     MERCHT_IDTFY_NO -- 商户识别编号
    ,RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,LP_ORG_NO -- 法人机构编号
    ,SUB_BRCH_ORG_NO -- 支行机构编号
    ,BNKOUTLS_ORG_NO -- 网点机构编号
    ,BELONG_ORG_NO -- 归属机构编号
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,MERCHT_NO -- 商户编号
    ,MERCHT_NAME -- 商户名称
    ,LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,MERCHT_PLAT_NO -- 商户平台编号
    ,SUPER_MERCHT_NO -- 上级商户编号
    ,SERV_PROVDER_NO -- 服务商编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,SERV_PROVDER_APP_ID -- 服务商APPID
    ,MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,APP_SCENE_CD -- 应用场景代码
    ,IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,FEE_MODE_CD -- 计费模式代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,REFUND_MODE_CD -- 退款模式代码
    ,COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,APP_STATUS_CD -- 申请状态代码
    ,APP_TM_STAMP -- 申请时间戳
    ,AUDIT_STATUS_CD -- 审核状态代码
    ,AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,FRZ_RSN_REM -- 冻结原因备注
    ,RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,INPUT_TELR_NO -- 录入柜员编号
    ,INPUT_ORG_NO -- 录入机构编号
    ,CREATE_TM_STAMP -- 创建时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,DT_FLG -- 数据存在标志
)
SELECT
     CONCAT(TRIM(P1.MERID),'000') AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,'' AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,'' AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,substr(p2.ORG_CODE,1,3)||'000' AS LP_ORG_NO -- 法人机构编号
    ,substr(p2.ORG_CODE,1,5)||'0' AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,p2.ORG_CODE AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,p2.ORG_CODE AS BELONG_ORG_NO -- 归属机构编号
    ,'YMT' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'01' AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,'YMT' AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,'YMT' AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,'01' AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,p2.MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,p2.MER_NAME AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,P2.MER_TYPE AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,'' AS MERCHT_NO -- 商户编号
    ,'' AS MERCHT_NAME -- 商户名称
    ,'0' AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,'' AS MERCHT_PLAT_NO -- 商户平台编号
    ,'' AS SUPER_MERCHT_NO -- 上级商户编号
    ,'' AS SERV_PROVDER_NO -- 服务商编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,'' AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,'' AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,'' AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,'' AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,'' AS APP_SCENE_CD -- 应用场景代码
    ,'' AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,'' AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,'0' AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,p1.TRADING_LIMIT AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,NULL AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,NULL AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,p1.TRADING_LIMIT AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,NULL AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,NULL AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,'' AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,'' AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,NULL AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,'' AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,'' AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,'' AS FEE_MODE_CD -- 计费模式代码
    ,'1' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN P1.SETTLE_METHOD     IS NULL OR TRIM(P1.SETTLE_METHOD)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_METHOD),'') END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,'' AS REFUND_MODE_CD -- 退款模式代码
    ,'' AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,'' AS APP_STATUS_CD -- 申请状态代码
    ,NULL AS APP_TM_STAMP -- 申请时间戳
    ,CASE WHEN P1.REVIEW_RESULT IS NULL OR TRIM(P1.REVIEW_RESULT)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.REVIEW_RESULT)),'') END AS AUDIT_STATUS_CD -- 审核状态代码
    ,unifiedTime1(P1.REVIEW_TIME) AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,unifiedTime(P1.RESERVE4) AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,'' AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,CASE WHEN P2.EWM_STATUE IS NULL OR TRIM(P2.EWM_STATUE)='' 
     THEN '' 
ELSE COALESCE(TRIM(S4.TARGET_CD_VAL), '@'||TRIM(P2.EWM_STATUE),'') END AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,'' AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,P1.CANCEL_TEXT AS FRZ_RSN_REM -- 冻结原因备注
    ,unifiedTime(P1.FREEZE_TIME) AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,unifiedTime(P1.UNFREEZE_TIME) AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,'' AS INPUT_TELR_NO -- 录入柜员编号
    ,P2.ORG_CODE AS INPUT_ORG_NO -- 录入机构编号
    ,unifiedTime(P1.CREATE_TIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'' AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,'' AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,unifiedTime(P1.UPDATE_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_ACPS_MGM_ONLINEMANYQRCODE_INFO_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
    ,'1' AS DT_FLG -- 数据存在标志
FROM
ODS_POSP${version_num}.ODS_POSP_ACPS_MGM_ONLINEMANYQRCODE_INFO_TF AS P1 -- 丰收一码通商户信息正式表

LEFT JOIN ODS_POSP${version_num}.ODS_POSP_TBL_STATIC_EWM_THREE_CODE_INFO_TF AS P2 -- 三码合一静态二维码表
       ON P2.MER_ID=P1.MERID                                                                         
        AND P2.DEL_F='0'        
        AND P2.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S2 -- 码值表
       ON P1.SETTLE_METHOD=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S2.SRC_TAB_EN_NAME='ACPS_MGM_ONLINEMANYQRCODE_INFO' --来源表英文名 大写
AND S2.SRC_FIELD_EN_NAME='SETTLE_METHOD' --来源字段英文名 大写
AND S2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND S2.TARGET_FIELD_EN_NAME='RECV_BIL_CAP_STL_PERIOD_CD' --目标字段 大写 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S3 -- 码值表
       ON P1.REVIEW_RESULT=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S3.SRC_TAB_EN_NAME='ACPS_MGM_ONLINEMANYQRCODE_INFO' --来源表英文名 大写
AND S3.SRC_FIELD_EN_NAME='REVIEW_RESULT' --来源字段英文名 大写
AND S3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND S3.TARGET_FIELD_EN_NAME='AUDIT_STATUS_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS S4 -- 码值表
       ON P2.EWM_STATUE =S4.SRC_CD_VAL  
AND S4.SRC_TAB_LIB_NAME ='POSP'  --源系统 简称或中文名 待定
AND S4.SRC_TAB_EN_NAME='TBL_STATIC_EWM_THREE_CODE_INFO' --来源表英文名 大写
AND S4.SRC_FIELD_EN_NAME='EWM_STATUE' --来源字段英文名 大写
AND S4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_AGT_INFO_TF' --目标表名 大写
AND S4.TARGET_FIELD_EN_NAME='RECV_BIL_MERCHT_STATUS_CD' --目标字段 大写 
WHERE P1.PT_DT='${process_date}'  
AND P1.DEL_F='0'
AND P1.POS_FLAG_ID<>'2'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_IDTFY_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_IDTFY_NO, BF.MERCHT_IDTFY_NO) END AS MERCHT_IDTFY_NO -- 商户识别编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SIGN_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SIGN_NO, BF.RECV_BIL_PROD_SIGN_NO) END AS RECV_BIL_PROD_SIGN_NO -- 收单产品签约编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_AUDIT_SN IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_AUDIT_SN, BF.SPC_ARGMT_MERCHT_AUDIT_SN) END AS SPC_ARGMT_MERCHT_AUDIT_SN -- 特约商户审核序列号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SIGN_SRC_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SIGN_SRC_CD, BF.RECV_BIL_PROD_SIGN_SRC_CD) END AS RECV_BIL_PROD_SIGN_SRC_CD -- 收单产品签约来源代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NO IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NO, BF.PAY_PROJ_NO) END AS PAY_PROJ_NO -- 缴费项目编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.PAY_PROJ_NAME IS NULL THEN NULL ELSE COALESCE(TM.PAY_PROJ_NAME, BF.PAY_PROJ_NAME) END AS PAY_PROJ_NAME -- 缴费项目名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LP_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.LP_ORG_NO, BF.LP_ORG_NO) END AS LP_ORG_NO -- 法人机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUB_BRCH_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.SUB_BRCH_ORG_NO, BF.SUB_BRCH_ORG_NO) END AS SUB_BRCH_ORG_NO -- 支行机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BNKOUTLS_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BNKOUTLS_ORG_NO, BF.BNKOUTLS_ORG_NO) END AS BNKOUTLS_ORG_NO -- 网点机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.BELONG_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.BELONG_ORG_NO, BF.BELONG_ORG_NO) END AS BELONG_ORG_NO -- 归属机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_NO IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_NO, BF.RECV_BIL_PROD_NO) END AS RECV_BIL_PROD_NO -- 收单产品编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_NAME IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_NAME, BF.RECV_BIL_PROD_NAME) END AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_TYPE_CD, BF.RECV_BIL_PROD_TYPE_CD) END AS RECV_BIL_PROD_TYPE_CD -- 收单产品类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SRC_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SRC_CD, BF.RECV_BIL_PROD_SRC_CD) END AS RECV_BIL_PROD_SRC_CD -- 收单产品来源代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_MCLS_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_MCLS_CD, BF.RECV_BIL_PROD_MCLS_CD) END AS RECV_BIL_PROD_MCLS_CD -- 收单产品大类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_MDL_CATOGR_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD, BF.RECV_BIL_PROD_MDL_CATOGR_CD) END AS RECV_BIL_PROD_MDL_CATOGR_CD -- 收单产品中类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_NO, BF.SPC_ARGMT_MERCHT_NO) END AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_NAME IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_NAME, BF.SPC_ARGMT_MERCHT_NAME) END AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_APP_ID IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_APP_ID, BF.SPC_ARGMT_MERCHT_APP_ID) END AS SPC_ARGMT_MERCHT_APP_ID -- 特约商户APPID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SPC_ARGMT_MERCHT_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD, BF.SPC_ARGMT_MERCHT_TYPE_CD) END AS SPC_ARGMT_MERCHT_TYPE_CD -- 特约商户类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_NO, BF.MERCHT_NO) END AS MERCHT_NO -- 商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_NAME IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_NAME, BF.MERCHT_NAME) END AS MERCHT_NAME -- 商户名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.LVL_ONE_MERCHT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.LVL_ONE_MERCHT_FLAG, BF.LVL_ONE_MERCHT_FLAG) END AS LVL_ONE_MERCHT_FLAG -- 一级商户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_PLAT_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_PLAT_NO, BF.MERCHT_PLAT_NO) END AS MERCHT_PLAT_NO -- 商户平台编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SUPER_MERCHT_NO IS NULL THEN NULL ELSE COALESCE(TM.SUPER_MERCHT_NO, BF.SUPER_MERCHT_NO) END AS SUPER_MERCHT_NO -- 上级商户编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_NO IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_NO, BF.SERV_PROVDER_NO) END AS SERV_PROVDER_NO -- 服务商编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_NAME IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_NAME, BF.SERV_PROVDER_NAME) END AS SERV_PROVDER_NAME -- 服务商名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SERV_PROVDER_APP_ID IS NULL THEN NULL ELSE COALESCE(TM.SERV_PROVDER_APP_ID, BF.SERV_PROVDER_APP_ID) END AS SERV_PROVDER_APP_ID -- 服务商APPID
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_DIGIT_WALLET_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_DIGIT_WALLET_MODE_CD, BF.MERCHT_DIGIT_WALLET_MODE_CD) END AS MERCHT_DIGIT_WALLET_MODE_CD -- 商户数字钱包模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MERCHT_DIGIT_WALLET_ID_NO IS NULL THEN NULL ELSE COALESCE(TM.MERCHT_DIGIT_WALLET_ID_NO, BF.MERCHT_DIGIT_WALLET_ID_NO) END AS MERCHT_DIGIT_WALLET_ID_NO -- 商户数字钱包ID编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DIGIT_MNTY_APP_BIZ_CATE_CD IS NULL THEN NULL ELSE COALESCE(TM.DIGIT_MNTY_APP_BIZ_CATE_CD, BF.DIGIT_MNTY_APP_BIZ_CATE_CD) END AS DIGIT_MNTY_APP_BIZ_CATE_CD -- 数字货币应用业务种类代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.DIGIT_MNTY_BIZ_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.DIGIT_MNTY_BIZ_TYPE_CD, BF.DIGIT_MNTY_BIZ_TYPE_CD) END AS DIGIT_MNTY_BIZ_TYPE_CD -- 数字货币业务类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.APP_SCENE_CD IS NULL THEN NULL ELSE COALESCE(TM.APP_SCENE_CD, BF.APP_SCENE_CD) END AS APP_SCENE_CD -- 应用场景代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.IN_BANK_SCENE_PLAT_CD IS NULL THEN NULL ELSE COALESCE(TM.IN_BANK_SCENE_PLAT_CD, BF.IN_BANK_SCENE_PLAT_CD) END AS IN_BANK_SCENE_PLAT_CD -- 行内场景平台代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.IN_BANK_SCENE_PLAT_NAME IS NULL THEN NULL ELSE COALESCE(TM.IN_BANK_SCENE_PLAT_NAME, BF.IN_BANK_SCENE_PLAT_NAME) END AS IN_BANK_SCENE_PLAT_NAME -- 行内场景平台名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.HELP_FMR_MERCHT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.HELP_FMR_MERCHT_FLAG, BF.HELP_FMR_MERCHT_FLAG) END AS HELP_FMR_MERCHT_FLAG -- 助农商户标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SINGLE_CONSM_LMT IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SINGLE_CONSM_LMT, BF.RECV_BIL_PROD_SINGLE_CONSM_LMT) END AS RECV_BIL_PROD_SINGLE_CONSM_LMT -- 收单产品单笔消费限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_DACM_CONSM_LMT IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_DACM_CONSM_LMT, BF.RECV_BIL_PROD_DACM_CONSM_LMT) END AS RECV_BIL_PROD_DACM_CONSM_LMT -- 收单产品日累计消费限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_MACM_CONSM_LMT IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_MACM_CONSM_LMT, BF.RECV_BIL_PROD_MACM_CONSM_LMT) END AS RECV_BIL_PROD_MACM_CONSM_LMT -- 收单产品月累计消费限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_SINGLE_TRAN_LMT IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_SINGLE_TRAN_LMT, BF.RECV_BIL_PROD_SINGLE_TRAN_LMT) END AS RECV_BIL_PROD_SINGLE_TRAN_LMT -- 收单产品单笔转账限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_DACM_TRAN_LMT IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_DACM_TRAN_LMT, BF.RECV_BIL_PROD_DACM_TRAN_LMT) END AS RECV_BIL_PROD_DACM_TRAN_LMT -- 收单产品日累计转账限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_MACM_TRAN_LMT IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_MACM_TRAN_LMT, BF.RECV_BIL_PROD_MACM_TRAN_LMT) END AS RECV_BIL_PROD_MACM_TRAN_LMT -- 收单产品月累计转账限额
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POINT_DEDUCT_FLAG IS NULL THEN NULL ELSE COALESCE(TM.POINT_DEDUCT_FLAG, BF.POINT_DEDUCT_FLAG) END AS POINT_DEDUCT_FLAG -- 积分抵扣标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POINT_DEDUCT_CEIL_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.POINT_DEDUCT_CEIL_MODE_CD, BF.POINT_DEDUCT_CEIL_MODE_CD) END AS POINT_DEDUCT_CEIL_MODE_CD -- 积分抵扣上限模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.POINT_DEDUCT_CEIL_VAL IS NULL THEN NULL ELSE COALESCE(TM.POINT_DEDUCT_CEIL_VAL, BF.POINT_DEDUCT_CEIL_VAL) END AS POINT_DEDUCT_CEIL_VAL -- 积分抵扣上限值
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_CUPNS_CARD_FLAG IS NULL THEN NULL ELSE COALESCE(TM.OPEN_CUPNS_CARD_FLAG, BF.OPEN_CUPNS_CARD_FLAG) END AS OPEN_CUPNS_CARD_FLAG -- 开通卡券标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.OPEN_RNDM_SUB_FLAG IS NULL THEN NULL ELSE COALESCE(TM.OPEN_RNDM_SUB_FLAG, BF.OPEN_RNDM_SUB_FLAG) END AS OPEN_RNDM_SUB_FLAG -- 开通随机立减标志
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FEE_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.FEE_MODE_CD, BF.FEE_MODE_CD) END AS FEE_MODE_CD -- 计费模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_CAP_STL_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD, BF.RECV_BIL_CAP_STL_MODE_CD) END AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_CAP_STL_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD, BF.RECV_BIL_CAP_STL_PERIOD_CD) END AS RECV_BIL_CAP_STL_PERIOD_CD -- 收单资金结算周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.REFUND_MODE_CD IS NULL THEN NULL ELSE COALESCE(TM.REFUND_MODE_CD, BF.REFUND_MODE_CD) END AS REFUND_MODE_CD -- 退款模式代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.COMM_FEE_STL_PERIOD_CD IS NULL THEN NULL ELSE COALESCE(TM.COMM_FEE_STL_PERIOD_CD, BF.COMM_FEE_STL_PERIOD_CD) END AS COMM_FEE_STL_PERIOD_CD -- 手续费结算周期代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.APP_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.APP_STATUS_CD, BF.APP_STATUS_CD) END AS APP_STATUS_CD -- 申请状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.APP_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.APP_TM_STAMP, BF.APP_TM_STAMP) END AS APP_TM_STAMP -- 申请时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUDIT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.AUDIT_STATUS_CD, BF.AUDIT_STATUS_CD) END AS AUDIT_STATUS_CD -- 审核状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.AUDIT_PASS_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.AUDIT_PASS_TM_STAMP, BF.AUDIT_PASS_TM_STAMP) END AS AUDIT_PASS_TM_STAMP -- 审核通过时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.MANY_CD_AUDIT_PASS_DT IS NULL THEN NULL ELSE COALESCE(TM.MANY_CD_AUDIT_PASS_DT, BF.MANY_CD_AUDIT_PASS_DT) END AS MANY_CD_AUDIT_PASS_DT -- 多码审核通过日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_MERCHT_SIGN_STAT_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_MERCHT_SIGN_STAT_CD, BF.RECV_BIL_MERCHT_SIGN_STAT_CD) END AS RECV_BIL_MERCHT_SIGN_STAT_CD -- 收单商户签约状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_MERCHT_STATUS_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_MERCHT_STATUS_CD, BF.RECV_BIL_MERCHT_STATUS_CD) END AS RECV_BIL_MERCHT_STATUS_CD -- 收单商户状态代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECV_BIL_PROD_FRZ_RSN_CD IS NULL THEN NULL ELSE COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD, BF.RECV_BIL_PROD_FRZ_RSN_CD) END AS RECV_BIL_PROD_FRZ_RSN_CD -- 收单产品冻结原因代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FRZ_RSN_REM IS NULL THEN NULL ELSE COALESCE(TM.FRZ_RSN_REM, BF.FRZ_RSN_REM) END AS FRZ_RSN_REM -- 冻结原因备注
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_FRZ_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.RECNT_FRZ_TM_STAMP, BF.RECNT_FRZ_TM_STAMP) END AS RECNT_FRZ_TM_STAMP -- 最近冻结时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_UNFRZ_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.RECNT_UNFRZ_TM_STAMP, BF.RECNT_UNFRZ_TM_STAMP) END AS RECNT_UNFRZ_TM_STAMP -- 最近解冻时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_TELR_NO, BF.INPUT_TELR_NO) END AS INPUT_TELR_NO -- 录入柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.INPUT_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.INPUT_ORG_NO, BF.INPUT_ORG_NO) END AS INPUT_ORG_NO -- 录入机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.CREATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.CREATE_TM_STAMP, BF.CREATE_TM_STAMP) END AS CREATE_TM_STAMP -- 创建时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TELR_NO IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TELR_NO, BF.FINAL_MODIF_TELR_NO) END AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.RECNT_MODIF_ORG_NO IS NULL THEN NULL ELSE COALESCE(TM.RECNT_MODIF_ORG_NO, BF.RECNT_MODIF_ORG_NO) END AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_MODIF_TYPE_CD IS NULL THEN NULL ELSE COALESCE(TM.FINAL_MODIF_TYPE_CD, BF.FINAL_MODIF_TYPE_CD) END AS FINAL_MODIF_TYPE_CD -- 最后修改类型代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.FINAL_UPDATE_TM_STAMP IS NULL THEN NULL ELSE COALESCE(TM.FINAL_UPDATE_TM_STAMP, BF.FINAL_UPDATE_TM_STAMP) END AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_SYS_CD IS NULL THEN NULL ELSE COALESCE(TM.SRC_SYS_CD,BF.SRC_SYS_CD) END AS SRC_SYS_CD -- 来源系统代码
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.SRC_TAB_EN_NAME IS NULL THEN NULL ELSE COALESCE(TM.SRC_TAB_EN_NAME,BF.SRC_TAB_EN_NAME) END AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND TM.GRP_SER_NO IS NULL THEN NULL ELSE COALESCE(TM.GRP_SER_NO,BF.GRP_SER_NO) END AS GRP_SER_NO -- 组序号
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN CAST(NOW() AS STRING) -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_SIGN_NO,'') = COALESCE(BF.RECV_BIL_PROD_SIGN_NO,'') -- 收单产品签约编号 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_AUDIT_SN,'') = COALESCE(BF.SPC_ARGMT_MERCHT_AUDIT_SN,'') -- 特约商户审核序列号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SIGN_SRC_CD,'') = COALESCE(BF.RECV_BIL_PROD_SIGN_SRC_CD,'') -- 收单产品签约来源代码 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NAME,'') = COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.SUB_BRCH_ORG_NO,'') = COALESCE(BF.SUB_BRCH_ORG_NO,'') -- 支行机构编号 非主键字段相等
         AND COALESCE(TM.BNKOUTLS_ORG_NO,'') = COALESCE(BF.BNKOUTLS_ORG_NO,'') -- 网点机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_NAME,'') = COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') = COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') = COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') = COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') = COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_APP_ID,'') = COALESCE(BF.SPC_ARGMT_MERCHT_APP_ID,'') -- 特约商户APPID 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段相等
         AND COALESCE(TM.MERCHT_NO,'') = COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段相等
         AND COALESCE(TM.MERCHT_NAME,'') = COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段相等
         AND COALESCE(TM.LVL_ONE_MERCHT_FLAG,'') = COALESCE(BF.LVL_ONE_MERCHT_FLAG,'') -- 一级商户标志 非主键字段相等
         AND COALESCE(TM.MERCHT_PLAT_NO,'') = COALESCE(BF.MERCHT_PLAT_NO,'') -- 商户平台编号 非主键字段相等
         AND COALESCE(TM.SUPER_MERCHT_NO,'') = COALESCE(BF.SUPER_MERCHT_NO,'') -- 上级商户编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NO,'') = COALESCE(BF.SERV_PROVDER_NO,'') -- 服务商编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NAME,'') = COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_APP_ID,'') = COALESCE(BF.SERV_PROVDER_APP_ID,'') -- 服务商APPID 非主键字段相等
         AND COALESCE(TM.MERCHT_DIGIT_WALLET_MODE_CD,'') = COALESCE(BF.MERCHT_DIGIT_WALLET_MODE_CD,'') -- 商户数字钱包模式代码 非主键字段相等
         AND COALESCE(TM.MERCHT_DIGIT_WALLET_ID_NO,'') = COALESCE(BF.MERCHT_DIGIT_WALLET_ID_NO,'') -- 商户数字钱包ID编号 非主键字段相等
         AND COALESCE(TM.DIGIT_MNTY_APP_BIZ_CATE_CD,'') = COALESCE(BF.DIGIT_MNTY_APP_BIZ_CATE_CD,'') -- 数字货币应用业务种类代码 非主键字段相等
         AND COALESCE(TM.DIGIT_MNTY_BIZ_TYPE_CD,'') = COALESCE(BF.DIGIT_MNTY_BIZ_TYPE_CD,'') -- 数字货币业务类型代码 非主键字段相等
         AND COALESCE(TM.APP_SCENE_CD,'') = COALESCE(BF.APP_SCENE_CD,'') -- 应用场景代码 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_NAME,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_NAME,'') -- 行内场景平台名称 非主键字段相等
         AND COALESCE(TM.HELP_FMR_MERCHT_FLAG,'') = COALESCE(BF.HELP_FMR_MERCHT_FLAG,'') -- 助农商户标志 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔消费限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计消费限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计消费限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔转账限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计转账限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计转账限额 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_FLAG,'') = COALESCE(BF.POINT_DEDUCT_FLAG,'') -- 积分抵扣标志 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_CEIL_MODE_CD,'') = COALESCE(BF.POINT_DEDUCT_CEIL_MODE_CD,'') -- 积分抵扣上限模式代码 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) -- 积分抵扣上限值 非主键字段相等
         AND COALESCE(TM.OPEN_CUPNS_CARD_FLAG,'') = COALESCE(BF.OPEN_CUPNS_CARD_FLAG,'') -- 开通卡券标志 非主键字段相等
         AND COALESCE(TM.OPEN_RNDM_SUB_FLAG,'') = COALESCE(BF.OPEN_RNDM_SUB_FLAG,'') -- 开通随机立减标志 非主键字段相等
         AND COALESCE(TM.FEE_MODE_CD,'') = COALESCE(BF.FEE_MODE_CD,'') -- 计费模式代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段相等
         AND COALESCE(TM.REFUND_MODE_CD,'') = COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段相等
         AND COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') = COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段相等
         AND COALESCE(TM.APP_STATUS_CD,'') = COALESCE(BF.APP_STATUS_CD,'') -- 申请状态代码 非主键字段相等
         AND COALESCE(TM.APP_TM_STAMP,'') = COALESCE(BF.APP_TM_STAMP,'') -- 申请时间戳 非主键字段相等
         AND COALESCE(TM.AUDIT_STATUS_CD,'') = COALESCE(BF.AUDIT_STATUS_CD,'') -- 审核状态代码 非主键字段相等
         AND COALESCE(TM.AUDIT_PASS_TM_STAMP,'') = COALESCE(BF.AUDIT_PASS_TM_STAMP,'') -- 审核通过时间戳 非主键字段相等
         AND COALESCE(TM.MANY_CD_AUDIT_PASS_DT,'') = COALESCE(BF.MANY_CD_AUDIT_PASS_DT,'') -- 多码审核通过日期 非主键字段相等
         AND COALESCE(TM.RECV_BIL_MERCHT_SIGN_STAT_CD,'') = COALESCE(BF.RECV_BIL_MERCHT_SIGN_STAT_CD,'') -- 收单商户签约状态代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_MERCHT_STATUS_CD,'') = COALESCE(BF.RECV_BIL_MERCHT_STATUS_CD,'') -- 收单商户状态代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') = COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段相等
         AND COALESCE(TM.FRZ_RSN_REM,'') = COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段相等
         AND COALESCE(TM.RECNT_FRZ_TM_STAMP,'') = COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') = COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段相等
         AND COALESCE(TM.INPUT_TELR_NO,'') = COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段相等
         AND COALESCE(TM.INPUT_ORG_NO,'') = COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段相等
         AND COALESCE(TM.CREATE_TM_STAMP,'') = COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TYPE_CD,'') = COALESCE(BF.FINAL_MODIF_TYPE_CD,'') -- 最后修改类型代码 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         ) THEN BF.ETL_TIMESTAMP -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_SIGN_NO,'') <> COALESCE(BF.RECV_BIL_PROD_SIGN_NO,'') -- 收单产品签约编号 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_AUDIT_SN,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_AUDIT_SN,'') -- 特约商户审核序列号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SIGN_SRC_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SIGN_SRC_CD,'') -- 收单产品签约来源代码 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NAME,'') <> COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.SUB_BRCH_ORG_NO,'') <> COALESCE(BF.SUB_BRCH_ORG_NO,'') -- 支行机构编号 非主键字段不相等
         OR COALESCE(TM.BNKOUTLS_ORG_NO,'') <> COALESCE(BF.BNKOUTLS_ORG_NO,'') -- 网点机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_NAME,'') <> COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') <> COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_APP_ID,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_APP_ID,'') -- 特约商户APPID 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段不相等
         OR COALESCE(TM.MERCHT_NO,'') <> COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_NAME,'') <> COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段不相等
         OR COALESCE(TM.LVL_ONE_MERCHT_FLAG,'') <> COALESCE(BF.LVL_ONE_MERCHT_FLAG,'') -- 一级商户标志 非主键字段不相等
         OR COALESCE(TM.MERCHT_PLAT_NO,'') <> COALESCE(BF.MERCHT_PLAT_NO,'') -- 商户平台编号 非主键字段不相等
         OR COALESCE(TM.SUPER_MERCHT_NO,'') <> COALESCE(BF.SUPER_MERCHT_NO,'') -- 上级商户编号 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_NO,'') <> COALESCE(BF.SERV_PROVDER_NO,'') -- 服务商编号 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_NAME,'') <> COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_APP_ID,'') <> COALESCE(BF.SERV_PROVDER_APP_ID,'') -- 服务商APPID 非主键字段不相等
         OR COALESCE(TM.MERCHT_DIGIT_WALLET_MODE_CD,'') <> COALESCE(BF.MERCHT_DIGIT_WALLET_MODE_CD,'') -- 商户数字钱包模式代码 非主键字段不相等
         OR COALESCE(TM.MERCHT_DIGIT_WALLET_ID_NO,'') <> COALESCE(BF.MERCHT_DIGIT_WALLET_ID_NO,'') -- 商户数字钱包ID编号 非主键字段不相等
         OR COALESCE(TM.DIGIT_MNTY_APP_BIZ_CATE_CD,'') <> COALESCE(BF.DIGIT_MNTY_APP_BIZ_CATE_CD,'') -- 数字货币应用业务种类代码 非主键字段不相等
         OR COALESCE(TM.DIGIT_MNTY_BIZ_TYPE_CD,'') <> COALESCE(BF.DIGIT_MNTY_BIZ_TYPE_CD,'') -- 数字货币业务类型代码 非主键字段不相等
         OR COALESCE(TM.APP_SCENE_CD,'') <> COALESCE(BF.APP_SCENE_CD,'') -- 应用场景代码 非主键字段不相等
         OR COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') <> COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段不相等
         OR COALESCE(TM.IN_BANK_SCENE_PLAT_NAME,'') <> COALESCE(BF.IN_BANK_SCENE_PLAT_NAME,'') -- 行内场景平台名称 非主键字段不相等
         OR COALESCE(TM.HELP_FMR_MERCHT_FLAG,'') <> COALESCE(BF.HELP_FMR_MERCHT_FLAG,'') -- 助农商户标志 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔消费限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计消费限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计消费限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔转账限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计转账限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计转账限额 非主键字段不相等
         OR COALESCE(TM.POINT_DEDUCT_FLAG,'') <> COALESCE(BF.POINT_DEDUCT_FLAG,'') -- 积分抵扣标志 非主键字段不相等
         OR COALESCE(TM.POINT_DEDUCT_CEIL_MODE_CD,'') <> COALESCE(BF.POINT_DEDUCT_CEIL_MODE_CD,'') -- 积分抵扣上限模式代码 非主键字段不相等
         OR COALESCE(TM.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) -- 积分抵扣上限值 非主键字段不相等
         OR COALESCE(TM.OPEN_CUPNS_CARD_FLAG,'') <> COALESCE(BF.OPEN_CUPNS_CARD_FLAG,'') -- 开通卡券标志 非主键字段不相等
         OR COALESCE(TM.OPEN_RNDM_SUB_FLAG,'') <> COALESCE(BF.OPEN_RNDM_SUB_FLAG,'') -- 开通随机立减标志 非主键字段不相等
         OR COALESCE(TM.FEE_MODE_CD,'') <> COALESCE(BF.FEE_MODE_CD,'') -- 计费模式代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段不相等
         OR COALESCE(TM.REFUND_MODE_CD,'') <> COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') <> COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段不相等
         OR COALESCE(TM.APP_STATUS_CD,'') <> COALESCE(BF.APP_STATUS_CD,'') -- 申请状态代码 非主键字段不相等
         OR COALESCE(TM.APP_TM_STAMP,'') <> COALESCE(BF.APP_TM_STAMP,'') -- 申请时间戳 非主键字段不相等
         OR COALESCE(TM.AUDIT_STATUS_CD,'') <> COALESCE(BF.AUDIT_STATUS_CD,'') -- 审核状态代码 非主键字段不相等
         OR COALESCE(TM.AUDIT_PASS_TM_STAMP,'') <> COALESCE(BF.AUDIT_PASS_TM_STAMP,'') -- 审核通过时间戳 非主键字段不相等
         OR COALESCE(TM.MANY_CD_AUDIT_PASS_DT,'') <> COALESCE(BF.MANY_CD_AUDIT_PASS_DT,'') -- 多码审核通过日期 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_MERCHT_SIGN_STAT_CD,'') <> COALESCE(BF.RECV_BIL_MERCHT_SIGN_STAT_CD,'') -- 收单商户签约状态代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_MERCHT_STATUS_CD,'') <> COALESCE(BF.RECV_BIL_MERCHT_STATUS_CD,'') -- 收单商户状态代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') <> COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段不相等
         OR COALESCE(TM.FRZ_RSN_REM,'') <> COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段不相等
         OR COALESCE(TM.RECNT_FRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段不相等
         OR COALESCE(TM.INPUT_TELR_NO,'') <> COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段不相等
         OR COALESCE(TM.INPUT_ORG_NO,'') <> COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段不相等
         OR COALESCE(TM.CREATE_TM_STAMP,'') <> COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TYPE_CD,'') <> COALESCE(BF.FINAL_MODIF_TYPE_CD,'') -- 最后修改类型代码 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         ) THEN CAST(NOW() AS STRING) -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_TIMESTAMP
     ELSE BF.ETL_TIMESTAMP END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_TIMESTAMP
     AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NOT NULL THEN BF.ETL_CREATE_DT -- 旧表有数，继承ETL_CREATE_DT
     ELSE '${process_date}' -- 旧表无对应数据，更新ETL_CREATE_DT
     END AS ETL_CREATE_DT -- ETL创建日期
    ,CASE WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上，新表有数，旧表无对应数据，取新表数据，更新ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_SIGN_NO,'') = COALESCE(BF.RECV_BIL_PROD_SIGN_NO,'') -- 收单产品签约编号 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_AUDIT_SN,'') = COALESCE(BF.SPC_ARGMT_MERCHT_AUDIT_SN,'') -- 特约商户审核序列号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SIGN_SRC_CD,'') = COALESCE(BF.RECV_BIL_PROD_SIGN_SRC_CD,'') -- 收单产品签约来源代码 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NO,'') = COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段相等
         AND COALESCE(TM.PAY_PROJ_NAME,'') = COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段相等
         AND COALESCE(TM.LP_ORG_NO,'') = COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段相等
         AND COALESCE(TM.SUB_BRCH_ORG_NO,'') = COALESCE(BF.SUB_BRCH_ORG_NO,'') -- 支行机构编号 非主键字段相等
         AND COALESCE(TM.BNKOUTLS_ORG_NO,'') = COALESCE(BF.BNKOUTLS_ORG_NO,'') -- 网点机构编号 非主键字段相等
         AND COALESCE(TM.BELONG_ORG_NO,'') = COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_NAME,'') = COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') = COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') = COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') = COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') = COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_APP_ID,'') = COALESCE(BF.SPC_ARGMT_MERCHT_APP_ID,'') -- 特约商户APPID 非主键字段相等
         AND COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') = COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段相等
         AND COALESCE(TM.MERCHT_NO,'') = COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段相等
         AND COALESCE(TM.MERCHT_NAME,'') = COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段相等
         AND COALESCE(TM.LVL_ONE_MERCHT_FLAG,'') = COALESCE(BF.LVL_ONE_MERCHT_FLAG,'') -- 一级商户标志 非主键字段相等
         AND COALESCE(TM.MERCHT_PLAT_NO,'') = COALESCE(BF.MERCHT_PLAT_NO,'') -- 商户平台编号 非主键字段相等
         AND COALESCE(TM.SUPER_MERCHT_NO,'') = COALESCE(BF.SUPER_MERCHT_NO,'') -- 上级商户编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NO,'') = COALESCE(BF.SERV_PROVDER_NO,'') -- 服务商编号 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_NAME,'') = COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段相等
         AND COALESCE(TM.SERV_PROVDER_APP_ID,'') = COALESCE(BF.SERV_PROVDER_APP_ID,'') -- 服务商APPID 非主键字段相等
         AND COALESCE(TM.MERCHT_DIGIT_WALLET_MODE_CD,'') = COALESCE(BF.MERCHT_DIGIT_WALLET_MODE_CD,'') -- 商户数字钱包模式代码 非主键字段相等
         AND COALESCE(TM.MERCHT_DIGIT_WALLET_ID_NO,'') = COALESCE(BF.MERCHT_DIGIT_WALLET_ID_NO,'') -- 商户数字钱包ID编号 非主键字段相等
         AND COALESCE(TM.DIGIT_MNTY_APP_BIZ_CATE_CD,'') = COALESCE(BF.DIGIT_MNTY_APP_BIZ_CATE_CD,'') -- 数字货币应用业务种类代码 非主键字段相等
         AND COALESCE(TM.DIGIT_MNTY_BIZ_TYPE_CD,'') = COALESCE(BF.DIGIT_MNTY_BIZ_TYPE_CD,'') -- 数字货币业务类型代码 非主键字段相等
         AND COALESCE(TM.APP_SCENE_CD,'') = COALESCE(BF.APP_SCENE_CD,'') -- 应用场景代码 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段相等
         AND COALESCE(TM.IN_BANK_SCENE_PLAT_NAME,'') = COALESCE(BF.IN_BANK_SCENE_PLAT_NAME,'') -- 行内场景平台名称 非主键字段相等
         AND COALESCE(TM.HELP_FMR_MERCHT_FLAG,'') = COALESCE(BF.HELP_FMR_MERCHT_FLAG,'') -- 助农商户标志 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔消费限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计消费限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计消费限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔转账限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计转账限额 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计转账限额 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_FLAG,'') = COALESCE(BF.POINT_DEDUCT_FLAG,'') -- 积分抵扣标志 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_CEIL_MODE_CD,'') = COALESCE(BF.POINT_DEDUCT_CEIL_MODE_CD,'') -- 积分抵扣上限模式代码 非主键字段相等
         AND COALESCE(TM.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) -- 积分抵扣上限值 非主键字段相等
         AND COALESCE(TM.OPEN_CUPNS_CARD_FLAG,'') = COALESCE(BF.OPEN_CUPNS_CARD_FLAG,'') -- 开通卡券标志 非主键字段相等
         AND COALESCE(TM.OPEN_RNDM_SUB_FLAG,'') = COALESCE(BF.OPEN_RNDM_SUB_FLAG,'') -- 开通随机立减标志 非主键字段相等
         AND COALESCE(TM.FEE_MODE_CD,'') = COALESCE(BF.FEE_MODE_CD,'') -- 计费模式代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') = COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段相等
         AND COALESCE(TM.REFUND_MODE_CD,'') = COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段相等
         AND COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') = COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段相等
         AND COALESCE(TM.APP_STATUS_CD,'') = COALESCE(BF.APP_STATUS_CD,'') -- 申请状态代码 非主键字段相等
         AND COALESCE(TM.APP_TM_STAMP,'') = COALESCE(BF.APP_TM_STAMP,'') -- 申请时间戳 非主键字段相等
         AND COALESCE(TM.AUDIT_STATUS_CD,'') = COALESCE(BF.AUDIT_STATUS_CD,'') -- 审核状态代码 非主键字段相等
         AND COALESCE(TM.AUDIT_PASS_TM_STAMP,'') = COALESCE(BF.AUDIT_PASS_TM_STAMP,'') -- 审核通过时间戳 非主键字段相等
         AND COALESCE(TM.MANY_CD_AUDIT_PASS_DT,'') = COALESCE(BF.MANY_CD_AUDIT_PASS_DT,'') -- 多码审核通过日期 非主键字段相等
         AND COALESCE(TM.RECV_BIL_MERCHT_SIGN_STAT_CD,'') = COALESCE(BF.RECV_BIL_MERCHT_SIGN_STAT_CD,'') -- 收单商户签约状态代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_MERCHT_STATUS_CD,'') = COALESCE(BF.RECV_BIL_MERCHT_STATUS_CD,'') -- 收单商户状态代码 非主键字段相等
         AND COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') = COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段相等
         AND COALESCE(TM.FRZ_RSN_REM,'') = COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段相等
         AND COALESCE(TM.RECNT_FRZ_TM_STAMP,'') = COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段相等
         AND COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') = COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段相等
         AND COALESCE(TM.INPUT_TELR_NO,'') = COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段相等
         AND COALESCE(TM.INPUT_ORG_NO,'') = COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段相等
         AND COALESCE(TM.CREATE_TM_STAMP,'') = COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TELR_NO,'') = COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段相等
         AND COALESCE(TM.RECNT_MODIF_ORG_NO,'') = COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TYPE_CD,'') = COALESCE(BF.FINAL_MODIF_TYPE_CD,'') -- 最后修改类型代码 非主键字段相等
         AND COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') = COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化，新表有数，旧表有数，取旧表数据，继承ETL_LAST_ACG_DT
     WHEN TM.DT_FLG IS NOT NULL AND BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.RECV_BIL_PROD_SIGN_NO,'') <> COALESCE(BF.RECV_BIL_PROD_SIGN_NO,'') -- 收单产品签约编号 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_AUDIT_SN,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_AUDIT_SN,'') -- 特约商户审核序列号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SIGN_SRC_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SIGN_SRC_CD,'') -- 收单产品签约来源代码 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NO,'') <> COALESCE(BF.PAY_PROJ_NO,'') -- 缴费项目编号 非主键字段不相等
         OR COALESCE(TM.PAY_PROJ_NAME,'') <> COALESCE(BF.PAY_PROJ_NAME,'') -- 缴费项目名称 非主键字段不相等
         OR COALESCE(TM.LP_ORG_NO,'') <> COALESCE(BF.LP_ORG_NO,'') -- 法人机构编号 非主键字段不相等
         OR COALESCE(TM.SUB_BRCH_ORG_NO,'') <> COALESCE(BF.SUB_BRCH_ORG_NO,'') -- 支行机构编号 非主键字段不相等
         OR COALESCE(TM.BNKOUTLS_ORG_NO,'') <> COALESCE(BF.BNKOUTLS_ORG_NO,'') -- 网点机构编号 非主键字段不相等
         OR COALESCE(TM.BELONG_ORG_NO,'') <> COALESCE(BF.BELONG_ORG_NO,'') -- 归属机构编号 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_NAME,'') <> COALESCE(BF.RECV_BIL_PROD_NAME,'') -- 收单产品名称 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_TYPE_CD,'') <> COALESCE(BF.RECV_BIL_PROD_TYPE_CD,'') -- 收单产品类型代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SRC_CD,'') <> COALESCE(BF.RECV_BIL_PROD_SRC_CD,'') -- 收单产品来源代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MCLS_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MCLS_CD,'') -- 收单产品大类代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MDL_CATOGR_CD,'') <> COALESCE(BF.RECV_BIL_PROD_MDL_CATOGR_CD,'') -- 收单产品中类代码 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_NAME,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_NAME,'') -- 特约商户名称 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_APP_ID,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_APP_ID,'') -- 特约商户APPID 非主键字段不相等
         OR COALESCE(TM.SPC_ARGMT_MERCHT_TYPE_CD,'') <> COALESCE(BF.SPC_ARGMT_MERCHT_TYPE_CD,'') -- 特约商户类型代码 非主键字段不相等
         OR COALESCE(TM.MERCHT_NO,'') <> COALESCE(BF.MERCHT_NO,'') -- 商户编号 非主键字段不相等
         OR COALESCE(TM.MERCHT_NAME,'') <> COALESCE(BF.MERCHT_NAME,'') -- 商户名称 非主键字段不相等
         OR COALESCE(TM.LVL_ONE_MERCHT_FLAG,'') <> COALESCE(BF.LVL_ONE_MERCHT_FLAG,'') -- 一级商户标志 非主键字段不相等
         OR COALESCE(TM.MERCHT_PLAT_NO,'') <> COALESCE(BF.MERCHT_PLAT_NO,'') -- 商户平台编号 非主键字段不相等
         OR COALESCE(TM.SUPER_MERCHT_NO,'') <> COALESCE(BF.SUPER_MERCHT_NO,'') -- 上级商户编号 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_NO,'') <> COALESCE(BF.SERV_PROVDER_NO,'') -- 服务商编号 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_NAME,'') <> COALESCE(BF.SERV_PROVDER_NAME,'') -- 服务商名称 非主键字段不相等
         OR COALESCE(TM.SERV_PROVDER_APP_ID,'') <> COALESCE(BF.SERV_PROVDER_APP_ID,'') -- 服务商APPID 非主键字段不相等
         OR COALESCE(TM.MERCHT_DIGIT_WALLET_MODE_CD,'') <> COALESCE(BF.MERCHT_DIGIT_WALLET_MODE_CD,'') -- 商户数字钱包模式代码 非主键字段不相等
         OR COALESCE(TM.MERCHT_DIGIT_WALLET_ID_NO,'') <> COALESCE(BF.MERCHT_DIGIT_WALLET_ID_NO,'') -- 商户数字钱包ID编号 非主键字段不相等
         OR COALESCE(TM.DIGIT_MNTY_APP_BIZ_CATE_CD,'') <> COALESCE(BF.DIGIT_MNTY_APP_BIZ_CATE_CD,'') -- 数字货币应用业务种类代码 非主键字段不相等
         OR COALESCE(TM.DIGIT_MNTY_BIZ_TYPE_CD,'') <> COALESCE(BF.DIGIT_MNTY_BIZ_TYPE_CD,'') -- 数字货币业务类型代码 非主键字段不相等
         OR COALESCE(TM.APP_SCENE_CD,'') <> COALESCE(BF.APP_SCENE_CD,'') -- 应用场景代码 非主键字段不相等
         OR COALESCE(TM.IN_BANK_SCENE_PLAT_CD,'') <> COALESCE(BF.IN_BANK_SCENE_PLAT_CD,'') -- 行内场景平台代码 非主键字段不相等
         OR COALESCE(TM.IN_BANK_SCENE_PLAT_NAME,'') <> COALESCE(BF.IN_BANK_SCENE_PLAT_NAME,'') -- 行内场景平台名称 非主键字段不相等
         OR COALESCE(TM.HELP_FMR_MERCHT_FLAG,'') <> COALESCE(BF.HELP_FMR_MERCHT_FLAG,'') -- 助农商户标志 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_SINGLE_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔消费限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_DACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计消费限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_MACM_CONSM_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计消费限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_SINGLE_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品单笔转账限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_DACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品日累计转账限额 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.RECV_BIL_PROD_MACM_TRAN_LMT,CAST(0 AS DECIMAL(28,2))) -- 收单产品月累计转账限额 非主键字段不相等
         OR COALESCE(TM.POINT_DEDUCT_FLAG,'') <> COALESCE(BF.POINT_DEDUCT_FLAG,'') -- 积分抵扣标志 非主键字段不相等
         OR COALESCE(TM.POINT_DEDUCT_CEIL_MODE_CD,'') <> COALESCE(BF.POINT_DEDUCT_CEIL_MODE_CD,'') -- 积分抵扣上限模式代码 非主键字段不相等
         OR COALESCE(TM.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) <> COALESCE(BF.POINT_DEDUCT_CEIL_VAL,CAST(0 AS DECIMAL(28,2))) -- 积分抵扣上限值 非主键字段不相等
         OR COALESCE(TM.OPEN_CUPNS_CARD_FLAG,'') <> COALESCE(BF.OPEN_CUPNS_CARD_FLAG,'') -- 开通卡券标志 非主键字段不相等
         OR COALESCE(TM.OPEN_RNDM_SUB_FLAG,'') <> COALESCE(BF.OPEN_RNDM_SUB_FLAG,'') -- 开通随机立减标志 非主键字段不相等
         OR COALESCE(TM.FEE_MODE_CD,'') <> COALESCE(BF.FEE_MODE_CD,'') -- 计费模式代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_MODE_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_MODE_CD,'') -- 收单资金结算模式代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_CAP_STL_PERIOD_CD,'') <> COALESCE(BF.RECV_BIL_CAP_STL_PERIOD_CD,'') -- 收单资金结算周期代码 非主键字段不相等
         OR COALESCE(TM.REFUND_MODE_CD,'') <> COALESCE(BF.REFUND_MODE_CD,'') -- 退款模式代码 非主键字段不相等
         OR COALESCE(TM.COMM_FEE_STL_PERIOD_CD,'') <> COALESCE(BF.COMM_FEE_STL_PERIOD_CD,'') -- 手续费结算周期代码 非主键字段不相等
         OR COALESCE(TM.APP_STATUS_CD,'') <> COALESCE(BF.APP_STATUS_CD,'') -- 申请状态代码 非主键字段不相等
         OR COALESCE(TM.APP_TM_STAMP,'') <> COALESCE(BF.APP_TM_STAMP,'') -- 申请时间戳 非主键字段不相等
         OR COALESCE(TM.AUDIT_STATUS_CD,'') <> COALESCE(BF.AUDIT_STATUS_CD,'') -- 审核状态代码 非主键字段不相等
         OR COALESCE(TM.AUDIT_PASS_TM_STAMP,'') <> COALESCE(BF.AUDIT_PASS_TM_STAMP,'') -- 审核通过时间戳 非主键字段不相等
         OR COALESCE(TM.MANY_CD_AUDIT_PASS_DT,'') <> COALESCE(BF.MANY_CD_AUDIT_PASS_DT,'') -- 多码审核通过日期 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_MERCHT_SIGN_STAT_CD,'') <> COALESCE(BF.RECV_BIL_MERCHT_SIGN_STAT_CD,'') -- 收单商户签约状态代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_MERCHT_STATUS_CD,'') <> COALESCE(BF.RECV_BIL_MERCHT_STATUS_CD,'') -- 收单商户状态代码 非主键字段不相等
         OR COALESCE(TM.RECV_BIL_PROD_FRZ_RSN_CD,'') <> COALESCE(BF.RECV_BIL_PROD_FRZ_RSN_CD,'') -- 收单产品冻结原因代码 非主键字段不相等
         OR COALESCE(TM.FRZ_RSN_REM,'') <> COALESCE(BF.FRZ_RSN_REM,'') -- 冻结原因备注 非主键字段不相等
         OR COALESCE(TM.RECNT_FRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_FRZ_TM_STAMP,'') -- 最近冻结时间戳 非主键字段不相等
         OR COALESCE(TM.RECNT_UNFRZ_TM_STAMP,'') <> COALESCE(BF.RECNT_UNFRZ_TM_STAMP,'') -- 最近解冻时间戳 非主键字段不相等
         OR COALESCE(TM.INPUT_TELR_NO,'') <> COALESCE(BF.INPUT_TELR_NO,'') -- 录入柜员编号 非主键字段不相等
         OR COALESCE(TM.INPUT_ORG_NO,'') <> COALESCE(BF.INPUT_ORG_NO,'') -- 录入机构编号 非主键字段不相等
         OR COALESCE(TM.CREATE_TM_STAMP,'') <> COALESCE(BF.CREATE_TM_STAMP,'') -- 创建时间戳 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TELR_NO,'') <> COALESCE(BF.FINAL_MODIF_TELR_NO,'') -- 最后修改柜员编号 非主键字段不相等
         OR COALESCE(TM.RECNT_MODIF_ORG_NO,'') <> COALESCE(BF.RECNT_MODIF_ORG_NO,'') -- 最后修改机构编号 非主键字段不相等
         OR COALESCE(TM.FINAL_MODIF_TYPE_CD,'') <> COALESCE(BF.FINAL_MODIF_TYPE_CD,'') -- 最后修改类型代码 非主键字段不相等
         OR COALESCE(TM.FINAL_UPDATE_TM_STAMP,'') <> COALESCE(BF.FINAL_UPDATE_TM_STAMP,'') -- 最后修改时间戳 非主键字段不相等
         ) THEN '${process_date}' -- 新旧数据可以关联上且数据有变化，新表有数，旧表有数，取新表数据，更新ETL_LAST_ACG_DT
     ELSE BF.ETL_LAST_ACG_DT END -- TM.DT_FLG IS NULL AND BF.PT_DT IS NOT NULL，新旧数据关联不上，新表无对应数据，旧表有数，取旧表数据，继承ETL_CREATE_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,CASE WHEN TM.DT_FLG IS NULL THEN '2'
     ELSE '0' END AS DEL_F -- 删除标志
FROM AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM TM
FULL OUTER JOIN (SELECT * FROM AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF WHERE PT_DT = CAST(TO_DATE('${process_date}','yyyy-MM-dd') - 1 AS STRING)) BF
ON (
     COALESCE(TM.MERCHT_IDTFY_NO,'') = COALESCE(BF.MERCHT_IDTFY_NO,'') -- 商户识别编号 主键字段关联
    AND COALESCE(TM.RECV_BIL_PROD_NO,'') = COALESCE(BF.RECV_BIL_PROD_NO,'') -- 收单产品编号 主键字段关联
    AND COALESCE(TM.SPC_ARGMT_MERCHT_NO,'') = COALESCE(BF.SPC_ARGMT_MERCHT_NO,'') -- 特约商户编号 主键字段关联
    )
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_RECV_BIL_AGT_INFO_TF_TM;
