-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-联社公共签约表02
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_T_SIGN_XXX_02_TF
--     表中文名：联社公共签约表02
--     创建日期：2024-04-15 00:00:00
--     主键字段：
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改中间业务库名，增加95组
--         2024-09-10 00:00:00 魏丹丹 新增字段：摘要代码，修改客户内码/签约账户开户机构编号 的取数逻辑，增加1组
--         2024-10-17 00:00:00 魏丹丹 拆分生活缴费签约协议信息聚合 中T_SIGN_XXX，已8开始871-897，已6开始632-682



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_T_SIGN_XXX_02_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM
USING ORC
COMMENT '联社公共签约表02-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_T_SIGN_XXX_02_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_871_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_871_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_29组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_872_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_872_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_30组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_873_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_873_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_31组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_875_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_875_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_31组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_875_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_875_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_32组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_876_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_876_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_33组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_877_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_877_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_34组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_881_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_881_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_35组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_882_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_882_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_36组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_883_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_883_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_37组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_885_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_885_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_38组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_886_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_886_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_39组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_891_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_891_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_40组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_892_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_892_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_41组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_893_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_893_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_42组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_895_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_895_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_43组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_896_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_896_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_44组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_897_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_897_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_81组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_632_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_632_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_82组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_635_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_635_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_83组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_636_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_636_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_84组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_637_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_637_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_85组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_SIGN_638_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP.ODS_OEHCP_T_SIGN_638_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_86组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_650_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_650_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_87组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_651_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_651_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_88组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_653_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_653_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_89组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_661_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_661_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_90组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_665_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_665_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_91组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_674_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_674_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_92组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_677_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_677_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_93组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_681_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_681_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3_94组）==============
-- 联社公共签约表02

INSERT INTO TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM(
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.CUST_NO AS CUST_NO -- 客户编号
    ,P1.CONTRACT AS CONTRACT -- 合同编号
    ,P1.ENTR_NO AS ENTR_NO -- 单位编号
    ,P1.USER_ID AS USER_ID -- 用户编号
    ,P1.USER_NAME AS USER_NAME -- 用户姓名
    ,P1.CERT_TYPE AS CERT_TYPE -- 证件种类
    ,P1.CERT_ID AS CERT_ID -- 证件号码
    ,P1.TELEPHONE AS TELEPHONE -- 电话号码
    ,P1.ADDRESS AS ADDRESS -- 地址
    ,P1.ACCT_TYPE AS ACCT_TYPE -- 账户性质
    ,P1.CARD_TYPE AS CARD_TYPE -- 卡折标志
    ,P1.ACCT_NO AS ACCT_NO -- 账号
    ,P1.STAT AS STAT -- 状态
    ,P1.CURR_NO AS CURR_NO -- 币种
    ,P1.CURR_IDEN AS CURR_IDEN -- 钞汇鉴别
    ,P1.ACT_NAME AS ACT_NAME -- 账户户名
    ,P1.CARD_NO AS CARD_NO -- 卡号
    ,P1.OPEN_BRCH AS OPEN_BRCH -- 开户机构
    ,P1.SIGN_DATE AS SIGN_DATE -- 签约日期
    ,P1.SIGN_TIME AS SIGN_TIME -- 签约时间
    ,P1.SIGN_BRCH_NO AS SIGN_BRCH_NO -- 签约机构
    ,P1.SIGN_TELLER_NO AS SIGN_TELLER_NO -- 签约柜员
    ,P1.UPT_DATE AS UPT_DATE -- 最后修改日期
    ,P1.UPT_TIME AS UPT_TIME -- 最后修改时间
    ,P1.UPT_BRCH_NO AS UPT_BRCH_NO -- 最后修改机构
    ,P1.UPT_TELLER_NO AS UPT_TELLER_NO -- 最后修改柜员
    ,P1.TALLY_ORDER AS TALLY_ORDER -- 顺序
    ,P1.RMRK AS RMRK -- 备注
    ,P1.OLD_ACCT_NO AS OLD_ACCT_NO -- 旧帐号
    ,P1.PLAT_DATE AS PLAT_DATE -- 平台日期
    ,'OSCIP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OSCIP_T_SIGN_682_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_OSCIP.ODS_OSCIP_T_SIGN_682_TF AS P1 -- 联社公共签约表02

WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_T_SIGN_XXX_02_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_T_SIGN_XXX_02_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_T_SIGN_XXX_02_TF PARTITION(PT_DT = '${process_date}')
SELECT
     CUST_NO -- 客户编号
    ,CONTRACT -- 合同编号
    ,ENTR_NO -- 单位编号
    ,USER_ID -- 用户编号
    ,USER_NAME -- 用户姓名
    ,CERT_TYPE -- 证件种类
    ,CERT_ID -- 证件号码
    ,TELEPHONE -- 电话号码
    ,ADDRESS -- 地址
    ,ACCT_TYPE -- 账户性质
    ,CARD_TYPE -- 卡折标志
    ,ACCT_NO -- 账号
    ,STAT -- 状态
    ,CURR_NO -- 币种
    ,CURR_IDEN -- 钞汇鉴别
    ,ACT_NAME -- 账户户名
    ,CARD_NO -- 卡号
    ,OPEN_BRCH -- 开户机构
    ,SIGN_DATE -- 签约日期
    ,SIGN_TIME -- 签约时间
    ,SIGN_BRCH_NO -- 签约机构
    ,SIGN_TELLER_NO -- 签约柜员
    ,UPT_DATE -- 最后修改日期
    ,UPT_TIME -- 最后修改时间
    ,UPT_BRCH_NO -- 最后修改机构
    ,UPT_TELLER_NO -- 最后修改柜员
    ,TALLY_ORDER -- 顺序
    ,RMRK -- 备注
    ,OLD_ACCT_NO -- 旧帐号
    ,PLAT_DATE -- 平台日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_T_SIGN_XXX_02_TF_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_T_SIGN_XXX_02_TF_TM;
