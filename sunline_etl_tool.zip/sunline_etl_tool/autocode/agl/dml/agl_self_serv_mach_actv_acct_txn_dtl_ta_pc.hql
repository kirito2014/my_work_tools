-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-自助机具动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA
--     表中文名：自助机具动账交易明细聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：BIZ_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-02-26 00:00:00 魏丹丹 新增
--         2024-08-20 00:00:00 魏丹丹 新增
--         2024-09-08 00:00:00 魏丹丹 新增字段，新增表
--         2024-10-16 00:00:00 魏丹丹 2024/9/20新增表市民卡交易流水表 ODS_ZZQZ_T_BSMS_JRNL_TF ，新增四个字段   2024/10/16第五组unifiedTime(P1.TRANDATE||P1.TRANTIME)



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM
USING ORC
COMMENT '自助机具动账交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 自助机具动账交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSEQ AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,'' --P1.CREATETIME AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,null AS TXN_COMM_FEE -- 交易手续费
    ,P1.SRVCD AS FUNC_ID -- 功能ID
    ,P1.SRVDESC AS FUNC_DESC -- 功能描述
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO1 AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO1 AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,P1.IDPASS1 AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,P1.NAME1 AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.CARDNO2 AS TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,P1.ACCTNO2 AS TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,P1.IDPASS2 AS TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,P1.NAME2 AS TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,P1.RESERVE1 AS VOCH_NO -- 凭证号码
    ,'' AS P_END_RSPS_CD -- P端响应码
    ,'' AS HOST_TRAN_CD -- 主机交易码
    ,'' AS HOST_TRAN_CD_DESC -- 主机交易码描述
    ,'' AS ACTL_RECV_AMT -- 实收金额
    ,'' AS UNPY_TRAN_CD -- 银联交易码
    ,'' AS OPBANK_NO -- 开户行行号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS UNIONPAY_SER_NO -- 银联流水号
    ,'' AS RV_SER_NO -- 冲正流水号
    ,'' AS BIZ_TYPE_NO -- 业务类型编号
    ,'' AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,'' AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.NODENO AS EQUIP_NO -- 设备编号
    ,P2.DEV_CATALOG AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P2.VIRTUAL_TELLER_NO AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,CASE WHEN P1.SUCCFLAG='3' THEN '1' ELSE '0' END AS SUCC_FLAG -- 成功标志
    ,CASE WHEN P1.CASH_FLG='1' THEN '1' ELSE '0' END  AS CASH_FLAG -- 现金标志
    ,'' AS RV_FLAG -- 冲正标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,''  -- P3.CODE_TYPE AS MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,P1.TRANBRCH AS TXN_ORG_NO -- 交易机构编号
    ,P1.TRANOPER AS TXN_TELR_NO -- 交易柜员编号
    ,P1.CHECKOPER AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN P1.DEL_F='0' THEN '1' ELSE '0' END  AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_STMP_TRANS_TABLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ${version_num}.ODS_ZZQZ_STMP_TRANS_TABLE_TA AS P1 -- 智柜交易流水表

LEFT JOIN ODS_ZZQZ${version_num}.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.NODENO=P2.NO AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
WHERE CAST(TRIM(P1.AMOUNT) AS DECIMAL(28,2))>0 AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 自助机具动账交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSEQ AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,'' --P1.CREATETIME AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,null AS TXN_COMM_FEE -- 交易手续费
    ,P1.SRVCD AS FUNC_ID -- 功能ID
    ,P1.SRVDESC AS FUNC_DESC -- 功能描述
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO1 AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO1 AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,P1.IDPASS1 AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,P1.NAME1 AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.CARDNO2 AS TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,P1.ACCTNO2 AS TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,P1.IDPASS2 AS TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,P1.NAME2 AS TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,P1.RESERVE1 AS VOCH_NO -- 凭证号码
    ,'' AS P_END_RSPS_CD -- P端响应码
    ,'' AS HOST_TRAN_CD -- 主机交易码
    ,'' AS HOST_TRAN_CD_DESC -- 主机交易码描述
    ,'' AS ACTL_RECV_AMT -- 实收金额
    ,'' AS UNPY_TRAN_CD -- 银联交易码
    ,'' AS OPBANK_NO -- 开户行行号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS UNIONPAY_SER_NO -- 银联流水号
    ,'' AS RV_SER_NO -- 冲正流水号
    ,'' AS BIZ_TYPE_NO -- 业务类型编号
    ,'' AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,'' AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.NODENO AS EQUIP_NO -- 设备编号
    ,P2.DEV_CATALOG AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P2.VIRTUAL_TELLER_NO AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,CASE WHEN P1.SUCCFLAG='3' THEN '1' ELSE '0' END AS SUCC_FLAG -- 成功标志
    ,CASE WHEN P1.CASH_FLG='1' THEN '1' ELSE '0' END  AS CASH_FLAG -- 现金标志
    ,'' AS RV_FLAG -- 冲正标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,'' AS MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,P1.TRANBRCH AS TXN_ORG_NO -- 交易机构编号
    ,P1.TRANOPER AS TXN_TELR_NO -- 交易柜员编号
    ,P1.CHECKOPER AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN P1.DEL_F='0' THEN '1' ELSE '0' END  AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_STMP_BSR_TRANS_TABLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ${version_num}.ODS_ZZQZ_STMP_BSR_TRANS_TABLE_TA AS P1 -- 新版助农终端交易流水表

LEFT JOIN ODS_ZZQZ${version_num}.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.NODENO=P2.NO AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
WHERE CAST(TRIM(P1.AMOUNT) AS DECIMAL(28,2))>0 AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 自助机具动账交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSEQ AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,'' --P1.CREATETIME AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,null AS TXN_COMM_FEE -- 交易手续费
    ,P1.SRVCD AS FUNC_ID -- 功能ID
    ,P1.SRVDESC AS FUNC_DESC -- 功能描述
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO1 AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO1 AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,P1.IDPASS1 AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,P1.NAME1 AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.CARDNO2 AS TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,P1.ACCTNO2 AS TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,P1.IDPASS2 AS TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,P1.NAME2 AS TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,P1.RESERVE1 AS VOCH_NO -- 凭证号码
    ,'' AS P_END_RSPS_CD -- P端响应码
    ,'' AS HOST_TRAN_CD -- 主机交易码
    ,'' AS HOST_TRAN_CD_DESC -- 主机交易码描述
    ,'' AS ACTL_RECV_AMT -- 实收金额
    ,'' AS UNPY_TRAN_CD -- 银联交易码
    ,'' AS OPBANK_NO -- 开户行行号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS UNIONPAY_SER_NO -- 银联流水号
    ,'' AS RV_SER_NO -- 冲正流水号
    ,'' AS BIZ_TYPE_NO -- 业务类型编号
    ,'' AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,'' AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.NODENO AS EQUIP_NO -- 设备编号
    ,P2.DEV_CATALOG AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P2.VIRTUAL_TELLER_NO AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,CASE WHEN P1.SUCCFLAG='3' THEN '1' ELSE '0' END AS SUCC_FLAG -- 成功标志
    ,CASE WHEN P1.CASH_FLG='1' THEN '1' ELSE '0' END AS CASH_FLAG -- 现金标志
    ,'' AS RV_FLAG -- 冲正标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,'' AS MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,P1.TRANBRCH AS TXN_ORG_NO -- 交易机构编号
    ,P1.TRANOPER AS TXN_TELR_NO -- 交易柜员编号
    ,P1.CHECKOPER AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN P1.DEL_F='0' THEN '1' ELSE '0' END AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_STMP_BSM_TRANS_TABLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ${version_num}.ODS_ZZQZ_STMP_BSM_TRANS_TABLE_TA AS P1 -- 新版助自助终端流水表

LEFT JOIN ODS_ZZQZ${version_num}.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.NODENO=P2.NO AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
WHERE CAST(TRIM(P1.AMOUNT) AS DECIMAL(28,2))>0 AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第4组）==============
-- 自助机具动账交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.TRANSEQ AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,'' --P1.CREATETIME AS TXN_TM_STAMP -- 交易时间戳
    ,'' AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,'CNY' AS TXN_CURR_CD -- 交易币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,null AS TXN_COMM_FEE -- 交易手续费
    ,P1.SRVCD AS FUNC_ID -- 功能ID
    ,P1.SRVDESC AS FUNC_DESC -- 功能描述
    ,'' AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO1 AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO1 AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,P1.IDPASS1 AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,P1.NAME1 AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.CARDNO2 AS TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,P1.ACCTNO2 AS TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,P1.IDPASS2 AS TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,P1.NAME2 AS TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,P1.RESERVE1 AS VOCH_NO -- 凭证号码
    ,'' AS P_END_RSPS_CD -- P端响应码
    ,'' AS HOST_TRAN_CD -- 主机交易码
    ,'' AS HOST_TRAN_CD_DESC -- 主机交易码描述
    ,'' AS ACTL_RECV_AMT -- 实收金额
    ,'' AS UNPY_TRAN_CD -- 银联交易码
    ,'' AS OPBANK_NO -- 开户行行号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS UNIONPAY_SER_NO -- 银联流水号
    ,'' AS RV_SER_NO -- 冲正流水号
    ,'' AS BIZ_TYPE_NO -- 业务类型编号
    ,'' AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,'' AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.NODENO AS EQUIP_NO -- 设备编号
    ,P2.DEV_CATALOG AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P2.VIRTUAL_TELLER_NO AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,CASE WHEN P1.SUCCFLAG='3' THEN '1' ELSE '0' END AS SUCC_FLAG -- 成功标志
    ,CASE WHEN P1.CASH_FLG='1' THEN '1' ELSE '0' END  AS CASH_FLAG -- 现金标志
    ,'' AS RV_FLAG -- 冲正标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,'' AS MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,P1.TRANBRCH AS TXN_ORG_NO -- 交易机构编号
    ,P1.TRANOPER AS TXN_TELR_NO -- 交易柜员编号
    ,P1.CHECKOPER AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN P1.DEL_F='0' THEN '1' ELSE '0' END  AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_STMP_BST_TRANS_TABLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ${version_num}.ODS_ZZQZ_STMP_BST_TRANS_TABLE_TA AS P1 -- 新版助农终端交易流水表

LEFT JOIN ODS_ZZQZ${version_num}.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.NODENO=P2.NO AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
WHERE CAST(TRIM(P1.AMOUNT) AS DECIMAL(28,2))>0 AND P1.PT_DT = '${process_date}'  AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第5组）==============
-- 自助机具动账交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM(
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.AT_TERMID||P1.TRANDATE||P1.AT_TRACE AS BIZ_SER_NO -- 业务流水号
    ,unifiedTime(P1.TRANDATE) AS TXN_DT -- 交易日期
    ,CASE WHEN LENGTH(P1.TRANDATE||' '||P1.TRANTIME)=9 THEN unifiedTime(P1.TRANDATE||' 00:00:00.000000') ELSE unifiedTime(P1.TRANDATE||' '||P1.TRANTIME) END AS TXN_TM_STAMP -- 交易时间戳
    ,p1.INITSIDE AS TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,CASE WHEN P1.CURCODE='156' THEN 'CNY' ELSE P1.CURCODE END AS TXN_CURR_CD -- 交易币种代码
    ,P1.CASHCODE AS CASH_RMT_CD -- 钞汇代码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,P1.FEE AS TXN_COMM_FEE -- 交易手续费
    ,'' AS FUNC_ID -- 功能ID
    ,'' AS FUNC_DESC -- 功能描述
    ,P1.FRONTTRACE AS FRONT_SER_NO -- 前置流水号
    ,P1.CARDNO AS TXN_INITR_CARD_NO -- 交易发起方卡号
    ,P1.ACCTNO AS TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,'' AS TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,'' AS TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,P1.INCARNO AS TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,P1.INACCTNO AS TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,'' AS TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,'' AS TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,'' AS VOCH_NO -- 凭证号码
    ,P1.RETCODE AS P_END_RSPS_CD -- P端响应码
    ,P1.HOST_CODE AS HOST_TRAN_CD -- 主机交易码
    ,P1.HOST_DESC AS HOST_TRAN_CD_DESC -- 主机交易码描述
    ,P3.AMT2 AS ACTL_RECV_AMT -- 实收金额
    ,P1.GD_TRANCODE AS UNPY_TRAN_CD -- 银联交易码
    ,P1.ACCTBANK AS OPBANK_NO -- 开户行行号
    ,P1.HOST_TRACE AS HOST_SER_NO -- 主机流水号
    ,P1.GD_TRACE AS UNIONPAY_SER_NO -- 银联流水号
    ,P1.REVTRACE AS RV_SER_NO -- 冲正流水号
    ,P1.BUSITYPE AS BIZ_TYPE_NO -- 业务类型编号
    ,P1.BUSIFLAG AS PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,P1.AT_TRACE AS SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,P1.AT_TERMID AS EQUIP_NO -- 设备编号
    ,P1.AT_TERMTYPE AS EQUIP_TYPE_CD -- 设备类型代码
    ,P2.ORG_NO AS AFLT_ORG_NO -- 所属机构编号
    ,P1.AT_TELLERID AS SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,P1.SUCCFLAG AS SUCC_FLAG -- 成功标志
    ,'' AS CASH_FLAG -- 现金标志
    ,P1.REVFLAG AS RV_FLAG -- 冲正标志
    ,P2.IP AS SERVER_IP -- 服务器IP
    ,'' AS MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,P1.AT_BRANCHNO AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS AUDIT_TELR_NO -- 审核柜员编号
    ,unifiedTime(P1.LAST_ETL_ACG_DT) AS FINAL_MODIF_DT -- 最后修改日期
    ,CASE WHEN P1.DEL_F='0' THEN '1' ELSE '0' END  AS DATA_EFFECT_FLAG -- 数据有效标志
    ,'ZZQZ' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_ZZQZ_TRANS_HISTORY_TABLE_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
FROM
ODS_ZZQZ${version_num}.ODS_ZZQZ_TRANS_HISTORY_TABLE_TA AS P1 -- 自助交易流水表

LEFT JOIN ODS_ZZQZ${version_num}.ODS_ZZQZ_DEV_BASE_INFO_TF AS P2 -- 设备基础信息表
       ON P1.AT_TERMID=P2.NO AND P2.PT_DT = '${process_date}' AND  P2.DEL_F='0' 
LEFT JOIN (SELECT AMT2,AT_TERMID,TRANDATE,AT_TRACE,TRANTIME FROM ODS_ZZQZ${version_num}.ODS_ZZQZ_T_BSMS_JRNL_TF WHERE PT_DT = '${process_date}' AND  DEL_F='0') AS P3 -- 市民卡交易流水表
       ON P1.AT_TERMID = P3.AT_TERMID
AND P1.TRANDATE  = P3.TRANDATE
AND P1.AT_TRACE  = P3.AT_TRACE
AND P1.TRANTIME  = P3.TRANTIME 
WHERE CAST(TRIM(P1.AMOUNT) AS DECIMAL(28,2))>0 AND P1.PT_DT = '${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     BIZ_SER_NO -- 业务流水号
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_INITR_TYPE_NO -- 交易发起方类型编号
    ,TXN_CURR_CD -- 交易币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,TXN_AMT -- 交易金额
    ,TXN_COMM_FEE -- 交易手续费
    ,FUNC_ID -- 功能ID
    ,FUNC_DESC -- 功能描述
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_INITR_CARD_NO -- 交易发起方卡号
    ,TXN_INITR_ACCT_NO -- 交易发起方账户编号
    ,TXN_INITR_CUST_DOC_NO -- 交易发起方客户证件号码
    ,TXN_INITR_CUST_NAME -- 交易发起方客户名称
    ,TXN_RECVER_CARD_NO -- 交易接收方卡号
    ,TXN_RECVER_ACCT_NO -- 交易接收方账户编号
    ,TXN_RECVER_CUST_DOC_NO -- 交易接收方客户证件号码
    ,TXN_RECVER_CUST_NAME -- 交易接收方客户名称
    ,VOCH_NO -- 凭证号码
    ,P_END_RSPS_CD -- P端响应码
    ,HOST_TRAN_CD -- 主机交易码
    ,HOST_TRAN_CD_DESC -- 主机交易码描述
    ,ACTL_RECV_AMT -- 实收金额
    ,UNPY_TRAN_CD -- 银联交易码
    ,OPBANK_NO -- 开户行行号
    ,HOST_SER_NO -- 主机流水号
    ,UNIONPAY_SER_NO -- 银联流水号
    ,RV_SER_NO -- 冲正流水号
    ,BIZ_TYPE_NO -- 业务类型编号
    ,PAY_BIZ_CATE_NO -- 缴费业务种类编号
    ,SELF_SERV_TERMN_SER_NO -- 自助终端流水号
    ,EQUIP_NO -- 设备编号
    ,EQUIP_TYPE_CD -- 设备类型代码
    ,AFLT_ORG_NO -- 所属机构编号
    ,SYS_VIRTUAL_TELR_NO -- 系统虚拟柜员编号
    ,SUCC_FLAG -- 成功标志
    ,CASH_FLAG -- 现金标志
    ,RV_FLAG -- 冲正标志
    ,SERVER_IP -- 服务器IP
    ,MACH_TXN_TYPE_CD -- 机具交易类型代码
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AUDIT_TELR_NO -- 审核柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,DATA_EFFECT_FLAG -- 数据有效标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA_TM;
