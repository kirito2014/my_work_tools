-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-生活缴费签约协议信息聚合05
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF
--     表中文名：生活缴费签约协议信息聚合05
--     创建日期：2024-04-15 00:00:00
--     主键字段：AGT_NO, THIRD_PTY_USER_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改中间业务库名，增加95组
--         2024-09-10 00:00:00 魏丹丹 新增字段：摘要代码，修改客户内码/签约账户开户机构编号 的取数逻辑，增加1组
--         2024-10-17 00:00:00 魏丹丹 拆分生活缴费签约协议信息聚合 中第三组组数据，包含AGL_T_SIGN_XXX_02_TF



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM
USING ORC
COMMENT '生活缴费签约协议信息聚合05-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PLAT_DT -- 平台日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SUMMARY_CD -- 摘要代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 生活缴费签约协议信息聚合05
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_00;

CREATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_00 (
     CUST_ISN STRING COMMENT '关联字段'
    ,ACCT_NO STRING COMMENT '关联字段'
    ,BEL_ORG STRING COMMENT '关联字段'
    ,ONOROFF_FLAG STRING COMMENT '关联字段'
)
USING ORC
COMMENT '生活缴费签约协议信息聚合05'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_00(
     CUST_ISN -- 关联字段
    ,ACCT_NO -- 关联字段
    ,BEL_ORG -- 关联字段
    ,ONOROFF_FLAG -- 关联字段
)
SELECT
     P1.CUST_ISN AS CUST_ISN -- 关联字段
    ,P1.ACCT_NO AS ACCT_NO -- 关联字段
    ,P1.BEL_ORG AS BEL_ORG -- 关联字段
    ,'1' AS ONOROFF_FLAG -- 关联字段
FROM
(SELECT * FROM(
SELECT CUST_ISN,ACCT_NO,BEL_ORG,ROW_NUMBER()OVER(PARTITION BY ACCT_NO ORDER BY BEL_ORG DESC)RN
FROM(
    SELECT  TRIM(AA03CSNO) CUST_ISN, TRIM(AA01AC15) ACCT_NO,TRIM(AA47BRNO) BEL_ORG
    FROM ODS_CORE.ODS_CORE_BDFMHQAA_TF --活期存款主档
    WHERE TRIM(AA15ZHZT) = '1' AND TRIM(RCSTRS1B) <> '9' AND PT_DT = '${process_date}' AND DEL_F='0'
      UNION
    SELECT TRIM(CINOCSNO) CUST_ISN,TRIM(CDNOAC19) ACCT_NO,TRIM(OWONBRNO) BEL_ORG 
    FROM ODS_CORE.ODS_CORE_BWFMDCIM_TF  --借记卡信息主档文件
    WHERE TRIM(CRDSCRDS) IN ('1','5') AND TRIM(RCSTRS1B) <> '9' AND PT_DT = '${process_date}' AND DEL_F='0'
      UNION
    SELECT TRIM(CUSTR_REF) CUST_ISN,TRIM(CARD_NBR) ACCT_NO,TRIM(PRMAG_CODE) BEL_ORG 
    FROM ODS_CCRD.ODS_CCRD_CARD_TF --卡片资料表
    WHERE PT_DT = '${process_date}' AND DEL_F='0'
  )WHERE CUST_ISN IS NOT NULL
)WHERE RN=1
) AS P1 -- 活期存款主档\借记卡信息主档文件\卡片资料表

;
-- ==============聚合层字段映射（第0-3组）==============
-- 新旧账号对应关系
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_03;

CREATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_03 (
     BD02AC15 STRING COMMENT '新账号'
    ,BD01AC22 STRING COMMENT '关联字段'
)
USING ORC
COMMENT '新旧账号对应关系'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_03(
     BD02AC15 -- 新账号
    ,BD01AC22 -- 关联字段
)
SELECT
     BD02AC15 AS BD02AC15 -- 新账号
    ,BD01AC22 AS BD01AC22 -- 关联字段
FROM
(SELECT BD02AC15,BD01AC22 FROM ODS_CORE.ODS_CORE_BDFMHQBD_TF WHERE PT_DT = '${process_date}' AND DEL_F='0') AS P1 -- 新旧账号对应关系

;
-- ==============聚合层字段映射（第0-4组）==============
-- 借记卡主档
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_04;

CREATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_04 (
     DFANAC19 STRING COMMENT '基本账号'
    ,CDNOAC19 STRING COMMENT '关联字段'
)
USING ORC
COMMENT '借记卡主档'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_04(
     DFANAC19 -- 基本账号
    ,CDNOAC19 -- 关联字段
)
SELECT
     DFANAC19 AS DFANAC19 -- 基本账号
    ,CDNOAC19 AS CDNOAC19 -- 关联字段
FROM
(SELECT * FROM(
SELECT
   DFANAC19
  ,CDNOAC19
  ,ROW_NUMBER() OVER(PARTITION BY CDNOAC19 ORDER BY  DFANAC19 DESC) RN
FROM ODS_CORE.ODS_CORE_BWFMDCIM_TF 
WHERE PT_DT = '${process_date}' AND DEL_F='0'
)WHERE RN=1) AS P1 -- 借记卡主档

;
-- ==============聚合层字段映射（第0-5组）==============
-- 用户信息表
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_05;

CREATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_05 (
     USER_ID STRING COMMENT '用户ID'
    ,CRTF_NO STRING COMMENT '关联字段'
    ,CRTF_TYP STRING COMMENT '关联字段'
)
USING ORC
COMMENT '用户信息表'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_05(
     USER_ID -- 用户ID
    ,CRTF_NO -- 关联字段
    ,CRTF_TYP -- 关联字段
)
SELECT
     USER_ID AS USER_ID -- 用户ID
    ,CRTF_NO AS CRTF_NO -- 关联字段
    ,CRTF_TYP AS CRTF_TYP -- 关联字段
FROM
(
SELECT * FROM(
  SELECT
     USER_ID
    ,CRTF_NO
    ,CRTF_TYP
    ,ROW_NUMBER() OVER(PARTITION BY CRTF_NO,CRTF_TYP ORDER BY GMT_MODIFIED DESC) RN
  FROM ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF
  WHERE DELETED = '0' AND CRTF_NO!='' AND USER_ID LIKE 'UR%' AND PT_DT = '${process_date}' AND DEL_F='0'         
  )WHERE RN=1
) AS P1 -- 用户信息表

;
-- ==============聚合层字段映射（第0-6组）==============
-- 代理单位管理表
DROP TABLE IF EXISTS AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06;

CREATE TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06 (
     ENTR_NAME STRING COMMENT '单位中文名称'
    ,BUSI_NO STRING COMMENT '业务种类'
    ,BRCH_NO STRING COMMENT '归属机构号'
    ,DSCRP_CODE STRING COMMENT '记帐摘要码'
    ,ENTR_NO STRING COMMENT '关联字段'
)
USING ORC
COMMENT '代理单位管理表'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06(
     ENTR_NAME -- 单位中文名称
    ,BUSI_NO -- 业务种类
    ,BRCH_NO -- 归属机构号
    ,DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO -- 关联字段
)
SELECT
     ENTR_NAME AS ENTR_NAME -- 单位中文名称
    ,BUSI_NO AS BUSI_NO -- 业务种类
    ,BRCH_NO AS BRCH_NO -- 归属机构号
    ,DSCRP_CODE AS DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO AS ENTR_NO -- 关联字段
FROM
ODS_MID71.ODS_MID71_T_ENTR_TF AS P1 -- 代理单位管理表

WHERE PT_DT = '${process_date}' AND DEL_F='0'
;
-- ==============聚合层字段映射（第0-6-2组）==============
-- 代理单位管理表

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06(
     ENTR_NAME -- 单位中文名称
    ,BUSI_NO -- 业务种类
    ,BRCH_NO -- 归属机构号
    ,DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO -- 关联字段
)
SELECT
     ENTR_NAME AS ENTR_NAME -- 单位中文名称
    ,BUSI_NO AS BUSI_NO -- 业务种类
    ,BRCH_NO AS BRCH_NO -- 归属机构号
    ,DSCRP_CODE AS DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO AS ENTR_NO -- 关联字段
FROM
ODS_MID73.ODS_MID73_T_ENTR_TF AS P1 -- 代理单位管理表

WHERE PT_DT = '${process_date}' AND DEL_F='0'
;
-- ==============聚合层字段映射（第0-6-3组）==============
-- 代理单位管理表

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06(
     ENTR_NAME -- 单位中文名称
    ,BUSI_NO -- 业务种类
    ,BRCH_NO -- 归属机构号
    ,DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO -- 关联字段
)
SELECT
     ENTR_NAME AS ENTR_NAME -- 单位中文名称
    ,BUSI_NO AS BUSI_NO -- 业务种类
    ,BRCH_NO AS BRCH_NO -- 归属机构号
    ,DSCRP_CODE AS DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO AS ENTR_NO -- 关联字段
FROM
ODS_OSCIP.ODS_OSCIP_T_ENTR_TF AS P1 -- 代理单位管理表

WHERE PT_DT = '${process_date}' AND DEL_F='0'
;
-- ==============聚合层字段映射（第0-6-4组）==============
-- 代理单位管理表

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06(
     ENTR_NAME -- 单位中文名称
    ,BUSI_NO -- 业务种类
    ,BRCH_NO -- 归属机构号
    ,DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO -- 关联字段
)
SELECT
     ENTR_NAME AS ENTR_NAME -- 单位中文名称
    ,BUSI_NO AS BUSI_NO -- 业务种类
    ,BRCH_NO AS BRCH_NO -- 归属机构号
    ,DSCRP_CODE AS DSCRP_CODE -- 记帐摘要码
    ,ENTR_NO AS ENTR_NO -- 关联字段
FROM
ODS_IMBSETC.ODS_IMBSETC_T_ENTR_TF AS P1 -- 代理单位管理表

WHERE PT_DT = '${process_date}' AND DEL_F='0'
;
-- ==============聚合层字段映射（第3_0组）==============
-- 生活缴费签约协议信息聚合05

INSERT INTO TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM(
     AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,PLAT_DT -- 平台日期
    ,MGMT_ORG_NO -- 管理机构编号
    ,SUMMARY_CD -- 摘要代码
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ENTR_NO||P1.CUST_NO||P1.STAT AS AGT_NO -- 协议编号
    ,P1.CONTRACT AS THIRD_PTY_AGT_NO -- 第三方协议编号
    ,'' AS CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,unifiedTime(P1.SIGN_DATE) AS AGT_EFFECT_DT -- 协议生效日期
    ,'9999-12-31' AS AGT_EXPIR_DT -- 协议失效日期
    ,'9999-12-31' AS PAY_START_TM_STAMP -- 缴费开始时间戳
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P2.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PROD_NO -- 产品编号
    ,'' AS PROD_NAME -- 产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'9999' AS MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,'' AS PAY_PROJ_NO -- 缴费项目编号
    ,'' AS PAY_PROJ_NAME -- 缴费项目名称
    ,P1.USER_ID AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,'' AS THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,'' AS THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,'' AS THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,P1.USER_NAME AS CUST_NAME -- 客户名称
    ,P8.CUST_ISN AS CUST_IN_CD -- 客户内码
    ,P4.USER_ID AS USER_ID -- 用户ID
    ,P1.CERT_TYPE AS DOCTYP_CD -- 证件类型代码
    ,P1.CERT_ID AS DOC_NO -- 证件号码
    ,P1.TELEPHONE AS CONT_NO_NO -- 联系电话号码
    ,P1.ADDRESS AS CONT_ADDR -- 联系地址
    ,'' AS POST_CD -- 邮政编码
    ,'' AS SIGN_AGENT_NAME -- 签约代理人名称
    ,'' AS SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,'' AS SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,'' AS SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,CASE WHEN P1.ACCT_TYPE IS NULL OR TRIM(P1.ACCT_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.ACCT_TYPE)),'')
END AS ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CASE WHEN P1.CARD_TYPE IS NULL OR TRIM(P1.CARD_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CARD_TYPE)),'')
END AS CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,COALESCE(P1.ACCT_NO,p5.DFANAC19,p6.BD02AC15,'') AS ACCT_NO -- 账户编号
    ,P1.ACT_NAME AS ACCT_NAME -- 账户名称
    ,P1.CARD_NO AS CARD_NO -- 卡片编号
    ,'1' AS LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,'' AS DRAW_MODE_CD -- 支取方式代码
    ,'' AS TXN_PWD -- 交易密码
    ,P8.BEL_ORG AS SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,'' AS SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,NULL AS SINGLE_LMT -- 单笔限额
    ,NULL AS DAILY_ACCUM_LMT -- 日累计限额
    ,NULL AS MONTHLY_ACCUM_LMT -- 月累计限额
    ,NULL AS YEAR_CUM_LMT -- 年累计限额
    ,'' AS SIGN_TYPE_CD -- 签约类型代码
    ,'' AS SIGN_CHNL_CD -- 签约渠道代码
    ,'' AS SIGN_SER_NO -- 签约序号
    ,unifiedTime(P1.SIGN_DATE) AS SIGN_CONTR_DT -- 签约日期
    ,unifiedTime(P1.SIGN_TIME) AS SIGN_TM_STAMP -- 签约时间戳
    ,P1.SIGN_BRCH_NO AS SIGN_ORG_NO -- 签约机构编号
    ,P1.SIGN_TELLER_NO AS SIGN_TELR_NO -- 签约柜员编号
    ,unifiedTime(P1.UPT_DATE) AS FINAL_MODIF_DT -- 最后修改日期
    ,unifiedTime(P1.UPT_TIME) AS FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,P1.UPT_BRCH_NO AS RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,P1.UPT_TELLER_NO AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,CASE WHEN P1.STAT IS NULL OR TRIM(P1.STAT)=''
     THEN ''
     ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.STAT)),'')
END AS LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,'' AS CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,P1.TALLY_ORDER AS LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,P1.RMRK AS REM -- 备注
    ,'' AS SIGN_RESLT_DESC -- 签约结果描述
    ,'' AS REC_LOCK_FLAG -- 记录锁定标志
    ,'' AS VER_NO -- 版本编号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,P2.BRCH_NO AS MGMT_ORG_NO -- 管理机构编号
    ,P2.DSCRP_CODE AS SUMMARY_CD -- 摘要代码
    ,P1.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,P1.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,P1.GRP_SER_NO AS GRP_SER_NO -- 组序号
FROM
AGL.AGL_T_SIGN_XXX_02_TF AS P1 -- 联社公共签约表02

LEFT JOIN AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06 AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO  AND (P2.BUSI_NO LIKE '%SF%' OR P2.BUSI_NO LIKE '%WT%'
 OR P2.BUSI_NO LIKE '%RQ%'OR P2.BUSI_NO LIKE '%MQF%' 
 OR P2.BUSI_NO LIKE '%TEL%'OR P2.BUSI_NO LIKE '%HS' 
 OR P2.BUSI_NO LIKE '%GD%' OR P2.BUSI_NO LIKE '%TV%'
 OR P2.BUSI_NO LIKE '%SMK%' OR P2.BUSI_NO LIKE '%MOB%' OR P2.BUSI_NO LIKE '%UT%'
 OR P2.BUSI_NO IN ('YJLH','LWXO','UPAY','OLA','LAYXT','QZJFT','YJYXT','SCZX','YQDS','LSXXT','YXT','YHLZF',' ROAD','ZHTC','CXTC','YYYKT','LAYXT','TZXYK','LCXYQC','NBFWK','LAQC','WLIAS','TLZHT','XXXX'))
 AND P2.BUSI_NO NOT IN('JXDSF','HGHS','LCESFCG','LCESF') 
LEFT JOIN AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_05 AS P4 -- 用户信息表
       ON P1.CERT_TYPE=P4.CRTF_TYP AND P1.CERT_ID=P4.CRTF_NO 
LEFT JOIN AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_04 AS P5 -- 借记卡主档
       ON P1.CARD_NO=P5.CDNOAC19 
LEFT JOIN AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_03 AS P6 -- 新旧账号对应关系
       ON P1.OLD_ACCT_NO=P6.BD01AC22 
LEFT JOIN AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_00 AS P8 -- 活期存款主档\借记卡信息主档文件\卡片资料表
       ON TRIM(P1.ACCT_NO) = TRIM(P8.ACCT_NO) OR TRIM(P1.CARD_NO) = TRIM(P8.ACCT_NO) 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON P1.ACCT_TYPE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='AGL'  --源系统
AND S1.SRC_TAB_EN_NAME='T_SIGN_XXX' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='ACCT_TYPE' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='ACCT_PUB_PRIV_TYPE_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 代码转换
       ON P1.CARD_TYPE=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='AGL'  --源系统
AND S2.SRC_TAB_EN_NAME='T_SIGN_XXX' --来源表英文名  
AND S2.SRC_FIELD_EN_NAME='CARD_TYPE' --来源字段英文名 
AND S2.TARGET_TAB_EN_NAME='AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF'  --目标表名   
AND S2.TARGET_FIELD_EN_NAME='CARD_DISCNT_IDNT_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S3 -- 代码转换
       ON P1.STAT=S3.SRC_CD_VAL  
AND S3.SRC_TAB_LIB_NAME ='AGL'  --源系统
AND S3.SRC_TAB_EN_NAME='T_SIGN_XXX' --来源表英文名  
AND S3.SRC_FIELD_EN_NAME='STAT' --来源字段英文名 
AND S3.TARGET_TAB_EN_NAME='AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF'  --目标表名   
AND S3.TARGET_FIELD_EN_NAME='LIFE_PAY_AGT_STATUS_CD' --目标字段 
WHERE P1.PT_DT = '${process_date}'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF PARTITION(PT_DT = '${process_date}')
SELECT
     AGT_NO -- 协议编号
    ,THIRD_PTY_AGT_NO -- 第三方协议编号
    ,CONT_CENTER_AGT_NO -- 合约中心协议编号
    ,AGT_EFFECT_DT -- 协议生效日期
    ,AGT_EXPIR_DT -- 协议失效日期
    ,PLAT_DT -- 平台日期
    ,PAY_START_TM_STAMP -- 缴费开始时间戳
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PROD_NO -- 产品编号
    ,PROD_NAME -- 产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,MDL_BIZ_SUB_CLS_CD -- 中间业务子类代码
    ,PAY_PROJ_NO -- 缴费项目编号
    ,PAY_PROJ_NAME -- 缴费项目名称
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,THIRD_PTY_USER_DOCTYP_CD -- 第三方用户证件类型代码
    ,THIRD_PTY_USER_DOC_NO -- 第三方用户证件号码
    ,THIRD_PTY_USER_CONT_ADDR -- 第三方用户联系地址
    ,THIRD_PTY_USER_CONT_NO_NO -- 第三方用户联系电话号码
    ,CUST_NAME -- 客户名称
    ,CUST_IN_CD -- 客户内码
    ,USER_ID -- 用户ID
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,CONT_NO_NO -- 联系电话号码
    ,CONT_ADDR -- 联系地址
    ,POST_CD -- 邮政编码
    ,SIGN_AGENT_NAME -- 签约代理人名称
    ,SIGN_AGENT_DOCTYP_CD -- 签约代理人证件类型代码
    ,SIGN_AGENT_DOC_NO -- 签约代理人证件号码
    ,SIGN_AGENT_CONT_NO_NO -- 签约代理人联系电话号码
    ,ACCT_PUB_PRIV_TYPE_CD -- 账户公私类型代码
    ,CARD_DISCNT_IDNT_CD -- 卡折标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,ACCT_NO -- 账户编号
    ,ACCT_NAME -- 账户名称
    ,CARD_NO -- 卡片编号
    ,LIFE_PAY_MED_TYPE_CD -- 生活缴费介质类型代码
    ,DRAW_MODE_CD -- 支取方式代码
    ,TXN_PWD -- 交易密码
    ,SIGN_ACCT_OPEN_ACCT_ORG_NO -- 签约账户开户机构编号
    ,SIGN_ACCT_OPBANK_CNAPS_CODE -- 签约账户开户行人行支付行号
    ,SINGLE_LMT -- 单笔限额
    ,DAILY_ACCUM_LMT -- 日累计限额
    ,MONTHLY_ACCUM_LMT -- 月累计限额
    ,YEAR_CUM_LMT -- 年累计限额
    ,SIGN_TYPE_CD -- 签约类型代码
    ,SIGN_CHNL_CD -- 签约渠道代码
    ,SIGN_SER_NO -- 签约序号
    ,SIGN_CONTR_DT -- 签约日期
    ,SIGN_TM_STAMP -- 签约时间戳
    ,SIGN_ORG_NO -- 签约机构编号
    ,SIGN_TELR_NO -- 签约柜员编号
    ,MGMT_ORG_NO -- 管理机构编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_UPDATE_TM_STAMP -- 最后修改时间戳
    ,RECNT_MODIF_ORG_NO -- 最后修改机构编号
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,LIFE_PAY_AGT_STATUS_CD -- 生活缴费协议状态代码
    ,CONT_CENTER_AGT_STATUS_CD -- 合约中心协议状态代码
    ,LIFE_PAY_SIGN_SYS_CD -- 生活缴费签约系统代码
    ,REM -- 备注
    ,SUMMARY_CD -- 摘要代码
    ,SIGN_RESLT_DESC -- 签约结果描述
    ,REC_LOCK_FLAG -- 记录锁定标志
    ,VER_NO -- 版本编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM;
DROP TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_00;
DROP TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_03;
DROP TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_04;
DROP TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_05;
DROP TABLE AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_05_TF_TM_06;
