-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-收单账户结算明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_ACCT_STL_DTL_TA
--     表中文名：收单账户结算明细聚合
--     创建日期：2024-01-03 00:00:00
--     主键字段：STL_SER_NO, MERCHT_ORDER_NO, TXN_SER_NO, RECV_BIL_SYS_TXN_TM_STAMP, TXN_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：缺表ODS_SPS_SP_SHARED_COMPANY_TF
--     更新记录：
--         2024-01-03 00:00:00 魏丹丹 新增
--         2024-04-23 00:00:00 魏丹丹 修改主键以及取数规则，缺少第二组，后面价值最后
--         2024-08-22 00:00:00 魏丹丹 修改主键以及取数规则，已加第二组，第二组缺表，逻辑未调整
--         2024-09-22 00:00:00 魏丹丹 调整日期函数，加表ODS_SPS_SP_PAY_SIMPLE_TF ,2024/09/26增加 银联应收手续费 取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM
USING ORC
COMMENT '收单账户结算明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.ID,P1.MSG_ID) AS STL_SER_NO -- 结算流水编号
    ,P1.ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.MSG_ID AS TXN_SER_NO -- 交易流水号
    ,P1.TOTAL_AMOUNT AS ORDER_AMT -- 订单金额
    ,P1.SETTLE_AMT AS SHOULD_STL_AMT -- 应结金额
    ,P1.SETTLE_TYPE AS STL_TYPE_CD -- 结算类型代码
    ,P1.SETTLE_AMOUNT AS STL_AMT -- 结算金额
    ,P1.SETTLE_CCY AS STL_CURR_CD -- 结算币种代码
    ,P1.SETTLE_CYCLE AS STL_PERIOD_CD -- 结算周期代码
    ,P1.SETTLE_STATUS AS STL_STATUS_CD -- 结算状态代码
    ,P1.SETTLE_MODE AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,unifiedTime(P1.SETTLE_DATE_ESTIMATED) AS ANTCPTD_STL_DT -- 预计结算日期
    ,unifiedTime(P1.SETTLE_DATE_COMPLETE) AS STL_CMPLT_DT -- 结算完成日期
    ,P1.PAR_ID AS PRTCPT_PTY_NO -- 参与方编号
    ,P1.PAR_TYPE AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,P1.PAR_NM AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MERCH_ID AS MERCHT_NO -- 商户编号
    ,P1.S_MER_ID AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.S_MER_IDEN_CD AS MERCHT_IDTFY_NO -- 商户识别编号
    ,P1.S_MER_SHRT_NM AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,P1.S_MER_NM AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.MER_ORG_NO AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,P1.MERCH_ORG_NM AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,P1.S_MERCH_APPID AS MERCHT_APP_ID -- 商户AppID
    ,P1.SP_APPID AS SERV_PROVDER_ID -- 服务商AppID
    ,P1.ISV_ID AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,P1.ISV_NM AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.PAY_PROD AS RECV_BIL_PROD_NO -- 收单产品编号
    ,P1.PRD_NM AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,P1.BANKTYPE AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,P1.DEBIT_BANKNO AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,P1.DEBIT_BANK_CD AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,P1.DEBIT_ACCOUNT AS DEBIT_ACCT_NO -- 借方账户编号
    ,P1.DEBIT_ACCOUNT_NAME AS DEBIT_ACCT_NAME -- 借方账户名称
    ,P1.CREDIT_BANKNO AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,P1.CREDIT_BANK_CD AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,P1.CREDIT_ACCOUNT AS CRDT_ACCT_NO -- 贷方账户编号
    ,P1.CREDIT_ACCOUNT_NAME AS CRDT_ACCT_NAME -- 贷方账户名称
    ,P1.TUNNEL_ID AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,P1.PAY_ID AS CNAPS_SER_NO -- 支付系统流水号
    ,P1.TXN_TYPE AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.AMT AS TXN_AMT -- 交易金额
    ,P1.CCY AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,P1.BIZ_CGY AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,P1.BIZ_TYPE AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TUNNEL_TYPE IS NULL OR TRIM(P1.TUNNEL_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.TUNNEL_TYPE),'') 
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,unifiedTime(P1.TRANS_TIME) AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,unifiedTime(P1.TXN_TIME) AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,P1.TXN_STS AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,P1.TXN_SUB_STS AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,P1.RECEIVABLE_FEE AS RECVBL_COMM_FEE -- 应收手续费
    ,P1.ACTUAL_FEE AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,P1.FEE_CCY AS FEE_CURR_CD -- 费用币种代码
    ,P1.FT_PAY_AMT AS USER_PAY_AMT -- 用户支付金额
    ,P1.FT_REFUND_AMT AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.CORE_TX_DATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,unifiedTime(P1.CREATE_TIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(P1.MODIFY_TIME) AS MODIF_TM_STAMP -- 修改时间戳
    ,'IG' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_IG_SP_BATCH_SETTLE_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_IG${version_num}.ODS_IG_SP_BATCH_SETTLE_DETAIL_TA AS P1 -- 结算明细表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.TUNNEL_TYPE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='IG' 
AND P2.SRC_TAB_EN_NAME='SP_BATCH_SETTLE_DETAIL'
AND P2.SRC_FIELD_EN_NAME='TUNNEL_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第2组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ID AS STL_SER_NO -- 结算流水编号
    ,P1.REQ_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.TXN_ID AS TXN_SER_NO -- 交易流水号
    ,'' AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,P1.SETTLE_TYPE AS STL_TYPE_CD -- 结算类型代码
    ,CASE WHEN P1.SETTLE_TYPE = '1' THEN P1.AMOUNT-P1.FEE_AMT
     WHEN P1.SETTLE_TYPE = '2' THEN P1.FEE_AMT
     ELSE NULL
END AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,P1.SETTLE_MODEL AS STL_PERIOD_CD -- 结算周期代码
    ,P1.STTL_STATUS AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,unifiedTime(P1.BATCH_DATE) AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MERCH_ID AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.INST_BRANCH AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,'' AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,P1.TXN_TYPE AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.AMOUNT AS TXN_AMT -- 交易金额
    ,P1.CCY AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,P1.BIZ_TYPE AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,unifiedTime(P1.TXN_TIME) AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,'' AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,'' AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,P1.FEE_CCY AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,unifiedTime(P1.GMT_CREATE) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(P1.GMT_MODIFIED) AS MODIF_TM_STAMP -- 修改时间戳
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SPS_SP_BATCH_MERCHANT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_SPS${version_num}.ODS_SPS_SP_BATCH_MERCHANT_DETAIL_TA AS P1 -- 商户结算明细表

LEFT JOIN ODS_SPS${version_num}.ODS_SPS_SP_SHARED_MERCHANT_TF AS P3 -- 机构信息表
       ON P1.MERCH_ID=P3.MERCHANT_ID AND P3.PT_DT='${process_date}' AND P3.DEL_F='0' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第3组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.SETTLESEQNBR AS STL_SER_NO -- 结算流水编号
    ,'' AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.SETTLESEQNBR AS TXN_SER_NO -- 交易流水号
    ,'' AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,CASE WHEN P1.STANDBOOKTYPCD IS NULL OR TRIM(P1.STANDBOOKTYPCD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.STANDBOOKTYPCD),'') 
END AS STL_TYPE_CD -- 结算类型代码
    ,P1.TRANSAMT AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,unifiedTime(P1.CLEARDATE) AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MERNBR AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,P1.PAYERACCTDEPTNBR AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,P1.PAYERACCTNBR AS DEBIT_ACCT_NO -- 借方账户编号
    ,P1.PAYERACCTNAME AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,P1.PAYEEACCTDEPTNBR AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,P1.PAYEEACCTNBR AS CRDT_ACCT_NO -- 贷方账户编号
    ,P1.PAYEEACCTNAME AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,'' AS TXN_AMT -- 交易金额
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,unifiedTime(P1.TRANSTIME) AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,'' AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,'' AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.DOWNSYSDATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(P1.DATELASTMAINT) AS MODIF_TM_STAMP -- 修改时间戳
    ,'EPAY' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_EPAY_BATCHMERSETTLEHIST_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,3 AS GRP_SER_NO -- 组序号
FROM
ODS_EPAY${version_num}.ODS_EPAY_BATCHMERSETTLEHIST_TA AS P1 -- 商户结算汇总历史表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.STANDBOOKTYPCD=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='EPAY' 
AND P2.SRC_TAB_EN_NAME='BATCHMERSETTLEHIST'
AND P2.SRC_FIELD_EN_NAME='STANDBOOKTYPCD'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='STL_TYPE_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第4组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.UNION_SETTLE_DT,P1.MCHNT_ORDER_ID,P1.FINISH_TM) AS STL_SER_NO -- 结算流水编号
    ,P1.MCHNT_ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'' AS ORDER_AMT -- 订单金额
    ,P1.POS_MCHNT_NET_AMOUNT AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,P1.MCHNT_NET_AMOUNT AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,CASE WHEN P1.SETTLE_PERIOD IS NULL OR TRIM(P1.SETTLE_PERIOD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_PERIOD),'') 
END AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,NULL AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.POS_MCHNT_CD AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,P1.MCHNT_ID AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.POS_ORG_NO AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,P1.POS_MCHNT_ACCOUNT_NUMBER AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TRANS_TYPE IS NULL OR TRIM(P1.TRANS_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.ORDER_AMOUNT AS TXN_AMT -- 交易金额
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,'' AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,P1.UNION_COMMISSION AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,P1.POS_MCHNT_COMMISSION AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.CORE_TRANS_DT) AS CORE_ACCTN_DT -- 核心记账日期
    ,unifiedTime(P1.CREATE_TM) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(P1.FINISH_TM) AS MODIF_TM_STAMP -- 修改时间戳
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_ALIPAY_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,4 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT${version_num}.ODS_CCPT_SW_ACCOUNT_ALIPAY_UNION_QUERY_TA AS P1 -- 支付宝对账银联方数据历史表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.SETTLE_PERIOD=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='CCPT' 
AND P2.SRC_TAB_EN_NAME='SW_ACCOUNT_ALIPAY_UNION_QUERY'
AND P2.SRC_FIELD_EN_NAME='SETTLE_PERIOD'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANS_TYPE=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='CCPT' 
AND P3.SRC_TAB_EN_NAME='SW_ACCOUNT_ALIPAY_UNION_QUERY'
AND P3.SRC_FIELD_EN_NAME='TRANS_TYPE'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='TXN_TYPE_CD'  
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第5组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.UNION_SETTLE_DT,P1.UNION_TRANS_DT_TM,P1.MCHNT_ORDER_ID) AS STL_SER_NO -- 结算流水编号
    ,P1.MCHNT_ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,P1.ORDER_PAYABLE_AMOUNT AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,P1.POS_SETTLE_AMOUNT AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,CASE WHEN P1.SETTLE_PERIOD IS NULL OR TRIM(P1.SETTLE_PERIOD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_PERIOD),'') 
END  AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,NULL AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.POS_MCHNT_CD AS MERCHT_NO -- 商户编号
    ,P1.SPECIAL_MCHNT_CD AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.POS_ORG_NO AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,P1.POS_MCHNT_ACCOUNT_NUMBER AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TRANS_TYPE IS NULL OR TRIM(P1.TRANS_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.ORDER_AMOUNT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.CURRENCY_TYPE IS NULL OR TRIM(P1.CURRENCY_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.CURRENCY_TYPE),'') 
END AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,CASE WHEN P1.TRANS_STATUS IS NULL OR TRIM(P1.TRANS_STATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_STATUS),'') 
END AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,'' AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,P1.COMMISSION AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,P1.POS_MCHNT_COMMISSION AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,P1.REFUND_AMOUNT AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.CORE_TRANS_DT) AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,NULL AS MODIF_TM_STAMP -- 修改时间戳
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_TENPAY_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,5 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT${version_num}.ODS_CCPT_SW_ACCOUNT_TENPAY_UNION_QUERY_TA AS P1 -- 微信对账银联方数据历史表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.SETTLE_PERIOD=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='CCPT' 
AND P2.SRC_TAB_EN_NAME='SW_ACCOUNT_TENPAY_UNION_QUERY'
AND P2.SRC_FIELD_EN_NAME='SETTLE_PERIOD'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANS_STATUS=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='CCPT' 
AND P3.SRC_TAB_EN_NAME='SW_ACCOUNT_TENPAY_UNION_QUERY'
AND P3.SRC_FIELD_EN_NAME='TRANS_STATUS'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_MAIN_STATUS_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TRANS_TYPE=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='CCPT' 
AND P4.SRC_TAB_EN_NAME='SW_ACCOUNT_TENPAY_UNION_QUERY'
AND P4.SRC_FIELD_EN_NAME='TRANS_TYPE'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='TXN_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.CURRENCY_TYPE=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='CCPT' 
AND P5.SRC_TAB_EN_NAME='SW_ACCOUNT_TENPAY_UNION_QUERY'
AND P5.SRC_FIELD_EN_NAME='CURRENCY_TYPE'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P5.TARGET_FIELD_EN_NAME='TXN_CURR_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第6组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.UNION_SETTLE_DT,P1.UNION_TRANS_DT_TM,P1.TRANS_TP_CD,P1.MSG_TP,P1.ACQ_INS_ID_CD,P1.FWD_INS_ID_CD,P1.SYS_TRA_NUMBER,P1.UNION_FILE_TP) AS STL_SER_NO -- 结算流水编号
    ,P1.ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'' AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,P1.SETTLE_AMOUNT AS STL_AMT -- 结算金额
    ,CASE WHEN P1.SETTLE_CURRENCY IS NULL OR TRIM(P1.SETTLE_CURRENCY)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_CURRENCY),'') 
END AS STL_CURR_CD -- 结算币种代码
    ,CASE WHEN P1.SETTLE_PERIOD IS NULL OR TRIM(P1.SETTLE_PERIOD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_PERIOD),'') 
END AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,unifiedTime(P1.SETTLE_DT) AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.MCHNT_BELONG_ORG_NO AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,P1.TFR_OUT_ORG_ID AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,P1.TFR_OUT_CARD_NUMBER AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,P1.TFR_IN_ORG_ID AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,P1.MCHNT_CARD_NUMBER AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TRANS_TYPE IS NULL OR TRIM(P1.TRANS_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.TRANS_CURRENCY IS NULL OR TRIM(P1.TRANS_CURRENCY)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_CURRENCY),'') 
END AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,P1.TRANS_TP_CD AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,unifiedTime(P1.UNION_TRANS_DT_TM) AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,'' AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,P1.REC_COMMISSION AS RECVBL_COMM_FEE -- 应收手续费
    ,P1.INNER_COMMISSION AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.TRANS_DT) AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,NULL AS MODIF_TM_STAMP -- 修改时间戳
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_UNIONEPOS_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,6 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT${version_num}.ODS_CCPT_SW_ACCOUNT_UNIONEPOS_UNION_QUERY_TA AS P1 -- 银联EPOS对账银联方数据查询表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.SETTLE_PERIOD=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='CCPT' 
AND P2.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONEPOS_UNION_QUERY'
AND P2.SRC_FIELD_EN_NAME='SETTLE_PERIOD'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANS_TYPE=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='CCPT' 
AND P3.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONEPOS_UNION_QUERY'
AND P3.SRC_FIELD_EN_NAME='TRANS_TYPE'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='TXN_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TRANS_CURRENCY=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='CCPT' 
AND P4.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONEPOS_UNION_QUERY'
AND P4.SRC_FIELD_EN_NAME='TRANS_CURRENCY'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='TXN_CURR_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.SETTLE_CURRENCY=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='CCPT' 
AND P5.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONEPOS_UNION_QUERY'
AND P5.SRC_FIELD_EN_NAME='SETTLE_CURRENCY'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P5.TARGET_FIELD_EN_NAME='STL_CURR_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第7组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.UNION_SETTLE_DT,P1.UNION_TRANS_DT_TM,P1.TRANS_TP_CD,P1.MSG_TP,P1.ACQ_INS_ID_CD,P1.FWD_INS_ID_CD,P1.SYS_TRA_NUMBER,P1.UNION_FILE_TP) AS STL_SER_NO -- 结算流水编号
    ,P1.ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,'' AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,P1.TRANS_AMOUNT - P1.QRCODE_COMMISSION AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,CASE WHEN P1.SETTLE_PERIOD IS NULL OR TRIM(P1.SETTLE_PERIOD)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.SETTLE_PERIOD),'') 
END AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,NULL AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MCHNT_CD AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,P1.MCHNT_BELONG_ORG_NO AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,P1.MCHNT_CARD_NUMBER AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TRANS_TYPE IS NULL OR TRIM(P1.TRANS_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.TRANS_AMOUNT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.TRANS_CURRENCY IS NULL OR TRIM(P1.TRANS_CURRENCY)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_CURRENCY),'') 
END AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,P1.TRANS_TP_CD AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,unifiedTime(P1.UNION_TRANS_DT_TM) AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,'' AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,P1.QRCODE_COMMISSION AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.TRANS_DT) AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,NULL AS MODIF_TM_STAMP -- 修改时间戳
    ,'CCPT' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CCPT_SW_ACCOUNT_UNIONSCAN_UNION_QUERY_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,7 AS GRP_SER_NO -- 组序号
FROM
ODS_CCPT${version_num}.ODS_CCPT_SW_ACCOUNT_UNIONSCAN_UNION_QUERY_TA AS P1 -- 银联扫码对账银联方数据历史表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.SETTLE_PERIOD=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='CCPT' 
AND P2.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONSCAN_UNION_QUERY'
AND P2.SRC_FIELD_EN_NAME='SETTLE_PERIOD'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='STL_PERIOD_CD'  
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANS_TYPE=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='CCPT' 
AND P3.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONSCAN_UNION_QUERY'
AND P3.SRC_FIELD_EN_NAME='TRANS_TYPE'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='TXN_TYPE_CD'  
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TRANS_CURRENCY=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='CCPT' 
AND P4.SRC_TAB_EN_NAME='SW_ACCOUNT_UNIONSCAN_UNION_QUERY'
AND P4.SRC_FIELD_EN_NAME='TRANS_CURRENCY'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='TXN_CURR_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第8组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ID AS STL_SER_NO -- 结算流水编号
    ,P1.ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,'' AS TXN_SER_NO -- 交易流水号
    ,P1.BIZ_AMOUNT AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,P1.FEE_AMT AS STL_AMT -- 结算金额
    ,P1.FEE_AMT_CCY AS STL_CURR_CD -- 结算币种代码
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,NULL AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MERCH_ID AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,P1.PROD_CD AS RECV_BIL_PROD_NO -- 收单产品编号
    ,P1.PRODUCT_NAME AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,'' AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TRANS_TYPE IS NULL OR TRIM(P1.TRANS_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TRANS_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,'' AS TXN_AMT -- 交易金额
    ,'' AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,TRIM(P2.CHANNL_ID) AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,P1.PURP_PRTRY AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.TUNNEL IS NULL OR TRIM(P1.TUNNEL)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.TUNNEL),'') 
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.PAY_STATUS IS NULL OR TRIM(P1.PAY_STATUS)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.PAY_STATUS),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,T2.FEE_AMT AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,P1.FEE_AMT_CCY AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,unifiedTime(P1.CREATE_TIME) AS CREATE_TM_STAMP -- 创建时间戳
    ,unifiedTime(P1.UPDATE_TIME) AS MODIF_TM_STAMP -- 修改时间戳
    ,'SPS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_SPS_SP_PAY_ORDER_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,8 AS GRP_SER_NO -- 组序号
FROM
ODS_SPS${version_num}.ODS_SPS_SP_PAY_ORDER_TA AS P1 -- 智能支付订单表

LEFT JOIN ODS_SPS${version_num}.ODS_SPS_SP_SHARED_MERCHANT_TF AS S1 -- None
       ON TRIM(P1.MERCH_ID)=TRIM(S1.MERCHANT_ID) 
AND SUBSTR(P1.CREATE_TIME,1,10)=S1.CREATE_DATETIME
AND S1.PT_DT='${process_date}' AND S1.DEL_F='0' 
LEFT JOIN ODS_SPS${version_num}.ODS_SPS_SP_BATCH_RECON_PARAM_TF AS P2 -- 配置表
       ON TRIM(S1.MERCHANT_ID)=TRIM(P2.CHANNL_MERCH_ID) AND P2.PT_DT='${process_date}' AND P2.DEL_F='0' 
LEFT JOIN ODS_SPS${version_num}.ODS_SPS_SP_PAY_SIMPLE_TF AS T2 -- None
       ON TRIM(P1.ORDER_ID)=TRIM(T2.TOT_ORD_ID) 
AND TRIM(T2.MSG_STS)='09' 
AND TRIM(T2.MSG_TYPE) IN('CTDD.011.001.01','AGDN.001.002.01','AGDN.002.002.01'
                        ,'AGPT.001.001.01','AGPT.002.001.01','AGPT.003.001.01'
                        ,'AGPT.004.001.01','TPDD.001.001.01','CUDD.008.002.01'
                        ,'FRDD.001.001.01','CTDD.008.001.01','CUDD.001.002.01'
                        ,'SSDD.001.001.01','CTDD.001.001.01')
AND SUBSTR(T2.CREATE_TIME,1,10)='${process_date}' AND T2.PT_DT='${process_date}' AND T2.DEL_F='0' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TRANS_TYPE=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='SPS' 
AND P3.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND P3.SRC_FIELD_EN_NAME='TRANS_TYPE'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='TXN_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.TUNNEL=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='SPS' 
AND P4.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND P4.SRC_FIELD_EN_NAME='TUNNEL'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.PAY_STATUS=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='SPS' 
AND P5.SRC_TAB_EN_NAME='SP_PAY_ORDER'
AND P5.SRC_FIELD_EN_NAME='PAY_STATUS'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P5.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第9组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ID AS STL_SER_NO -- 结算流水编号
    ,P1.ORDERNUMBER AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.TERM_TRANS_TRC AS TXN_SER_NO -- 交易流水号
    ,P1.ORG_AMOUNT AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,'' AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,CASE WHEN P1.STLMODE IS NULL OR TRIM(P1.STLMODE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.STLMODE),'') 
END AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,unifiedTime(P1.SETDATE) AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.STDACCID AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,'' AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,'' AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,P1.SYSPROCOD AS TRAN_CD -- 交易码
    ,P1.STDTRNSAMT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.STDTRNSCUR IS NULL OR TRIM(P1.STDTRNSCUR)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.STDTRNSCUR),'') 
END AS TXN_CURR_CD -- 交易币种代码
    ,NULL AS TXN_DT -- 交易日期
    ,'' AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,'' AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TRNSFLAG IS NULL OR TRIM(P1.TRNSFLAG)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.TRNSFLAG),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,P1.WHITE_TRNSFEE AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,P1.FK_FEE AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,P1.YL_FEE AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,'' AS COMM_FEE_RATE -- 手续费率
    ,P1.SD_FEE AS RECVBL_COMM_FEE -- 应收手续费
    ,P1.STDTRNSFEE AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,unifiedTime(P1.REFUND_AMOUNT) AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,NULL AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,NULL AS MODIF_TM_STAMP -- 修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,9 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP${version_num}.ODS_POSP_TBL_EPS_TRNS_OLDJOUR_TA AS P1 -- 交易OLD流水表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.STLMODE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_EPS_TRNS_OLDJOUR'
AND P2.SRC_FIELD_EN_NAME='STLMODE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='STL_PERIOD_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.STDTRNSCUR=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_EPS_TRNS_OLDJOUR'
AND P4.SRC_FIELD_EN_NAME='STDTRNSCUR'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='TXN_CURR_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.TRNSFLAG=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP' 
AND P5.SRC_TAB_EN_NAME='TBL_EPS_TRNS_OLDJOUR'
AND P5.SRC_FIELD_EN_NAME='TRNSFLAG'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P5.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第10组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS STL_SER_NO -- 结算流水编号
    ,P1.MER_ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.TRADE_MONEY AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,'' AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,NULL AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MER_ID AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,'' AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,P1.MOBILE_ORDER_ID AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.RECEIPT_AMOUNT AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.CURRENCY_CODE IS NULL OR TRIM(P1.CURRENCY_CODE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.CURRENCY_CODE),'') 
END AS TXN_CURR_CD -- 交易币种代码
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.TXN_CHANNEL AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,P1.PAY_ACCESS_TYPE AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,P1.BANK_CHARGE AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,P1.BANK_FEE_RATE AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,'' AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,P1.REFUND_AMOUNT AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.CORE_DATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,NULL AS MODIF_TM_STAMP -- 修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_TBL_ORDER_TXN_HIS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,10 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP${version_num}.ODS_POSP_TBL_ORDER_TXN_HIS_TA AS P1 -- 银联扫码对账银联方数据历史表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_TYPE=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P3.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='TXN_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.CURRENCY_CODE=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P4.SRC_FIELD_EN_NAME='CURRENCY_CODE'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='TXN_CURR_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.TXN_STA=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP' 
AND P5.SRC_TAB_EN_NAME='TBL_ORDER_TXN_HIS'
AND P5.SRC_FIELD_EN_NAME='TXN_STA'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P5.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;
-- ==============聚合层字段映射（第11组）==============
-- 收单账户结算明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM(
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     '' AS STL_SER_NO -- 结算流水编号
    ,P1.MER_ORDER_ID AS MERCHT_ORDER_NO -- 商户订单编号
    ,P1.TXN_SEQ_ID AS TXN_SER_NO -- 交易流水号
    ,P1.TRADE_MONEY AS ORDER_AMT -- 订单金额
    ,'' AS SHOULD_STL_AMT -- 应结金额
    ,'' AS STL_TYPE_CD -- 结算类型代码
    ,'' AS STL_AMT -- 结算金额
    ,'' AS STL_CURR_CD -- 结算币种代码
    ,'' AS STL_PERIOD_CD -- 结算周期代码
    ,'' AS STL_STATUS_CD -- 结算状态代码
    ,'' AS RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,NULL AS ANTCPTD_STL_DT -- 预计结算日期
    ,NULL AS STL_CMPLT_DT -- 结算完成日期
    ,'' AS PRTCPT_PTY_NO -- 参与方编号
    ,'' AS PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,'' AS PRTCPT_PTY_NAME -- 参与方名称
    ,P1.MER_ID AS MERCHT_NO -- 商户编号
    ,'' AS SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,'' AS MERCHT_IDTFY_NO -- 商户识别编号
    ,'' AS SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,'' AS SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,'' AS SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,'' AS SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,'' AS MERCHT_APP_ID -- 商户AppID
    ,'' AS SERV_PROVDER_ID -- 服务商AppID
    ,'' AS SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,'' AS SERV_PROVDER_NAME -- 服务商名称
    ,'' AS RECV_BIL_PROD_NO -- 收单产品编号
    ,'' AS RECV_BIL_PROD_NAME -- 收单产品名称
    ,'' AS STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,'' AS DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,'' AS DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,'' AS DEBIT_ACCT_NO -- 借方账户编号
    ,'' AS DEBIT_ACCT_NAME -- 借方账户名称
    ,'' AS CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,'' AS CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,'' AS CRDT_ACCT_NO -- 贷方账户编号
    ,'' AS CRDT_ACCT_NAME -- 贷方账户名称
    ,'' AS PASS_RETURN_SER_NO -- 通道返回流水号
    ,'' AS CNAPS_SER_NO -- 支付系统流水号
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P3.TARGET_CD_VAL), '@'||TRIM(P1.TXN_TYPE),'') 
END AS RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,'' AS TRAN_CD -- 交易码
    ,P1.REALITY_MONEY AS TXN_AMT -- 交易金额
    ,CASE WHEN P1.CURRENCY_CODE IS NULL OR TRIM(P1.CURRENCY_CODE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P4.TARGET_CD_VAL), '@'||TRIM(P1.CURRENCY_CODE),'') 
END AS TXN_CURR_CD -- 交易币种代码
    ,unifiedTime(P1.TXN_DT) AS TXN_DT -- 交易日期
    ,P1.TXN_CHANNEL AS RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,'' AS RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,'' AS RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,CASE WHEN P1.PAY_ACCESS_TYPE IS NULL OR TRIM(P1.PAY_ACCESS_TYPE)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P2.TARGET_CD_VAL), '@'||TRIM(P1.PAY_ACCESS_TYPE),'') 
END AS RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,NULL AS RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,NULL AS CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,'' AS RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,CASE WHEN P1.TXN_STA IS NULL OR TRIM(P1.TXN_STA)='' 
     THEN '' 
     ELSE COALESCE(TRIM(P5.TARGET_CD_VAL), '@'||TRIM(P1.TXN_STA),'') 
END AS RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,'' AS WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,'' AS IN_BANK_COMM_FEE -- 行内手续费
    ,'' AS CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,'' AS UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,P1.BANK_FEE_RATE AS COMM_FEE_RATE -- 手续费率
    ,'' AS RECVBL_COMM_FEE -- 应收手续费
    ,'' AS ACTL_RECV_COMM_FEE -- 实收手续费
    ,'' AS FEE_CURR_CD -- 费用币种代码
    ,'' AS USER_PAY_AMT -- 用户支付金额
    ,'' AS USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,unifiedTime(P1.CORE_DATE) AS CORE_ACCTN_DT -- 核心记账日期
    ,NULL AS CREATE_TM_STAMP -- 创建时间戳
    ,NULL AS MODIF_TM_STAMP -- 修改时间戳
    ,'POSP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_POSP_TBL_C2B_ORDER_TXN_HIS_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,11 AS GRP_SER_NO -- 组序号
FROM
ODS_POSP${version_num}.ODS_POSP_TBL_C2B_ORDER_TXN_HIS_TA AS P1 -- 银联扫码对账银联方数据历史表

LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P2 -- 码值映射表
       ON P1.PAY_ACCESS_TYPE=P2.SRC_CD_VAL  
AND P2.SRC_TAB_LIB_NAME ='POSP' 
AND P2.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P2.SRC_FIELD_EN_NAME='PAY_ACCESS_TYPE'
AND P2.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P2.TARGET_FIELD_EN_NAME='RECV_BIL_STL_PASS_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P3 -- 码值映射表
       ON P1.TXN_TYPE=P3.SRC_CD_VAL  
AND P3.SRC_TAB_LIB_NAME ='POSP' 
AND P3.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P3.SRC_FIELD_EN_NAME='TXN_TYPE'
AND P3.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P3.TARGET_FIELD_EN_NAME='TXN_TYPE_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P4 -- 码值映射表
       ON P1.CURRENCY_CODE=P4.SRC_CD_VAL  
AND P4.SRC_TAB_LIB_NAME ='POSP' 
AND P4.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P4.SRC_FIELD_EN_NAME='CURRENCY_CODE'
AND P4.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P4.TARGET_FIELD_EN_NAME='TXN_CURR_CD' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS P5 -- 码值映射表
       ON P1.TXN_STA=P5.SRC_CD_VAL  
AND P5.SRC_TAB_LIB_NAME ='POSP' 
AND P5.SRC_TAB_EN_NAME='TBL_C2B_ORDER_TXN_HIS'
AND P5.SRC_FIELD_EN_NAME='TXN_STA'
AND P5.TARGET_TAB_EN_NAME='AGL_RECV_BIL_ACCT_STL_DTL_TA' 
AND P5.TARGET_FIELD_EN_NAME='RECV_BIL_TXN_SUB_STATUS_CD' 
WHERE P1.PT_DT='${process_date}' AND P1.DEL_F='0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     STL_SER_NO -- 结算流水编号
    ,MERCHT_ORDER_NO -- 商户订单编号
    ,TXN_SER_NO -- 交易流水号
    ,ORDER_AMT -- 订单金额
    ,SHOULD_STL_AMT -- 应结金额
    ,STL_TYPE_CD -- 结算类型代码
    ,STL_AMT -- 结算金额
    ,STL_CURR_CD -- 结算币种代码
    ,STL_PERIOD_CD -- 结算周期代码
    ,STL_STATUS_CD -- 结算状态代码
    ,RECV_BIL_CAP_STL_MODE_CD -- 收单资金结算模式代码
    ,ANTCPTD_STL_DT -- 预计结算日期
    ,STL_CMPLT_DT -- 结算完成日期
    ,PRTCPT_PTY_NO -- 参与方编号
    ,PRTCPT_PTY_TXN_TYPE_CD -- 参与方交易类型代码
    ,PRTCPT_PTY_NAME -- 参与方名称
    ,MERCHT_NO -- 商户编号
    ,SPC_ARGMT_MERCHT_NO -- 特约商户编号
    ,MERCHT_IDTFY_NO -- 商户识别编号
    ,SPC_ARGMT_MERCHT_ABB -- 特约商户简称
    ,SPC_ARGMT_MERCHT_NAME -- 特约商户名称
    ,SPC_ARGMT_MERCHT_BELONG_ORG_NO -- 特约商户归属机构编号
    ,SAM_BLG_ORG_NAME -- 特约商户归属机构名称
    ,MERCHT_APP_ID -- 商户AppID
    ,SERV_PROVDER_ID -- 服务商AppID
    ,SERV_PROVDER_IDTFY_NO -- 服务商识别编号
    ,SERV_PROVDER_NAME -- 服务商名称
    ,RECV_BIL_PROD_NO -- 收单产品编号
    ,RECV_BIL_PROD_NAME -- 收单产品名称
    ,STL_CARD_PROPTY_CD -- 结算卡性质代码
    ,DEBIT_BANK_CNAPS_CODE -- 借方银行人行支付行号
    ,DEBIT_OPBANK_ORG_NO -- 借方开户行机构编号
    ,DEBIT_ACCT_NO -- 借方账户编号
    ,DEBIT_ACCT_NAME -- 借方账户名称
    ,CRDT_BANK_CNAPS_CODE -- 贷方银行人行支付行号
    ,CRDT_OPBANK_ORG_NO -- 贷方开户行机构编号
    ,CRDT_ACCT_NO -- 贷方账户编号
    ,CRDT_ACCT_NAME -- 贷方账户名称
    ,PASS_RETURN_SER_NO -- 通道返回流水号
    ,CNAPS_SER_NO -- 支付系统流水号
    ,RECV_BIL_TXN_TYPE_CD -- 收单交易类型代码
    ,TRAN_CD -- 交易码
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_DT -- 交易日期
    ,RECV_BIL_INTER_TXN_CHNL_CD -- 收单内部交易渠道代码
    ,RECV_BIL_BIZ_TYPE_CD -- 收单业务类型代码
    ,RECV_BIL_BIZ_CATE_CD -- 收单业务种类代码
    ,RECV_BIL_STL_PASS_TYPE_CD -- 收单结算通道类型代码
    ,RECV_BIL_SYS_TXN_TM_STAMP -- 收单系统交易时间戳
    ,CNAPS_TXN_TM_STAMP -- 支付系统交易时间戳
    ,RECV_BIL_TXN_MAIN_STATUS_CD -- 收单交易主状态代码
    ,RECV_BIL_TXN_SUB_STATUS_CD -- 收单交易子状态代码
    ,WHITE_LIST_ADV_COMM_FEE -- 白名单垫付手续费
    ,IN_BANK_COMM_FEE -- 行内手续费
    ,CARD_ISSUER_COMM_FEE -- 发卡方手续费
    ,UNPY_RECVBL_COMM_FEE -- 银联应收手续费
    ,COMM_FEE_RATE -- 手续费率
    ,RECVBL_COMM_FEE -- 应收手续费
    ,ACTL_RECV_COMM_FEE -- 实收手续费
    ,FEE_CURR_CD -- 费用币种代码
    ,USER_PAY_AMT -- 用户支付金额
    ,USER_ACTL_FALLBACK_AMT -- 用户实退金额
    ,CORE_ACCTN_DT -- 核心记账日期
    ,CREATE_TM_STAMP -- 创建时间戳
    ,MODIF_TM_STAMP -- 修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_RECV_BIL_ACCT_STL_DTL_TA_TM;
