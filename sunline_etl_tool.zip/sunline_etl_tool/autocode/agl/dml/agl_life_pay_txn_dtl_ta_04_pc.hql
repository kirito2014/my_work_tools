-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-生活缴费交易明细聚合04
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_TXN_DTL_TA
--     表中文名：生活缴费交易明细聚合04
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04;

/* 1.2 create main temp table  */
CREATE TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04
USING ORC
COMMENT '生活缴费交易明细聚合临时表04'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04;

/* 2.1 get today data */
-- ==============聚合层字段映射（第89组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SEQ_NO) AS TXN_SER_NO -- 交易流水号
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,'' AS LOC_BATCH_NO -- 本地批次编号
    ,'' AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,'' AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,unifiedTime(P1.TXDATE) AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,unifiedTime(P1.PLAT_DATE) AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,unifiedTime(P1.PLAT_DATE) AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TXAMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.TXAMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,NULL AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,NULL AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,P1.BRCHNO AS TXN_ORG_NO -- 交易机构编号
    ,P1.TLRNO AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'CNY' AS CURR_CD -- 币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,'' AS PAY_CARD_NO -- 缴费卡号
    ,'' AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,'' AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,'' AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,'' AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,'' AS CUST_IN_CD -- 客户内码
    ,P1.CUSTNO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'06' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,P1.HOST_ACC_STAT AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,'' AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,P1.HOST_CHK_STAT AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,P1.ENTR_CHK_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'0' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_UPAY_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,89 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_UPAY_JRNL_TA AS P1 -- 华数业务流水表

WHERE CONCAT(cast(P1.PLAT_DATE as string), cast(P1.SEQ_NO as string)) NOT IN (SELECT CONCAT(cast(PLAT_DATE as string), cast(SEQ_NO as string)) FROM ODS_OEHCP${version_num}.ODS_OEHCP_T_JRNL_TA WHERE PT_DT = '${process_date}' AND DEL_F = '0')
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第90组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SEQ_NO) AS TXN_SER_NO -- 交易流水号
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,'' AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,'' AS LOC_BATCH_NO -- 本地批次编号
    ,'' AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,'' AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,unifiedTime(P1.TXDATE) AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,unifiedTime(P1.PLAT_DATE) AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,unifiedTime(P1.PLAT_DATE) AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TXAMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.TXAMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,NULL AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,NULL AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,P1.BRCHNO AS TXN_ORG_NO -- 交易机构编号
    ,P1.TLRNO AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'CNY' AS CURR_CD -- 币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,'' AS PAY_CARD_NO -- 缴费卡号
    ,'' AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,'' AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,'' AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,'' AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,'' AS CUST_IN_CD -- 客户内码
    ,P1.CUSTNO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'06' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,P1.HOST_ACC_STAT AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,'' AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,P1.HOST_CHK_STAT AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,P1.ENTR_CHK_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'0' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_ZJHS_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,90 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_ZJHS_JRNL_TA AS P1 -- 浙江华数流水表

WHERE CONCAT(cast(P1.PLAT_DATE as string), cast(P1.SEQ_NO as string)) NOT IN (SELECT CONCAT(cast(PLAT_DATE as string), cast(SEQ_NO as string)) FROM ODS_OEHCP${version_num}.ODS_OEHCP_T_JRNL_TA WHERE PT_DT = '${process_date}' AND DEL_F = '0')
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第92组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SEQ_NO) AS TXN_SER_NO -- 交易流水号
    ,P1.seq_no AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ AS HOST_SER_NO -- 主机流水号
    ,P1.OTH_SEQ AS THIRD_PTY_SER_NO -- 第三方流水号
    ,P1.OLD_SEQ AS UNDO_SER_NO -- 撤销流水号
    ,'' AS LOC_BATCH_NO -- 本地批次编号
    ,'' AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,'' AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,unifiedTime(P1.TX_DATE) AS TXN_DT -- 交易日期
    ,unifiedTime1(P1.TX_TIME) AS TXN_TM_STAMP -- 交易时间戳
    ,NULL AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(P1.ACT_TIME) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,unifiedTime(P1.OTH_DATE) AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(P1.OTH_TIME) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TX_AMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.TX_AMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,NULL AS TXN_AMT -- 交易金额
    ,P1.TX_FEE AS COMM_FEE_AMT -- 手续费金额
    ,P1.TX_LATE AS LATE_FEE -- 滞纳金
    ,P1.TX_MODE AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,P1.TX_CODE AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,P1.CHN_NO AS CHNL_CD -- 渠道代码
    ,P1.TALLY_ORDER AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,P1.MNG_BRCH AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,P1.BRCHNO AS TXN_ORG_NO -- 交易机构编号
    ,P1.TLRNO AS TXN_TELR_NO -- 交易柜员编号
    ,P1.BRCH_NO AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,CASE WHEN P1.DC_FLAG IS NULL OR TRIM(P1.DC_FLAG)='' 
     THEN '' 
ELSE COALESCE(TRIM(M1.TARGET_CD_VAL), '@'||TRIM(P1.DC_FLAG),'') END AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,P1.CURR_NO AS CURR_CD -- 币种代码
    ,P1.CURR_IDEN AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN P1.HOST_ACT_NO1 LIKE '6%' THEN P1.HOST_ACT_NO1
     ELSE ''
END AS PAY_CARD_NO -- 缴费卡号
    ,CASE WHEN P1.HOST_ACT_NO1 NOT LIKE '6%' THEN P1.HOST_ACT_NO1
     ELSE P3.DFANAC19
END AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,P1.ACT_NAME1 AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,P1.OPEN_BRCH_NO AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,P1.ACT_NO2 AS TRNIN_ACCT_NO -- 转入账户编号
    ,P1.ACT_NAME2 AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,COALESCE(P3.CINOCSNO,P4.AA03CSNO,'') AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,P1.ENTR_NAME AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,P1.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'06' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,P1.TX_FLAG AS TXN_STATUS_CD -- 交易状态代码
    ,P1.HOST_ACC_STAT AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,P1.OTH_CODE AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,P1.OTH_MSG AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,P1.SUM_MSG AS SUMMARY_CD -- 摘要代码
    ,P1.SUM_CODE AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,P1.CHK_ACT_NO AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,P1.HOST_CHK_STAT AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,P1.ENTR_CHK_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'0' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MID73_ZJHS_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,92 AS GRP_SER_NO -- 组序号
FROM
ODS_MID73${version_num}.ODS_MID73_ZJHS_JRNL_TA AS P1 -- 华数流水表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡信息主档文件
       ON P1.HOST_ACT_NO1 = P3.CDNOAC19
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款账户主档
       ON SUBSTR(P1.HOST_ACT_NO1,1,15)=SUBSTR(P4.AA01AC15,1,15)
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
LEFT JOIN AGL${version_num}.PUB_CD_MAP AS M1 -- 码值表
       ON P1.DC_FLAG=M1.SRC_CD_VAL  
AND M1.SRC_TAB_LIB_NAME ='OEHCP'  --源系统 简称或中文名 待定
AND M1.SRC_TAB_EN_NAME='T_JRNL_DYSF' --来源表英文名 大写
AND M1.SRC_FIELD_EN_NAME='DC_FLAG' --来源字段英文名 大写
AND M1.TARGET_TAB_EN_NAME='AGL_LIFE_PAY_TXN_DTL_TA' --目标表名 大写
AND M1.TARGET_FIELD_EN_NAME='DEBIT_CRDT_IDNT_CD' --目标字段 大写 
WHERE CONCAT(cast(P1.PLAT_DATE as string), cast(P1.SEQ_NO as string)) NOT IN (SELECT CONCAT(cast(PLAT_DATE as string), cast(SEQ_NO as string)) FROM ODS_OEHCP${version_num}.ODS_OEHCP_T_JRNL_TA WHERE PT_DT = '${process_date}' AND DEL_F = '0')
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第104组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SEQ_NO) AS TXN_SER_NO -- 交易流水号
    ,P1.seq_no AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,'' AS HOST_SER_NO -- 主机流水号
    ,P1.OTH_SEQ AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,'' AS LOC_BATCH_NO -- 本地批次编号
    ,'' AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,'' AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,unifiedTime(P1.PLAT_DATE) AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,unifiedTime(P1.PLAT_DATE) AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,unifiedTime(P1.PLAT_DATE) AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TX_AMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.TX_AMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,NULL AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,NULL AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,P1.BRCH_NO AS TXN_ORG_NO -- 交易机构编号
    ,P1.TELLER_NO AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'CNY' AS CURR_CD -- 币种代码
    ,'1' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN P1.ACCT_NO LIKE '6%' THEN P1.ACCT_NO
     ELSE ''
END AS PAY_CARD_NO -- 缴费卡号
    ,CASE WHEN P1.ACCT_NO NOT LIKE '6%' THEN P1.ACCT_NO
     ELSE P3.DFANAC19
END AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,'' AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,'' AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,'' AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,COALESCE(P3.CINOCSNO,P4.AA03CSNO,'') AS CUST_IN_CD -- 客户内码
    ,P1.USER_ID AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,'' AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'05' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,P1.HOST_ACC_STAT AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,P1.ENTR_ACC_STAT AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,'' AS HOST_RTN_CD -- 主机返回码
    ,'' AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,P1.OTH_CODE AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,P1.OTH_MSG AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,P1.HOST_CHK_STAT AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,P1.ENTR_CHK_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'0' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'ODS_OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_TELE_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,104 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_TELE_JRNL_TA AS P1 -- 电信流水表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡信息主档文件
       ON P1.ACCT_NO = P3.CDNOAC19
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款账户主档
       ON SUBSTR(P1.ACCT_NO,1,15)=SUBSTR(P4.AA01AC15,1,15)
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
WHERE CONCAT(cast(P1.PLAT_DATE as string), cast(P1.SEQ_NO as string)) NOT IN (SELECT CONCAT(cast(PLAT_DATE as string), cast(SEQ_NO as string)) FROM ODS_OEHCP${version_num}.ODS_OEHCP_T_JRNL_TA WHERE PT_DT = '${process_date}' AND DEL_F = '0')
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第114组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SERI_NO,P1.BAT_SEQ ) AS TXN_SER_NO -- 交易流水号
    ,P1.seq_no AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ_NO AS HOST_SER_NO -- 主机流水号
    ,'' AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,P1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,P1.DET_STAT AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,P1.SERI_NO AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,NULL AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,NULL AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,NULL AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TOT_AMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.REAL_AMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,P1.TRAN_AMT AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,P1.LATE_AMT AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,'' AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN P1.CUST_ACCT_NO1 LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE ''
END AS PAY_CARD_NO -- 缴费卡号
    ,CASE WHEN P1.CUST_ACCT_NO1 NOT LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE P3.DFANAC19
END AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,P1.ACCT_NAME AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,P1.SET_ACCT_NO1 AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,COALESCE(P3.CINOCSNO,P4.AA03CSNO,'') AS CUST_IN_CD -- 客户内码
    ,P1.USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'06' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,'' AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,'' AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,'' AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'1' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'ODS_OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_ZJHS_BAT_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,114 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_ZJHS_BAT_TA AS P1 -- 华数批量明细表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡信息主档文件
       ON P1.CUST_ACCT_NO1 = P3.CDNOAC19
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款账户主档
       ON SUBSTR(P1.CUST_ACCT_NO1,1,15)=SUBSTR(P4.AA01AC15,1,15)
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
WHERE CONCAT(cast(P1.PLAT_DATE as string),cast(P1.SERI_NO as string),cast(P1.BAT_SEQ as string)) NOT IN (
SELECT CONCAT(cast(PLAT_DATE as string),cast(SERI_NO as string),cast(BAT_SEQ as string)) FROM AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM WHERE PT_DT = '${process_date}' GROUP BY 1
)     
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第193组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SERI_NO,P1.BAT_SEQ ) AS TXN_SER_NO -- 交易流水号
    ,P1.seq_no AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ_NO AS HOST_SER_NO -- 主机流水号
    ,'' AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,P1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,P1.DET_STAT AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,P1.SERI_NO AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,NULL AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,NULL AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,NULL AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TOT_AMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.REAL_AMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,P1.TRAN_AMT AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,P1.LATE_AMT AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,'' AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN P1.CUST_ACCT_NO1 LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE ''
END AS PAY_CARD_NO -- 缴费卡号
    ,CASE WHEN P1.CUST_ACCT_NO1 NOT LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE P3.DFANAC19
END AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,P1.ACCT_NAME AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,P1.SET_ACCT_NO1 AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,COALESCE(P3.CINOCSNO,P4.AA03CSNO,'') AS CUST_IN_CD -- 客户内码
    ,P1.USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,'' AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'02' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,'' AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,'' AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,P1.ENTR_CHK_STAT AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'1' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'ODS_OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_TELE_BAT_DETAIL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,193 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_T_TELE_BAT_DETAIL_TA AS P1 -- 省版电信批量流水表

LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡信息主档文件
       ON P1.CUST_ACCT_NO1 = P3.CDNOAC19
      AND P3.DEL_F ='0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款账户主档
       ON SUBSTR(P1.CUST_ACCT_NO1,1,15)=SUBSTR(P4.AA01AC15,1,15)
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
WHERE CONCAT(cast(P1.PLAT_DATE as string),cast(P1.SERI_NO as string),cast(P1.BAT_SEQ as string)) NOT IN (
SELECT CONCAT(cast(PLAT_DATE as string),cast(SERI_NO as string),cast(BAT_SEQ as string)) FROM AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM WHERE PT_DT = '${process_date}' GROUP BY 1
)
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第202组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SERI_NO,P1.BAT_SEQ ) AS TXN_SER_NO -- 交易流水号
    ,P1.SEQ_NO AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ_NO AS HOST_SER_NO -- 主机流水号
    ,'' AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,P1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,P1.DET_STAT AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,P1.SERI_NO AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,NULL AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,NULL AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,NULL AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TOT_AMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.REAL_AMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,P1.TRAN_AMT AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,P1.LATE_AMT AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,NVL(TRIM(M1.BRCH_NO),'') AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN P1.CUST_ACCT_NO1 LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE ''
END AS PAY_CARD_NO -- 缴费卡号
    ,CASE WHEN P1.CUST_ACCT_NO1 NOT LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE P3.DFANAC19
END AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,P1.ACCT_NAME AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,P1.SET_ACCT_NO1 AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,COALESCE(P3.CINOCSNO,P4.AA03CSNO,'' ) AS CUST_IN_CD -- 客户内码
    ,P1.USER_NO AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'06' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,'' AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,'' AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,'' AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'1' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'OEHCP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_OEHCP_T_LASF2_JRNL_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,202 AS GRP_SER_NO -- 组序号
FROM
ODS_OEHCP${version_num}.ODS_OEHCP_UPAY_BAT_TA AS P1 -- 华数批扣表 

LEFT JOIN (select bat_seq, entr_no, BRCH_NO 
from ODS_OSCIP${version_num}.ODS_OSCIP_T_BAT_TASK_TF 
WHERE DEL_F = '0' and PT_DT='${process_date}'
union 
select bat_seq, entr_no, BRCH_NO 
from ODS_MID73${version_num}.ODS_MID73_T_BAT_TASK_TF 
WHERE DEL_F = '0' and PT_DT='${process_date}' ) AS M1 -- 批量控制表
       ON P1.bat_seq = M1.bat_seq and trim(P1.entr_no) = trim(M1.entr_no) 
LEFT JOIN ODS_OSCIP${version_num}.ODS_OSCIP_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO
      AND P2.DEL_F = '0'
      AND P2.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡信息主档文件
       ON P1.CUST_ACCT_NO1 = P3.CDNOAC19
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款账户主档
       ON SUBSTR(P1.CUST_ACCT_NO1,1,15)=SUBSTR(P4.AA01AC15,1,15)
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
WHERE CONCAT(cast(P1.PLAT_DATE as string),cast(P1.SERI_NO as string),cast(P1.BAT_SEQ as string)) NOT IN (
SELECT CONCAT(cast(PLAT_DATE as string),cast(SERI_NO as string),cast(BAT_SEQ as string)) FROM AGL${version_num}.AGL_T_AGT_DATA_XXXX_TA_TM WHERE PT_DT = '${process_date}' GROUP BY 1
)
  AND P1.PT_DT = '${process_date}' 
  AND P1.DEL_F = '0'
;
-- ==============聚合层字段映射（第204组）==============
-- 生活缴费交易明细聚合

INSERT INTO TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04(
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     CONCAT(P1.PLAT_DATE,P1.SEQ_NO) AS TXN_SER_NO -- 交易流水号
    ,P1.seq_no AS PLAT_SER_NO -- 平台流水号
    ,'' AS ORDER_SER_NO -- 订单流水号
    ,'' AS FORE_END_SER_NO -- 前端流水号
    ,P1.HOST_SEQ_NO AS HOST_SER_NO -- 主机流水号
    ,'' AS THIRD_PTY_SER_NO -- 第三方流水号
    ,'' AS UNDO_SER_NO -- 撤销流水号
    ,P1.BAT_SEQ AS LOC_BATCH_NO -- 本地批次编号
    ,P1.DET_STAT AS LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,P1.SERI_NO AS BATCH_SEQ_NO -- 批次顺序号
    ,unifiedTime(P1.PLAT_DATE) AS PLAT_DT -- 平台日期
    ,NULL AS ORDER_DT -- 订单日期
    ,NULL AS TXN_DT -- 交易日期
    ,unifiedTime1(NULL) AS TXN_TM_STAMP -- 交易时间戳
    ,NULL AS HOST_TXN_DT -- 主机交易日期
    ,unifiedTime1(NULL) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,NULL AS THIRD_PTY_TXN_DT -- 第三方交易日期
    ,unifiedTime1(NULL) AS THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,P1.TOT_AMT AS PAYOFF_TOTAL_AMT -- 代收总金额
    ,NULL AS AGCOL_FAIL_AMT -- 代收失败金额
    ,P1.REAL_AMT AS AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,P1.TRAN_AMT AS TXN_AMT -- 交易金额
    ,NULL AS COMM_FEE_AMT -- 手续费金额
    ,P1.LATE_AMT AS LATE_FEE -- 滞纳金
    ,'' AS LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,'' AS MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,'' AS CHNL_CD -- 渠道代码
    ,'' AS LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,'' AS AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,'' AS TXN_ORG_NO -- 交易机构编号
    ,'' AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS STL_STRU_NO -- 结算机构编号
    ,'' AS DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,'' AS CURR_CD -- 币种代码
    ,'' AS CASH_RMT_CD -- 钞汇代码
    ,CASE WHEN P1.CUST_ACCT_NO1 LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE ''
END AS PAY_CARD_NO -- 缴费卡号
    ,CASE WHEN P1.CUST_ACCT_NO1 NOT LIKE '6%' THEN P1.CUST_ACCT_NO1
     ELSE P3.DFANAC19
END AS PAY_FEE_ACCT_NO -- 缴费账户编号
    ,P1.ACCT_NAME AS PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,P1.OPEN_BRCH AS OPEN_ACCT_ORG_NO -- 开户机构编号
    ,P1.SET_ACCT_NO1 AS TRNIN_ACCT_NO -- 转入账户编号
    ,'' AS TRNIN_ACCT_NAME -- 转入账户名称
    ,'' AS DOC_NO -- 证件号码
    ,COALESCE(P3.CINOCSNO,P4.AA03CSNO,'') AS CUST_IN_CD -- 客户内码
    ,COALESCE(P1.USER_NO,P1.CUSTNO) AS THIRD_PTY_USER_NO -- 第三方用户编号
    ,P1.ENTR_NO AS BIZ_UNIT_NO -- 业务单元编号
    ,'' AS BIZ_UNIT_NAME -- 业务单元名称
    ,'' AS PAY_PROD_NO -- 缴费产品编号
    ,'' AS PAY_PROD_NAME -- 缴费产品名称
    ,P2.BUSI_NO AS MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,'' AS MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,'' AS MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,'' AS MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,'06' AS LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,'' AS PROJ_NO -- 项目编号
    ,'' AS PROJ_NAME -- 项目名称
    ,'' AS LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,'' AS PAY_BIZ_NO -- 缴费业务编号
    ,'' AS TXN_STATUS_CD -- 交易状态代码
    ,'' AS LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,'' AS AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,P1.HOST_CODE AS HOST_RTN_CD -- 主机返回码
    ,P1.HOST_MSG AS HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,'' AS THIRD_PTY_RTN_CD -- 第三方返回码
    ,'' AS THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,'' AS SUMMARY_CD -- 摘要代码
    ,'' AS SUMMARY_DESC -- 摘要描述
    ,'' AS STUD_GRD -- 学生年级
    ,'' AS CHENK_ACCT_CLS_NO -- 对账分类编号
    ,'' AS LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,'' AS AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,'1' AS BAT_PAY_FLAG -- 批量缴费标志
    ,'ODS_MID73' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_MID73_ZJHS_BAT_TA' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,204 AS GRP_SER_NO -- 组序号
FROM
ODS_MID73${version_num}.ODS_MID73_ZJHS_BAT_TA AS P1 -- 华数批量明细表

LEFT JOIN ODS_OSCIP${version_num}.ODS_OSCIP_T_ENTR_TF AS P2 -- 代理单位管理表
       ON P1.ENTR_NO = P2.ENTR_NO
      AND P2.DEL_F = '0'
      AND P2.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BWFMDCIM_TF AS P3 -- 借记卡信息主档文件
       ON P1.CUST_ACCT_NO1 = P3.CDNOAC19
      AND P3.DEL_F = '0'
      AND P3.PT_DT = '${process_date}' 
LEFT JOIN ODS_CORE${version_num}.ODS_CORE_BDFMHQAA_TF AS P4 -- 活期存款账户主档
       ON SUBSTR(P1.CUST_ACCT_NO1,1,15)=SUBSTR(P4.AA01AC15,1,15)
      AND P4.DEL_F = '0'
      AND P4.PT_DT = '${process_date}' 
WHERE  P1.PT_DT = '${process_date}'  AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_04 ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_04 DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_04 PARTITION(PT_DT = '${process_date}')
SELECT
     TXN_SER_NO -- 交易流水号
    ,PLAT_SER_NO -- 平台流水号
    ,ORDER_SER_NO -- 订单流水号
    ,FORE_END_SER_NO -- 前端流水号
    ,HOST_SER_NO -- 主机流水号
    ,THIRD_PTY_SER_NO -- 第三方流水号
    ,UNDO_SER_NO -- 撤销流水号
    ,LOC_BATCH_NO -- 本地批次编号
    ,LIFE_PAY_PAYOFF_BATCH_STATUS_CD -- 生活缴费代发批次状态代码
    ,BATCH_SEQ_NO -- 批次顺序号
    ,PLAT_DT -- 平台日期
    ,ORDER_DT -- 订单日期
    ,TXN_DT -- 交易日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,HOST_TXN_DT -- 主机交易日期
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,THIRD_PTY_TXN_DT -- 第三方交易日期
    ,THIRD_PTY_TXN_TM_STAMP -- 第三方交易时间戳
    ,PAYOFF_TOTAL_AMT -- 代收总金额
    ,AGCOL_FAIL_AMT -- 代收失败金额
    ,AGCOL_ACTL_TXN_AMT -- 代收实际交易金额
    ,TXN_AMT -- 交易金额
    ,COMM_FEE_AMT -- 手续费金额
    ,LATE_FEE -- 滞纳金
    ,LIFE_PAY_TXN_MODE_CD -- 生活缴费交易方式代码
    ,MDL_BIZ_TRAN_CD -- 中间业务交易码
    ,CHNL_CD -- 渠道代码
    ,LIFE_PAY_ACCTN_SEQ_CD -- 生活缴费记账顺序代码
    ,AGEN_CORP_MGMT_ORG_NO -- 代理单位管理机构编号
    ,TXN_ORG_NO -- 交易机构编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,STL_STRU_NO -- 结算机构编号
    ,DEBIT_CRDT_IDNT_CD -- 借贷标识代码
    ,CURR_CD -- 币种代码
    ,CASH_RMT_CD -- 钞汇代码
    ,PAY_CARD_NO -- 缴费卡号
    ,PAY_FEE_ACCT_NO -- 缴费账户编号
    ,PAY_AMT_ACCT_NAME -- 缴费账户名称
    ,OPEN_ACCT_ORG_NO -- 开户机构编号
    ,TRNIN_ACCT_NO -- 转入账户编号
    ,TRNIN_ACCT_NAME -- 转入账户名称
    ,DOC_NO -- 证件号码
    ,CUST_IN_CD -- 客户内码
    ,THIRD_PTY_USER_NO -- 第三方用户编号
    ,BIZ_UNIT_NO -- 业务单元编号
    ,BIZ_UNIT_NAME -- 业务单元名称
    ,PAY_PROD_NO -- 缴费产品编号
    ,PAY_PROD_NAME -- 缴费产品名称
    ,MDL_BIZ_CATE_NO -- 中间业务种类编号
    ,MDL_BIZ_CATE_NAME -- 中间业务种类名称
    ,MDL_BIZ_MDL_CATOGR_NO -- 中间业务中类编号
    ,MDL_BIZ_MDL_CATOGR_NAME -- 中间业务中类名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_1 -- 生活缴费业务类别代码1
    ,PROJ_NO -- 项目编号
    ,PROJ_NAME -- 项目名称
    ,LIFE_PAY_BIZ_CATEGORY_CD_2 -- 生活缴费业务类别代码2
    ,PAY_BIZ_NO -- 缴费业务编号
    ,TXN_STATUS_CD -- 交易状态代码
    ,LIFE_PAY_HOST_ACCTN_STATUS_CD -- 生活缴费主机记账状态代码
    ,AGEN_CORP_REC_ACCT_RESLT_CD -- 代理单位记账结果代码
    ,HOST_RTN_CD -- 主机返回码
    ,HOST_RETURN_INFO_DESC -- 主机返回信息描述
    ,THIRD_PTY_RTN_CD -- 第三方返回码
    ,THIRD_PTY_RETURN_INFO_DESC -- 第三方返回信息描述
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,STUD_GRD -- 学生年级
    ,CHENK_ACCT_CLS_NO -- 对账分类编号
    ,LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD -- 生活缴费主机对账结果代码
    ,AGEN_CORP_CHECK_ENTRY_RESLT_CD -- 代理单位对账结果代码
    ,BAT_PAY_FLAG -- 批量缴费标志
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04
;


/* 4.1 drop temp table */
DROP TABLE AGL${version_num}.AGL_LIFE_PAY_TXN_DTL_TA_TM_04;
