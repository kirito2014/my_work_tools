-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-小额支付对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：小额支付对账差错明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO, CHECK_ENTRY_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建
--         2024-09-18 00:00:00 陈艺丹 修改表名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA_TM
USING ORC
COMMENT '小额支付对账差错明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,CHECK_ENTRY_DT -- 对账日期
    ,MSG_CATEGORY_CD -- 报文类别代码
    ,MSG_NO -- 报文编号
    ,COL_PAY_MNY_IDNT_CD -- 收付款标识代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,MSG_IDE_NO -- 报文标识号
    ,RECV_DIR_PRTCPT_ORG_NO -- 接收直接参与机构编号
    ,TOTAL_CNT -- 总笔数
    ,TXN_TOTAL_AMT -- 交易总金额
    ,NTTG_DT -- 轧差日期
    ,NTTG_SITE_CNT -- 轧差场次
    ,MICRO_HOST_CHECK_ENTRY_STATUS_CD -- 小额主机对账状态代码
    ,DONE_ERR_DEAL_FLAG -- 已做差错处理标志
    ,ERR_DEAL_INFO_DESC -- 差错处理信息描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 小额支付对账差错明细聚合

INSERT INTO TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA_TM(
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,CHECK_ENTRY_DT -- 对账日期
    ,MSG_CATEGORY_CD -- 报文类别代码
    ,MSG_NO -- 报文编号
    ,COL_PAY_MNY_IDNT_CD -- 收付款标识代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,MSG_IDE_NO -- 报文标识号
    ,RECV_DIR_PRTCPT_ORG_NO -- 接收直接参与机构编号
    ,TOTAL_CNT -- 总笔数
    ,TXN_TOTAL_AMT -- 交易总金额
    ,NTTG_DT -- 轧差日期
    ,NTTG_SITE_CNT -- 轧差场次
    ,MICRO_HOST_CHECK_ENTRY_STATUS_CD -- 小额主机对账状态代码
    ,DONE_ERR_DEAL_FLAG -- 已做差错处理标志
    ,ERR_DEAL_INFO_DESC -- 差错处理信息描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.PLAT_DATE AS PLAT_DT -- 平台日期
    ,P1.PLAT_SEQ AS PLAT_SER_NO -- 平台流水号
    ,P1.CHK_DATE AS CHECK_ENTRY_DT -- 对账日期
    ,P1.BUSI_FLAG AS MSG_CATEGORY_CD -- 报文类别代码
    ,P1.MSG_CODE AS MSG_NO -- 报文编号
    ,P1.PMT_FLAG AS COL_PAY_MNY_IDNT_CD -- 收付款标识代码
    ,P1.SR_FLAG AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,P1.BUSI_STAT AS MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,P1.NPC_STAT AS PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,P1.SND_CLRBANK AS INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,P1.MSG_PKGID AS MSG_IDE_NO -- 报文标识号
    ,P1.RCV_CLRBANK AS RECV_DIR_PRTCPT_ORG_NO -- 接收直接参与机构编号
    ,P1.TOT_CNT AS TOTAL_CNT -- 总笔数
    ,P1.TOT_AMT AS TXN_TOTAL_AMT -- 交易总金额
    ,P1.NPC_NETDATE AS NTTG_DT -- 轧差日期
    ,P1.NPC_NETGRND AS NTTG_SITE_CNT -- 轧差场次
    ,P1.CHK_RSLT AS MICRO_HOST_CHECK_ENTRY_STATUS_CD -- 小额主机对账状态代码
    ,CASE WHEN P1.PROC_FLAG='0' THEN 'N' ELSE 'Y' END AS DONE_ERR_DEAL_FLAG -- 已做差错处理标志
    ,P1.PROC_MSG AS ERR_DEAL_INFO_DESC -- 差错处理信息描述
    ,'PYMT' AS SRC_SYS_CD -- 来源系统代码
    ,'t_beps_chkerr'  AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_PYMT.ODS_PYMT_T_BEPS_CHKERR_TF AS None -- 小额对账差错表

WHERE P1.PT_DT='${process_date}' AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
INSERT INTO AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA PARTITION(PT_DT = '${process_date}')
SELECT
     PLAT_DT -- 平台日期
    ,PLAT_SER_NO -- 平台流水号
    ,CHECK_ENTRY_DT -- 对账日期
    ,MSG_CATEGORY_CD -- 报文类别代码
    ,MSG_NO -- 报文编号
    ,COL_PAY_MNY_IDNT_CD -- 收付款标识代码
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,PBC_AGEN_PAY_BIZ_STATUS_CD -- 人行代理支付业务状态代码
    ,INIT_LIQD_BANK_CNAPS_CODE -- 发起清算行人行支付行号
    ,MSG_IDE_NO -- 报文标识号
    ,RECV_DIR_PRTCPT_ORG_NO -- 接收直接参与机构编号
    ,TOTAL_CNT -- 总笔数
    ,TXN_TOTAL_AMT -- 交易总金额
    ,NTTG_DT -- 轧差日期
    ,NTTG_SITE_CNT -- 轧差场次
    ,MICRO_HOST_CHECK_ENTRY_STATUS_CD -- 小额主机对账状态代码
    ,DONE_ERR_DEAL_FLAG -- 已做差错处理标志
    ,ERR_DEAL_INFO_DESC -- 差错处理信息描述
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA_TM;
