-- 模板名称: 聚合层-流水表-区间流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVP-第三方快捷支付交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 15:10:00
-- 脚本类型: DML
-- 注意: 1.辅助字段【ETL_PERIOD_DT STRING COMMENT 'ETL区间日期'】需要显式的填写到SDM文档映射每组目标为主临时表_TM的字段映射里面。
--       2.参数 ${interval_flow_dt} 区间起始日期 由配置任务时候选择区间天数，DataOps作业跑批时候会自动计算。
-- 修改日志:
--     表英文名：AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG
--     表中文名：第三方快捷支付交易明细聚合
--     创建日期：2023-12-19 00:00:00
--     主键字段：MSG_NO
--     归属层次：AGL-EVP
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-28 00:00:00 游崔龙 新增
--         2024-01-19 00:00:00 游崔龙 对标
--         2024-08-03 00:00:00 魏丹丹 证件号码，客户证件类型代码，数据来源更改，主键修改
--         2024-08-24 00:00:00 魏丹丹 修改取数逻辑，增加快捷支付交易发起渠道代码、快捷支付渠道代码码值映射
--         2024-09-04 00:00:00 魏丹丹 加表，修改PAYER_ACCT_NO取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.0 drop old backup table */
DROP TABLE IF EXISTS AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_BK;

/* 1.1 backup before batch_date data */
CREATE TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_BK
USING ORC
COMMENT '第三方快捷支付交易明细聚合-历史区间数据备份表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,CUST_IN_CD -- 客户内码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CARD_AFLT_ORG_NO -- 卡所属机构编号
    ,PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,PAYER_USER_ID -- 付款方用户ID
    ,PAYER_NAME -- 付款方名称
    ,PAYER_TXN_UNION_BANK -- 付款方交易联行号
    ,PAYER_TXN_UNION_BANK_NAME -- 付款方交易联行名称
    ,PAYER_MEM_UNION_BANK -- 付款方成员联行号
    ,PAYER_MEM_UNION_BANK_NAME -- 付款方成员联行名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,PAYER_ACCT_BELONG_ORG_NAME -- 付款方账户归属机构名称
    ,PAYER_OPEN_ACCT_UNION_BANK -- 付款方开户联行号
    ,PAYER_OPEN_ACCT_UBANK_NAME -- 付款方开户联行名称
    ,PAYER_ACCT_NO_TYPE_CD -- 付款方账号类型代码
    ,PAYEE_ACCT_NO -- 收款方账户编号
    ,PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,PAYEE_USER_ID -- 收款方用户ID
    ,PAYEE_NAME -- 收款方名称
    ,PAYEE_TXN_UNION_BANK -- 收款方交易联行号
    ,PAYEE_TXN_UNION_BANK_NAME -- 收款方交易联行名称
    ,PAYEE_ACCT_NO_TYPE_CD -- 收款方账号类型代码
    ,PAYEE_MEM_UNION_BANK -- 收款方成员联行号
    ,PAYEE_MEM_UNION_BANK_NAME -- 收款方成员联行名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,PAYEE_ACCT_BELONG_ORG_NAME -- 收款方账户归属机构名称
    ,PAYEE_OPBANK_NO -- 收款方开户行行号
    ,PAYEE_ACCT_TYPE_CD -- 收款方账户类型代码
    ,ORDER_TXN_PLAT_NAME -- 订单交易平台名称
    ,ORDER_PAYEE_NAME -- 订单收款方名称
    ,CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,TXN_ORDER_NO -- 交易订单编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_SUCC_AMT -- 交易成功金额
    ,FAST_PAY_TXN_TYPE_CD -- 快捷支付交易类型代码
    ,TXN_DTL_INFO_DESC -- 交易详情信息描述
    ,TXN_ERR_INFO_DESC -- 交易错误信息描述
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,FAST_PAY_TXN_INIT_CHNL_CD -- 快捷支付交易发起渠道代码
    ,RTN_GOODS_FLAG -- 退货标志
    ,REFUND_AMT -- 退款金额
    ,RESP_STATUS_INFO_DESC -- 响应状态信息描述
    ,FAST_PAY_CHNL_CD -- 快捷支付渠道代码
    ,FAST_PAY_TXN_STATUS_CD -- 快捷支付交易状态代码
    ,ERR_INFO_DESC -- 错误信息描述
    ,BELONG_CORE_PLAT_CD -- 归属核心平台代码
    ,ASSIGN_DEBIT_PASS_CD -- 指定借方通道代码
    ,ASSIGN_CRDT_PASS_CD -- 指定贷方通道代码
    ,THIRD_PTY_FAST_BIZ_TYPE_CD -- 第三方快捷业务类型代码
    ,THIRD_PTY_FAST_BIZ_CATE_CD -- 第三方快捷业务种类代码
    ,RECORD_STATUS_CD -- 入账状态代码
    ,ACCTN_FLAG -- 记账标志
    ,RSPS_CD -- 响应码
    ,MSG_NO -- 报文编号
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,ORIG_MSG_TXN_NO -- 原报文交易编号
    ,MSG_SEND_BANK_NO -- 报文发送行号
    ,MSG_SEND_ROW_BRCH_BANK_NO -- 报文发送行分行号
    ,MSG_RECV_BANK_NO -- 报文接收行号
    ,MSG_RECV_BANK_BRCH_BANK_NO -- 报文接收行分行号
    ,IN_BANK_MSG_TYPE_NO -- 行内报文类型编号
    ,MSG_RECV_TM_STAMP -- 报文接收时间戳
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,RURAL_CRDT_MSG_TYPE_NO -- NPS农信银报文类型编号
    ,EXT_RESP_MSG_NO -- 外部响应报文编号
    ,PASS_MSG_SEND_TM_STAMP -- 通道报文发送时间戳
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,AUTH_CD -- 授权码
    ,AUTH_DOCTYP_CD -- 授权证件类型代码
    ,AUTH_DOC_NO -- 授权证件号码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,ETL_LAST_ACG_DT -- ETL更新日期
    ,PT_DT -- ETL区间日期
FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG
WHERE PT_DT < '${process_date}' AND PT_DT > '${interval_flow_dt}';


/* 2.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_TM;

/* 2.2 create main temp table  */
CREATE TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_TM
USING ORC
COMMENT '第三方快捷支付交易明细聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,CUST_IN_CD -- 客户内码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CARD_AFLT_ORG_NO -- 卡所属机构编号
    ,PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,PAYER_USER_ID -- 付款方用户ID
    ,PAYER_NAME -- 付款方名称
    ,PAYER_TXN_UNION_BANK -- 付款方交易联行号
    ,PAYER_TXN_UNION_BANK_NAME -- 付款方交易联行名称
    ,PAYER_MEM_UNION_BANK -- 付款方成员联行号
    ,PAYER_MEM_UNION_BANK_NAME -- 付款方成员联行名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,PAYER_ACCT_BELONG_ORG_NAME -- 付款方账户归属机构名称
    ,PAYER_OPEN_ACCT_UNION_BANK -- 付款方开户联行号
    ,PAYER_OPEN_ACCT_UBANK_NAME -- 付款方开户联行名称
    ,PAYER_ACCT_NO_TYPE_CD -- 付款方账号类型代码
    ,PAYEE_ACCT_NO -- 收款方账户编号
    ,PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,PAYEE_USER_ID -- 收款方用户ID
    ,PAYEE_NAME -- 收款方名称
    ,PAYEE_TXN_UNION_BANK -- 收款方交易联行号
    ,PAYEE_TXN_UNION_BANK_NAME -- 收款方交易联行名称
    ,PAYEE_ACCT_NO_TYPE_CD -- 收款方账号类型代码
    ,PAYEE_MEM_UNION_BANK -- 收款方成员联行号
    ,PAYEE_MEM_UNION_BANK_NAME -- 收款方成员联行名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,PAYEE_ACCT_BELONG_ORG_NAME -- 收款方账户归属机构名称
    ,PAYEE_OPBANK_NO -- 收款方开户行行号
    ,PAYEE_ACCT_TYPE_CD -- 收款方账户类型代码
    ,ORDER_TXN_PLAT_NAME -- 订单交易平台名称
    ,ORDER_PAYEE_NAME -- 订单收款方名称
    ,CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,TXN_ORDER_NO -- 交易订单编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_SUCC_AMT -- 交易成功金额
    ,FAST_PAY_TXN_TYPE_CD -- 快捷支付交易类型代码
    ,TXN_DTL_INFO_DESC -- 交易详情信息描述
    ,TXN_ERR_INFO_DESC -- 交易错误信息描述
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,FAST_PAY_TXN_INIT_CHNL_CD -- 快捷支付交易发起渠道代码
    ,RTN_GOODS_FLAG -- 退货标志
    ,REFUND_AMT -- 退款金额
    ,RESP_STATUS_INFO_DESC -- 响应状态信息描述
    ,FAST_PAY_CHNL_CD -- 快捷支付渠道代码
    ,FAST_PAY_TXN_STATUS_CD -- 快捷支付交易状态代码
    ,ERR_INFO_DESC -- 错误信息描述
    ,BELONG_CORE_PLAT_CD -- 归属核心平台代码
    ,ASSIGN_DEBIT_PASS_CD -- 指定借方通道代码
    ,ASSIGN_CRDT_PASS_CD -- 指定贷方通道代码
    ,THIRD_PTY_FAST_BIZ_TYPE_CD -- 第三方快捷业务类型代码
    ,THIRD_PTY_FAST_BIZ_CATE_CD -- 第三方快捷业务种类代码
    ,RECORD_STATUS_CD -- 入账状态代码
    ,ACCTN_FLAG -- 记账标志
    ,RSPS_CD -- 响应码
    ,MSG_NO -- 报文编号
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,ORIG_MSG_TXN_NO -- 原报文交易编号
    ,MSG_SEND_BANK_NO -- 报文发送行号
    ,MSG_SEND_ROW_BRCH_BANK_NO -- 报文发送行分行号
    ,MSG_RECV_BANK_NO -- 报文接收行号
    ,MSG_RECV_BANK_BRCH_BANK_NO -- 报文接收行分行号
    ,IN_BANK_MSG_TYPE_NO -- 行内报文类型编号
    ,MSG_RECV_TM_STAMP -- 报文接收时间戳
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,RURAL_CRDT_MSG_TYPE_NO -- NPS农信银报文类型编号
    ,EXT_RESP_MSG_NO -- 外部响应报文编号
    ,PASS_MSG_SEND_TM_STAMP -- 通道报文发送时间戳
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,AUTH_CD -- 授权码
    ,AUTH_DOCTYP_CD -- 授权证件类型代码
    ,AUTH_DOC_NO -- 授权证件号码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS ETL_PERIOD_DT -- ETL区间日期
FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG WHERE 0=1 ;


/* 2.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_TM;

/* 3.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 第三方快捷支付交易明细聚合

INSERT INTO TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_TM(
     TXN_SER_NO -- 交易流水号
    ,TXN_DT -- 交易日期
    ,CUST_IN_CD -- 客户内码
    ,CUST_MOBILE_NO -- 客户手机号码
    ,CUST_DOC_NO -- 客户证件号码
    ,CUST_DOCTYP_CD -- 客户证件类型代码
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,PAYER_ACCT_NO -- 付款方账户编号
    ,PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,CARD_AFLT_ORG_NO -- 卡所属机构编号
    ,PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,PAYER_USER_ID -- 付款方用户ID
    ,PAYER_NAME -- 付款方名称
    ,PAYER_TXN_UNION_BANK -- 付款方交易联行号
    ,PAYER_TXN_UNION_BANK_NAME -- 付款方交易联行名称
    ,PAYER_MEM_UNION_BANK -- 付款方成员联行号
    ,PAYER_MEM_UNION_BANK_NAME -- 付款方成员联行名称
    ,PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,PAYER_ACCT_BELONG_ORG_NAME -- 付款方账户归属机构名称
    ,PAYER_OPEN_ACCT_UNION_BANK -- 付款方开户联行号
    ,PAYER_OPEN_ACCT_UBANK_NAME -- 付款方开户联行名称
    ,PAYER_ACCT_NO_TYPE_CD -- 付款方账号类型代码
    ,PAYEE_ACCT_NO -- 收款方账户编号
    ,PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,PAYEE_USER_ID -- 收款方用户ID
    ,PAYEE_NAME -- 收款方名称
    ,PAYEE_TXN_UNION_BANK -- 收款方交易联行号
    ,PAYEE_TXN_UNION_BANK_NAME -- 收款方交易联行名称
    ,PAYEE_ACCT_NO_TYPE_CD -- 收款方账号类型代码
    ,PAYEE_MEM_UNION_BANK -- 收款方成员联行号
    ,PAYEE_MEM_UNION_BANK_NAME -- 收款方成员联行名称
    ,PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,PAYEE_ACCT_BELONG_ORG_NAME -- 收款方账户归属机构名称
    ,PAYEE_OPBANK_NO -- 收款方开户行行号
    ,PAYEE_ACCT_TYPE_CD -- 收款方账户类型代码
    ,ORDER_TXN_PLAT_NAME -- 订单交易平台名称
    ,ORDER_PAYEE_NAME -- 订单收款方名称
    ,CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,TXN_ORDER_NO -- 交易订单编号
    ,TXN_TM_STAMP -- 交易时间戳
    ,TXN_AMT -- 交易金额
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_SUCC_AMT -- 交易成功金额
    ,FAST_PAY_TXN_TYPE_CD -- 快捷支付交易类型代码
    ,TXN_DTL_INFO_DESC -- 交易详情信息描述
    ,TXN_ERR_INFO_DESC -- 交易错误信息描述
    ,HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,FAST_PAY_TXN_INIT_CHNL_CD -- 快捷支付交易发起渠道代码
    ,RTN_GOODS_FLAG -- 退货标志
    ,REFUND_AMT -- 退款金额
    ,RESP_STATUS_INFO_DESC -- 响应状态信息描述
    ,FAST_PAY_CHNL_CD -- 快捷支付渠道代码
    ,FAST_PAY_TXN_STATUS_CD -- 快捷支付交易状态代码
    ,ERR_INFO_DESC -- 错误信息描述
    ,BELONG_CORE_PLAT_CD -- 归属核心平台代码
    ,ASSIGN_DEBIT_PASS_CD -- 指定借方通道代码
    ,ASSIGN_CRDT_PASS_CD -- 指定贷方通道代码
    ,THIRD_PTY_FAST_BIZ_TYPE_CD -- 第三方快捷业务类型代码
    ,THIRD_PTY_FAST_BIZ_CATE_CD -- 第三方快捷业务种类代码
    ,RECORD_STATUS_CD -- 入账状态代码
    ,ACCTN_FLAG -- 记账标志
    ,RSPS_CD -- 响应码
    ,MSG_NO -- 报文编号
    ,MSG_CONT_DIR_CD -- 报文往来方向代码
    ,MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,ORIG_MSG_TXN_NO -- 原报文交易编号
    ,MSG_SEND_BANK_NO -- 报文发送行号
    ,MSG_SEND_ROW_BRCH_BANK_NO -- 报文发送行分行号
    ,MSG_RECV_BANK_NO -- 报文接收行号
    ,MSG_RECV_BANK_BRCH_BANK_NO -- 报文接收行分行号
    ,IN_BANK_MSG_TYPE_NO -- 行内报文类型编号
    ,MSG_RECV_TM_STAMP -- 报文接收时间戳
    ,MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,RURAL_CRDT_MSG_TYPE_NO -- NPS农信银报文类型编号
    ,EXT_RESP_MSG_NO -- 外部响应报文编号
    ,PASS_MSG_SEND_TM_STAMP -- 通道报文发送时间戳
    ,END_TO_END_IDE_NO -- 端到端标识号
    ,AUTH_CD -- 授权码
    ,AUTH_DOCTYP_CD -- 授权证件类型代码
    ,AUTH_DOC_NO -- 授权证件号码
    ,PLAT_CLEAR_DT -- 平台清算日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,ETL_PERIOD_DT -- ETL区间日期
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.ORDER_ID AS TXN_SER_NO -- 交易流水号
    ,SUBSTR(CAST(P1.TRANS_TIME AS STRING),1,10) AS TXN_DT -- 交易日期
    ,CASE WHEN LENGTH(P1.DBTR_CLIENT_CODE)=11 THEN P1.DBTR_CLIENT_CODE
     WHEN LENGTH(P1.DBTR_CLIENT_CODE)=14 THEN P2.CST_IN_CD
     ELSE ''
END AS CUST_IN_CD -- 客户内码
    ,P1.MOBILENUMBER AS CUST_MOBILE_NO -- 客户手机号码
    ,P2.CRTF_NO AS CUST_DOC_NO -- 客户证件号码
    ,P2.CRTF_TYP AS CUST_DOCTYP_CD -- 客户证件类型代码
    ,P4.OBANK_STF AS OBANK_EMPLY_FLAG -- 本行员工标志
    ,COALESCE(P5.DFANAC19,T5.XACCOUNT,T6.CUSTAC) AS PAYER_ACCT_NO -- 付款方账户编号
    ,P1.DBTR_ACCT_ID AS PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,P1.POSTING_OFFICE_ID AS CARD_AFLT_ORG_NO -- 卡所属机构编号
    ,P1.FSTDB_ACCT_ID AS PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,CASE WHEN LENGTH(P1.DBTR_CLIENT_CODE)=11 THEN T2.USER_ID
     WHEN LENGTH(P1.DBTR_CLIENT_CODE)=14 THEN P1.DBTR_CLIENT_CODE
     ELSE ''
END AS PAYER_USER_ID -- 付款方用户ID
    ,P1.DBTR_NM AS PAYER_NAME -- 付款方名称
    ,P1.DBTR_INST_ID AS PAYER_TXN_UNION_BANK -- 付款方交易联行号
    ,P6.HHMC AS PAYER_TXN_UNION_BANK_NAME -- 付款方交易联行名称
    ,P1.DBTR_MEMB_ID AS PAYER_MEM_UNION_BANK -- 付款方成员联行号
    ,P7.HHMC AS PAYER_MEM_UNION_BANK_NAME -- 付款方成员联行名称
    ,P5.OWONBRNO AS PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,P8.ORCAFLNM AS PAYER_ACCT_BELONG_ORG_NAME -- 付款方账户归属机构名称
    ,P1.DBTR_ISSR_ID AS PAYER_OPEN_ACCT_UNION_BANK -- 付款方开户联行号
    ,T7.HHMC AS PAYER_OPEN_ACCT_UBANK_NAME -- 付款方开户联行名称
    ,P1.DBTR_ACCT_TP AS PAYER_ACCT_NO_TYPE_CD -- 付款方账号类型代码
    ,P1.CDTR_ACCT_ID AS PAYEE_ACCT_NO -- 收款方账户编号
    ,P1.FSTCD_ACCT_ID AS PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,P1.CDTR_CLIENT_CODE AS PAYEE_USER_ID -- 收款方用户ID
    ,P1.CDTR_NM AS PAYEE_NAME -- 收款方名称
    ,P1.CDTR_ID AS PAYEE_TXN_UNION_BANK -- 收款方交易联行号
    ,P9.HHMC AS PAYEE_TXN_UNION_BANK_NAME -- 收款方交易联行名称
    ,P1.CDTR_ACCT_TP AS PAYEE_ACCT_NO_TYPE_CD -- 收款方账号类型代码
    ,P1.CDTR_AGT_ID AS PAYEE_MEM_UNION_BANK -- 收款方成员联行号
    ,P10.HHMC AS PAYEE_MEM_UNION_BANK_NAME -- 收款方成员联行名称
    ,P11.OWONBRNO AS PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,P12.ORCAFLNM AS PAYEE_ACCT_BELONG_ORG_NAME -- 收款方账户归属机构名称
    ,P1.CDTR_ISSR_ID AS PAYEE_OPBANK_NO -- 收款方开户行行号
    ,P1.DBTR_ACCT_LV AS PAYEE_ACCT_TYPE_CD -- 收款方账户类型代码
    ,(CASE WHEN P1.cust_remit_info like '%CNMrchntPltfrmNm:%'
      THEN SPLIT(SPLIT(P1.cust_remit_info,'CNMrchntPltfrmNm:')[1],';')[0]
   ELSE ''
END) AS ORDER_TXN_PLAT_NAME -- 订单交易平台名称
    ,(CASE WHEN P1.cust_remit_info like '%CNOrdrDesc:%'
      THEN SPLIT(SUBSTR(SPLIT(P1.cust_remit_info,'CNOrdrDesc:')[1],5,100),'%')[0]
      ELSE ''
END) AS ORDER_PAYEE_NAME -- 订单收款方名称
    ,P1.MND AS CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,P1.TXN_ID AS TXN_ORDER_NO -- 交易订单编号
    ,unifiedTime(P1.TRANS_TIME) AS TXN_TM_STAMP -- 交易时间戳
    ,P1.STTL_AMT AS TXN_AMT -- 交易金额
    ,P1.STTL_AMT_CCY AS TXN_CURR_CD -- 交易币种代码
    ,P1.ACTUAL_STTL_AMT AS TXN_SUCC_AMT -- 交易成功金额
    ,CASE WHEN P1.TXN_TYPE IS NULL OR TRIM(P1.TXN_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(P13.TARGET_CD_VAL), CONCAT('@',TRIM(P1.TXN_TYPE)),'')
END AS FAST_PAY_TXN_TYPE_CD -- 快捷支付交易类型代码
    ,P1.CUST_REMIT_INFO AS TXN_DTL_INFO_DESC -- 交易详情信息描述
    ,P1.ERROR_CODE AS TXN_ERR_INFO_DESC -- 交易错误信息描述
    ,unifiedTime(P1.CAPTURE_TIME) AS HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,CASE WHEN P1.CHANNEL_TYPE IS NULL OR TRIM(P1.CHANNEL_TYPE)=''
     THEN ''
     ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CHANNEL_TYPE)),'')
END AS FAST_PAY_TXN_INIT_CHNL_CD -- 快捷支付交易发起渠道代码
    ,P1.REVOKE_FLG AS RTN_GOODS_FLAG -- 退货标志
    ,P1.R_STTL_AMT AS REFUND_AMT -- 退款金额
    ,P1.RES_MSG AS RESP_STATUS_INFO_DESC -- 响应状态信息描述
    ,CASE WHEN P1.CHAN_ID IS NULL OR TRIM(P1.CHAN_ID)=''
     THEN ''
     ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CHAN_ID)),'')
END AS FAST_PAY_CHNL_CD -- 快捷支付渠道代码
    ,P1.MSG_STS AS FAST_PAY_TXN_STATUS_CD -- 快捷支付交易状态代码
    ,P1.ERROR_DESP AS ERR_INFO_DESC -- 错误信息描述
    ,P1.BIZ_INST_ID AS BELONG_CORE_PLAT_CD -- 归属核心平台代码
    ,P1.CAL_CDTR_ID AS ASSIGN_DEBIT_PASS_CD -- 指定借方通道代码
    ,P1.CAL_DBTR_ID AS ASSIGN_CRDT_PASS_CD -- 指定贷方通道代码
    ,P1.BIZ_CATEGORY AS THIRD_PTY_FAST_BIZ_TYPE_CD -- 第三方快捷业务类型代码
    ,P1.BIZ_PURP AS THIRD_PTY_FAST_BIZ_CATE_CD -- 第三方快捷业务种类代码
    ,SUBSTR(P1.POSTING_STS,1,2) AS RECORD_STATUS_CD -- 入账状态代码
    ,P1.RECON_ID AS ACCTN_FLAG -- 记账标志
    ,P1.RESP_CODE AS RSPS_CD -- 响应码
    ,P1.MSG_ID AS MSG_NO -- 报文编号
    ,P1.IO_FLG AS MSG_CONT_DIR_CD -- 报文往来方向代码
    ,P1.PROC_STS AS MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,P1.ORGL_TXNID AS ORIG_MSG_TXN_NO -- 原报文交易编号
    ,P1.SNDR_ID AS MSG_SEND_BANK_NO -- 报文发送行号
    ,P1.SNDR_BRNCH_ID AS MSG_SEND_ROW_BRCH_BANK_NO -- 报文发送行分行号
    ,P1.RCVR_ID AS MSG_RECV_BANK_NO -- 报文接收行号
    ,P1.RCVR_BRNCH_ID AS MSG_RECV_BANK_BRCH_BANK_NO -- 报文接收行分行号
    ,P1.MSG_TYPE AS IN_BANK_MSG_TYPE_NO -- 行内报文类型编号
    ,unifiedTime(P1.CREATE_TIME) AS MSG_RECV_TM_STAMP -- 报文接收时间戳
    ,unifiedTime(P1.SEND_TIME) AS MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,P1.EXT_MSG_TP AS RURAL_CRDT_MSG_TYPE_NO -- NPS农信银报文类型编号
    ,P1.EXT_MSG_ID_RESP AS EXT_RESP_MSG_NO -- 外部响应报文编号
    ,unifiedTime(P1.TUNNEL_CREATE_DATE) AS PASS_MSG_SEND_TM_STAMP -- 通道报文发送时间戳
    ,P1.ENDTOENDID AS END_TO_END_IDE_NO -- 端到端标识号
    ,P1.AUTH_ID AS AUTH_CD -- 授权码
    ,P1.AUTH_CERT_TP AS AUTH_DOCTYP_CD -- 授权证件类型代码
    ,P1.AUTH_CERT_NM AS AUTH_DOC_NO -- 授权证件号码
    ,P1.SP_STTL_DT AS PLAT_CLEAR_DT -- 平台清算日期
    ,unifiedTime(P1.UPDATE_TIME) AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P1.LAST_ETL_ACG_DT AS ETL_PERIOD_DT -- ETL区间日期
    ,'UPP' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_UPP_SP_PAY_SIMPLE_TG' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
ODS_UPP.ODS_UPP_SP_PAY_SIMPLE_TG AS P1 -- 支付减水表

LEFT JOIN ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF AS P2 -- 内部用户信息表
       ON TRIM(P1.DBTR_CLIENT_CODE) = TRIM(P2.USER_ID) AND P2.PT_DT = '${process_date}'  AND P2.DEL_F='0' 
LEFT JOIN (
SELECT * FROM(
  SELECT
     USER_ID
    ,CST_IN_CD
    ,ROW_NUMBER() OVER(PARTITION BY CST_IN_CD ORDER BY ID DESC) RN
  FROM ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF
  WHERE PT_DT = '${process_date}'  AND DEL_F='0'
  )WHERE RN=1
) AS T2 -- 内部用户信息表
       ON TRIM(P1.DBTR_CLIENT_CODE) = TRIM(T2.CST_IN_CD) 
LEFT JOIN ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF AS P3 -- 客户证件信息表
       ON P2.CST_IN_CD=P3.CST_IN_CD AND P2.CRTF_TYP=P3.CRTF_TYP AND P2.CRTF_NO=P3.CRTF_NO AND P3.PT_DT = '${process_date}' AND P3.DEL_F='0' 
LEFT JOIN ODS_EICC.ODS_EICC_C_CUS_PRIV_SOCIAL_TF AS P4 -- 客户社会信息
       ON P2.CST_IN_CD = P4.CST_IN_CD AND SUBSTR(P1.POSTING_OFFICE_ID,1,3)||'000'=P4.CORP_ORG_NO  AND P4.PT_DT = '${process_date}' AND P4.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P5 -- 借记卡信息主档
       ON TRIM(P1.DBTR_ACCT_ID) = TRIM(P5.CDNOAC19) AND P5.PT_DT = '${process_date}' AND P5.DEL_F='0' 
LEFT JOIN ODS_CCRD.ODS_CCRD_CARD_TF AS T5 -- 卡片资料表
       ON TRIM(P1.DBTR_ACCT_ID)  = TRIM(T5.CARD_NBR) AND T5.PT_DT = '${process_date}' AND T5.DEL_F='0' 
LEFT JOIN ODS_NAS.ODS_NAS_KNA_ACDC_TF AS T6 -- 电子账户表
       ON TRIM(P1.DBTR_ACCT_ID) = TRIM(T6.CARDNO)  AND T6.PT_DT = '${process_date}' AND T6.DEL_F='0' 
LEFT JOIN ODS_UPPRUN.ODS_UPPRUN_ZPS_BANK_TF AS P6 -- 农信银支付系统号表
       ON P1.DBTR_INST_ID = P6.HH AND P6.PT_DT = '${process_date}' AND P6.DEL_F='0' 
LEFT JOIN ODS_UPPRUN.ODS_UPPRUN_ZPS_BANK_TF AS P7 -- 农信银支付系统号表
       ON P1.DBTR_MEMB_ID = P7.HH AND P7.PT_DT = '${process_date}'  AND P7.DEL_F='0' 
LEFT JOIN ODS_UPPRUN.ODS_UPPRUN_ZPS_BANK_TF AS T7 -- 农信银支付系统号表
       ON P1.DBTR_ISSR_ID = T7.HH AND T7.PT_DT = '${process_date}'  AND T7.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BBFMORGA_TF AS P8 -- 机构信息表
       ON CONCAT(SUBSTR(P5.OWONBRNO,1,3),'000') = P8.ORCABRNO AND P8.PT_DT = '${process_date}' AND P8.DEL_F='0' 
LEFT JOIN ODS_UPPRUN.ODS_UPPRUN_ZPS_BANK_TF AS P9 -- 农信银支付系统号表
       ON P1.CDTR_ID = P9.HH AND P9.PT_DT = '${process_date}'  AND P9.DEL_F='0' 
LEFT JOIN ODS_UPPRUN.ODS_UPPRUN_ZPS_BANK_TF AS P10 -- 农信银支付系统号表
       ON P1.CDTR_AGT_ID = P10.HH AND P10.PT_DT = '${process_date}'  AND P10.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BWFMDCIM_TF AS P11 -- 借记卡信息主档
       ON P1.CDTR_ACCT_ID = P11.CDNOAC19 AND P11.PT_DT = '${process_date}'  AND P11.DEL_F='0' 
LEFT JOIN ODS_CORE.ODS_CORE_BBFMORGA_TF AS P12 -- 机构信息表
       ON P11.OWONBRNO = P12.ORCABRNO AND P12.PT_DT = '${process_date}'  AND P12.DEL_F='0' 
LEFT JOIN AGL.PUB_CD_MAP AS P13 -- 代码转换
       ON P1.TXN_TYPE=P13.SRC_CD_VAL  
AND P13.SRC_TAB_LIB_NAME ='UPP'  --源系统
AND P13.SRC_TAB_EN_NAME='SP_PAY_SIMPLE' --来源表英文名  
AND P13.SRC_FIELD_EN_NAME='TXN_TYPE' --来源字段英文名 
AND P13.TARGET_TAB_EN_NAME='AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG'  --目标表名   
AND P13.TARGET_FIELD_EN_NAME='FAST_PAY_TXN_TYPE_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S1 -- 代码转换
       ON P1.CHANNEL_TYPE=S1.SRC_CD_VAL  
AND S1.SRC_TAB_LIB_NAME ='UPP'  --源系统
AND S1.SRC_TAB_EN_NAME='SP_PAY_SIMPLE' --来源表英文名  
AND S1.SRC_FIELD_EN_NAME='CHANNEL_TYPE' --来源字段英文名 
AND S1.TARGET_TAB_EN_NAME='AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG'  --目标表名   
AND S1.TARGET_FIELD_EN_NAME='FAST_PAY_TXN_INIT_CHNL_CD' --目标字段 
LEFT JOIN AGL.PUB_CD_MAP AS S2 -- 代码转换
       ON P1.CHAN_ID=S2.SRC_CD_VAL  
AND S2.SRC_TAB_LIB_NAME ='UPP'  --源系统
AND S2.SRC_TAB_EN_NAME='SP_PAY_SIMPLE' --来源表英文名  
AND S2.SRC_FIELD_EN_NAME='CHAN_ID' --来源字段英文名 
AND S2.TARGET_TAB_EN_NAME='AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG'  --目标表名   
AND S2.TARGET_FIELD_EN_NAME='FAST_PAY_CHNL_CD' --目标字段 
WHERE P1.chan_id in ('JDPAY'
,'BAIFUBAO'
,'99BILL'
,'PINGANFU' 
,'ALIPAY'
,'TENPAY'
,'BESTPAY'
,'NWPAY' 
,'YDPAY' 
,'SUNINGPAY' 
,'MEITUANPAY' 
,'19PAY' 
,'PDDPAY'
,'DYPAY'
,'YIPAY')
AND CAST(P1.LAST_ETL_ACG_DT AS STRING) <='${process_date}' AND CAST(P1.LAST_ETL_ACG_DT AS STRING)> '${interval_flow_dt}'  AND P1.PT_DT='${process_date}' AND P1.DEL_F='0' 
;

/* 4.1 drop target table's period partition */
ALTER TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG DROP IF EXISTS PARTITION(PT_DT > '${interval_flow_dt}');

/* 4.2 put data into target table */
INSERT INTO AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG
SELECT
     TM.TXN_SER_NO -- 交易流水号
    ,TM.TXN_DT -- 交易日期
    ,TM.CUST_IN_CD -- 客户内码
    ,TM.CUST_MOBILE_NO -- 客户手机号码
    ,TM.CUST_DOC_NO -- 客户证件号码
    ,TM.CUST_DOCTYP_CD -- 客户证件类型代码
    ,TM.OBANK_EMPLY_FLAG -- 本行员工标志
    ,TM.PAYER_ACCT_NO -- 付款方账户编号
    ,TM.PAYER_PAY_CARD_NO -- 付款方支付卡号
    ,TM.CARD_AFLT_ORG_NO -- 卡所属机构编号
    ,TM.PAYER_CLEAR_ACCT_NO -- 付款方清算账户编号
    ,TM.PAYER_USER_ID -- 付款方用户ID
    ,TM.PAYER_NAME -- 付款方名称
    ,TM.PAYER_TXN_UNION_BANK -- 付款方交易联行号
    ,TM.PAYER_TXN_UNION_BANK_NAME -- 付款方交易联行名称
    ,TM.PAYER_MEM_UNION_BANK -- 付款方成员联行号
    ,TM.PAYER_MEM_UNION_BANK_NAME -- 付款方成员联行名称
    ,TM.PAYER_ACCT_BELONG_ORG_NO -- 付款方账户归属机构编号
    ,TM.PAYER_ACCT_BELONG_ORG_NAME -- 付款方账户归属机构名称
    ,TM.PAYER_OPEN_ACCT_UNION_BANK -- 付款方开户联行号
    ,TM.PAYER_OPEN_ACCT_UBANK_NAME -- 付款方开户联行名称
    ,TM.PAYER_ACCT_NO_TYPE_CD -- 付款方账号类型代码
    ,TM.PAYEE_ACCT_NO -- 收款方账户编号
    ,TM.PAYEE_CLEAR_ACCT_NO -- 收款方清算账户编号
    ,TM.PAYEE_USER_ID -- 收款方用户ID
    ,TM.PAYEE_NAME -- 收款方名称
    ,TM.PAYEE_TXN_UNION_BANK -- 收款方交易联行号
    ,TM.PAYEE_TXN_UNION_BANK_NAME -- 收款方交易联行名称
    ,TM.PAYEE_ACCT_NO_TYPE_CD -- 收款方账号类型代码
    ,TM.PAYEE_MEM_UNION_BANK -- 收款方成员联行号
    ,TM.PAYEE_MEM_UNION_BANK_NAME -- 收款方成员联行名称
    ,TM.PAYEE_ACCT_BELONG_ORG_NO -- 收款方账户归属机构编号
    ,TM.PAYEE_ACCT_BELONG_ORG_NAME -- 收款方账户归属机构名称
    ,TM.PAYEE_OPBANK_NO -- 收款方开户行行号
    ,TM.PAYEE_ACCT_TYPE_CD -- 收款方账户类型代码
    ,TM.ORDER_TXN_PLAT_NAME -- 订单交易平台名称
    ,TM.ORDER_PAYEE_NAME -- 订单收款方名称
    ,TM.CONT_SIGN_AGT_NO -- 合约签约协议编号
    ,TM.TXN_ORDER_NO -- 交易订单编号
    ,TM.TXN_TM_STAMP -- 交易时间戳
    ,TM.TXN_AMT -- 交易金额
    ,TM.TXN_CURR_CD -- 交易币种代码
    ,TM.TXN_SUCC_AMT -- 交易成功金额
    ,TM.FAST_PAY_TXN_TYPE_CD -- 快捷支付交易类型代码
    ,TM.TXN_DTL_INFO_DESC -- 交易详情信息描述
    ,TM.TXN_ERR_INFO_DESC -- 交易错误信息描述
    ,TM.HOST_TXN_TM_STAMP -- 主机交易时间戳
    ,TM.FAST_PAY_TXN_INIT_CHNL_CD -- 快捷支付交易发起渠道代码
    ,TM.RTN_GOODS_FLAG -- 退货标志
    ,TM.REFUND_AMT -- 退款金额
    ,TM.RESP_STATUS_INFO_DESC -- 响应状态信息描述
    ,TM.FAST_PAY_CHNL_CD -- 快捷支付渠道代码
    ,TM.FAST_PAY_TXN_STATUS_CD -- 快捷支付交易状态代码
    ,TM.ERR_INFO_DESC -- 错误信息描述
    ,TM.BELONG_CORE_PLAT_CD -- 归属核心平台代码
    ,TM.ASSIGN_DEBIT_PASS_CD -- 指定借方通道代码
    ,TM.ASSIGN_CRDT_PASS_CD -- 指定贷方通道代码
    ,TM.THIRD_PTY_FAST_BIZ_TYPE_CD -- 第三方快捷业务类型代码
    ,TM.THIRD_PTY_FAST_BIZ_CATE_CD -- 第三方快捷业务种类代码
    ,TM.RECORD_STATUS_CD -- 入账状态代码
    ,TM.ACCTN_FLAG -- 记账标志
    ,TM.RSPS_CD -- 响应码
    ,TM.MSG_NO -- 报文编号
    ,TM.MSG_CONT_DIR_CD -- 报文往来方向代码
    ,TM.MSG_DEAL_STATUS_CD -- 报文处理状态代码
    ,TM.ORIG_MSG_TXN_NO -- 原报文交易编号
    ,TM.MSG_SEND_BANK_NO -- 报文发送行号
    ,TM.MSG_SEND_ROW_BRCH_BANK_NO -- 报文发送行分行号
    ,TM.MSG_RECV_BANK_NO -- 报文接收行号
    ,TM.MSG_RECV_BANK_BRCH_BANK_NO -- 报文接收行分行号
    ,TM.IN_BANK_MSG_TYPE_NO -- 行内报文类型编号
    ,TM.MSG_RECV_TM_STAMP -- 报文接收时间戳
    ,TM.MSG_SEND_TM_STAMP -- 报文发送时间戳
    ,TM.RURAL_CRDT_MSG_TYPE_NO -- NPS农信银报文类型编号
    ,TM.EXT_RESP_MSG_NO -- 外部响应报文编号
    ,TM.PASS_MSG_SEND_TM_STAMP -- 通道报文发送时间戳
    ,TM.END_TO_END_IDE_NO -- 端到端标识号
    ,TM.AUTH_CD -- 授权码
    ,TM.AUTH_DOCTYP_CD -- 授权证件类型代码
    ,TM.AUTH_DOC_NO -- 授权证件号码
    ,TM.PLAT_CLEAR_DT -- 平台清算日期
    ,TM.FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,TM.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,TM.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,TM.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上,更新ETL_LAST_ACG_DT
     WHEN BF.PT_DT IS NOT NULL AND (
          COALESCE(TM.TXN_SER_NO,'') = COALESCE(BF.TXN_SER_NO,'') -- 交易流水号 非主键字段相等
         AND COALESCE(TM.TXN_DT,'') = COALESCE(BF.TXN_DT,'') -- 交易日期 非主键字段相等
         AND COALESCE(TM.CUST_IN_CD,'') = COALESCE(BF.CUST_IN_CD,'') -- 客户内码 非主键字段相等
         AND COALESCE(TM.CUST_MOBILE_NO,'') = COALESCE(BF.CUST_MOBILE_NO,'') -- 客户手机号码 非主键字段相等
         AND COALESCE(TM.CUST_DOC_NO,'') = COALESCE(BF.CUST_DOC_NO,'') -- 客户证件号码 非主键字段相等
         AND COALESCE(TM.CUST_DOCTYP_CD,'') = COALESCE(BF.CUST_DOCTYP_CD,'') -- 客户证件类型代码 非主键字段相等
         AND COALESCE(TM.OBANK_EMPLY_FLAG,'') = COALESCE(BF.OBANK_EMPLY_FLAG,'') -- 本行员工标志 非主键字段相等
         AND COALESCE(TM.PAYER_ACCT_NO,'') = COALESCE(BF.PAYER_ACCT_NO,'') -- 付款方账户编号 非主键字段相等
         AND COALESCE(TM.PAYER_PAY_CARD_NO,'') = COALESCE(BF.PAYER_PAY_CARD_NO,'') -- 付款方支付卡号 非主键字段相等
         AND COALESCE(TM.CARD_AFLT_ORG_NO,'') = COALESCE(BF.CARD_AFLT_ORG_NO,'') -- 卡所属机构编号 非主键字段相等
         AND COALESCE(TM.PAYER_CLEAR_ACCT_NO,'') = COALESCE(BF.PAYER_CLEAR_ACCT_NO,'') -- 付款方清算账户编号 非主键字段相等
         AND COALESCE(TM.PAYER_USER_ID,'') = COALESCE(BF.PAYER_USER_ID,'') -- 付款方用户ID 非主键字段相等
         AND COALESCE(TM.PAYER_NAME,'') = COALESCE(BF.PAYER_NAME,'') -- 付款方名称 非主键字段相等
         AND COALESCE(TM.PAYER_TXN_UNION_BANK,'') = COALESCE(BF.PAYER_TXN_UNION_BANK,'') -- 付款方交易联行号 非主键字段相等
         AND COALESCE(TM.PAYER_TXN_UNION_BANK_NAME,'') = COALESCE(BF.PAYER_TXN_UNION_BANK_NAME,'') -- 付款方交易联行名称 非主键字段相等
         AND COALESCE(TM.PAYER_MEM_UNION_BANK,'') = COALESCE(BF.PAYER_MEM_UNION_BANK,'') -- 付款方成员联行号 非主键字段相等
         AND COALESCE(TM.PAYER_MEM_UNION_BANK_NAME,'') = COALESCE(BF.PAYER_MEM_UNION_BANK_NAME,'') -- 付款方成员联行名称 非主键字段相等
         AND COALESCE(TM.PAYER_ACCT_BELONG_ORG_NO,'') = COALESCE(BF.PAYER_ACCT_BELONG_ORG_NO,'') -- 付款方账户归属机构编号 非主键字段相等
         AND COALESCE(TM.PAYER_ACCT_BELONG_ORG_NAME,'') = COALESCE(BF.PAYER_ACCT_BELONG_ORG_NAME,'') -- 付款方账户归属机构名称 非主键字段相等
         AND COALESCE(TM.PAYER_OPEN_ACCT_UNION_BANK,'') = COALESCE(BF.PAYER_OPEN_ACCT_UNION_BANK,'') -- 付款方开户联行号 非主键字段相等
         AND COALESCE(TM.PAYER_OPEN_ACCT_UBANK_NAME,'') = COALESCE(BF.PAYER_OPEN_ACCT_UBANK_NAME,'') -- 付款方开户联行名称 非主键字段相等
         AND COALESCE(TM.PAYER_ACCT_NO_TYPE_CD,'') = COALESCE(BF.PAYER_ACCT_NO_TYPE_CD,'') -- 付款方账号类型代码 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_NO,'') = COALESCE(BF.PAYEE_ACCT_NO,'') -- 收款方账户编号 非主键字段相等
         AND COALESCE(TM.PAYEE_CLEAR_ACCT_NO,'') = COALESCE(BF.PAYEE_CLEAR_ACCT_NO,'') -- 收款方清算账户编号 非主键字段相等
         AND COALESCE(TM.PAYEE_USER_ID,'') = COALESCE(BF.PAYEE_USER_ID,'') -- 收款方用户ID 非主键字段相等
         AND COALESCE(TM.PAYEE_NAME,'') = COALESCE(BF.PAYEE_NAME,'') -- 收款方名称 非主键字段相等
         AND COALESCE(TM.PAYEE_TXN_UNION_BANK,'') = COALESCE(BF.PAYEE_TXN_UNION_BANK,'') -- 收款方交易联行号 非主键字段相等
         AND COALESCE(TM.PAYEE_TXN_UNION_BANK_NAME,'') = COALESCE(BF.PAYEE_TXN_UNION_BANK_NAME,'') -- 收款方交易联行名称 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_NO_TYPE_CD,'') = COALESCE(BF.PAYEE_ACCT_NO_TYPE_CD,'') -- 收款方账号类型代码 非主键字段相等
         AND COALESCE(TM.PAYEE_MEM_UNION_BANK,'') = COALESCE(BF.PAYEE_MEM_UNION_BANK,'') -- 收款方成员联行号 非主键字段相等
         AND COALESCE(TM.PAYEE_MEM_UNION_BANK_NAME,'') = COALESCE(BF.PAYEE_MEM_UNION_BANK_NAME,'') -- 收款方成员联行名称 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NO,'') = COALESCE(BF.PAYEE_ACCT_BELONG_ORG_NO,'') -- 收款方账户归属机构编号 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_BELONG_ORG_NAME,'') = COALESCE(BF.PAYEE_ACCT_BELONG_ORG_NAME,'') -- 收款方账户归属机构名称 非主键字段相等
         AND COALESCE(TM.PAYEE_OPBANK_NO,'') = COALESCE(BF.PAYEE_OPBANK_NO,'') -- 收款方开户行行号 非主键字段相等
         AND COALESCE(TM.PAYEE_ACCT_TYPE_CD,'') = COALESCE(BF.PAYEE_ACCT_TYPE_CD,'') -- 收款方账户类型代码 非主键字段相等
         AND COALESCE(TM.ORDER_TXN_PLAT_NAME,'') = COALESCE(BF.ORDER_TXN_PLAT_NAME,'') -- 订单交易平台名称 非主键字段相等
         AND COALESCE(TM.ORDER_PAYEE_NAME,'') = COALESCE(BF.ORDER_PAYEE_NAME,'') -- 订单收款方名称 非主键字段相等
         AND COALESCE(TM.CONT_SIGN_AGT_NO,'') = COALESCE(BF.CONT_SIGN_AGT_NO,'') -- 合约签约协议编号 非主键字段相等
         AND COALESCE(TM.TXN_ORDER_NO,'') = COALESCE(BF.TXN_ORDER_NO,'') -- 交易订单编号 非主键字段相等
         AND COALESCE(TM.TXN_TM_STAMP,'') = COALESCE(BF.TXN_TM_STAMP,'') -- 交易时间戳 非主键字段相等
         AND COALESCE(TM.TXN_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易金额 非主键字段相等
         AND COALESCE(TM.TXN_CURR_CD,'') = COALESCE(BF.TXN_CURR_CD,'') -- 交易币种代码 非主键字段相等
         AND COALESCE(TM.TXN_SUCC_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.TXN_SUCC_AMT,CAST(0 AS DECIMAL(28,2))) -- 交易成功金额 非主键字段相等
         AND COALESCE(TM.FAST_PAY_TXN_TYPE_CD,'') = COALESCE(BF.FAST_PAY_TXN_TYPE_CD,'') -- 快捷支付交易类型代码 非主键字段相等
         AND COALESCE(TM.TXN_DTL_INFO_DESC,'') = COALESCE(BF.TXN_DTL_INFO_DESC,'') -- 交易详情信息描述 非主键字段相等
         AND COALESCE(TM.TXN_ERR_INFO_DESC,'') = COALESCE(BF.TXN_ERR_INFO_DESC,'') -- 交易错误信息描述 非主键字段相等
         AND COALESCE(TM.HOST_TXN_TM_STAMP,'') = COALESCE(BF.HOST_TXN_TM_STAMP,'') -- 主机交易时间戳 非主键字段相等
         AND COALESCE(TM.FAST_PAY_TXN_INIT_CHNL_CD,'') = COALESCE(BF.FAST_PAY_TXN_INIT_CHNL_CD,'') -- 快捷支付交易发起渠道代码 非主键字段相等
         AND COALESCE(TM.RTN_GOODS_FLAG,'') = COALESCE(BF.RTN_GOODS_FLAG,'') -- 退货标志 非主键字段相等
         AND COALESCE(TM.REFUND_AMT,CAST(0 AS DECIMAL(28,2))) = COALESCE(BF.REFUND_AMT,CAST(0 AS DECIMAL(28,2))) -- 退款金额 非主键字段相等
         AND COALESCE(TM.RESP_STATUS_INFO_DESC,'') = COALESCE(BF.RESP_STATUS_INFO_DESC,'') -- 响应状态信息描述 非主键字段相等
         AND COALESCE(TM.FAST_PAY_CHNL_CD,'') = COALESCE(BF.FAST_PAY_CHNL_CD,'') -- 快捷支付渠道代码 非主键字段相等
         AND COALESCE(TM.FAST_PAY_TXN_STATUS_CD,'') = COALESCE(BF.FAST_PAY_TXN_STATUS_CD,'') -- 快捷支付交易状态代码 非主键字段相等
         AND COALESCE(TM.ERR_INFO_DESC,'') = COALESCE(BF.ERR_INFO_DESC,'') -- 错误信息描述 非主键字段相等
         AND COALESCE(TM.BELONG_CORE_PLAT_CD,'') = COALESCE(BF.BELONG_CORE_PLAT_CD,'') -- 归属核心平台代码 非主键字段相等
         AND COALESCE(TM.ASSIGN_DEBIT_PASS_CD,'') = COALESCE(BF.ASSIGN_DEBIT_PASS_CD,'') -- 指定借方通道代码 非主键字段相等
         AND COALESCE(TM.ASSIGN_CRDT_PASS_CD,'') = COALESCE(BF.ASSIGN_CRDT_PASS_CD,'') -- 指定贷方通道代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_FAST_BIZ_TYPE_CD,'') = COALESCE(BF.THIRD_PTY_FAST_BIZ_TYPE_CD,'') -- 第三方快捷业务类型代码 非主键字段相等
         AND COALESCE(TM.THIRD_PTY_FAST_BIZ_CATE_CD,'') = COALESCE(BF.THIRD_PTY_FAST_BIZ_CATE_CD,'') -- 第三方快捷业务种类代码 非主键字段相等
         AND COALESCE(TM.RECORD_STATUS_CD,'') = COALESCE(BF.RECORD_STATUS_CD,'') -- 入账状态代码 非主键字段相等
         AND COALESCE(TM.ACCTN_FLAG,'') = COALESCE(BF.ACCTN_FLAG,'') -- 记账标志 非主键字段相等
         AND COALESCE(TM.RSPS_CD,'') = COALESCE(BF.RSPS_CD,'') -- 响应码 非主键字段相等
         AND COALESCE(TM.MSG_CONT_DIR_CD,'') = COALESCE(BF.MSG_CONT_DIR_CD,'') -- 报文往来方向代码 非主键字段相等
         AND COALESCE(TM.MSG_DEAL_STATUS_CD,'') = COALESCE(BF.MSG_DEAL_STATUS_CD,'') -- 报文处理状态代码 非主键字段相等
         AND COALESCE(TM.ORIG_MSG_TXN_NO,'') = COALESCE(BF.ORIG_MSG_TXN_NO,'') -- 原报文交易编号 非主键字段相等
         AND COALESCE(TM.MSG_SEND_BANK_NO,'') = COALESCE(BF.MSG_SEND_BANK_NO,'') -- 报文发送行号 非主键字段相等
         AND COALESCE(TM.MSG_SEND_ROW_BRCH_BANK_NO,'') = COALESCE(BF.MSG_SEND_ROW_BRCH_BANK_NO,'') -- 报文发送行分行号 非主键字段相等
         AND COALESCE(TM.MSG_RECV_BANK_NO,'') = COALESCE(BF.MSG_RECV_BANK_NO,'') -- 报文接收行号 非主键字段相等
         AND COALESCE(TM.MSG_RECV_BANK_BRCH_BANK_NO,'') = COALESCE(BF.MSG_RECV_BANK_BRCH_BANK_NO,'') -- 报文接收行分行号 非主键字段相等
         AND COALESCE(TM.IN_BANK_MSG_TYPE_NO,'') = COALESCE(BF.IN_BANK_MSG_TYPE_NO,'') -- 行内报文类型编号 非主键字段相等
         AND COALESCE(TM.MSG_RECV_TM_STAMP,'') = COALESCE(BF.MSG_RECV_TM_STAMP,'') -- 报文接收时间戳 非主键字段相等
         AND COALESCE(TM.MSG_SEND_TM_STAMP,'') = COALESCE(BF.MSG_SEND_TM_STAMP,'') -- 报文发送时间戳 非主键字段相等
         AND COALESCE(TM.RURAL_CRDT_MSG_TYPE_NO,'') = COALESCE(BF.RURAL_CRDT_MSG_TYPE_NO,'') -- NPS农信银报文类型编号 非主键字段相等
         AND COALESCE(TM.EXT_RESP_MSG_NO,'') = COALESCE(BF.EXT_RESP_MSG_NO,'') -- 外部响应报文编号 非主键字段相等
         AND COALESCE(TM.PASS_MSG_SEND_TM_STAMP,'') = COALESCE(BF.PASS_MSG_SEND_TM_STAMP,'') -- 通道报文发送时间戳 非主键字段相等
         AND COALESCE(TM.END_TO_END_IDE_NO,'') = COALESCE(BF.END_TO_END_IDE_NO,'') -- 端到端标识号 非主键字段相等
         AND COALESCE(TM.AUTH_CD,'') = COALESCE(BF.AUTH_CD,'') -- 授权码 非主键字段相等
         AND COALESCE(TM.AUTH_DOCTYP_CD,'') = COALESCE(BF.AUTH_DOCTYP_CD,'') -- 授权证件类型代码 非主键字段相等
         AND COALESCE(TM.AUTH_DOC_NO,'') = COALESCE(BF.AUTH_DOC_NO,'') -- 授权证件号码 非主键字段相等
         AND COALESCE(TM.PLAT_CLEAR_DT,'') = COALESCE(BF.PLAT_CLEAR_DT,'') -- 平台清算日期 非主键字段相等
         AND COALESCE(TM.FINAL_MODIF_TM_STAMP,'') = COALESCE(BF.FINAL_MODIF_TM_STAMP,'') -- 最后修改时间戳 非主键字段相等
         ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化,继承ETL_LAST_ACG_DT
     ELSE '${process_date}' END -- 新旧数据可以关联上且数据变化,更新ETL_LAST_ACG_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,ETL_PERIOD_DT AS PT_DT -- 表分区日期
FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_TM TM
LEFT JOIN AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_BK BF
ON (
     COALESCE(TM.MSG_NO,'') = COALESCE(BF.MSG_NO,'') -- 报文编号 主键字段关联
    AND COALESCE(TM.ETL_PERIOD_DT,'') = COALESCE(BF.PT_DT,'') -- 数据日期 主键字段关联
    )
;


/* 5.1 drop temp table */
DROP TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_BK;
DROP TABLE AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG_TM;
