-- 模板名称: 聚合层-流水表-增量流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人活期存款账户交易明细还原聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA
--     表中文名：个人活期存款账户交易明细还原聚合
--     创建日期：2023-12-29 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_ACCTN_DT, TXN_ACCT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-29 00:00:00 游崔龙 新增
--         2024-07-23 00:00:00 魏丹丹 修改模板
--         2024-09-06 00:00:00 魏丹丹 新增电子账户字段，同步20240902 版本
--         2024-09-13 00:00:00 魏丹丹 修改逻辑取值
--         2024-10-19 00:00:00 魏丹丹 修改设计2024/9/27的更新
--         2024-11-19 00:00:00 魏丹丹 修改第二组用户ID，客户内码的取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop main temp table */
DROP TABLE IF EXISTS AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM;

/* 1.2 create main temp table  */
CREATE TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM
USING ORC
COMMENT '个人活期存款账户交易明细还原聚合-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NO -- 交易账户编号
    ,EACCT_NO -- 电子账户编号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,FORGN_RELAT_PAY_CLS_CD -- 涉外收支交易分类代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_DIR_CTRY_CD -- 交易去向国家代码
    ,CROSS_BORDER_TXN_FLAG -- 跨境交易标志
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AL_AUTH_FLAG -- 已授权标志
    ,AUTH_TELR_NO -- 授权柜员编号
    ,REMOTE_AUTH_AUDIT_TELR_NO -- 远程授权审核柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,UN_CNTER_TXN_FLAG -- 非柜台交易标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CHNL_CLS_CD -- 渠道分类代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,HOST_START_UP_ORIG_TRAN_CD -- 主机启动原交易码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_TERMN_CD -- 交易终端号
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,STRK_BAL_TYPE_CD -- 抹账类型代码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,AGENT_NATION_CD -- 代理人国籍代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA WHERE 0=1 ;


/* 1.3 truncate main temp table  */
TRUNCATE TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM;

/* 2.1 get today data */
-- ==============聚合层字段映射（第1组）==============
-- 临时表_核心_01
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_01;

CREATE TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_01 (
     AA01AC15 STRING COMMENT '账号'
    ,AA04FLNM STRING COMMENT '账户全名'
    ,USER_ID STRING COMMENT '用户ID'
    ,AA03CSNO STRING COMMENT '客户内码'
    ,AA11ACFG STRING COMMENT '帐户类型'
    ,AA13ZHTP STRING COMMENT '账户性质'
    ,AA47BRNO STRING COMMENT '归属网点'
    ,AA45BRNO STRING COMMENT '统计机构'
    ,AA48BRNO STRING COMMENT '核算主体行'
    ,CUST_NM STRING COMMENT '客户名称'
    ,NTNLT STRING COMMENT '国籍'
    ,CW05FLNM STRING COMMENT '产品名称'
    ,CRTF_TYP STRING COMMENT '证件类型'
    ,CRTF_NO STRING COMMENT '证件号码'
    ,OBANK_STF STRING COMMENT '本行员工'
    ,AA07PDTP STRING COMMENT '产品类型'
    ,AA08PRON STRING COMMENT '产品代码'
)
USING ORC
COMMENT '临时表_核心_01'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_01(
     AA01AC15 -- 账号
    ,AA04FLNM -- 账户全名
    ,USER_ID -- 用户ID
    ,AA03CSNO -- 客户内码
    ,AA11ACFG -- 帐户类型
    ,AA13ZHTP -- 账户性质
    ,AA47BRNO -- 归属网点
    ,AA45BRNO -- 统计机构
    ,AA48BRNO -- 核算主体行
    ,CUST_NM -- 客户名称
    ,NTNLT -- 国籍
    ,CW05FLNM -- 产品名称
    ,CRTF_TYP -- 证件类型
    ,CRTF_NO -- 证件号码
    ,OBANK_STF -- 本行员工
    ,AA07PDTP -- 产品类型
    ,AA08PRON -- 产品代码
)
SELECT
     P3.AA01AC15 AS AA01AC15 -- 账号
    ,P3.AA04FLNM AS AA04FLNM -- 账户全名
    ,COALESCE(P4.USER_ID,T4.CUSTID) AS USER_ID -- 用户ID
    ,P3.AA03CSNO AS AA03CSNO -- 客户内码
    ,P3.AA11ACFG AS AA11ACFG -- 帐户类型
    ,P3.AA13ZHTP AS AA13ZHTP -- 账户性质
    ,P3.AA47BRNO AS AA47BRNO -- 归属网点
    ,P3.AA45BRNO AS AA45BRNO -- 统计机构
    ,P3.AA48BRNO AS AA48BRNO -- 核算主体行
    ,P5.CUST_NM AS CUST_NM -- 客户名称
    ,P5.NTNLT AS NTNLT -- 国籍
    ,P9.CW05FLNM AS CW05FLNM -- 产品名称
    ,P13.CRTF_TYP AS CRTF_TYP -- 证件类型
    ,P13.CRTF_NO AS CRTF_NO -- 证件号码
    ,P11.OBANK_STF AS OBANK_STF -- 本行员工
    ,P3.AA07PDTP AS AA07PDTP -- 产品类型
    ,P3.AA08PRON AS AA08PRON -- 产品代码
FROM
(
 SELECT 
      D3.AA04FLNM
     ,D3.AA03CSNO
     ,D3.AA11ACFG
     ,D3.AA13ZHTP
     ,D3.AA07PDTP
     ,D3.AA08PRON
     ,D3.AA47BRNO
     ,D3.AA45BRNO
     ,D3.AA48BRNO
     ,D3.AA01AC15
 FROM ODS_CORE.ODS_CORE_BDFMHQAA_TF D3
 WHERE  D3.PT_DT = '${process_date}'   
and del_f = '0'
) AS P3 -- 活期存款账户主档

LEFT JOIN (SELECT * FROM(
    SELECT
      U4.USER_ID
     ,U4.CST_IN_CD 
     ,ROW_NUMBER() OVER(PARTITION BY U4.CST_IN_CD ORDER BY U4.USER_ID DESC ) RN
    FROM ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF  U4
    WHERE U4.PT_DT = '${process_date}'  AND DEL_F = '0'
)D4 WHERE D4.RN = 1) AS P4 -- 用户信息表
       ON P3.AA03CSNO = P4.CST_IN_CD 
LEFT JOIN (SELECT * FROM(
    SELECT
      U4.CUSTID
     ,U4.CUSTCD 
     ,ROW_NUMBER() OVER(PARTITION BY U4.CUSTCD ORDER BY U4.STATUS DESC ) RN
    FROM ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF  U4
    WHERE U4.PT_DT = '${process_date}'  AND DEL_F = '0'
)D4 WHERE D4.RN = 1) AS T4 -- 客户信息关联表
       ON P3.AA03CSNO =T4.CUSTCD 
LEFT JOIN (
    SELECT 
        D5.CUST_NM
       ,D5.CST_IN_CD
    ,D5.NTNLT
    FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_BAS_TF D5
    WHERE  D5.PT_DT = '${process_date}'
and del_f = '0'
) AS P5 -- 客户基础信息表
       ON P3.AA03CSNO = P5.CST_IN_CD 
LEFT JOIN (
 SELECT 
 
   D9.CW02PDTP
  ,D9.CW03PRON
  ,D9.CW04BRNO
  ,D9.CW05FLNM
 FROM ODS_CORE.ODS_CORE_BDFMHQCW_TF D9
 WHERE  D9.PT_DT = '${process_date}'   
and del_f = '0'
)  AS P9 -- 产品代码名称表
       ON P3.AA08PRON = P9.CW03PRON
AND P3.AA07PDTP = P9.CW02PDTP  
LEFT JOIN (
 SELECT 
  D11.OBANK_STF
  ,D11.CORP_ORG_NO
  ,D11.CST_IN_CD 
  ,D11.ORG_CREATE
 FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_SOCIAL_TF D11
 WHERE  D11.PT_DT = '${process_date}'   
and del_f = '0'
) AS P11 -- 客户社会信息
       ON P3.AA03CSNO = P11.CST_IN_CD 
AND P3.AA48BRNO = P11.CORP_ORG_NO 
LEFT JOIN (
   select D13.CST_IN_CD
     ,D13.CRTF_TYP
     ,D13.CRTF_NO
    from 
    (
        SELECT 
             U13.CRTF_TYP
            ,U13.CRTF_NO
            ,U13.CST_IN_CD
            ,row_number()over(partition by U13.CST_IN_CD order by U13.org_modified desc ) rn
        FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF U13
        WHERE  U13.PT_DT = '${process_date}'
and del_f = '0'
    ) D13
   where D13.RN = 1
) AS P13 -- 客户证件信息表
       ON P3.AA03CSNO = P13.CST_IN_CD 
;
-- ==============聚合层字段映射（第2组）==============
-- 临时表_核心_02
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_02;

CREATE TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_02 (
     AC03TXSN STRING COMMENT '原交易流水号'
    ,AC04TSSN STRING COMMENT '子交易流水号'
    ,AC02DATE STRING COMMENT '交易记账日期'
    ,AC01AC15 STRING COMMENT '交易账户编号'
    ,OACC_NO STRING COMMENT '老系统交易账户编号'
    ,TX_DIS STRING COMMENT '交易地区代码'
    ,AUT_FLG STRING COMMENT '已授权标志'
    ,ATEL_ID1 STRING COMMENT '授权柜员号'
    ,ATEL_ID2 STRING COMMENT '远程授权申请审核柜员号'
    ,CON_TELID STRING COMMENT '复核柜员号'
    ,SRS_ID STRING COMMENT '发起方系统'
    ,TEL_TXID STRING COMMENT '柜员输入原交易码'
    ,SYS_TXID STRING COMMENT '主机启动原交易码'
    ,ATX_ID STRING COMMENT '子交易码/分录码'
    ,WS_NO STRING COMMENT '交易终端号'
    ,REV_FLG STRING COMMENT '被抹帐标志'
    ,JRN_MARK STRING COMMENT '备注'
    ,CRT_DTE STRING COMMENT '建立日期'
    ,CRE_TS STRING COMMENT '建立时间戳'
    ,CRE_UID STRING COMMENT '建立用户代码'
    ,UPD_DTE STRING COMMENT '最后更新日期'
    ,UPD_TS STRING COMMENT '最后更新时间戳'
    ,UPD_UID STRING COMMENT '最后更新用户代码'
    ,KHDAACID STRING COMMENT '会计科目编号'
    ,KHDAFLNM STRING COMMENT '会计科目名称'
    ,TRADECODE STRING COMMENT '涉外收支交易分类代码'
    ,GOCOUNTRY STRING COMMENT '交易去向国家代码'
    ,ISFOREIGN STRING COMMENT '跨境交易标志'
)
USING ORC
COMMENT '临时表_核心_02'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_02(
     AC03TXSN -- 原交易流水号
    ,AC04TSSN -- 子交易流水号
    ,AC02DATE -- 交易记账日期
    ,AC01AC15 -- 交易账户编号
    ,OACC_NO -- 老系统交易账户编号
    ,TX_DIS -- 交易地区代码
    ,AUT_FLG -- 已授权标志
    ,ATEL_ID1 -- 授权柜员号
    ,ATEL_ID2 -- 远程授权申请审核柜员号
    ,CON_TELID -- 复核柜员号
    ,SRS_ID -- 发起方系统
    ,TEL_TXID -- 柜员输入原交易码
    ,SYS_TXID -- 主机启动原交易码
    ,ATX_ID -- 子交易码/分录码
    ,WS_NO -- 交易终端号
    ,REV_FLG -- 被抹帐标志
    ,JRN_MARK -- 备注
    ,CRT_DTE -- 建立日期
    ,CRE_TS -- 建立时间戳
    ,CRE_UID -- 建立用户代码
    ,UPD_DTE -- 最后更新日期
    ,UPD_TS -- 最后更新时间戳
    ,UPD_UID -- 最后更新用户代码
    ,KHDAACID -- 会计科目编号
    ,KHDAFLNM -- 会计科目名称
    ,TRADECODE -- 涉外收支交易分类代码
    ,GOCOUNTRY -- 交易去向国家代码
    ,ISFOREIGN -- 跨境交易标志
)
SELECT
     P1.AC03TXSN AS AC03TXSN -- 原交易流水号
    ,P1.AC04TSSN AS AC04TSSN -- 子交易流水号
    ,P1.AC02DATE AS AC02DATE -- 交易记账日期
    ,P1.AC01AC15 AS AC01AC15 -- 交易账户编号
    ,COALESCE(P2.OACC_NO,P3.OACC_NO) AS OACC_NO -- 老系统交易账户编号
    ,COALESCE(P2.TX_DIS,P3.TX_DIS) AS TX_DIS -- 交易地区代码
    ,COALESCE(CASE WHEN TRIM(P2.AUT_FLG) = '' THEN '2' ELSE P2.AUT_FLG END ,CASE WHEN TRIM(P3.AUT_FLG) = '' THEN '2' ELSE P3.AUT_FLG END ) AS AUT_FLG -- 已授权标志
    ,COALESCE(P2.ATEL_ID1  ,P3.ATEL_ID1 ) AS ATEL_ID1 -- 授权柜员号
    ,COALESCE(P2.ATEL_ID2  ,P3.ATEL_ID2 ) AS ATEL_ID2 -- 远程授权申请审核柜员号
    ,COALESCE(P2.CON_TELID ,P3.CON_TELID) AS CON_TELID -- 复核柜员号
    ,COALESCE(P2.SRS_ID    ,P3.SRS_ID   ) AS SRS_ID -- 发起方系统
    ,COALESCE(P2.TEL_TXID ,P3.TEL_TXID ) AS TEL_TXID -- 柜员输入原交易码
    ,COALESCE(P2.SYS_TXID ,P3.SYS_TXID ) AS SYS_TXID -- 主机启动原交易码
    ,COALESCE(P2.ATX_ID   ,P3.ATX_ID   ) AS ATX_ID -- 子交易码/分录码
    ,COALESCE(P2.WS_NO    ,P3.WS_NO    ) AS WS_NO -- 交易终端号
    ,COALESCE(P2.REV_FLG  ,P3.REV_FLG  ) AS REV_FLG -- 被抹帐标志
    ,COALESCE(P2.JRN_MARK ,P3.JRN_MARK ) AS JRN_MARK -- 备注
    ,COALESCE(P2.CRT_DTE  ,P3.CRT_DTE  ) AS CRT_DTE -- 建立日期
    ,COALESCE(P2.CRE_TS   ,P3.CRE_TS   ) AS CRE_TS -- 建立时间戳
    ,COALESCE(P2.CRE_UID  ,P3.CRE_UID  ) AS CRE_UID -- 建立用户代码
    ,COALESCE(P2.UPD_DTE  ,P3.UPD_DTE  ) AS UPD_DTE -- 最后更新日期
    ,COALESCE(P2.UPD_TS   ,P3.UPD_TS   ) AS UPD_TS -- 最后更新时间戳
    ,COALESCE(P2.UPD_UID  ,P3.UPD_UID  ) AS UPD_UID -- 最后更新用户代码
    ,P7.KHDAACID AS KHDAACID -- 会计科目编号
    ,P7.KHDAFLNM AS KHDAFLNM -- 会计科目名称
    ,P8.TRADECODE AS TRADECODE -- 涉外收支交易分类代码
    ,P8.GOCOUNTRY AS GOCOUNTRY -- 交易去向国家代码
    ,P8.ISFOREIGN AS ISFOREIGN -- 跨境交易标志
FROM
(
 SELECT
      D1.AC03TXSN
     ,D1.AC04TSSN
     ,cast(D1.AC02DATE as string) as AC02DATE
     ,D1.AC01AC15
     ,D1.AC16STAM
     ,D1.AC24SN04
     ,D1.AC25NO12
     ,D1.AC07CCYC
     ,D1.AC08CHSX
     ,D1.BTXMTXCD
     ,D1.AC12CDFG
     ,D1.AC24JYLX
     ,D1.AC09JZFS
     ,D1.AC10AMT
     ,D1.AC11AMT
     ,D1.AC20NTCD
     ,D1.ZYXXNM40
     ,D1.AC19BRNO
     ,D1.AC18STAF
     ,D1.AC17CNCD
     ,D1.AC13BLTP
     ,D1.AC14BLNO
     ,D1.AC25BRNO

 FROM ODS_CORE.ODS_CORE_BDFMHQAC_TA D1
 WHERE SUBSTR(D1.AC01AC15,1,1) = '1'  
     AND D1.RCSTRS1B <> '9' 
     AND D1.PT_DT = '${process_date}' 
AND DEL_F = '0'
) AS P1 -- 活期存款账户交易明细表

LEFT JOIN ODS_CORE.ODS_CORE_BYFTJRN_TA AS P2 -- 会计流水文件
       ON cast(P1.AC02DATE as string) =P2.TX_DATE
AND cast(P1.AC03TXSN as string) =P2.BTX_JNO
AND cast(P1.AC04TSSN as string) =P2.ATX_JNO
AND P1.AC01AC15 =P2.ACC_NO 
LEFT JOIN (
 select 
   D7.KHDAACID
  ,D7.KHDAFLNM
  ,D7.KHDBACID
 from ODS_CORE.ODS_CORE_BGFDKHDZ_TF D7
 WHERE  D7.PT_DT = '${process_date}'
and del_f = '0'
) AS P7 -- 新会计科目核算码对照表
       ON P2.GLAC_NO = P7.KHDBACID 
LEFT JOIN (
 select 
         D8.IBSERIALNO
        ,REPLACE(cast(D8.ENROLDATE  as STRING),'-','') as ENROLDATE 
        ,D8.TRADECODE
        ,D8.GOCOUNTRY
        ,D8.ISFOREIGN

 from ODS_INTLBIZ.ODS_INTLBIZ_RWM_TRANS_TXN_TA D8
 WHERE  D8.PT_DT = '${process_date}'
and del_f = '0'
) AS P8 -- 国结业务交易
       ON P2.SRV_JNO = P8.IBSERIALNO
AND P2.TX_DATE = P8.ENROLDATE 
LEFT JOIN ODS_CORE.ODS_CORE_BGFTYJRN_TA AS P3 -- 会计流水文件
       ON CAST(P1.AC02DATE AS STRING) = CAST(P3.TX_DATE AS STRING)
AND P1.AC03TXSN =P3.BTX_JNO
AND P1.AC04TSSN =P3.ATX_JNO
AND P1.AC01AC15 =P3.ACC_NO
AND P3.DEL_F= '0'
AND P3.PT_DT='${process_date}' 
;
-- ==============聚合层字段映射（第3组）==============
-- 临时表_核心_03
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_03;

CREATE TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_03 (
     AC03TXSN STRING COMMENT '原交易流水号'
    ,AC04TSSN STRING COMMENT '子交易流水号'
    ,AC02DATE STRING COMMENT '交易记账日期'
    ,AC01AC15 STRING COMMENT '账号'
    ,AC10AMT DECIMAL(28,2) COMMENT '交易金额折人民币'
    ,TXN_AMT_CONVT_USD DECIMAL(28,2) COMMENT '交易金额折美元'
)
USING ORC
COMMENT '临时表_核心_03'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_03(
     AC03TXSN -- 原交易流水号
    ,AC04TSSN -- 子交易流水号
    ,AC02DATE -- 交易记账日期
    ,AC01AC15 -- 账号
    ,AC10AMT -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
)
SELECT
     T1.AC03TXSN AS AC03TXSN -- 原交易流水号
    ,T1.AC04TSSN AS AC04TSSN -- 子交易流水号
    ,T1.AC02DATE AS AC02DATE -- 交易记账日期
    ,T1.AC01AC15 AS AC01AC15 -- 账号
    ,T1.AC10AMT AS AC10AMT -- 交易金额折人民币
    ,T1.CONVET_USD AS TXN_AMT_CONVT_USD -- 交易金额折美元
FROM
(
 SELECT
      cast(P1.AC03TXSN as string ) AS AC03TXSN -- 原交易流水号
     ,cast(P1.AC04TSSN as string ) AS AC04TSSN -- 子交易流水号
     ,P1.AC02DATE AS AC02DATE -- 交易记账日期
     ,P1.AC01AC15 AS AC01AC15 -- 账号
     ,p1.AC07CCYC
     ,CASE WHEN P1.AC07CCYC = 'CNY' THEN P1.AC10AMT else P1.AC10AMT*COALESCE(P6.YRCAEXRT,0)/COALESCE(P6.YRCACUNO,100)  END  AS AC10AMT -- 交易金额折人民币
     ,case when p1.ac07ccyc = 'CNY' then P1.ac10amt / coalesce(P7.yrcaexrt,0) * coalesce(P7.yrcacuno ,100) 
   when  p1.ac07ccyc = 'USD' then  P1.ac10amt 
   else  (P1.ac10amt * coalesce(P6.yrcaexrt,0) / coalesce(P6.yrcacuno ,100))/coalesce(P7.yrcaexrt,0)*coalesce(P7.yrcacuno ,100) 
     end as CONVET_USD
 FROM
 (
   SELECT
       D1.AC03TXSN
       ,D1.AC04TSSN
       ,cast(D1.AC02DATE as string) as AC02DATE
       ,D1.AC01AC15
       ,D1.AC16STAM
       ,D1.AC24SN04
       ,D1.AC25NO12
       ,D1.AC07CCYC
       ,D1.AC08CHSX
       ,D1.BTXMTXCD
       ,D1.AC12CDFG
       ,D1.AC24JYLX
       ,D1.AC09JZFS
       ,D1.AC10AMT
       ,D1.AC11AMT
       ,D1.AC20NTCD
       ,D1.ZYXXNM40
       ,D1.AC19BRNO
       ,D1.AC18STAF
       ,D1.AC17CNCD
       ,D1.AC13BLTP
       ,D1.AC14BLNO
  
   FROM ODS_CORE.ODS_CORE_BDFMHQAC_TA D1
   WHERE SUBSTR(D1.AC01AC15,1,1) = '1'  
       AND D1.RCSTRS1B <> '9' 
       AND D1.PT_DT = '${process_date}' 
and del_f = '0'
  ) AS P1 -- 活期存款账户交易明细表
  
  LEFT JOIN (  
  SELECT 
          D6.YRCAEXRT
          ,D6.YRCACUNO
          ,D6.YRCACCYC 
      FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D6
      WHERE  D6.PT_DT = '${process_date}'
          AND  CAST(D6.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
          AND D6.YRCARS1B <> '9'
          AND D6.DEL_F = '0'
  )        AS P6 -- 年度报表汇率文件
         ON P1.AC07CCYC = P6.YRCACCYC  
  left join 
  (
    SELECT 
        D15.YRCAEXRT
        ,D15.YRCACUNO
        ,NVL(D15.YRCAEXRT,0)/NVL(D15.YRCACUNO,10) as usdexrt
        ,D15.YRCACCYC 
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D15
    WHERE  D15.PT_DT = '${process_date}'
and del_f = '0'
        AND  CAST(D15.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D15.YRCARS1B <> '9'
        AND D15.YRCACCYC = 'USD' 

 )P7  on 1=1

         
)  AS T1 -- 活期存款账户交易明细表

;
-- ==============聚合层字段映射（第4组）==============
-- 个人活期存款账户交易明细还原聚合

INSERT INTO TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NO -- 交易账户编号
    ,EACCT_NO -- 电子账户编号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,FORGN_RELAT_PAY_CLS_CD -- 涉外收支交易分类代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_DIR_CTRY_CD -- 交易去向国家代码
    ,CROSS_BORDER_TXN_FLAG -- 跨境交易标志
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AL_AUTH_FLAG -- 已授权标志
    ,AUTH_TELR_NO -- 授权柜员编号
    ,REMOTE_AUTH_AUDIT_TELR_NO -- 远程授权审核柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,UN_CNTER_TXN_FLAG -- 非柜台交易标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CHNL_CLS_CD -- 渠道分类代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,HOST_START_UP_ORIG_TRAN_CD -- 主机启动原交易码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_TERMN_CD -- 交易终端号
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,STRK_BAL_TYPE_CD -- 抹账类型代码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,AGENT_NATION_CD -- 代理人国籍代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.AC03TXSN AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.AC04TSSN AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.AC02DATE AS TXN_ACCTN_DT -- 交易记账日期
    ,P1.AC16STAM AS TXN_TM_STAMP -- 交易时间戳
    ,P1.AC24SN04 AS TELR_SER_NO -- 柜员流水号
    ,P1.AC25NO12 AS FRONT_SER_NO -- 前置流水号
    ,P1.AC01AC15 AS TXN_ACCT_NO -- 交易账户编号
    ,'' AS EACCT_NO -- 电子账户编号
    ,P2.OACC_NO AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,P3.AA04FLNM AS TXN_ACCT_NAME -- 交易账户名称
    ,P3.USER_ID AS USER_ID -- 用户ID
    ,P3.AA03CSNO AS CUST_IN_CD -- 客户内码
    ,P3.CUST_NM AS CUST_NAME -- 客户名称
    ,P3.NTNLT AS NATION_CD -- 国籍代码
    ,P3.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,P3.CRTF_NO AS DOC_NO -- 证件号码
    ,P3.AA11ACFG AS ACCT_TYPE_CD -- 账户类型代码
    ,P3.AA13ZHTP AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.AC07CCYC AS TXN_CURR_CD -- 交易币种代码
    ,P1.AC08CHSX AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.BTXMTXCD AS TRAN_CD -- 交易码
    ,P1.AC12CDFG AS TXN_DIR_CD -- 交易方向代码
    ,P1.AC24JYLX AS TXN_TYPE_CD -- 交易类型代码
    ,P1.AC09JZFS AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.AC10AMT AS TXN_AMT -- 交易金额
    ,P4.AC10AMT AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,P4.TXN_AMT_CONVT_USD AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.AC11AMT AS ACCT_BAL -- 账户余额
    ,P1.AC20NTCD AS SUMMARY_CD -- 摘要代码
    ,P1.ZYXXNM40 AS SUMMARY_DESC -- 摘要描述
    ,P2.KHDAACID AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P2.KHDAFLNM AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,P2.TRADECODE AS FORGN_RELAT_PAY_CLS_CD -- 涉外收支交易分类代码
    ,CONCAT(P3.AA07PDTP,P3.AA08PRON) AS DPSIT_PROD_CD -- 存款产品代码
    ,P3.CW05FLNM AS DPSIT_PROD_NAME -- 存款产品名称
    ,'' AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,'' AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,'' AS CNTPTY_BANK_NO -- 对方行号
    ,'' AS CNTPTY_BANK_NAME -- 对方行名
    ,NVL(P2.GOCOUNTRY,'156') AS TXN_DIR_CTRY_CD -- 交易去向国家代码
    ,P2.ISFOREIGN AS CROSS_BORDER_TXN_FLAG -- 跨境交易标志
    ,P1.AC19BRNO AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P2.TX_DIS AS TXN_RGN_NO -- 交易地区编号
    ,P1.AC18STAF AS TXN_TELR_NO -- 交易柜员编号
    ,CASE WHEN P2.AUT_FLG IS NULL OR TRIM(P2.AUT_FLG)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P2.AUT_FLG)),'') END

 AS AL_AUTH_FLAG -- 已授权标志
    ,P2.ATEL_ID1 AS AUTH_TELR_NO -- 授权柜员编号
    ,P2.ATEL_ID2 AS REMOTE_AUTH_AUDIT_TELR_NO -- 远程授权审核柜员编号
    ,P2.CON_TELID AS CHECKER_NO -- 复核人柜员编号
    ,P2.SRS_ID AS INITR_SYS_CD -- 发起方系统代码
    ,CASE WHEN P1.AC17CNCD <> 'TE' THEN 0 ELSE 1 END AS UN_CNTER_TXN_FLAG -- 非柜台交易标志
    ,P1.AC17CNCD AS TXN_CHNL_CD -- 交易渠道代码
    ,P5.BJ02QDLB AS CHNL_CLS_CD -- 渠道分类代码
    ,P2.TEL_TXID AS TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,P2.SYS_TXID AS HOST_START_UP_ORIG_TRAN_CD -- 主机启动原交易码
    ,P2.ATX_ID AS SUB_TRAN_CD -- 子交易码
    ,P2.WS_NO AS TXN_TERMN_CD -- 交易终端号
    ,P10.KF06IPAD AS TXN_EQUIP_IP -- 交易设备IP
    ,P10.KF07MAC AS TXN_EQUIP_MAC -- 交易设备MAC
    ,P3.OBANK_STF AS OBANK_EMPLY_FLAG -- 本行员工标志
    ,CASE WHEN P1.AC13BLTP IS NULL OR TRIM(P1.AC13BLTP)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AC13BLTP)),'') END AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.AC14BLNO AS TXN_VOCH_NO -- 交易凭证号码
    ,P2.REV_FLG AS STRK_BAL_TYPE_CD -- 抹账类型代码
    ,P12.HA07CFTP AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P12.HA08CFNO AS AGENT_DOC_NO -- 代理人证件号码
    ,P12.HA09FLNM AS AGENT_NAME -- 代理人名称
    ,P12.HA10TELN AS AGENT_CONT_MODE -- 代理人联系方式
    ,P3.NTNLT AS AGENT_NATION_CD -- 代理人国籍代码
    ,P1.AC25BRNO AS BELONG_ORG_NO -- 归属机构编号
    ,P3.AA45BRNO AS STAT_ORG_NO -- 统计机构编号
    ,P3.AA48BRNO AS LP_ORG_NO -- 法人机构编号
    ,P2.JRN_MARK AS REM -- 备注
    ,unifiedTime(P2.CRT_DTE) AS SETUP_DT -- 建立日期
    ,P2.CRE_TS AS SETUP_TM_STAMP -- 建立时间戳
    ,P2.CRE_UID AS SETUP_TELR_NO -- 建立柜员编号
    ,P2.UPD_DTE AS FINAL_MODIF_DT -- 最后修改日期
    ,P2.UPD_TS AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,P2.UPD_UID AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'CORE' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_CORE_BDFMHQAC_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,1 AS GRP_SER_NO -- 组序号
FROM
(
 SELECT
      D1.AC03TXSN
     ,D1.AC04TSSN
     ,cast(D1.AC02DATE as string) as AC02DATE
     ,D1.AC01AC15
     ,D1.AC16STAM
     ,D1.AC24SN04
     ,D1.AC25NO12
     ,D1.AC07CCYC
     ,D1.AC08CHSX
     ,D1.BTXMTXCD
     ,D1.AC12CDFG
     ,D1.AC24JYLX
     ,D1.AC09JZFS
     ,D1.AC10AMT
     ,D1.AC11AMT
     ,D1.AC20NTCD
     ,D1.ZYXXNM40
     ,D1.AC19BRNO
     ,D1.AC18STAF
     ,D1.AC17CNCD
     ,D1.AC13BLTP
     ,D1.AC14BLNO
     ,D1.AC25BRNO

 FROM ODS_CORE.ODS_CORE_BDFMHQAC_TA D1
 WHERE SUBSTR(D1.AC01AC15,1,1) = '1'  
     AND D1.RCSTRS1B <> '9' 
     AND D1.PT_DT = '${process_date}' 
AND DEL_F = '0'
) AS P1 -- 活期存款账户交易明细表

LEFT JOIN AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_02 AS P2 -- 会计流水文件
       ON cast(P1.AC02DATE as string) =cast(P2.AC02DATE as string)
AND cast(P1.AC03TXSN as string) =cast(P2.AC03TXSN as string)
AND cast(P1.AC04TSSN as string) =cast(P2.AC04TSSN as string)
AND P1.AC01AC15 = P2.AC01AC15 
LEFT JOIN AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_01 AS P3 -- 活期存款账户主档
       ON P1.AC01AC15 = P3.AA01AC15 
LEFT JOIN AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_03 AS P4 -- 临时表_核心_03
       ON P1.AC01AC15=P4.AC01AC15
        AND cast(P1.AC02DATE as STRING)=P4.AC02DATE
        AND cast(P1.AC03TXSN as STRING)=P4.AC03TXSN
        AND cast(P1.AC04TSSN as STRING)=P4.AC04TSSN 
LEFT JOIN (
select
 BJ02QDLB,
 BJ06TXSN,
 BJ04CCYC,
 BJ01DATE
from
 ods_core.ods_core_BDFMHQBJ_ta D01
where
 RCSTRS1B <> '9'
 and DEL_F = '0'
 and PT_DT = '${process_date}'
group by
 BJ02QDLB,
 BJ06TXSN,
 BJ04CCYC,
 BJ01DATE ) AS P5 -- 存款对账登记簿
       ON P5.BJ06TXSN=p1.AC03TXSN
AND  P5.BJ04CCYC=p1.AC07CCYC
AND   unifiedTime(P5.BJ01DATE)= '${process_date}' 
LEFT JOIN (
 select 
        D10.KF01AC15
        ,cast(D10.KF02DATE as string) as KF02DATE
        ,D10.KF03TXSN
        ,D10.KF04TSSN  
        ,D10.KF06IPAD
        ,D10.KF07MAC
 from ODS_CORE.ODS_CORE_BDFMHQKF_TA D10
 WHERE  D10.PT_DT = '${process_date}'
AND DEL_F = '0'
) AS P10 -- 活期存款互联网交易登记簿（当日）
       ON P1.AC01AC15 = P10.KF01AC15
AND P1.AC02DATE = P10.KF02DATE
AND P1.AC03TXSN = P10.KF03TXSN
AND P1.AC04TSSN = P10.KF04TSSN  
LEFT JOIN (
 select 
         D12.HA07CFTP
        ,D12.HA08CFNO
        ,D12.HA09FLNM
        ,D12.HA10TELN
        ,REPLACE(cast(D12.HA17DTE as STRING),'-','') as HA17DTE
        ,D12.HA01TXSN
        ,D12.HA04TSSN 
 from ODS_CORE.ODS_CORE_BDFMHQHA_TA D12
 WHERE  D12.PT_DT = '${process_date}'
AND DEL_F = '0'
) AS P12 -- 会计流水补充文件
       ON P1.AC02DATE = P12.HA17DTE
AND P1.AC03TXSN = P12.HA01TXSN
AND P1.AC04TSSN = P12.HA04TSSN  
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     where  p1.SRC_TAB_LIB_NAME ='CORE' 
     AND p1.SRC_TAB_EN_NAME='BYFTJRN' 
     AND p1.SRC_FIELD_EN_NAME='AUT_FLG' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA'  
     AND p1.TARGET_FIELD_EN_NAME='AL_AUTH_FLAG' 
)  AS S1 -- 代码转换
       ON P2.AUT_FLG=S1.SRC_CD_VAL  
LEFT JOIN (
 SELECT 
      P2.TARGET_CD_VAL
     ,P2.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P2
     where  P2.SRC_TAB_LIB_NAME ='CORE' 
     AND P2.SRC_TAB_EN_NAME='BDFMHQAC' 
     AND P2.SRC_FIELD_EN_NAME='AC13BLTP' 
     AND P2.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA'  
     AND P2.TARGET_FIELD_EN_NAME='TXN_VOCH_CATE_CD' 
) 
 AS S2 -- 代码转换
       ON P1.AC13BLTP=S2.SRC_CD_VAL  
;
-- ==============聚合层字段映射（第5组）==============
-- None
DROP TABLE IF EXISTS AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_05;

CREATE TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_05 (
     transq STRING COMMENT '主交易流水'
    ,detlsq STRING COMMENT '明细序号'
    ,trandt STRING COMMENT '交易日期'
    ,acctno STRING COMMENT '账号'
    ,opcuac STRING COMMENT 'opcuac'
    ,card_bin_no STRING COMMENT 'card_bin_no'
    ,card_length STRING COMMENT 'card_length'
    ,bank_name STRING COMMENT 'bank_name'
    ,CNTPTY_BANK_NO STRING COMMENT '对方行号'
    ,CNTPTY_BANK_NAME STRING COMMENT '对方行名'
)
USING ORC
COMMENT 'None'
OPTIONS (compression 'zstd')
;

INSERT INTO TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_05(
     transq -- 主交易流水
    ,detlsq -- 明细序号
    ,trandt -- 交易日期
    ,acctno -- 账号
    ,opcuac -- opcuac
    ,card_bin_no -- card_bin_no
    ,card_length -- card_length
    ,bank_name -- bank_name
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
)
SELECT
     P.transq AS transq -- 主交易流水
    ,P.detlsq AS detlsq -- 明细序号
    ,P.trandt AS trandt -- 交易日期
    ,p.acctno AS acctno -- 账号
    ,p.opcuac AS opcuac -- opcuac
    ,p.card_bin_no AS card_bin_no -- card_bin_no
    ,p.card_length AS card_length -- card_length
    ,p.bank_name AS bank_name -- bank_name
    ,P.CNTPTY_BANK_NO AS CNTPTY_BANK_NO -- 对方行号
    ,P.CNTPTY_BANK_NAME AS CNTPTY_BANK_NAME -- 对方行名
FROM
( 
 SELECT
 P1.transq
  ,P1.detlsq
  ,P1.trandt
  ,P1.acctno
  ,p1.opcuac
  ,p14.bank_no
  ,p14.card_bin_no
  ,p14.card_length
  ,p14.bank_name
  ,case when (trim(P1.bankcd) = '' or P1.bankcd is null) and (P1.opbrch = '999000' or trim(P1.opbrch)='' or P1.opbrch is null)
then case when substr(P1.opcuac,1,6)<>'933000'
then case when substr(P1.opcuac,1,10)=P14.card_bin_no then P14.bank_no else case when substr(P1.opcuac,1,9)=P14.card_bin_no then P14.bank_no
else case when substr(P1.opcuac,1,8)=P14.card_bin_no then P14.bank_no else case when substr(P1.opcuac,1,7)=P14.card_bin_no then P14.bank_no
else case when substr(P1.opcuac,1,6)=P14.card_bin_no then P14.bank_no else case when substr(P1.opcuac,1,5)=P14.card_bin_no then P14.bank_no
else case when substr(P1.opcuac,1,4)=P14.card_bin_no then P14.bank_no end end end end end end end when substr(P1.opcuac,1,6)='93300' then '403100000004'
else case when length(trim(P1.bankcd))>0 then P1.bankcd else P1.opbrch end end end  as CNTPTY_BANK_NO
,case when (trim(P1.bankcd) = '' or P1.bankcd is null) and (P1.opbrch = '999000' or trim(P1.opbrch)='' or P1.opbrch is null)
then case when substr(P1.opcuac,1,6)<>'933000'
then case when substr(P1.opcuac,1,10)=P14.card_bin_no then P14.bank_name else case when substr(P1.opcuac,1,9)=P14.card_bin_no then P14.bank_name
else case when substr(P1.opcuac,1,8)=P14.card_bin_no then P14.bank_name else case when substr(P1.opcuac,1,7)=P14.card_bin_no then P14.bank_name
else case when substr(P1.opcuac,1,6)=P14.card_bin_no then P14.bank_name else case when substr(P1.opcuac,1,5)=P14.card_bin_no then P14.bank_name
else case when substr(P1.opcuac,1,4)=P14.card_bin_no then P14.bank_name end end end end end end end when substr(P1.opcuac,1,6)='93300' then '403100000004'
else case when length(trim(P1.bankcd))>0 then P1.bankcd else P1.opbrch end end end  as CNTPTY_BANK_NAME
,row_number()over(partition by P1.transq,P1.detlsq,P1.trandt,P1.acctno order by p1.opcuac desc ) rn 
 FROM
 ODS_NAS.ODS_NAS_KNL_BILL_TA AS P1 -- 账户余额发生明细
 
 INNER  JOIN 
  ( 
   select D2.acctno,
    d2.corpno  
   from ODS_NAS.ODS_NAS_KNA_ACCS_TF D2 --用于数据过滤
   where D2.pt_dt  = '${process_date}' 
    and D2.fcflag  = '0204'
    and D2.del_f  = '0'
  ) AS P2 -- 负债账号客户账号对照表  
        ON P1.ACCTNO = P2.ACCTNO 
   --AND P2.CORPNO=P1.CORPNO 
 
 left join 
  (
   select 
           T1.bank_no,
           T1.card_bin_no, --卡bin号
           T1.bank_name,   --银行名称
           T1.card_length  --卡长度
     from ODS_UPPRUN.ODS_UPPRUN_CARD_BIN_AND_BANKNO_RELATIONSHIP_TF T1 --超级（农信银）卡bin号表
   where T1.del_f='0'
    AND T1.PT_DT = '${process_date}'
    and T1.tunnel_id = 'IBPS'
    and T1.card_bin_no = '6223093370'
   group by T1.bank_no,
     T1.card_bin_no,
     T1.bank_name,
     T1.card_length
  ) AS P14 -- None
       
 ON length(P1.opcuac) = CAST(P14.card_length AS BIGINT)
 and ((substr(P1.opcuac,1,10)=P14.card_bin_no )
      or (substr(P1.opcuac,1,9)=P14.card_bin_no)
      or (substr(P1.opcuac,1,8)=P14.card_bin_no)
      or (substr(P1.opcuac,1,7)=P14.card_bin_no)
      or (substr(P1.opcuac,1,6)=P14.card_bin_no)
      or (substr(P1.opcuac,1,5)=P14.card_bin_no)
      or (substr(P1.opcuac,1,4)=P14.card_bin_no)) 
 
 where p1.pt_dt = '${process_date}'
 and p1.del_f = '0'
 ) AS P -- 账户余额发生明细

WHERE P.RN =1
;
-- ==============聚合层字段映射（第6组）==============
-- 个人活期存款账户交易明细还原聚合

INSERT INTO TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM(
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NO -- 交易账户编号
    ,EACCT_NO -- 电子账户编号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,FORGN_RELAT_PAY_CLS_CD -- 涉外收支交易分类代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_DIR_CTRY_CD -- 交易去向国家代码
    ,CROSS_BORDER_TXN_FLAG -- 跨境交易标志
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AL_AUTH_FLAG -- 已授权标志
    ,AUTH_TELR_NO -- 授权柜员编号
    ,REMOTE_AUTH_AUDIT_TELR_NO -- 远程授权审核柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,UN_CNTER_TXN_FLAG -- 非柜台交易标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CHNL_CLS_CD -- 渠道分类代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,HOST_START_UP_ORIG_TRAN_CD -- 主机启动原交易码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_TERMN_CD -- 交易终端号
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,STRK_BAL_TYPE_CD -- 抹账类型代码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,AGENT_NATION_CD -- 代理人国籍代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
)
SELECT
     P1.transq AS ORIG_TXN_SER_NO -- 原交易流水号
    ,P1.detlsq AS SUB_TXN_SER_NO -- 子交易流水号
    ,P1.trandt AS TXN_ACCTN_DT -- 交易记账日期
    ,P1.trantm AS TXN_TM_STAMP -- 交易时间戳
    ,P1.ussqno AS TELR_SER_NO -- 柜员流水号
    ,P1.procsq AS FRONT_SER_NO -- 前置流水号
    ,P1.acctno AS TXN_ACCT_NO -- 交易账户编号
    ,P3.CUSTAC AS EACCT_NO -- 电子账户编号
    ,'' AS OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,P1.acctna AS TXN_ACCT_NAME -- 交易账户名称
    ,p4.CUSTID AS USER_ID -- 用户ID
    ,CASE WHEN TRIM(T4.CUST_INNER_ID)<>'' THEN TRIM(T4.CUST_INNER_ID) ELSE P4.CUSTCD END AS CUST_IN_CD -- 客户内码
    ,p3.acctna AS CUST_NAME -- 客户名称
    ,p31.INCTRY AS NATION_CD -- 国籍代码
    ,P6.CRTF_TYP AS DOCTYP_CD -- 证件类型代码
    ,P6.CRTF_NO AS DOC_NO -- 证件号码
    ,'1' AS ACCT_TYPE_CD -- 账户类型代码
    ,CASE WHEN P7.ACCATP = '1'  AND P3.ACSETP= '01'  
     THEN '0011'
     WHEN P7.ACCATP = '2'  AND P3.ACSETP= '01'  
  THEN '0013'
     WHEN P7.ACCATP = '3' AND P3.ACSETP= '03'
  THEN 'W003'
     WHEN P7.ACCATP = '3' AND P3.ACSETP= '02' 
  THEN '0014'
     WHEN P3.ACSETP IN ('04','08') 
  THEN '0012'
     WHEN P3.ACSETP = '01' AND P7.ACCATP IS NULL 
  THEN '0011'
     WHEN P3.ACSETP = '02' AND P7.ACCATP IS NULL 
  THEN '0014'
     ELSE 'W9999' 
END AS ACCT_PROPTY_CD -- 账户性质代码
    ,P1.trancy AS TXN_CURR_CD -- 交易币种代码
    ,CASE WHEN P1.CSEXTG IS NULL OR TRIM(P1.CSEXTG)='' 
     THEN '' 
ELSE COALESCE(TRIM(S1.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CSEXTG)),'') END
 AS TXN_CASH_RMT_CD -- 交易钞汇代码
    ,P1.intrcd AS TRAN_CD -- 交易码
    ,CASE WHEN P1.AMNTCD IS NULL OR TRIM(P1.AMNTCD)='' 
     THEN '' 
ELSE COALESCE(TRIM(S2.TARGET_CD_VAL), CONCAT('@',TRIM(P1.AMNTCD)),'') END
 AS TXN_DIR_CD -- 交易方向代码
    ,CASE WHEN P1.CORRTG = '1' THEN '2'
     WHEN P1.STACPS = '1' THEN '3'
     WHEN P1.STACPS = '2' THEN '4'
     ELSE '1' 
END  AS TXN_TYPE_CD -- 交易类型代码
    ,CASE WHEN P1.CDTRFG= '0' 
     THEN '1' 
     ELSE '2'
END AS CASH_TRAN_IDNT_CD -- 现转标识代码
    ,P1.tranam AS TXN_AMT -- 交易金额
    ,CASE WHEN  P1.trancy = 'CNY' THEN P1.tranam ELSE P1.tranam*(coalesce(P8.YRCAEXRT,0)/coalesce(P8.YRCACUNO,100))  END  AS TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,CASE WHEN  P1.trancy = 'CNY' THEN P1.tranam/coalesce(P19.YRCAEXRT,0)*coalesce(P19.YRCACUNO,100)  
when P1.trancy = 'USD'  THEN P1.tranam  
ELSE (P1.tranam*coalesce(P8.YRCAEXRT,0)/coalesce(P8.YRCACUNO,100))/COALESCE(P19.YRCAEXRT,0)*coalesce(P19.YRCACUNO,100) END
 AS TXN_AMT_CONVT_USD -- 交易金额折美元
    ,P1.acctbl AS ACCT_BAL -- 账户余额
    ,P1.smrycd AS SUMMARY_CD -- 摘要代码
    ,P1.smryds AS SUMMARY_DESC -- 摘要描述
    ,P10.subject AS ACCTN_SUBJ_NO -- 会计科目编号
    ,P10.description AS ACCTN_SUBJ_NAME -- 会计科目名称
    ,'' AS FORGN_RELAT_PAY_CLS_CD -- 涉外收支交易分类代码
    ,P3.PRODCD AS DPSIT_PROD_CD -- 存款产品代码
    ,P13.prodtx AS DPSIT_PROD_NAME -- 存款产品名称
    ,P1.opcuac AS CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,P1.opacna AS CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,P14.CNTPTY_BANK_NO AS CNTPTY_BANK_NO -- 对方行号
    ,P14.CNTPTY_BANK_NAME AS CNTPTY_BANK_NAME -- 对方行名
    ,'156' AS TXN_DIR_CTRY_CD -- 交易去向国家代码
    ,'1' AS CROSS_BORDER_TXN_FLAG -- 跨境交易标志
    ,P1.tranbr AS TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,P15.ORCAATDR AS TXN_RGN_NO -- 交易地区编号
    ,P1.userid AS TXN_TELR_NO -- 交易柜员编号
    ,'' AS AL_AUTH_FLAG -- 已授权标志
    ,P1.authus AS AUTH_TELR_NO -- 授权柜员编号
    ,'' AS REMOTE_AUTH_AUDIT_TELR_NO -- 远程授权审核柜员编号
    ,'' AS CHECKER_NO -- 复核人柜员编号
    ,'' AS INITR_SYS_CD -- 发起方系统代码
    ,'1' AS UN_CNTER_TXN_FLAG -- 非柜台交易标志
    ,P1.servtp AS TXN_CHNL_CD -- 交易渠道代码
    ,'' AS CHNL_CLS_CD -- 渠道分类代码
    ,'' AS TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,'' AS HOST_START_UP_ORIG_TRAN_CD -- 主机启动原交易码
    ,'' AS SUB_TRAN_CD -- 子交易码
    ,'' AS TXN_TERMN_CD -- 交易终端号
    ,case when coalesce(trim(p1.oppomk),'') = ''  then '' when length(p1.oppomk) <=2 then P1.oppomk
else split(P1.oppomk,'\|,')[1]    end AS TXN_EQUIP_IP -- 交易设备IP
    ,case when coalesce(trim(p1.oppomk),'') = ''  then '' when length(p1.oppomk) <=2 then P1.oppomk
else split(P1.oppomk,'\|,')[8]    end AS TXN_EQUIP_MAC -- 交易设备MAC
    ,'' AS OBANK_EMPLY_FLAG -- 本行员工标志
    ,P1.dcmttp AS TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,P1.dcbtno AS TXN_VOCH_NO -- 交易凭证号码
    ,CASE WHEN P1.CORRTG IS NULL OR TRIM(P1.CORRTG)='' 
     THEN '' 
ELSE COALESCE(TRIM(S3.TARGET_CD_VAL), CONCAT('@',TRIM(P1.CORRTG)),'') END AS STRK_BAL_TYPE_CD -- 抹账类型代码
    ,P16.agidtp AS AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,P16.agidno AS AGENT_DOC_NO -- 代理人证件号码
    ,P16.agname AS AGENT_NAME -- 代理人名称
    ,P16.agtlno AS AGENT_CONT_MODE -- 代理人联系方式
    ,P18.NTNLT AS AGENT_NATION_CD -- 代理人国籍代码
    ,P1.corpno||'000' AS BELONG_ORG_NO -- 归属机构编号
    ,P1.corpno AS STAT_ORG_NO -- 统计机构编号
    ,P1.corpno AS LP_ORG_NO -- 法人机构编号
    ,P1.remark AS REM -- 备注
    ,unifiedTime(P1.timetm) AS SETUP_DT -- 建立日期
    ,P1.timetm AS SETUP_TM_STAMP -- 建立时间戳
    ,'' AS SETUP_TELR_NO -- 建立柜员编号
    ,'' AS FINAL_MODIF_DT -- 最后修改日期
    ,'' AS FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,'' AS FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,'NAS' AS SRC_SYS_CD -- 来源系统代码
    ,'ODS_NAS_KNL_BILL_TF' AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,2 AS GRP_SER_NO -- 组序号
FROM
ODS_NAS.ODS_NAS_KNL_BILL_TA AS P1 -- 账户余额发生明细

INNER  JOIN ( 
 select D2.acctno,d2.corpno  from ODS_NAS.ODS_NAS_KNA_ACCS_TF D2 --用于数据过滤
 where D2.pt_dt  = '${process_date}' 
 and D2.fcflag  = '0204'
 and D2.del_f  = '0'
) AS P2 -- 负债账号客户账号对照表  
       ON P1.ACCTNO = P2.ACCTNO 
AND P2.CORPNO=P1.CORPNO 
LEFT JOIN (  
 select 
      d3.custno
     ,d3.acsetp
     ,d3.ACCTNO 
     ,D3.CUSTAC
,d3.prodcd
,d3.acctna 
 from 
 ods_nas.ODS_NAS_KNA_ACCT_TF d3 
 where  d3.PT_DT = '${process_date}'
) AS P3 -- 负债活期帐户信息表
       ON P1.ACCTNO = P3.ACCTNO 
LEFT JOIN (SELECT * FROM(
    SELECT
      CUSTNO
     ,CUSTID
     ,CUSTCD
     , ROW_NUMBER() OVER(PARTITION BY CUSTNO ORDER BY STATUS) RN
    FROM  ODS_NAS.ODS_NAS_CIF_CUST_ACCS_TF
    WHERE PT_DT = '${process_date}'  AND DEL_F = '0'
    )D4 WHERE D4.RN = 1 
) AS P4 -- 客户信息关联表
       ON P3.CUSTNO  = P4.CUSTNO 
LEFT JOIN (SELECT
  CUST_INNER_ID
 ,USER_ID
FROM  ODS_EICC.ODS_EICC_U_USER_INNER_BAS_TF
WHERE PT_DT = '${process_date}'  AND DEL_F = '0'
) AS T4 -- 用户信息表
       ON T4.USER_ID=P4.CUSTID 
LEFT JOIN (
SELECT
  P1.INCTRY
 ,P1.CUSTID 
FROM ODS_ICF.ODS_ICF_SCMS_CUST_TF P1
WHERE P1.PT_DT = '${process_date}' AND P1.DEL_F = '0'
) AS P31 -- None
       ON P4.CUSTID  = P31.CUSTID 
LEFT JOIN (
   select D6.CST_IN_CD
     ,D6.CRTF_TYP
     ,D6.CRTF_NO
    from 
    (
        SELECT 
             U13.CRTF_TYP
            ,U13.CRTF_NO
            ,U13.CST_IN_CD
            ,row_number()over(partition by U13.CST_IN_CD order by U13.crtf_no desc ) rn
        FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF U13
        WHERE  U13.PT_DT = '${process_date}'
        and U13.DEL_F = '0'
        and U13.MAJOR_FLG = '1'
        and U13.DELETED = '0'

    ) D6
   where D6.RN = 1
) AS P6 -- 客户证件信息表
       ON P4.custcd = P6.CST_IN_CD 
LEFT JOIN (  
 select 
      d7.ACCATP
     ,d7.acctno 
     ,d7.corpno
  
 from 
 ods_nas.ODS_NAS_KNA_ACCT_ADDT_TF d7 
 where  d7.PT_DT = '${process_date}'
  and d7.del_f = '0'
) AS P7 -- 负债账户附加信息表
       ON P3.acctno = P7.acctno 
--AND P1.CORPNO = P7.CORPNO 
LEFT JOIN (
    SELECT 
        D8.YRCAEXRT
        ,D8.YRCACUNO
        ,D8.YRCACCYC 
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D8
    WHERE  D8.PT_DT = '${process_date}'
        AND  CAST(D8.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D8.YRCARS1B <> '9'

) AS P8 -- 年度报表汇率文件
       ON P1.trancy = P8.YRCACCYC 
LEFT JOIN (
 select
  transq,
  amntcd,
  acctno,
  toacct,
  dtitcd,
  tranms
 from
  ods_nas.ods_nas_KNS_ACSQ_tf p
 where
  p.del_f = '0'
  and ATOWTP = '0'
  and pt_dt = '${process_date}'
 group by
  transq,
  amntcd,
  acctno,
  toacct,
  dtitcd,
  tranms) AS P12 -- 定期负债账户表
       ON p12.TRANSQ = p1.TRANSQ
 and p12.AMNTCD = p1.AMNTCD
 and p12.ACCTNO = p1.ACCTNO
 and p12.TOACCT = p1.OPCUAC 
LEFT JOIN (
select
 CASE WHEN coalesce(TRIM(D1.SUBJECT_DR),'') <>''  
                   THEN D1.SUBJECT_DR 
                   ELSE D1.SUBJECT_CR
              END SUBJECT,
 D2.description,
 D1.product ,
 D1.EVENT_TYPE
 
from
 ods_GAS.ods_GAS_CUX_EA_RULES_tf D1
left join ODS_GAS.ODS_GAS_cux_flex_values_v_TF D2
on
  CASE WHEN coalesce(TRIM(D1.SUBJECT_DR),'') <>''  
                   THEN D1.SUBJECT_DR 
                   ELSE D1.SUBJECT_CR
              END  = D2.flex_value
 and D2.pt_dt ='${process_date}'
 and D2.DEL_F = '0'
where D1.pt_dt  = '${process_date}'
and D1.DEL_F = '0'
) AS P10 -- 会计核算规则定义
       ON P12.DTITCD = P10.PRODUCT
 and P10.EVENT_TYPE = P12.TRANMS 
LEFT JOIN (  
 select 
     d13.prodtx
     ,d13.prodcd 
  
 from 
 ods_nas.ODS_NAS_KUP_DPPB_TF d13
 where  d13.PT_DT = '${process_date}'
) AS P13 -- 网络核心产品表
       ON P3.prodcd = P13.prodcd 
LEFT JOIN AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_05 AS P14 -- None
       ON P1.ACCTNO =P14.ACCTNO
AND P1.DETLSQ =P14.DETLSQ
AND P1.TRANDT =P14.TRANDT
AND P1.TRANSQ =P14.TRANSQ 
LEFT JOIN (  
 select 
  d15.ORCAATDR
  ,d15.ORCABRNO
  
 from 
 ods_CORE.ODS_CORE_BBFMORGA_TF d15
 where  d15.PT_DT = '${process_date}'
  and d15.del_f = '0'
  AND D15.ORCARS1B <> '9'
)
 AS P15 -- 机构信息表
       ON P1.TRANBR = P15.ORCABRNO 
LEFT JOIN (  
 select 
     D16.agidtp
     ,D16.agidno
     ,D16.agname
     ,D16.agtlno
     ,D16.CORPNO
     ,D16.ACCTNO
 from 
 ods_NAS.ODS_NAS_KNB_DCMT_TF d16
 where  d16.PT_DT = '${process_date}'
  and d16.del_f = '0'
) AS P16 -- 凭证登记簿
       ON P1.acctno = P16.acctno 
AND P1.CORPNO = P16.CORPNO 
LEFT JOIN (
   select D13.CST_IN_CD
     ,D13.CRTF_TYP
     ,D13.CRTF_NO
    from 
    (
        SELECT 
             U13.CRTF_TYP
            ,U13.CRTF_NO
            ,U13.CST_IN_CD
            ,row_number()over(partition by U13.CST_IN_CD order by U13.org_modified desc ) rn
        FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_CRTF_TF U13
        WHERE  U13.PT_DT = '${process_date}'
    ) D13
   where D13.RN = 1
) AS P17 -- 客户证件信息表
       ON P16.AGIDNO = P17.CRTF_NO
AND P16.AGIDTP= P17.CRTF_TYP 
LEFT JOIN (
    SELECT 
        D5.CUST_NM
       ,D5.CST_IN_CD
    ,D5.NTNLT
    FROM ODS_EICC.ODS_EICC_C_CUS_PRIV_BAS_TF D5
    WHERE  D5.PT_DT = '${process_date}'
) AS P18 -- 客户基础信息表
       ON P17.CST_IN_CD = P18.CST_IN_CD 
LEFT JOIN (
    SELECT 
        D19.YRCAEXRT
        ,D19.YRCACUNO
        ,D19.YRCACCYC 
        ,D19.PT_DT
    FROM ODS_CORE.ODS_CORE_AFFMYRPT_TF D19
    WHERE  D19.PT_DT = '${process_date}'
        AND  CAST(D19.YRCADATE AS STRING) = REPLACE('${process_date}','-','')  --跑批日，因为有可能会追跑历史数据
        AND D19.YRCARS1B <> '9'
        AND D19.YRCACCYC = 'USD' 

)  AS P19 -- 年度报表汇率文件
       ON P1.PT_DT = P19.PT_DT 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     where  p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNL_BILL' 
     AND p1.SRC_FIELD_EN_NAME='CSEXTG' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA'  
     AND p1.TARGET_FIELD_EN_NAME='TXN_CASH_RMT_CD' 
)  AS S1 -- 代码转换
       ON P1.CSEXTG=S1.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     where  p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNL_BILL' 
     AND p1.SRC_FIELD_EN_NAME='AMNTCD' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA'  
     AND p1.TARGET_FIELD_EN_NAME='TXN_DIR_CD' 
)  AS S2 -- 代码转换
       ON P1.AMNTCD=S2.SRC_CD_VAL 
LEFT JOIN (
 SELECT 
      P1.TARGET_CD_VAL
     ,P1.SRC_CD_VAL  
 FROM AGL.PUB_CD_MAP  P1
     where  p1.SRC_TAB_LIB_NAME ='NAS' 
     AND p1.SRC_TAB_EN_NAME='KNL_BILL' 
     AND p1.SRC_FIELD_EN_NAME='CORRTG' 
     AND p1.TARGET_TAB_EN_NAME='AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA'  
     AND p1.TARGET_FIELD_EN_NAME='STRK_BAL_TYPE_CD' 
)  AS S3 -- 代码转换
       ON P1.CORRTG=S3.SRC_CD_VAL 
WHERE P1.PT_DT = '${process_date}'
AND P1.DEL_F = '0'
;

/* 3.1 drop target table's today partition */
ALTER TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
ALTER TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 3.2 put data into target table */
INSERT INTO AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA PARTITION(PT_DT = '${process_date}')
SELECT
     ORIG_TXN_SER_NO -- 原交易流水号
    ,SUB_TXN_SER_NO -- 子交易流水号
    ,TXN_ACCTN_DT -- 交易记账日期
    ,TXN_TM_STAMP -- 交易时间戳
    ,TELR_SER_NO -- 柜员流水号
    ,FRONT_SER_NO -- 前置流水号
    ,TXN_ACCT_NO -- 交易账户编号
    ,EACCT_NO -- 电子账户编号
    ,OLD_SYS_TXN_ACCT_NO -- 老系统交易账户编号
    ,TXN_ACCT_NAME -- 交易账户名称
    ,USER_ID -- 用户ID
    ,CUST_IN_CD -- 客户内码
    ,CUST_NAME -- 客户名称
    ,NATION_CD -- 国籍代码
    ,DOCTYP_CD -- 证件类型代码
    ,DOC_NO -- 证件号码
    ,ACCT_TYPE_CD -- 账户类型代码
    ,ACCT_PROPTY_CD -- 账户性质代码
    ,TXN_CURR_CD -- 交易币种代码
    ,TXN_CASH_RMT_CD -- 交易钞汇代码
    ,TRAN_CD -- 交易码
    ,TXN_DIR_CD -- 交易方向代码
    ,TXN_TYPE_CD -- 交易类型代码
    ,CASH_TRAN_IDNT_CD -- 现转标识代码
    ,TXN_AMT -- 交易金额
    ,TXN_AMT_CONVT_RMB -- 交易金额折人民币
    ,TXN_AMT_CONVT_USD -- 交易金额折美元
    ,ACCT_BAL -- 账户余额
    ,SUMMARY_CD -- 摘要代码
    ,SUMMARY_DESC -- 摘要描述
    ,ACCTN_SUBJ_NO -- 会计科目编号
    ,ACCTN_SUBJ_NAME -- 会计科目名称
    ,FORGN_RELAT_PAY_CLS_CD -- 涉外收支交易分类代码
    ,DPSIT_PROD_CD -- 存款产品代码
    ,DPSIT_PROD_NAME -- 存款产品名称
    ,CNTPTY_TXN_ACCT_NO -- 对方交易账户编号
    ,CNTPTY_TXN_ACCT_NAME -- 对方交易账户名称
    ,CNTPTY_BANK_NO -- 对方行号
    ,CNTPTY_BANK_NAME -- 对方行名
    ,TXN_DIR_CTRY_CD -- 交易去向国家代码
    ,CROSS_BORDER_TXN_FLAG -- 跨境交易标志
    ,TXN_HAPP_ORG_NO -- 交易发生机构编号
    ,TXN_RGN_NO -- 交易地区编号
    ,TXN_TELR_NO -- 交易柜员编号
    ,AL_AUTH_FLAG -- 已授权标志
    ,AUTH_TELR_NO -- 授权柜员编号
    ,REMOTE_AUTH_AUDIT_TELR_NO -- 远程授权审核柜员编号
    ,CHECKER_NO -- 复核人柜员编号
    ,INITR_SYS_CD -- 发起方系统代码
    ,UN_CNTER_TXN_FLAG -- 非柜台交易标志
    ,TXN_CHNL_CD -- 交易渠道代码
    ,CHNL_CLS_CD -- 渠道分类代码
    ,TELR_INPUT_ORIG_TRAN_CD -- 柜员输入原交易码
    ,HOST_START_UP_ORIG_TRAN_CD -- 主机启动原交易码
    ,SUB_TRAN_CD -- 子交易码
    ,TXN_TERMN_CD -- 交易终端号
    ,TXN_EQUIP_IP -- 交易设备IP
    ,TXN_EQUIP_MAC -- 交易设备MAC
    ,OBANK_EMPLY_FLAG -- 本行员工标志
    ,TXN_VOCH_CATE_CD -- 交易凭证种类代码
    ,TXN_VOCH_NO -- 交易凭证号码
    ,STRK_BAL_TYPE_CD -- 抹账类型代码
    ,AGENT_DOCTYP_CD -- 代理人证件类型代码
    ,AGENT_DOC_NO -- 代理人证件号码
    ,AGENT_NAME -- 代理人名称
    ,AGENT_CONT_MODE -- 代理人联系方式
    ,AGENT_NATION_CD -- 代理人国籍代码
    ,BELONG_ORG_NO -- 归属机构编号
    ,STAT_ORG_NO -- 统计机构编号
    ,LP_ORG_NO -- 法人机构编号
    ,REM -- 备注
    ,SETUP_DT -- 建立日期
    ,SETUP_TM_STAMP -- 建立时间戳
    ,SETUP_TELR_NO -- 建立柜员编号
    ,FINAL_MODIF_DT -- 最后修改日期
    ,FINAL_MODIF_TM_STAMP -- 最后修改时间戳
    ,FINAL_MODIF_TELR_NO -- 最后修改柜员编号
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM
;


/* 4.1 drop temp table */
DROP TABLE AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_TM;
DROP TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_01;
DROP TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_02;
DROP TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_03;
DROP TABLE AGL.TMP_AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA_05;
