-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人活期存款账户交易明细还原聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA
--     表中文名：个人活期存款账户交易明细还原聚合
--     创建日期：2023-12-29 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_ACCTN_DT, TXN_ACCT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-29 00:00:00 游崔龙 新增
--         2024-07-23 00:00:00 魏丹丹 修改模板
--         2024-09-06 00:00:00 魏丹丹 新增电子账户字段，同步20240902 版本
--         2024-09-13 00:00:00 魏丹丹 修改逻辑取值
--         2024-10-19 00:00:00 魏丹丹 修改设计2024/9/27的更新
--         2024-11-19 00:00:00 魏丹丹 修改第二组用户ID，客户内码的取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_ACCTN_DT, TXN_ACCT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ORIG_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SUB_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_ACCTN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_ACCT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TELR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TELR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('FRONT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND FRONT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('EACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND EACCT_NO like '@%';

   SELECT
       ''
      ,CAST('OLD_SYS_TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND OLD_SYS_TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('NATION_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND NATION_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_TRAN_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_TRAN_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT_CONVT_USD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT_CONVT_USD like '@%';

   SELECT
       ''
      ,CAST('ACCT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BAL like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_DESC like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('FORGN_RELAT_PAY_CLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND FORGN_RELAT_PAY_CLS_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_TXN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_TXN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_DIR_CTRY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DIR_CTRY_CD like '@%';

   SELECT
       ''
      ,CAST('CROSS_BORDER_TXN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CROSS_BORDER_TXN_FLAG like '@%';

   SELECT
       ''
      ,CAST('TXN_HAPP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_HAPP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AL_AUTH_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AL_AUTH_FLAG like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('REMOTE_AUTH_AUDIT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND REMOTE_AUTH_AUDIT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHECKER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECKER_NO like '@%';

   SELECT
       ''
      ,CAST('INITR_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND INITR_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('UN_CNTER_TXN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND UN_CNTER_TXN_FLAG like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('CHNL_CLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_CLS_CD like '@%';

   SELECT
       ''
      ,CAST('TELR_INPUT_ORIG_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TELR_INPUT_ORIG_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_START_UP_ORIG_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_START_UP_ORIG_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('SUB_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_TERMN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TERMN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_EQUIP_IP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_EQUIP_IP like '@%';

   SELECT
       ''
      ,CAST('TXN_EQUIP_MAC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_EQUIP_MAC like '@%';

   SELECT
       ''
      ,CAST('OBANK_EMPLY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND OBANK_EMPLY_FLAG like '@%';

   SELECT
       ''
      ,CAST('TXN_VOCH_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_VOCH_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_VOCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_VOCH_NO like '@%';

   SELECT
       ''
      ,CAST('STRK_BAL_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND STRK_BAL_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('AGENT_CONT_MODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AGENT_CONT_MODE like '@%';

   SELECT
       ''
      ,CAST('AGENT_NATION_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND AGENT_NATION_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_TXN_DTL_RESTORE_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */