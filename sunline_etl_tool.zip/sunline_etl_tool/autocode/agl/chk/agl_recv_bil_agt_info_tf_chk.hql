-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_AGT_INFO_TF
--     表中文名：收单协议信息聚合
--     创建日期：2023-12-19 00:00:00
--     主键字段：MERCHT_IDTFY_NO, RECV_BIL_PROD_NO, SPC_ARGMT_MERCHT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军/魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-19 00:00:00 沈健 新增
--         2024-08-01 00:00:00 王穆军/魏丹丹 修改同步设计文档，修改筛选条件，码值映射
--         2024-08-28 00:00:00 王穆军/魏丹丹 新增字段，修改逻辑
--         2024-09-05 00:00:00 王穆军/魏丹丹 新增字段，修改码值
--         2024-09-25 00:00:00 王穆军/魏丹丹 修改0902 第6组主表变更



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(MERCHT_IDTFY_NO, RECV_BIL_PROD_NO, SPC_ARGMT_MERCHT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(MERCHT_IDTFY_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(RECV_BIL_PROD_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SPC_ARGMT_MERCHT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('MERCHT_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SIGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SIGN_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_AUDIT_SN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_AUDIT_SN like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SIGN_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SIGN_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_PROJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_PROJ_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_PROJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_PROJ_NAME like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_BRCH_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUB_BRCH_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BNKOUTLS_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_MDL_CATOGR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_MDL_CATOGR_CD like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_APP_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_APP_ID like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('LVL_ONE_MERCHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LVL_ONE_MERCHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHT_PLAT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_PLAT_NO like '@%';

   SELECT
       ''
      ,CAST('SUPER_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPER_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NAME like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_APP_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_APP_ID like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DIGIT_WALLET_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DIGIT_WALLET_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DIGIT_WALLET_ID_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DIGIT_WALLET_ID_NO like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTY_APP_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTY_APP_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTY_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTY_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('APP_SCENE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_SCENE_CD like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_SCENE_PLAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_SCENE_PLAT_CD like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_SCENE_PLAT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_SCENE_PLAT_NAME like '@%';

   SELECT
       ''
      ,CAST('HELP_FMR_MERCHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HELP_FMR_MERCHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SINGLE_CONSM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SINGLE_CONSM_LMT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_DACM_CONSM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_DACM_CONSM_LMT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_MACM_CONSM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_MACM_CONSM_LMT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SINGLE_TRAN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SINGLE_TRAN_LMT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_DACM_TRAN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_DACM_TRAN_LMT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_MACM_TRAN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_MACM_TRAN_LMT like '@%';

   SELECT
       ''
      ,CAST('POINT_DEDUCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_DEDUCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('POINT_DEDUCT_CEIL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_DEDUCT_CEIL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('POINT_DEDUCT_CEIL_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_DEDUCT_CEIL_VAL like '@%';

   SELECT
       ''
      ,CAST('OPEN_CUPNS_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_CUPNS_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('OPEN_RNDM_SUB_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_RNDM_SUB_FLAG like '@%';

   SELECT
       ''
      ,CAST('FEE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FEE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_CAP_STL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_CAP_STL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_CAP_STL_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_CAP_STL_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('REFUND_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_STL_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_STL_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('APP_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('APP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('AUDIT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('AUDIT_PASS_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_PASS_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MANY_CD_AUDIT_PASS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MANY_CD_AUDIT_PASS_DT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_MERCHT_SIGN_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_MERCHT_SIGN_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_MERCHT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_MERCHT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_FRZ_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_FRZ_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('FRZ_RSN_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_RSN_REM like '@%';

   SELECT
       ''
      ,CAST('RECNT_FRZ_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_FRZ_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_UNFRZ_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_UNFRZ_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('INPUT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('INPUT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */