-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡分期付款申请信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_INSTALMT_APP_INFO_TF
--     表中文名：信用卡分期付款申请信息聚合
--     创建日期：2024-03-06 00:00:00
--     主键字段：APLC_PART_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-06 00:00:00 龙耀超 创建
--         2024-10-14 00:00:00 魏丹丹 归属机构编号拼接‘000’



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(APLC_PART_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(APLC_PART_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('APLC_PART_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APLC_PART_NO like '@%';

   SELECT
       ''
      ,CAST('APP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_DT like '@%';

   SELECT
       ''
      ,CAST('APLC_PART_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APLC_PART_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('FAMILY_TEL_AREA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAMILY_TEL_AREA_CD like '@%';

   SELECT
       ''
      ,CAST('FAMILY_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAMILY_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('APP_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('APP_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MODIF_STATUS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODIF_STATUS_DT like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_TMS like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_AMT like '@%';

   SELECT
       ''
      ,CAST('EACH_TERM_APPORTION_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACH_TERM_APPORTION_AMT like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_TOTAL_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_TOTAL_LMT like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_ANL_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_ANL_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('REQUEST_FUND_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REQUEST_FUND_DT like '@%';

   SELECT
       ''
      ,CAST('INPUT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_DT like '@%';

   SELECT
       ''
      ,CAST('INPUT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('INPUT_OPERR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_OPERR like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_APP_SUCC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_APP_SUCC_FLAG like '@%';

   SELECT
       ''
      ,CAST('AUTH_APPRV_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_APPRV_CD like '@%';

   SELECT
       ''
      ,CAST('AUTH_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_CD like '@%';

   SELECT
       ''
      ,CAST('AUTH_DEAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_DEAL_DT like '@%';

   SELECT
       ''
      ,CAST('AUTH_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('AUTH_OPERR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_OPERR like '@%';

   SELECT
       ''
      ,CAST('AUTH_MSG_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_MSG_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */