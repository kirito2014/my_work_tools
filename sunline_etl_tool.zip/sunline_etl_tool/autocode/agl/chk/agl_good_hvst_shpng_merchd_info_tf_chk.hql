-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-丰收购商品信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF
--     表中文名：丰收购商品信息聚合
--     创建日期：2024-03-15 00:00:00
--     主键字段：MERCHD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-15 00:00:00 龙耀超 创建
--         2024-11-05 00:00:00 魏丹丹 补入缺失字段
--         2024-11-10 00:00:00 魏丹丹 修改商品审核状态代码取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(MERCHD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(MERCHD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('MERCHD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_NAME_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_NAME_1 like '@%';

   SELECT
       ''
      ,CAST('MERCHD_NAME_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_NAME_2 like '@%';

   SELECT
       ''
      ,CAST('MERCHD_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LABEL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LABEL_DESC like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SHOP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_NO like '@%';

   SELECT
       ''
      ,CAST('MANUF_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MANUF_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHD_PRC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_PRC like '@%';

   SELECT
       ''
      ,CAST('MERCHD_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHD_AUDIT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_AUDIT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHD_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHD_PUT_ON_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_PUT_ON_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHD_PUT_OFF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_PUT_OFF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHD_ISSUE_PSN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_ISSUE_PSN_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_ISSUE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_ISSUE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHD_MODIF_PSN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_MODIF_PSN_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHD_TAX_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_TAX_RATE like '@%';

   SELECT
       ''
      ,CAST('MERCHD_ARTC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_ARTC_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_FROM_DRAW_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_FROM_DRAW_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHD_INSTMT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_INSTMT_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHD_QR_CD_URL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_QR_CD_URL like '@%';

   SELECT
       ''
      ,CAST('QR_CD_IMAGE_URL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND QR_CD_IMAGE_URL like '@%';

   SELECT
       ''
      ,CAST('TRANSPORT_FEE_TEMPLET_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TRANSPORT_FEE_TEMPLET_NO like '@%';

   SELECT
       ''
      ,CAST('RECNT_MT_SUB_ACT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MT_SUB_ACT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_RACT_START_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_RACT_START_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHD_RECNT_ACT_END_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_RECNT_ACT_END_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHD_INVTRY_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_INVTRY_CNT like '@%';

   SELECT
       ''
      ,CAST('MERCHD_INVTRY_CNT_WARN_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_INVTRY_CNT_WARN_VAL like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LMT_TM_SALES_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LMT_TM_SALES_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LMT_BUY_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LMT_BUY_CNT like '@%';

   SELECT
       ''
      ,CAST('SELL_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELL_CNT like '@%';

   SELECT
       ''
      ,CAST('TOTAL_SALES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TOTAL_SALES_CNT like '@%';

   SELECT
       ''
      ,CAST('MONTH_SALES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MONTH_SALES_CNT like '@%';

   SELECT
       ''
      ,CAST('RECNT_SALES_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_SALES_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SALES_AFT_SERV_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALES_AFT_SERV_DESC like '@%';

   SELECT
       ''
      ,CAST('ESTIM_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ESTIM_CNT like '@%';

   SELECT
       ''
      ,CAST('DEAL_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEAL_CNT like '@%';

   SELECT
       ''
      ,CAST('RECMD_RSN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECMD_RSN_DESC like '@%';

   SELECT
       ''
      ,CAST('MERCHD_SCORE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_SCORE like '@%';

   SELECT
       ''
      ,CAST('FAVOR_APPEAL_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAVOR_APPEAL_VAL like '@%';

   SELECT
       ''
      ,CAST('RECMD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECMD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CLS_MERCHD_RANK_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CLS_MERCHD_RANK_SER_NO like '@%';

   SELECT
       ''
      ,CAST('RECMD_MERCHD_RANK_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECMD_MERCHD_RANK_SER_NO like '@%';

   SELECT
       ''
      ,CAST('AUSLESE_MERCHD_RANK_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUSLESE_MERCHD_RANK_SER_NO like '@%';

   SELECT
       ''
      ,CAST('AVAILBL_CLS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVAILBL_CLS_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LVL_THREE_CLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LVL_THREE_CLS_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LVL_THREE_CLS_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LVL_THREE_CLS_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LVL_TWO_CLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LVL_TWO_CLS_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LVL_TWO_CLS_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LVL_TWO_CLS_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHD_LVL_ONE_CLS_RANK_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_LVL_ONE_CLS_RANK_SER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_CLS_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_CLS_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('INFNT_SCRL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFNT_SCRL_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */