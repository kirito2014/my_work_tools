-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单服务商信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_SERV_PROVDER_INFO_TF
--     表中文名：收单服务商信息聚合
--     创建日期：2024-03-14 00:00:00
--     主键字段：SERV_PROVDER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-14 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(SERV_PROVDER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(SERV_PROVDER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SERV_PROVDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NAME like '@%';

   SELECT
       ''
      ,CAST('BELONG_LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_LP_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_LP_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_ORG_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_ORG_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CO_PARTNER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CO_PARTNER_NO like '@%';

   SELECT
       ''
      ,CAST('PARTNER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARTNER_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('REG_CAP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_CAP like '@%';

   SELECT
       ''
      ,CAST('REG_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_ADDR like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_OUTSR_REC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_OUTSR_REC_NO like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DOC_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_NAME like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOC_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOC_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_EMAIL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_EMAIL_ADDR like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_OPEN_ACCT_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_OPEN_ACCT_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('STL_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_SUBMIT_APP_FUNC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_SUBMIT_APP_FUNC_FLAG like '@%';

   SELECT
       ''
      ,CAST('DVLP_PROD_ABIL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DVLP_PROD_ABIL_DESC like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CAN_EXPAND_MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAN_EXPAND_MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RESTR_INDUS_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESTR_INDUS_DESC like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_OPER_APP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_OPER_APP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_BIZ_RELA_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_BIZ_RELA_DT like '@%';

   SELECT
       ''
      ,CAST('TERMI_BIZ_RELA_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TERMI_BIZ_RELA_DT like '@%';

   SELECT
       ''
      ,CAST('INPUT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('INPUT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_AUDIT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_AUDIT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('AUDIT_SN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_SN like '@%';

   SELECT
       ''
      ,CAST('AUDIT_INFO_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_INFO_REM like '@%';

   SELECT
       ''
      ,CAST('AUDIT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SERV_PROVDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */