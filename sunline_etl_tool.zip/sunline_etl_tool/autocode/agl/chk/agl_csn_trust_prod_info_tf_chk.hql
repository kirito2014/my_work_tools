-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-代销信托产品信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CSN_TRUST_PROD_INFO_TF
--     表中文名：代销信托产品信息聚合
--     创建日期：2023-12-27 00:00:00
--     主键字段：TA_CD, PROD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-27 00:00:00 魏丹丹 新增
--         2024-05-22 00:00:00 魏丹丹 删除字段
--         2024-09-02 00:00:00 魏丹丹 修改字段名
--         2024-09-26 00:00:00 魏丹丹 加表，加字段



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TA_CD, PROD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TA_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(PROD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SALPSN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALPSN_NO like '@%';

   SELECT
       ''
      ,CAST('TA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TA_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_ABB like '@%';

   SELECT
       ''
      ,CAST('CSN_TRUST_PROD_ATTR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSN_TRUST_PROD_ATTR_CD like '@%';

   SELECT
       ''
      ,CAST('CSN_TRUST_PROD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSN_TRUST_PROD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('STL_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_ISSUER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_ISSUER_NAME like '@%';

   SELECT
       ''
      ,CAST('MGER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MGER_NO like '@%';

   SELECT
       ''
      ,CAST('CSDTY_ROW_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSDTY_ROW_NAME like '@%';

   SELECT
       ''
      ,CAST('INVESTOR_EXP_LMT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVESTOR_EXP_LMT_FLAG like '@%';

   SELECT
       ''
      ,CAST('INVESTOR_LMT_COND_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVESTOR_LMT_COND_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_PAR_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_PAR_VAL like '@%';

   SELECT
       ''
      ,CAST('MKTING_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('DIVDND_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIVDND_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_SUBSCR_MNY_DRAW_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_SUBSCR_MNY_DRAW_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('EXPECT_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPECT_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_START_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_START_TM like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_END_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_END_TM like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_REDEM_START_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_REDEM_START_TM like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_REDEM_END_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_REDEM_END_TM like '@%';

   SELECT
       ''
      ,CAST('PROD_FUNDRS_START_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FUNDRS_START_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_FUNDRS_END_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FUNDRS_END_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_FOUND_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FOUND_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('RISK_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RISK_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_LOW_HOLD_SHARE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_LOW_HOLD_SHARE like '@%';

   SELECT
       ''
      ,CAST('BIZ_SWITCH_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_SWITCH_CD like '@%';

   SELECT
       ''
      ,CAST('CSN_TRUST_PROD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSN_TRUST_PROD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('FRONT_BACK_END_CHARGE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRONT_BACK_END_CHARGE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('EQTY_REG_DAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQTY_REG_DAY_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_FULLNAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FULLNAME like '@%';

   SELECT
       ''
      ,CAST('CSRC_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSRC_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_FLOR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_FLOR like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_CEIL like '@%';

   SELECT
       ''
      ,CAST('MGMT_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MGMT_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('PROD_PRFT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_PRFT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('CSN_FIN_PROD_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSN_FIN_PROD_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('EXT_ORG_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXT_ORG_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_REG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_REG_NO like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_NOTE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_NOTE like '@%';

   SELECT
       ''
      ,CAST('OPER_WAY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_WAY_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_FLAG like '@%';

   SELECT
       ''
      ,CAST('ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SALPSN_NAME_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALPSN_NAME_ABB like '@%';

   SELECT
       ''
      ,CAST('SALPSN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALPSN_NAME like '@%';

   SELECT
       ''
      ,CAST('SELLER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELLER_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_TXN_FREQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_TXN_FREQ like '@%';

   SELECT
       ''
      ,CAST('BUY_RULE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BUY_RULE_DESC like '@%';

   SELECT
       ''
      ,CAST('PRFT_RULE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRFT_RULE_DESC like '@%';

   SELECT
       ''
      ,CAST('REDEM_RULE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_RULE_DESC like '@%';

   SELECT
       ''
      ,CAST('ARRIVE_ACCT_RULE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARRIVE_ACCT_RULE_DESC like '@%';

   SELECT
       ''
      ,CAST('REDEM_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_TM like '@%';

   SELECT
       ''
      ,CAST('ARRIVE_ACCT_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARRIVE_ACCT_TM like '@%';

   SELECT
       ''
      ,CAST('IDTFY_BUY_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IDTFY_BUY_FEE like '@%';

   SELECT
       ''
      ,CAST('APP_BUY_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_BUY_FEE like '@%';

   SELECT
       ''
      ,CAST('REDEM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_FEE like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_CHARGE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_CHARGE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_AL_SALES_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_AL_SALES_LMT like '@%';

   SELECT
       ''
      ,CAST('PROD_BEING_SALES_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_BEING_SALES_LMT like '@%';

   SELECT
       ''
      ,CAST('SALES_TOTAL_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALES_TOTAL_LMT like '@%';

   SELECT
       ''
      ,CAST('NET_VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NET_VAL_DT like '@%';

   SELECT
       ''
      ,CAST('ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('SM_DAY_FIN_PROD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SM_DAY_FIN_PROD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SM_DAY_TOTAL_SHARE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SM_DAY_TOTAL_SHARE like '@%';

   SELECT
       ''
      ,CAST('SM_DAY_PROD_NET_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SM_DAY_PROD_NET_VAL like '@%';

   SELECT
       ''
      ,CAST('CUM_NET_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUM_NET_VAL like '@%';

   SELECT
       ''
      ,CAST('PROD_CORP_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_CORP_YIELD like '@%';

   SELECT
       ''
      ,CAST('PROD_SEVEN_DAY_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_SEVEN_DAY_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('PROD_TEN_THSNDS_PRFT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_TEN_THSNDS_PRFT like '@%';

   SELECT
       ''
      ,CAST('FOUND_SINCE_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FOUND_SINCE_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('INDV_PROD_LOW_HOLD_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_PROD_LOW_HOLD_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INDV_SINGLE_MIN_REDEM_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SINGLE_MIN_REDEM_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INDV_SINGLE_DAY_CUM_BUY_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SINGLE_DAY_CUM_BUY_CEIL like '@%';

   SELECT
       ''
      ,CAST('INDV_SUBSCR_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SUBSCR_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_APP_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_APP_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_APP_SUPP_START_POINT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_APP_SUPP_START_POINT_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_REDEM_SINGLE_MAX_SHARE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_REDEM_SINGLE_MAX_SHARE like '@%';

   SELECT
       ''
      ,CAST('ORG_PROD_LOW_HOLD_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_PROD_LOW_HOLD_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('ORG_SINGLE_MIN_REDEM_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_SINGLE_MIN_REDEM_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('ORG_SINGLE_DAY_CUM_BUY_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_SINGLE_DAY_CUM_BUY_CEIL like '@%';

   SELECT
       ''
      ,CAST('ORG_SUBSCR_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_SUBSCR_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('ORG_SUBSCR_SUPP_START_POINT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_SUBSCR_SUPP_START_POINT_AMT like '@%';

   SELECT
       ''
      ,CAST('ORG_FIRST_SUBSCR_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_FIRST_SUBSCR_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('ORG_REDEM_SINGLE_MAX_SHARE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_REDEM_SINGLE_MAX_SHARE like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_NAME like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_HTML_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_HTML_NAME like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_LOC_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_LOC_PATH like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_OSS_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_OSS_PATH like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_UPLOAD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_UPLOAD_DT like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_UPLOAD_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_UPLOAD_TM like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_UPDATE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_UPDATE_DT like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_UPDATE_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_UPDATE_TM like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_NOTICE_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_NOTICE_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_DOC_UPLOAD_STATUS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_DOC_UPLOAD_STATUS_FLAG like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_NOTICE_MSG_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_NOTICE_MSG_ID like '@%';

   SELECT
       ''
      ,CAST('INFO_PBLS_CLS_DOC_CHNL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_PBLS_CLS_DOC_CHNL like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_HTML_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_HTML_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_LOC_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_LOC_PATH like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_OSS_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_OSS_PATH like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_UPLOAD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_UPLOAD_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_UPLOAD_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_UPLOAD_TM like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_UPDATE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_UPDATE_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_UPDATE_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_UPDATE_TM like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_NOTICE_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_NOTICE_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_DOC_UPLOAD_STATUS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_DOC_UPLOAD_STATUS_FLAG like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_NOTICE_MSG_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_NOTICE_MSG_ID like '@%';

   SELECT
       ''
      ,CAST('CONT_TEMPLET_DOC_CHNL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CSN_TRUST_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEMPLET_DOC_CHNL like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */