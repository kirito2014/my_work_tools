-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-排队叫号机排队明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_QCM_QUEUE_DTL_TF
--     表中文名：排队叫号机排队明细聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：QUEUE_DT, PROC_ORG_NO, QUEUE_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-27 00:00:00 吉云龙 创建
--         2024-09-12 00:00:00 陈艺丹 删除等待人数WAIT_PSN_CNT字段；
--         2024-09-12 00:00:00 陈艺丹 修改主表与柜台表关联条件，on QM_B_QUEUE.ORGID=QM_C_WININFO.ORGID AND QM_B_QUEUE.WINID=QM_C_WININFO.WINID AND QM_B_QUEUE.QMID=QM_C_WININFO.QMID；
--         2024-09-12 00:00:00 陈艺丹 修改主表与排队机设备表关联条件，on QM_B_QUEUE.QMID=QM_D_QMINFO.QMID AND QM_B_QUEUE.ORGID=QM_D_QMINFO.ORGID
--         2024-11-10 00:00:00 魏丹丹 更换主表



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(QUEUE_DT, PROC_ORG_NO, QUEUE_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(QUEUE_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PROC_ORG_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(QUEUE_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('QUEUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_DT like '@%';

   SELECT
       ''
      ,CAST('PROC_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PROC_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('QUEUE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('RANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RANK_NO like '@%';

   SELECT
       ''
      ,CAST('CALLNO_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CALLNO_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('IN_QUEUE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND IN_QUEUE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('OUT_QUEUE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OUT_QUEUE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('WAIT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND WAIT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('START_PROC_BIZ_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND START_PROC_BIZ_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('END_PROC_BIZ_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND END_PROC_BIZ_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('BIZ_PROC_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_PROC_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_STCT_DEG_ESTIM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_STCT_DEG_ESTIM_CD like '@%';

   SELECT
       ''
      ,CAST('CNTER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTER_NO like '@%';

   SELECT
       ''
      ,CAST('CNTER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTER_NAME like '@%';

   SELECT
       ''
      ,CAST('TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TELR_NO like '@%';

   SELECT
       ''
      ,CAST('GET_NO_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND GET_NO_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('GET_NO_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND GET_NO_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('REMOTE_GET_NO_RESV_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REMOTE_GET_NO_RESV_CD like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_MACH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_MACH_NO like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_MAC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_MAC_ADDR like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_ENABLED_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_ENABLED_FLAG like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_ONLINE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_ONLINE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_ONLINE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_ONLINE_FLAG like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_NAME like '@%';

   SELECT
       ''
      ,CAST('QUEUE_CALLNO_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND QUEUE_CALLNO_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('BIZ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_NAME like '@%';

   SELECT
       ''
      ,CAST('BIZ_NAME_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_NAME_ABB like '@%';

   SELECT
       ''
      ,CAST('BIZ_CNTER_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_CNTER_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CNTER_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTER_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('LVL_TWO_BUNDRY_EN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LVL_TWO_BUNDRY_EN_NAME like '@%';

   SELECT
       ''
      ,CAST('CNTER_WIN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTER_WIN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CNTER_WIN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTER_WIN_NAME like '@%';

   SELECT
       ''
      ,CAST('CNTER_WIN_EN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTER_WIN_EN_NAME like '@%';

   SELECT
       ''
      ,CAST('DSPLY_WIN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_QCM_QUEUE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DSPLY_WIN_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */