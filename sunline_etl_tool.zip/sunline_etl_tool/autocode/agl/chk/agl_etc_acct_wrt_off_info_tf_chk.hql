-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-ETC挂销账信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ETC_ACCT_WRT_OFF_INFO_TF
--     表中文名：ETC挂销账信息聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：ETC_DATA_ENCASE_DT, ETC_DATA_ENCASE_BATCH_NO, BATCH_SEQ_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ETC_DATA_ENCASE_DT, ETC_DATA_ENCASE_BATCH_NO, BATCH_SEQ_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ETC_DATA_ENCASE_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(ETC_DATA_ENCASE_BATCH_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BATCH_SEQ_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ETC_DATA_ENCASE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_DATA_ENCASE_DT like '@%';

   SELECT
       ''
      ,CAST('ETC_DATA_ENCASE_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_DATA_ENCASE_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('BATCH_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BATCH_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_COLOR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_COLOR_CD like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('HIGH_SPEED_IN_SITE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HIGH_SPEED_IN_SITE_DESC like '@%';

   SELECT
       ''
      ,CAST('HIGH_SPEED_OUT_SITE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HIGH_SPEED_OUT_SITE_DESC like '@%';

   SELECT
       ''
      ,CAST('PROV_IN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROV_IN_FLAG like '@%';

   SELECT
       ''
      ,CAST('ETC_TXN_SCENE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_TXN_SCENE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_AMT like '@%';

   SELECT
       ''
      ,CAST('ETC_ADV_MNY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_ADV_MNY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_DTL_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_DTL_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('ETC_TXN_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_TXN_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAYER_PAY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAYER_PAY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('GUAR_PAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GUAR_PAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('AL_WRTOFF_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_WRTOFF_AMT like '@%';

   SELECT
       ''
      ,CAST('UN_WRTOFF_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_WRTOFF_AMT like '@%';

   SELECT
       ''
      ,CAST('AL_WRTOFF_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_WRTOFF_CNT like '@%';

   SELECT
       ''
      ,CAST('FINAL_WRTOFF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_WRTOFF_DT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_DEDUCT_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_DEDUCT_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_WAIT_STL_INTER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_WAIT_STL_INTER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_WAIT_STL_INTER_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_WAIT_STL_INTER_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_ACCT_WRT_OFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_REM like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */