-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡介质信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_MED_INFO_TF
--     表中文名：信用卡介质信息聚合
--     创建日期：2023-12-13 00:00:00
--     主键字段：CARD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-13 00:00:00 游崔龙 新增
--         2024-01-18 00:00:00 游崔龙 对标
--         2024-09-08 00:00:00 游崔龙 新增字段数量5



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CARD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CARD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUST_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUST_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('SPREAD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPREAD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MAIN_SCD_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_SCD_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_CD like '@%';

   SELECT
       ''
      ,CAST('URG_SUBST_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_SUBST_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CARD_PAGE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_PAGE_DESC like '@%';

   SELECT
       ''
      ,CAST('CARD_BIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_BIN like '@%';

   SELECT
       ''
      ,CAST('CARD_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_NO_CHECK_BIT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO_CHECK_BIT like '@%';

   SELECT
       ''
      ,CAST('MASTER_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MASTER_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('DEBUT_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBUT_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('URG_SUBST_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_SUBST_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('UPGRD_CARD_ORIG_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UPGRD_CARD_ORIG_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_ORG_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ORG_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('IC_CARD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IC_CARD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RENEW_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RENEW_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CARD_CRDT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CRDT_LMT like '@%';

   SELECT
       ''
      ,CAST('SUPP_CARD_LMT_SET_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPP_CARD_LMT_SET_CD like '@%';

   SELECT
       ''
      ,CAST('SUPP_CARD_LMT_PCT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPP_CARD_LMT_PCT like '@%';

   SELECT
       ''
      ,CAST('SUPP_CARD_FIX_QUOTA' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPP_CARD_FIX_QUOTA like '@%';

   SELECT
       ''
      ,CAST('SUPP_CARD_FIX_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPP_CARD_FIX_LMT like '@%';

   SELECT
       ''
      ,CAST('SUPP_CARD_LMT_ADJ_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPP_CARD_LMT_ADJ_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('OD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OD_BAL like '@%';

   SELECT
       ''
      ,CAST('CARD_FEE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_FEE_CD like '@%';

   SELECT
       ''
      ,CAST('CHG_CARD_FEE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CHG_CARD_FEE_FLAG like '@%';

   SELECT
       ''
      ,CAST('CARD_NEED_PIN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NEED_PIN_FLAG like '@%';

   SELECT
       ''
      ,CAST('PROD_PIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_PIN_DT like '@%';

   SELECT
       ''
      ,CAST('XAM_PIN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND XAM_PIN_FLAG like '@%';

   SELECT
       ''
      ,CAST('LATST_TXN_USE_PIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LATST_TXN_USE_PIN_DT like '@%';

   SELECT
       ''
      ,CAST('ALLOW_USE_PIN_ERR_MOST_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_USE_PIN_ERR_MOST_TMS like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DAILY_PIN_ERR_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DAILY_PIN_ERR_TMS like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('QUICK_CARD_ISSUE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND QUICK_CARD_ISSUE_FLAG like '@%';

   SELECT
       ''
      ,CAST('URG_CARD_ISSUE_FEE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_CARD_ISSUE_FEE_FLAG like '@%';

   SELECT
       ''
      ,CAST('CARD_POST_ADDR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_POST_ADDR_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('CARD_VALID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_VALID like '@%';

   SELECT
       ''
      ,CAST('HEAVY_CARD_ISSUE_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HEAVY_CARD_ISSUE_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('HEAVY_CARD_ISSUE_KEEP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HEAVY_CARD_ISSUE_KEEP_CD like '@%';

   SELECT
       ''
      ,CAST('HEAVY_CARD_ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HEAVY_CARD_ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('CARD_ACT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ACT_DT like '@%';

   SELECT
       ''
      ,CAST('ENTITY_CARD_FIRST_ACT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ENTITY_CARD_FIRST_ACT_DT like '@%';

   SELECT
       ''
      ,CAST('CARD_REPLOS_CLOSE_CARD_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_REPLOS_CLOSE_CARD_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_REPLOS_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_REPLOS_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('REPLOS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_DT like '@%';

   SELECT
       ''
      ,CAST('REPLOS_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CLOSE_CARD_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CLOSE_CARD_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CLOSE_CARD_TELR_AFLT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CLOSE_CARD_TELR_AFLT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CLOSE_CARD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CLOSE_CARD_DT like '@%';

   SELECT
       ''
      ,CAST('PWD_INFO_RESET_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_INFO_RESET_FLAG like '@%';

   SELECT
       ''
      ,CAST('PWD_INFO_RESET_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_INFO_RESET_TMS like '@%';

   SELECT
       ''
      ,CAST('CARD_TXN_PWD_SET_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_TXN_PWD_SET_FLAG like '@%';

   SELECT
       ''
      ,CAST('PWD_INFO_RESET_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_INFO_RESET_DT like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DAILY_POSITIVE_TXN_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DAILY_POSITIVE_TXN_CNT like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DAILY_VIP_TXN_MAX_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DAILY_VIP_TXN_MAX_TMS like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DAILY_VIP_TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DAILY_VIP_TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('AUTH_RESET_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_RESET_FLAG like '@%';

   SELECT
       ''
      ,CAST('AUTH_RESET_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_RESET_AMT like '@%';

   SELECT
       ''
      ,CAST('AUTH_DEAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_DEAL_DT like '@%';

   SELECT
       ''
      ,CAST('LATST_AUTH_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LATST_AUTH_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('FIRST_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('LATST_ADV_BRW_CASH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LATST_ADV_BRW_CASH_DT like '@%';

   SELECT
       ''
      ,CAST('LATST_POSITIVE_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LATST_POSITIVE_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('CREATE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_DT like '@%';

   SELECT
       ''
      ,CAST('RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGN_CD like '@%';

   SELECT
       ''
      ,CAST('VALID_START_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VALID_START_DT like '@%';

   SELECT
       ''
      ,CAST('REPEAT_CARD_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPEAT_CARD_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_MED_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BELONG_ORG_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */