-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-市民卡圈存明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CITIZEN_CARD_LOAD_DTL_TA
--     表中文名：市民卡圈存明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_DT, PLAT_SER_NO, BIZ_UNIT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BIZ_UNIT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TRPRT_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRPRT_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CTZ_CARD_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CTZ_CARD_SER_NO like '@%';

   SELECT
       ''
      ,CAST('FORE_END_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FORE_END_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CORE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('UNDO_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNDO_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_CATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_CATE_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('CTZ_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CTZ_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_UCC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_UCC_FLAG like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('MASTER_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MASTER_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('NOW_CHARGE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NOW_CHARGE_FLAG like '@%';

   SELECT
       ''
      ,CAST('CASH_TRAN_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_TRAN_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('TAX_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TAX_FLAG like '@%';

   SELECT
       ''
      ,CAST('CHARGE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHARGE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('VOCH_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VOCH_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('VOCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VOCH_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('LATE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LATE_FEE like '@%';

   SELECT
       ''
      ,CAST('RECORD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECORD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LOGIN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LOGIN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHENK_ACCT_CLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHENK_ACCT_CLS_NO like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_MGMT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_MGMT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('SEND_HOST_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SEND_HOST_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('HECKER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HECKER_NO like '@%';

   SELECT
       ''
      ,CAST('PRE_AUTH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRE_AUTH_NO like '@%';

   SELECT
       ''
      ,CAST('OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DRAW_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DRAW_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('IDENTITY_CARD_REG_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND IDENTITY_CARD_REG_FLAG like '@%';

   SELECT
       ''
      ,CAST('LATST_EMPLYER_TEL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LATST_EMPLYER_TEL like '@%';

   SELECT
       ''
      ,CAST('CTZ_CARD_PAY_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CTZ_CARD_PAY_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('SEND_SUCC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SEND_SUCC_FLAG like '@%';

   SELECT
       ''
      ,CAST('HOST_CHECK_ENTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_CHECK_ENTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TRPRT_CHECK_ENTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRPRT_CHECK_ENTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_ACCTN_STAUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_ACCTN_STAUS_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_CHECK_ENTRY_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_CHECK_ENTRY_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_ILUS like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_RSPS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_RSPS_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_RESP_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_RESP_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_HAPP_TM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_HAPP_TM_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('HOST_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('TRPRT_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRPRT_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('BAT_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('APP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND APP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('PAY_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('OPER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPER_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TERM_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TERM_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_LOAD_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */