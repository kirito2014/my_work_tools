-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-大额支付对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA
--     表中文名：大额支付对账明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：TXN_DT, TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建
--         2024-09-18 00:00:00 陈艺丹 修改表名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_DT, TXN_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('ACCT_CONT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_CONT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('START_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NO ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NO  like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO  like '@%';

   SELECT
       ''
      ,CAST('TXN_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NUM like '@%';

   SELECT
       ''
      ,CAST('ORIG_START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('ORIG_START_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_START_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('ORIG_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('LARGE_AMT_PAY_ENTRY_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LARGE_AMT_PAY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LARGE_AMT_PAY_ENTRY_RESLT_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */