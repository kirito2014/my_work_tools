-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-超级网银对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：超级网银对账差错明细聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：SUPER_EBANK_CHECK_ENTRY_SYS_CD, TXN_BIZ_CATE_CD, PLAT_DT, PLAT_SER_NO, THIRD_PTY_CLEAR_DT
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：原海娜
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-06-25 00:00:00 原海娜 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(SUPER_EBANK_CHECK_ENTRY_SYS_CD, TXN_BIZ_CATE_CD, PLAT_DT, PLAT_SER_NO, THIRD_PTY_CLEAR_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(SUPER_EBANK_CHECK_ENTRY_SYS_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_BIZ_CATE_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(THIRD_PTY_CLEAR_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SUPER_EBANK_CHECK_ENTRY_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_EBANK_CHECK_ENTRY_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_SER_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PBC_BIZ_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_BIZ_SER_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CRDT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_CONT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_CONT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RGN_NO like '@%';

   SELECT
       ''
      ,CAST('INIT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INIT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SUPER_EBANK_HOST_LPAY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_EBANK_HOST_LPAY_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_CHECK_ENTRY_ERR_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_CHECK_ENTRY_ERR_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('SUPER_EBANK_TRPRT_LPAY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_EBANK_TRPRT_LPAY_CD like '@%';

   SELECT
       ''
      ,CAST('TPTY_CENT_ERR_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TPTY_CENT_ERR_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('SUPER_EBANK_ERR_DEAL_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_EBANK_ERR_DEAL_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DONE_ERR_DEAL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DONE_ERR_DEAL_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */