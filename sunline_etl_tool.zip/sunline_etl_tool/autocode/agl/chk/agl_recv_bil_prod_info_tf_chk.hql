-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单产品信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_PROD_INFO_TF
--     表中文名：收单产品信息聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：RECV_BIL_PROD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-27 00:00:00 吉云龙 创建
--         2024-08-13 00:00:00 陈艺丹 修改字段适用商户类型代码的取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(RECV_BIL_PROD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(RECV_BIL_PROD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('NEED_DVLP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEED_DVLP_FLAG like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_MDL_CATOGR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_MDL_CATOGR_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_DESC like '@%';

   SELECT
       ''
      ,CAST('CAN_CHOOSE_FEE_MODE_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAN_CHOOSE_FEE_MODE_SEQ like '@%';

   SELECT
       ''
      ,CAST('CAN_CHOOSE_PAY_MODE_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAN_CHOOSE_PAY_MODE_SEQ like '@%';

   SELECT
       ''
      ,CAST('BIG_WALLET_FIT_ORG_NO_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIG_WALLET_FIT_ORG_NO_SEQ like '@%';

   SELECT
       ''
      ,CAST('SMALL_WALLET_FIT_ORG_NO_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMALL_WALLET_FIT_ORG_NO_SEQ like '@%';

   SELECT
       ''
      ,CAST('PROD_FIT_ORG_NO_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FIT_ORG_NO_SEQ like '@%';

   SELECT
       ''
      ,CAST('FIT_MERCHT_ATTR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIT_MERCHT_ATTR_CD like '@%';

   SELECT
       ''
      ,CAST('FIT_MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIT_MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('FIT_MERCHT_MCC_CD_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIT_MERCHT_MCC_CD_SEQ like '@%';

   SELECT
       ''
      ,CAST('FIT_APP_OBJ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIT_APP_OBJ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SAM_APPID_MATN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SAM_APPID_MATN_FLAG like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_APPID_MATN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_APPID_MATN_FLAG like '@%';

   SELECT
       ''
      ,CAST('FIT_TERMN_TYPE_SEQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIT_TERMN_TYPE_SEQ like '@%';

   SELECT
       ''
      ,CAST('AUTO_TUNE_PAY_CTRL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTO_TUNE_PAY_CTRL_FLAG like '@%';

   SELECT
       ''
      ,CAST('PUT_ON_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PUT_ON_FLAG like '@%';

   SELECT
       ''
      ,CAST('PUT_ON_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PUT_ON_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('INPUT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('INPUT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */