-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-生活缴费交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_TXN_DTL_TA
--     表中文名：生活缴费交易明细聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORDER_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_SER_NO like '@%';

   SELECT
       ''
      ,CAST('FORE_END_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FORE_END_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_SER_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_SER_NO like '@%';

   SELECT
       ''
      ,CAST('UNDO_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNDO_SER_NO like '@%';

   SELECT
       ''
      ,CAST('LOC_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LOC_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_PAYOFF_BATCH_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_PAYOFF_BATCH_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('BATCH_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BATCH_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('ORDER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('AGCOL_FAIL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGCOL_FAIL_AMT like '@%';

   SELECT
       ''
      ,CAST('AGCOL_ACTL_TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGCOL_ACTL_TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('LATE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LATE_FEE like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_TXN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_TXN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_ACCTN_SEQ_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_ACCTN_SEQ_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_MGMT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_MGMT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHECKER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECKER_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_FEE_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_FEE_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_AMT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_AMT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAY_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_CATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_CATE_NO like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_CATE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_CATE_NAME like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_MDL_CATOGR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_MDL_CATOGR_NO like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_MDL_CATOGR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_MDL_CATOGR_NAME like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_BIZ_CATEGORY_CD_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_BIZ_CATEGORY_CD_1 like '@%';

   SELECT
       ''
      ,CAST('PROJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROJ_NO like '@%';

   SELECT
       ''
      ,CAST('PROJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROJ_NAME like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_BIZ_CATEGORY_CD_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_BIZ_CATEGORY_CD_2 like '@%';

   SELECT
       ''
      ,CAST('PAY_BIZ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BIZ_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_HOST_ACCTN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_HOST_ACCTN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_REC_ACCT_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_REC_ACCT_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_DESC like '@%';

   SELECT
       ''
      ,CAST('CHENK_ACCT_CLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHENK_ACCT_CLS_NO like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_HOST_CHECK_ENTRY_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_CHECK_ENTRY_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_CHECK_ENTRY_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('BAT_PAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_PAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('B_SRC_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('SRC_TAB_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SRC_TAB_NAME like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */