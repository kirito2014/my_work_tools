-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人保证金账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_MRG_ACCT_INFO_TF
--     表中文名：个人保证金账户信息聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ACCT_NO, CURR_CD, CASH_RMT_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CASH_RMT_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('MRG_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MRG_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('MRG_BIZ_CATE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MRG_BIZ_CATE_NAME like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('VOCH_REPLOS_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VOCH_REPLOS_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('BNCHMK_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BNCHMK_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('FLOT_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLOT_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('FLOT_INT_RATE_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLOT_INT_RATE_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('FLOT_INT_RATE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLOT_INT_RATE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INTACR_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ADJ_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADJ_INT like '@%';

   SELECT
       ''
      ,CAST('ADJ_INT_INT_TAX' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADJ_INT_INT_TAX like '@%';

   SELECT
       ''
      ,CAST('DRAW_INT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_INT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('FRZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('STOP_PAY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_PAY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('UNIVERSAL_WITHDR_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIVERSAL_WITHDR_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('UNIVERSAL_SAVING_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIVERSAL_SAVING_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_WITHDR_CASH_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_WITHDR_CASH_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DRAW_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DRAW_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DPSIT_IN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DPSIT_IN_FLAG like '@%';

   SELECT
       ''
      ,CAST('CURR_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_BAL like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('STOP_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('KEEP_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND KEEP_AMT like '@%';

   SELECT
       ''
      ,CAST('FRZ_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_AMT like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_YEAR_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_YEAR_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_MONTH_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_MONTH_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_TEN_DAYS_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_TEN_DAYS_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_QUAR_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_QUAR_ACCUM like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_DT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PERIOD like '@%';

   SELECT
       ''
      ,CAST('MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATU_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_DPSIT_DRAW_MNY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_DPSIT_DRAW_MNY_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('DEPT_OR_DEFLT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEPT_OR_DEFLT_TMS like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_MRG_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */