-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-移动展业背夹设备信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_YDZY_BJ_EQUIP_INFO_TF
--     表中文名：移动展业背夹设备信息聚合
--     创建日期：2024-05-20 00:00:00
--     主键字段：EQUIP_PIN_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：可用于统计移动展业设备数量
--     更新记录：
--         2024-05-20 00:00:00 王穆军 NEW
--         2024-09-05 00:00:00 王穆军 调试上线



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(EQUIP_PIN_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(EQUIP_PIN_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('EQUIP_PIN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_PIN_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('SYS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SYS_NO like '@%';

   SELECT
       ''
      ,CAST('MANUFAC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MANUFAC_NAME like '@%';

   SELECT
       ''
      ,CAST('FGPRT_INST_MANUFAC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FGPRT_INST_MANUFAC_NAME like '@%';

   SELECT
       ''
      ,CAST('BT_MAC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BT_MAC_ADDR like '@%';

   SELECT
       ''
      ,CAST('BT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BT_NAME like '@%';

   SELECT
       ''
      ,CAST('BT_JOIN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BT_JOIN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('PWD_KEYBRD_REG_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_KEYBRD_REG_FLAG like '@%';

   SELECT
       ''
      ,CAST('KEY_POUR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND KEY_POUR_FLAG like '@%';

   SELECT
       ''
      ,CAST('REG_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_FLAG like '@%';

   SELECT
       ''
      ,CAST('MAIN_KEY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_KEY_DESC like '@%';

   SELECT
       ''
      ,CAST('EQUIP_INVTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_INVTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MGMT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MGMT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MGMT_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MGMT_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BIND_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BIND_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BIND_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BIND_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BIND_VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BIND_VIRTUAL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_TELR_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_TELR_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_BJ_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */