-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-综合代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SYN_AGEN_PAY_TXN_DTL_TA
--     表中文名：综合代发交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：PLAT_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-18 00:00:00 魏丹丹 新增
--         2024-09-09 00:00:00 魏丹丹 修改中间业务表名 ,第二组主表少关联条件字段,0920设计通知不需要第二组



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO, BIZ_UNIT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_BATCH_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BAT_AGEN_PAY_SEQ_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BIZ_UNIT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('BAT_AGEN_PAY_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_AGEN_PAY_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('FRONT_BAT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FRONT_BAT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_CORP_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_CORP_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('SYN_PAYOFF_OPEN_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYN_PAYOFF_OPEN_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SYN_PAYOFF_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYN_PAYOFF_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('SYN_PAYOFF_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYN_PAYOFF_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_CORP_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_CORP_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SYN_PAYOFF_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYN_PAYOFF_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ISSUG_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ISSUG_AMT like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_TOTAL_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_TOTAL_CNT like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_SUCC_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_SUCC_CNT like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_FAIL_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_FAIL_CNT like '@%';

   SELECT
       ''
      ,CAST('HOST_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SYN_AGEN_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */