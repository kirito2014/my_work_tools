-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-乘车码交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MULTY_CAR_CD_TXN_DTL_TA
--     表中文名：乘车码交易明细聚合
--     创建日期：2024-08-01 00:00:00
--     主键字段：TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-01 00:00:00 陈艺丹 创建
--         2024-09-14 00:00:00 陈艺丹 1.UNION1和UNION2主源表与卡合约表增加关联条件
--         2024-09-20 00:00:00 陈艺丹 新增字段:用户编号,用户归属机构编号,优惠金额
--         2024-09-20 00:00:00 陈艺丹 UNION1和UNION2字段原始票价金额、执行票价金额修改取数逻辑；UNION3字段实际支付金额、应收金额修改取数逻辑\
--         2024-09-20 00:00:00 陈艺丹 UNION1和UNION2字段“交通类型代码”填写固定值
--         2024-09-29 00:00:00 陈艺丹 修改正常交易流水表，公交订单记录表，地铁订单记录表和营销活动核销记录表为增量表；
--         2024-09-29 00:00:00 陈艺丹 修改实际支付金额,应收金额PAYABLE_PRICE/100为PAYABLE_PRICE，RECEIVABLE_PRICE/100为RECEIVABLE_PRICE；



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_TXN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_TXN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('OPENID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPENID like '@%';

   SELECT
       ''
      ,CAST('PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('MCC_MERCHT_ORDER_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MCC_MERCHT_ORDER_SER_NO like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('USER_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SCENE_QR_CD_PLAT_USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SCENE_QR_CD_PLAT_USER_NO like '@%';

   SELECT
       ''
      ,CAST('APPLY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND APPLY_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TRFC_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRFC_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_ACCESS_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_ACCESS_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_TXN_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_TXN_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_MODE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_MODE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MKUP_PAY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MKUP_PAY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_PAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_PAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('ORDER_EFFECT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_EFFECT_FLAG like '@%';

   SELECT
       ''
      ,CAST('ORDER_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_EFFECT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_EFFECT_FLAG like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_RESLT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_RESLT_DESC like '@%';

   SELECT
       ''
      ,CAST('PAY_RESLT_EXPAND_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_RESLT_EXPAND_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('INTLG_PAY_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTLG_PAY_SER_NO like '@%';

   SELECT
       ''
      ,CAST('INTLG_PAY_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTLG_PAY_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('BUCKLE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BUCKLE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('INTLG_PAY_ACPTD_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTLG_PAY_ACPTD_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_APP_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_APP_ID like '@%';

   SELECT
       ''
      ,CAST('UNPY_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_SYS_TXN_ORDER_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_SYS_TXN_ORDER_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TSYST_TXN_NTC_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TSYST_TXN_NTC_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_BIL_PRC_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_BIL_PRC_AMT like '@%';

   SELECT
       ''
      ,CAST('EXC_BIL_PRC_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXC_BIL_PRC_AMT like '@%';

   SELECT
       ''
      ,CAST('ACTL_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACTL_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('RECVBL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECVBL_AMT like '@%';

   SELECT
       ''
      ,CAST('PREFR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PREFR_AMT like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_PREFR_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_PREFR_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACT_WRTOFF_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACT_WRTOFF_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_BIL_GET_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_BIL_GET_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('RELA_CUST_BIL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RELA_CUST_BIL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACT_WRTOFF_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACT_WRTOFF_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ACT_WRTOFF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACT_WRTOFF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHT_PREFR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_PREFR_AMT like '@%';

   SELECT
       ''
      ,CAST('BANK_PTY_PREFR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_PTY_PREFR_AMT like '@%';

   SELECT
       ''
      ,CAST('PREFR_ACT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PREFR_ACT_NO like '@%';

   SELECT
       ''
      ,CAST('PREFR_ACT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PREFR_ACT_NAME like '@%';

   SELECT
       ''
      ,CAST('PREFR_MKTING_CTRB_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PREFR_MKTING_CTRB_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PMKT_CTRB_ORG_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PMKT_CTRB_ORG_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('JOURNEY_BIL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND JOURNEY_BIL_NO like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_FEE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_FEE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('GET_ON_IN_STATION_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_ON_IN_STATION_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('GET_OFF_OUT_STATION_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_OFF_OUT_STATION_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('GET_ON_IN_STATION_SITE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_ON_IN_STATION_SITE_DESC like '@%';

   SELECT
       ''
      ,CAST('GET_OFF_OUT_STATION_SITE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_OFF_OUT_STATION_SITE_DESC like '@%';

   SELECT
       ''
      ,CAST('GET_ON_IN_STATION_TERMN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_ON_IN_STATION_TERMN_NO like '@%';

   SELECT
       ''
      ,CAST('GET_OFF_OUT_STATION_TERMN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_OFF_OUT_STATION_TERMN_NO like '@%';

   SELECT
       ''
      ,CAST('GET_ON_IN_STATION_LINE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_ON_IN_STATION_LINE_DESC like '@%';

   SELECT
       ''
      ,CAST('GET_OFF_OUT_STATION_LINE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GET_OFF_OUT_STATION_LINE_DESC like '@%';

   SELECT
       ''
      ,CAST('LINE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LINE_NAME like '@%';

   SELECT
       ''
      ,CAST('POS_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND POS_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('POS_LINE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND POS_LINE_NO like '@%';

   SELECT
       ''
      ,CAST('POS_SITE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND POS_SITE_NO like '@%';

   SELECT
       ''
      ,CAST('VEHIC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_NO like '@%';

   SELECT
       ''
      ,CAST('6_BIT_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND 6_BIT_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('CITY_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CITY_NAME like '@%';

   SELECT
       ''
      ,CAST('DRIVER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DRIVER_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('PROD_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROD_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROD_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_SCENE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_SCENE_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */