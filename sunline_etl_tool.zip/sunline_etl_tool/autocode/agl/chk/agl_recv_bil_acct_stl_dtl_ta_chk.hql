-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-收单账户结算明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_ACCT_STL_DTL_TA
--     表中文名：收单账户结算明细聚合
--     创建日期：2024-01-03 00:00:00
--     主键字段：STL_SER_NO, MERCHT_ORDER_NO, TXN_SER_NO, RECV_BIL_SYS_TXN_TM_STAMP, TXN_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：缺表ODS_SPS_SP_SHARED_COMPANY_TF
--     更新记录：
--         2024-01-03 00:00:00 魏丹丹 新增
--         2024-04-23 00:00:00 魏丹丹 修改主键以及取数规则，缺少第二组，后面价值最后
--         2024-08-22 00:00:00 魏丹丹 修改主键以及取数规则，已加第二组，第二组缺表，逻辑未调整
--         2024-09-22 00:00:00 魏丹丹 调整日期函数，加表ODS_SPS_SP_PAY_SIMPLE_TF ,2024/09/26增加 银联应收手续费 取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(STL_SER_NO, MERCHT_ORDER_NO, TXN_SER_NO, RECV_BIL_SYS_TXN_TM_STAMP, TXN_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(STL_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_ORDER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(RECV_BIL_SYS_TXN_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('STL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORDER_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_AMT like '@%';

   SELECT
       ''
      ,CAST('SHOULD_STL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SHOULD_STL_AMT like '@%';

   SELECT
       ''
      ,CAST('STL_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('STL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_AMT like '@%';

   SELECT
       ''
      ,CAST('STL_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('STL_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('STL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_CAP_STL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_CAP_STL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ANTCPTD_STL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ANTCPTD_STL_DT like '@%';

   SELECT
       ''
      ,CAST('STL_CMPLT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_CMPLT_DT like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_PTY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_PTY_NO like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_PTY_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_PTY_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_PTY_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_PTY_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_ABB like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SAM_BLG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SAM_BLG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_APP_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_APP_ID like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_ID like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('STL_CARD_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_CARD_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('DEBIT_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('DEBIT_OPBANK_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_OPBANK_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CRDT_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CRDT_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('CRDT_OPBANK_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CRDT_OPBANK_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CRDT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CRDT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PASS_RETURN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PASS_RETURN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CNAPS_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNAPS_SER_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_INTER_TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_INTER_TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_PASS_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_PASS_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_SYS_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_SYS_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CNAPS_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNAPS_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_MAIN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_MAIN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_SUB_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_SUB_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('WHITE_LIST_ADV_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WHITE_LIST_ADV_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUER_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUER_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('UNPY_RECVBL_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_RECVBL_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_RATE like '@%';

   SELECT
       ''
      ,CAST('RECVBL_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECVBL_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('ACTL_RECV_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACTL_RECV_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('FEE_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FEE_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('USER_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('USER_ACTL_FALLBACK_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_ACTL_FALLBACK_AMT like '@%';

   SELECT
       ''
      ,CAST('CORE_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ACCT_STL_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */