-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人活期存款账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CURR_DPSIT_ACCT_INFO_TF
--     表中文名：个人活期存款账户信息聚合
--     创建日期：2023-02-15 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：存储个人活期存款账户聚合
--     更新记录：
--         2024-04-09 00:00:00 沈健 加上DEL_F=0,流水补充文件表注释
--         2024-09-24 00:00:00 王穆军 新增多个字段，调整逻辑，修改映射
--         2024-10-21 00:00:00 王穆军 变更设计文档0927截止：新增字段：客户国籍代码，客户职业代码，两组用户ID调整逻辑
--         2024-11-04 00:00:00 魏丹丹 删除字段：客户国籍代码，客户职业代码，昨日余额调整
--         2024-11-19 00:00:00 魏丹丹 修改第一组记录状态代码取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ACCT_NO, CURR_CD, CASH_RMT_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CASH_RMT_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('INDV_CORP_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_CORP_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('MAIN_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('MAIN_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('UNIVERSAL_WITHDR_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIVERSAL_WITHDR_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('UNIVERSAL_SAVING_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIVERSAL_SAVING_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('MRGACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MRGACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('MRG_BIZ_CATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MRG_BIZ_CATE like '@%';

   SELECT
       ''
      ,CAST('MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('HANG_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HANG_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('MASTER_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MASTER_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('DPSTRCP_CONVT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSTRCP_CONVT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('EACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACCT_NO like '@%';

   SELECT
       ''
      ,CAST('EACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ELEC_LIACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_LIACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('ELEC_LIACCT_CLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_LIACCT_CLS_CD like '@%';

   SELECT
       ''
      ,CAST('ELEC_LIACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_LIACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('DPSIT_COMB_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_COMB_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_COMB_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_COMB_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('STOP_PAY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_PAY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('REPLOS_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('FRZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_WITHDR_CASH_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_WITHDR_CASH_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DRAW_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DRAW_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DPSIT_IN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DPSIT_IN_FLAG like '@%';

   SELECT
       ''
      ,CAST('DRAW_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_PWD_ENABLED_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_PWD_ENABLED_FLAG like '@%';

   SELECT
       ''
      ,CAST('PWD_ENCRYPT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_ENCRYPT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('TEL_BANK_PWD_ENCRYPT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEL_BANK_PWD_ENCRYPT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('CURR_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_BAL like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL like '@%';

   SELECT
       ''
      ,CAST('KEEP_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND KEEP_AMT like '@%';

   SELECT
       ''
      ,CAST('FRZ_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_AMT like '@%';

   SELECT
       ''
      ,CAST('STOP_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('AUTH_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_AMT like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_MONTH_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_MONTH_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_QUAR_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_QUAR_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_YEAR_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_YEAR_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_MONTH_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_MONTH_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_QUAR_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_QUAR_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_YEAR_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_YEAR_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('CHARGE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CHARGE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('BNCHMK_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BNCHMK_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('FLOT_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLOT_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('FLOT_INT_RATE_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLOT_INT_RATE_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('FLOT_INT_RATE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLOT_INT_RATE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INTACR_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('SETMENT_FREQ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETMENT_FREQ like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('DRAW_INT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_INT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACTL_INT_AMT_YEAR_CUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_INT_AMT_YEAR_CUM like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_TM like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_TELR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_TELR like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('AGENT_CONT_MODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_CONT_MODE like '@%';

   SELECT
       ''
      ,CAST('DRAW_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DRAW_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('PAYOFF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAYOFF_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_CHNL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_CHNL like '@%';

   SELECT
       ''
      ,CAST('WX_BIND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WX_BIND_FLAG like '@%';

   SELECT
       ''
      ,CAST('RECV_INTERCONT_OPEN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_INTERCONT_OPEN_FLAG like '@%';

   SELECT
       ''
      ,CAST('STATUS_VERI_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STATUS_VERI_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('B_SRC_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('CUST_FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */