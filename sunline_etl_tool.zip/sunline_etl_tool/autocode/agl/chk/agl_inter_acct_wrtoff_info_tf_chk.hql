-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-内部账户销账信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INTER_ACCT_WRTOFF_INFO_TF
--     表中文名：内部账户销账信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：ON_ACCT_SER_NO, WRTOFF_ACCT_DT, WRTOFF_SER_NO, REC_STATUS_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-16 00:00:00 魏丹丹 新增
--         2024-09-06 00:00:00 魏丹丹 更新



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ON_ACCT_SER_NO, WRTOFF_ACCT_DT, WRTOFF_SER_NO, REC_STATUS_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ON_ACCT_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(WRTOFF_ACCT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(WRTOFF_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(REC_STATUS_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ON_ACCT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_SER_NO like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('INTER_ACCT_ON_ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_ON_ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('INTER_ACCT_WRTOFF_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_WRTOFF_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TELR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TELR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_DESC like '@%';

   SELECT
       ''
      ,CAST('VOCH_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VOCH_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_VOCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_VOCH_NO like '@%';

   SELECT
       ''
      ,CAST('VOUCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VOUCH_NO like '@%';

   SELECT
       ''
      ,CAST('DWELL_SPC_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DWELL_SPC_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_AMT like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_CRDT_STAT_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_CRDT_STAT_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('ON_ACCT_AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_ACCT_AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_CRDT_STAT_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_CRDT_STAT_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_WRTOFF_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */