-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-自助机具设备信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SELF_SERV_MACH_EQUIP_INFO_TF
--     表中文名：自助机具设备信息聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：EQUIP_NO, SRC_SYS_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-02-26 00:00:00 魏丹丹 新增
--         2024-09-04 00:00:00 魏丹丹 新增字段
--         2024-09-30 00:00:00 魏丹丹 缺字段补入



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(EQUIP_NO, SRC_SYS_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(EQUIP_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SRC_SYS_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_PUT_IN_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_PUT_IN_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BRAND_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BRAND_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BRAND_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BRAND_NAME like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MODEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MODEL_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MODEL_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MODEL_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_EQUIP_MAC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_EQUIP_MAC like '@%';

   SELECT
       ''
      ,CAST('TXN_EQUIP_IP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_EQUIP_IP like '@%';

   SELECT
       ''
      ,CAST('EQUIP_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('OUT_BANK_IN_BANK_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OUT_BANK_IN_BANK_CD like '@%';

   SELECT
       ''
      ,CAST('OPER_PAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_PAT_CD like '@%';

   SELECT
       ''
      ,CAST('OPER_MGMT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_MGMT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('REG_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_FLAG like '@%';

   SELECT
       ''
      ,CAST('KEY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND KEY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ATMC_SOFT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ATMC_SOFT_NO like '@%';

   SELECT
       ''
      ,CAST('WEB_MODEL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WEB_MODEL_CD like '@%';

   SELECT
       ''
      ,CAST('RUN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RUN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FRONT_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRONT_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_ATTACH_CNTER_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_ATTACH_CNTER_FLAG like '@%';

   SELECT
       ''
      ,CAST('DPSTRCP_ATTACH_CNTER_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSTRCP_ATTACH_CNTER_FLAG like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_ATTACH_CNTER_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_ATTACH_CNTER_FLAG like '@%';

   SELECT
       ''
      ,CAST('SMS_NOTICE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMS_NOTICE_FLAG like '@%';

   SELECT
       ''
      ,CAST('GOOD_HVST_HOP_EQUIP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GOOD_HVST_HOP_EQUIP_FLAG like '@%';

   SELECT
       ''
      ,CAST('CEP_TRANS_SIZE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CEP_TRANS_SIZE_DESC like '@%';

   SELECT
       ''
      ,CAST('COMMUNIC_TRANS_COMP_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMMUNIC_TRANS_COMP_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_SUPR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_SUPR_NO like '@%';

   SELECT
       ''
      ,CAST('SUPR_CONT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPR_CONT_NAME like '@%';

   SELECT
       ''
      ,CAST('SUPR_CONT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPR_CONT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('CASH_BOX_ALARM_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_BOX_ALARM_AMT like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MATN_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MATN_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MANUFAC_LEAVE_FACTORY_SN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MANUFAC_LEAVE_FACTORY_SN like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BUY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BUY_DT like '@%';

   SELECT
       ''
      ,CAST('EQUIP_INSTALL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_INSTALL_DT like '@%';

   SELECT
       ''
      ,CAST('EQUIP_ENABLED_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_ENABLED_DT like '@%';

   SELECT
       ''
      ,CAST('EQUIP_STOP_USE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_STOP_USE_DT like '@%';

   SELECT
       ''
      ,CAST('DAILY_BOOT_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DAILY_BOOT_TM like '@%';

   SELECT
       ''
      ,CAST('DAILY_SHUTDOWN_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DAILY_SHUTDOWN_TM like '@%';

   SELECT
       ''
      ,CAST('WARRT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WARRT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('EQUIP_INSP_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_INSP_PERIOD like '@%';

   SELECT
       ''
      ,CAST('INSTALL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_LOCAL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_LOCAL_ADDR like '@%';

   SELECT
       ''
      ,CAST('LOCAL_PROV_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOCAL_PROV_CD like '@%';

   SELECT
       ''
      ,CAST('CITY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CITY_CD like '@%';

   SELECT
       ''
      ,CAST('AERA_COUNTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AERA_COUNTY_CD like '@%';

   SELECT
       ''
      ,CAST('LOCAL_STREET_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOCAL_STREET_CD like '@%';

   SELECT
       ''
      ,CAST('LOCAL_COMM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOCAL_COMM_CD like '@%';

   SELECT
       ''
      ,CAST('DTL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DTL_ADDR like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_EQUIP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */