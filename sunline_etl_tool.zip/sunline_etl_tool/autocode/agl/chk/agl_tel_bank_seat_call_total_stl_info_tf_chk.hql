-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-电话银行坐席通话总结信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF
--     表中文名：电话银行坐席通话总结信息聚合
--     创建日期：2024-03-27 00:00:00
--     主键字段：BRIEF_SUM_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-27 00:00:00 吉云龙 创建
--         2024-08-13 00:00:00 陈艺丹 修改来源字段英文名,修改表名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(BRIEF_SUM_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(BRIEF_SUM_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('BRIEF_SUM_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BRIEF_SUM_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SOUND_REC_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOUND_REC_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_LABEL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_LABEL_CD like '@%';

   SELECT
       ''
      ,CAST('TEL_SEAT_SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEL_SEAT_SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CALL_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CALL_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('SEAT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEAT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SEAT_LOGIN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEAT_LOGIN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SEAT_EXT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEAT_EXT_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_START_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_START_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SERV_END_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_END_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SERV_CALL_DURAN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CALL_DURAN like '@%';

   SELECT
       ''
      ,CAST('SERV_RESLT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_RESLT_DESC like '@%';

   SELECT
       ''
      ,CAST('SERV_CONT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CONT_DESC like '@%';

   SELECT
       ''
      ,CAST('SERV_CONT_SUPP_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CONT_SUPP_DESC like '@%';

   SELECT
       ''
      ,CAST('BRIEF_SUM_SUBMIT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TEL_BANK_SEAT_CALL_TOTAL_STL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BRIEF_SUM_SUBMIT_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */