-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-自助机具故障信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SELF_SERV_MACH_FAULT_INFO_TF
--     表中文名：自助机具故障信息聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：FAULT_CASE_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(FAULT_CASE_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(FAULT_CASE_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('FAULT_CASE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAULT_CASE_NO like '@%';

   SELECT
       ''
      ,CAST('DEV_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEV_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MANUFAC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MANUFAC_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MODULE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MODULE_CD like '@%';

   SELECT
       ''
      ,CAST('FAULT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAULT_CD like '@%';

   SELECT
       ''
      ,CAST('FAULT_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAULT_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('CASE_CREATE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_CREATE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('CASE_CREATE_PSN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_CREATE_PSN_NAME like '@%';

   SELECT
       ''
      ,CAST('CASE_CURR_LVL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_CURR_LVL like '@%';

   SELECT
       ''
      ,CAST('CASE_MAX_LVL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_MAX_LVL like '@%';

   SELECT
       ''
      ,CAST('CASE_UPGRD_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_UPGRD_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('CASE_MAIN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_MAIN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CASE_CURR_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_CURR_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MANUFAC_FAULT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MANUFAC_FAULT_CD like '@%';

   SELECT
       ''
      ,CAST('FAULT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAULT_DESC like '@%';

   SELECT
       ''
      ,CAST('SLTN_PLAN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SLTN_PLAN_DESC like '@%';

   SELECT
       ''
      ,CAST('CASE_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CASE_NOTICE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_NOTICE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('REPAIR_PRES_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPAIR_PRES_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CASE_CLOSE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_CLOSE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CASE_HANG_UP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_HANG_UP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CASE_UPGRD_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_UPGRD_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('EXPECT_REPLY_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPECT_REPLY_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('EXPECT_PRES_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPECT_PRES_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('EXPECT_CLOSE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPECT_CLOSE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('EXPECT_HANG_UP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPECT_HANG_UP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ACTL_REPLY_DURAN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_REPLY_DURAN like '@%';

   SELECT
       ''
      ,CAST('ACTL_PRES_DURAN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_PRES_DURAN like '@%';

   SELECT
       ''
      ,CAST('ACTL_CLOSE_DURAN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_FAULT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_CLOSE_DURAN like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */