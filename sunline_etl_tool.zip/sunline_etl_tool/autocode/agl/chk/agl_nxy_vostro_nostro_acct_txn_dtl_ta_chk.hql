-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-农信银来往账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA
--     表中文名：农信银来往账交易明细聚合
--     创建日期：2024-08-30 00:00:00
--     主键字段：PLAT_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：None
--     保留周期：None
--     描述信息：包含银行汇兑业务、银行汇票、业务查询和查复、现金汇款、现金存取款、实时跨行转账等相关信息
--     更新记录：
--         2024-08-30 00:00:00 王穆军 new
--         2024-09-13 00:00:00 王穆军 字段重复



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_ACCTN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_ACCTN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_REQE_BIZ_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_REQE_BIZ_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_SYS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_SYS_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_RECV_SYS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_RECV_SYS_NO like '@%';

   SELECT
       ''
      ,CAST('START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('TELEG_ROW_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TELEG_ROW_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_MSG_ROW_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_MSG_ROW_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('END_TO_END_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND END_TO_END_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('INTER_MSG_NO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTER_MSG_NO_DESC like '@%';

   SELECT
       ''
      ,CAST('MSG_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_RECV_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_RECV_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_MSG_PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MSG_PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_CONT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_CONT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_CORE_PLAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_CORE_PLAT_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_FUND_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_FUND_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('RECORD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECORD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('HANDLE_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HANDLE_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('NXY_BIZ_DEAL_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_BIZ_DEAL_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('NXY_BIZ_SUB_CLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_BIZ_SUB_CLS_CD like '@%';

   SELECT
       ''
      ,CAST('NXY_BIZ_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_BIZ_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('NXY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('NXY_BIZ_SUB_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_BIZ_SUB_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NUM like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('RE_EXCH_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RE_EXCH_AMT like '@%';

   SELECT
       ''
      ,CAST('CLEAR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_AMT like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CLEAR_PATH_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_PATH_CD like '@%';

   SELECT
       ''
      ,CAST('NXY_PAY_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_PAY_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('FIRST_CRDT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CRDT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('FIRST_DEBIT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FIRST_DEBIT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('RMT_AGING_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RMT_AGING_CD like '@%';

   SELECT
       ''
      ,CAST('DRFT_AUTHC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DRFT_AUTHC like '@%';

   SELECT
       ''
      ,CAST('PASS_END_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PASS_END_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('EXT_REQE_MSG_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_REQE_MSG_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('EXT_RESP_MSG_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_RESP_MSG_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('EXT_NXY_BIZ_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_NXY_BIZ_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('EXT_NXY_BIZ_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_NXY_BIZ_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('EXT_START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('EXT_RECV_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_RECV_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('EXT_TELEG_ROW_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_TELEG_ROW_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('EXT_RECV_MSG_ROW_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_RECV_MSG_ROW_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('INPUT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHECKER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECKER_NO like '@%';

   SELECT
       ''
      ,CAST('CFM_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CFM_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('APPRV_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND APPRV_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHENK_ACCT_CLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHENK_ACCT_CLS_NO like '@%';

   SELECT
       ''
      ,CAST('RSPS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RSPS_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_DESC like '@%';

   SELECT
       ''
      ,CAST('PASS_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PASS_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('HOST_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('HOST_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('COMMS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NXY_VOSTRO_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMMS_DT like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */