-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人数字货币钱包绑卡协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF
--     表中文名：个人数字货币钱包绑卡协议信息聚合
--     创建日期：2024-04-02 00:00:00
--     主键字段：CONT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-02 00:00:00 吉云龙 创建
--         2024-08-27 00:00:00 陈艺丹 修改排序条件：按last_etl_acg_dt倒序改为按修改时间创建时间倒序；
--         2024-09-02 00:00:00 陈艺丹 修改字段名：签约渠道代码改为数币签约运营机构类型代码，签约类型代码改为签约标志；新增字段运营机构编号，签约卡类型代码；
--         2024-09-12 00:00:00 陈艺丹 修改字段名：系统编码代码改为系统代码；签约标志改为默认值1；新增字段数币合约类型名称；



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CONT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CONT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTY_CONT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTY_CONT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTY_CONT_TYPE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTY_CONT_TYPE_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_BNKOUTLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_BNKOUTLS_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_TCA_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_TCA_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_CANCEL_CONT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_CANCEL_CONT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_USER_ID like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('OPER_ORG_TIE_CARD_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_ORG_TIE_CARD_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_SOO_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_SOO_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PASS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PASS_NO like '@%';

   SELECT
       ''
      ,CAST('SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SYS_CD like '@%';

   SELECT
       ''
      ,CAST('ANALY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ANALY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('MKTING_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CONT_EFFECT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_EFFECT_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TIE_CARD_AGT_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TIE_CARD_AGT_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_CANC_ACCT_XAM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_CANC_ACCT_XAM_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('BANK_RESV_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BANK_RESV_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('DBO_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DBO_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_FLAG like '@%';

   SELECT
       ''
      ,CAST('WALLET_ESTB_AFLT_FIN_ORG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ESTB_AFLT_FIN_ORG_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CARD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CARD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('OPBANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPBANK_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_CARD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_CARD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_SINGLE_TXN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_SINGLE_TXN_LMT like '@%';

   SELECT
       ''
      ,CAST('WALLET_DAILY_ACCUM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_DAILY_ACCUM_LMT like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_TIE_CARD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */