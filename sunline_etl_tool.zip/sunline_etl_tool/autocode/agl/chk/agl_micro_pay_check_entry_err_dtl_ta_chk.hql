-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-小额支付对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：小额支付对账差错明细聚合
--     创建日期：2024-08-08 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO, CHECK_ENTRY_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建
--         2024-09-18 00:00:00 陈艺丹 修改表名



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_DT, PLAT_SER_NO, CHECK_ENTRY_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CHECK_ENTRY_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_DT like '@%';

   SELECT
       ''
      ,CAST('MSG_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('COL_PAY_MNY_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COL_PAY_MNY_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_CONT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_CONT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_PAY_BIZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_PAY_BIZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('INIT_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INIT_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('MSG_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_DIR_PRTCPT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_DIR_PRTCPT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TOTAL_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TOTAL_CNT like '@%';

   SELECT
       ''
      ,CAST('TXN_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('NTTG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NTTG_DT like '@%';

   SELECT
       ''
      ,CAST('NTTG_SITE_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NTTG_SITE_CNT like '@%';

   SELECT
       ''
      ,CAST('MICRO_HOST_CHECK_ENTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MICRO_HOST_CHECK_ENTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DONE_ERR_DEAL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DONE_ERR_DEAL_FLAG like '@%';

   SELECT
       ''
      ,CAST('ERR_DEAL_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MICRO_PAY_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_DEAL_INFO_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */