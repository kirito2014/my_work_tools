-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-乘车码协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MULTY_CAR_CD_AGT_INFO_TF
--     表中文名：乘车码协议信息聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：CONT_NO, VIRTUAL_CARD_CARD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：原海娜
--     时间粒度：日
--     保留周期：None
--     描述信息：场景二维码平台所有状态的乘车码合约数据（包括自建场景和银联场景）
--     更新记录：
--         2024-06-25 00:00:00 原海娜 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CONT_NO, VIRTUAL_CARD_CARD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CONT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(VIRTUAL_CARD_CARD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('SCENE_QR_CD_PLAT_USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCENE_QR_CD_PLAT_USER_NO like '@%';

   SELECT
       ''
      ,CAST('UNPY_TRFC_TRAVEL_PLAT_USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_TRFC_TRAVEL_PLAT_USER_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ID like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('USER_BELONG_LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_BELONG_LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('USER_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('USER_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_EACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_EACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ACCT_BELONG_LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BELONG_LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_CONT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_CONT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_BLKLIST_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_BLKLIST_FLAG like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_ARA_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_ARA_FLAG like '@%';

   SELECT
       ''
      ,CAST('VCARD_APP_DEREGIS_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VCARD_APP_DEREGIS_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_FRZ_END_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_FRZ_END_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('VCARD_RTN_CARD_SUCC_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VCARD_RTN_CARD_SUCC_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_ROUTE_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_ROUTE_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_ACCESS_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_ACCESS_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('APPLY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPLY_NO like '@%';

   SELECT
       ''
      ,CAST('APP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CONT_FINAL_CHG_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_FINAL_CHG_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CONT_INFO_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_INFO_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CONT_INFO_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_INFO_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('VCARD_INFO_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VCARD_INFO_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('VCARD_INFO_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VCARD_INFO_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('USER_INFO_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_INFO_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('USER_INFO_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_INFO_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MULTY_CAR_CD_SCENE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MULTY_CAR_CD_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MULTY_CAR_CD_SCENE_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */