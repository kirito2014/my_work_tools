-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-移动展业交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_YDZY_TXN_DTL_TA
--     表中文名：移动展业交易明细聚合
--     创建日期：2024-06-11 00:00:00
--     主键字段：TXN_SER_NO, EVENT_ID
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：选取移动展业系统交易流水表的全部信息
--     更新记录：
--         2024-06-11 00:00:00 王穆军 new
--         2024-09-03 00:00:00 王穆军 修改字段
--         2024-10-08 00:00:00 王穆军 新增主键字段



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO, EVENT_ID) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(EVENT_ID AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('EVENT_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EVENT_ID like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM like '@%';

   SELECT
       ''
      ,CAST('PAD_EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAD_EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('PAD_EQUIP_MODEL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAD_EQUIP_MODEL like '@%';

   SELECT
       ''
      ,CAST('MAC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MAC_ADDR like '@%';

   SELECT
       ''
      ,CAST('BJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BJ_NO like '@%';

   SELECT
       ''
      ,CAST('IP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND IP_ADDR like '@%';

   SELECT
       ''
      ,CAST('GEOG_PSTN_LGTD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GEOG_PSTN_LGTD like '@%';

   SELECT
       ''
      ,CAST('GEOG_PSTN_LATD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GEOG_PSTN_LATD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('ELEC_VOCH_PERMNT_KEEP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ELEC_VOCH_PERMNT_KEEP_FLAG like '@%';

   SELECT
       ''
      ,CAST('ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MENU_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MENU_NO like '@%';

   SELECT
       ''
      ,CAST('MENU_MODULE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MENU_MODULE_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_SERV_LINK_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SERV_LINK_DESC like '@%';

   SELECT
       ''
      ,CAST('TXN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_DESC_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DESC_1 like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('HANDLE_TELR_POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HANDLE_TELR_POST_CD like '@%';

   SELECT
       ''
      ,CAST('HANDLE_TELR_POST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HANDLE_TELR_POST_NAME like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_FLAG like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCT_CATEGORY_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_CATEGORY_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_RESLT_DESC_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RESLT_DESC_1 like '@%';

   SELECT
       ''
      ,CAST('TXN_RESLT_DESC_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RESLT_DESC_2 like '@%';

   SELECT
       ''
      ,CAST('FRONT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FRONT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TELR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TELR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('IMAGE_PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND IMAGE_PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('GLOB_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GLOB_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CORE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CORE_SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */