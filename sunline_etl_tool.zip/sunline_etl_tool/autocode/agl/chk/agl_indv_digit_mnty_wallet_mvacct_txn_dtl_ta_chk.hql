-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人数字货币钱包动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA
--     表中文名：个人数字货币钱包动账交易明细聚合
--     创建日期：2024-06-24 00:00:00
--     主键字段：CORE_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-06-24 00:00:00 魏丹丹 新增
--         2024-10-16 00:00:00 魏丹丹 生产问题修复，入湖补入字段同步



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CORE_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CORE_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CORE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CORE_ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CORE_FLOW_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_FLOW_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_CORE_FLOW_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_CORE_FLOW_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_REQE_FLOW_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_REQE_FLOW_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_CHNL_REQE_FLOW_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_TRACK_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TRACK_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_OVERTM_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_OVERTM_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTYTIE_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTYTIE_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTYTIE_SUB_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTYTIE_SUB_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_TXN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_TXN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_DESC like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTY_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTY_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTY_APP_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTY_APP_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_CARD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPEN_CARD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_HAPP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_HAPP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WALLET_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WALLET_NAME like '@%';

   SELECT
       ''
      ,CAST('WALLET_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WALLET_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WALLET_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_WALLET_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_WALLET_NO like '@%';

   SELECT
       ''
      ,CAST('TRPS_PTY_OPER_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRPS_PTY_OPER_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_WALLET_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_WALLET_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_WALLET_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_WALLET_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_WALLET_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_WALLET_NAME like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_TRNOUT_ACT_TP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_TRNOUT_ACT_TP_CD like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_ACCT_NO_HANG_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_ACCT_NO_HANG_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_WALLET_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_WALLET_NO like '@%';

   SELECT
       ''
      ,CAST('TRANEE_OPER_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRANEE_OPER_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_WALLET_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_WALLET_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TRNIN_WALLET_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_WALLET_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('TRNIN_WALLET_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_WALLET_NAME like '@%';

   SELECT
       ''
      ,CAST('TRNIN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_TRNIN_ACT_TP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_TRNIN_ACT_TP_CD like '@%';

   SELECT
       ''
      ,CAST('TRNIN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_OPER_ORG_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_OPER_ORG_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_PAY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_PAY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SHOULD_STL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SHOULD_STL_AMT like '@%';

   SELECT
       ''
      ,CAST('GEN_GOLD_COPN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GEN_GOLD_COPN_AMT like '@%';

   SELECT
       ''
      ,CAST('TERMN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TERMN_NO like '@%';

   SELECT
       ''
      ,CAST('CNT_CURR_SCENE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNT_CURR_SCENE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CHNL_MERCHT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_MERCHT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_MERCHT_FLOW_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_MERCHT_FLOW_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_OPER_ORG_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_OPER_ORG_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('ORDER_PAY_CMPLT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_PAY_CMPLT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORDER_INVALID_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_INVALID_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_CHNL_MERCHT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CHNL_MERCHT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CHNL_MERCHT_FLOW_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CHNL_MERCHT_FLOW_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_COL_OPORG_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_COL_OPORG_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CNT_CURR_PAY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CNT_CURR_PAY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DIGIT_MNTYTIE_TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIGIT_MNTYTIE_TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_ESTB_AFLT_FIN_ORG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ESTB_AFLT_FIN_ORG_CD like '@%';

   SELECT
       ''
      ,CAST('SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYS_CD like '@%';

   SELECT
       ''
      ,CAST('ANALY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ANALY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('OPERR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_NAME like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('OPERR_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */