-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-城乡两费交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_URTF_TXN_DTL_TA
--     表中文名：城乡两费交易明细聚合
--     创建日期：2024-03-21 00:00:00
--     主键字段：TXN_DT, TXN_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-21 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_DT, TXN_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_FEE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_FEE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('PLAT_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_PAY_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_PAY_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_PUB_PRIV_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PUB_PRIV_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('BANK_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_REFUND_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_REFUND_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('BANK_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TAX_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TAX_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_CD like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_VIRTUAL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_VIRTUAL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TAX_PRTCPT_INSURE_PSN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TAX_PRTCPT_INSURE_PSN_NO like '@%';

   SELECT
       ''
      ,CAST('TAX_PRTCPT_INSURE_PSN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TAX_PRTCPT_INSURE_PSN_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_PSN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_PSN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('COMMS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMMS_DT like '@%';

   SELECT
       ''
      ,CAST('BANK_PAY_AGT_BOOK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_PAY_AGT_BOOK_NO like '@%';

   SELECT
       ''
      ,CAST('URBA_RUBAL_FEE_PAY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URBA_RUBAL_FEE_PAY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('URFEE_TPTY_ACCTN_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URFEE_TPTY_ACCTN_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('URFEE_HOST_ACCTN_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URFEE_HOST_ACCTN_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URTF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_TXN_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */