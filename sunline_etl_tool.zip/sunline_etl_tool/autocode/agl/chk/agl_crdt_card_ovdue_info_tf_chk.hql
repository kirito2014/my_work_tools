-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡逾期信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_OVDUE_INFO_TF
--     表中文名：信用卡逾期信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：CRDT_CARD_ACCT_NO, MONTHS
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-23 00:00:00 魏丹丹 新增
--         2024-09-07 00:00:00 魏丹丹 修改取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CRDT_CARD_ACCT_NO, MONTHS) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CRDT_CARD_ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(MONTHS AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CRDT_CARD_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('OVDUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_DT like '@%';

   SELECT
       ''
      ,CAST('TURN_OVR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TURN_OVR_DT like '@%';

   SELECT
       ''
      ,CAST('BIL_MONTH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIL_MONTH like '@%';

   SELECT
       ''
      ,CAST('OVDUE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_FLAG like '@%';

   SELECT
       ''
      ,CAST('INIT_OVDUE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_OVDUE_AMT like '@%';

   SELECT
       ''
      ,CAST('INIT_OVDUE_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_OVDUE_INT like '@%';

   SELECT
       ''
      ,CAST('REMAIN_OVDUE_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_OVDUE_PRIN like '@%';

   SELECT
       ''
      ,CAST('REMAIN_OVDUE_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_OVDUE_INT like '@%';

   SELECT
       ''
      ,CAST('LAST_REPAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_REPAY_DT like '@%';

   SELECT
       ''
      ,CAST('OVDUE_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('OD_TO_OVDUE_FEE_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OD_TO_OVDUE_FEE_BAL like '@%';

   SELECT
       ''
      ,CAST('REMAIN_OVDUE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_OVDUE_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_TXN_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_TXN_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_ANLFEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_ANLFEE like '@%';

   SELECT
       ''
      ,CAST('INIT_LATE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_LATE_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_OVER_LMT_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_OVER_LMT_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_INSTALMT_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_INSTALMT_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_VA_SERV_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_VA_SERV_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_OTHER_FEE_INCOME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_OTHER_FEE_INCOME like '@%';

   SELECT
       ''
      ,CAST('INIT_REPAY_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_REPAY_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_TXN_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_TXN_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_ANLFEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_ANLFEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_LATE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_LATE_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_OVER_LMT_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_OVER_LMT_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_INSTALMT_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_INSTALMT_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_VA_SERV_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_VA_SERV_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_OTHER_FEE_INCOME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_OTHER_FEE_INCOME like '@%';

   SELECT
       ''
      ,CAST('REMAIN_REPAY_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_REPAY_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('INIT_INSTMT_UNRPD_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_INSTMT_UNRPD_FEE like '@%';

   SELECT
       ''
      ,CAST('REMAIN_INSTMT_UNRPD_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_OVDUE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_INSTMT_UNRPD_FEE like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */