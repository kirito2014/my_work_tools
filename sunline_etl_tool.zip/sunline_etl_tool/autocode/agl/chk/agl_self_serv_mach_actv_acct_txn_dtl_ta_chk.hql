-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-自助机具动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA
--     表中文名：自助机具动账交易明细聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：BIZ_SER_NO, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-02-26 00:00:00 魏丹丹 新增
--         2024-08-20 00:00:00 魏丹丹 新增
--         2024-09-08 00:00:00 魏丹丹 新增字段，新增表
--         2024-10-16 00:00:00 魏丹丹 2024/9/20新增表市民卡交易流水表 ODS_ZZQZ_T_BSMS_JRNL_TF ，新增四个字段   2024/10/16第五组unifiedTime(P1.TRANDATE||P1.TRANTIME)



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(BIZ_SER_NO, TXN_DT, TXN_TM_STAMP) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(BIZ_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_TM_STAMP AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('BIZ_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_INITR_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_INITR_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('FUNC_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUNC_ID like '@%';

   SELECT
       ''
      ,CAST('FUNC_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUNC_DESC like '@%';

   SELECT
       ''
      ,CAST('FRONT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FRONT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_INITR_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_INITR_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_INITR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_INITR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_INITR_CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_INITR_CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_INITR_CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_INITR_CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_RECVER_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RECVER_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_RECVER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RECVER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_RECVER_CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RECVER_CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_RECVER_CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RECVER_CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('VOCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VOCH_NO like '@%';

   SELECT
       ''
      ,CAST('P_END_RSPS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND P_END_RSPS_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_TRAN_CD_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TRAN_CD_DESC like '@%';

   SELECT
       ''
      ,CAST('ACTL_RECV_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACTL_RECV_AMT like '@%';

   SELECT
       ''
      ,CAST('UNPY_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('OPBANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPBANK_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_SER_NO like '@%';

   SELECT
       ''
      ,CAST('UNIONPAY_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNIONPAY_SER_NO like '@%';

   SELECT
       ''
      ,CAST('RV_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RV_SER_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_BIZ_CATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BIZ_CATE_NO like '@%';

   SELECT
       ''
      ,CAST('SELF_SERV_TERMN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SELF_SERV_TERMN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('AFLT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AFLT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SYS_VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYS_VIRTUAL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SUCC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUCC_FLAG like '@%';

   SELECT
       ''
      ,CAST('CASH_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_FLAG like '@%';

   SELECT
       ''
      ,CAST('RV_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RV_FLAG like '@%';

   SELECT
       ''
      ,CAST('SERVER_IP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERVER_IP like '@%';

   SELECT
       ''
      ,CAST('MACH_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MACH_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUDIT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('DATA_EFFECT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_SERV_MACH_ACTV_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DATA_EFFECT_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */