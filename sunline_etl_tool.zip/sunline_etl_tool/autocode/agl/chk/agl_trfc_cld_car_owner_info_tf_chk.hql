-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云车主信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_CAR_OWNER_INFO_TF
--     表中文名：交通云车主信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：PLAN_CLS_AST_IVS_TXN_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：叶禹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-16 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAN_CLS_AST_IVS_TXN_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAN_CLS_AST_IVS_TXN_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TRFC_FIN_CLD_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TRFC_FIN_CLD_USER_ID like '@%';

   SELECT
       ''
      ,CAST('GOOD_HVST_INTCNK_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GOOD_HVST_INTCNK_USER_ID like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_USE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_USE_FLAG like '@%';

   SELECT
       ''
      ,CAST('DEL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEL_FLAG like '@%';

   SELECT
       ''
      ,CAST('INPUT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('USER_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('WX_OPENID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WX_OPENID like '@%';

   SELECT
       ''
      ,CAST('ETC_INTGRT_CERT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_INTGRT_CERT_FLAG like '@%';

   SELECT
       ''
      ,CAST('CAR_OWNER_CERT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAR_OWNER_CERT_FLAG like '@%';

   SELECT
       ''
      ,CAST('NO_TOUCH_STOP_CAR_SIGN_CERT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_CAR_OWNER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NO_TOUCH_STOP_CAR_SIGN_CERT_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */