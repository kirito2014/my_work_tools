-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-电子社保卡信息聚合表
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF
--     表中文名：电子社保卡信息聚合表
--     创建日期：2024-08-08 00:00:00
--     主键字段：TXN_SEQ_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-08 00:00:00 陈艺丹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SEQ_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SEQ_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NAME like '@%';

   SELECT
       ''
      ,CAST('IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_RGN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_RGN_NAME like '@%';

   SELECT
       ''
      ,CAST('ELEC_SOCI_SECU_CARD_OPEN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_SOCI_SECU_CARD_OPEN_FLAG like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_CARD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_CARD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CONT_SIGN_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_SIGN_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('EXC_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND EXC_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('REG_LOCAL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_LOCAL_ADDR like '@%';

   SELECT
       ''
      ,CAST('DRAW_CARD_BIZ_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_CARD_BIZ_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ISSUE_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('ISSUE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_NO like '@%';

   SELECT
       ''
      ,CAST('VALID_END_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND VALID_END_DT like '@%';

   SELECT
       ''
      ,CAST('DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND DIST_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('ELEC_SOCI_SECU_CARD_TRIG_FUNC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_SOCI_SECU_CARD_TRIG_FUNC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('GOOD_HVST_INTCNK_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND GOOD_HVST_INTCNK_USER_ID like '@%';

   SELECT
       ''
      ,CAST('CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('NOTICE_SOCI_SECU_STAUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_INFO_AGGREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_SOCI_SECU_STAUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */