-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-商户反欺诈灰黑名单信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF
--     表中文名：商户反欺诈灰黑名单信息聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-10-10 00:00:00 魏丹丹 新增
--         2024-10-30 00:00:00 魏丹丹 新增客户证件信息表，客户内码字段



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT('MERCHT_REC_SER_NO', '01xb', 'MERCHT_NO', '01xb', 'MERCHT_NAME', '01xb', 'CUST_IN_CD', '01xb', 'MERCHT_RISK_SRC_CHNL_CD', '01xb', 'MERCHT_BLKLIST_STAT_CD', '01xb', 'RECV_BIL_MERCHT_TXN_CHNL_CD', '01xb', 'ACCT_STATUS_CD', '01xb', 'MERCHT_BLKLIST_SRC_CD', '01xb', 'MERCHANT_FLAG', '01xb', 'MERCHT_DOCTYP_CD', '01xb', 'MERCHT_DOC_NO', '01xb', 'LP_REPRSNT_NAME', '01xb', 'LP_REPRSNT_DOCTYP_CD', '01xb', 'LP_REPRSNT_DOC_NO', '01xb', 'LP_RISK_TYPE_CD', '01xb', 'BELONG_ORG_NO', '01xb', 'CREATE_TM_STAMP', '01xb', 'EXP_TM_STAMP', '01xb', 'FINAL_UPDATE_TM_STAMP', '01xb', 'FINAL_MODIF_TELR_NO') AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(
      CAST(COALESCE(CAST(MERCHT_REC_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_NAME AS STRING),'') AS STRING), CAST(COALESCE(CAST(CUST_IN_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_RISK_SRC_CHNL_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_BLKLIST_STAT_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(RECV_BIL_MERCHT_TXN_CHNL_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(ACCT_STATUS_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_BLKLIST_SRC_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHANT_FLAG AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_DOCTYP_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(MERCHT_DOC_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(LP_REPRSNT_NAME AS STRING),'') AS STRING), CAST(COALESCE(CAST(LP_REPRSNT_DOCTYP_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(LP_REPRSNT_DOC_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(LP_RISK_TYPE_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(BELONG_ORG_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CREATE_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(EXP_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(FINAL_UPDATE_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(FINAL_MODIF_TELR_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('MERCHT_REC_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_REC_SER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_RISK_SRC_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_RISK_SRC_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_BLKLIST_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_BLKLIST_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_MERCHT_TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_MERCHT_TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_BLKLIST_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_BLKLIST_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHANT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHANT_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('LP_REPRSNT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_REPRSNT_NAME like '@%';

   SELECT
       ''
      ,CAST('LP_REPRSNT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_REPRSNT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('LP_REPRSNT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_REPRSNT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('LP_RISK_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_RISK_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('EXP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_MERCHT_ANTI_FRAUD_HBLKLIST_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */