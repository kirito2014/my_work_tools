-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-人行代理收付交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA
--     表中文名：人行代理收付交易明细聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：PLAT_SER_NO, PLAT_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：包括经人行转发的缴费交易信息、批量代收付交易信息和实时代收付交易信息
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 20240724 版本同步
--         2024-10-08 00:00:00 王穆军 修改赋值错误



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_SER_NO, PLAT_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('LOC_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LOC_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('PBC_NET_IN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_NET_IN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('ACCESS_POINT_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCESS_POINT_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('TXN_PROD_COST' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_PROD_COST like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_COL_PAY_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_COL_PAY_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGT_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_INFO_CNT_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_INFO_CNT_VAL like '@%';

   SELECT
       ''
      ,CAST('PAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_DT like '@%';

   SELECT
       ''
      ,CAST('PBC_PAY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_PAY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('PBC_BIZ_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_BIZ_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('PBC_BIZ_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_BIZ_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_PBC_BIZ_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_PBC_BIZ_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_PBC_BIZ_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_PBC_BIZ_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_COL_PAY_PAY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_COL_PAY_PAY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_COL_PAY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_COL_PAY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('CHNL_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CORE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CORE_INPUT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_INPUT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('HOST_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('HOST_STRK_BAL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_STRK_BAL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_ON_ACCT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_ON_ACCT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_ON_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_ON_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('HOST_WRTOFF_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_WRTOFF_SER_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_PAY_CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_PAY_CUST_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_PAY_CUST_NO_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_PAY_CUST_NO_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NO ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NO  like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_INTER_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_INTER_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_INTER_STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_INTER_STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_OPBANK_ACCT_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_OPBANK_ACCT_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAYER_OPBANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_OPBANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAY_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAY_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAYER_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('PAYER_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_MVACCT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_MVACCT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_NOTICE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_NOTICE_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO  like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_INTER_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_INTER_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_INTER_STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_INTER_STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_FIN_ACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_FIN_ACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('PAYEE_OPBANK_ACCT_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_OPBANK_ACCT_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAYEE_OPBANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_OPBANK_NAME like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_AMT_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_AMT_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAYEE_MVACCT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_MVACCT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('RCD_NOTICE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RCD_NOTICE_NO like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_RCPT_PAY_CENTER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_RCPT_PAY_CENTER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_VER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_VER_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_CONT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_CONT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('PKG_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PKG_SER_NO like '@%';

   SELECT
       ''
      ,CAST('DTL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DTL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PKG_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PKG_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('DTL_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DTL_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('DTL_BIZ_REF_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DTL_BIZ_REF_NO like '@%';

   SELECT
       ''
      ,CAST('PKG_COMMS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PKG_COMMS_DT like '@%';

   SELECT
       ''
      ,CAST('DTL_COMMS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DTL_COMMS_DT like '@%';

   SELECT
       ''
      ,CAST('AL_CHECK_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AL_CHECK_FLAG like '@%';

   SELECT
       ''
      ,CAST('START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('INIT_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INIT_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PACP_BIZ_RCPT_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PACP_BIZ_RCPT_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_PKG_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_PKG_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_DTL_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_DTL_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_COMMS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_COMMS_DT like '@%';

   SELECT
       ''
      ,CAST('ORIG_START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('REFUS_ORG_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REFUS_ORG_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('REFUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REFUS_CD like '@%';

   SELECT
       ''
      ,CAST('REFUS_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REFUS_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('NPC_PROC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NPC_PROC_CD like '@%';

   SELECT
       ''
      ,CAST('NPC_REFUS_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NPC_REFUS_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('NPC_DEAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NPC_DEAL_DT like '@%';

   SELECT
       ''
      ,CAST('NPC_BIZ_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NPC_BIZ_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_PAY_BIZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_PAY_BIZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MGMT_ORG_CLEAR_CENTER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MGMT_ORG_CLEAR_CENTER_NO like '@%';

   SELECT
       ''
      ,CAST('INPUT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INPUT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('INPUT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('UPDATE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UPDATE_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('B_SRC_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('B_SRC_TAB_EN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_TAB_EN_NAME like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */