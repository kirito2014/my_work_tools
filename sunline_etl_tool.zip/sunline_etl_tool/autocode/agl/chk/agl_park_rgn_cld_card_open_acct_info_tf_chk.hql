-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-园区云卡片开户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF
--     表中文名：园区云卡片开户信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：BAT_OPEN_ACCT_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：叶禹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-16 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(BAT_OPEN_ACCT_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(BAT_OPEN_ACCT_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('BAT_OPEN_ACCT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAT_OPEN_ACCT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_NAME like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NO like '@%';

   SELECT
       ''
      ,CAST('PRC_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRC_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NAME like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('PRC_CUST_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRC_CUST_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_GENDER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_GENDER_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_BIRTH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_BIRTH_DT like '@%';

   SELECT
       ''
      ,CAST('CUST_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('FAMILY_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAMILY_ADDR like '@%';

   SELECT
       ''
      ,CAST('CUST_COMMUNIC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_COMMUNIC_ADDR like '@%';

   SELECT
       ''
      ,CAST('POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POST_CD like '@%';

   SELECT
       ''
      ,CAST('EMAIL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EMAIL_ADDR like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SYS_DEAL_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SYS_DEAL_TM like '@%';

   SELECT
       ''
      ,CAST('DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_CARD_OPEN_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEAL_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */