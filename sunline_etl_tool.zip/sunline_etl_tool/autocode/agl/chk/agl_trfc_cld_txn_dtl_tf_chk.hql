-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_TXN_DTL_TF
--     表中文名：交通云交易明细聚合
--     创建日期：None
--     主键字段：TXN_SER_NO, TXN_TYPE_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-15 00:00:00 万香 新增
--         2024-10-21 00:00:00 魏丹丹 修改字段英文名：业务流水号



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO, TXN_TYPE_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_TYPE_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('STOP_CAR_PLACE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_CAR_PLACE_NO like '@%';

   SELECT
       ''
      ,CAST('DRIVING_IN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DRIVING_IN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('PAYER_PAY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PAYER_PAY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_REFUND_BIL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_REFUND_BIL_NO like '@%';

   SELECT
       ''
      ,CAST('AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_NO like '@%';

   SELECT
       ''
      ,CAST('REFUND_STATUS_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_STATUS_DESC like '@%';

   SELECT
       ''
      ,CAST('DEL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DEL_FLAG like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TRFC_CLD_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TRFC_CLD_MERCHT_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */