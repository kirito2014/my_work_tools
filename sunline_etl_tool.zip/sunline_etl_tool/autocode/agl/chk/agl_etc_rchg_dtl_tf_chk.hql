-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-ETC充值明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ETC_RCHG_DTL_TF
--     表中文名：ETC充值明细聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：ETC充值信息，特色代收付平台的交易流水表
--     更新记录：
--         2024-10-10 00:00:00 魏丹丹 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_DT, PLAT_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('RCHG_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RCHG_SER_NO like '@%';

   SELECT
       ''
      ,CAST('RCHG_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RCHG_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('RCHG_CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RCHG_CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('INIT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('INIT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('RCHG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RCHG_DT like '@%';

   SELECT
       ''
      ,CAST('RCHG_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RCHG_AMT like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_RCHG_TXN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_RCHG_TXN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_COLOR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_COLOR_CD like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('FORE_END_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FORE_END_SER_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CHNL_NO like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_NO like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_NAME like '@%';

   SELECT
       ''
      ,CAST('ETC_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('UNDO_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNDO_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SEQ_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SEQ_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_DESC like '@%';

   SELECT
       ''
      ,CAST('ERR_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ERR_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('HOST_ACCTN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND HOST_ACCTN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_CENT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND HOST_CENT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_CENT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_RCHG_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_CENT_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */