-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人活期存款不动户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF
--     表中文名：个人活期存款不动户信息聚合
--     创建日期：2024-07-24 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-07-24 00:00:00 陈艺丹 创建
--         2024-09-19 00:00:00 陈艺丹 修改union2主表筛选条件
--         2024-10-16 00:00:00 魏丹丹 修改第一组 ：存款产品编号逻辑，记录状态代码，开发问题修复



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ACCT_NO, CURR_CD, CASH_RMT_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CASH_RMT_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('NON_ACTV_ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NON_ACTV_ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DPSTRCP_CONVT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSTRCP_CONVT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('REDT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('DPSIT_ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('NON_ACTV_ACCT_ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NON_ACTV_ACCT_ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('NON_ACTV_ACCT_ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NON_ACTV_ACCT_ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('TURN_NON_BIZ_ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TURN_NON_BIZ_ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('TURN_NON_BIZ_ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TURN_NON_BIZ_ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('CURR_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_BAL like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('TURN_NON_BIZ_INCOME_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TURN_NON_BIZ_INCOME_DT like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('DPSIT_BIZ_MDL_CATOGR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_BIZ_MDL_CATOGR_CD like '@%';

   SELECT
       ''
      ,CAST('OD_LIC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OD_LIC_FLAG like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('INTACR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_FLAG like '@%';

   SELECT
       ''
      ,CAST('TRNIN_BAL_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_BAL_ACCUM like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('DRAW_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DRAW_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_ACT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_ACT_DT like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CURR_DPSIT_NON_ACTV_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */