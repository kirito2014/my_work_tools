-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-人行代理缴费签约信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF
--     表中文名：人行代理缴费签约信息聚合
--     创建日期：2024-06-25 00:00:00
--     主键字段：AGT_NO, BIZ_UNIT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：mid平台中所有有效的一户通签约协议数据，不包括已解约又重新签约的解约数据
--     更新记录：
--         2024-06-25 00:00:00 原海娜 新增
--         2024-10-22 00:00:00 原海娜 新增主键，修改T4,T5关联条件
--         2024-11-11 00:00:00 魏丹丹 增加 账户公私类型代码,人行代理缴费账户性质代码,卡折标识代码,扣款周期代码 码值，时间戳修复;人行代理缴费账户性质代码 中英文名变更



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(AGT_NO, BIZ_UNIT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(AGT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BIZ_UNIT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('AGT_EFFECT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_EFFECT_DT like '@%';

   SELECT
       ''
      ,CAST('AGT_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_PAY_AGT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_PAY_AGT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('PBC_BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PBC_BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('USCD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND USCD like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_CATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_CATE_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('ACCT_PUB_PRIV_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PUB_PRIV_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PBC_AGEN_PAY_ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PBC_AGEN_PAY_ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_DISCNT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_DISCNT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_OPBANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_OPBANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND POST_CD like '@%';

   SELECT
       ''
      ,CAST('PAYER_TXN_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PAYER_TXN_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('PAYEE_TXN_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_TXN_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('INIT_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND INIT_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('ACTL_USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_USER_NAME like '@%';

   SELECT
       ''
      ,CAST('USER_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('USER_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ADDR like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('SINGLE_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SINGLE_LMT like '@%';

   SELECT
       ''
      ,CAST('ALLOW_PERIOD_IN_TXN_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_PERIOD_IN_TXN_CNT like '@%';

   SELECT
       ''
      ,CAST('ALLOW_PERIOD_IN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_PERIOD_IN_LMT like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_CHNL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_CHNL_DT like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_AGT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_AGT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_EXCEP_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PBC_AGEN_COL_PAY_SIGN_INFO_AHHREGT_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_EXCEP_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */