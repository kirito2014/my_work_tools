-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人大额存取款交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA
--     表中文名：个人大额存取款交易明细聚合
--     创建日期：2024-05-18 00:00:00
--     主键字段：ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_DT
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：翟向阳
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-17 00:00:00 翟向阳 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ORIG_TXN_SER_NO, SUB_TXN_SER_NO, TXN_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ORIG_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SUB_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DATA_SRC_MODULE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DATA_SRC_MODULE_CD like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_TRAN_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_TRAN_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('TELR_INPUT_ORIG_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TELR_INPUT_ORIG_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('OPERR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_NAME like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TELR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TELR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LARGE_AMT_DPSIT_DRAW_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */