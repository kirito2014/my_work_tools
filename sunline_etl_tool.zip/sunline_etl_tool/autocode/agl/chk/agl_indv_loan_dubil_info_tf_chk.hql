-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人贷款借据信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_LOAN_DUBIL_INFO_TF
--     表中文名：个人贷款借据信息聚合
--     创建日期：2023-12-06 00:00:00
--     主键字段：LOAN_CONT_NO, DUBIL_NO, LOAN_CONT_GRP_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-06 00:00:00 魏丹丹 新增
--         2024-04-25 00:00:00 魏丹丹 活期可用余额修改，更换来源表，增加字段
--         2024-08-02 00:00:00 魏丹丹 新增积数
--         2024-09-06 00:00:00 魏丹丹 新增字段15个，字段名变更，取数来源变更
--         2024-10-09 00:00:00 魏丹丹 删除：本金科目编号，贷款科目编号; 新增字段：存单折类型代码/账户性质代码/开户渠道代码/信息编码/行社贷款产品代码/账户处理状态编号/开户日期/开户柜员编号/开户金额/贷款合同起始日期/贷款合同到期日期/贷款表内利息/贷款表外利息/应收欠息/催收欠息/利息结清标志/借新还旧标志/贷款核算码/本金核算码/浙里贷标志/利息序号/归属信贷员编号/建立机构名称



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(LOAN_CONT_NO, DUBIL_NO, LOAN_CONT_GRP_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(LOAN_CONT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(DUBIL_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(LOAN_CONT_GRP_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('LOAN_CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_NO like '@%';

   SELECT
       ''
      ,CAST('DUBIL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DUBIL_NO like '@%';

   SELECT
       ''
      ,CAST('LOAN_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('LNACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LNACCT_NO like '@%';

   SELECT
       ''
      ,CAST('INDV_BIZ_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_BIZ_FLAG like '@%';

   SELECT
       ''
      ,CAST('SMALL_MICRO_CORP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMALL_MICRO_CORP_FLAG like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_MODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_MODE like '@%';

   SELECT
       ''
      ,CAST('TEL_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEL_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('ADDR_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADDR_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ADDR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADDR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DPSTRCP_CONVT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSTRCP_CONVT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('INFO_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_CD like '@%';

   SELECT
       ''
      ,CAST('MCH_LOANPROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MCH_LOANPROD_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_DEAL_STATUS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_DEAL_STATUS_NO like '@%';

   SELECT
       ''
      ,CAST('LNACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LNACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_LOAN_LVL_FOUR_MODAL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_LOAN_LVL_FOUR_MODAL_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_LOAN_LVL_FIVE_MODAL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_LOAN_LVL_FIVE_MODAL_CD like '@%';

   SELECT
       ''
      ,CAST('REF_LOAN_LVL_FIVE_MODAL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REF_LOAN_LVL_FIVE_MODAL_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('LOAN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_DT like '@%';

   SELECT
       ''
      ,CAST('LOAN_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_AMT like '@%';

   SELECT
       ''
      ,CAST('LOAN_PRIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_PRIN_AMT like '@%';

   SELECT
       ''
      ,CAST('DAILY_CUT__BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DAILY_CUT__BAL like '@%';

   SELECT
       ''
      ,CAST('CURR_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_BAL like '@%';

   SELECT
       ''
      ,CAST('YESTD_LOAN_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_LOAN_BAL like '@%';

   SELECT
       ''
      ,CAST('YESTD_LOAN_BAL_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_LOAN_BAL_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_MONTH_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_MONTH_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_QUAR_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_QUAR_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_YEAR_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_YEAR_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('NORMAL_EXC_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NORMAL_EXC_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('OVDUE_EXC_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_EXC_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('COMP_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMP_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('CURR_REMAIN_UNREPAID_PRIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_REMAIN_UNREPAID_PRIN_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_REMAIN_UNREPAID_INT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_REMAIN_UNREPAID_INT_AMT like '@%';

   SELECT
       ''
      ,CAST('LOAN_ON_BS_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_ON_BS_INT like '@%';

   SELECT
       ''
      ,CAST('LOAN_OFBS_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_OFBS_INT like '@%';

   SELECT
       ''
      ,CAST('ON_BS_RECVBL_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ON_BS_RECVBL_INT like '@%';

   SELECT
       ''
      ,CAST('OFBS_RECVBL_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OFBS_RECVBL_INT like '@%';

   SELECT
       ''
      ,CAST('RECVBL_DEBIT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECVBL_DEBIT_INT like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_DEBIT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_DEBIT_INT like '@%';

   SELECT
       ''
      ,CAST('ACTL_RECV_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_RECV_INT like '@%';

   SELECT
       ''
      ,CAST('INT_PAYOFF_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INT_PAYOFF_FLAG like '@%';

   SELECT
       ''
      ,CAST('COMPND_INT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMPND_INT_FLAG like '@%';

   SELECT
       ''
      ,CAST('LOAN_REFLES_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_REFLES_FLAG like '@%';

   SELECT
       ''
      ,CAST('DUBIL_DEFLT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DUBIL_DEFLT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SETMENT_AUTO_REPAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETMENT_AUTO_REPAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('SETMENT_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETMENT_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('MATU_AUTO_REPAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATU_AUTO_REPAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('OVDUE_DEBIT_INT_AUTO_REPAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_DEBIT_INT_AUTO_REPAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('DUBIL_LOAN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DUBIL_LOAN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('DRAW_INT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_INT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_REPAY_GRACE_TERM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_REPAY_GRACE_TERM like '@%';

   SELECT
       ''
      ,CAST('REPAY_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPAY_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('DUBIL_LAST_REPAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DUBIL_LAST_REPAY_DT like '@%';

   SELECT
       ''
      ,CAST('DUBIL_LAST_SETMENT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DUBIL_LAST_SETMENT_DT like '@%';

   SELECT
       ''
      ,CAST('LOAN_ACCT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_ACCT_CD like '@%';

   SELECT
       ''
      ,CAST('PRIN_ACCT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRIN_ACCT_CD like '@%';

   SELECT
       ''
      ,CAST('PRIN_ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRIN_ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('SUBJ_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBJ_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('CRDT_DEFLT_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_DEFLT_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('OCCUPY_APPRO_EXC_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OCCUPY_APPRO_EXC_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_INT_RATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_INT_RATE_NO like '@%';

   SELECT
       ''
      ,CAST('LOAN_INT_RATE_FRTO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_INT_RATE_FRTO like '@%';

   SELECT
       ''
      ,CAST('OCCUPY_APPRO_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OCCUPY_APPRO_FLAG like '@%';

   SELECT
       ''
      ,CAST('LOAN_INT_RATE_ADJ_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_INT_RATE_ADJ_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('INTACR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_FLAG like '@%';

   SELECT
       ''
      ,CAST('ZLD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ZLD_FLAG like '@%';

   SELECT
       ''
      ,CAST('PURE_DATA_DRIVER_LOAN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PURE_DATA_DRIVER_LOAN_FLAG like '@%';

   SELECT
       ''
      ,CAST('WHITE_LIST_LOAN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WHITE_LIST_LOAN_FLAG like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_AGREE_SETMENT_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_AGREE_SETMENT_DAY like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_AGREE_REPAY_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_AGREE_REPAY_DAY like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('DUBIL_CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DUBIL_CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('MTG_LOAN_TOTAL_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_LOAN_TOTAL_TMS like '@%';

   SELECT
       ''
      ,CAST('MTG_LOAN_OVDUE_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_LOAN_OVDUE_CNT like '@%';

   SELECT
       ''
      ,CAST('MTG_CUM_REPAY_INT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_CUM_REPAY_INT_AMT like '@%';

   SELECT
       ''
      ,CAST('MTG_REPAY_CURR_PERIOD_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_REPAY_CURR_PERIOD_TMS like '@%';

   SELECT
       ''
      ,CAST('MTG_REPAY_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_REPAY_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MTG_LOAN_CURR_MONTHLY_PY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_LOAN_CURR_MONTHLY_PY_AMT like '@%';

   SELECT
       ''
      ,CAST('FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('MTG_LOAN_OVDUE_AUTO_REPAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MTG_LOAN_OVDUE_AUTO_REPAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('COMUT_DEBT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMUT_DEBT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DISPLC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DISPLC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TRAN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TRAN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('INT_IN_OFF_BS_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INT_IN_OFF_BS_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('INT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_PRIN_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_PRIN_BAL like '@%';

   SELECT
       ''
      ,CAST('OFBS_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OFBS_BAL like '@%';

   SELECT
       ''
      ,CAST('BORR_TYPE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BORR_TYPE_DESC like '@%';

   SELECT
       ''
      ,CAST('CUST_CRDT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CRDT like '@%';

   SELECT
       ''
      ,CAST('DPSIT_LOAN_HOOK_UP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_LOAN_HOOK_UP_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('REPAY_ACCT_NO_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPAY_ACCT_NO_1 like '@%';

   SELECT
       ''
      ,CAST('REPAY_ACCT_NO_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPAY_ACCT_NO_2 like '@%';

   SELECT
       ''
      ,CAST('REPAY_ACCT_NO_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPAY_ACCT_NO_3 like '@%';

   SELECT
       ''
      ,CAST('AGR_RELAT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGR_RELAT_FLAG like '@%';

   SELECT
       ''
      ,CAST('EXT_CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXT_CONT_NO like '@%';

   SELECT
       ''
      ,CAST('LOAN_CAP_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CAP_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_TERM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_TERM_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_GUAR_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_GUAR_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_GUAR_MODE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_GUAR_MODE_DESC like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_INSTALLMENT_REPAY_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_INSTALLMENT_REPAY_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('EXT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXT_TMS like '@%';

   SELECT
       ''
      ,CAST('EXT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXT_AMT like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_USAGE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_USAGE_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_USAGE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_USAGE_DESC like '@%';

   SELECT
       ''
      ,CAST('LOAN_AST_SECUZT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_AST_SECUZT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_TERM_MONTHS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_TERM_MONTHS like '@%';

   SELECT
       ''
      ,CAST('LOAN_INDUS_INVEST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_INDUS_INVEST_CD like '@%';

   SELECT
       ''
      ,CAST('LOANPROD_DERIV_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOANPROD_DERIV_CD like '@%';

   SELECT
       ''
      ,CAST('LOANPROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOANPROD_NO like '@%';

   SELECT
       ''
      ,CAST('LOANPROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOANPROD_NAME like '@%';

   SELECT
       ''
      ,CAST('LOANPROD_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOANPROD_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_LVL_TWO_PROD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_LVL_TWO_PROD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('LOAN_LATST_LOAN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_LATST_LOAN_DT like '@%';

   SELECT
       ''
      ,CAST('AVAILBL_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVAILBL_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('AVAILBL_PROD_VER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVAILBL_PROD_VER_NO like '@%';

   SELECT
       ''
      ,CAST('AVAILBL_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVAILBL_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('STDBY_FIELD_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STDBY_FIELD_1 like '@%';

   SELECT
       ''
      ,CAST('LOAN_CONT_GRP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOAN_CONT_GRP_CD like '@%';

   SELECT
       ''
      ,CAST('LOW_DEDUCT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOW_DEDUCT_LMT like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_LOAN_OFFICER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_LOAN_OFFICER_NO like '@%';

   SELECT
       ''
      ,CAST('LVL_ONE_SUM_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LVL_ONE_SUM_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACPTD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_DEPT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DEPT_NO like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('SUPCHA_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_LOAN_DUBIL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPCHA_ORDER_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */