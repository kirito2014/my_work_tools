-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-网联来账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA
--     表中文名：网联来账交易明细聚合
--     创建日期：2024-06-13 00:00:00
--     主键字段：MSG_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：包含第三方发起的支付、退货退款、第三方机构提现、签约解约等来账交易相关信息
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 修改脚本
--         2024-09-20 00:00:00 王穆军 修改P4关联条件,修改关联条件
--         2024-11-11 00:00:00 魏丹丹 增加来源表，修改客户内码取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(MSG_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(MSG_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('NUCC_VOSTRO_ACCT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_VOSTRO_ACCT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('NUCC_BIZ_CHNL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_BIZ_CHNL_DESC like '@%';

   SELECT
       ''
      ,CAST('BIZ_SINGLE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_SINGLE_NO like '@%';

   SELECT
       ''
      ,CAST('NUCC_MSG_MAP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_MSG_MAP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('NUCC_BIZ_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_BIZ_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('NUCC_BIZ_MCLS_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_BIZ_MCLS_DESC like '@%';

   SELECT
       ''
      ,CAST('NUCC_BIZ_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_BIZ_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('NUCC_BIZ_SCLS_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_BIZ_SCLS_DESC like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_SUCC_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SUCC_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_MSG_TXN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MSG_TXN_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_SIGN_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CONT_SIGN_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('END_TO_END_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND END_TO_END_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('RESP_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RESP_CODE like '@%';

   SELECT
       ''
      ,CAST('RESP_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RESP_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('TELEG_BANK_UPP_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TELEG_BANK_UPP_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_MSG_BANK_UPP_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_MSG_BANK_UPP_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MSG_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('RURAL_BANK_CRDT_MSG_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RURAL_BANK_CRDT_MSG_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('PLAT_CLEAR_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_CLEAR_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CN_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_USER_ID like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CLEAR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CLEAR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_USER_ID like '@%';

   SELECT
       ''
      ,CAST('PAYER_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_BANK_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BANK_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_CLEAR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_CLEAR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_RMT_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_RMT_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('ACCT_CONT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_CONT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CHENK_ACCT_CLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHENK_ACCT_CLS_NO like '@%';

   SELECT
       ''
      ,CAST('ERR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_DESC like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('NUCC_CORE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_CORE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('EXT_RESP_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NUCC_VOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EXT_RESP_MSG_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */