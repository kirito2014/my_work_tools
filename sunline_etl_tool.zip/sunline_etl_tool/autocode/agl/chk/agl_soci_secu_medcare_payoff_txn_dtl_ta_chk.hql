-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-医保社保代发交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA
--     表中文名：医保社保代发交易明细聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：TXN_SER_NO, TXN_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-11-15 00:00:00 魏丹丹 重写



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO, TXN_DT, PLAT_BATCH_NO, BAT_AGEN_PAY_SEQ_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_BATCH_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BAT_AGEN_PAY_SEQ_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('BAT_AGEN_PAY_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_AGEN_PAY_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('MSS_PAYOFF_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSS_PAYOFF_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_FUND_COL_ACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_FUND_COL_ACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_PAYOFF_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_PAYOFF_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MSS_PAYOFF_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSS_PAYOFF_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CLEAR_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('MSS_TXN_DTL_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSS_TXN_DTL_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_RCPT_PAY_CUST_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_RCPT_PAY_CUST_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('AGEN_CORP_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_CORP_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_FUND_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_FUND_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAY_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_OBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_OBJ_NO like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_OBJ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_OBJ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_OBJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_OBJ_NAME like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_OBJ_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_OBJ_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_OBJ_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_OBJ_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_OBJ_NATION_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_OBJ_NATION_CD like '@%';

   SELECT
       ''
      ,CAST('INS_COMMUNIC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INS_COMMUNIC_ADDR like '@%';

   SELECT
       ''
      ,CAST('MEDCARE_PAYOFF_DTL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MEDCARE_PAYOFF_DTL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CMPLT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CMPLT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('STL_PLAT_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_PLAT_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('STL_PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_ILUS like '@%';

   SELECT
       ''
      ,CAST('POSTSC_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SOCI_SECU_MEDCARE_PAYOFF_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND POSTSC_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */