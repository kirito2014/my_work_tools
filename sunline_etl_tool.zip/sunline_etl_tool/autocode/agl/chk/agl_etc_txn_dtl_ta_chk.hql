-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-ETC交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ETC_TXN_DTL_TA
--     表中文名：ETC交易明细聚合
--     创建日期：2024-04-23 00:00:00
--     主键字段：ETC_DATA_ENCASE_DT, ETC_DATA_ENCASE_BATCH_NO, BATCH_SEQ_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-23 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ETC_DATA_ENCASE_DT, ETC_DATA_ENCASE_BATCH_NO, BATCH_SEQ_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ETC_DATA_ENCASE_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(ETC_DATA_ENCASE_BATCH_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BATCH_SEQ_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ETC_DATA_ENCASE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ETC_DATA_ENCASE_DT like '@%';

   SELECT
       ''
      ,CAST('ETC_DATA_ENCASE_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ETC_DATA_ENCASE_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('BATCH_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BATCH_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('INTER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ETC_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_USAGE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_USAGE_DESC like '@%';

   SELECT
       ''
      ,CAST('TXN_DTL_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DTL_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_COLOR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_COLOR_CD like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_NO like '@%';

   SELECT
       ''
      ,CAST('PROV_IN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PROV_IN_FLAG like '@%';

   SELECT
       ''
      ,CAST('HIGH_SPEED_IN_SITE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HIGH_SPEED_IN_SITE_DESC like '@%';

   SELECT
       ''
      ,CAST('HIGH_SPEED_OUT_SITE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HIGH_SPEED_OUT_SITE_DESC like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_DT like '@%';

   SELECT
       ''
      ,CAST('GUAR_PAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GUAR_PAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('ETC_TXN_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ETC_TXN_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND HOST_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('ETC_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ETC_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_DT like '@%';

   SELECT
       ''
      ,CAST('ERR_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_DEAL_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_DEAL_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ADV_MNY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ETC_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ADV_MNY_AMT like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */