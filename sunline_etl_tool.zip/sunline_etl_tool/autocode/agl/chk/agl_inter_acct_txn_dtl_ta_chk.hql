-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-内部账户交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INTER_ACCT_TXN_DTL_TA
--     表中文名：内部账户交易明细聚合
--     创建日期：2023-12-11 00:00:00
--     主键字段：TXN_ACCT_NO, BELONG_GL_ACCT_ORG_NO, TXN_ACCTN_DT, ORIG_TXN_SER_NO, VOUCH_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-02-29 00:00:00 魏丹丹 新增
--         2024-09-07 00:00:00 魏丹丹 修改取数逻辑
--         2024-09-10 00:00:00 魏丹丹 修改会计科目编号取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_ACCT_NO, BELONG_GL_ACCT_ORG_NO, TXN_ACCTN_DT, ORIG_TXN_SER_NO, VOUCH_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BELONG_GL_ACCT_ORG_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_ACCTN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(ORIG_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(VOUCH_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_GL_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_GL_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('VOUCH_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VOUCH_SER_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PRIN_OFBS_IN_FLAG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PRIN_OFBS_IN_FLAG_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_TRAN_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CASH_TRAN_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('RBMRK_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RBMRK_CD like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('INTER_ACCT_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('REAL_TM_ACCT_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REAL_TM_ACCT_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_BAL_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_BAL_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_BAL like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NO like '@%';

   SELECT
       ''
      ,CAST('DWELL_SPC_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DWELL_SPC_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TELR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TELR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('VOCH_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VOCH_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('VOCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND VOCH_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_DEBIT_CRDT_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_DEBIT_CRDT_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RGN_NO like '@%';

   SELECT
       ''
      ,CAST('AGENT_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGENT_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('DLGT_BANK_BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DLGT_BANK_BNKOUTLS_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHECKER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECKER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_AUTH_TELR_NO_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AUTH_TELR_NO_1 like '@%';

   SELECT
       ''
      ,CAST('AUTH_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_CLEAR_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_CLEAR_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ACCT_REC_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCT_REC_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('GL_CHECK_ENTRY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND GL_CHECK_ENTRY_FLAG like '@%';

   SELECT
       ''
      ,CAST('ORIG_TRAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TRAN_CD like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_DESC like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */