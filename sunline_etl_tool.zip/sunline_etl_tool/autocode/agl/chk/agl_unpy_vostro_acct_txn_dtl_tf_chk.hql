-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-银联来账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF
--     表中文名：银联来账交易明细聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：TXN_SER_NO, UNPY_MSG_TYPE_NO, UNPY_TXN_PROC_CD, UNPY_TXN_TRANS_TM_STAMP, UNPY_EQUIP_SYS_TRACK_NO, ACPTD_TXN_UNPY_ORG_NO, SEND_TXN_UNPY_ORG_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO, UNPY_MSG_TYPE_NO, UNPY_TXN_PROC_CD, UNPY_TXN_TRANS_TM_STAMP, UNPY_EQUIP_SYS_TRACK_NO, ACPTD_TXN_UNPY_ORG_NO, SEND_TXN_UNPY_ORG_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_MSG_TYPE_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_TXN_PROC_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_TXN_TRANS_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_EQUIP_SYS_TRACK_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(ACPTD_TXN_UNPY_ORG_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SEND_TXN_UNPY_ORG_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('UNPY_VOSTRO_ACCT_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_VOSTRO_ACCT_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('MVACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MVACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CRDT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CRDT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('UNPY_VOSTRO_ACCT_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_VOSTRO_ACCT_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CNTRA_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CNTRA_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CNTRA_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CNTRA_NAME like '@%';

   SELECT
       ''
      ,CAST('TXN_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_REM like '@%';

   SELECT
       ''
      ,CAST('REFUND_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_AMT like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_MCC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_MCC_CD like '@%';

   SELECT
       ''
      ,CAST('PLAT_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('CLEAR_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CLEAR_EXCH_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_EXCH_RATE like '@%';

   SELECT
       ''
      ,CAST('CLEAR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_AMT like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_STATUS_CERT_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_STATUS_CERT_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_ACCT_NO_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_ACCT_NO_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_DEDUCT_EXCH_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_DEDUCT_EXCH_RATE like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_DEDUCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_DEDUCT_AMT like '@%';

   SELECT
       ''
      ,CAST('ACPTD_ORG_CTRY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_ORG_CTRY_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ERR_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('SERV_POINT_INPUT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_POINT_INPUT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_POINT_COND_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_POINT_COND_CD like '@%';

   SELECT
       ''
      ,CAST('UNPY_MSG_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_MSG_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('UNPY_TXN_PROC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_TXN_PROC_CD like '@%';

   SELECT
       ''
      ,CAST('UNPY_TXN_TRANS_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_TXN_TRANS_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('UNPY_EQUIP_SYS_TRACK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_EQUIP_SYS_TRACK_NO like '@%';

   SELECT
       ''
      ,CAST('ACPTD_TXN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_TXN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SEND_TXN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SEND_TXN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_TXN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_TXN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RETRIV_REF_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RETRIV_REF_NO like '@%';

   SELECT
       ''
      ,CAST('PRE_AUTH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_AUTH_NO like '@%';

   SELECT
       ''
      ,CAST('UNPY_VOSTRO_ACCT_TERMN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_VOSTRO_ACCT_TERMN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('USER_DEF_ADDIT_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_DEF_ADDIT_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('RISK_ADDIT_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RISK_ADDIT_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('RTN_GOODS_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RTN_GOODS_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_ADDIT_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_VOSTRO_ACCT_TXN_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_ADDIT_INFO_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */