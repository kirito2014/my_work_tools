-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-ATM非动账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ATM_UN_MVACCT_TXN_DTL_TA
--     表中文名：ATM非动账交易明细聚合
--     创建日期：None
--     主键字段：TXN_DT, TXN_TM_STAMP, EQUIP_NO, EQUIP_SYS_TRACK_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-15 00:00:00 万香 新增
--         2024-10-21 00:00:00 魏丹丹 修改临时表1,2,3的开窗分组字段
--         2024-10-28 00:00:00 魏丹丹 重写



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_DT, TXN_TM_STAMP, EQUIP_NO, EQUIP_SYS_TRACK_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(EQUIP_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(EQUIP_SYS_TRACK_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ATM_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ATM_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CARD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CARD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CARD_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CARD_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_SYS_TRACK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_SYS_TRACK_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BELONG_BNKOUTLS_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BELONG_BNKOUTLS_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_VIRTUAL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('ACPTD_TXN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_TXN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACPTD_TXN_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_TXN_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('RETRIV_REF_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RETRIV_REF_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_MCC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_MCC_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_POINT_INPUT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_POINT_INPUT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_DESC like '@%';

   SELECT
       ''
      ,CAST('SERV_SIDE_ADDIT_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ATM_UN_MVACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_SIDE_ADDIT_INFO_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */