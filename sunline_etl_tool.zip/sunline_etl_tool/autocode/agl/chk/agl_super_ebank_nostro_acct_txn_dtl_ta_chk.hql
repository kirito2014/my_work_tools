-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-超级网银往账交易明细
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA
--     表中文名：超级网银往账交易明细
--     创建日期：2024-06-13 00:00:00
--     主键字段：PLAT_DT, PLAT_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：None
--     描述信息：取超级网银T_IBPS_BOOK表的贷记往账、借记往账。剔除借记来账、三方来账（指如国家电网等代收付单位）
--     更新记录：
--         2024-06-13 00:00:00 王穆军 new
--         2024-09-05 00:00:00 王穆军 同步20240822 设计



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_DT, PLAT_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAY_BANK_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BANK_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAY_BANK_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAY_BANK_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO  like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CN_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_LIQD_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_LIQD_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_AMT_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_AMT_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_CONT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_CONT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('BIZ_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('STL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND STL_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('SUPER_EBANK_BIZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_EBANK_BIZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DEAL_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEAL_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('DEAL_RESLT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DEAL_RESLT_DESC like '@%';

   SELECT
       ''
      ,CAST('BIZ_REFUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_REFUS_CD like '@%';

   SELECT
       ''
      ,CAST('BIZ_REFUS_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BIZ_REFUS_DESC like '@%';

   SELECT
       ''
      ,CAST('ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_SRC_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_SRC_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_DT like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('INITR_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INITR_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('START_BANK_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECER_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECER_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('END_TO_END_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND END_TO_END_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECORD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECORD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('CHNL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_DT like '@%';

   SELECT
       ''
      ,CAST('CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_FLOW_MSG_SEND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_FLOW_MSG_SEND_FLAG like '@%';

   SELECT
       ''
      ,CAST('CHNL_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHNL_USER_ID like '@%';

   SELECT
       ''
      ,CAST('CERT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CERT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('BATCH_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BATCH_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('BAT_ACCTN_SUBJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_ACCTN_SUBJ_NO like '@%';

   SELECT
       ''
      ,CAST('BAT_ACTL_PAYER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_ACTL_PAYER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BAT_ACTL_PAYER_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BAT_ACTL_PAYER_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ONLINE_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ONLINE_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ONLINE_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ONLINE_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ONLINE_TXN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ONLINE_TXN_ILUS like '@%';

   SELECT
       ''
      ,CAST('INTFC_FLAG_BIT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTFC_FLAG_BIT like '@%';

   SELECT
       ''
      ,CAST('ORIG_PAY_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_PAY_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('ORIG_SEND_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_SEND_DT like '@%';

   SELECT
       ''
      ,CAST('ORIG_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_END_TO_END_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_END_TO_END_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_SUPER_EBANK_BIZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_SUPER_EBANK_BIZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('ORIG_PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('NOTICE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_DT like '@%';

   SELECT
       ''
      ,CAST('NOTICE_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('NTTG_SITE_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NTTG_SITE_CNT like '@%';

   SELECT
       ''
      ,CAST('NTTG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NTTG_DT like '@%';

   SELECT
       ''
      ,CAST('MSG_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_FORMAT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_FORMAT_DESC like '@%';

   SELECT
       ''
      ,CAST('WORK_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND WORK_DT like '@%';

   SELECT
       ''
      ,CAST('COMMUNIC_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COMMUNIC_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('SUPER_EBANK_REF_CONT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_EBANK_REF_CONT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('RCPT_MSG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RCPT_MSG_DT like '@%';

   SELECT
       ''
      ,CAST('RCPT_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RCPT_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('ENTRED_PAY_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SUPER_EBANK_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ENTRED_PAY_TXN_SER_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */