-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人借记卡信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DEBIT_CARD_INFO_TF
--     表中文名：个人借记卡信息聚合
--     创建日期：2023-12-13 00:00:00
--     主键字段：DEBIT_CARD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-13 00:00:00 游崔龙 新增
--         2024-01-11 00:00:00 游崔龙 对标
--         2024-02-20 00:00:00 王穆军 修改映射信息
--         2024-04-19 00:00:00 王穆军 修改客户内码去除空值的逻辑
--         2024-07-23 00:00:00 王穆军 修改与设计文档一致
--         2024-08-05 00:00:00 王穆军 新增字段
--         2024-09-06 00:00:00 王穆军 新增5个字段
--         2024-09-12 00:00:00 王穆军 修改第二组 账号逻辑
--         2024-09-24 00:00:00 王穆军 1、账户性质代码 20240915：新增字段2、国密卡标志 20240915：新增字段3、最后存取款日期 20240915：新增字段
--         2024-10-28 00:00:00 王穆军 新增3个字段，修改一个字段的中英文名称，删除最后存取款日期



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(DEBIT_CARD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(DEBIT_CARD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('DEBIT_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('MAIN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_MONTH_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_MONTH_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_QUAR_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_QUAR_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_YEAR_ACCUM_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_YEAR_ACCUM_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_MONTH_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_MONTH_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_QUAR_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_QUAR_ACCUM like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_YEAR_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_YEAR_ACCUM like '@%';

   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CARD_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CARD_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CARD_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_PROPTY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_PROPTY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TRGT_CUST_CARD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TRGT_CUST_CARD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_BRAND_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_BRAND_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('MODIF_BEF_CARD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODIF_BEF_CARD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('GOOD_HVST_DEBIT_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GOOD_HVST_DEBIT_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('EMPLY_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EMPLY_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('FOLD_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FOLD_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('FORGED_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FORGED_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('NAT_SECRET_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NAT_SECRET_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CARD_AGT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_AGT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('VOCH_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VOCH_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('CO_SIGN_IDTFY_CERT_CORP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CO_SIGN_IDTFY_CERT_CORP_NO like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CARD_ANLFEE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_ANLFEE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_CHARGE_RATE_PREFR_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CHARGE_RATE_PREFR_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('FREE_CARD_ANLFEE_EFFECT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FREE_CARD_ANLFEE_EFFECT_DT like '@%';

   SELECT
       ''
      ,CAST('FREE_CARD_ANLFEE_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FREE_CARD_ANLFEE_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('LAST_COL_ANLFEE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_COL_ANLFEE_DT like '@%';

   SELECT
       ''
      ,CAST('CONSM_POINT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONSM_POINT_BAL like '@%';

   SELECT
       ''
      ,CAST('UN_CROSS_ANLFEE_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_CROSS_ANLFEE_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('ELEC_CASH_ALLOW_OPEN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_CASH_ALLOW_OPEN_FLAG like '@%';

   SELECT
       ''
      ,CAST('ELEC_CASH_OPEN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ELEC_CASH_OPEN_FLAG like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_CARD_ONLINE_ACT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_CARD_ONLINE_ACT_FLAG like '@%';

   SELECT
       ''
      ,CAST('SMS_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMS_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('TEL_BANK_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEL_BANK_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('ATM_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ATM_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('POS_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POS_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('SETUP_COMMS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_COMMS_FLAG like '@%';

   SELECT
       ''
      ,CAST('MICRO_FREE_SECRET_VISA_XMP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MICRO_FREE_SECRET_VISA_XMP_FLAG like '@%';

   SELECT
       ''
      ,CAST('ACPTD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MAKE_CARD_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAKE_CARD_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('MAKE_CARD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAKE_CARD_DT like '@%';

   SELECT
       ''
      ,CAST('ISSUE_DRAW_CARD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_DRAW_CARD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_CARD_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_CARD_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_CARD_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_CARD_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_CARD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_CARD_DT like '@%';

   SELECT
       ''
      ,CAST('ENABLED_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ENABLED_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('ENABLED_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ENABLED_DT like '@%';

   SELECT
       ''
      ,CAST('SAME_CARD_NO_CHG_CARD_APP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SAME_CARD_NO_CHG_CARD_APP_FLAG like '@%';

   SELECT
       ''
      ,CAST('SAME_CARD_NO_CHG_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SAME_CARD_NO_CHG_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CHG_CARD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CHG_CARD_DT like '@%';

   SELECT
       ''
      ,CAST('PWD_ENABLED_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_ENABLED_FLAG like '@%';

   SELECT
       ''
      ,CAST('REPLOS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_FLAG like '@%';

   SELECT
       ''
      ,CAST('CARD_PWD_REPLOS_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_PWD_REPLOS_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_REPLOS_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_REPLOS_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_MATU_YM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_MATU_YM like '@%';

   SELECT
       ''
      ,CAST('NOT_CARD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOT_CARD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('NOT_CARD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOT_CARD_DT like '@%';

   SELECT
       ''
      ,CAST('RECV_CARD_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_CARD_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('CLOSE_CARD_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CLOSE_CARD_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_CARD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_CARD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_CARD_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_CARD_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_CARD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_CARD_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CUST_FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('B_SRC_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MICRO_ACCT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MICRO_ACCT_BAL like '@%';

   SELECT
       ''
      ,CAST('COMPLT_ACCT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMPLT_ACCT_BAL like '@%';

   SELECT
       ''
      ,CAST('ECASH_ACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DEBIT_CARD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ECASH_ACCT_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */