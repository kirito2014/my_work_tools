-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人账户对账服务签约信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF
--     表中文名：个人账户对账服务签约信息聚合
--     创建日期：2024-09-20 00:00:00
--     主键字段：CUST_NO, MASTER_CARD_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：叶禹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-09-20 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CUST_NO, MASTER_CARD_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CUST_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(MASTER_CARD_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('MASTER_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MASTER_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('ISSUE_DRAW_CARD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_DRAW_CARD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('LAST_SIGN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_SIGN_DT like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_SERV_SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_SERV_SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_BOOK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_BOOK_NO like '@%';

   SELECT
       ''
      ,CAST('ACCTN_DTL_TBNM_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_DTL_TBNM_NAME like '@%';

   SELECT
       ''
      ,CAST('STAT_DT_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_DT_PERIOD like '@%';

   SELECT
       ''
      ,CAST('AGAIN_STAT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGAIN_STAT_FLAG like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DTL_ORIENT_ELMNT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DTL_ORIENT_ELMNT_DESC like '@%';

   SELECT
       ''
      ,CAST('PRE_TM_UN_PRINT_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_TM_UN_PRINT_CNT like '@%';

   SELECT
       ''
      ,CAST('PRE_PRINT_END_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_PRINT_END_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('PRE_END_ORIG_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_END_ORIG_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PRE_END_SUB_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_END_SUB_SER_NO like '@%';

   SELECT
       ''
      ,CAST('NEXT_PRINT_ROWS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEXT_PRINT_ROWS like '@%';

   SELECT
       ''
      ,CAST('PRINT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINT_DT like '@%';

   SELECT
       ''
      ,CAST('PRINT_PAG_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINT_PAG_CNT like '@%';

   SELECT
       ''
      ,CAST('PRINT_END_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINT_END_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('PRINT_END_ORIG_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINT_END_ORIG_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PRINT_END_SUB_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINT_END_SUB_SER_NO like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('SETUP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_DEPT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DEPT_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DEPT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DEPT_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_SINGLE_CHECK_ENTRY_SERV_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */