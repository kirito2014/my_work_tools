-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-丰收购商品订单信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF
--     表中文名：丰收购商品订单信息聚合
--     创建日期：2024-03-15 00:00:00
--     主键字段：ORDER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-15 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ORDER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ORDER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NO like '@%';

   SELECT
       ''
      ,CAST('REAL_NAME_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REAL_NAME_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('REAL_NAME_IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REAL_NAME_IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ANONY_BUY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ANONY_BUY_FLAG like '@%';

   SELECT
       ''
      ,CAST('UNPY_RETURN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_RETURN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORDER_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORDER_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORDER_PAY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_PAY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORDER_ORIG_PRC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_ORIG_PRC like '@%';

   SELECT
       ''
      ,CAST('ORDER_PRC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_PRC like '@%';

   SELECT
       ''
      ,CAST('CONTA_TFEE_ORDER_TOTAL_PRC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONTA_TFEE_ORDER_TOTAL_PRC like '@%';

   SELECT
       ''
      ,CAST('ORDER_PREFR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_PREFR_AMT like '@%';

   SELECT
       ''
      ,CAST('ORDER_MT_SUB_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_MT_SUB_AMT like '@%';

   SELECT
       ''
      ,CAST('GOOD_HVST_COPN_DEDUCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GOOD_HVST_COPN_DEDUCT_AMT like '@%';

   SELECT
       ''
      ,CAST('SHOP_COPN_DEDUCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_COPN_DEDUCT_AMT like '@%';

   SELECT
       ''
      ,CAST('ACTL_PAY_PRC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_PAY_PRC like '@%';

   SELECT
       ''
      ,CAST('ORDER_ORDER_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_ORDER_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORDER_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORDER_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORDER_PAY_EXP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_PAY_EXP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORDER_CANCEL_RSN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_CANCEL_RSN_ILUS like '@%';

   SELECT
       ''
      ,CAST('ORDER_USER_LEAVE_MSG_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_USER_LEAVE_MSG_DESC like '@%';

   SELECT
       ''
      ,CAST('PLACE_ORDER_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PLACE_ORDER_REM like '@%';

   SELECT
       ''
      ,CAST('ORDER_CHNL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_CHNL_DESC like '@%';

   SELECT
       ''
      ,CAST('SPLIT_SGODS_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPLIT_SGODS_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('DEL_ORDER_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEL_ORDER_FLAG like '@%';

   SELECT
       ''
      ,CAST('POINT_ORDER_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_ORDER_FLAG like '@%';

   SELECT
       ''
      ,CAST('POINT_BLG_DCC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_BLG_DCC_NO like '@%';

   SELECT
       ''
      ,CAST('ORDER_DEDUCT_POINT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_DEDUCT_POINT like '@%';

   SELECT
       ''
      ,CAST('POINT_DEDUCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_DEDUCT_AMT like '@%';

   SELECT
       ''
      ,CAST('POINT_DEDUCT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POINT_DEDUCT_RATE like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACT_NO like '@%';

   SELECT
       ''
      ,CAST('BOOKG_GRP_ACT_GRP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BOOKG_GRP_ACT_GRP_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_ACT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_ACT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INSTMT_MERCHD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTMT_MERCHD_NO like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_TMS like '@%';

   SELECT
       ''
      ,CAST('INSTMT_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTMT_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('INSTMT_SERV_CHARGE_RATE_DISCNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTMT_SERV_CHARGE_RATE_DISCNT like '@%';

   SELECT
       ''
      ,CAST('INSTMT_COMM_FEE_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTMT_COMM_FEE_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('INSTMT_COMM_FEE_EACH_TERM_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTMT_COMM_FEE_EACH_TERM_AMT like '@%';

   SELECT
       ''
      ,CAST('EACH_TERM_EREPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACH_TERM_EREPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('RECIPIENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECIPIENT_NAME like '@%';

   SELECT
       ''
      ,CAST('RECIPIENT_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECIPIENT_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('RECIPIENT_POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECIPIENT_POST_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_GOOD_ADDR_LOCAL_PROV_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_GOOD_ADDR_LOCAL_PROV_NAME like '@%';

   SELECT
       ''
      ,CAST('RGA_LOCAL_MNCP_LVL_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGA_LOCAL_MNCP_LVL_NAME like '@%';

   SELECT
       ''
      ,CAST('RGA_AERA_COUNTY_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGA_AERA_COUNTY_NAME like '@%';

   SELECT
       ''
      ,CAST('RECIPIENT_DWLG_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECIPIENT_DWLG_ADDR like '@%';

   SELECT
       ''
      ,CAST('SENDOUT_GOODS_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SENDOUT_GOODS_DT like '@%';

   SELECT
       ''
      ,CAST('SENDOUT_GOODS_CARGO_CORP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SENDOUT_GOODS_CARGO_CORP_NAME like '@%';

   SELECT
       ''
      ,CAST('SENDOUT_GOODS_FR_TRANSPORT_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SENDOUT_GOODS_FR_TRANSPORT_FEE like '@%';

   SELECT
       ''
      ,CAST('SENDOUT_GOODS_CARGO_BIL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SENDOUT_GOODS_CARGO_BIL_NO like '@%';

   SELECT
       ''
      ,CAST('EXPR_DLVY_PRINT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPR_DLVY_PRINT_FLAG like '@%';

   SELECT
       ''
      ,CAST('FROM_DRAW_BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FROM_DRAW_BNKOUTLS_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FROM_DRAW_BNKOUTLS_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FROM_DRAW_BNKOUTLS_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('FROM_DRAW_BNKOUTLS_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FROM_DRAW_BNKOUTLS_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('BDF_OPEN_TM_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BDF_OPEN_TM_DESC like '@%';

   SELECT
       ''
      ,CAST('FROM_DRAW_BNKOUTLS_SMS_VERI_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FROM_DRAW_BNKOUTLS_SMS_VERI_CD like '@%';

   SELECT
       ''
      ,CAST('MKTING_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('BDF_WRTOFF_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BDF_WRTOFF_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('BDF_WRTOFF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BDF_WRTOFF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('BDF_WRTOFF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BDF_WRTOFF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_GOOD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_GOOD_DT like '@%';

   SELECT
       ''
      ,CAST('USER_ESTIM_CONT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ESTIM_CONT_DESC like '@%';

   SELECT
       ''
      ,CAST('USER_COMNT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_COMNT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SERV_QLTY_SCORE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_QLTY_SCORE like '@%';

   SELECT
       ''
      ,CAST('ISSUE_SPEED_SCORE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_SPEED_SCORE like '@%';

   SELECT
       ''
      ,CAST('LGST_SPEED_SCORE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LGST_SPEED_SCORE like '@%';

   SELECT
       ''
      ,CAST('USER_COMNT_CHNL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_COMNT_CHNL_DESC like '@%';

   SELECT
       ''
      ,CAST('TAXER_IDT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAXER_IDT like '@%';

   SELECT
       ''
      ,CAST('INV_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INV_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INVOICE_HEAD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVOICE_HEAD like '@%';

   SELECT
       ''
      ,CAST('INV_CONT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHD_ORDER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INV_CONT_DESC like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */