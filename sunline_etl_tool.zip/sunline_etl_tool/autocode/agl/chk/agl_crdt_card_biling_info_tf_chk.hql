-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡账单信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_BILING_INFO_TF
--     表中文名：信用卡账单信息聚合
--     创建日期：2024-06-06 00:00:00
--     主键字段：CRDT_CARD_ACCT_NO, BIL_MONTH
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-06-06 00:00:00 魏丹丹 新增
--         2024-09-23 00:00:00 魏丹丹 整表字段修改，增加6字段



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CRDT_CARD_ACCT_NO, BIL_MONTH) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CRDT_CARD_ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BIL_MONTH AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CRDT_CARD_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('NEXT_BIL_PROD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEXT_BIL_PROD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('OVDUE_TURN_AROUND_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_TURN_AROUND_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT like '@%';

   SELECT
       ''
      ,CAST('CRDT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_LMT like '@%';

   SELECT
       ''
      ,CAST('BILING_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BILING_DT like '@%';

   SELECT
       ''
      ,CAST('BIL_MONTH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIL_MONTH like '@%';

   SELECT
       ''
      ,CAST('AVAILBL_POINT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVAILBL_POINT_BAL like '@%';

   SELECT
       ''
      ,CAST('ADV_BRW_CASH_RATIO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_BRW_CASH_RATIO like '@%';

   SELECT
       ''
      ,CAST('CURR_INTACR_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_INTACR_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('INTACR_TAX_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_TAX_RATE like '@%';

   SELECT
       ''
      ,CAST('FINAL_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_BAL like '@%';

   SELECT
       ''
      ,CAST('FINAL_BAL_SYMBOL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_BAL_SYMBOL like '@%';

   SELECT
       ''
      ,CAST('NON_INT_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NON_INT_PRIN like '@%';

   SELECT
       ''
      ,CAST('INTACR_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_PRIN like '@%';

   SELECT
       ''
      ,CAST('INTACR_PRIN_SYMBOL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_PRIN_SYMBOL like '@%';

   SELECT
       ''
      ,CAST('UN_CACL_COL_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_CACL_COL_INT like '@%';

   SELECT
       ''
      ,CAST('TH_MONTH_INT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TH_MONTH_INT_AMT like '@%';

   SELECT
       ''
      ,CAST('ADV_BRW_CASH_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_BRW_CASH_INT like '@%';

   SELECT
       ''
      ,CAST('ACRU_CINT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACRU_CINT like '@%';

   SELECT
       ''
      ,CAST('CINT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CINT_BAL like '@%';

   SELECT
       ''
      ,CAST('RECVBL_CINT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECVBL_CINT like '@%';

   SELECT
       ''
      ,CAST('CINT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CINT_INT like '@%';

   SELECT
       ''
      ,CAST('BIL_MONTH_INT_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIL_MONTH_INT_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('INT_SUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INT_SUM like '@%';

   SELECT
       ''
      ,CAST('CPR_INSTALMT_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_INSTALMT_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('ANLFEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ANLFEE like '@%';

   SELECT
       ''
      ,CAST('CPR_ADV_BRW_CASH_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_ADV_BRW_CASH_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('REPLOS_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_FEE like '@%';

   SELECT
       ''
      ,CAST('OTHER_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OTHER_FEE like '@%';

   SELECT
       ''
      ,CAST('CPR_LATE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_LATE_FEE like '@%';

   SELECT
       ''
      ,CAST('CPR_REPLOS_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_REPLOS_FEE like '@%';

   SELECT
       ''
      ,CAST('CPR_ANLFEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_ANLFEE like '@%';

   SELECT
       ''
      ,CAST('CPR_OVER_LMT_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_OVER_LMT_FEE like '@%';

   SELECT
       ''
      ,CAST('CPR_REPAY_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_REPAY_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('CPR_OTHER_INCOME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPR_OTHER_INCOME like '@%';

   SELECT
       ''
      ,CAST('FEE_SUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FEE_SUM like '@%';

   SELECT
       ''
      ,CAST('FEE_AND_TAX_SUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FEE_AND_TAX_SUM like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_REPAY_AMT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_REPAY_AMT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('OVER_LMT_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVER_LMT_FEE like '@%';

   SELECT
       ''
      ,CAST('LOW_PAYBL_UNPAID_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOW_PAYBL_UNPAID_AMT like '@%';

   SELECT
       ''
      ,CAST('LOW_PAYBL_REPAY_TERM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOW_PAYBL_REPAY_TERM like '@%';

   SELECT
       ''
      ,CAST('OVER_PAYMENT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVER_PAYMENT_AMT like '@%';

   SELECT
       ''
      ,CAST('STOP_RECV_CINT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_RECV_CINT like '@%';

   SELECT
       ''
      ,CAST('STOP_RECV_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_RECV_INT like '@%';

   SELECT
       ''
      ,CAST('STOP_RECV_LATE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_RECV_LATE_FEE like '@%';

   SELECT
       ''
      ,CAST('STOP_RECV_UN_LATE_FEE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_RECV_UN_LATE_FEE_FEE like '@%';

   SELECT
       ''
      ,CAST('STL_PERIOD_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_PERIOD_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('STL_PERIOD_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_PERIOD_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('STL_PERIOD_EFFECT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_PERIOD_EFFECT_DT like '@%';

   SELECT
       ''
      ,CAST('LATST_BILING_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LATST_BILING_DT like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_1 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_2 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_3 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_4' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_4 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_5' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_5 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_6' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_BILING_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_6 like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */