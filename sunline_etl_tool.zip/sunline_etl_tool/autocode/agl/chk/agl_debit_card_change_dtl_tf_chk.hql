-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人借记卡变更明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_DEBIT_CARD_CHANGE_DTL_TF
--     表中文名：个人借记卡变更明细聚合
--     创建日期：2023-12-14 00:00:00
--     主键字段：CARD_NO, CARD_CHG_TM_STAMP, CARD_CHG_EVENT_NO, CARD_CHG_TYPE_CD, CURR_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军/魏丹丹
--     时间粒度：日
--     保留周期：13M
--     描述信息：None
--     更新记录：
--         2023-12-14 00:00:00 游崔龙 新增
--         2023-01-11 00:00:00 游崔龙 对标
--         2024-02-22 00:00:00 王穆军/魏丹丹 修改问题
--         2024-07-23 00:00:00 王穆军/魏丹丹 修改同步设计文档
--         2024-08-05 00:00:00 王穆军/魏丹丹 修改第7-8组字段映射 拼接000,补充缺失码值映射
--         2024-08-19 00:00:00 王穆军/魏丹丹 修改生产验证反馈问题
--         2024-09-24 00:00:00 王穆军/魏丹丹 新增字段 联合主键



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CARD_NO, CARD_CHG_TM_STAMP, CARD_CHG_EVENT_NO, CARD_CHG_TYPE_CD, CURR_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CARD_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CARD_CHG_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(CARD_CHG_EVENT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CARD_CHG_TYPE_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_EVENT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_EVENT_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_TYPE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_TYPE_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_PROC_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_PROC_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_PROC_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_PROC_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('CO_SIGN_IDTFY_CERT_CORP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CO_SIGN_IDTFY_CERT_CORP_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_PROPTY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_PROPTY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_AGT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_AGT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CARD_CSICC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CARD_CSICC_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CARD_PROPTY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CARD_PROPTY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_CARD_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CARD_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_CARD_AGT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CARD_AGT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_RSN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_RSN_DESC like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_EVENT_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_EVENT_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_CHG_ACCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CHG_ACCT_AMT like '@%';

   SELECT
       ''
      ,CAST('DRAW_INT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_INT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('MAX_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MAX_LMT like '@%';

   SELECT
       ''
      ,CAST('ACCT_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_INCLD_TAX_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_INCLD_TAX_INT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_INT_TAX' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_INT_TAX like '@%';

   SELECT
       ''
      ,CAST('REPLOS_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('MIN_CANCLR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MIN_CANCLR_DT like '@%';

   SELECT
       ''
      ,CAST('SCNCC_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SCNCC_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('SCNCC_APP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SCNCC_APP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SCNCC_CERT_VALID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SCNCC_CERT_VALID like '@%';

   SELECT
       ''
      ,CAST('INFO_CHG_ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_CHG_ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('INFO_CHG_SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_CHG_SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('INFO_CHG_ENABLED_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_CHG_ENABLED_DT like '@%';

   SELECT
       ''
      ,CAST('INFO_CHG_NEW_CONTENT_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_CHG_NEW_CONTENT_ILUS like '@%';

   SELECT
       ''
      ,CAST('INFO_CHG_ORIG_CONTENT_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INFO_CHG_ORIG_CONTENT_ILUS like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_DEBIT_CARD_CHANGE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */