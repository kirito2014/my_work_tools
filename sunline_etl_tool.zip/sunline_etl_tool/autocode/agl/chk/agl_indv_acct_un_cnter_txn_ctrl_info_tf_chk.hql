-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-个人账户非柜面交易控制信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF
--     表中文名：个人账户非柜面交易控制信息聚合
--     创建日期：2024-08-01 00:00:00
--     主键字段：无主键
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-01 00:00:00 陈艺丹 创建
--         2024-09-14 00:00:00 陈艺丹 修改表名：”个人账户非柜面交易控制明细聚合“改为”个人账户非柜面交易控制信息聚合“



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(无主键) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(无主键 AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('MAIN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUB_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('EACCT_CLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACCT_CLS_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CTRL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('EACCT_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACCT_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CTRL_RSN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_RSN_DESC like '@%';

   SELECT
       ''
      ,CAST('CTRL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CTRL_AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CTRL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_DT like '@%';

   SELECT
       ''
      ,CAST('CTRL_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CTRL_LIFTED_RSN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRL_LIFTED_RSN_DESC like '@%';

   SELECT
       ''
      ,CAST('LIFTED_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_DT like '@%';

   SELECT
       ''
      ,CAST('LIFTED_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_ACCT_UN_CNTER_TXN_CTRL_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */