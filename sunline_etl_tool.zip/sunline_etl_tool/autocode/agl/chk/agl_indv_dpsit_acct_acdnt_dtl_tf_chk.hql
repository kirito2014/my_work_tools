-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人存款账户事故明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF
--     表中文名：个人存款账户事故明细聚合
--     创建日期：2024-05-18 00:00:00
--     主键字段：NO, MED_NO, OPER_DT
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：翟向阳
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-17 00:00:00 翟向阳 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(NO, MED_NO, OPER_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(MED_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(OPER_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('OPER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_DT like '@%';

   SELECT
       ''
      ,CAST('MED_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MED_NO like '@%';

   SELECT
       ''
      ,CAST('CNTPTY_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CNTPTY_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('DATA_SRC_MODULE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND DATA_SRC_MODULE_CD like '@%';

   SELECT
       ''
      ,CAST('RIGHTS_ORG_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RIGHTS_ORG_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RIGHTS_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RIGHTS_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('APP_NOTICE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_NOTICE_NO like '@%';

   SELECT
       ''
      ,CAST('ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_NO like '@%';

   SELECT
       ''
      ,CAST('HANDLE_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND HANDLE_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('APPRV_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND APPRV_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('CHKR_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CHKR_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('OPERR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OPERR_NAME like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('RELA_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RELA_NO like '@%';

   SELECT
       ''
      ,CAST('MNY_PAID_STK_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MNY_PAID_STK_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('ALL_IN_ONE_PSBOOK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ALL_IN_ONE_PSBOOK_NO like '@%';

   SELECT
       ''
      ,CAST('ACDNT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACDNT_AMT like '@%';

   SELECT
       ''
      ,CAST('ACDNT_RSN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACDNT_RSN like '@%';

   SELECT
       ''
      ,CAST('MEASURE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND MEASURE_CD like '@%';

   SELECT
       ''
      ,CAST('LIFTED_NOTICE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_NOTICE_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_OPERR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_OPERR_NAME like '@%';

   SELECT
       ''
      ,CAST('LIFTED_OPERR_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_OPERR_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('LIFTED_OPERR_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_OPERR_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('LIFTED_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_DT like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('ACDNT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACDNT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('RV_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND RV_FLAG like '@%';

   SELECT
       ''
      ,CAST('ACDNT_CAP_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND ACDNT_CAP_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('INPUT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SITU_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SITU_DESC like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_ACCT_ACDNT_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_DT like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */