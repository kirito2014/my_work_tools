-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-市民卡签约信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CITIZEN_CARD_SIGN_INFO_TF
--     表中文名：市民卡签约信息聚合
--     创建日期：2024-08-20 00:00:00
--     主键字段：PLAT_DT, BIZ_UNIT_NO, USER_NO, BANK_CARD_NO, BATCH_SEQ_NO, BATCH_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：陈艺丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-08-20 00:00:00 陈艺丹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PLAT_DT, BIZ_UNIT_NO, USER_NO, BANK_CARD_NO, BATCH_SEQ_NO, BATCH_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PLAT_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(BIZ_UNIT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(USER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BANK_CARD_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BATCH_SEQ_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BATCH_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('FRONT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRONT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CONT_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_DISCNT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_DISCNT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_TYPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_TYPE like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('BANK_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BANK_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_FUND_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_FUND_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('FUND_COL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUND_COL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('HST_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HST_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('USER_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('USER_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('GENDER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GENDER_CD like '@%';

   SELECT
       ''
      ,CAST('COMMUNIC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMMUNIC_ADDR like '@%';

   SELECT
       ''
      ,CAST('CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('SINGLE_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SINGLE_LMT like '@%';

   SELECT
       ''
      ,CAST('ENABLED_LOAD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ENABLED_LOAD_FLAG like '@%';

   SELECT
       ''
      ,CAST('UNLD_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNLD_LMT like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_SEQ_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_SEQ_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ORDER_DTL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORDER_DTL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ISSUE_LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_DT like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POST_CD like '@%';

   SELECT
       ''
      ,CAST('BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('BATCH_SEQ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BATCH_SEQ_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MSG_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('PRTCPT_INSURE_RGN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRTCPT_INSURE_RGN_NAME like '@%';

   SELECT
       ''
      ,CAST('APP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_NO like '@%';

   SELECT
       ''
      ,CAST('MAKE_CARD_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAKE_CARD_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('LOC_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOC_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('ETC_DATA_ENCASE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_DATA_ENCASE_DT like '@%';

   SELECT
       ''
      ,CAST('OUT_CUST_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OUT_CUST_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('BIRTH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIRTH_DT like '@%';

   SELECT
       ''
      ,CAST('LIC_AUTH_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_AUTH_NAME like '@%';

   SELECT
       ''
      ,CAST('DOC_VALID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_VALID like '@%';

   SELECT
       ''
      ,CAST('NATION_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NATION_DESC like '@%';

   SELECT
       ''
      ,CAST('NATION_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NATION_CD like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_CORP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_CORP_NO like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_CORP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_CORP_NAME like '@%';

   SELECT
       ''
      ,CAST('COMM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_CD like '@%';

   SELECT
       ''
      ,CAST('COMM_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_NAME like '@%';

   SELECT
       ''
      ,CAST('INQR_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INQR_SER_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_SUCC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_SUCC_FLAG like '@%';

   SELECT
       ''
      ,CAST('ERR_RSN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ERR_RSN_ILUS like '@%';

   SELECT
       ''
      ,CAST('RECORD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECORD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LOGIN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOGIN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HOST_SER_NO like '@%';

   SELECT
       ''
      ,CAST('HOST_RTN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HOST_RTN_CD like '@%';

   SELECT
       ''
      ,CAST('HOST_RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HOST_RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('AL_PRINT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CITIZEN_CARD_SIGN_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_PRINT_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */