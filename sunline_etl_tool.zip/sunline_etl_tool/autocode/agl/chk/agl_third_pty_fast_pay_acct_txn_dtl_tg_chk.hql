-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVP-第三方快捷支付交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG
--     表中文名：第三方快捷支付交易明细聚合
--     创建日期：2023-12-19 00:00:00
--     主键字段：MSG_NO
--     归属层次：AGL-EVP
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-28 00:00:00 游崔龙 新增
--         2024-01-19 00:00:00 游崔龙 对标
--         2024-08-03 00:00:00 魏丹丹 证件号码，客户证件类型代码，数据来源更改，主键修改
--         2024-08-24 00:00:00 魏丹丹 修改取数逻辑，增加快捷支付交易发起渠道代码、快捷支付渠道代码码值映射
--         2024-09-04 00:00:00 魏丹丹 加表，修改PAYER_ACCT_NO取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(MSG_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(MSG_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CUST_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CUST_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OBANK_EMPLY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND OBANK_EMPLY_FLAG like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_PAY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_PAY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_AFLT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CARD_AFLT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_CLEAR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_CLEAR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_USER_ID like '@%';

   SELECT
       ''
      ,CAST('PAYER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_TXN_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_TXN_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('PAYER_TXN_UNION_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_TXN_UNION_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_MEM_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_MEM_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('PAYER_MEM_UNION_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_MEM_UNION_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_OPEN_ACCT_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_OPEN_ACCT_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('PAYER_OPEN_ACCT_UBANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_OPEN_ACCT_UBANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NO_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NO_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_CLEAR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_CLEAR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_USER_ID like '@%';

   SELECT
       ''
      ,CAST('PAYEE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_TXN_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_TXN_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('PAYEE_TXN_UNION_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_TXN_UNION_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PAYEE_MEM_UNION_BANK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_MEM_UNION_BANK like '@%';

   SELECT
       ''
      ,CAST('PAYEE_MEM_UNION_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_MEM_UNION_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_OPBANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_OPBANK_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORDER_TXN_PLAT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORDER_TXN_PLAT_NAME like '@%';

   SELECT
       ''
      ,CAST('ORDER_PAYEE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORDER_PAYEE_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_SIGN_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CONT_SIGN_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_SUCC_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_SUCC_AMT like '@%';

   SELECT
       ''
      ,CAST('FAST_PAY_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FAST_PAY_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DTL_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_DTL_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('TXN_ERR_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_ERR_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('HOST_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND HOST_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FAST_PAY_TXN_INIT_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FAST_PAY_TXN_INIT_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('RTN_GOODS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RTN_GOODS_FLAG like '@%';

   SELECT
       ''
      ,CAST('REFUND_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND REFUND_AMT like '@%';

   SELECT
       ''
      ,CAST('RESP_STATUS_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RESP_STATUS_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('FAST_PAY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FAST_PAY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('FAST_PAY_TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FAST_PAY_TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ERR_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('BELONG_CORE_PLAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BELONG_CORE_PLAT_CD like '@%';

   SELECT
       ''
      ,CAST('ASSIGN_DEBIT_PASS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ASSIGN_DEBIT_PASS_CD like '@%';

   SELECT
       ''
      ,CAST('ASSIGN_CRDT_PASS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ASSIGN_CRDT_PASS_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_FAST_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_FAST_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_FAST_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_FAST_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('RECORD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECORD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ACCTN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ACCTN_FLAG like '@%';

   SELECT
       ''
      ,CAST('RSPS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RSPS_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_CONT_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_CONT_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_MSG_TXN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MSG_TXN_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_ROW_BRCH_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_ROW_BRCH_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_RECV_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_RECV_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_RECV_BANK_BRCH_BANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_RECV_BANK_BRCH_BANK_NO like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_MSG_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_MSG_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_RECV_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_RECV_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MSG_SEND_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MSG_SEND_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RURAL_CRDT_MSG_TYPE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RURAL_CRDT_MSG_TYPE_NO like '@%';

   SELECT
       ''
      ,CAST('EXT_RESP_MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXT_RESP_MSG_NO like '@%';

   SELECT
       ''
      ,CAST('PASS_MSG_SEND_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PASS_MSG_SEND_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('END_TO_END_IDE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND END_TO_END_IDE_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND AUTH_CD like '@%';

   SELECT
       ''
      ,CAST('AUTH_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND AUTH_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('AUTH_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND AUTH_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PLAT_CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_THIRD_PTY_FAST_PAY_ACCT_TXN_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */