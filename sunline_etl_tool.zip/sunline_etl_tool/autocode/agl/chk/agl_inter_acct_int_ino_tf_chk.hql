-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-内部账户利息信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INTER_ACCT_INT_INO_TF
--     表中文名：内部账户利息信息聚合
--     创建日期：2024-09-06 00:00:00
--     主键字段：INTER_ACCT_NO, VAL_DT, SEG_BEGIN_DT
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：叶禹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-09-06 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(INTER_ACCT_NO, VAL_DT, SEG_BEGIN_DT) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(INTER_ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(VAL_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(SEG_BEGIN_DT AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('INTER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('INTER_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('LOW_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOW_LMT like '@%';

   SELECT
       ''
      ,CAST('RCD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND RCD_FLAG like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('INTACR_DDL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_DDL like '@%';

   SELECT
       ''
      ,CAST('SEG_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('SEG_DDL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_DDL like '@%';

   SELECT
       ''
      ,CAST('BAL_TOTAL_ACCUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_TOTAL_ACCUM like '@%';

   SELECT
       ''
      ,CAST('BAL_TOTAL_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_TOTAL_INT like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_1 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_1 like '@%';

   SELECT
       ''
      ,CAST('YEAR_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND YEAR_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_2 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_2 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_2 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_3 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_3 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_3 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_4' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_4 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_4' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_4 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_4' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_4 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_5' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_5 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_5' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_5 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_5' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_5 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_6' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_6 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_6' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_6 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_6' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_6 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_7' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_7 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_7' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_7 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_7' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_7 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_8' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_8 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_8' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_8 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_8' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_8 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_9' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_9 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_9' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_9 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_9' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_9 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_10' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_10 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_10' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_10 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_10' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_10 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_11' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_11 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_11' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_11 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_11' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_11 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_12' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_12 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_12' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_12 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_12' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_12 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_13' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_13 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_13' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_13 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_13' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_13 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_14' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_14 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_14' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_14 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_14' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_14 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_15' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_15 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_15' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_15 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_15' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_15 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_16' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_16 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_16' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_16 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_16' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_16 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_17' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_17 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_17' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_17 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_17' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_17 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_18' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_18 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_18' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_18 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_18' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_18 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_19' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_19 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_19' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_19 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_19' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_19 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_ACCUM_20' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_ACCUM_20 like '@%';

   SELECT
       ''
      ,CAST('BAL_SEG_INT_20' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND BAL_SEG_INT_20 like '@%';

   SELECT
       ''
      ,CAST('SEG_ANL_INT_RATE_20' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INTER_ACCT_INT_INO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEG_ANL_INT_RATE_20 like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */