-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人存款汇集账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF
--     表中文名：个人存款汇集账户信息聚合
--     创建日期：2024-04-15 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-15 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ACCT_NO, CURR_CD, CASH_RMT_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CASH_RMT_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('EXCH_GATHER_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCH_GATHER_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('EXCH_GATHER_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCH_GATHER_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('EXCH_GATHER_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCH_GATHER_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('EXCH_GATHER_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCH_GATHER_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('VOCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VOCH_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('REPLOS_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REPLOS_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('FRZ_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('PART_STOP_PAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PART_STOP_PAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('PLEDGE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PLEDGE_FLAG like '@%';

   SELECT
       ''
      ,CAST('CRDT_PROOF_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_PROOF_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_WITHDR_CASH_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_WITHDR_CASH_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DRAW_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DRAW_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DPSIT_IN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DPSIT_IN_FLAG like '@%';

   SELECT
       ''
      ,CAST('DRAW_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('UNIVERSAL_WITHDR_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIVERSAL_WITHDR_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('UNIVERSAL_SAVING_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIVERSAL_SAVING_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('PSBOOK_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PSBOOK_FLAG like '@%';

   SELECT
       ''
      ,CAST('SMS_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMS_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('TEL_BANK_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEL_BANK_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('WBANK_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WBANK_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('CALLCENTER_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CALLCENTER_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('ATM_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ATM_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('POS_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POS_SERV_PROVI_FLAG like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL_CONVT_RMB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL_CONVT_RMB like '@%';

   SELECT
       ''
      ,CAST('YESTD_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YESTD_BAL like '@%';

   SELECT
       ''
      ,CAST('CURR_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_BAL like '@%';

   SELECT
       ''
      ,CAST('FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DPSIT_EXCH_GATHER_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */