-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-生活缴费签约协议信息聚合03
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF
--     表中文名：生活缴费签约协议信息聚合03
--     创建日期：2024-04-15 00:00:00
--     主键字段：AGT_NO, THIRD_PTY_USER_NO, BIZ_UNIT_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改中间业务库名，增加95组
--         2024-09-10 00:00:00 魏丹丹 新增字段：摘要代码，修改客户内码/签约账户开户机构编号 的取数逻辑，增加1组
--         2024-10-17 00:00:00 魏丹丹 拆分生活缴费签约协议信息聚合03 中第4-10组组数据



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(AGT_NO, THIRD_PTY_USER_NO, BIZ_UNIT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(AGT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(THIRD_PTY_USER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(BIZ_UNIT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SIGN_ISNO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ISNO like '@%';

   SELECT
       ''
      ,CAST('AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_CENTER_AGT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_CENTER_AGT_NO like '@%';

   SELECT
       ''
      ,CAST('AGT_EFFECT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_EFFECT_DT like '@%';

   SELECT
       ''
      ,CAST('AGT_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('PLAT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DT like '@%';

   SELECT
       ''
      ,CAST('PAY_START_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_START_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_CATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_CATE_NO like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_CATE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_CATE_NAME like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_MDL_CATOGR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_MDL_CATOGR_NO like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_MDL_CATOGR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_MDL_CATOGR_NAME like '@%';

   SELECT
       ''
      ,CAST('MDL_BIZ_SUB_CLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MDL_BIZ_SUB_CLS_CD like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_PROJ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_PROJ_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_PROJ_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_PROJ_NAME like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_USER_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_USER_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND POST_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_PUB_PRIV_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_PUB_PRIV_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARD_DISCNT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_DISCNT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_MED_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_MED_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DRAW_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND DRAW_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_PWD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_PWD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_OPBANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_OPBANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('SINGLE_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SINGLE_LMT like '@%';

   SELECT
       ''
      ,CAST('DAILY_ACCUM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND DAILY_ACCUM_LMT like '@%';

   SELECT
       ''
      ,CAST('MONTHLY_ACCUM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MONTHLY_ACCUM_LMT like '@%';

   SELECT
       ''
      ,CAST('YEAR_CUM_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND YEAR_CUM_LMT like '@%';

   SELECT
       ''
      ,CAST('SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('MGMT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND MGMT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_AGT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_AGT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CONT_CENTER_AGT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_CENTER_AGT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('LIFE_PAY_SIGN_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFE_PAY_SIGN_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('SUMMARY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SUMMARY_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_RESLT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_RESLT_DESC like '@%';

   SELECT
       ''
      ,CAST('REC_LOCK_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_LOCK_FLAG like '@%';

   SELECT
       ''
      ,CAST('VER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_LIFE_PAY_SIGN_AGT_INFO_03_TF 
 WHERE PT_DT = '${process_date}'
   AND VER_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */