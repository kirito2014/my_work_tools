-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人特色活期存款签约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF
--     表中文名：个人特色活期存款签约协议信息聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：ACCT_NO, CURR_CD, CASH_RMT_CD, PROD_NO, SIGN_STATUS_CD, SIGN_TMS
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ACCT_NO, CURR_CD, CASH_RMT_CD, PROD_NO, SIGN_STATUS_CD, SIGN_TMS) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CASH_RMT_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(PROD_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SIGN_STATUS_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(SIGN_TMS AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TMS like '@%';

   SELECT
       ''
      ,CAST('SIGN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_BNKOUTLS_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_RETND_MIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_RETND_MIN_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_LOW_RETND_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_LOW_RETND_AMT like '@%';

   SELECT
       ''
      ,CAST('NOTICE_DPSIT_MIN_DPSIT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_DPSIT_MIN_DPSIT_AMT like '@%';

   SELECT
       ''
      ,CAST('PROD_INT_RATE_MAX_LMT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_INT_RATE_MAX_LMT_FLAG like '@%';

   SELECT
       ''
      ,CAST('MAX_PROD_INT_RATE_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAX_PROD_INT_RATE_LMT like '@%';

   SELECT
       ''
      ,CAST('EXCESS_INT_RATE_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_INT_RATE_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('RGL_INT_RATE_DISCNT_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_INT_RATE_DISCNT_VAL like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DEFLT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DEFLT_TMS like '@%';

   SELECT
       ''
      ,CAST('VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VAL_DT like '@%';

   SELECT
       ''
      ,CAST('NEXT_PAY_INT_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEXT_PAY_INT_DAY like '@%';

   SELECT
       ''
      ,CAST('AL_PAY_INT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_PAY_INT_TMS like '@%';

   SELECT
       ''
      ,CAST('AL_POSTPN_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_POSTPN_TMS like '@%';

   SELECT
       ''
      ,CAST('AGT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_PERIOD_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_PERIOD_VAL like '@%';

   SELECT
       ''
      ,CAST('PERIOD_CORP_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PERIOD_CORP_DESC like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOC_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOC_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_DT like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_DOC_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_DOC_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_CURR_DPSIT_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */