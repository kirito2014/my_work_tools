-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡账户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_ACCT_INFO_TF
--     表中文名：信用卡账户信息聚合
--     创建日期：2024-03-06 00:00:00
--     主键字段：CRDT_CARD_ACCT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-06 00:00:00 龙耀超 创建
--         2024-10-30 00:00:00 魏丹丹 None
--         2024-11-03 00:00:00 魏丹丹 更改人民币贷记帐户来源表英文名ODS_CCRD_ACCT_SP_TF（ODS开发表特殊处理ACCT用ACCT_SP）



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CRDT_CARD_ACCT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CRDT_CARD_ACCT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CRDT_CARD_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_TYPE_CHG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_TYPE_CHG_DT like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('OD_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OD_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('ACCT_ANLFEE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_ANLFEE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ANLFEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ANLFEE like '@%';

   SELECT
       ''
      ,CAST('CARD_CRDT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CRDT_LMT like '@%';

   SELECT
       ''
      ,CAST('CINT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CINT_BAL like '@%';

   SELECT
       ''
      ,CAST('OFBS_ACCT_FEE_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OFBS_ACCT_FEE_BAL like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_UN_BIL_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_UN_BIL_BAL like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_UN_BIL_BAL_SYMBOL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_UN_BIL_BAL_SYMBOL_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_CURR_REMAIN_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_CURR_REMAIN_PRIN like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_CURR_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_CURR_BAL like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_BIL_TOTAL_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_BIL_TOTAL_BAL like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_BIL_TOTAL_BAL_SYMBOL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_BIL_TOTAL_BAL_SYMBOL_CD like '@%';

   SELECT
       ''
      ,CAST('OFBS_RECVBL_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OFBS_RECVBL_INT like '@%';

   SELECT
       ''
      ,CAST('OFBS_RECVBL_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OFBS_RECVBL_FEE like '@%';

   SELECT
       ''
      ,CAST('OVDUE_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_1 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_2 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_3 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_4' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_4 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_5' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_5 like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT_6' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT_6 like '@%';

   SELECT
       ''
      ,CAST('ACCT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BAL like '@%';

   SELECT
       ''
      ,CAST('OD_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OD_PRIN like '@%';

   SELECT
       ''
      ,CAST('REMAIN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REMAIN_LMT like '@%';

   SELECT
       ''
      ,CAST('CRDT_LINE_DEG_CHG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_LINE_DEG_CHG_DT like '@%';

   SELECT
       ''
      ,CAST('LAM_INSTMT_CRDT_LINE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAM_INSTMT_CRDT_LINE like '@%';

   SELECT
       ''
      ,CAST('TEMP_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEMP_LMT like '@%';

   SELECT
       ''
      ,CAST('TEMP_LMT_EFFECT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEMP_LMT_EFFECT_DT like '@%';

   SELECT
       ''
      ,CAST('TEMP_LMT_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEMP_LMT_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('ADV_BRW_CASH_RATIO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_BRW_CASH_RATIO like '@%';

   SELECT
       ''
      ,CAST('ADV_BRW_CASH_MAX_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_BRW_CASH_MAX_AMT like '@%';

   SELECT
       ''
      ,CAST('ADV_BRW_CASH_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_BRW_CASH_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('ADV_BRW_CASH_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ADV_BRW_CASH_AMT like '@%';

   SELECT
       ''
      ,CAST('BILING_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BILING_DT like '@%';

   SELECT
       ''
      ,CAST('BIL_ADDR_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIL_ADDR_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TAP_GNRL_CONSM_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAP_GNRL_CONSM_CNT like '@%';

   SELECT
       ''
      ,CAST('TAP_WHOLE_TXN_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAP_WHOLE_TXN_CNT like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_BIL_CONSM_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_BIL_CONSM_BAL like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_BIL_FREE_INT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_BIL_FREE_INT_BAL like '@%';

   SELECT
       ''
      ,CAST('CPERID_BILDT_REC_INT_BSMB_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPERID_BILDT_REC_INT_BSMB_CD like '@%';

   SELECT
       ''
      ,CAST('CPERID_BILDT_REC_INT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPERID_BILDT_REC_INT_BAL like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_BIL_INT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_BIL_INT_BAL like '@%';

   SELECT
       ''
      ,CAST('CPERID_BIL_ACTL_LOW_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CPERID_BIL_ACTL_LOW_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_BIL_LOW_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_BIL_LOW_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_BIL_REPAID_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_BIL_REPAID_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_LOW_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_LOW_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('UN_BIL_CONSM_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_BIL_CONSM_BAL like '@%';

   SELECT
       ''
      ,CAST('UN_BIL_NOT_REC_INT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_BIL_NOT_REC_INT_BAL like '@%';

   SELECT
       ''
      ,CAST('UN_BILDT_REC_INT_BSMB_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_BILDT_REC_INT_BSMB_CD like '@%';

   SELECT
       ''
      ,CAST('UN_BILING_DT_REC_INT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_BILING_DT_REC_INT_BAL like '@%';

   SELECT
       ''
      ,CAST('UN_BIL_INT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UN_BIL_INT_BAL like '@%';

   SELECT
       ''
      ,CAST('INST_BILED_BSMB_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INST_BILED_BSMB_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_BILED_SINGLE_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_BILED_SINGLE_BAL like '@%';

   SELECT
       ''
      ,CAST('LARGE_AMT_INSTMT_REMAIN_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LARGE_AMT_INSTMT_REMAIN_PRIN like '@%';

   SELECT
       ''
      ,CAST('LAM_INSTMT_REMAIN_TAMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAM_INSTMT_REMAIN_TAMT like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_ACRU_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_ACRU_INT like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_ACRU_CINT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_ACRU_CINT_INT like '@%';

   SELECT
       ''
      ,CAST('SM_DAY_INSTALMT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SM_DAY_INSTALMT_AMT like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_AUTH_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_AUTH_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('INST_CPERID_APPRTN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INST_CPERID_APPRTN_AMT like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_CRDT_LINE_DEG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_CRDT_LINE_DEG like '@%';

   SELECT
       ''
      ,CAST('SM_DAY_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SM_DAY_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_PERIOD_CONSM_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_PERIOD_CONSM_AMT like '@%';

   SELECT
       ''
      ,CAST('REG_INSTMT_INSTMT_PEND_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_INSTMT_INSTMT_PEND_BAL like '@%';

   SELECT
       ''
      ,CAST('LARGE_AMT_INSTALLMENT_PEND_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LARGE_AMT_INSTALLMENT_PEND_BAL like '@%';

   SELECT
       ''
      ,CAST('FUNONG_CARD_INSTMT_PEND_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNONG_CARD_INSTMT_PEND_BAL like '@%';

   SELECT
       ''
      ,CAST('OVDUE_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('CURR_OVDUE_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_OVDUE_TMS like '@%';

   SELECT
       ''
      ,CAST('LVL_FIVE_MODAL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LVL_FIVE_MODAL_CD like '@%';

   SELECT
       ''
      ,CAST('RECVBL_PENALTY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECVBL_PENALTY_AMT like '@%';

   SELECT
       ''
      ,CAST('RECV_PENALTY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_PENALTY_AMT like '@%';

   SELECT
       ''
      ,CAST('SELF_DED_REPAY_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELF_DED_REPAY_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SELF_DED_REPAY_ACCT_NO_RELA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELF_DED_REPAY_ACCT_NO_RELA_CD like '@%';

   SELECT
       ''
      ,CAST('MATU_REPAY_DEAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATU_REPAY_DEAL_DT like '@%';

   SELECT
       ''
      ,CAST('AL_FULL_AMT_REPAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_FULL_AMT_REPAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('RECNT_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('RECNT_REPAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_REPAY_DT like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_DT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_OPER_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_OPER_FLAG like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_ON_BS_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_ON_BS_INT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_OFBS_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_OFBS_INT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_OD_PRIN_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_OD_PRIN_BAL like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_OD_PRIN_FLAG_BIT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_OD_PRIN_FLAG_BIT like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_OVDUE_PRIN_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_OVDUE_PRIN_BAL like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_DULL_PRIN_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_DULL_PRIN_BAL like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_OD_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_OD_FEE like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_OVDUE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_OVDUE_FEE like '@%';

   SELECT
       ''
      ,CAST('WRTOFF_TM_DULL_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WRTOFF_TM_DULL_FEE like '@%';

   SELECT
       ''
      ,CAST('CUM_CONVERTIBLE_POINT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUM_CONVERTIBLE_POINT_FLAG like '@%';

   SELECT
       ''
      ,CAST('CUM_CONVERTIBLE_POINT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUM_CONVERTIBLE_POINT like '@%';

   SELECT
       ''
      ,CAST('RECNT_CLOSE_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_CLOSE_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('RECVBL_OD_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECVBL_OD_INT like '@%';

   SELECT
       ''
      ,CAST('ACRU_CINT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACRU_CINT_INT like '@%';

   SELECT
       ''
      ,CAST('SYN_CRDT_LINE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SYN_CRDT_LINE like '@%';

   SELECT
       ''
      ,CAST('PRMTR_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRMTR_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('PRMTR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRMTR_NAME like '@%';

   SELECT
       ''
      ,CAST('OD_RECVBL_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OD_RECVBL_FEE like '@%';

   SELECT
       ''
      ,CAST('MONTHLU_ACCUM_OD_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MONTHLU_ACCUM_OD_PRIN like '@%';

   SELECT
       ''
      ,CAST('QUAR_CUM_OD_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND QUAR_CUM_OD_PRIN like '@%';

   SELECT
       ''
      ,CAST('YEAR_CUM_OD_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND YEAR_CUM_OD_PRIN like '@%';

   SELECT
       ''
      ,CAST('SPREAD_BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_ACCT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPREAD_BNKOUTLS_ORG_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */