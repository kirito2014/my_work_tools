-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-丰收购商户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF
--     表中文名：丰收购商户信息聚合
--     创建日期：2024-03-15 00:00:00
--     主键字段：MERCHT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-15 00:00:00 龙耀超 创建
--         2024-01-01 00:00:00 魏丹丹 缺失字段补入
--         2024-11-10 00:00:00 魏丹丹 限定配送省份代码,限定配送城市代码,限定配送地区代码修改取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(MERCHT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(MERCHT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO_1 like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_TEL_NO_AL_VERI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_TEL_NO_AL_VERI_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHT_MAILBOX_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_MAILBOX_ADDR like '@%';

   SELECT
       ''
      ,CAST('MERCHT_MAILBOX_VERI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_MAILBOX_VERI_FLAG like '@%';

   SELECT
       ''
      ,CAST('LP_IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('REG_IP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_IP_ADDR like '@%';

   SELECT
       ''
      ,CAST('REG_MAC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_MAC_ADDR like '@%';

   SELECT
       ''
      ,CAST('REG_CHNL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_CHNL_DESC like '@%';

   SELECT
       ''
      ,CAST('MERCHT_AUDIT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_AUDIT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_MGR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_MGR_NO like '@%';

   SELECT
       ''
      ,CAST('AFLT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AFLT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_ROLE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_ROLE_CD like '@%';

   SELECT
       ''
      ,CAST('SUPER_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUPER_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_CHARGE_RATE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CHARGE_RATE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_CHARGE_RATE_AMT_PCT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CHARGE_RATE_AMT_PCT like '@%';

   SELECT
       ''
      ,CAST('SERV_CHARGE_RATE_COMM_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_CHARGE_RATE_COMM_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('GEN_SALES_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GEN_SALES_FLAG like '@%';

   SELECT
       ''
      ,CAST('FREE_AUDIT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FREE_AUDIT_FLAG like '@%';

   SELECT
       ''
      ,CAST('GET_GOODS_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GET_GOODS_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_REFUND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_REFUND_FLAG like '@%';

   SELECT
       ''
      ,CAST('SEND_MSG_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SEND_MSG_FLAG like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DEREGIS_RSN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DEREGIS_RSN_ILUS like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DEREGIS_AUDIT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DEREGIS_AUDIT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_DEREGIS_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_DEREGIS_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('PWD_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PWD_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHT_REG_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_REG_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_LOGIN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_LOGIN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHT_INFO_MODIFIER_MEM_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_INFO_MODIFIER_MEM_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_INFO_MODIF_MDL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_INFO_MODIF_MDL_FLAG like '@%';

   SELECT
       ''
      ,CAST('MERCHT_INFO_FMODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_INFO_FMODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SHOP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_NO like '@%';

   SELECT
       ''
      ,CAST('SHOP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_NAME like '@%';

   SELECT
       ''
      ,CAST('SHOP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_ADDR like '@%';

   SELECT
       ''
      ,CAST('SHOP_ADDR_POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_ADDR_POST_CD like '@%';

   SELECT
       ''
      ,CAST('SHOP_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('SHOP_OPER_SCOPE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_OPER_SCOPE_DESC like '@%';

   SELECT
       ''
      ,CAST('SHOP_INFO_DESC_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_INFO_DESC_1 like '@%';

   SELECT
       ''
      ,CAST('SHOP_IDE_URL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_IDE_URL like '@%';

   SELECT
       ''
      ,CAST('SHOP_LVL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_LVL_DESC like '@%';

   SELECT
       ''
      ,CAST('SHOP_AUDIT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_AUDIT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SHOP_INFO_DESC_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_INFO_DESC_2 like '@%';

   SELECT
       ''
      ,CAST('FAVOR_APPEAL_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FAVOR_APPEAL_VAL like '@%';

   SELECT
       ''
      ,CAST('ONLINE_REPLY_CONT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ONLINE_REPLY_CONT_DESC like '@%';

   SELECT
       ''
      ,CAST('OFF_LINE_REPLY_CONT_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OFF_LINE_REPLY_CONT_DESC like '@%';

   SELECT
       ''
      ,CAST('MAX_POINT_DEDUCT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAX_POINT_DEDUCT_RATE like '@%';

   SELECT
       ''
      ,CAST('AUSLESE_SHOP_AUTH_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUSLESE_SHOP_AUTH_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('LMT_DLVY_PROV_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LMT_DLVY_PROV_CD like '@%';

   SELECT
       ''
      ,CAST('LMT_DLVY_CITY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LMT_DLVY_CITY_CD like '@%';

   SELECT
       ''
      ,CAST('LMT_DLVY_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LMT_DLVY_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('SHOP_SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SHOP_INFO_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOP_INFO_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CORP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_NO like '@%';

   SELECT
       ''
      ,CAST('CORP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_NAME like '@%';

   SELECT
       ''
      ,CAST('CORP_EN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_EN_NAME like '@%';

   SELECT
       ''
      ,CAST('LEGAL_REP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LEGAL_REP_NAME like '@%';

   SELECT
       ''
      ,CAST('CORP_SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CORP_REG_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_REG_ADDR like '@%';

   SELECT
       ''
      ,CAST('CORP_CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('CORP_CONT_MODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_CONT_MODE like '@%';

   SELECT
       ''
      ,CAST('CORP_OPERR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_OPERR_NAME like '@%';

   SELECT
       ''
      ,CAST('CORP_PRINC_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_PRINC_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CORP_MAILBOX_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_MAILBOX_ADDR like '@%';

   SELECT
       ''
      ,CAST('LAST_YEAR_TOTAL_SALES_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_YEAR_TOTAL_SALES_AMT like '@%';

   SELECT
       ''
      ,CAST('REG_CAP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_CAP like '@%';

   SELECT
       ''
      ,CAST('CORP_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CORP_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CORP_OPER_SCOPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_OPER_SCOPE like '@%';

   SELECT
       ''
      ,CAST('BIZ_LIC_MATU_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_LIC_MATU_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('BIZ_LIC_LOCAL_PROV_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_LIC_LOCAL_PROV_NAME like '@%';

   SELECT
       ''
      ,CAST('BIZ_LIC_LOCAL_MNCP_LVL_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_LIC_LOCAL_MNCP_LVL_NAME like '@%';

   SELECT
       ''
      ,CAST('BIZ_LIC_LOCAL_DIST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_LIC_LOCAL_DIST_NAME like '@%';

   SELECT
       ''
      ,CAST('BIZ_LIC_LOC_DTL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_LIC_LOC_DTL_ADDR like '@%';

   SELECT
       ''
      ,CAST('CORP_INFO_APP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_INFO_APP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CORP_INFO_SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_INFO_SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CORP_INFO_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_GOOD_HVST_SHPNG_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_INFO_MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */