-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-交通云行驶证信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_TRFC_CLD_DRIVING_LIC_INFO_TF
--     表中文名：交通云行驶证信息聚合
--     创建日期：2024-08-16 00:00:00
--     主键字段：DRIVING_LIC_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：叶禹
--     时间粒度：日
--     保留周期：None
--     描述信息：三张表找不到
--     更新记录：
--         2024-08-16 00:00:00 叶禹 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(DRIVING_LIC_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(DRIVING_LIC_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('DRIVING_LIC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRIVING_LIC_NO like '@%';

   SELECT
       ''
      ,CAST('TRFC_FIN_CLD_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TRFC_FIN_CLD_USER_ID like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_NO like '@%';

   SELECT
       ''
      ,CAST('VEHIC_TYPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_TYPE like '@%';

   SELECT
       ''
      ,CAST('VEHIC_BELONGER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_BELONGER_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_ADDR like '@%';

   SELECT
       ''
      ,CAST('ETC_USE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ETC_USE_FLAG like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('VEHIC_USAGE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_USAGE_DESC like '@%';

   SELECT
       ''
      ,CAST('VEHIC_BRAND' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_BRAND like '@%';

   SELECT
       ''
      ,CAST('VEHIC_IDTFY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_IDTFY_CD like '@%';

   SELECT
       ''
      ,CAST('ENGINE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ENGINE_NO like '@%';

   SELECT
       ''
      ,CAST('DRIVING_LIC_REG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRIVING_LIC_REG_DT like '@%';

   SELECT
       ''
      ,CAST('DRIVING_LIC_ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DRIVING_LIC_ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('ARCHIVE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARCHIVE_NO like '@%';

   SELECT
       ''
      ,CAST('APPRV_LOAD_PSN_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPRV_LOAD_PSN_CNT like '@%';

   SELECT
       ''
      ,CAST('TOTAL_WEIGHT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TOTAL_WEIGHT like '@%';

   SELECT
       ''
      ,CAST('CURB_WEIGHT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURB_WEIGHT like '@%';

   SELECT
       ''
      ,CAST('APPRV_WEIGHT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPRV_WEIGHT like '@%';

   SELECT
       ''
      ,CAST('OUT_XPSN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OUT_XPSN_DESC like '@%';

   SELECT
       ''
      ,CAST('AXLE_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AXLE_CNT like '@%';

   SELECT
       ''
      ,CAST('COMNLY_VEHIC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMNLY_VEHIC_FLAG like '@%';

   SELECT
       ''
      ,CAST('DEL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEL_FLAG like '@%';

   SELECT
       ''
      ,CAST('LIC_PLATE_COLOR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIC_PLATE_COLOR_CD like '@%';

   SELECT
       ''
      ,CAST('CERT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CERT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('INPUT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MKTING_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('MKTING_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_TRFC_CLD_DRIVING_LIC_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_ORG_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */