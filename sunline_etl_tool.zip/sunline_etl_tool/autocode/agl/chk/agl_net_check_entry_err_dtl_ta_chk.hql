-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-网联对账差错明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_NET_CHECK_ENTRY_ERR_DTL_TA
--     表中文名：网联对账差错明细聚合
--     创建日期：2024-07-01 00:00:00
--     主键字段：UPP_SER_NO
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：原海娜
--     时间粒度：日
--     保留周期：None
--     描述信息：网联支付平台与农信银和核心进行三方对账错账处理
--     更新记录：
--         2024-07-01 00:00:00 原海娜 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(UPP_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(UPP_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('UPP_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UPP_SER_NO like '@%';

   SELECT
       ''
      ,CAST('MSG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_NO like '@%';

   SELECT
       ''
      ,CAST('REQE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REQE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('NXY_BIZ_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_BIZ_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CMPLT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CMPLT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_DT like '@%';

   SELECT
       ''
      ,CAST('NXY_CHECK_ENTRY_PASS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_CHECK_ENTRY_PASS_CD like '@%';

   SELECT
       ''
      ,CAST('NXY_CORE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NXY_CORE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('LP_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND LP_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ERR_ACCT_PROD_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_ACCT_PROD_DT like '@%';

   SELECT
       ''
      ,CAST('ERR_ACCT_PROD_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_ACCT_PROD_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('NUCC_ERR_ACCT_DEAL_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_ERR_ACCT_DEAL_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('NUCC_ERR_ACCT_DEAL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_ERR_ACCT_DEAL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ERR_ACCT_DEAL_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_ACCT_DEAL_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ERR_ACCT_DEAL_MSG_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ERR_ACCT_DEAL_MSG_DESC like '@%';

   SELECT
       ''
      ,CAST('OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CHECKER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECKER_NO like '@%';

   SELECT
       ''
      ,CAST('CFM_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CFM_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('NUCC_PASS_CHECK_ENTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_PASS_CHECK_ENTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('NUCC_CORE_CHECK_ENTRY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_CORE_CHECK_ENTRY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('NUCC_PASS_CHECK_ENTRY_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND NUCC_PASS_CHECK_ENTRY_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('PASS_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PASS_BATCH_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_BATCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_NET_CHECK_ENTRY_ERR_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PLAT_BATCH_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */