-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人数字货币钱包信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF
--     表中文名：个人数字货币钱包信息聚合
--     创建日期：2024-03-28 00:00:00
--     主键字段：WALLET_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：吉云龙
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-28 00:00:00 吉云龙 创建
--         2024-08-27 00:00:00 陈艺丹 放开机构信息表注释并修改关联表名；
--         2024-09-12 00:00:00 陈艺丹 钱包接入方式代码修改映射规则



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(WALLET_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(WALLET_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('WALLET_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_NO like '@%';

   SELECT
       ''
      ,CAST('MAIN_WALLET_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_WALLET_FLAG like '@%';

   SELECT
       ''
      ,CAST('WALLET_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_NAME like '@%';

   SELECT
       ''
      ,CAST('WALLET_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_ACCT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ACCT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_ESTB_AFLT_FIN_ORG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ESTB_AFLT_FIN_ORG_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_BNKOUTLS_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_ACCESS_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ACCESS_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_MFSCT_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_MFSCT_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('WALLET_AUTH_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_AUTH_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('IBANK_AUTH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IBANK_AUTH_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_AUTH_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_AUTH_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('WALLET_AUTH_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_AUTH_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('WALLET_AUTH_END_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_AUTH_END_DT like '@%';

   SELECT
       ''
      ,CAST('WALLET_ESTB_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_ESTB_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ANALY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ANALY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('PHYS_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PHYS_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SYS_CD like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('REG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_DT like '@%';

   SELECT
       ''
      ,CAST('WALLET_BIND_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_BIND_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('WALLET_BIND_MAILBOX_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WALLET_BIND_MAILBOX_ADDR like '@%';

   SELECT
       ''
      ,CAST('VIRTUAL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_DIGIT_MNTY_WALLET_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIRTUAL_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */