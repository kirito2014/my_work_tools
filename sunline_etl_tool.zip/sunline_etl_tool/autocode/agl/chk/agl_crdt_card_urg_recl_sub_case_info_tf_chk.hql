-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡催收子案件信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF
--     表中文名：信用卡催收子案件信息聚合
--     创建日期：2024-03-07 00:00:00
--     主键字段：SUB_CASE_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-07 00:00:00 龙耀超 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(SUB_CASE_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(SUB_CASE_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SUB_CASE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUB_CASE_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_CASE_REPAY_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUB_CASE_REPAY_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CASE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASE_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_RISK_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_RISK_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_COMMIT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_COMMIT_FLAG like '@%';

   SELECT
       ''
      ,CAST('ACCT_DEFLT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_DEFLT_FLAG like '@%';

   SELECT
       ''
      ,CAST('ACCT_WRTOFF_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_WRTOFF_FLAG like '@%';

   SELECT
       ''
      ,CAST('BILING_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BILING_DT like '@%';

   SELECT
       ''
      ,CAST('CARD_CRDT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CRDT_LMT like '@%';

   SELECT
       ''
      ,CAST('ACCT_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_BAL like '@%';

   SELECT
       ''
      ,CAST('OVDUE_STAGE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_STAGE_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_OVDUE_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_OVDUE_TMS like '@%';

   SELECT
       ''
      ,CAST('OVDUE_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_PRIN like '@%';

   SELECT
       ''
      ,CAST('OVDUE_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_INT like '@%';

   SELECT
       ''
      ,CAST('OVDUE_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_FEE like '@%';

   SELECT
       ''
      ,CAST('OVDUE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVDUE_AMT like '@%';

   SELECT
       ''
      ,CAST('OVER_LMT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVER_LMT_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_BIL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_BIL_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_LOW_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_LOW_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_EREPAY_UNREPAID_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_EREPAY_UNREPAID_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_LRA_UNRPD_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_LRA_UNRPD_AMT like '@%';

   SELECT
       ''
      ,CAST('RECNT_REPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_REPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('RECNT_REPAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_REPAY_DT like '@%';

   SELECT
       ''
      ,CAST('CONT_UNRPD_LRA_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_UNRPD_LRA_TMS like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_UN_APPORTION_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_UN_APPORTION_BAL like '@%';

   SELECT
       ''
      ,CAST('CURR_URG_RECL_TASK_POOL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_URG_RECL_TASK_POOL_CD like '@%';

   SELECT
       ''
      ,CAST('ENTER_URG_RECL_TASK_POOL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ENTER_URG_RECL_TASK_POOL_DT like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_BATCH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_BATCH_DT like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_CO_CORP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_CO_CORP_NO like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_OUTSOURC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_OUTSOURC_FLAG like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_HST_OUTSOURC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_HST_OUTSOURC_FLAG like '@%';

   SELECT
       ''
      ,CAST('RECNT_URG_RECL_OUTSOURC_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_URG_RECL_OUTSOURC_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_URG_RECL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_URG_RECL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_UEC_DST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_UEC_DST_CD like '@%';

   SELECT
       ''
      ,CAST('LAST_DEAL_URG_RECL_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_DEAL_URG_RECL_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_DEAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_DEAL_DT like '@%';

   SELECT
       ''
      ,CAST('STOP_URGE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_URGE_FLAG like '@%';

   SELECT
       ''
      ,CAST('PERMNT_STOP_URGE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PERMNT_STOP_URGE_FLAG like '@%';

   SELECT
       ''
      ,CAST('STOP_URGE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_URGE_DT like '@%';

   SELECT
       ''
      ,CAST('STOP_URGE_RSN_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_URGE_RSN_DESC like '@%';

   SELECT
       ''
      ,CAST('STOP_URGE_MATU_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STOP_URGE_MATU_DAY like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('GENDER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GENDER_CD like '@%';

   SELECT
       ''
      ,CAST('CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('RESIDENTIAL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESIDENTIAL_ADDR like '@%';

   SELECT
       ''
      ,CAST('OWN_ESTATE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OWN_ESTATE_FLAG like '@%';

   SELECT
       ''
      ,CAST('VIP_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VIP_FLAG like '@%';

   SELECT
       ''
      ,CAST('NATION_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NATION_CD like '@%';

   SELECT
       ''
      ,CAST('BIRTH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIRTH_DT like '@%';

   SELECT
       ''
      ,CAST('CUST_ANL_INCOME_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_ANL_INCOME_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('HIGHST_DEG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HIGHST_DEG_CD like '@%';

   SELECT
       ''
      ,CAST('MARRI_SITU_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MARRI_SITU_CD like '@%';

   SELECT
       ''
      ,CAST('MAIN_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CAMP_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAMP_NAME like '@%';

   SELECT
       ''
      ,CAST('CORP_POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_POST_CD like '@%';

   SELECT
       ''
      ,CAST('CAMP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAMP_ADDR like '@%';

   SELECT
       ''
      ,CAST('CAMP_CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAMP_CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('LOCAL_CORP_DEPT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LOCAL_CORP_DEPT_NAME like '@%';

   SELECT
       ''
      ,CAST('POSITION_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POSITION_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RESIDENTIAL_POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESIDENTIAL_POST_CD like '@%';

   SELECT
       ''
      ,CAST('LATST_FAMILY_TEL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LATST_FAMILY_TEL like '@%';

   SELECT
       ''
      ,CAST('CONT_NAME_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NAME_1 like '@%';

   SELECT
       ''
      ,CAST('FIRST_CONT_RELA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CONT_RELA_CD like '@%';

   SELECT
       ''
      ,CAST('CONT_TEL_NO_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEL_NO_1 like '@%';

   SELECT
       ''
      ,CAST('CONT_NAME_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NAME_2 like '@%';

   SELECT
       ''
      ,CAST('SCD_CONT_RELA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCD_CONT_RELA_CD like '@%';

   SELECT
       ''
      ,CAST('CONT_TEL_NO_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEL_NO_2 like '@%';

   SELECT
       ''
      ,CAST('CREATOR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATOR_NO like '@%';

   SELECT
       ''
      ,CAST('CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MODIFIER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODIFIER_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('KEY_POT_OD_ACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND KEY_POT_OD_ACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('URG_RECL_CUST_RISK_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_URG_RECL_SUB_CASE_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URG_RECL_CUST_RISK_TYPE_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */