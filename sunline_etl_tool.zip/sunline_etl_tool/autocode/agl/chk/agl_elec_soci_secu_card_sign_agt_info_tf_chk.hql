-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-电子社保卡签约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF
--     表中文名：电子社保卡签约协议信息聚合
--     创建日期：2024-10-10 00:00:00
--     主键字段：CONT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：包含社保云系统端发起的电子社保卡的签约、解约交易数据信息
--     更新记录：
--         2024-10-10 00:00:00 魏丹丹 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CONT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CONT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CONT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO like '@%';

   SELECT
       ''
      ,CAST('USER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NAME like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_CANC_ACCT_XAM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_CANC_ACCT_XAM_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('OPBANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPBANK_NO like '@%';

   SELECT
       ''
      ,CAST('OPBANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPBANK_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_USER_ID like '@%';

   SELECT
       ''
      ,CAST('MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ACPTD_BNKOUTLS_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACPTD_BNKOUTLS_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TELR_NO like '@%';

   SELECT
       ''
      ,CAST('ISSUE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_ELEC_SOCI_SECU_CARD_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */