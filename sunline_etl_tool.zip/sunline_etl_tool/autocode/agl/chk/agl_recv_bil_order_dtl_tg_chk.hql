-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVP-收单订单明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_ORDER_DTL_TG
--     表中文名：收单订单明细聚合
--     创建日期：2024-01-03 00:00:00
--     主键字段：TXN_SER_NO, ORIG_TXN_SER_NO, TXN_RECV_TM_STAMP, TXN_SETUP_TM_STAMP, TXN_UPDATE_TM_STAMP, TXN_CMPLT_TM_STAMP, ORIG_TXN_RECV_TM_STAMP
--     归属层次：AGL-EVP
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-01-03 00:00:00 魏丹丹 新增
--         2024-08-24 00:00:00 魏丹丹 新增字段、主键
--         2024-08-29 00:00:00 魏丹丹 添加时间戳初始化日期
--         2024-09-11 00:00:00 魏丹丹 第二组参数表已入湖，修复 ,2024/9/26修改区间取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TXN_SER_NO, ORIG_TXN_SER_NO, TXN_RECV_TM_STAMP, TXN_SETUP_TM_STAMP, TXN_UPDATE_TM_STAMP, TXN_CMPLT_TM_STAMP, ORIG_TXN_RECV_TM_STAMP) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(ORIG_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_RECV_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_SETUP_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_UPDATE_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_CMPLT_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(ORIG_TXN_RECV_TM_STAMP AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_RECV_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_RECV_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_CMPLT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_CMPLT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_RECV_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_RECV_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CHNL_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CHNL_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_DATA_SRC_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_DATA_SRC_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_SCENE_PLAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_SCENE_PLAT_CD like '@%';

   SELECT
       ''
      ,CAST('CHNL_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CHNL_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CNAPS_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CNAPS_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_CNAPS_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORIG_CNAPS_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CNAPS_TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CNAPS_TXN_DT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_PASS_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_PASS_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PASS_RETURN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PASS_RETURN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PASS_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PASS_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CORE_ACCTN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CORE_ACCTN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('PSBOOK_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PSBOOK_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('DEBIT_CARD_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND DEBIT_CARD_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('SCD_SSC_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SCD_SSC_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('THIRD_SSC_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND THIRD_SSC_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('OBANK_CRDT_CARD_INSPAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND OBANK_CRDT_CARD_INSPAY_AMT like '@%';

   SELECT
       ''
      ,CAST('EACCT_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EACCT_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('KINSHIP_WALLET_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND KINSHIP_WALLET_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('FLOW_HEART_COST_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FLOW_HEART_COST_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('POINT_DEDUCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND POINT_DEDUCT_AMT like '@%';

   SELECT
       ''
      ,CAST('RNDM_SUB_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RNDM_SUB_AMT like '@%';

   SELECT
       ''
      ,CAST('CUPNS_CARD_DEDUCT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CUPNS_CARD_DEDUCT_AMT like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_BIZ_CATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_BIZ_CATE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_SYS_TASK_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_SYS_TASK_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_MAIN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_MAIN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_TXN_SUB_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_TXN_SUB_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('REFUND_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('SHOULD_STL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SHOULD_STL_AMT like '@%';

   SELECT
       ''
      ,CAST('CAN_DISCNT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CAN_DISCNT_AMT like '@%';

   SELECT
       ''
      ,CAST('UN_RTN_GOODS_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND UN_RTN_GOODS_AMT like '@%';

   SELECT
       ''
      ,CAST('NO_DISCNT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND NO_DISCNT_AMT like '@%';

   SELECT
       ''
      ,CAST('CFM_RECV_GOOD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CFM_RECV_GOOD_FLAG like '@%';

   SELECT
       ''
      ,CAST('COURT_MNY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND COURT_MNY_FLAG like '@%';

   SELECT
       ''
      ,CAST('PRE_AUTH_SCENE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PRE_AUTH_SCENE_CD like '@%';

   SELECT
       ''
      ,CAST('AUTH_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND AUTH_CD like '@%';

   SELECT
       ''
      ,CAST('PRE_AUTH_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PRE_AUTH_CD like '@%';

   SELECT
       ''
      ,CAST('PRE_AUTH_CFM_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PRE_AUTH_CFM_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_MODE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAY_MODE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('MERGE_PAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERGE_PAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('FATHER_TXN_FLOW_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FATHER_TXN_FLOW_FLAG like '@%';

   SELECT
       ''
      ,CAST('FATHER_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND FATHER_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ERR_RSN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ERR_RSN_ILUS like '@%';

   SELECT
       ''
      ,CAST('ERR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ERR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_TERMN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TXN_TERMN_CD like '@%';

   SELECT
       ''
      ,CAST('TERMN_SN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TERMN_SN like '@%';

   SELECT
       ''
      ,CAST('CD_BRAND_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CD_BRAND_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ASSIS_EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ASSIS_EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('TERMN_REAL_TM_LTLN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TERMN_REAL_TM_LTLN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('TERMN_NET_IN_CERT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND TERMN_NET_IN_CERT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_POINT_EQUIP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_POINT_EQUIP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('APP_PROGRAM_VER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND APP_PROGRAM_VER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_POINT_EQUIP_IP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_POINT_EQUIP_IP_ADDR like '@%';

   SELECT
       ''
      ,CAST('CAN_OPEN_ELEC_INVOICE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CAN_OPEN_ELEC_INVOICE_FLAG like '@%';

   SELECT
       ''
      ,CAST('USER_IP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND USER_IP_ADDR like '@%';

   SELECT
       ''
      ,CAST('USER_MAC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND USER_MAC_ADDR like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_SCENE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAY_SCENE_CD like '@%';

   SELECT
       ''
      ,CAST('BASIC_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BASIC_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('ORIG_MERCHT_ORDER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORIG_MERCHT_ORDER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHD_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHD_DESC like '@%';

   SELECT
       ''
      ,CAST('ORDER_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORDER_REM like '@%';

   SELECT
       ''
      ,CAST('ORDER_TITLE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORDER_TITLE_NAME like '@%';

   SELECT
       ''
      ,CAST('ORDER_INVALID_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ORDER_INVALID_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_ABB like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_APP_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_APP_ID like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_AFLT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_AFLT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_STORE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_STORE_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_SMALL_RECEIPT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BIZ_SMALL_RECEIPT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('THIRD_PTY_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND THIRD_PTY_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_MERCHT_PUB_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SUB_MERCHT_PUB_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('SELLER_ZFB_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SELLER_ZFB_USER_ID like '@%';

   SELECT
       ''
      ,CAST('ZFB_SHOP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND ZFB_SHOP_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_OPERR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_OPERR_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_RGN_INFO_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_RGN_INFO_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_WALLET_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_WALLET_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_BIZ_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_BIZ_SER_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_ORG_IDTFY_IDNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_ORG_IDTFY_IDNT like '@%';

   SELECT
       ''
      ,CAST('APPLY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND APPLY_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_CHNL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_CHNL_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_APP_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_APP_ID like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NAME like '@%';

   SELECT
       ''
      ,CAST('CHNL_MERCHT_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CHNL_MERCHT_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('CHNL_MERCHT_MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CHNL_MERCHT_MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('MCH_RECV_BIL_WAIT_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MCH_RECV_BIL_WAIT_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('MCH_RBCSA_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MCH_RBCSA_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_NO_OPBANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_NO_OPBANK_NO like '@%';

   SELECT
       ''
      ,CAST('RBSA_OPBK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RBSA_OPBK_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_FUND_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAY_FUND_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAY_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAY_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAY_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PAY_ACCT_OPEN_ACCT_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND PAY_ACCT_OPEN_ACCT_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PAY_ACCT_LMT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PAY_ACCT_LMT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_DEBIT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_DEBIT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_DEBIT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_DEBIT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_DEBIT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_DEBIT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_CRDT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_CRDT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_CRDT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_CRDT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_CRDT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_CRDT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('COURT_MNY_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND COURT_MNY_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BUYER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_NAME like '@%';

   SELECT
       ''
      ,CAST('BUYER_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('BUYER_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('BUYER_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('BUYER_MIN_AGE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_MIN_AGE like '@%';

   SELECT
       ''
      ,CAST('BUYER_CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_CUST_NO like '@%';

   SELECT
       ''
      ,CAST('MNY_USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MNY_USER_ID like '@%';

   SELECT
       ''
      ,CAST('BUYER_LOGIN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_LOGIN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BUYER_IDTFY_IDNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND BUYER_IDTFY_IDNT like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('INST_TOTAL_CFEE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND INST_TOTAL_CFEE_RATE like '@%';

   SELECT
       ''
      ,CAST('MERCHT_SCF_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_SCF_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('MCH_SBDY_INSFSC_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MCH_SBDY_INSFSC_RATE like '@%';

   SELECT
       ''
      ,CAST('MCH_SBDY_INSCF_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MCH_SBDY_INSCF_AMT like '@%';

   SELECT
       ''
      ,CAST('CHDER_INSFSC_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CHDER_INSFSC_RATE like '@%';

   SELECT
       ''
      ,CAST('CHDER_INSCF_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND CHDER_INSCF_AMT like '@%';

   SELECT
       ''
      ,CAST('MERCHT_SBDY_INSCF_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_SBDY_INSCF_AMT like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_PAY_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_PAY_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_TMS like '@%';

   SELECT
       ''
      ,CAST('STAT_QR_CD_SN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND STAT_QR_CD_SN like '@%';

   SELECT
       ''
      ,CAST('B_SRC_SYS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_SYS_CD like '@%';

   SELECT
       ''
      ,CAST('B_SRC_TAB_EN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_ORDER_DTL_TG 
 WHERE PT_DT = '${process_date}'
   AND B_SRC_TAB_EN_NAME like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */