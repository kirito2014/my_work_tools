-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-移动展业埋点明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_YDZY_SAMPLE_DTL_TF
--     表中文名：移动展业埋点明细聚合
--     创建日期：2024-05-18 00:00:00
--     主键字段：EVENT_TRIG_TM, USER_ID, EVENT_ID
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：翟向阳
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-17 00:00:00 翟向阳 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(EVENT_TRIG_TM, USER_ID, EVENT_ID) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(EVENT_TRIG_TM AS STRING),'') AS STRING), CAST(COALESCE(CAST(USER_ID AS STRING),'') AS STRING), CAST(COALESCE(CAST(EVENT_ID AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('EVENT_TRIG_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EVENT_TRIG_TM like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('EVENT_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EVENT_ID like '@%';

   SELECT
       ''
      ,CAST('VISITOR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND VISITOR_NO like '@%';

   SELECT
       ''
      ,CAST('LOGIN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LOGIN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('IDFA' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND IDFA like '@%';

   SELECT
       ''
      ,CAST('IMEI' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND IMEI like '@%';

   SELECT
       ''
      ,CAST('SYS_DEAL_TM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SYS_DEAL_TM like '@%';

   SELECT
       ''
      ,CAST('EVENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EVENT_NAME like '@%';

   SELECT
       ''
      ,CAST('EVENT_LABEL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EVENT_LABEL_DESC like '@%';

   SELECT
       ''
      ,CAST('EVENT_TM_ACCRT_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EVENT_TM_ACCRT_VAL like '@%';

   SELECT
       ''
      ,CAST('EVENT_DURAN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EVENT_DURAN like '@%';

   SELECT
       ''
      ,CAST('SAMPLE_MODE_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SAMPLE_MODE_DESC like '@%';

   SELECT
       ''
      ,CAST('SAMPLE_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SAMPLE_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('SPME_DAY_ACCESS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SPME_DAY_ACCESS_FLAG like '@%';

   SELECT
       ''
      ,CAST('TM_ZONE_DEVIAT_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND TM_ZONE_DEVIAT_VAL like '@%';

   SELECT
       ''
      ,CAST('LOGIN_EQUIP_LGTD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LOGIN_EQUIP_LGTD like '@%';

   SELECT
       ''
      ,CAST('LOGIN_EQUIP_DIMEN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND LOGIN_EQUIP_DIMEN like '@%';

   SELECT
       ''
      ,CAST('SRC_CHNL_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SRC_CHNL_DESC like '@%';

   SELECT
       ''
      ,CAST('PAGE_TITLE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PAGE_TITLE_NAME like '@%';

   SELECT
       ''
      ,CAST('PAGE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PAGE_NAME like '@%';

   SELECT
       ''
      ,CAST('PAGE_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PAGE_ADDR like '@%';

   SELECT
       ''
      ,CAST('PAGE_PATH_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PAGE_PATH_DESC like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BRAND_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BRAND_NAME like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MANUF_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MANUF_NAME like '@%';

   SELECT
       ''
      ,CAST('EQUIP_MODEL_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_MODEL_NAME like '@%';

   SELECT
       ''
      ,CAST('OS_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OS_NAME like '@%';

   SELECT
       ''
      ,CAST('OS_VER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OS_VER_NAME like '@%';

   SELECT
       ''
      ,CAST('SCRN_HEIGHT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SCRN_HEIGHT like '@%';

   SELECT
       ''
      ,CAST('SCRN_WIDTH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SCRN_WIDTH like '@%';

   SELECT
       ''
      ,CAST('WIFI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND WIFI_FLAG like '@%';

   SELECT
       ''
      ,CAST('CAROPR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CAROPR_NAME like '@%';

   SELECT
       ''
      ,CAST('WEB_TYPE_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND WEB_TYPE_NAME like '@%';

   SELECT
       ''
      ,CAST('IP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND IP_ADDR like '@%';

   SELECT
       ''
      ,CAST('CITY_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CITY_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('PROV_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND PROV_NAME like '@%';

   SELECT
       ''
      ,CAST('CTRY_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CTRY_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BELONG_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BELONG_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('SYS_VER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_YDZY_SAMPLE_DTL_TF 
 WHERE PT_DT = '${process_date}'
   AND SYS_VER_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */