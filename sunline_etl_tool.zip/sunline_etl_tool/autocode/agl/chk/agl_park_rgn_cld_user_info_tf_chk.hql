-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-园区云用户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_PARK_RGN_CLD_USER_INFO_TF
--     表中文名：园区云用户信息聚合
--     创建日期：None
--     主键字段：CUST_NO, USER_ID
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：None
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-10-16 00:00:00 魏丹丹 修改CSV
--         2024-10-24 00:00:00 魏丹丹 修改设计1017的更新



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CUST_NO, USER_ID) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CUST_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(USER_ID AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('PRC_OLD_PSN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRC_OLD_PSN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DSBL_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DSBL_FLAG like '@%';

   SELECT
       ''
      ,CAST('PASS_AWAY_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PASS_AWAY_FLAG like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_NAME like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PARK_RGN_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PARK_RGN_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ORG_BELONG_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ORG_BELONG_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('GENDER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GENDER_CD like '@%';

   SELECT
       ''
      ,CAST('BIRTH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIRTH_DT like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('LANDLINE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LANDLINE_NO like '@%';

   SELECT
       ''
      ,CAST('RESIDENTIAL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESIDENTIAL_ADDR like '@%';

   SELECT
       ''
      ,CAST('DWLG_ADDR_BELONG_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DWLG_ADDR_BELONG_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('DWLG_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DWLG_ADDR like '@%';

   SELECT
       ''
      ,CAST('COMMUNIC_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMMUNIC_ADDR like '@%';

   SELECT
       ''
      ,CAST('POST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POST_CD like '@%';

   SELECT
       ''
      ,CAST('EMAIL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EMAIL_ADDR like '@%';

   SELECT
       ''
      ,CAST('CUST_INFO_CREATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_INFO_CREATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_PARK_RGN_CLD_USER_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */