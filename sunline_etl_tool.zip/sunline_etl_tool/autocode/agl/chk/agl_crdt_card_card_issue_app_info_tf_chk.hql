-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡发卡申请信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF
--     表中文名：信用卡发卡申请信息聚合
--     创建日期：2024-03-01 00:00:00
--     主键字段：APP_FORM_NO, APP_DT_SLR_DAY, APP_FORM_SER_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-01 00:00:00 龙耀超 新增



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(APP_FORM_NO, APP_DT_SLR_DAY, APP_FORM_SER_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(APP_FORM_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(APP_DT_SLR_DAY AS STRING),'') AS STRING), CAST(COALESCE(CAST(APP_FORM_SER_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('APP_FORM_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_FORM_NO like '@%';

   SELECT
       ''
      ,CAST('APP_DT_SLR_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_DT_SLR_DAY like '@%';

   SELECT
       ''
      ,CAST('APP_FORM_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_FORM_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_ANLFEE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_ANLFEE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACCT_ANL_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_ANL_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PRINC_SUPP_CARD_APP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINC_SUPP_CARD_APP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PRINC_SUPP_CARD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRINC_SUPP_CARD_FLAG like '@%';

   SELECT
       ''
      ,CAST('MASTER_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MASTER_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('APP_CARD_TYPE_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_CARD_TYPE_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('MAIN_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('MAIN_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DOC_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('DOC_VALID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_VALID like '@%';

   SELECT
       ''
      ,CAST('MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUST_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUST_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('GENDER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GENDER_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUST_SRC_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUST_SRC_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('BIRTH_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIRTH_DT like '@%';

   SELECT
       ''
      ,CAST('MARRI_SITU_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MARRI_SITU_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUST_EDU_DEG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUST_EDU_DEG_CD like '@%';

   SELECT
       ''
      ,CAST('RESIDENTIAL_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESIDENTIAL_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('RESIDENTIAL_TEL_AREA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESIDENTIAL_TEL_AREA_CD like '@%';

   SELECT
       ''
      ,CAST('EMAIL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EMAIL_ADDR like '@%';

   SELECT
       ''
      ,CAST('CAREER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAREER_CD like '@%';

   SELECT
       ''
      ,CAST('WORK_YEARS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WORK_YEARS like '@%';

   SELECT
       ''
      ,CAST('UNIT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNIT_NAME like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUEM_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUEM_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUST_INDS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUST_INDS_CD like '@%';

   SELECT
       ''
      ,CAST('CORP_TEL_EXT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_TEL_EXT_NO like '@%';

   SELECT
       ''
      ,CAST('INDV_ANL_INCOME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_ANL_INCOME like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CUST_INCOME_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CUST_INCOME_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('HOS_SITU_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HOS_SITU_CD like '@%';

   SELECT
       ''
      ,CAST('ESTATE_OCPY_LAND_AREA' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ESTATE_OCPY_LAND_AREA like '@%';

   SELECT
       ''
      ,CAST('ESTATE_MONTHLY_PAY_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ESTATE_MONTHLY_PAY_AMT like '@%';

   SELECT
       ''
      ,CAST('VEHIC_PRC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_PRC like '@%';

   SELECT
       ''
      ,CAST('VEHIC_LIC_PLATE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_LIC_PLATE_NO like '@%';

   SELECT
       ''
      ,CAST('PURCH_SELF_CAR_BUY_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PURCH_SELF_CAR_BUY_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('VEHIC_BRAND' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND VEHIC_BRAND like '@%';

   SELECT
       ''
      ,CAST('PSCAR_LOAN_SITU_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PSCAR_LOAN_SITU_CD like '@%';

   SELECT
       ''
      ,CAST('SELF_DED_REPAY_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELF_DED_REPAY_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FCURR_SELF_DED_REPAY_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FCURR_SELF_DED_REPAY_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FIRST_CONT_AND_APPCANT_RELA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CONT_AND_APPCANT_RELA_CD like '@%';

   SELECT
       ''
      ,CAST('FIRST_CONT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CONT_NAME like '@%';

   SELECT
       ''
      ,CAST('FIRST_CONT_TEL_AREA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CONT_TEL_AREA_CD like '@%';

   SELECT
       ''
      ,CAST('FIRST_CONT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CONT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('FIRST_CONT_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CONT_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('SCD_CONT_AND_APPCANT_RELA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCD_CONT_AND_APPCANT_RELA_CD like '@%';

   SELECT
       ''
      ,CAST('SCD_CONT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCD_CONT_NAME like '@%';

   SELECT
       ''
      ,CAST('SCD_CONT_TEL_AREA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCD_CONT_TEL_AREA_CD like '@%';

   SELECT
       ''
      ,CAST('SCD_CONT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCD_CONT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('SCD_CONT_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SCD_CONT_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('SPREAD_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPREAD_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SPREAD_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPREAD_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('SPREAD_SUBMIT_APP_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPREAD_SUBMIT_APP_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('SPREAD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPREAD_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('APP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_DT like '@%';

   SELECT
       ''
      ,CAST('APP_GIFT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_GIFT_NO like '@%';

   SELECT
       ''
      ,CAST('APPCANT_APP_INSTALMT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPCANT_APP_INSTALMT_LMT like '@%';

   SELECT
       ''
      ,CAST('APPCANT_APP_CRDT_LINE_DEG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPCANT_APP_CRDT_LINE_DEG like '@%';

   SELECT
       ''
      ,CAST('APP_SPC_CASE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_SPC_CASE_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CIAPP_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CIAPP_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_CIAPP_AUDIT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_CIAPP_AUDIT_CD like '@%';

   SELECT
       ''
      ,CAST('APP_AUDIT_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APP_AUDIT_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('PRECHK_CHECK_CROSS_XAM_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRECHK_CHECK_CROSS_XAM_FLAG like '@%';

   SELECT
       ''
      ,CAST('APPRV_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPRV_DT like '@%';

   SELECT
       ''
      ,CAST('CHECK_APPRV_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CHECK_APPRV_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('REFUS_APPRV_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUS_APPRV_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('CRDT_CARD_AUDIT_RESLT_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CRDT_CARD_AUDIT_RESLT_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('REFUS_RSN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUS_RSN_ILUS like '@%';

   SELECT
       ''
      ,CAST('APPRV_CRDT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPRV_CRDT_LMT like '@%';

   SELECT
       ''
      ,CAST('APPRV_INSTALMT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND APPRV_INSTALMT_LMT like '@%';

   SELECT
       ''
      ,CAST('LETTER_PROD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LETTER_PROD_FLAG like '@%';

   SELECT
       ''
      ,CAST('QUICK_CARD_ISSUE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND QUICK_CARD_ISSUE_FLAG like '@%';

   SELECT
       ''
      ,CAST('QUICK_CARD_ISSUE_FEE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND QUICK_CARD_ISSUE_FEE_FLAG like '@%';

   SELECT
       ''
      ,CAST('SMS_SERV_PROVI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_CARD_ISSUE_APP_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMS_SERV_PROVI_FLAG like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */