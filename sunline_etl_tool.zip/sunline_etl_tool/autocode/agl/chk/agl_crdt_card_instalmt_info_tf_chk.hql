-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-信用卡分期付款信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_CRDT_CARD_INSTALMT_INFO_TF
--     表中文名：信用卡分期付款信息聚合
--     创建日期：2024-01-03 00:00:00
--     主键字段：INSTALLMENT_BIZ_NO, ACCT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-01-03 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改码值映射



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(INSTALLMENT_BIZ_NO, ACCT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(INSTALLMENT_BIZ_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('INSTALLMENT_BIZ_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_BIZ_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_CRDT_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_CRDT_LMT like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NAME like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('MAIN_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('MAIN_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAIN_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_FLAG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_FLAG_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_PROC_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_PROC_DT like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_PROC_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_PROC_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('AUTH_DEAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_DEAL_DT like '@%';

   SELECT
       ''
      ,CAST('AUTH_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('AUTH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_NO like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_ANL_INT_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_ANL_INT_RATE like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_TMS like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_AMT like '@%';

   SELECT
       ''
      ,CAST('EACH_TERM_AMORT_INSTALMT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACH_TERM_AMORT_INSTALMT_AMT like '@%';

   SELECT
       ''
      ,CAST('AL_INSTALLMENT_AMORT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_INSTALLMENT_AMORT_TMS like '@%';

   SELECT
       ''
      ,CAST('AL_APPORTION_UN_AMORT_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_APPORTION_UN_AMORT_PRIN like '@%';

   SELECT
       ''
      ,CAST('AL_AMORT_NOT_RECORD_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_AMORT_NOT_RECORD_PRIN like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_INSTMT_AMORT_PRIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_INSTMT_AMORT_PRIN_AMT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_INSTALLMENT_AMORT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_INSTALLMENT_AMORT_DT like '@%';

   SELECT
       ''
      ,CAST('AL_APPORTION_UNREPAID_PRIN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_APPORTION_UNREPAID_PRIN like '@%';

   SELECT
       ''
      ,CAST('INT_TOTAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INT_TOTAL_AMT like '@%';

   SELECT
       ''
      ,CAST('FIRST_TXN_INSTALLMENT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_TXN_INSTALLMENT_INT like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_INSTALLMENT_AMORT_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_INSTALLMENT_AMORT_INT like '@%';

   SELECT
       ''
      ,CAST('AMORTD_INT_CUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AMORTD_INT_CUM like '@%';

   SELECT
       ''
      ,CAST('AL_APPORTION_UNREPAID_INT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_APPORTION_UNREPAID_INT like '@%';

   SELECT
       ''
      ,CAST('TOTAL_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TOTAL_FEE like '@%';

   SELECT
       ''
      ,CAST('PNLTINT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PNLTINT_AMT like '@%';

   SELECT
       ''
      ,CAST('AL_APPORTION_UNREPAID_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AL_APPORTION_UNREPAID_FEE like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_STATUS_CHG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_STATUS_CHG_DT like '@%';

   SELECT
       ''
      ,CAST('PREPAY_RSN_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PREPAY_RSN_ILUS like '@%';

   SELECT
       ''
      ,CAST('PAUSE_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAUSE_TMS like '@%';

   SELECT
       ''
      ,CAST('POSTPONE_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_CRDT_CARD_INSTALMT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POSTPONE_TMS like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */