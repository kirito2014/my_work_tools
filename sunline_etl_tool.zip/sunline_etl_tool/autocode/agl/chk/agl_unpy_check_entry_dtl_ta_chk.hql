-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-银联对账明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_CHECK_ENTRY_DTL_TA
--     表中文名：银联对账明细聚合
--     创建日期：2024-06-14 00:00:00
--     主键字段：CHECK_ENTRY_DT, UNPY_TXN_TM_STAMP, UNPY_TXN_PROC_CD, MSG_TYPE_CD, AGEN_TXN_UNPY_ORG_NO, SEND_MSG_UNPY_ORG_NO, SYS_TRACK_NO, UNPY_DOC_TYPE_CD
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：清算综合服务平台的银联与账务交易系统对账结果数据
--     更新记录：
--         2024-06-14 00:00:00 wangmujun new
--         2024-08-22 00:00:00 王穆军 修改最新版本
--         2024-09-03 00:00:00 王穆军 修改字段名称
--         2024-09-13 00:00:00 王穆军 修改主键逻辑
--         2024-11-10 00:00:00 魏丹丹 修改代理交易银联机构编号，发送报文银联机构编号,原始交易时间戳,服务点输入方式代码,清算日期取数逻辑



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(CHECK_ENTRY_DT, UNPY_TXN_TM_STAMP, UNPY_TXN_PROC_CD, MSG_TYPE_CD, AGEN_TXN_UNPY_ORG_NO, SEND_MSG_UNPY_ORG_NO, SYS_TRACK_NO, UNPY_DOC_TYPE_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(CHECK_ENTRY_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_TXN_TM_STAMP AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_TXN_PROC_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(MSG_TYPE_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(AGEN_TXN_UNPY_ORG_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SEND_MSG_UNPY_ORG_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SYS_TRACK_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(UNPY_DOC_TYPE_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CHECK_ENTRY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_DT like '@%';

   SELECT
       ''
      ,CAST('UNPY_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('UNPY_TXN_PROC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_TXN_PROC_CD like '@%';

   SELECT
       ''
      ,CAST('MSG_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MSG_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('AGEN_TXN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_TXN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SEND_MSG_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SEND_MSG_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SYS_TRACK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SYS_TRACK_NO like '@%';

   SELECT
       ''
      ,CAST('UNPY_DOC_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_DOC_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('UNPY_CENT_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_CENT_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_MCC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_MCC_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('ORDER_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORDER_SER_NO like '@%';

   SELECT
       ''
      ,CAST('AGEN_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AGEN_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('SEND_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SEND_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_TXN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_TXN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_ISSUE_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_ISSUE_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('ORIG_TXSYS_TRACK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ORIG_TXSYS_TRACK_NO like '@%';

   SELECT
       ''
      ,CAST('RETRIV_REF_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RETRIV_REF_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_POINT_COND_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_POINT_COND_CD like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNOUT_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNOUT_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_UNPY_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_UNPY_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TRNIN_CARD_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRNIN_CARD_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_ANSWER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND AUTH_ANSWER_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_POINT_INPUT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SERV_POINT_INPUT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('TERMN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TERMN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('CLEAR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_DT like '@%';

   SELECT
       ''
      ,CAST('CLEAR_PERIOD_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_PERIOD_DESC like '@%';

   SELECT
       ''
      ,CAST('CLEAR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_AMT like '@%';

   SELECT
       ''
      ,CAST('CLEAR_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CLEAR_EXCH_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CLEAR_EXCH_RATE like '@%';

   SELECT
       ''
      ,CAST('CARD_HOLDER_TXN_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CARD_HOLDER_TXN_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('RECV_PTY_RECVBL_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_PTY_RECVBL_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('RECV_PTY_PAYBL_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_PTY_PAYBL_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('TRAN_SERV_FEE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TRAN_SERV_FEE_AMT like '@%';

   SELECT
       ''
      ,CAST('COL_MERCHT_FIX_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND COL_MERCHT_FIX_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('INSTALMT_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INSTALMT_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('DOC_SRC_PATH_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND DOC_SRC_PATH_DESC like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_OBJ_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_OBJ_DESC like '@%';

   SELECT
       ''
      ,CAST('UNPY_CHECK_ENTRY_RESLT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_CHECK_ENTRY_RESLT_CD like '@%';

   SELECT
       ''
      ,CAST('ECI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND ECI_FLAG like '@%';

   SELECT
       ''
      ,CAST('FRONT_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FRONT_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CHECK_ENTRY_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CHECK_ENTRY_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CORE_ACPTD_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_CHECK_ENTRY_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_ACPTD_ORG_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */