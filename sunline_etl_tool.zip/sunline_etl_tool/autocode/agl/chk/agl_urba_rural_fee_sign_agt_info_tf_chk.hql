-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-城乡两费签约协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF
--     表中文名：城乡两费签约协议信息聚合
--     创建日期：2024-03-14 00:00:00
--     主键字段：BANK_PAY_AGT_BOOK_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-03-14 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(BANK_PAY_AGT_BOOK_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(BANK_PAY_AGT_BOOK_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('BANK_PAY_AGT_BOOK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BANK_PAY_AGT_BOOK_NO like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_CD like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_SRC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_SRC_CD like '@%';

   SELECT
       ''
      ,CAST('DIROR_TAX_ORG_VIRTUAL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIROR_TAX_ORG_VIRTUAL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SIGN_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('GIVE_UP_USE_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GIVE_UP_USE_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CARD_DISCNT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_DISCNT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('AGT_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('AGT_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGT_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('PAY_PSN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_PSN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_NO_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NO_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_ACCT_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_ACCT_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('URBA_RURAL_FEE_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND URBA_RURAL_FEE_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DEDUCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEDUCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('SINGLE_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SINGLE_LMT like '@%';

   SELECT
       ''
      ,CAST('SIGN_ACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_ACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('OPBANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPBANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('PAY_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('TAX_ADMIN_RGN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_ADMIN_RGN_NO like '@%';

   SELECT
       ''
      ,CAST('TAX_PRTCPT_INSURE_PSN_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_PRTCPT_INSURE_PSN_NO like '@%';

   SELECT
       ''
      ,CAST('TAX_PRTCPT_INSURE_PSN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_PRTCPT_INSURE_PSN_NAME like '@%';

   SELECT
       ''
      ,CAST('TAX_ORG_BANK_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_ORG_BANK_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('TAX_ORG_RECV_TAX_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_ORG_RECV_TAX_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('TAX_PAY_PSN_AFLT_NATION_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_PAY_PSN_AFLT_NATION_CD like '@%';

   SELECT
       ''
      ,CAST('SOCI_SECU_HANDLE_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SOCI_SECU_HANDLE_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('AGEN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGEN_FLAG like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REM like '@%';

   SELECT
       ''
      ,CAST('DATA_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_URBA_RURAL_FEE_SIGN_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DATA_DT like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */