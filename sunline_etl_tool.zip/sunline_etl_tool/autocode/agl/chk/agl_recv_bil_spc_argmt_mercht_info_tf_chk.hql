-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-收单特约商户信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF
--     表中文名：收单特约商户信息聚合
--     创建日期：2023-12-05 00:00:00
--     主键字段：SPC_ARGMT_MERCHT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：存储特约商户聚合
--     更新记录：
--         2023-12-04 00:00:00 沈健 新增
--         2024-07-25 00:00:00 王穆军 修改保持与设计文档一致
--         2024-08-14 00:00:00 王穆军 修改版本，不是最新版，第三组数据重复，证件号关联
--         2024-08-29 00:00:00 王穆军 新增字段，修改逻辑
--         2024-09-05 00:00:00 王穆军 变更字段，码值变更
--         2024-10-21 00:00:00 魏丹丹 修改9月的变更以及1012截止的变更
--         2024-11-11 00:00:00 魏丹丹 生产问题修复



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(SPC_ARGMT_MERCHT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(SPC_ARGMT_MERCHT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_ATTR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_ATTR_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('WX_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WX_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('ZFB_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ZFB_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('UNPY_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND UNPY_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('STL_ACCT_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_ACCT_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('LP_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CORP_CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_NO like '@%';

   SELECT
       ''
      ,CAST('DOC_ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('DOC_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOC_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('REG_CAP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_CAP like '@%';

   SELECT
       ''
      ,CAST('REG_ADDR_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_ADDR_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('REG_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REG_ADDR like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOC_ISSUE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOC_ISSUE_DT like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_DOC_MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_DOC_MATU_DT like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_NAME like '@%';

   SELECT
       ''
      ,CAST('LP_PRINC_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_PRINC_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('LP_DOC_INFO_SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_DOC_INFO_SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('LP_DOC_INFO_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LP_DOC_INFO_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('ASSIS_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ASSIS_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('ASSIS_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ASSIS_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('ASSIS_DOC_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ASSIS_DOC_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_NAME like '@%';

   SELECT
       ''
      ,CAST('CONT_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('CONT_EMAIL_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CONT_EMAIL_ADDR like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_NAME_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_NAME_ABB like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_EN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_EN_NAME like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('SAM_CATEGORY_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SAM_CATEGORY_DESC like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_SCENE_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_SCENE_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_SCENE_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_SCENE_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('INDUS_CATEGORY_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDUS_CATEGORY_NAME like '@%';

   SELECT
       ''
      ,CAST('INDUS_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDUS_NAME like '@%';

   SELECT
       ''
      ,CAST('ZFB_OPER_CAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ZFB_OPER_CAT_CD like '@%';

   SELECT
       ''
      ,CAST('WX_CORP_STL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WX_CORP_STL_CD like '@%';

   SELECT
       ''
      ,CAST('HELP_FMR_POINT_STAR_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HELP_FMR_POINT_STAR_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('WEB_MERCHT_REG_URL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WEB_MERCHT_REG_URL like '@%';

   SELECT
       ''
      ,CAST('WEB_MERCHT_REG_IP_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WEB_MERCHT_REG_IP_ADDR like '@%';

   SELECT
       ''
      ,CAST('WEB_MERCHT_IC_REC_LIC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WEB_MERCHT_IC_REC_LIC_NO like '@%';

   SELECT
       ''
      ,CAST('WX_COST_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND WX_COST_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('CUST_SERV_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_SERV_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('ACTL_OPER_ADDR_LOCAL_PROV_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_OPER_ADDR_LOCAL_PROV_CD like '@%';

   SELECT
       ''
      ,CAST('ACTL_OPER_ADDR_LOCAL_CITY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_OPER_ADDR_LOCAL_CITY_CD like '@%';

   SELECT
       ''
      ,CAST('ACTL_OPER_ADDR_LOCAL_DIST_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_OPER_ADDR_LOCAL_DIST_CD like '@%';

   SELECT
       ''
      ,CAST('AOA_LOCAL_TOWN_STREET_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AOA_LOCAL_TOWN_STREET_CD like '@%';

   SELECT
       ''
      ,CAST('AOA_LOCAL_VILG_COMM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AOA_LOCAL_VILG_COMM_CD like '@%';

   SELECT
       ''
      ,CAST('ACTL_OPER_ADDR_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_OPER_ADDR_DESC like '@%';

   SELECT
       ''
      ,CAST('ACTL_OPER_ADDR_LATD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_OPER_ADDR_LATD like '@%';

   SELECT
       ''
      ,CAST('ACTL_OPER_ADDR_LGTD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACTL_OPER_ADDR_LGTD like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('PREFR_DERATE_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PREFR_DERATE_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SMALL_MICRO_MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SMALL_MICRO_MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RISK_ESTIM_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RISK_ESTIM_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('EXPAND_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXPAND_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MKTING_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('MKTING_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('MATN_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATN_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('MATN_TELR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATN_TELR_NAME like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_CD like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_NAME like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('SERV_PROVDER_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SERV_PROVDER_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('DAILY_ACCUM_TRAN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DAILY_ACCUM_TRAN_LMT like '@%';

   SELECT
       ''
      ,CAST('MONTHLY_ACCUM_TRAN_LMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MONTHLY_ACCUM_TRAN_LMT like '@%';

   SELECT
       ''
      ,CAST('STL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('RBSA_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RBSA_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RBSA_OPEN_ACCT_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RBSA_OPEN_ACCT_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_OPBANK_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_OPBANK_NO like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_STL_ACCT_OPBANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_STL_ACCT_OPBANK_NAME like '@%';

   SELECT
       ''
      ,CAST('ARBSA_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARBSA_NO like '@%';

   SELECT
       ''
      ,CAST('ARBSA_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARBSA_NAME like '@%';

   SELECT
       ''
      ,CAST('ARBSA_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARBSA_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('ARBSA_OPEN_ACCT_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARBSA_OPEN_ACCT_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('ARBSA_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARBSA_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ARBSA_OPBANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ARBSA_OPBANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('CFEA_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CFEA_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_EXPNT_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_EXPNT_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_EXPNT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_EXPNT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_EXPNT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_EXPNT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_CAP_STL_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_CAP_STL_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_CAP_STL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_CAP_STL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('COMM_FEE_STL_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMM_FEE_STL_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('RECV_GOOD_CFM_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_GOOD_CFM_FLAG like '@%';

   SELECT
       ''
      ,CAST('REFUND_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('REFUND_EACCT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_EACCT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('REFUND_EXPNT_ACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_EXPNT_ACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('REFUND_EXPNT_ACCT_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_EXPNT_ACCT_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('REFUND_EXPNT_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_EXPNT_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('EXCESS_REFUND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCESS_REFUND_FLAG like '@%';

   SELECT
       ''
      ,CAST('REFUND_MRGACCT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MRGACCT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('REFUND_MRGACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MRGACCT_NO like '@%';

   SELECT
       ''
      ,CAST('REFUND_MRGACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MRGACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('RMACT_OPEN_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RMACT_OPEN_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RMACT_OPEN_ACCT_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RMACT_OPEN_ACCT_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('REFUND_MRG_ACCT_NO_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REFUND_MRG_ACCT_NO_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TERROR_ACT_LIST_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TERROR_ACT_LIST_FLAG like '@%';

   SELECT
       ''
      ,CAST('CO_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CO_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('BIZ_PROD_PRVLG_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_PROD_PRVLG_CD like '@%';

   SELECT
       ''
      ,CAST('ESCR_MERCHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ESCR_MERCHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('PRFT_CUT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRFT_CUT_FLAG like '@%';

   SELECT
       ''
      ,CAST('INSTALLMENT_MERCHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTALLMENT_MERCHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('POS_MERCHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POS_MERCHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('POS_MIGRATE_MERCHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND POS_MIGRATE_MERCHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_SCENE_PLAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_SCENE_PLAT_CD like '@%';

   SELECT
       ''
      ,CAST('SAM_OPER_APP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SAM_OPER_APP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SPC_ARGMT_MERCHT_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SPC_ARGMT_MERCHT_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SAM_AUDIT_STAT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SAM_AUDIT_STAT_CD like '@%';

   SELECT
       ''
      ,CAST('SUBMIT_APP_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBMIT_APP_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('SUBMIT_APP_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBMIT_APP_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PRE_COL_INFO_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_COL_INFO_SER_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('OPEN_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('AUDIT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_NO like '@%';

   SELECT
       ''
      ,CAST('AUDIT_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECV_BIL_PROD_FRZ_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECV_BIL_PROD_FRZ_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_RSN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_RSN_CD like '@%';

   SELECT
       ''
      ,CAST('AUDIT_FAIL_RSN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUDIT_FAIL_RSN like '@%';

   SELECT
       ''
      ,CAST('INPUT_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('INPUT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INPUT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('RECNT_MODIF_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_MODIF_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('MIGRATE_MERCHT_IDNT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MIGRATE_MERCHT_IDNT_CD like '@%';

   SELECT
       ''
      ,CAST('MIGRATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MIGRATE_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FRZ_RSN_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FRZ_RSN_REM like '@%';

   SELECT
       ''
      ,CAST('RECNT_FRZ_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_FRZ_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('RECNT_UNFRZ_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_RECV_BIL_SPC_ARGMT_MERCHT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RECNT_UNFRZ_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */