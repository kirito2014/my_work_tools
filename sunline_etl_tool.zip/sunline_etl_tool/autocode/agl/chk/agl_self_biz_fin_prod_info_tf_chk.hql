-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-自营理财产品信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_SELF_BIZ_FIN_PROD_INFO_TF
--     表中文名：自营理财产品信息聚合
--     创建日期：2023-12-26 00:00:00
--     主键字段：PROD_ISSUE_COPRT_UNI_NO, PROD_NO, TA_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2023-12-26 00:00:00 魏丹丹 新增
--         2024-04-29 00:00:00 魏丹丹 修改字段以及数据字典
--         2024-09-02 00:00:00 魏丹丹 修改字段以及数据字典



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(PROD_ISSUE_COPRT_UNI_NO, PROD_NO, TA_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(PROD_ISSUE_COPRT_UNI_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(PROD_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TA_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('BRAND_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BRAND_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_SERIES_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUB_SERIES_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_ISSUE_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_ISSUE_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NO like '@%';

   SELECT
       ''
      ,CAST('SHOW_USE_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOW_USE_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('OPER_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MUM_PROD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MUM_PROD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_ABB like '@%';

   SELECT
       ''
      ,CAST('SELF_BIZ_FIN_PROD_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELF_BIZ_FIN_PROD_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SELLER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELLER_NO like '@%';

   SELECT
       ''
      ,CAST('TA_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TA_CD like '@%';

   SELECT
       ''
      ,CAST('MKTING_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_PRFT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_PRFT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PRFT_FEATURE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRFT_FEATURE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_FEATURE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_FEATURE_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('ISSUE_PAR_VAL_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_PAR_VAL_AMT like '@%';

   SELECT
       ''
      ,CAST('SALES_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALES_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('INVEST_DIR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_DIR_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_SERIES_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_SERIES_CD like '@%';

   SELECT
       ''
      ,CAST('RISK_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RISK_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_ISSUE_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_ISSUE_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('CSDTY_ROW_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSDTY_ROW_NO like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_PRFT_DISTRI_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_PRFT_DISTRI_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PRFT_INTACR_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRFT_INTACR_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_SHORTEST_HOLD_TERM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_SHORTEST_HOLD_TERM like '@%';

   SELECT
       ''
      ,CAST('PROD_MAX_HOLD_TERM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_MAX_HOLD_TERM like '@%';

   SELECT
       ''
      ,CAST('CAN_RESV_SUBSCR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAN_RESV_SUBSCR_FLAG like '@%';

   SELECT
       ''
      ,CAST('RESV_SUBSCR_START_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESV_SUBSCR_START_DT like '@%';

   SELECT
       ''
      ,CAST('FUNDRS_START_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNDRS_START_DT like '@%';

   SELECT
       ''
      ,CAST('RESV_SUBSCR_EXPIR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESV_SUBSCR_EXPIR_DT like '@%';

   SELECT
       ''
      ,CAST('FUNDRS_END_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNDRS_END_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_REG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_REG_DT like '@%';

   SELECT
       ''
      ,CAST('EQTY_REG_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQTY_REG_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_FOUND_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FOUND_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_WIND_UP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_WIND_UP_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_STOP_INT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_STOP_INT_DT like '@%';

   SELECT
       ''
      ,CAST('FUNDRS_PERIOD_24_HOUR_TXN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNDRS_PERIOD_24_HOUR_TXN_FLAG like '@%';

   SELECT
       ''
      ,CAST('OPEN_PERIOD_24_HOUR_TXN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_PERIOD_24_HOUR_TXN_FLAG like '@%';

   SELECT
       ''
      ,CAST('PROD_CLOSE_END_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_CLOSE_END_DT like '@%';

   SELECT
       ''
      ,CAST('MATU_INTACR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATU_INTACR_FLAG like '@%';

   SELECT
       ''
      ,CAST('CAP_ARRIVE_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAP_ARRIVE_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('ROLL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ROLL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FUNDRS_TO_MAX_LMT_TM_REAL_TM_FOUND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNDRS_TO_MAX_LMT_TM_REAL_TM_FOUND_FLAG like '@%';

   SELECT
       ''
      ,CAST('DEFLT_DIVDND_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DEFLT_DIVDND_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_SALES_CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_SALES_CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_CFM_INTRV_DAYS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_CFM_INTRV_DAYS like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_DEDUCT_INTRV_DAYS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_DEDUCT_INTRV_DAYS like '@%';

   SELECT
       ''
      ,CAST('REDEM_CFM_INTRV_DAYS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_CFM_INTRV_DAYS like '@%';

   SELECT
       ''
      ,CAST('REDEM_REPAY_INTRV_DAYS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_REPAY_INTRV_DAYS like '@%';

   SELECT
       ''
      ,CAST('BUY_NON_REALTM_CFM_CAP_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BUY_NON_REALTM_CFM_CAP_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_MODIF_DIVDND_MODE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_MODIF_DIVDND_MODE_FLAG like '@%';

   SELECT
       ''
      ,CAST('HUGE_REDEM_CTRL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HUGE_REDEM_CTRL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('HUGE_REDEM_RATIO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HUGE_REDEM_RATIO like '@%';

   SELECT
       ''
      ,CAST('REDEM_SHARE_DEAL_SEQ_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_SHARE_DEAL_SEQ_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_0_AMT_FOUND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_0_AMT_FOUND_FLAG like '@%';

   SELECT
       ''
      ,CAST('FOUND_DAY_SM_DAY_ALLOW_TXN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FOUND_DAY_SM_DAY_ALLOW_TXN_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_FUNDRS_END_DAY_WITHDR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_FUNDRS_END_DAY_WITHDR_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_PRE_DEAL_TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_PRE_DEAL_TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_TRAN_CONCESS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_TRAN_CONCESS_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_PLEDGE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_PLEDGE_FLAG like '@%';

   SELECT
       ''
      ,CAST('AGST_NEW_CUST_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGST_NEW_CUST_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_CUST_ASSIGN_REDEM_MODE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_CUST_ASSIGN_REDEM_MODE_FLAG like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('MIN_CUST_AGE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MIN_CUST_AGE like '@%';

   SELECT
       ''
      ,CAST('MAX_CUST_AGE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MAX_CUST_AGE like '@%';

   SELECT
       ''
      ,CAST('USE_ARRIVE_ACCT_DURAN_INTACR_ON_ACCT_ACCT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USE_ARRIVE_ACCT_DURAN_INTACR_ON_ACCT_ACCT_FLAG like '@%';

   SELECT
       ''
      ,CAST('STRUC_FIN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STRUC_FIN_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_SUBSCR_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_SUBSCR_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_REDEM_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_REDEM_FLAG like '@%';

   SELECT
       ''
      ,CAST('DIVDND_NET_VAL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DIVDND_NET_VAL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_SALES_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_SALES_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('LMT_CTRL_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LMT_CTRL_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_PERIOD_LMT_CTRL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_PERIOD_LMT_CTRL_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_CFM_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CFM_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('USE_WORKDAY_PLAN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND USE_WORKDAY_PLAN like '@%';

   SELECT
       ''
      ,CAST('PROD_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_SER_NO like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_NOTE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_NOTE like '@%';

   SELECT
       ''
      ,CAST('NET_VAL_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NET_VAL_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_NET_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_NET_VAL like '@%';

   SELECT
       ''
      ,CAST('CUM_NET_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUM_NET_VAL like '@%';

   SELECT
       ''
      ,CAST('TEN_THSNDS_PRFT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TEN_THSNDS_PRFT like '@%';

   SELECT
       ''
      ,CAST('ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('DAY_7_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DAY_7_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('LAST_DAY_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_DAY_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('LSTTRM_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LSTTRM_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('FOUND_SINCE_ANL_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FOUND_SINCE_ANL_YIELD like '@%';

   SELECT
       ''
      ,CAST('PRFT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRFT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('PUB_ISSUE_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PUB_ISSUE_FLAG like '@%';

   SELECT
       ''
      ,CAST('TXN_CALN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TXN_CALN like '@%';

   SELECT
       ''
      ,CAST('TERM_DAYS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TERM_DAYS like '@%';

   SELECT
       ''
      ,CAST('SUSTAIN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUSTAIN_FLAG like '@%';

   SELECT
       ''
      ,CAST('INVEST_COMB_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_COMB_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_REG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_REG_NO like '@%';

   SELECT
       ''
      ,CAST('INVEST_PROD_PROPTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_PROD_PROPTY_CD like '@%';

   SELECT
       ''
      ,CAST('INVEST_PROD_PRFT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_PROD_PRFT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SALES_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SALES_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_BREED_TERM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_BREED_TERM_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_MGMT_CLS_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_MGMT_CLS_FLAG like '@%';

   SELECT
       ''
      ,CAST('PROD_RISK_LVL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_RISK_LVL_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_DEAL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_DEAL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('EXCLSV_PROD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCLSV_PROD_FLAG like '@%';

   SELECT
       ''
      ,CAST('IN_BANK_IDTFY_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IN_BANK_IDTFY_NO like '@%';

   SELECT
       ''
      ,CAST('PLAN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAN_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_FEAT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_FEAT like '@%';

   SELECT
       ''
      ,CAST('PROD_MGR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_MGR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_BNCHMK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_BNCHMK like '@%';

   SELECT
       ''
      ,CAST('INTACR_BASE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INTACR_BASE_CD like '@%';

   SELECT
       ''
      ,CAST('TARGET_CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TARGET_CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_PERIOD_BIZ_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_PERIOD_BIZ_ILUS like '@%';

   SELECT
       ''
      ,CAST('FUNDRS_BEGIN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNDRS_BEGIN_DT like '@%';

   SELECT
       ''
      ,CAST('PROD_DSGR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_DSGR_NAME like '@%';

   SELECT
       ''
      ,CAST('PROD_DSGR_IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_DSGR_IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('PROD_APPRV_PSN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_APPRV_PSN_NAME like '@%';

   SELECT
       ''
      ,CAST('PROD_APPRV_PSN_IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_APPRV_PSN_IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('INVEST_MGR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_MGR_NAME like '@%';

   SELECT
       ''
      ,CAST('INVEST_MGR_IDENTITY_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_MGR_IDENTITY_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_CONT_PSN_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_CONT_PSN_NAME like '@%';

   SELECT
       ''
      ,CAST('BIZ_CONT_PSN_TEL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_CONT_PSN_TEL_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_CONT_PSN_MOBILE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_CONT_PSN_MOBILE_NO like '@%';

   SELECT
       ''
      ,CAST('BIZ_CONT_PSN_MAILBOX_ADDR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BIZ_CONT_PSN_MAILBOX_ADDR like '@%';

   SELECT
       ''
      ,CAST('CAP_INVEST_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CAP_INVEST_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_INVEST_CTRY_RGN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_INVEST_CTRY_RGN_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_BIZ_SERV_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_BIZ_SERV_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_OPER_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_OPER_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_AST_CFG_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_AST_CFG_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('PROD_MGMT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_MGMT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('INVEST_AST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_AST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_CO_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_CO_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('CO_ORG_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CO_ORG_NAME like '@%';

   SELECT
       ''
      ,CAST('INVEST_AST_CATE_RATIO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_AST_CATE_RATIO_DESC like '@%';

   SELECT
       ''
      ,CAST('CASH_PRIN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_PRIN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_PRFT_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_PRFT_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('PLAN_FUNDRS_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAN_FUNDRS_AMT like '@%';

   SELECT
       ''
      ,CAST('INVEST_PRIN_STL_DAYS_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_PRIN_STL_DAYS_PERIOD like '@%';

   SELECT
       ''
      ,CAST('INVEST_PRFT_STL_DAYS_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_PRFT_STL_DAYS_PERIOD like '@%';

   SELECT
       ''
      ,CAST('CSDTY_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CSDTY_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('DOM_AST_CSTD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOM_AST_CSTD_CD like '@%';

   SELECT
       ''
      ,CAST('DOM_AST_CSTD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DOM_AST_CSTD_NAME like '@%';

   SELECT
       ''
      ,CAST('OVERS_AST_CSTD_CTRY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVERS_AST_CSTD_CTRY like '@%';

   SELECT
       ''
      ,CAST('OVERS_AST_CSTD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OVERS_AST_CSTD_NAME like '@%';

   SELECT
       ''
      ,CAST('ISSUE_ORG_ADV_TERMI_RIGHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ISSUE_ORG_ADV_TERMI_RIGHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('CUST_REDEM_RIGHT_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_REDEM_RIGHT_FLAG like '@%';

   SELECT
       ''
      ,CAST('PROD_CRDT_ENHANC_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_CRDT_ENHANC_FLAG like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_CRDT_ENHANC_ORG_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_CRDT_ENHANC_ORG_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('AVG_ANTCPTD_CUST_YEAR_YIELD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVG_ANTCPTD_CUST_YEAR_YIELD like '@%';

   SELECT
       ''
      ,CAST('STCN_LAYERED_PROD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STCN_LAYERED_PROD_FLAG like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_LVL_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_LVL_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('OPEN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('RGL_PATRN_OPEN_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_PATRN_OPEN_PERIOD like '@%';

   SELECT
       ''
      ,CAST('OTHER_RGL_PATRN_OPEN_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OTHER_RGL_PATRN_OPEN_PERIOD like '@%';

   SELECT
       ''
      ,CAST('FIRST_OPEN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_OPEN_DT like '@%';

   SELECT
       ''
      ,CAST('HLDY_OPEN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HLDY_OPEN_FLAG like '@%';

   SELECT
       ''
      ,CAST('AVG_ANLLY_OPEN_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AVG_ANLLY_OPEN_TMS like '@%';

   SELECT
       ''
      ,CAST('OPEN_PERIOD_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_PERIOD_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_CRDT_ENHANC_FORM_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_CRDT_ENHANC_FORM_CD like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_PERIOD_OPEN_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_PERIOD_OPEN_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_PERIOD_OPEN_DAYS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_PERIOD_OPEN_DAYS like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_PERIOD_OPEN_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_PERIOD_OPEN_PERIOD like '@%';

   SELECT
       ''
      ,CAST('OPEN_PERIOD_CORP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_PERIOD_CORP like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_WORKDAY_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_WORKDAY_DT like '@%';

   SELECT
       ''
      ,CAST('FUNDRS_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FUNDRS_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_MGMT_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_MGMT_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('FIN_IBANK_EXCLSV_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_IBANK_EXCLSV_FLAG like '@%';

   SELECT
       ''
      ,CAST('SET_SHORTEST_HOLD_TERM_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SET_SHORTEST_HOLD_TERM_FLAG like '@%';

   SELECT
       ''
      ,CAST('SHORTEST_HOLD_PERIOD_AFT_ALLOW_FREE_REDEM_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHORTEST_HOLD_PERIOD_AFT_ALLOW_FREE_REDEM_FLAG like '@%';

   SELECT
       ''
      ,CAST('INVEST_MGMT_SERV_CHARGE_RATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INVEST_MGMT_SERV_CHARGE_RATE like '@%';

   SELECT
       ''
      ,CAST('FIN_MGMT_CUST_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_MGMT_CUST_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_FLOR' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_FLOR like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_CEIL like '@%';

   SELECT
       ''
      ,CAST('ACVMNT_COMP_BNCHMK_ILUS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACVMNT_COMP_BNCHMK_ILUS like '@%';

   SELECT
       ''
      ,CAST('PROVI_FOR_AGED_FIN_PROD_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROVI_FOR_AGED_FIN_PROD_FLAG like '@%';

   SELECT
       ''
      ,CAST('CLSFC_RATIO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CLSFC_RATIO like '@%';

   SELECT
       ''
      ,CAST('FIN_PROD_ESPEC_ATTR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIN_PROD_ESPEC_ATTR_CD like '@%';

   SELECT
       ''
      ,CAST('RGL_OPEN_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_OPEN_PERIOD like '@%';

   SELECT
       ''
      ,CAST('PAY_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PAY_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('ALLOW_ADV_FOUND_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_ADV_FOUND_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_ADV_TERMI_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_ADV_TERMI_FLAG like '@%';

   SELECT
       ''
      ,CAST('ALLOW_DEFLT_REDEM_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ALLOW_DEFLT_REDEM_FLAG like '@%';

   SELECT
       ''
      ,CAST('SELF_BIZ_FIN_PROD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SELF_BIZ_FIN_PROD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('CARRY_OVER_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CARRY_OVER_PERIOD like '@%';

   SELECT
       ''
      ,CAST('PERIOD_VAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PERIOD_VAL like '@%';

   SELECT
       ''
      ,CAST('FIRST_CARRY_OVER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FIRST_CARRY_OVER_DT like '@%';

   SELECT
       ''
      ,CAST('LAST_CARRY_OVER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LAST_CARRY_OVER_DT like '@%';

   SELECT
       ''
      ,CAST('TH_TM_CARRY_OVER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TH_TM_CARRY_OVER_DT like '@%';

   SELECT
       ''
      ,CAST('NEXT_EXPECT_CARRY_OVER_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEXT_EXPECT_CARRY_OVER_DT like '@%';

   SELECT
       ''
      ,CAST('PERIOD_TYPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PERIOD_TYPE like '@%';

   SELECT
       ''
      ,CAST('HLDY_POSTPN_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HLDY_POSTPN_FLAG like '@%';

   SELECT
       ''
      ,CAST('CORP_CUM_BUY_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_CUM_BUY_CEIL like '@%';

   SELECT
       ''
      ,CAST('CORP_SUBSCR_SINGLE_MAX_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_SUBSCR_SINGLE_MAX_AMT like '@%';

   SELECT
       ''
      ,CAST('CORP_SUBSCR_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_SUBSCR_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('CORP_SUBSCR_SUPP_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_SUBSCR_SUPP_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('CORP_APP_SINGLE_MAX_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_APP_SINGLE_MAX_AMT like '@%';

   SELECT
       ''
      ,CAST('CORP_APP_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_APP_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('CORP_APP_SUPP_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_APP_SUPP_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('CORP_REDEM_SINGLE_LEAST_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_REDEM_SINGLE_LEAST_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('CORP_REDEM_SINGLE_DAY_CUM_MAX_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_REDEM_SINGLE_DAY_CUM_MAX_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('CORP_REDEM_MAX_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_REDEM_MAX_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('CORP_LOW_HOLD_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CORP_LOW_HOLD_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INDV_SINGLE_DAY_CUM_BUY_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SINGLE_DAY_CUM_BUY_CEIL like '@%';

   SELECT
       ''
      ,CAST('INDV_CUM_BUY_CEIL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_CUM_BUY_CEIL like '@%';

   SELECT
       ''
      ,CAST('INDV_SUBSCR_SINGLE_MAX_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SUBSCR_SINGLE_MAX_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_SUBSCR_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SUBSCR_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_SUBSCR_SUPP_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_SUBSCR_SUPP_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_APP_SINGLE_MAX_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_APP_SINGLE_MAX_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_APP_FIRST_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_APP_FIRST_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_APP_SUPP_LOW_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_APP_SUPP_LOW_AMT like '@%';

   SELECT
       ''
      ,CAST('INDV_REDEM_SINGLE_LEAST_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_REDEM_SINGLE_LEAST_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INDV_REDEM_SINGLE_DAY_CUM_MAX_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_REDEM_SINGLE_DAY_CUM_MAX_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INDV_REDEM_MAX_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_REDEM_MAX_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INDV_LOW_HOLD_SHARES_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INDV_LOW_HOLD_SHARES_CNT like '@%';

   SELECT
       ''
      ,CAST('INSTRS_VER' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTRS_VER like '@%';

   SELECT
       ''
      ,CAST('INSTRS_VER_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INSTRS_VER_PATH like '@%';

   SELECT
       ''
      ,CAST('SHOW_IMAGE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SHOW_IMAGE like '@%';

   SELECT
       ''
      ,CAST('IMAGE_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND IMAGE_PATH like '@%';

   SELECT
       ''
      ,CAST('CUST_EQTY_BOOK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_EQTY_BOOK like '@%';

   SELECT
       ''
      ,CAST('EQTY_BOOK_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EQTY_BOOK_PATH like '@%';

   SELECT
       ''
      ,CAST('RISK_SUGST_BOOK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RISK_SUGST_BOOK like '@%';

   SELECT
       ''
      ,CAST('RISK_SUGST_BOOK_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RISK_SUGST_BOOK_PATH like '@%';

   SELECT
       ''
      ,CAST('PROD_AGT_BOOK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_AGT_BOOK like '@%';

   SELECT
       ''
      ,CAST('PROD_AGT_BOOK_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROD_AGT_BOOK_PATH like '@%';

   SELECT
       ''
      ,CAST('REDEM_AGT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_AGT like '@%';

   SELECT
       ''
      ,CAST('REDEM_AGT_PATH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_SELF_BIZ_FIN_PROD_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REDEM_AGT_PATH like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */