-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-联社公共签约表02
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_T_SIGN_XXX_02_TF
--     表中文名：联社公共签约表02
--     创建日期：2024-04-15 00:00:00
--     主键字段：
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-17 00:00:00 魏丹丹 新增
--         2024-08-26 00:00:00 魏丹丹 修改中间业务库名，增加95组
--         2024-09-10 00:00:00 魏丹丹 新增字段：摘要代码，修改客户内码/签约账户开户机构编号 的取数逻辑，增加1组
--         2024-10-17 00:00:00 魏丹丹 拆分生活缴费签约协议信息聚合 中T_SIGN_XXX，已8开始871-897，已6开始632-682



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT('CUST_NO', '01xb', 'CONTRACT', '01xb', 'ENTR_NO', '01xb', 'USER_ID', '01xb', 'USER_NAME', '01xb', 'CERT_TYPE', '01xb', 'CERT_ID', '01xb', 'TELEPHONE', '01xb', 'ADDRESS', '01xb', 'ACCT_TYPE', '01xb', 'CARD_TYPE', '01xb', 'ACCT_NO', '01xb', 'STAT', '01xb', 'CURR_NO', '01xb', 'CURR_IDEN', '01xb', 'ACT_NAME', '01xb', 'CARD_NO', '01xb', 'OPEN_BRCH', '01xb', 'SIGN_DATE', '01xb', 'SIGN_TIME', '01xb', 'SIGN_BRCH_NO', '01xb', 'SIGN_TELLER_NO', '01xb', 'UPT_DATE', '01xb', 'UPT_TIME', '01xb', 'UPT_BRCH_NO', '01xb', 'UPT_TELLER_NO', '01xb', 'TALLY_ORDER', '01xb', 'RMRK', '01xb', 'OLD_ACCT_NO', '01xb', 'PLAT_DATE') AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(
      CAST(COALESCE(CAST(CUST_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CONTRACT AS STRING),'') AS STRING), CAST(COALESCE(CAST(ENTR_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(USER_ID AS STRING),'') AS STRING), CAST(COALESCE(CAST(USER_NAME AS STRING),'') AS STRING), CAST(COALESCE(CAST(CERT_TYPE AS STRING),'') AS STRING), CAST(COALESCE(CAST(CERT_ID AS STRING),'') AS STRING), CAST(COALESCE(CAST(TELEPHONE AS STRING),'') AS STRING), CAST(COALESCE(CAST(ADDRESS AS STRING),'') AS STRING), CAST(COALESCE(CAST(ACCT_TYPE AS STRING),'') AS STRING), CAST(COALESCE(CAST(CARD_TYPE AS STRING),'') AS STRING), CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(STAT AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_IDEN AS STRING),'') AS STRING), CAST(COALESCE(CAST(ACT_NAME AS STRING),'') AS STRING), CAST(COALESCE(CAST(CARD_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(OPEN_BRCH AS STRING),'') AS STRING), CAST(COALESCE(CAST(SIGN_DATE AS STRING),'') AS STRING), CAST(COALESCE(CAST(SIGN_TIME AS STRING),'') AS STRING), CAST(COALESCE(CAST(SIGN_BRCH_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SIGN_TELLER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(UPT_DATE AS STRING),'') AS STRING), CAST(COALESCE(CAST(UPT_TIME AS STRING),'') AS STRING), CAST(COALESCE(CAST(UPT_BRCH_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(UPT_TELLER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TALLY_ORDER AS STRING),'') AS STRING), CAST(COALESCE(CAST(RMRK AS STRING),'') AS STRING), CAST(COALESCE(CAST(OLD_ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(PLAT_DATE AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('CONTRACT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CONTRACT like '@%';

   SELECT
       ''
      ,CAST('ENTR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND ENTR_NO like '@%';

   SELECT
       ''
      ,CAST('USER_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_ID like '@%';

   SELECT
       ''
      ,CAST('USER_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND USER_NAME like '@%';

   SELECT
       ''
      ,CAST('CERT_TYPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CERT_TYPE like '@%';

   SELECT
       ''
      ,CAST('CERT_ID' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CERT_ID like '@%';

   SELECT
       ''
      ,CAST('TELEPHONE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND TELEPHONE like '@%';

   SELECT
       ''
      ,CAST('ADDRESS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND ADDRESS like '@%';

   SELECT
       ''
      ,CAST('ACCT_TYPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_TYPE like '@%';

   SELECT
       ''
      ,CAST('CARD_TYPE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_TYPE like '@%';

   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('STAT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT like '@%';

   SELECT
       ''
      ,CAST('CURR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_IDEN' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_IDEN like '@%';

   SELECT
       ''
      ,CAST('ACT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND ACT_NAME like '@%';

   SELECT
       ''
      ,CAST('CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND CARD_NO like '@%';

   SELECT
       ''
      ,CAST('OPEN_BRCH' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND OPEN_BRCH like '@%';

   SELECT
       ''
      ,CAST('SIGN_DATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_DATE like '@%';

   SELECT
       ''
      ,CAST('SIGN_TIME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TIME like '@%';

   SELECT
       ''
      ,CAST('SIGN_BRCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_BRCH_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_TELLER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TELLER_NO like '@%';

   SELECT
       ''
      ,CAST('UPT_DATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND UPT_DATE like '@%';

   SELECT
       ''
      ,CAST('UPT_TIME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND UPT_TIME like '@%';

   SELECT
       ''
      ,CAST('UPT_BRCH_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND UPT_BRCH_NO like '@%';

   SELECT
       ''
      ,CAST('UPT_TELLER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND UPT_TELLER_NO like '@%';

   SELECT
       ''
      ,CAST('TALLY_ORDER' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND TALLY_ORDER like '@%';

   SELECT
       ''
      ,CAST('RMRK' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND RMRK like '@%';

   SELECT
       ''
      ,CAST('OLD_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND OLD_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PLAT_DATE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_T_SIGN_XXX_02_TF 
 WHERE PT_DT = '${process_date}'
   AND PLAT_DATE like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */