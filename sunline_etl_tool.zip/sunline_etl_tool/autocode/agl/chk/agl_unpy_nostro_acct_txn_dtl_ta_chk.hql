-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-EVI-银联往账交易明细聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA
--     表中文名：银联往账交易明细聚合
--     创建日期：2024-06-14 00:00:00
--     主键字段：TOTAL_TXN_SER_NO, SUB_TXN_SER_NO, TXN_TYPE_CD, TXN_DT, TXN_TM_STAMP
--     归属层次：AGL-EVI
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：王穆军
--     时间粒度：None
--     保留周期：None
--     描述信息：行内对接银联系统的往账交易明细
--     更新记录：
--         2024-06-14 00:00:00 wangmujun new
--         2024-09-05 00:00:00 王穆军 新增字段，同步设计20240902
--         2024-09-13 00:00:00 王穆军  修改主键重复去重
--         2024-09-18 00:00:00 王穆军 修改子查询，新建临时表



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(TOTAL_TXN_SER_NO, SUB_TXN_SER_NO, TXN_TYPE_CD, TXN_DT, TXN_TM_STAMP) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(TOTAL_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(SUB_TXN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_TYPE_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_DT AS STRING),'') AS STRING), CAST(COALESCE(CAST(TXN_TM_STAMP AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('TOTAL_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TOTAL_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('TXN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_DT like '@%';

   SELECT
       ''
      ,CAST('TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('TXN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_AMT like '@%';

   SELECT
       ''
      ,CAST('SUB_TXN_IN_BANK_COMM_FEE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUB_TXN_IN_BANK_COMM_FEE like '@%';

   SELECT
       ''
      ,CAST('REFUND_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND REFUND_AMT like '@%';

   SELECT
       ''
      ,CAST('TXN_REM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND TXN_REM like '@%';

   SELECT
       ''
      ,CAST('UNPY_BIZ_MCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_BIZ_MCLS_CD like '@%';

   SELECT
       ''
      ,CAST('UNPY_BIZ_SCLS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND UNPY_BIZ_SCLS_CD like '@%';

   SELECT
       ''
      ,CAST('CORE_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND CORE_SER_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYER_ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYER_ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('BANK_INTER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_INTER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('BANK_INTER_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND BANK_INTER_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('INTER_ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND INTER_ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NO ' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NO  like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('PAYEE_ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND PAYEE_ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('START_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('START_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND START_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_CNAPS_CODE' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_CNAPS_CODE like '@%';

   SELECT
       ''
      ,CAST('RECV_BANK_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RECV_BANK_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_OPEN_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_OPEN_DT like '@%';

   SELECT
       ''
      ,CAST('MERCHT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('MERCHT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_NAME like '@%';

   SELECT
       ''
      ,CAST('MERCHT_ABB' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_ABB like '@%';

   SELECT
       ''
      ,CAST('MERCHT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('MERCHT_MCC_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND MERCHT_MCC_CD like '@%';

   SELECT
       ''
      ,CAST('SUPER_MERCHT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND SUPER_MERCHT_NO like '@%';

   SELECT
       ''
      ,CAST('RETURN_INFO_DESC' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND RETURN_INFO_DESC like '@%';

   SELECT
       ''
      ,CAST('EQUIP_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('EQUIP_TXN_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND EQUIP_TXN_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_UPDATE_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_UNPY_NOSTRO_ACCT_TXN_DTL_TA 
 WHERE PT_DT = '${process_date}'
   AND FINAL_UPDATE_TM_STAMP like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */