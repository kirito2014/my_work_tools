-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人组合存款协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_COMB_DPSIT_AGT_INFO_TF
--     表中文名：个人组合存款协议信息聚合
--     创建日期：2024-05-07 00:00:00
--     主键字段：SIGN_SER_NO, CURR_ACCT_NO, CURR_CD, CASH_RMT_CD, COMB_DPSIT_SIGN_STATUS_CD, COMB_DPSIT_PROD_TYPE_CD
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：魏丹丹
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-05-07 00:00:00 吉云龙 创建
--         2024-10-16 00:00:00 魏丹丹 因长度限制字段英文名修改，CUST_IN_CD来源取数逻辑，新增字段：灵活定期余额，第三组：组合存款业务类型代码，组合存款产品类型代码，签约渠道代码 来源逻辑调整



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(SIGN_SER_NO, CURR_ACCT_NO, CURR_CD, CASH_RMT_CD, COMB_DPSIT_SIGN_STATUS_CD, COMB_DPSIT_PROD_TYPE_CD) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(SIGN_SER_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_ACCT_NO AS STRING),'') AS STRING), CAST(COALESCE(CAST(CURR_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(CASH_RMT_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(COMB_DPSIT_SIGN_STATUS_CD AS STRING),'') AS STRING), CAST(COALESCE(CAST(COMB_DPSIT_PROD_TYPE_CD AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('SIGN_CARD_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CARD_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_SER_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_SER_NO like '@%';

   SELECT
       ''
      ,CAST('CURR_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('RGL_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('EACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EACCT_NO like '@%';

   SELECT
       ''
      ,CAST('EXCH_GATHER_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND EXCH_GATHER_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_NO like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_BIZ_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_BIZ_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_PROD_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_PROD_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_PROD_NO_1' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_PROD_NO_1 like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_PROD_NO_2' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_PROD_NO_2 like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_PROD_NO_3' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_PROD_NO_3 like '@%';

   SELECT
       ''
      ,CAST('CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_ACCT_REDT_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_ACCT_REDT_AMT like '@%';

   SELECT
       ''
      ,CAST('MIN_GUAR_RGL_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MIN_GUAR_RGL_BAL like '@%';

   SELECT
       ''
      ,CAST('FLEXI_RGL_BAL' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FLEXI_RGL_BAL like '@%';

   SELECT
       ''
      ,CAST('RGL_ACCT_TRNIN_MIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_ACCT_TRNIN_MIN_AMT like '@%';

   SELECT
       ''
      ,CAST('CURR_ACCT_TRNOUT_MIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_ACCT_TRNOUT_MIN_AMT like '@%';

   SELECT
       ''
      ,CAST('RGL_ACCT_TRNOUT_SIGN_MIN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_ACCT_TRNOUT_SIGN_MIN_AMT like '@%';

   SELECT
       ''
      ,CAST('GDPSIT_TRNIN_SIGN_AMT_CNT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GDPSIT_TRNIN_SIGN_AMT_CNT like '@%';

   SELECT
       ''
      ,CAST('GDPSIT_REDT_INT_DEAL_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GDPSIT_REDT_INT_DEAL_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('GDPSIT_TURN_BACK_INT_DEAL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GDPSIT_TURN_BACK_INT_DEAL_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PERIOD like '@%';

   SELECT
       ''
      ,CAST('CTG_PERIOD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CTG_PERIOD_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('GTC_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GTC_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('COMB_DPSIT_SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND COMB_DPSIT_SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('MATU_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MATU_DT like '@%';

   SELECT
       ''
      ,CAST('TURN_BACK_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TURN_BACK_DT like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_DT like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_TBCA_FLAG' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_TBCA_FLAG like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_MAIN_ACCT_BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_MAIN_ACCT_BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_MAIN_ACCT_HANDLE_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_MAIN_ACCT_HANDLE_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_MAIN_ACCT_ACCT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_MAIN_ACCT_ACCT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('HANDLE_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HANDLE_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('MKTING_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MKTING_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_NAME like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('CANCEL_CONT_AGENT_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANCEL_CONT_AGENT_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('SETUP_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_DT like '@%';

   SELECT
       ''
      ,CAST('SETUP_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('SETUP_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SETUP_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TM_STAMP' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TM_STAMP like '@%';

   SELECT
       ''
      ,CAST('FINAL_MODIF_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_COMB_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND FINAL_MODIF_TELR_NO like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */