-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-PKA-个人特色定期存款协议信息聚合
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF
--     表中文名：个人特色定期存款协议信息聚合
--     创建日期：2024-04-23 00:00:00
--     主键字段：ACCT_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL
--     分析人员：龙耀超
--     时间粒度：日
--     保留周期：None
--     描述信息：None
--     更新记录：
--         2024-04-23 00:00:00 龙耀超 创建



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */

/* 2.3 put data into target table DQC_03 */
SELECT
       ''
      ,CAST(CONCAT(ACCT_NO) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF
 WHERE PT_DT = '${process_date}'
   AND CONCAT(     CAST(COALESCE(CAST(ACCT_NO AS STRING),'') AS STRING)
) = '';

/* 2.4 put data into target table DQC_04 */


   SELECT
       ''
      ,CAST('ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('ACCT_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND ACCT_NAME like '@%';

   SELECT
       ''
      ,CAST('SIGN_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('SIGN_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_STATUS_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_BIZ_CATEGORY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_BIZ_CATEGORY_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PROD_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PROD_NAME like '@%';

   SELECT
       ''
      ,CAST('AGREE_ACCT_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGREE_ACCT_NO like '@%';

   SELECT
       ''
      ,CAST('RESV_REDT_MATU_INDICATE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RESV_REDT_MATU_INDICATE_CD like '@%';

   SELECT
       ''
      ,CAST('AGREE_REDT_DEDUCT_TMS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGREE_REDT_DEDUCT_TMS like '@%';

   SELECT
       ''
      ,CAST('GIFDI_INTRV_MONTHS' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND GIFDI_INTRV_MONTHS like '@%';

   SELECT
       ''
      ,CAST('AGREE_DRAW_DPSIT_IN_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGREE_DRAW_DPSIT_IN_AMT like '@%';

   SELECT
       ''
      ,CAST('CDPSIT_CANCEL_CONT_TYPE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CDPSIT_CANCEL_CONT_TYPE_CD like '@%';

   SELECT
       ''
      ,CAST('NEXT_EXC_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEXT_EXC_DT like '@%';

   SELECT
       ''
      ,CAST('RGL_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('RGL_CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND RGL_CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('DPSIT_PERIOD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND DPSIT_PERIOD like '@%';

   SELECT
       ''
      ,CAST('CURR_CURR_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CURR_CD like '@%';

   SELECT
       ''
      ,CAST('CURR_CASH_RMT_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CURR_CASH_RMT_CD like '@%';

   SELECT
       ''
      ,CAST('AGREE_REDT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AGREE_REDT_DT like '@%';

   SELECT
       ''
      ,CAST('SIGN_CONTR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SIGN_CONTR_DT like '@%';

   SELECT
       ''
      ,CAST('MODIF_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODIF_DT like '@%';

   SELECT
       ''
      ,CAST('LIFTED_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LIFTED_DT like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOCTYP_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOCTYP_CD like '@%';

   SELECT
       ''
      ,CAST('OPERR_DOC_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPERR_DOC_NO like '@%';

   SELECT
       ''
      ,CAST('OPERR_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPERR_NAME like '@%';

   SELECT
       ''
      ,CAST('TAX_TAX_FREE_BIL_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND TAX_TAX_FREE_BIL_NO like '@%';

   SELECT
       ''
      ,CAST('PROOF_SCH_NAME' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PROOF_SCH_NAME like '@%';

   SELECT
       ''
      ,CAST('CANC_ACCT_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CANC_ACCT_DT like '@%';

   SELECT
       ''
      ,CAST('NOTICE_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_NO like '@%';

   SELECT
       ''
      ,CAST('NOTICE_BREED_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_BREED_CD like '@%';

   SELECT
       ''
      ,CAST('CUST_IN_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND CUST_IN_CD like '@%';

   SELECT
       ''
      ,CAST('NOTICE_MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_MODE_CD like '@%';

   SELECT
       ''
      ,CAST('MODE_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND MODE_CD like '@%';

   SELECT
       ''
      ,CAST('NOTICE_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_AMT like '@%';

   SELECT
       ''
      ,CAST('NOTICE_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NOTICE_DT like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_AMT like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_CHNL_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_CHNL_CD like '@%';

   SELECT
       ''
      ,CAST('SUBSCR_DT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND SUBSCR_DT like '@%';

   SELECT
       ''
      ,CAST('INT_PTY_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND INT_PTY_CD like '@%';

   SELECT
       ''
      ,CAST('NEXT_PAY_INT_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND NEXT_PAY_INT_DAY like '@%';

   SELECT
       ''
      ,CAST('PRE_PAY_INT_DAY' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND PRE_PAY_INT_DAY like '@%';

   SELECT
       ''
      ,CAST('LARGE_AMT_DPSTRCP_ACRDG_PERIOD_PAY_INT_CUM_AMT' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LARGE_AMT_DPSTRCP_ACRDG_PERIOD_PAY_INT_CUM_AMT like '@%';

   SELECT
       ''
      ,CAST('LARGE_AMT_DPSTRCP_ACRDG_PERIOD_PAY_INT_TMS_CUM' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND LARGE_AMT_DPSTRCP_ACRDG_PERIOD_PAY_INT_TMS_CUM like '@%';

   SELECT
       ''
      ,CAST('BELONG_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND BELONG_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('STAT_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND STAT_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('OPER_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND OPER_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('AUTH_TELR_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND AUTH_TELR_NO like '@%';

   SELECT
       ''
      ,CAST('HANDLE_ORG_NO' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND HANDLE_ORG_NO like '@%';

   SELECT
       ''
      ,CAST('REC_STATUS_CD' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM AGL.AGL_INDV_CHARACT_RGL_DPSIT_AGT_INFO_TF 
 WHERE PT_DT = '${process_date}'
   AND REC_STATUS_CD like '@%';




/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */

/* 3.1 drop check result temp tables if exists */