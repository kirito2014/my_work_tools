# ae_sql_generator.py

"""
作者: gsp
日期: 20240301
功能: 渲染SDM输出AE层SQL脚本。
日志:
    20240301 gsp v1.0
"""

import os
import sys
import openpyxl

from jinja2 import Environment, FileSystemLoader
from package.utils import excelhelper, filehelper
from package.ae import ae_sdm_reader, metadata_extractor



def render(file, info):
    filepath, filename = os.path.split(file)
    env = Environment(loader=FileSystemLoader(filepath))
    template = env.get_template(filename)
    content = template.render(info)
    return content.replace("\n    \n", "\n").replace("\n        \n", "\n")


def generate_ae_sql(file_path,generate_sql_file):
    etl_home = os.environ["ETL_HOME"]
    
    # 打开 Excel 文件
    workbook = openpyxl.load_workbook(file_path)

    # 获取 index sheet 页
    index_sheet = workbook['index']

    # 遍历 A 列和 B 列的数据，从第三行开始
    for row in index_sheet.iter_rows(min_row=3, values_only=True):
        data_a = row[1] # Serial Number
        data_b = row[2] # sheet_name
        data_c = row[3] # table_name
        data_d = row[12] # is_auto_create_script
        data_e = row[13] # algorithm_template

        
        # 判断 自动生成标志 列的值是否为 Y
        if data_d == 'Y':
            # 判断 算法模板 列的值是否合法
            algorithm_allowed_values = {'AGL-PKA', 'AGL-EVI', 'AGL-EVP', 'AGL-STF', 'AGL-DEF'}
            if data_e not in algorithm_allowed_values:
                print("算法错误，未知算法类型：%s！" % data_e)
                return
            if data_e == 'AGL-PKA':
                print("模板类型：主档表-全量快照")
                algorithm_suffix = "agl_pka"
            if data_e == 'AGL-EVI':
                print("模板类型：流水表-增量流水")
                algorithm_suffix = "agl_evi"
            if data_e == 'AGL-EVP':
                print("模板类型：流水表-区间流水")
                algorithm_suffix = "agl_evp"
            if data_e == 'AGL-STF':
                print("模板类型：拉链表-全量拉链")
                algorithm_suffix = "agl_stf"
            if data_e == 'AGL-DEF':
                print("模板类型：普通表-默认算法")
                algorithm_suffix = "agl_def"
            # 根据 A 列的数据获取对应的 sheet 页
            if data_b in workbook.sheetnames:
                sheet_name = data_b
                table_name = data_c.lower()
                generate_sql_file.append(table_name)
                template_dml_file = "%s/templage/ae/ae_template_dml_%s.hql" % (etl_home, algorithm_suffix)
                template_ddl_file = "%s/templage/ae/ae_template_ddl_%s.hql" % (etl_home, algorithm_suffix)
                template_chk_file = "%s/templage/ae/ae_template_check_script.hql" % etl_home
                sdm_excel = excelhelper.Xlsx(file_path)
                sdm_dict = sdm_excel.data
                sdm_martix = sdm_dict[sheet_name]
                ae_sdm = ae_sdm_reader.AeSDM(sdm_martix)
                table_metadata, table_metadata_pk_y, table_metadata_pk_n = metadata_extractor.extract_table_metadata(file_path, 'rem-数据字典', data_c)
                #print(table_metadata_pk_y) 
                ae_sdm.sdm['metadata_all'] = table_metadata
                ae_sdm.sdm['metadata_pk_y'] = table_metadata_pk_y
                ae_sdm.sdm['metadata_pk_n'] = table_metadata_pk_n
                #print("Test metadata", table_metadata)
                #print("ae_sdm details",ae_sdm.sdm['basic_info'])
                #print("metadata",ae_sdm.sdm['metadata'])
                #print("basic_info", ae_sdm.sdm['basic_info'])
                if ae_sdm:
                    output_ae_sdm_file = "%s/autocode/agl/dml/%s_pc.hql" % (etl_home, table_name)
                    output_ae_ddl_file = "%s/autocode/agl/ddl/createtable_%s.hql" % (etl_home, table_name)
                    output_ae_chk_file = "%s/autocode/agl/chk/%s_chk.hql" % (etl_home, table_name)
                    contnent_ae_sdm = render(template_dml_file, ae_sdm.sdm)
                    contnent_cea_ddl = render(template_ddl_file, ae_sdm.sdm)
                    contnent_chk_result = render(template_chk_file, ae_sdm.sdm)
                    filehelper.write_file(output_ae_sdm_file, contnent_ae_sdm)
                    filehelper.write_file(output_ae_ddl_file, contnent_cea_ddl)
                    filehelper.write_file(output_ae_chk_file, contnent_chk_result)
                    print("Render SQL file for sheet %s: %s done.\nFiles' Location:" % (data_a, sheet_name))
                    print("DDL SQL file Location: %s" % output_ae_ddl_file)
                    print("DML SQL file Location: %s" % output_ae_sdm_file)
                    print("CHK SQL file Location: %s\n" % output_ae_chk_file)
                else:
                    print("Unable to render SQL file for sheet: %s" % sheet_name)

    # 关闭 Excel 文件
    workbook.close()
