# metadata_extractor.py

"""
作者: gsp
日期: 20240301
功能: 读取SDM模板的数据，从 rem-数据字典 sheet页获取每张模型表的数据字典。
日志:
    20240301 gsp v1.0
"""

import openpyxl
from collections import OrderedDict




class TableMetadata:
    def __init__(self, table_data):
        self.table_data = table_data
        #在初始化时检查is_primary_key，并根据此设置primary_key和no_primary_key
        if table_data.get('is_primary_key') == 'Y':
            self.primary_key = table_data.get('field_english_name')
            self.no_primary_key = None
        elif table_data.get('is_primary_key') == 'N':
            self.no_primary_key = table_data.get('field_english_name')
            self.primary_key = None
    
    def __getattr__(self, name):
        if name in self.table_data:
            return self.table_data[name]
        else:
            raise AttributeError(f"'TableMetadata' object has no attribute '{name}'")

#新增两个类
class TableMetadata_PK_Y(TableMetadata):
    def __init__(self, table_data):
        self.table_data = table_data
        if table_data['is_primary_key'] == 'Y':
            super().__init__(table_data)
        else:
            raise ValueError("Primary must be 'Y' for TableMetadata_PK_Y")

class TableMetadata_PK_N(TableMetadata):
    def __init__(self, table_data):
        self.table_data = table_data
        if table_data['is_primary_key'] == 'N':
            super().__init__(table_data)
        else:
            raise ValueError("Primary must be 'N' for TableMetadata_PK_N")
    


def extract_table_metadata(file_path, sheet_name, tablename=None):
    wb = openpyxl.load_workbook(file_path)
    sheet = wb[sheet_name]

    table_metadata_list = []
    table_metadata_pk_y_list = []
    table_metadata_pk_n_list = []

    for row in sheet.iter_rows(min_row=2, values_only=True):
        table_english_name = row[1]

        if tablename and table_english_name == tablename:
            field_data = {
                'table_english_name': row[1],
                'table_chinese_name': row[2],
                'field_serial_number': row[3],
                'field_english_name': row[4],
                'field_chinese_name': row[5],
                'field_type_scale': row[6],
                'is_null': row[7],
                'is_distributed_key': row[8],
                'is_primary_key': row[9]
            }
            table_metadata = TableMetadata(field_data)
            table_metadata_list.append(table_metadata)
            if field_data['is_primary_key'] == 'Y':
                table_metadata_pk_y = TableMetadata_PK_Y(field_data)
                table_metadata_pk_y_list.append(table_metadata_pk_y)
            elif field_data['is_primary_key'] == 'N':
                table_metadata_pk_n = TableMetadata_PK_N(field_data)
                table_metadata_pk_n_list.append(table_metadata_pk_n)

    return table_metadata_list, table_metadata_pk_y_list, table_metadata_pk_n_list

