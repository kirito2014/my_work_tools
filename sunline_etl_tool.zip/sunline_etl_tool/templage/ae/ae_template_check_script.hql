{% set tblnm = basic_info.table_name -%}
{% set table_schema = 'AGL' -%}
-- 模板名称: 聚合层-DQC质量检查脚本。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024年8月16日10:21:03
-- 脚本类型: DML
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     分析人员：{{basic_info.analyse_user}}
--     时间粒度：{{basic_info.data_interval}}
--     保留周期：{{basic_info.date_retention}}
--     描述信息：{{basic_info.table_comment}}
--     更新记录：
           {%- for record in update_record %}
               {%- if record.update_date is not none  %}
--         {{record.update_date}} {{record.update_user}} {{record.update_comment}}
               {%- endif %}
           {%- endfor %}



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop check result temp tables if exists */

/* 1.2 create check result temp tables  */

/* 2.1 put data into target table DQC_01 */
{#- 主程序 #}
{#- 记录数 #}
SELECT
       ''
      ,'REC_CNT'
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS REC_CNT -- 记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}
 WHERE PT_DT = '${process_date}';

/* 2.2 put data into target table DQC_02 */
{#- 是否主键重复 #}

/* 2.3 put data into target table DQC_03 */
{#- 主键是否有空 #}
SELECT
       ''
      ,CAST(CONCAT({% if not basic_info.table_pk_column %}
       {%- for m in metadata_all %}
          {{-"'"~m.field_english_name}}'
          {%- if not loop.last %}, '01xb', {% endif %}
       {%- endfor %}
	   {%- else %}
	   {%- for pk in basic_info.table_pk_column %}
            {{-pk}}
            {%- if not loop.last %}, {% endif %}
       {%- endfor %}
	   {%- endif %}) AS STRING)
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS PK_NULL_CNT -- 主键为空记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}
 WHERE PT_DT = '${process_date}'
   AND CONCAT(
 {%- if not basic_info.table_pk_column %}
 {% for m in metadata_all -%}
    {% if basic_info.table_name|upper is not none -%}
        {%- if not loop.first %}, {% else %}     {% endif -%}
        {{"CAST(COALESCE(CAST("~m.field_english_name|upper~" AS STRING),'') AS STRING)"}}
    {%- endif -%}
 {%- endfor %}
 {%- else %}
 {%- for pk in basic_info.table_pk_column %}
	  {%- if not loop.first %}, {% else %}     {% endif -%}
	  {{"CAST(COALESCE(CAST("~pk|upper~" AS STRING),'') AS STRING)"}}
 {%- endfor %}
 {%- endif %}
) = '';

/* 2.4 put data into target table DQC_04 */
{#- 码值异常 #}

{% for m in metadata_all %}
   {% if basic_info.table_name|upper is not none -%}
SELECT
       ''
      ,CAST('{{m.field_english_name|upper}}' AS STRING) AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS DECIMAL(28,0)) AS EXCEP_CD_VAL_CNT -- 异常码值记录数
      ,''
      ,'999000'
      ,Current_Date()
  FROM {{table_schema|upper}}.{{basic_info.table_name|upper}} 
 WHERE PT_DT = '${process_date}'
   AND {{m.field_english_name|upper}} like '@%';

   {%- endif %}
{% endfor %}



/* 2.5 put all data into final target table T99_CHECK_RESULT_TF */
{#- 把数据插入目标表 #}

/* 3.1 drop check result temp tables if exists */
{#- 结束前删除临时表 #}
