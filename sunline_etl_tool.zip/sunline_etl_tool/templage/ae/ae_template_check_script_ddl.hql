-- 模板名称: 聚合层-DQC质量检查-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: AGL-COMM-检查结果表
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-15 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：AGL_S01_IMP_LC_INFO_TF
--     表中文名：进口信用证信息聚合表
--     创建日期：2023-12-20 00:00:00
--     主键字段：LC_NO
--     归属层次：AGL-PKA
--     归属主题：一级领域
--     库/模式：AGL_CORP
--     时间粒度：日
--     描述信息：None



/* 1.1 drop table if exists */
DROP TABLE IF EXISTS AGL.T99_CHECK_RESULT_TF;


/* 1.2  create check result table  */
CREATE TABLE AGL.T99_CHECK_RESULT_TF (
     LVL STRING COMMENT '归属层次'
    ,SUBJ STRING COMMENT '归属主题'
    ,TASK_NAME STRING COMMENT '作业名'
    ,TASK_ALIAS STRING COMMENT '作业别名'
    ,DB_NAME STRING COMMENT '库名'
    ,TAB_EN_NAME STRING COMMENT '表英文名'
    ,TAB_CN_NAME STRING COMMENT '表中文名'
    ,REC_CNT DECIMAL(28,0) COMMENT '记录数'
    ,PK STRING COMMENT '主键'
    ,IS_PK_DUP STRING COMMENT '是否主键重复'
    ,PK_HAVE_NULL STRING COMMENT '主键是否有空'
    ,CD_VAL_EXCEP STRING COMMENT '码值异常'
    ,TM_GRLTY STRING COMMENT '时间粒度'
    ,CREATE_DT STRING COMMENT '创建日期'
)
USING ORC
COMMENT '检查结果表'
PARTITIONED BY (
     JOB_CD STRING COMMENT '作业名称'
    ,PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;




