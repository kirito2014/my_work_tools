{% set table_schema='AGL' -%}
-- 模板名称: 聚合层-拉链表-全量拉链脚本。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 10:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     分析人员：{{basic_info.analyse_user}}
--     时间粒度：{{basic_info.data_interval}}
--     保留周期：{{basic_info.date_retention}}
--     描述信息：{{basic_info.table_comment}}
--     更新记录：
           {%- for record in update_record %}
               {%- if record.update_date is not none  %}
--         {{record.update_date}} {{record.update_user}} {{record.update_comment}}
               {%- endif %}
           {%- endfor %}



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.1 drop bf temp table */
{#- 删除bf上日数据临时表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{basic_info.table_name|upper}}_BF;

/* 1.2 create bf temp table contain data  */
{#- 创建bf上日数据临时表 #}
CREATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_BF
USING ORC
COMMENT '{{basic_info.table_cn_name}}-bf上日数据临时表'
OPTIONS (compression 'zstd')
AS
SELECT
{% for m in metadata %}
    {%- if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif %}
{%- endfor 
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,ETL_TIMESTAMP -- 时间戳
    ,CREATE_DT -- 创建日期
    ,UPDATE_DT -- 最近更新日期
    ,DEL_F -- 删除标志
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}} WHERE PT_DT = CAST('${process_date}' AS DATE) - 1 ;

/* 2.1 drop main temp table */
{#- 删除默认主临时表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;

/* 2.2 create main temp table  */
{#- 创建主临时表 #}
CREATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM
USING ORC 
COMMENT '{{basic_info.table_cn_name}}-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
{% for m in metadata %}
    {%- if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif %}
{%- endfor %}
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,ETL_TIMESTAMP -- 时间戳
    ,CREATE_DT -- 创建日期
    ,UPDATE_DT -- 最近更新日期
    ,DEL_F -- 删除标志
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}} WHERE 0=1 ;


/* 2.3 truncate main temp table  */
{#- 清空主临时表 #}
TRUNCATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;

/* 3.1 get today data */
{#- 循环输出每一组字段映射的处理规则 #}
{%- for cm in column_mapping %}
-- =============={{cm.id}}==============
-- {{cm.table_cn_name}}
{%- if 'Y' in cm.template_table_type %}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{cm.table_name|upper}};

CREATE TABLE {{table_schema|upper}}.{{cm.table_name|upper}} (
{% for m in cm.mapping %}
    {%- if m.tgt_column_name is not none %}
        {%- if not loop.first %}, {% else %}      {% endif %}
        {{-m.tgt_column_name}} {{m.tgt_column_type}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
    ,ETL_TIMESTAMP STRING -- 时间戳
    ,CREATE_DT STRING -- 创建日期
    ,UPDATE_DT STRING -- 最近更新日期
    ,DEL_F STRING -- 删除标志
)
USING ORC
COMMENT '{{cm.table_cn_name}}'
OPTIONS (compression 'zstd')
;
{%- endif %}

INSERT INTO TABLE {{table_schema|upper}}.{{cm.table_name|upper}}(
{% for m in cm.mapping %}
    {%- if m.tgt_column_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.tgt_column_name}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
    ,ETL_TIMESTAMP -- 时间戳
    ,CREATE_DT -- 创建日期
    ,UPDATE_DT -- 最近更新日期
    ,DEL_F -- 删除标志
)
SELECT
{% for m in cm.mapping %}
    {%- if m.mapping_rule is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
            {{-m.mapping_rule}} AS {{m.tgt_column_name}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- 时间戳
    ,'${process_date}' AS CREATE_DT -- 创建日期
    ,'${process_date}' AS UPDATE_DT -- 最近更新日期
    ,P1.DEL_F AS DEL_F -- 删除标志
FROM 
{%- for tj in cm.table_join %}
{% if tj.join_type is not none %}{{tj.join_type}} {% endif %}
{%- if tj.src_schema is not none %}{{-tj.src_schema}}.{% endif %}
{{-tj.src_table_name}} AS {{tj.src_table_alias}} -- {{tj.src_table_cn_name}}
{% if tj.join_condition is not none %}       ON {{tj.join_condition}} {% endif %}
{%- endfor %}
{#- 以下三项均是有值时才输出 #}
{%- if cm.where is not none %}
WHERE {{cm.where}}
{%- endif %}
{%- if cm.group_by is not none %}
GROUP BY {{cm.group_by}}
{%- endif %}
{%- if cm.order_by is not none %}
ORDER BY {{cm.order_by}}
{%- endif %}
;
{%- endfor %}

/* 4.1 drop target table's today partition */
{#- 手工新增目标表当天数据分区，确保遗留数据可以被正确清除 #}
ALTER TABLE {{table_schema}}.{{basic_info.table_name}} ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
{#- 清除目标表当天分区数据 #}
ALTER TABLE {{table_schema}}.{{basic_info.table_name}} DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 4.2 put data into target table */
{#- 把数据插入目标表 #}
INSERT INTO {{table_schema|upper}}.{{basic_info.table_name|upper}} PARTITION(PT_DT = '${process_date}')
/* 
新旧数据关联不上
更新cre_dt
更新upd_dt

新旧数据可以关联上且数据无变化
继承cre_dt
继承upd_dt

新旧数据可以关联上且数据变化
继承cre_dt
更新upd_dt
 */
SELECT 
{% for m in metadata -%}
    {% if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif -%}
        TM.{{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif -%}
{%- endfor %}
    ,TM.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
	,TM.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
	,TM.GRP_SER_NO AS GRP_SER_NO -- 组序号
	,TM.ETL_TIMESTAMP AS ETL_TIMESTAMP -- 时间戳
    ,CASE WHEN BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上,更新cre_dt
     ELSE BF.CREATE_DT -- 新旧数据可以关联上,继承cre_dt
     END AS CREATE_DT -- 创建日期
    ,CASE WHEN BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上,更新upd_dt
     WHEN BF.PT_DT IS NOT NULL AND (
     {% for m in metadata %}
         {%- if m.is_primary_key is not none %}
         {% set found_n = false %}
             {%- if m.is_primary_key == 'N' and not found_n -%}
                 {{"AND TM."~m.field_english_name|upper}} = {{"BF."~m.field_english_name|upper}}
                 {%- set found_n = true -%}
             {%- else -%}
                 {{"TM."~m.field_english_name|upper}} = {{"BF."~m.field_english_name|upper}}
             {%- endif -%}
         {% endif %}
     {%- endfor %}
     ) THEN BF.UPDATE_DT -- 新旧数据可以关联上且数据无变化,继承upd_dt
     ELSE '${process_date}' END -- 新旧数据可以关联上且数据变化,更新upd_dt
     AS UPDATE_DT -- 最近更新日期
    ,TM.DEL_F AS DEL_F -- 删除标志
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM TM
LEFT JOIN {{table_schema|upper}}.{{basic_info.table_name|upper}}_BF BF
ON (
{% for m in metadata %}
    {%- if m.is_primary_key is not none %}
    {% set found_y = false %}
        {%- if m.is_primary_key == 'Y' and not found_y %}
            {{"TM."~m.field_english_name|upper}} = {{"BF."~m.field_english_name|upper}} -- {{m.field_chinese_name}} 主键关联
            {%- set found_y = true -%}
        {%- else -%}
            {{"AND TM."~m.field_english_name|upper}} = {{"BF."~m.field_english_name|upper}} -- {{m.field_chinese_name}} 主键关联
        {% endif -%}
    {% endif %}
{%- endfor %}
)


/* 5.1 drop temp table */
{#- 删除所有临时表 #}
DROP TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;
DROP TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_BF;
{%- for cm in column_mapping %}
{%- if 'Y' in cm.template_table_type %}
DROP TABLE {{table_schema|upper}}.{{cm.table_name|upper}};
{%- endif %}
{%- endfor %}

