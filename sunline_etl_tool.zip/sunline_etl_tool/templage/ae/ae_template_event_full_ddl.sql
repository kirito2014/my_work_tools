{% set tblnm = basic_info.table_name -%}
{% set table_schema = '' -%}
{% if tblnm.startswith('AGL_S01') -%}
    {% set table_schema='AGL_CORP' -%}
{% elif tblnm.startswith('AGL_S02') -%}
    {% set table_schema='AGL_RTLB' -%}
{% elif tblnm.startswith('AGL_S03') -%}
    {% set table_schema='AGL_LOAN' -%}
{% elif tblnm.startswith('AGL_S04') -%}
    {% set table_schema='AGL_ASSM' -%}
{% elif tblnm.startswith('AGL_S05') -%}
    {% set table_schema='AGL_FINM' -%}
{% elif tblnm.startswith('AGL_S06') -%}
    {% set table_schema='AGL_OPRS' -%}
{% elif tblnm.startswith('AGL_S07') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S08') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S09') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S10') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S11') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S12') -%}
    {% set table_schema='AGL_COMM' -%}
{% else -%}
    {% set table_schema='AGL_COMM' -%}
{% endif -%}
-- 模板名称: 聚合层-流水表DDL。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-01-24 17:01:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     时间粒度：{{basic_info.data_interval}}
--     描述信息：{{basic_info.table_comment}}





/* 1.1 drop table if exists */
{#- 建表前删除已存在旧表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}${version_num}.{{basic_info.table_name|upper}};


/* 1.2 create table  */
{#- 创建表 #}
CREATE TABLE {{table_schema|upper}}${version_num}.{{basic_info.table_name|upper}} (
{% for m in metadata -%}
    {% if m.table_english_name is not none %}
        {{-m.field_english_name|upper}} {{m.field_type_scale|upper}} COMMENT '{{-m.field_chinese_name}}'
		{%- if not loop.last %}, {%- else %}     {% endif %}
    {% endif -%}
{%- endfor %}
)
COMMENT '{{basic_info.table_cn_name}}'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\27' 
STORED AS ORC TBLPROPERTIES ('orc.compress'='ZSTD')
;


