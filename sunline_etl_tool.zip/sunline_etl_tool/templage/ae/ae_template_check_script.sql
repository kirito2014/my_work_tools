{% set tblnm = basic_info.table_name -%}
{% set table_schema = '' -%}
{% if tblnm.startswith('S01') -%}
    {% set table_schema='AGL_CORP' -%}
{% elif tblnm.startswith('S02') -%}
    {% set table_schema='AGL_RTLB' -%}
{% elif tblnm.startswith('S03') -%}
    {% set table_schema='AGL_LOAN' -%}
{% elif tblnm.startswith('S04') -%}
    {% set table_schema='AGL_ASSM' -%}
{% elif tblnm.startswith('S05') -%}
    {% set table_schema='AGL_FINM' -%}
{% elif tblnm.startswith('S06') -%}
    {% set table_schema='AGL_OPRS' -%}
{% elif tblnm.startswith('S07') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('S08') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('S09') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('S10') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('S11') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('S12') -%}
    {% set table_schema='AGL_COMM' -%}
{% else -%}
    {% set table_schema='AGL_COMM' -%}
{% endif -%}
-- 模板名称: 聚合层-全量流水脚本，删除目标表指定源系统分区的数据，把当天数据插入到目标表中。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-01-09 08:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     分析人员：{{basic_info.analyse_user}}
--     时间粒度：{{basic_info.data_interval}}
--     保留周期：{{basic_info.date_retention}}
--     描述信息：{{basic_info.table_comment}}
--     更新记录：
           {%- for record in update_record %}
		       {%- if record.update_date is not none  %}
--         {{record.update_date}} {{record.update_user}} {{record.update_comment}}
               {%- endif %}
           {%- endfor %}



/* 1.1 drop check result table if exists */
DROP TABLE IF EXISTS AGL_COMM.T99_CHECK_RESULT;


/* 1.2 create check result table  */
CREATE TABLE AGL_COMM.T99_CHECK_RESULT (
     TAB_CN_NAME STRING COMMENT '表中文名'
    ,TAB_EN_NAME STRING COMMENT '表英文名'
    ,FIELD_CN_NAME STRING COMMENT '字段中文名'
    ,FIELD_EN_NAME STRING COMMENT '字段英文名'
    ,EMPTY_VAL_CNT BIGINT COMMENT '空值数量'
)
COMMENT '检查结果表'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
STORED AS ORC
TBLPROPERTIES ("orc.compress"="ZSTD")
;

/* 1.1 main part */
{#- 主程序 #}

/* 1.2 put data into target table */
{#- 把数据插入目标表 #}
{% for m in metadata -%}
    {% if m.table_english_name is not none %}
        {%- if not loop.first %} {%- else %}     {% endif -%}
        -- {{m.field_english_name|upper}} {{m.field_chinese_name}}
INSERT INTO AGL_COMM.T99_CHECK_RESULT PARTITION(PT_DT = '${process_date}')
SELECT
       '{{m.table_chinese_name|upper}}' AS TAB_CN_NAME -- 表中文名
      ,'{{m.table_english_name|upper}}' AS TAB_EN_NAME -- 表英文名
      ,'{{m.field_chinese_name|upper}}' AS FIELD_CN_NAME -- 字段中文名
      ,'{{m.field_english_name|upper}}' AS FIELD_EN_NAME -- 字段英文名
      ,CAST(COUNT(1) AS BIGINT) AS EMPTY_VAL_CNT -- 空值数量
  FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}
 WHERE COALESCE(CAST({{-m.field_english_name|upper}} AS STRING),'') = ''
   AND PT_DT = '${process_date}';
    {% endif -%}
{%- endfor %}
 ;

