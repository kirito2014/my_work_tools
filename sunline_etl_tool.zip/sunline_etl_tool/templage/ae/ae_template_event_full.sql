{% set tblnm = basic_info.table_name -%}
{% set table_schema = '' -%}
{% if tblnm.startswith('AGL_S01') -%}
    {% set table_schema='AGL_CORP' -%}
{% elif tblnm.startswith('AGL_S02') -%}
    {% set table_schema='AGL_RTLB' -%}
{% elif tblnm.startswith('AGL_S03') -%}
    {% set table_schema='AGL_LOAN' -%}
{% elif tblnm.startswith('AGL_S04') -%}
    {% set table_schema='AGL_ASSM' -%}
{% elif tblnm.startswith('AGL_S05') -%}
    {% set table_schema='AGL_FINM' -%}
{% elif tblnm.startswith('AGL_S06') -%}
    {% set table_schema='AGL_OPRS' -%}
{% elif tblnm.startswith('AGL_S07') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S08') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S09') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S10') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S11') -%}
    {% set table_schema='AGL_COMM' -%}
{% elif tblnm.startswith('AGL_S12') -%}
    {% set table_schema='AGL_COMM' -%}
{% else -%}
    {% set table_schema='AGL_COMM' -%}
{% endif -%}
-- 模板名称: 聚合层-全量流水脚本，删除目标表指定源系统分区的数据，把当天数据插入到目标表中。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-01-09 08:54:00
-- 脚本类型: DML
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     分析人员：{{basic_info.analyse_user}}
--     时间粒度：{{basic_info.data_interval}}
--     保留周期：{{basic_info.date_retention}}
--     描述信息：{{basic_info.table_comment}}
--     更新记录：
           {%- for record in update_record %}
		       {%- if record.update_date is not none  %}
--         {{record.update_date}} {{record.update_user}} {{record.update_comment}}
               {%- endif %}
           {%- endfor %}



/* 1.1 drop main temp table */
{#- 删除默认主临时表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;

/* 1.2 create main temp table  */
{#- 创建主临时表 #}
CREATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM
STORED AS ORC
TBLPROPERTIES ("orc.compress"="ZSTD")
AS
SELECT
{% for m in metadata %}
    {%- if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif %}
{%- endfor %}
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}} WHERE 0=1 ;


/* 1.3 truncate main temp table  */
{#- 清空主临时表 #}
TRUNCATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;

/* 2.1 get today data */
{#- 循环输出每一组字段映射的处理规则 #}
{%- for cm in column_mapping %}
-- =============={{cm.id}}==============
-- {{cm.table_cn_name}}
{%- if 'Y' in cm.template_table_type %}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{cm.table_name|upper}};

CREATE TABLE {{table_schema|upper}}.{{cm.table_name|upper}} (
{% for m in cm.mapping %}
    {%- if m.tgt_column_name is not none %}
        {%- if not loop.first %}, {% else %}      {% endif %}
        {{-m.tgt_column_name}} {{m.tgt_column_type}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
)
COMMENT '{{cm.table_cn_name}}'
STORED AS ORC
TBLPROPERTIES ("orc.compress"="ZSTD")
;
{%- endif %}

INSERT INTO TABLE {{table_schema|upper}}.{{cm.table_name|upper}}(
{% for m in cm.mapping %}
    {%- if m.tgt_column_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.tgt_column_name}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
)
SELECT
{% for m in cm.mapping %}
    {%- if m.mapping_rule is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
            {{-m.mapping_rule}} AS {{m.tgt_column_name}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
FROM 
{%- for tj in cm.table_join %}
{% if tj.join_type is not none %}{{tj.join_type}} {% endif %}
{%- if tj.src_schema is not none %}{{-tj.src_schema}}.{% endif %}
{{-tj.src_table_name}} AS {{tj.src_table_alias}} -- {{tj.src_table_cn_name}}
{% if tj.join_condition is not none %}       ON {{tj.join_condition}} {% endif %}
{%- endfor %}
{#- 以下三项均是有值时才输出 #}
{%- if cm.where is not none %}
WHERE {{cm.where}}
{%- endif %}
{%- if cm.group_by is not none %}
GROUP BY {{cm.group_by}}
{%- endif %}
{%- if cm.order_by is not none %}
ORDER BY {{cm.order_by}}
{%- endif %}
;
{%- endfor %}

/* 3.1 drop target table's today partition */
{#- 清除目标表当天分区数据 #}
ALTER TABLE {{table_schema}}.{{basic_info.table_name}} DROP IF EXISTS PARTITION(PT_DT = '${process_date}');

/* 3.2 put data into target table */
{#- 把数据插入目标表 #}
INSERT INTO {{table_schema|upper}}.{{basic_info.table_name|upper}} PARTITION(PT_DT = '${process_date}')
SELECT
{% for m in metadata -%}
    {% if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif -%}
        {{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif -%}
{%- endfor %}
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM ;


/* 4.1 drop temp table */
{#- 删除所有临时表 #}
DROP TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;
{%- for cm in column_mapping %}
{%- if 'Y' in cm.template_table_type %}
DROP TABLE {{table_schema|upper}}.{{cm.table_name|upper}};
{%- endif %}
{%- endfor %}



