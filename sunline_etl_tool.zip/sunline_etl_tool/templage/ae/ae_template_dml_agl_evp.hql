{% set table_schema='AGL' -%}
-- 模板名称: 聚合层-流水表-区间流水脚本。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-6-27 15:10:00
-- 脚本类型: DML
-- 注意: 1.辅助字段【ETL_PERIOD_DT STRING COMMENT 'ETL区间日期'】需要显式的填写到SDM文档映射每组目标为主临时表_TM的字段映射里面。
--       2.参数 ${interval_flow_dt} 区间起始日期 由配置任务时候选择区间天数，DataOps作业跑批时候会自动计算。
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     分析人员：{{basic_info.analyse_user}}
--     时间粒度：{{basic_info.data_interval}}
--     保留周期：{{basic_info.date_retention}}
--     描述信息：{{basic_info.table_comment}}
--     更新记录：
           {%- for record in update_record %}
               {%- if record.update_date is not none  %}
--         {{record.update_date}} {{record.update_user}} {{record.update_comment}}
               {%- endif %}
           {%- endfor %}



--  0.1 set parameter 
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrick;
set spark.sql.orc.compression.codec=zstd;
set spark.sql.mergeSmallFiles.enabled=false;

/* 1.0 drop old backup table */
{#- 删除旧备份临时表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{basic_info.table_name|upper}}_BK;

/* 1.1 backup before batch_date data */
{#- 创建历史区间数据备份表 #}
CREATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_BK
USING ORC
COMMENT '{{basic_info.table_cn_name}}-历史区间数据备份表'
OPTIONS (compression 'zstd')
AS
SELECT
{% for m in metadata_all %}
    {%- if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif %}
{%- endfor %}
    ,SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO -- 组序号
    ,ETL_LAST_ACG_DT -- ETL更新日期
    ,PT_DT -- ETL区间日期
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}
WHERE PT_DT < '${process_date}' AND PT_DT > '${interval_flow_dt}';


/* 2.1 drop main temp table */
{#- 删除默认主临时表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;

/* 2.2 create main temp table  */
{#- 创建主临时表 #}
CREATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM
USING ORC
COMMENT '{{basic_info.table_cn_name}}-跑批主临时表'
OPTIONS (compression 'zstd')
AS
SELECT
{% for m in metadata_all %}
    {%- if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif %}
{%- endfor %}
    ,SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,CAST(NULL AS STRING) AS ETL_PERIOD_DT -- ETL区间日期
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}} WHERE 0=1 ;


/* 2.3 truncate main temp table  */
{#- 清空主临时表 #}
TRUNCATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;

/* 3.1 get today data */
{#- 循环输出每一组字段映射的处理规则 #}
{%- for cm in column_mapping %}
-- =============={{cm.id}}==============
-- {{cm.table_cn_name}}
{%- if 'Y' in cm.template_table_type %}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{cm.table_name|upper}};

CREATE TABLE {{table_schema|upper}}.{{cm.table_name|upper}} (
{% for m in cm.mapping %}
    {%- if m.tgt_column_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.tgt_column_name}} {{m.tgt_column_type}} COMMENT '{{m.tgt_column_cn_name}}'
    {% endif %}
{%- endfor %}
)
USING ORC
COMMENT '{{cm.table_cn_name}}'
OPTIONS (compression 'zstd')
;
{%- endif %}

INSERT INTO TABLE {{table_schema|upper}}.{{cm.table_name|upper}}(
{% for m in cm.mapping %}
    {%- if m.tgt_column_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
        {{-m.tgt_column_name}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
)
SELECT
{% for m in cm.mapping %}
    {%- if m.mapping_rule is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif %}
            {{-m.mapping_rule}} AS {{m.tgt_column_name}} -- {{m.tgt_column_cn_name}}
    {% endif %}
{%- endfor %}
FROM 
{%- for tj in cm.table_join %}
{% if tj.join_type is not none %}{{tj.join_type}} {% endif %}
{%- if tj.src_schema is not none %}{{-tj.src_schema}}.{% endif %}
{{-tj.src_table_name}} AS {{tj.src_table_alias}} -- {{tj.src_table_cn_name}}
{% if tj.join_condition is not none %}       ON {{tj.join_condition}} {% endif %}
{%- endfor %}
{#- 以下三项均是有值时才输出 #}
{%- if cm.where is not none %}
WHERE {{cm.where}}
{%- endif %}
{%- if cm.group_by is not none %}
GROUP BY {{cm.group_by}}
{%- endif %}
{%- if cm.order_by is not none %}
ORDER BY {{cm.order_by}}
{%- endif %}
;
{%- endfor %}

/* 4.1 drop target table's period partition */
{#- 手工新增目标表当天数据分区，确保遗留数据可以被正确清除 #}
ALTER TABLE {{table_schema}}.{{basic_info.table_name}} ADD IF NOT EXISTS PARTITION(PT_DT = '${process_date}');
{#- 清除目标表日期区间分区数据 #}
ALTER TABLE {{table_schema}}.{{basic_info.table_name}} DROP IF EXISTS PARTITION(PT_DT > '${interval_flow_dt}');

set spark.sql.mergeSmallFiles.enabled=true;
/* 4.2 put data into target table */
{#- 把数据插入目标表 #}
INSERT INTO {{table_schema|upper}}.{{basic_info.table_name|upper}}
SELECT
{% for m in metadata_all -%}
    {% if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif -%}
        {{-"TM."~m.field_english_name|upper}} -- {{m.field_chinese_name}}
    {% endif -%}
{%- endfor %}
    ,TM.SRC_SYS_CD AS SRC_SYS_CD -- 来源系统代码
    ,TM.SRC_TAB_EN_NAME AS SRC_TAB_EN_NAME -- 来源表英文名称
    ,TM.GRP_SER_NO AS GRP_SER_NO -- 组序号
    ,CAST(NOW() AS STRING) AS ETL_TIMESTAMP -- ETL时间戳
    ,CASE WHEN BF.PT_DT IS NULL THEN '${process_date}' -- 新旧数据关联不上,更新ETL_LAST_ACG_DT
     WHEN BF.PT_DT IS NOT NULL AND (
     {% for m in metadata_pk_n -%}
         {% if m.table_english_name is not none -%}
             {% if m.field_type_scale.startswith('STRING') %}
                 {%- if not loop.first %}AND {% else %}     {% endif -%}
                 {{"COALESCE(TM."~m.field_english_name|upper~",'')"}} = {{"COALESCE(BF."~m.field_english_name|upper~",'')"}} -- {{m.field_chinese_name}} 非主键字段相等
             {%- elif m.field_type_scale.startswith('BIGINT') or m.field_type_scale.startswith('DECIMAL') %}
                 {%- if not loop.first %}AND {% else %}     {% endif -%}
                 {{"COALESCE(TM."~m.field_english_name|upper~",CAST(0 AS "~m.field_type_scale|upper~"))"}} = {{"COALESCE(BF."~m.field_english_name|upper~",CAST(0 AS "~m.field_type_scale|upper~"))"}} -- {{m.field_chinese_name}} 非主键字段相等
             {%- elif m.field_type_scale.startswith('DATE') or m.field_type_scale.startswith('TIMESTAMP') %}
                 {%- if not loop.first %}AND {% else %}     {% endif -%}
                 {{"COALESCE(TM."~m.field_english_name|upper~",CAST('0001-01-01' AS "~m.field_type_scale|upper~"))"}} = {{"COALESCE(BF."~m.field_english_name|upper~",CAST('0001-01-01' AS "~m.field_type_scale|upper~"))"}} -- {{m.field_chinese_name}} 非主键字段相等
             {% endif %}
         {% endif -%}
     {%- endfor -%}
     ) THEN BF.ETL_LAST_ACG_DT -- 新旧数据可以关联上且数据无变化,继承ETL_LAST_ACG_DT
     ELSE '${process_date}' END -- 新旧数据可以关联上且数据变化,更新ETL_LAST_ACG_DT
     AS ETL_LAST_ACG_DT -- ETL更新日期
    ,ETL_PERIOD_DT AS PT_DT -- 表分区日期
FROM {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM TM
LEFT JOIN {{table_schema|upper}}.{{basic_info.table_name|upper}}_BK BF
ON (
{% for m in metadata_pk_y -%}
    {% if m.table_english_name is not none -%}
        {% if m.field_type_scale.startswith('STRING') %}
            {%- if not loop.first %}AND {% else %}     {% endif -%}
            {{"COALESCE(TM."~m.field_english_name|upper~",'')"}} = {{"COALESCE(BF."~m.field_english_name|upper~",'')"}} -- {{m.field_chinese_name}} 主键字段关联
        {%- elif m.field_type_scale.startswith('BIGINT') or m.field_type_scale.startswith('DECIMAL') -%}
            {%- if not loop.first %}AND {% else %}     {% endif -%}
            {{"COALESCE(TM."~m.field_english_name|upper~",CAST(0 AS "~m.field_type_scale|upper~"))"}} = {{"COALESCE(BF."~m.field_english_name|upper~",CAST(0 AS "~m.field_type_scale|upper~"))"}} -- {{m.field_chinese_name}} 主键字段关联
        {%- elif m.field_type_scale.startswith('DATE') or m.field_type_scale.startswith('TIMESTAMP') -%}
            {%- if not loop.first %}AND {% else %}     {% endif -%}
            {{"COALESCE(TM."~m.field_english_name|upper~",CAST('0001-01-01' AS "~m.field_type_scale|upper~"))"}} = {{"COALESCE(BF."~m.field_english_name|upper~",CAST('0001-01-01' AS "~m.field_type_scale|upper~"))"}} -- {{m.field_chinese_name}} 主键字段关联
        {% endif %}
    {% endif -%}
{%- endfor -%}
    AND COALESCE(TM.ETL_PERIOD_DT,'') = COALESCE(BF.PT_DT,'') -- 数据日期 主键字段关联
    )
;


/* 5.1 drop temp table */
{#- 删除所有临时表 #}
DROP TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_BK;
DROP TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}}_TM;
{%- for cm in column_mapping %}
{%- if 'Y' in cm.template_table_type %}
DROP TABLE {{table_schema|upper}}.{{cm.table_name|upper}};
{%- endif %}
{%- endfor %}

