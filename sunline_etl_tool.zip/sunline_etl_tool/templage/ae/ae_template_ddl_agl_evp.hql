{% set table_schema='AGL' -%}
-- 模板名称: 聚合层-流水表-区间流水-DDL。此脚本由生成引擎自动生成。
-- 层次-表名: {{basic_info.model_level}}-{{basic_info.table_cn_name}}
-- 模板作者: Zjj,GSP
-- 使用方法: DataOPS平台
-- 模板最后修改日期: 2024-03-10 11:03:00
-- 脚本类型: DDL
-- 修改日志:
--     表英文名：{{basic_info.table_name}}
--     表中文名：{{basic_info.table_cn_name}}
--     创建日期：{{basic_info.create_date}}
--     主键字段：
            {%- for pk in basic_info.table_pk_column %}
                {{-pk}}
                {%- if not loop.last %}, {% endif %}
            {%- endfor %}
--     归属层次：{{basic_info.model_level}}
--     归属主题：{{basic_info.model_theme}}
--     库/模式：{{table_schema}}
--     时间粒度：{{basic_info.data_interval}}
--     描述信息：{{basic_info.table_comment}}



--  0.1 set parameter 
set spark.sql.orc.compression.codec=zstd;

/* 1.1 drop table if exists */
{#- 建表前删除已存在旧表 #}
DROP TABLE IF EXISTS {{table_schema|upper}}.{{basic_info.table_name|upper}};


/* 1.2 create table  */
{#- 创建表 #}
CREATE TABLE {{table_schema|upper}}.{{basic_info.table_name|upper}} (
{% for m in metadata_all -%}
    {% if m.table_english_name is not none %}
        {%- if not loop.first %}, {%- else %}     {% endif -%}
        {{-m.field_english_name|upper}} {{m.field_type_scale|upper}} COMMENT '{{-m.field_chinese_name}}'
    {% endif -%}
{%- endfor %}
    ,SRC_SYS_CD STRING COMMENT '来源系统代码'
    ,SRC_TAB_EN_NAME STRING COMMENT '来源表英文名称'
    ,GRP_SER_NO BIGINT COMMENT '组序号'
    ,ETL_TIMESTAMP STRING COMMENT 'ETL时间戳'
    ,ETL_LAST_ACG_DT STRING COMMENT 'ETL更新日期'
)
USING ORC
COMMENT '{{basic_info.table_cn_name}}'
PARTITIONED BY (
    PT_DT STRING COMMENT '表分区日期'
)
OPTIONS (compression 'zstd')
;





