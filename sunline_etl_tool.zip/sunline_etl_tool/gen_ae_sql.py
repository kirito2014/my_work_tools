#!/usr/bin/env python3
# -*- coding:utf-8 -*-

"""
作者: zjj
日期: 20231128
功能: 用于生成基于AE模板的sql文件，sql文件会生成至 ${ELT_HOME}/autocode/dml/agl|exl/ 目录下
使用方法：python %ETL_HOME%/script/gen_ae_sql.py 归属层次 模板文件路径
        例：python %ETL_HOME%/script/gen_ae_sql.py agl|exl D:/tmp/test.xlsx
日志:
    20231128 zjj v1.0 初始框架版本
    20231205 gsp v1.1 测试版1
    20240120 gsp v1.2 测试版2
    20240208 gsp v1.3 测试版3
    20240301 gsp v1.4 入口程序正式版，只保留main()
"""

import os,re
import sys

from package.ae import ae_sql_generator

def replace_autocode_text(autocode_path1,version,generate_sql_file,exec_type):
    new_generate_sql_file = []
    for sql_file1 in generate_sql_file:
        if exec_type == "dml":
            new_generate_sql_file.append(sql_file1+"_pc.hql")
        if exec_type == "ddl":
            new_generate_sql_file.append("createtable_"+sql_file1+".hql")
    
    for file_name in os.listdir(autocode_path1):
        if file_name in new_generate_sql_file:
            file_all_path = os.path.join(autocode_path1,file_name)
            new_context_list = []
            ods_match_list = []
            with open(file_all_path,'r', encoding='utf-8') as f1:
                line_context = f1.read()
                new_context_list.append(line_context)
                ods_match = re.findall(r'ODS_[A-Za-z0-9]*\.|AGL\.',line_context,re.I)
                if ods_match != "" and ods_match not in ods_match_list:
                    ods_match_list.extend(ods_match)
            new_file = os.path.join(autocode_path1,"temp"+file_name)
            with open(new_file,'w',encoding='utf-8') as f2:
                for new_line in new_context_list:
                    for match_ele in ods_match_list:
                        match_ele1 = match_ele[0:-1]+version+"."
                        new_line = new_line.replace(match_ele,match_ele1)
                    f2.write(new_line)
            os.remove(file_all_path)        
            os.rename(new_file,file_all_path)

def main():
    args = sys.argv
    if len(args) < 3:
        print("Usage: python %ETL_HOME%/gen_ae_sql.py <归属层级> <模板文件路径>")
        return
    at_level, file_path = args[1], args[2]
    
    level_allowed_values = {'agl', 'exl'}
    if at_level not in level_allowed_values:
        print("层级错误，未知层级名：%s！" % at_level)
        return
    
    print("\n归属层次: %s" % at_level)
    print("模板文件路径: %s\n" % file_path)
    
    generate_sql_file=[]
    ae_sql_generator.generate_ae_sql(file_path,generate_sql_file)
    print("本次生成SQL文完毕。\n")
    
    print(generate_sql_file)
    version="${version_num}"
    print("\n库名后缀: %s" % version)
    etl_home1 = os.environ["ETL_HOME"]
    autocode_dml_path1 = etl_home1+os.path.sep+"autocode"+os.path.sep+at_level+os.path.sep+"dml"
    autocode_ddl_path1 = etl_home1+os.path.sep+"autocode"+os.path.sep+at_level+os.path.sep+"ddl"
    replace_autocode_text(autocode_dml_path1,version,generate_sql_file,'dml')
    replace_autocode_text(autocode_ddl_path1,version,generate_sql_file,'ddl')
    print("替换SQL文件中的库名结束。\n")

if __name__ == '__main__':
    main()
