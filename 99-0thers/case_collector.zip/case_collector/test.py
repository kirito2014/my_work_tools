import os
import pandas as pd
import openpyxl
from collections import OrderedDict

'''
#def format_data(case_data):

    main_key = [
        ["*一、案例基本信息", "basic_info"],
        ["*二、项目实施内容", "proj_content"],
        ["*三、案例分类", "case_class"],
        ["*四、案例通用补充信息", "case_supplement"],
        ["*五、其它补充信息", "other_supplement"]
    ]
'''

def format_basic_info_data(case_data):
    '''
    根据特定的单元格内容分割数据，并格式化为不同部分的 DataFrame。
    '''
    # 标志开始和结束的关键字
    start_key = "*合同名称"
    end_key = "*二、项目实施内容"
    
    start_index = None
    end_index = None
    basic_info_dict = []
    # 查找开始和结束的行索引
    for i, row in case_data.iterrows():
        #print(row.iloc[0])
        cell_value = str(row.iloc[0]).strip()  # 将单元格值转换为字符串
        #print(cell_value)
        if cell_value.startswith(start_key):
            start_index = i
        elif cell_value.startswith(end_key):
            end_index = i
            break
    #print(start_index )
    #print(end_index)
    if start_index is not None and end_index is not None:
        # 提取基本信息部分的数据
        basic_info_df = case_data.iloc[start_index:end_index].reset_index(drop=True)
        if basic_info_df is not None:
            print("Basic Info DataFrame:")
            fddd = basic_info_df.iloc[1:].dropna(how='all').copy()
            fddd.columns = basic_info_df.iloc[0]
            # 将 DataFrame 转换为数组
            data_array = fddd.to_numpy()
            column_names = fddd.columns.tolist()
            
            # 转换成字典列表
            for row in data_array:
                row_dict = {}
                for key, value in zip(column_names, row):
                    if isinstance(key, str) and key.startswith("*合同名称"):
                        row_dict["contract_name"] = value
                    elif isinstance(key, str) and key.startswith("*项目规模"):
                        row_dict["project_scale"] = value
                    elif isinstance(key, str) and key.startswith("*合同年份"):
                        row_dict["contract_year"] = value
                    elif isinstance(key, str) and key.startswith("*是否人力外包"):
                        row_dict["is_outsourced"] = value
                    elif isinstance(key, str) and key.startswith("*客户简称"):
                        row_dict["cust_abb"] = value
                    elif isinstance(key, str) and key.startswith("*客户联系人及联系方式"):
                        row_dict["cust_contact"] = value
                    elif isinstance(key, str) and key.startswith("是否涉及新开业或合并"):
                        row_dict["is_new_cust"] = value
                    elif isinstance(key, str) and key.startswith("*主管系统部"):
                        row_dict["hd_managedp"] = value
                    elif isinstance(key, str) and key.startswith("*分管系统部"):
                        row_dict["asi_managedp"] = value
                    elif isinstance(key, str) and key.startswith("*项目经理"):
                        row_dict["project_manager"] = value
                    elif isinstance(key, str) and key.startswith("*销售区域"):
                        row_dict["sale_area"] = value
                    elif isinstance(key, str) and key.startswith("*实施周期"):
                        row_dict["project_period"] = value
                    elif isinstance(key, str) and key.startswith("*项目状态"):
                        row_dict["project_status"] = value
                basic_info_dict.append(row_dict)
                #print(basic_info_dict)
                return basic_info_dict
    else:
        print(f"无法找到 {start_key} 或 {end_key}")
        return None
#文档检查
def check_and_process_file(filepath):
    # 打开Excel文件
    try:
        df_source = pd.read_excel(filepath, sheet_name='案例调研')
        #print(df_source)

        # 格式化数据，提取基本信息部分
        basic_info_dict = format_basic_info_data(df_source)
        for data_dict in basic_info_dict:
                        for key, value in data_dict.items():
                            print(f"{key}: {value}")

















    except Exception as e:
        print(f"Error opening {filepath}: {e}")
    
#清除目标文件信息
def clear_target_file(target_file_path):
    sheet_names_to_check = ["案例清单", "通用补充信息", "数据应用类补充信息", "客户清单"]
    error_log = f"error_log.txt"
    try:
        workbook = openpyxl.load_workbook(target_file_path)
    except Exception as e:
        log_error(error_log, f"无法加载目标文件: {e}")
        return
    
    for sheet_name in sheet_names_to_check:
        if sheet_name in workbook.sheetnames:
            if sheet_name != "客户清单":  # "客户清单"不需要清除内容
                sheet = workbook[sheet_name]
                for row in sheet.iter_rows(min_row=4):
                    for cell in row:
                        cell.value = None
        else:
            log_error(error_log, f"目标文件中缺少 {sheet_name} 页，请检查")
    
    try:
        workbook.save(target_file_path)
    except Exception as e:
        log_error(error_log, f"无法保存目标文件: {e}")
#日志记录
def log_error(log_file,message):
    with open(log_file, 'w', encoding='utf-8') as f:
        f.write(message + '\n')
    print(message)
    


if __name__ == "__main__":
    source_file_path='D:/github/99-0thers/case_collector/第一季度案例收集/北部湾湖仓一体实施项目案例信息- 调研模板-20240529.xlsx'
    target_file_path='D:/github/99-0thers/case_collector/1111.xlsx'
    #clear_target_file(target_file_path)
    check_and_process_file(source_file_path)